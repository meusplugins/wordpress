<?php
namespace com\sakuraplugins\appetit\templates\admin;

class AdminBanner {
    static function render(): void {
        ?>
        <div class="appetit-admin-banner">
            <div class="title"><span style="font-weight: normal;"><?= esc_html__('Insta', 'instafood'); ?></span><span><?= esc_html__('Food', 'instafood'); ?></span></div>
        </div>
        <?php
    }
}
?>