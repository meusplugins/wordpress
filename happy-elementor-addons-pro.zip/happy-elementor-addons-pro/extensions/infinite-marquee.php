<?php
namespace Happy_Addons_Pro\Extensions;

// Elementor Classes.
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Infinite_Marquee {

/**
 * @var mixed
 */
	private static $instance = null;

	/**
	 * @var mixed
	 */
	private $load_script = null;

	public static function instance() {
		if ( null === ( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {

		// Enqueue the required JS file.
		add_action( 'wp_enqueue_scripts', [$this, 'register_scripts'] );
		add_action( 'wp_enqueue_scripts', [$this, 'register_styles'] );

		add_action( 'elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts'] );

		// Creates Horizontal Scroll tab at the end of layout/content & section advance tab.
		// Container
		if ( defined( 'ELEMENTOR_VERSION' ) && ha_elementor()->experiments->is_feature_active( 'container' ) ) {
			add_action( 'elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 1 );
		}

		// Section
		add_action( 'elementor/element/section/section_advanced/after_section_end', [$this, 'register_controls'], 1 );

		add_action( 'elementor/frontend/container/before_render', [$this, 'before_render'] );

	}

	// Register Scripts
	public function register_scripts() {
		$suffix = ha_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'happy-infinite-marquee',
			HAPPY_ADDONS_PRO_ASSETS . 'js/infinite-marquee' . $suffix . 'js',
			['jquery', 'happy-elementor-addons'],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}

	// Register Styles
	public function register_styles() {
		$suffix = ha_is_script_debug_enabled() ? '.' : '.min.';
		wp_register_style(
			'happy-infinite-marquee',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/infinite-marquee.min.css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);
	}

	// Enqueue Preview Scripts
	public function enqueue_preview_scripts() {
		wp_enqueue_script( 'gsap' );
		wp_enqueue_script( 'happy-infinite-marquee' );

		wp_enqueue_style( 'happy-infinite-marquee' );
	}

	public function register_controls( $element ) {

		$element->start_controls_section(
			'_ha_im_section',
			[
				'label' => esc_html__( 'Marquee', 'happy-addons-pro' ) . ha_get_section_icon(),
				'tab'   => Controls_Manager::TAB_ADVANCED
			]
		);

		$element->add_control(
			'ha_im_help_url_notice_box',
			[
				'type'        => Controls_Manager::NOTICE,
				'notice_type' => 'info',
				'content'     => sprintf(
					esc_html__( 'Need help? %s', 'happy-addons-pro' ),
					'<a href="https://happyaddons.com/docs/happy-addons-for-elementor-pro/features/marquee-animation-2/" target="_blank" rel="noopener noreferrer">'
					. esc_html__( 'Read Documentation', 'happy-addons-pro' )
					. '</a>'
				),
			]
		);

		$this->add_content_controls( $element );

		$element->end_controls_section();
	}

	public function add_content_controls( $element ) {

		$element->add_control(
			'ha_im_init_notice',
			[
				'type'       => Controls_Manager::ALERT,
				'alert_type' => 'info',
				'heading'    => esc_html__( 'Note:', 'happy-addons-pro' ),
				'content'    => esc_html__( 'You must set your container / section to full width for this feature to work.', 'happy-addons-pro' )
			]
		);

		$element->add_control(
			'ha_im_switcher',
			[
				'label'              => __( 'Enable', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'prefix_class'       => 'ha-im-',
				'render_type'        => 'template',
				'return_value'       => 'yes',
				'style_transfer'     => false,
				'frontend_available' => true,
				'assets'             => [
					'scripts' => [
						[
							'name'       => 'elementor-frontend',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_im_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						],
						[
							'name'       => 'gsap',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_im_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						],
						[
							'name'       => 'happy-infinite-marquee',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_im_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						]
					],
					'styles'  => [
						[
							'name'       => 'happy-infinite-marquee',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_im_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						]
					]
				]
			]
		);

	$element->add_control(
		'ha_im_disable_in_editor',
		[
			'label'              => __( 'Disable in Editor', 'happy-addons-pro' ),
			'description'        => __( 'Turn off the marquee animation inside the editor so you can edit the items in their normal layout. Does not affect the live site.', 'happy-addons-pro' ),
			'type'               => Controls_Manager::SWITCHER,
			'label_on'           => __( 'Yes', 'happy-addons-pro' ),
			'label_off'          => __( 'No', 'happy-addons-pro' ),
			'return_value'       => 'yes',
			'default'            => 'yes',
			'render_type'        => 'template',
			'frontend_available' => true,
			'condition'          => [
				'ha_im_switcher' => 'yes'
			]
		]
	);

	$element->add_control(
		'ha_im_pause_hover',
			[
				'label'              => __( 'Pause on Hover', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'prefix_class'       => 'ha-im-pause-',
				'return_value'       => 'yes',
				'default'            => '',
				'condition'          => [
					'ha_im_switcher' => 'yes'
				],
				'render_type'        => 'template',
				'frontend_available' => true
			]
		);

		$element->add_responsive_control(
			'ha_im_speed',
			[
				'label'              => __( 'Speed(ms)', 'happy-addons-pro' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'step'               => 1,
				'default'            => 120,
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes'
				],
				'toggle'             => false,
				'style_transfer'     => true
			]
		);

		$element->add_responsive_control(
			'ha_im_mode',
			[
				'label'              => __( 'Mode', 'happy-addons-pro' ),
				'type'               => Controls_Manager::CHOOSE,
				'options'            => [
					'horizontal' => [
						'title' => __( 'Horizontal', 'happy-addons-pro' ),
						'icon'  => 'eicon-align-stretch-h'
					],
					'vertical'   => [
						'title' => __( 'Vertical', 'happy-addons-pro' ),
						'icon'  => 'eicon-align-stretch-v'
					]
				],
				'default'            => 'horizontal',
				'condition'          => [
					'ha_im_switcher' => 'yes'
				],
				'render_type'        => 'template',
				'frontend_available' => true
			]
		);

		$element->add_responsive_control(
			'ha_im_horizontal_direction',
			[
				'label'              => __( 'Direction', 'happy-addons-pro' ),
				'type'               => Controls_Manager::CHOOSE,
				'render_type'        => 'template',
				'frontend_available' => true,
				'options'            => [
					'left'  => [
						'title' => __( 'Left', 'happy-addons-pro' ),
						'icon'  => 'eicon-h-align-left'
					],
					'right' => [
						'title' => __( 'Right', 'happy-addons-pro' ),
						'icon'  => 'eicon-h-align-right'
					]
				],
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode' => 'horizontal',
				],
				'default'            => 'left',
				'toggle'             => false,
				'style_transfer'     => true
			]
		);

		$element->add_responsive_control(
			'ha_im_vertical_direction',
			[
				'label'              => __( 'Direction', 'happy-addons-pro' ),
				'type'               => Controls_Manager::CHOOSE,
				'render_type'        => 'template',
				'frontend_available' => true,
				'options'            => [
					'top'  => [
						'title' => __( 'Top', 'happy-addons-pro' ),
						'icon'  => 'eicon-v-align-top'
					],
					'bottom' => [
						'title' => __( 'Bottom', 'happy-addons-pro' ),
						'icon'  => 'eicon-v-align-bottom'
					]
				],
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode' => 'vertical',
				],
				'default'            => 'top',
				'toggle'             => false,
				'style_transfer'     => true
			]
		);

		$element->add_responsive_control(
			'ha_im_gap_between_iem',
			[
				'label'              => __( 'Items Gap', 'happy-addons-pro' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 0,
				'max'                => 1000,
				'step'               => 1,
				'default'            => 5,
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes'
				],
				'toggle'             => false,
				'style_transfer'     => true,
				'selectors'      => [
					'{{WRAPPER}}.ha-marquee-container .ha-marquee-content' => 'gap:{{VALUE}}px;',
				],
			]
		);

		$element->add_control(
			'ha_im_elips',
			[
				'label'              => __( 'Ellipse (Arc) Effect', 'happy-addons-pro' ),
				'description'        => __( 'Display marquee items along a smooth curved arc instead of a straight line.', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'prefix_class'       => 'ha-im-elips-',
				'return_value'       => 'yes',
				'default'            => '',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
				],
			]
		);

		$element->add_responsive_control(
			'ha_im_elips_curve',
			[
				'label'              => __( 'Curve Depth', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SLIDER,
				'size_units'         => [ 'px' ],
				'range'              => [
					'px' => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					],
				],
				'default'            => [
					'unit' => 'px',
					'size' => 130,
				],
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
					'ha_im_elips'    => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_im_elips_rotate',
			[
				'label'              => __( 'Rotate Effect', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'return_value'       => 'yes',
				'default'            => 'yes',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
					'ha_im_elips'    => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_im_elips_zoom',
			[
				'label'              => __( 'Zoom Effect', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'return_value'       => 'yes',
				'default'            => 'yes',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
					'ha_im_elips'    => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_im_elips_fade',
			[
				'label'              => __( 'Fade Effect', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'return_value'       => 'yes',
				'default'            => 'yes',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
					'ha_im_elips'    => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_im_elips_blur',
			[
				'label'              => __( 'Blur Effect', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'return_value'       => 'yes',
				'default'            => '',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
					'ha_im_mode'     => 'horizontal',
					'ha_im_elips'    => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_im_enable_on_mobile',
			[
				'label'              => __( 'Enable On Mobile', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_on'           => __( 'Yes', 'happy-addons-pro' ),
				'label_off'          => __( 'No', 'happy-addons-pro' ),
				'return_value'       => 'yes',
				'default'            => 'no',
				'render_type'        => 'template',
				'frontend_available' => true,
				'condition'          => [
					'ha_im_switcher' => 'yes',
				],
				'description'        => __( 'When disabled, the marquee animation will not run on mobile devices.', 'happy-addons-pro' ),
			]
		);

	}

	/**
	 * Render Global badge output on the frontend.
	 * @param $element Elementor Element instance.
	 * @return void
	 *
	 */
	public function before_render( $element ) {
		$settings     = $element->get_settings_for_display();
		$element_type = $element->get_type();

		$id = $element->get_id();

		if ( empty( $settings['ha_im_switcher'] ) || 'yes' !== $settings['ha_im_switcher'] ) {
			return;
		}

		$ha_im_switcher = $settings['ha_im_switcher'] ?? 'no';

		// Base classes
		$classes = ['ha-marquee-container'];

		// Attach to wrapper
		$element->add_render_attribute(
			'_wrapper',
			[
				'class'      => implode( ' ', $classes ),
				'data-ha-im' => '1'
			]
		);

	}

}
