<?php
/**
 * Class: Jet_Woo_Product_Gallery_Anchor_Nav
 * Name: Gallery Anchor Navigation
 * Slug: jet-woo-product-gallery-anchor-nav
 */

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Jet_Woo_Product_Gallery_Anchor_Nav extends Jet_Gallery_Widget_Base {

	public function get_name() {
		return 'jet-woo-product-gallery-anchor-nav';
	}

	public function get_title() {
		return __( 'Gallery Anchor Navigation', 'jet-woo-product-gallery' );
	}

	public function get_script_depends() {
		return array( 'zoom', 'wc-single-product', 'mediaelement', 'photoswipe-ui-default', 'photoswipe' );
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 1.0.0
	 * @since 2.1.19 Added widget styles.
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'jet-gallery-widget-gallery-anchor-nav' ];
	}

	public function get_icon() {
		return 'jet-gallery-icon-anchor-nav';
	}

	public function get_jet_help_url() {
		return 'https://crocoblock.com/knowledge-base/articles/jetproductgallery-gallery-anchor-navigation-widget-how-to-create-a-scrollable-product-images-layout-with-an-anchor-navigation-element/';
	}

	public function get_categories() {
		return array( 'jet-woo-product-gallery' );
	}

	public function register_gallery_content_controls() {

		$this->start_controls_section(
			'section_product_images',
			array(
				'label'      => __( 'Images', 'jet-woo-product-gallery' ),
				'tab'        => Controls_Manager::TAB_CONTENT,
				'show_label' => false,
			)
		);

		$this->add_control(
			'image_size',
			array(
				'label'   => __( 'Image Size', 'jet-woo-product-gallery' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'full',
				'options' => jet_woo_product_gallery_tools()->get_image_sizes(),
			)
		);

		$this->add_control(
			'thumbs_image_size',
			[
				'label'   => __( 'Thumbnails Size', 'jet-woo-product-gallery' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'thumbnail',
				'options' => jet_woo_product_gallery_tools()->get_image_sizes(),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_navigation_settings',
			array(
				'label'      => __( 'Navigation', 'jet-woo-product-gallery' ),
				'tab'        => Controls_Manager::TAB_CONTENT,
				'show_label' => false,
			)
		);

		$this->add_control(
			'navigation_type',
			array(
				'type'    => Controls_Manager::CHOOSE,
				'label'   => __( 'Navigation Type', 'jet-woo-product-gallery' ),
				'options' => [
					'bullets'    => [
						'title' => __( 'Bullets', 'jet-woo-product-gallery' ),
						'icon'  => 'eicon-navigation-horizontal',
					],
					'thumbnails' => [
						'title' => __( 'Thumbnails', 'jet-woo-product-gallery' ),
						'icon'  => 'eicon-image',
					],
				],
				'default' => 'bullets',
			)
		);

		$video_thumbnail_conditions = [
			'relation' => 'and',
			'terms'    => [
				[
					'name'     => 'video_display_in',
					'operator' => '===',
					'value'    => 'content',
				],
				[
					'name'     => 'navigation_type',
					'operator' => '===',
					'value'    => 'thumbnails',
				],
				[
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'enable_video',
							'operator' => '===',
							'value'    => 'yes',
						],
						[
							'name'     => 'gallery_source',
							'operator' => '===',
							'value'    => 'products',
						],
					],
				],
			],
		];

		$video_thumbnail_show_conditions = $video_thumbnail_conditions;
		$video_thumbnail_show_conditions['terms'][] = [
			'name'     => 'selected_video_thumbnail_icon[value]',
			'operator' => '!==',
			'value'    => '',
		];

		$this->add_control(
			'video_thumbnail_heading',
			[
				'label'      => __( 'Video Thumbnail', 'jet-woo-product-gallery' ),
				'type'       => Controls_Manager::HEADING,
				'separator'  => 'before',
				'conditions' => $video_thumbnail_conditions,
			]
		);

		$this->__add_advanced_icon_control(
			'video_thumbnail_icon',
			[
				'label'       => __( 'Thumbnail Icon', 'jet-woo-product-gallery' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => true,
				'file'        => '',
				'conditions'  => $video_thumbnail_conditions,
			]
		);

		$this->add_control(
			'video_thumbnail_show_thumbnail',
			[
				'label'      => __( 'Show Thumbnail', 'jet-woo-product-gallery' ),
				'type'       => Controls_Manager::SELECT,
				'default'    => 'yes',
				'options'    => [
					'yes' => __( 'Yes', 'jet-woo-product-gallery' ),
					'no'  => __( 'No', 'jet-woo-product-gallery' ),
				],
				'conditions' => $video_thumbnail_show_conditions,
			]
		);
		
		$this->add_control(
			'navigation_position',
			array(
				'label'        => __( 'Navigation Position', 'jet-woo-product-gallery' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'outside',
				'options'      => array(
					'outside' => __( 'Outside', 'jet-woo-product-gallery' ),
					'inside'  => __( 'Inside', 'jet-woo-product-gallery' ),
				),
				'prefix_class' => 'navigation-position-',
			)
		);
		
		$this->end_controls_section();
		
		$css_scheme = apply_filters(
			'jet-woo-product-gallery-anchor-nav/css-scheme',
			[
				'item'                         => '.jet-woo-product-gallery__image-item',
				'items'                        => '.jet-woo-product-gallery-anchor-nav-items',
				'images'                       => '.jet-woo-product-gallery-anchor-nav .jet-woo-product-gallery__image',
				'controller'                   => '.jet-woo-product-gallery-anchor-nav-controller',
				'controller-sticky'            => '.jet-woo-product-gallery-anchor-nav-controller-sticky',
				'controller-item'              => '.jet-woo-product-gallery-anchor-nav-controller .controller-item',
				'controller-bullet'            => '.jet-woo-product-gallery-anchor-nav-controller .controller-item__bullet',
				'controller-bullet-current'    => '.jet-woo-product-gallery-anchor-nav-controller .current-item .controller-item__bullet',
				'controller-thumbnail'         => '.jet-woo-product-gallery-anchor-nav-controller .controller-item__thumbnail img',
				'controller-thumbnail-current' => '.jet-woo-product-gallery-anchor-nav-controller .current-item .controller-item__thumbnail img',
				'video-thumbnail-icon'         => '.jet-woo-product-gallery-anchor-nav-controller .controller-item__thumbnail-video-icon',
			]
		);

		$this->register_controls_images_style( $css_scheme );

		$this->register_controls_controller_style( $css_scheme );

	}

	public function register_controls_images_style( $css_scheme ) {

		$this->start_controls_section(
			'section_gallery_images_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Images', 'jet-woo-product-gallery' ),
			]
		);

		$this->add_responsive_control(
			'gallery_images_space_between',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Space Between Images', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'size' => 5,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['item'] . '+' . $css_scheme['item'] => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'gallery_images_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-woo-product-gallery' ),
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['images'] => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'gallery_images_border',
				'selector' => '{{WRAPPER}} ' . $css_scheme['images'],
			]
		);

		$this->add_control(
			'gallery_images_border_radius',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Radius', 'jet-woo-product-gallery' ),
				'size_units' => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['images'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'gallery_images_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['images'],
			)
		);

		$this->end_controls_section();

	}

	public function register_controls_controller_style( $css_scheme ) {
		$this->start_controls_section(
			'section_controller_style',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'Navigation', 'jet-woo-product-gallery' ),
			]
		);

		$this->add_responsive_control(
			'controller_width',
			[
				'type'        => Controls_Manager::SLIDER,
				'label'       => __( 'Width', 'jet-woo-product-gallery' ),
				'render_type' => 'template',
				'size_units'  => $this->set_custom_size_unit( [ 'px', '%' ] ),
				'range'       => [
					'px' => [
						'min' => 70,
						'max' => 500,
					],
					'%'  => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'     => [
					'size' => 80,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} ' . $css_scheme['controller'] => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} ' . $css_scheme['items']      => 'max-width: calc(100% - {{SIZE}}{{UNIT}});',
				],
				'condition'   => [
					'navigation_position' => 'outside',
					'controller_position' => [ 'left', 'right' ],
				],
			]
		);

		$this->add_responsive_control(
			'controller_offset_top',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Offset Top (px)', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-sticky'] => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'controller_offset_right',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Offset Right (px)', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-sticky'] => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'controller_offset_bottom',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Offset Bottom (px)', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-sticky'] => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'controller_offset_left',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Offset Left (px)', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'    => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-sticky'] => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'controller_align',
			array(
				'label'        => __( 'Controller Align', 'jet-woo-product-gallery' ),
				'type'         => Controls_Manager::CHOOSE,
				'toggle'       => false,
				'default'      => 'start',
				'options'      => array(
					'start'  => array(
						'title' => __( 'Start', 'jet-woo-product-gallery' ),
						'icon'  => ! is_rtl() ? 'eicon-text-align-left' : 'eicon-text-align-right',
					),
					'center'  => array(
						'title' => __( 'Center', 'jet-woo-product-gallery' ),
						'icon'  => 'eicon-text-align-center',
					),
					'end' => array(
						'title' => __( 'End', 'jet-woo-product-gallery' ),
						'icon'  => ! is_rtl() ? 'eicon-text-align-right' : 'eicon-text-align-left',
					),

				),
				'prefix_class' => 'jet-woo-product-gallery-anchor-nav-controller-align-',
				'condition'   => [
					'navigation_type' => 'bullets',
					'controller_position' => [ 'top', 'bottom' ],
				],
			)
		);

		$this->add_control(
			'controller_position',
			array(
				'label'        => __( 'Position', 'jet-woo-product-gallery' ),
				'type'         => Controls_Manager::CHOOSE,
				'toggle'       => false,
				'default'      => 'left',
				'options'      => array(
					'top'  => array(
						'title' => __( 'Top', 'jet-woo-product-gallery' ),
						'icon'  => 'eicon-v-align-top',
					),
					'left'  => array(
						'title' => __( 'Start', 'jet-woo-product-gallery' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-left' : 'eicon-h-align-right',
					),
					'right' => array(
						'title' => __( 'End', 'jet-woo-product-gallery' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-right' : 'eicon-h-align-left',
					),
					'bottom'  => array(
						'title' => __( 'Bottom', 'jet-woo-product-gallery' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'prefix_class' => 'jet-woo-product-gallery-anchor-nav-controller-',
			)
		);

		$this->add_control(
			'controller_bullets_heading',
			array(
				'label'      => __( 'Bullets', 'jet-woo-product-gallery' ),
				'type'       => Controls_Manager::HEADING,
				'separator'  => 'before',
				'condition'  => [
					'navigation_type' => 'bullets',
				],
			)
		);

		$this->add_control(
			'controller_thumbnails_heading',
			array(
				'label'     => __( 'Thumbnails', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'navigation_type' => 'thumbnails',
				],
			)
		);

		$this->add_responsive_control(
			'controller_bullets_width',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Width', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'navigation_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'controller_bullets_height',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Height', 'jet-woo-product-gallery' ),
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'navigation_type' => 'bullets',
				],
			]
		);

		$this->start_controls_tabs( 'controller_style_tabs',
		);

		$this->start_controls_tab(
			'controller_normal_styles',
			[
				'label' => __( 'Normal', 'jet-woo-product-gallery' ),
			]
		);

		$this->add_control(
			'controller_thumbnails_opacity',
			[
				'type'      => Controls_Manager::SLIDER,
				'label'     => __( 'Opacity', 'jet-woo-product-gallery' ),
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'default' => [
					'size' => 0.5,
				],
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail']   => 'opacity: {{SIZE}};',
					'{{WRAPPER}} ' . $css_scheme['video-thumbnail-icon'] => 'opacity: {{SIZE}};',
				],
				'condition'  => [
					'navigation_type' => 'thumbnails',
				],
			]
		);

		$this->add_control(
			'controller_bullets_normal_background_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Background Color', 'jet-woo-product-gallery' ),
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] => 'background-color: {{VALUE}}',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail'] => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'controller_hover_styles',
			array(
				'label' => __( 'Hover', 'jet-woo-product-gallery' ),
			)
		);

		$this->add_control(
			'controller_thumbnails_opacity_hover',
			[
				'type'      => Controls_Manager::SLIDER,
				'label'     => __( 'Opacity', 'jet-woo-product-gallery' ),
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'default' => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail'] . ':hover' => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .jet-woo-product-gallery-anchor-nav-controller .controller-item:hover .controller-item__thumbnail-video-icon' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'navigation_type' => 'thumbnails',
				],
			]
		);

		$this->add_control(
			'controller_bullets_hover_background_color',
			array(
				'label'     => __( 'Background Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] . ':hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail'] . ':hover' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'controller_bullets_hover_border_color',
			array(
				'label'     => __( 'Border Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] . ':hover' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail'] . ':hover' => 'border-color: {{VALUE}}',

				),
				'condition' => array(
					'controller_bullets_normal_border_border!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'controller_bullets_hover_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['controller-bullet'] . ':hover' . ', {{WRAPPER}} ' . $css_scheme['controller-thumbnail'] . ':hover',
			)
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'controller_current_styles',
			array(
				'label' => __( 'Current', 'jet-woo-product-gallery' ),
			)
		);

		$this->add_control(
			'controller_thumbnails_opacity_active',
			[
				'type'      => Controls_Manager::SLIDER,
				'label'     => __( 'Opacity', 'jet-woo-product-gallery' ),
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'default' => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail-current']                                          => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .jet-woo-product-gallery-anchor-nav-controller .current-item .controller-item__thumbnail-video-icon' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'navigation_type' => 'thumbnails',
				],
			]
		);

		$this->add_control(
			'controller_bullets_current_background_color',
			array(
				'label'     => __( 'Background Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['controller-bullet-current'] => 'background-color: {{VALUE}}',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail-current'] => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'controller_bullets_current_border_color',
			array(
				'label'     => __( 'Border Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['controller-bullet-current'] => 'border-color: {{VALUE}}',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail-current'] => 'border-color: {{VALUE}}',
				),
				'condition' => array(
					'controller_bullets_normal_border_border!' => '',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'controller_bullets_current_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['controller-bullet-current'] . ', {{WRAPPER}} ' . $css_scheme['controller-thumbnail-current'],
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'controller_bullets_normal_border',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} ' . $css_scheme['controller-bullet'] . ', {{WRAPPER}} ' . $css_scheme['controller-thumbnail'],
			]
		);

		$this->add_control(
			'controller_bullets_border_radius',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Border Radius', 'jet-woo-product-gallery' ),
				'size_units' => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} ' . $css_scheme['controller-thumbnail'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'controller_bullets_normal_shadow',
				'selector'  => '{{WRAPPER}} ' . $css_scheme['controller-bullet'] . ', {{WRAPPER}} ' . $css_scheme['controller-thumbnail'],
			]
		);

		$this->add_responsive_control(
			'controller_bullets_margin',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => __( 'Margin', 'jet-woo-product-gallery' ),
				'size_units' => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-bullet'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'navigation_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'controller_thumbnails_gutter',
			[
				'type'               => Controls_Manager::DIMENSIONS,
				'label'              => __( 'Gutter', 'jet-woo-product-gallery' ),
				'separator'          => 'before',
				'size_units'         => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'allowed_dimensions' => 'horizontal',
				'render_type'        => 'template',
				'placeholder'        => [
					'top'    => 'auto',
					'right'  => '',
					'bottom' => 'auto',
					'left'   => '',
				],
				'selectors'          => [
					'{{WRAPPER}} ' . $css_scheme['controller'] => 'padding-left: {{LEFT}}{{UNIT}}; padding-right: {{RIGHT}}{{UNIT}};',
				],
				'condition'          => [
					'navigation_type' => 'thumbnails',
				]
			]
		);

		$this->add_responsive_control(
			'controller_thumbnails_width',
			[
				'type'        => Controls_Manager::SLIDER,
				'label'       => __( 'Thumbnails Width', 'jet-woo-product-gallery' ),
				'render_type' => 'template',
				'size_units'  => $this->set_custom_size_unit( [ 'px', '%' ] ),
				'range'       => [
					'px' => [
						'min' => 70,
						'max' => 500,
					],
					'%'  => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'     => [
					'size' => 150,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}} ' . $css_scheme['controller'] => 'max-width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'controller_position' => [ 'left', 'right' ],
					'navigation_type' => 'thumbnails',
					'navigation_position' => 'inside',
				],
			]
		);

		$this->add_responsive_control(
			'controller_thumbnails_spacing_v',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Thumbnails Spacing', 'jet-woo-product-gallery' ),
				'size_units' => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-item'] . ':not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'navigation_type'     => 'thumbnails',
					'controller_position' => [ 'left', 'right' ],
				],
			]
		);

		$this->add_responsive_control(
			'controller_thumbnails_spacing_h',
			[
				'type'       => Controls_Manager::SLIDER,
				'label'      => __( 'Thumbnails Spacing', 'jet-woo-product-gallery' ),
				'size_units' => $this->set_custom_size_unit( [ 'px', 'em', '%' ] ),
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['controller-item'] . ( !is_rtl() ? ':not(:last-child)' : ':not(:first-child)' ) => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'navigation_type'     => 'thumbnails',
					'controller_position' => [ 'top', 'bottom' ],
				],
			]
		);

		$video_thumbnail_icon_conditions = [
			'relation' => 'and',
			'terms'    => [
				[
					'name'     => 'video_display_in',
					'operator' => '===',
					'value'    => 'content',
				],
				[
					'name'     => 'navigation_type',
					'operator' => '===',
					'value'    => 'thumbnails',
				],
				[
					'name'     => 'selected_video_thumbnail_icon[value]',
					'operator' => '!==',
					'value'    => '',
				],
			],
		];

		$this->add_control(
			'video_thumbnail_icon_style_heading',
			[
				'label'      => __( 'Video Thumbnail Icon', 'jet-woo-product-gallery' ),
				'type'       => Controls_Manager::HEADING,
				'separator'  => 'before',
				'conditions' => $video_thumbnail_icon_conditions,
			]
		);

		$this->add_responsive_control(
			'video_thumbnail_icon_size',
			[
				'label'      => __( 'Size', 'jet-woo-product-gallery' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default'    => [
					'size' => 32,
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} ' . $css_scheme['video-thumbnail-icon'] => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'conditions' => $video_thumbnail_icon_conditions,
			]
		);

		$this->start_controls_tabs(
			'video_thumbnail_icon_style_tabs',
			[
				'conditions' => $video_thumbnail_icon_conditions,
			]
		);

		$this->start_controls_tab(
			'video_thumbnail_icon_normal_style_tab',
			[
				'label' => __( 'Normal', 'jet-woo-product-gallery' ),
			]
		);

		$this->add_control(
			'video_thumbnail_icon_color',
			[
				'label'     => __( 'Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ' . $css_scheme['video-thumbnail-icon'] => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'video_thumbnail_icon_hover_style_tab',
			[
				'label' => __( 'Hover', 'jet-woo-product-gallery' ),
			]
		);

		$this->add_control(
			'video_thumbnail_icon_hover_color',
			[
				'label'     => __( 'Color', 'jet-woo-product-gallery' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .jet-woo-product-gallery-anchor-nav-controller .controller-item:hover .controller-item__thumbnail-video-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'video_thumbnail_icon_notice',
			[
				'type'       => Controls_Manager::RAW_HTML,
				'raw'        => __( '<strong>Note:</strong> Color and hover color may not work correctly with some icons.', 'jet-woo-product-gallery' ),
				'separator'  => 'before',
				'conditions' => $video_thumbnail_icon_conditions,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		jet_woo_product_gallery()->base->render_gallery( 'gallery-anchor-nav', $this->get_settings_for_display(), 'elementor' );
	}

}