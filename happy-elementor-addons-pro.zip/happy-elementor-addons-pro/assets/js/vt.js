"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/**
	 * Publish each title's real (unscaled) painted width as
	 * --ha-v-tabs-title-w on its .ha-v-tabs-title-wrap. The CSS zoom is a
	 * transform (layout-neutral), so the "after" prefix number needs it to
	 * compute its translateX((scale − 1) × w) tracking shift. No-op unless
	 * zoom is active — pure guard against wasted reflows.
	 */
function publishVisualTabsTitleWidths(list) {
  if (!list || !list.classList.contains('ha-v-tabs-zoom')) {
    return;
  }
  var wraps = list.querySelectorAll(':scope > .ha-v-tabs-item > .ha-v-tabs-title-wrap');
  for (var i = 0; i < wraps.length; i++) {
    var wrap = wraps[i];
    var title = wrap.querySelector(':scope > .ha-v-tabs-service-title');
    if (!title) {
      continue;
    }
    var next = Math.round(title.offsetWidth) + 'px';
    if (wrap.style.getPropertyValue('--ha-v-tabs-title-w') !== next) {
      wrap.style.setProperty('--ha-v-tabs-title-w', next);
    }
  }
}

/**
 * HappyNestedServiceScroll
 *
 * Frontend controller that turns a `.ha-v-tabs-list` (scroll mode) into an
 * Apple-style pinned storytelling section. One instance per widget; fully
 * scoped — no global selectors are used.
 *
 * Scroll timeline:
 *   list top hits viewport top  →  pin the whole stage
 *   titles translate upward     →  driven by scroll progress (scrubbed)
 *   titles reach maxTranslate   →  clamp (never overscroll)
 *   remaining panels swap       →  active index keeps advancing
 *   last panel revealed         →  release pin, resume normal scroll
 *
 * All geometry (item count, title heights, stage height, max translate,
 * scroll distance, active index) is measured at runtime and re-measured on
 * resize / ScrollTrigger refresh.
 */
var HappyNestedServiceScroll = /*#__PURE__*/function () {
  /**
   * @param {HTMLElement} listEl The .ha-v-tabs-list element.
   * @param {Object}      opts   Config + animation helpers from the widget.
   */
  function HappyNestedServiceScroll(listEl, opts) {
    _classCallCheck(this, HappyNestedServiceScroll);
    this.list = listEl;
    this.opts = opts || {};

    // Config (parsed from data attributes by the caller).
    this.inactiveOpacity = this.opts.inactiveOpacity;
    this.contentAnimation = this.opts.contentAnimation || 'fade';
    this.duration = (this.opts.duration || 400) / 1000; // ms → seconds
    this.easing = this.opts.easing || 'power1.out';

    // Scroll speed: higher = less scroll distance to advance an item.
    // Stored as the inverse multiplier applied to the pin length.
    this.scrollDistance = 1 / Math.max(0.1, this.opts.scrollSpeed || 3);

    // Animation helpers shared with the hover/click paths so the big
    // content-animation switch is never duplicated. Each returns a
    // plain GSAP vars object.
    this.getAnimIn = this.opts.getAnimIn; // () => visible "to" state
    this.getAnimOut = this.opts.getAnimOut; // () => hidden "to" state
    this.getAnimFrom = this.opts.getAnimFrom; // () => hidden "from" state

    // Tunables (kept out of the hot path — no magic numbers inline).
    this.breakpoint = 768; // below this width, pinning is disabled
    this.titlePhase = 0.8; // fraction of the pin spent scrolling titles

    // Cached DOM + measured geometry.
    this.items = [];
    this.titles = []; // per-item title (may contain nulls)
    this.titleEls = []; // non-null titles, used for the transform setter
    this.panels = [];
    this.count = 0;
    this.offsets = []; // cumulative top of each title (pre-transform)
    this.heights = []; // on-screen height of each title
    this.totalTitleHeight = 0;
    this.visibleHeight = 0;
    this.maxTranslate = 0;

    // Runtime state.
    this.active = -1;
    this.swapTl = null;
    this.st = null;
    this.enabled = false;
    this.mq = null;
    this._pinSpacerDiff = 0;

    // Bound handlers (stable refs for add/removeEventListener).
    this._update = this._update.bind(this);
    this._onResize = this._onResize.bind(this);
    this._onMqChange = this._onMqChange.bind(this);
  }

  /* ── Lifecycle ─────────────────────────────────────────── */
  return _createClass(HappyNestedServiceScroll, [{
    key: "init",
    value: function init() {
      this.cacheElements();

      // Single item → full-height stage, first panel visible, no pinning.
      if (this.count < 2) {
        this.list.setAttribute('data-vtabs-pinned', '1');
        this.calculate();
        this._setStageHeight();
        if (typeof gsap !== 'undefined') {
          this._initState();
        } else {
          this._showStatic();
        }
        return this;
      }

      // No GSAP / no ScrollTrigger → safe static fallback.
      if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
        this._markStatic();
        this._showStatic();
        return this;
      }
      gsap.registerPlugin(ScrollTrigger);
      this._claimScrollRestoration();
      this._wireBreakpoint();
      return this;
    }

    /**
     * A reload restores the scroll offset while the document is still
     * being built — before the pin-spacer and stage height exist — so
     * the restored position lands against a half-sized document and the
     * scrubbed pin opens misaligned. Take restoration from the browser:
     * remember the restored Y, then re-apply it once everything has
     * loaded and ScrollTrigger has re-measured.
     */
  }, {
    key: "_claimScrollRestoration",
    value: function _claimScrollRestoration() {
      var cls = HappyNestedServiceScroll;
      if (cls._restorationClaimed) {
        return;
      }
      if (!('scrollRestoration' in window.history) || typeof ScrollTrigger === 'undefined') {
        return;
      }
      cls._restorationClaimed = true;
      var savedY = window.scrollY || window.pageYOffset || 0;
      if (savedY <= 0) {
        return;
      }
      window.history.scrollRestoration = 'manual';
      var settle = function settle() {
        ScrollTrigger.refresh();
        window.scrollTo(0, savedY);
        requestAnimationFrame(function () {
          ScrollTrigger.refresh();
          window.scrollTo(0, savedY);
        });
      };
      if (document.readyState === 'complete') {
        settle();
      } else {
        window.addEventListener('load', settle);
      }
    }
  }, {
    key: "destroy",
    value: function destroy() {
      this._unwireBreakpoint();
      window.removeEventListener('resize', this._onResize);
      this._killAnimations();
      this._unobserveContent();
      this._resetDom();
      this._markStatic();
      this.enabled = false;
      if (typeof ScrollTrigger !== 'undefined') {
        ScrollTrigger.refresh();
      }
    }

    /* ── DOM cache ─────────────────────────────────────────── */
  }, {
    key: "cacheElements",
    value: function cacheElements() {
      var itemEls = this.list.querySelectorAll(':scope > .ha-v-tabs-item');
      this.items = [];
      this.titles = [];
      this.titleEls = [];
      this.panels = [];
      for (var i = 0; i < itemEls.length; i++) {
        var item = itemEls[i];
        var title = item.querySelector(':scope > .ha-v-tabs-title-wrap');
        var panel = item.querySelector(':scope > .ha-v-tabs-sticky-container');
        this.items.push(item);
        this.titles.push(title);
        if (title) {
          this.titleEls.push(title);
        }
        this.panels.push(panel);
      }
      this.count = this.items.length;
    }

    /* ── Geometry ──────────────────────────────────────────── */

    /**
     * Measure every dynamic value. Invoked on init, resize and on every
     * ScrollTrigger refresh so the maths always reflects the live DOM.
     *
     *   totalTitleHeight — stacked height of every title plus the row gaps.
     *                      The maximum distance the track could travel.
     *   visibleHeight    — the stage height available to the title track.
     *   maxTranslate     — totalTitleHeight − visibleHeight, floored at 0.
     *                      The track may never move past this or the last
     *                      title would scroll beyond the stage (overscroll).
     *
     * titlePhase is derived from the item count so the title scroll always
     * finishes just before the final content swap (see _update).
     */
  }, {
    key: "calculate",
    value: function calculate() {
      // Re-publish title widths (feeds the zoom-tracked after-number
      // shift) — fonts / typography may have changed since init.
      publishVisualTabsTitleWidths(this.list);
      var cs = window.getComputedStyle(this.list);
      var rowGap = parseFloat(cs.rowGap) || 0;
      this.heights = [];
      this.offsets = [];
      var cumulative = 0;
      for (var i = 0; i < this.count; i++) {
        var title = this.titles[i];
        // offsetHeight includes padding + border = real painted height.
        var h = title ? title.offsetHeight : 0;
        this.heights.push(h);
        this.offsets.push(cumulative);
        cumulative += h + (i < this.count - 1 ? rowGap : 0);
      }
      this.totalTitleHeight = cumulative;
      // The list itself is the stage (CSS forces viewport height desktop).
      // Subtract the stage's top/bottom padding (e.g. --ha-v-tabs-sticky-top)
      // because the title track lives in the content box while overflow is
      // clipped at the padding box. Without this, maxTranslate is too small
      // by the padding amount and the last title gets clipped at the bottom.
      var stagePadTop = parseFloat(cs.paddingTop) || 0;
      var stagePadBottom = parseFloat(cs.paddingBottom) || 0;
      this.visibleHeight = Math.max(0, this.list.clientHeight - stagePadTop - stagePadBottom);
      this.maxTranslate = Math.max(0, this.totalTitleHeight - this.visibleHeight);

      // Per-panel vertical overflow: how much of each panel's content
      // exceeds the visible panel area. That amount is scrubbed with the
      // page scroll (see _contentOffsetAt) so over-height content stays
      // reachable WITHOUT an internal scrollbar.
      this.contentHeights = [];
      this.contentOverflow = [];
      for (var j = 0; j < this.count; j++) {
        var ch = this._measurePanelContent(j);
        this.contentHeights.push(ch);
        this.contentOverflow.push(Math.max(0, ch - this.visibleHeight));
      }

      // Titles finish scrolling just before the last panel becomes active.
      if (this.count >= 2) {
        this.titlePhase = Math.max(0.5, Math.min(0.95, (this.count - 1.5) / (this.count - 1)));
      } else {
        this.titlePhase = 1;
      }
    }

    /* ── ScrollTrigger wiring ──────────────────────────────── */
  }, {
    key: "createScrollTrigger",
    value: function createScrollTrigger() {
      var self = this;
      this.st = ScrollTrigger.create({
        trigger: this.list,
        start: 'top top',
        // Function-based end → re-evaluated on refresh (responsive).
        // Allocates one viewport-height of scroll per item, scaled by
        // the user's Scroll Speed setting (higher speed → shorter pin).
        end: function end() {
          var distance = self.count * window.innerHeight * self.scrollDistance;
          return '+=' + Math.max(window.innerHeight * 0.25, distance);
        },
        pin: true,
        pinSpacing: true,
        scrub: true,
        invalidateOnRefresh: true,
        onRefresh: function onRefresh() {
          self.calculate();
          self._setStageHeight();
          // ScrollTrigger just (re)calculated the pin-spacer based on
          // the tall stage. Shrink it by (tallest − last) so the
          // excess height from the biggest item doesn't linger as a
          // gap after the pin ends.
          self._reducePinSpacer();
        },
        onUpdate: function onUpdate(trigger) {
          self._update(trigger.progress);
        },
        onLeave: function onLeave() {
          // Pin ended → shrink the stage to the last item.
          self._setExitStageHeight();
        },
        onEnterBack: function onEnterBack() {
          // Scrolling back → restore the tall stage.
          self._setStageHeight();
        },
        onLeaveBack: function onLeaveBack() {
          self._update(0);
        }
      });

      // On reload the scrub starts mid-progress; onUpdate only fires on
      // movement, so titles/panels would stay parked on item 0 until the
      // user scrolls. Sync the visual state to the restored progress.
      this._update(this.st.progress || 0);
    }

    /* ── Per-frame update (scrubbed) ───────────────────────── */

    /**
     * Map scroll progress (0→1) to an EVEN active index + track translation.
     *
     * Every item owns an equal slice of the pin, so each content swap takes
     * exactly the same amount of scroll — regardless of title heights or
     * item count. The previous design advanced items by title height during
     * a "title phase" then squeezed the rest into a short "tail phase",
     * which made some swaps feel fast and others slow. Scroll Speed still
     * scales the whole pin, and per-item pacing now stays uniform.
     *
     * Active index advances evenly: round(p · (count-1)).
     * The title track glides via _trackOffsetAt() so the active title stays
     * near the focal line, with a centered glide window between swaps.
     */
  }, {
    key: "_update",
    value: function _update(progress) {
      var p = Math.min(Math.max(progress, 0), 1);

      // Even advancement → uniform swap speed for every item.
      var active = Math.round(p * (this.count - 1));
      active = Math.min(Math.max(active, 0), this.count - 1);

      // Smooth, evenly-paced track translation (clamped; never overscroll).
      var delta = this.maxTranslate > 0 ? this._trackOffsetAt(p) : 0;
      this.updateTitlePosition(delta);

      // Scrub the active panel's content with the page scroll so
      // over-height content is revealed without an internal scrollbar.
      var contentOffset = this._contentOffsetAt(p, active);
      this.updatePanelContent(active, contentOffset);
      if (active !== this.active) {
        this.updateActiveItem(active);
      }
    }

    /**
     * How far the active panel's content has been scrubbed for scroll
     * progress p ∈ [0,1]. Each panel scrolls through its OWN content
     * during the half-slice it is active: it starts at the top when the
     * item activates and reaches the bottom exactly when the next item
     * swaps in — so the content moves with the page scroll, never with
     * an internal scrollbar. First and last items use their remaining
     * pin distance (pin start → first swap, last swap → pin end).
     */
  }, {
    key: "_contentOffsetAt",
    value: function _contentOffsetAt(p, active) {
      if (!this.contentOverflow || !this.contentOverflow[active]) {
        return 0;
      }
      if (this.count < 2) {
        return 0;
      }
      var pos = p * (this.count - 1);
      var half = 0.5;
      var start, end;
      if (active === 0) {
        start = 0;
        end = half;
      } else if (active === this.count - 1) {
        start = this.count - 1 - half;
        end = this.count - 1;
      } else {
        start = active - half;
        end = active + half;
      }
      var frac = (pos - start) / (end - start);
      frac = Math.min(Math.max(frac, 0), 1);
      return frac * this.contentOverflow[active];
    }

    /** Translate the active panel's content so it tracks the page scroll. */
  }, {
    key: "updatePanelContent",
    value: function updatePanelContent(index, offset) {
      var applied = this._panelOffsets ? this._panelOffsets[index] : 0;
      if (applied === offset) {
        return;
      }
      var panel = this.panels[index];
      if (!panel) {
        return;
      }
      var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
      if (!content) {
        return;
      }
      if (!this._panelOffsets) {
        this._panelOffsets = {};
      }
      if (offset > 0) {
        gsap.set(content, {
          y: -offset
        });
      } else {
        gsap.set(content, {
          clearProps: 'y'
        });
      }
      this._panelOffsets[index] = offset;
    }

    /**
     * Smooth, evenly-paced track offset for scroll progress p ∈ [0,1].
     *
     * Each item owns an equal progress slice [i, i+1]/(count-1). The track
     * HOLDS at offsets[i] for the first part of the slice, GLIDES through a
     * centered window to offsets[i+1], then holds again. Combined with the
     * even active index this guarantees:
     *   • every swap happens after the same scroll distance, and
     *   • the active title stays pinned near the focal line between swaps.
     * Result is clamped to [0, maxTranslate] so the last title never
     * overscrolls.
     */
  }, {
    key: "_trackOffsetAt",
    value: function _trackOffsetAt(p) {
      if (this.count < 2) {
        return 0;
      }
      var pos = p * (this.count - 1); // 0 → count-1
      var i = Math.floor(pos);
      if (i >= this.count - 1) {
        return Math.min(this.offsets[this.count - 1], this.maxTranslate);
      }
      var frac = pos - i;
      var from = this.offsets[i] || 0;
      var to = this.offsets[i + 1] || 0;

      // Centered glide window [0.2, 0.8]; hold outside it.
      var half = 0.3,
        center = 0.5;
      var t;
      if (frac <= center - half) {
        t = 0;
      } else if (frac >= center + half) {
        t = 1;
      } else {
        var k = (frac - (center - half)) / (2 * half); // 0..1 across the window
        t = k * k * (3 - 2 * k); // smoothstep
      }
      var val = from + (to - from) * t;
      return Math.min(Math.max(val, 0), this.maxTranslate);
    }

    /** GPU-friendly transform-only movement (never touches layout). */
  }, {
    key: "updateTitlePosition",
    value: function updateTitlePosition(delta) {
      if (!this.titleEls.length) {
        return;
      }
      gsap.set(this.titleEls, {
        y: -delta
      });
    }
  }, {
    key: "updateActiveItem",
    value: function updateActiveItem(next) {
      var prev = this.active;
      this.active = next;

      // e-active drives title colour + opacity via CSS.
      if (prev >= 0 && this.items[prev]) {
        this.items[prev].classList.remove('e-active');
      }
      if (this.items[next]) {
        this.items[next].classList.add('e-active');
      }
      this.animateContent(prev, next);
    }

    /**
     * Smooth cross-fade/scale swap of the content panels, honouring the
     * configured content animation. Any in-flight swap is killed first so
     * fast scrolling never stacks overlapping tweens.
     */
  }, {
    key: "animateContent",
    value: function animateContent(prev, next) {
      if (this.swapTl) {
        this.swapTl.kill();
        this.swapTl = null;
      }
      var prevPanel = this.panels[prev];
      var nextPanel = this.panels[next];
      if (!nextPanel) {
        return;
      }

      // "None" = instant panel swap, no animated transition.
      if (this.contentAnimation === 'none') {
        for (var k = 0; k < this.count; k++) {
          if (this.panels[k]) {
            gsap.set(this.panels[k], {
              opacity: k === next ? 1 : 0,
              display: k === next ? 'block' : 'none'
            });
          }
        }
        return;
      }
      var hasPrev = prev >= 0 && prev !== next && prevPanel;
      var tl = gsap.timeline({
        defaults: {
          ease: this.easing,
          overwrite: 'auto'
        }
      });

      // Park every uninvolved panel: hidden + display none so it never
      // interferes with layout or measurement.
      var hidden = this.getAnimFrom ? this.getAnimFrom() : {
        opacity: 0
      };
      for (var k = 0; k < this.count; k++) {
        if (k !== next && k !== prev && this.panels[k]) {
          gsap.set(this.panels[k], Object.assign({
            opacity: 0,
            display: 'none'
          }, hidden));
        }
      }

      // Show the incoming panel BEFORE its fade-in starts.
      tl.set(nextPanel, {
        display: 'block'
      }, 0);
      if (hasPrev) {
        var outVars = this.getAnimOut ? this.getAnimOut() : {
          opacity: 0,
          duration: this.duration
        };
        tl.to(prevPanel, outVars, 0);
        // Hide the outgoing panel AFTER its fade-out completes.
        tl.set(prevPanel, {
          display: 'none'
        });
      }
      var fromVars = this.getAnimFrom ? this.getAnimFrom() : {
        opacity: 0
      };
      var toVars = this.getAnimIn ? this.getAnimIn() : {
        opacity: 1,
        duration: this.duration
      };
      tl.fromTo(nextPanel, Object.assign({
        opacity: 0
      }, fromVars), Object.assign({
        opacity: 1,
        duration: this.duration
      }, toVars), 0);
      this.swapTl = tl;
    }

    /* ── Responsive enable / disable ───────────────────────── */
  }, {
    key: "_wireBreakpoint",
    value: function _wireBreakpoint() {
      this.mq = window.matchMedia('(min-width: ' + this.breakpoint + 'px)');
      this._onBreakpoint(this.mq.matches);
      if (typeof this.mq.addEventListener === 'function') {
        this.mq.addEventListener('change', this._onMqChange);
      } else if (typeof this.mq.addListener === 'function') {
        this.mq.addListener(this._onMqChange);
      }
    }
  }, {
    key: "_unwireBreakpoint",
    value: function _unwireBreakpoint() {
      if (!this.mq) {
        return;
      }
      if (typeof this.mq.removeEventListener === 'function') {
        this.mq.removeEventListener('change', this._onMqChange);
      } else if (typeof this.mq.removeListener === 'function') {
        this.mq.removeListener(this._onMqChange);
      }
      this.mq = null;
    }
  }, {
    key: "_onBreakpoint",
    value: function _onBreakpoint(matches) {
      if (matches) {
        this.enable();
      } else {
        this.disable();
      }
    }
  }, {
    key: "_onMqChange",
    value: function _onMqChange(e) {
      this._onBreakpoint(e.matches);
    }
  }, {
    key: "enable",
    value: function enable() {
      if (this.enabled) {
        return;
      }
      this.enabled = true;
      this.list.removeAttribute('data-vtabs-static');
      this.list.setAttribute('data-vtabs-pinned', '1');
      this.calculate();
      this._setStageHeight();
      this._initState();
      this.createScrollTrigger();
      window.addEventListener('resize', this._onResize);
      this._observeContent();
      // Let layout settle, then refresh so pin positions are correct.
      var self = this;
      requestAnimationFrame(function () {
        if (typeof ScrollTrigger !== 'undefined') {
          ScrollTrigger.refresh();
          self._update(self.st ? self.st.progress : 0);
        }
      });
    }
  }, {
    key: "disable",
    value: function disable() {
      var wasEnabled = this.enabled;
      this.enabled = false;
      window.removeEventListener('resize', this._onResize);
      this._killAnimations();
      this._unobserveContent();
      this.list.removeAttribute('data-vtabs-pinned');
      this._markStatic();
      this._resetDom();
      if (wasEnabled && typeof ScrollTrigger !== 'undefined') {
        ScrollTrigger.refresh();
      }
    }

    /**
     * Watch the panel content (e-con + its widget containers) so lazily
     * loaded media can grow the measured content height mid-pin. Only
     * geometry is recomputed — the stage stays viewport-capped and the
     * pinned distance is scroll-driven, so no ScrollTrigger refresh is
     * needed (that would risk a refresh loop).
     */
  }, {
    key: "_observeContent",
    value: function _observeContent() {
      if (typeof ResizeObserver === 'undefined') {
        return;
      }
      var self = this;
      this.contentRO = new ResizeObserver(function () {
        if (!self.enabled || !self.count) {
          return;
        }
        self.calculate();
      });
      for (var i = 0; i < this.count; i++) {
        var panel = this.panels[i];
        if (!panel) {
          continue;
        }
        var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
        if (!content) {
          continue;
        }
        this.contentRO.observe(content);
        var inner = content.querySelectorAll('.elementor-widget-container');
        for (var k = 0; k < inner.length; k++) {
          this.contentRO.observe(inner[k]);
        }
      }
    }
  }, {
    key: "_unobserveContent",
    value: function _unobserveContent() {
      if (this.contentRO) {
        this.contentRO.disconnect();
        this.contentRO = null;
      }
    }

    /* ── Initial visual state ──────────────────────────────── */

    /**
     * Park every panel: first visible (active), the rest hidden. Clears any
     * inline transforms left by a previous run / setupItem so the measured
     * geometry stays valid and CSS owns the title opacity.
     */
  }, {
    key: "_initState",
    value: function _initState() {
      for (var i = 0; i < this.count; i++) {
        var item = this.items[i];
        var title = this.titles[i];
        var panel = this.panels[i];
        var isActive = i === 0;
        if (item) {
          item.classList.toggle('e-active', isActive);
        }
        if (title) {
          gsap.set(title, {
            clearProps: 'opacity',
            y: 0
          });
        }
        if (panel) {
          gsap.set(panel, {
            clearProps: 'scale,opacity,clipPath,filter,x,y,rotation,rotationY'
          });
          var contentEl = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
          if (contentEl) {
            gsap.set(contentEl, {
              clearProps: 'y'
            });
          }
          if (isActive) {
            gsap.set(panel, this.getAnimIn ? this.getAnimIn() : {
              opacity: 1,
              scale: 1
            });
            gsap.set(panel, {
              display: 'block'
            });
          } else {
            gsap.set(panel, this.getAnimFrom ? this.getAnimFrom() : {
              opacity: 0,
              scale: 0.95
            });
            gsap.set(panel, {
              display: 'none'
            });
          }
        }
      }
      this._panelOffsets = {};
      this.active = 0;
    }

    /* ── DOM reset / fallback ──────────────────────────────── */
  }, {
    key: "_resetDom",
    value: function _resetDom() {
      for (var i = 0; i < this.count; i++) {
        var item = this.items[i];
        var title = this.titles[i];
        var panel = this.panels[i];
        if (item) {
          item.classList.toggle('e-active', i === 0);
        }
        if (title) {
          gsap.set(title, {
            clearProps: 'opacity,y'
          });
        }
        if (panel) {
          gsap.set(panel, {
            clearProps: 'scale,opacity,clipPath,filter,x,y,rotation,rotationY,display'
          });
          var contentEl = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
          if (contentEl) {
            gsap.set(contentEl, {
              clearProps: 'y'
            });
          }
        }
      }
      this.list.style.removeProperty('--ha-v-tabs-stage-height');
      this._panelOffsets = {};
      this.active = 0;
    }

    /**
     * No-GSAP / static fallback: reveal every panel using raw inline styles
     * (no GSAP dependency) so the widget degrades gracefully.
     */
  }, {
    key: "_showStatic",
    value: function _showStatic() {
      for (var i = 0; i < this.count; i++) {
        var item = this.items[i];
        var title = this.titles[i];
        var panel = this.panels[i];
        if (item) {
          item.classList.toggle('e-active', i === 0);
        }
        if (title) {
          title.style.opacity = '';
          title.style.transform = '';
        }
        if (panel) {
          panel.style.opacity = '1';
          panel.style.transform = '';
          panel.style.clipPath = '';
          panel.style.filter = '';
          panel.style.display = '';
          var contentEl = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
          if (contentEl) {
            contentEl.style.transform = '';
          }
        }
      }
      this.active = 0;
    }
  }, {
    key: "_markStatic",
    value: function _markStatic() {
      this.list.setAttribute('data-vtabs-static', '1');
      this.list.removeAttribute('data-vtabs-pinned');
    }
  }, {
    key: "_killAnimations",
    value: function _killAnimations() {
      if (this.swapTl) {
        try {
          this.swapTl.kill();
        } catch (e) {}
        this.swapTl = null;
      }
      if (this.st) {
        try {
          this.st.kill();
        } catch (e) {}
        this.st = null;
      }
    }
  }, {
    key: "_setStageHeight",
    value: function _setStageHeight() {
      // During the pin: as tall as the viewport (capped) so nothing
      // goes unreachable below the fold. Panels whose content is
      // taller are scrubbed up with the page scroll (no scrollbar).
      // Single items are never pinned, so they keep their natural
      // height and a tall panel scrolls normally with the page.
      var maxContent = 0;
      for (var i = 0; i < this.count; i++) {
        var ch = this._measurePanelContent(i);
        if (ch > maxContent) {
          maxContent = ch;
        }
      }
      this._writeStageHeight(maxContent, this.count >= 2);
    }
  }, {
    key: "_setExitStageHeight",
    value: function _setExitStageHeight() {
      // After the pin ends: only as tall as the LAST item so the next
      // section follows immediately — no empty gap.
      this._writeStageHeight(this._measurePanelContent(this.count - 1));
      // Reset the scrubbed content offset: the collapsed stage now
      // matches the panel's natural height, so a leftover translate
      // would clip the top of the last panel.
      this.updatePanelContent(this.count - 1, 0);
    }

    /**
     * Compute the stage height for a given panel content height.
     *
     * When capToViewport is set the stage never outgrows the viewport:
     * used while the stage is pinned (it is fixed on screen, so content
     * below the fold would be unreachable). Over-height panel content is
     * scrubbed up with the page scroll instead — no scrollbar needed.
     */
  }, {
    key: "_stageHeight",
    value: function _stageHeight(contentPx, capToViewport) {
      var titles = this.totalTitleHeight || 0;
      var stickyTop = parseFloat(getComputedStyle(this.list).paddingTop) || 0;
      var h = Math.max(contentPx, titles) + stickyTop;
      if (h < stickyTop + 50) {
        h = window.innerHeight;
      }
      if (capToViewport) {
        h = Math.min(h, window.innerHeight);
      }
      return h;
    }
  }, {
    key: "_writeStageHeight",
    value: function _writeStageHeight(contentPx, capToViewport) {
      var next = Math.ceil(this._stageHeight(contentPx, capToViewport)) + 'px';
      // Only write when the value actually changes — onRefresh calls
      // this too, and rewriting the same value would make
      // ScrollTrigger detect a size change → refresh → loop.
      if (this.list.style.getPropertyValue('--ha-v-tabs-stage-height') !== next) {
        this.list.style.setProperty('--ha-v-tabs-stage-height', next);
      }
    }

    /**
     * Shrink the ScrollTrigger pin-spacer by (tallest panel − last panel).
     *
     * ScrollTrigger sizes the pin-spacer for the tall stage at refresh
     * time and never shrinks it. The excess from the biggest item
     * shows up as a gap after the pin ends. Reducing the pin-spacer by
     * that excess closes the gap.
     */
  }, {
    key: "_reducePinSpacer",
    value: function _reducePinSpacer() {
      var spacer = this.list.closest('.pin-spacer');
      if (!spacer) {
        spacer = this.list.parentElement;
        if (!spacer || spacer === document.body) {
          return;
        }
      }
      var tallest = 0;
      for (var i = 0; i < this.count; i++) {
        var ch = this._measurePanelContent(i);
        if (ch > tallest) {
          tallest = ch;
        }
      }
      var last = this._measurePanelContent(this.count - 1);
      // Reduce by the ACTUAL staged heights. The pinned stage is capped
      // to the viewport, so a very tall panel must never over-shrink
      // the spacer (which would destroy the scroll distance).
      var excess = Math.max(0, this._stageHeight(tallest, true) - this._stageHeight(last, false));
      if (excess <= 0) {
        return;
      }
      var cur = spacer.offsetHeight;
      // Remove EXACTLY the excess. The old "+120" fudge always left
      // ~120px of empty space below the section after the pin ended —
      // and when the excess was smaller than the fudge it even GREW
      // the spacer, adding a gap that was never there.
      var next = Math.max(this.list.offsetHeight, cur - excess);
      if (next >= cur) {
        return;
      }
      spacer.style.height = Math.ceil(next) + 'px';
    }

    /**
     * Natural content height of a panel's inner .e-con. Releases the
     * inset stretch (height / bottom) temporarily so the element
     * reports its content height, then restores.
     */
  }, {
    key: "_measurePanelContent",
    value: function _measurePanelContent(index) {
      var panel = this.panels[index];
      if (!panel) {
        return 0;
      }
      var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
      if (!content) {
        return 0;
      }
      var panelSt = panel.style;
      var st = content.style;
      var savedDisplay = panelSt.display;
      var savedBottom = st.bottom;
      var savedHeight = st.height;
      // Temporarily reveal the panel so its content height can be
      // measured even when it is display:none.
      if (savedDisplay === 'none') {
        panelSt.display = 'block';
      }
      st.bottom = 'auto';
      st.height = 'auto';
      var h = content.offsetHeight;
      st.bottom = savedBottom;
      st.height = savedHeight;
      panelSt.display = savedDisplay;
      return h;
    }
  }, {
    key: "_onResize",
    value: function _onResize() {
      if (!this.enabled) {
        return;
      }
      this.calculate();
      this._setStageHeight();
      ScrollTrigger.refresh();
    }
  }]);
}();
/**
 * Content height sync for Visual Tabs.
 *
 * Content panels are absolutely positioned, so they never contribute to
 * the list height. Without a height the list collapses to the title
 * track's height and panels overlap the following sections.
 *
 * The FRONTEND measures EVERY panel and locks the list height to the
 * TALLEST item (max height) for SCROLL stages — the height is stable
 * from first paint and the "Vertical Items Position" alignment never
 * jumps while switching items. For HOVER/CLICK stages the height
 * FOLLOWS the active item's .ha-v-tabs-sticky-container content
 * instead, so the element grows/shrinks with the visible panel (the
 * MutationObserver below re-measures on every e-active toggle).
 * (The EDITOR keeps its own mirror in happy-visual-tabs.js that
 * follows the currently visible panel instead.)
 *
 * The measured height is exposed as --ha-v-tabs-content-height and used
 * as a min-height on every non-pinned layout. A ResizeObserver
 * re-measures when any panel's content grows (media loads / lazy
 * content). Runs regardless of GSAP so the static / no-GSAP fallback
 * (plain absolute panels) is fixed too.
 */
var syncVisualTabsContentHeight = function syncVisualTabsContentHeight($list) {
  var list = $list[0];
  if (!list) {
    return;
  }

  // element_ready re-runs on re-render — drop the previous instance so
  // observers never accumulate.
  var prev = $list.data('ha-v-tabs-heightsync');
  if (prev) {
    if (prev.ro) {
      prev.ro.disconnect();
    }
    if (prev.mo) {
      prev.mo.disconnect();
    }
    if (prev.onResize) {
      jQuery(window).off('resize.haVTabsHeight', prev.onResize);
    }
    $list.removeData('ha-v-tabs-heightsync');
  }
  var panelOf = function panelOf(item) {
    var wrap = item.querySelector(':scope > .ha-v-tabs-sticky-container');
    var host = wrap || item;
    return {
      wrap: wrap || null,
      content: host.querySelector(':scope > .e-con, :scope > .elementor-element')
    };
  };

  // Hover/Click: the element height follows the ACTIVE panel's sticky
  // container content; Scroll keeps the tallest-panel lock (stable stage).
  var selectType = String($list.attr('data-select-type') || 'scroll');
  var followActivePanel = selectType === 'hover' || selectType === 'click';

  // Mirrors the scroll controller's _measurePanelContent: release the
  // top/bottom stretch (and an explicit height) so the panel reports
  // its natural content height instead of the circular "stretched to
  // the list" height, and temporarily reveal the wrapper because GSAP
  // parks inactive panels at display:none — without that, hidden panels
  // measure 0. The hover/click sticky rule no longer clamps
  // max-height, so tall content reports its full natural height and the
  // element grows beyond the viewport with it.
  var measurePanel = function measurePanel(parts) {
    var el = parts && parts.content;
    if (!el) {
      return 0;
    }
    var wrapSt = parts.wrap ? parts.wrap.style : null;
    var savedWrapDisplay = wrapSt ? wrapSt.display : '';
    var st = el.style;
    var saved = {
      bottom: st.bottom,
      height: st.height
    };
    if (wrapSt && savedWrapDisplay === 'none') {
      wrapSt.display = 'block';
    }
    st.bottom = 'auto';
    st.height = 'auto';
    var h = el.offsetHeight;
    st.bottom = saved.bottom;
    st.height = saved.height;
    if (wrapSt) {
      wrapSt.display = savedWrapDisplay;
    }
    return h;
  };
  var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(schedule) : null;
  var roObserved = ro && typeof WeakSet !== 'undefined' ? new WeakSet() : null;
  var pending = false;
  var track = function track(el) {
    if (ro && roObserved && el && !roObserved.has(el)) {
      roObserved.add(el);
      ro.observe(el);
    }
  };
  var measure = function measure() {
    pending = false;

    // Title widths feed the zoom-tracked prefix number (after-position)
    // — keep them fresh on every resize / class mutation even while
    // the panel-height work below is skipped for pinned stages.
    publishVisualTabsTitleWidths(list);

    // Pinned scroll stages keep their fixed viewport height — the CSS
    // ignores the variable there, so don't do pointless layout work.
    if (list.hasAttribute('data-vtabs-pinned')) {
      return;
    }

    // Fixed height from the tallest item (hidden panels included —
    // measurePanel reveals them for the measurement). Hover/Click only
    // measures the ACTIVE item (first item as fallback) so the element
    // height changes with the visible .ha-v-tabs-sticky-container.
    var h = 0;
    var $panels;
    if (followActivePanel) {
      var $active = $list.children('.ha-v-tabs-item.e-active').first();
      $panels = $active.length ? $active : $list.children('.ha-v-tabs-item').first();
    } else {
      $panels = $list.children('.ha-v-tabs-item');
    }
    $panels.each(function () {
      var ph = measurePanel(panelOf(this));
      if (ph > h) {
        h = ph;
      }
    });

    // Track the title text boxes too: web-font swaps / typography
    // changes resize them without touching the panels, and the zoom
    // "after" number shift reads their measured width.
    if (list.classList.contains('ha-v-tabs-zoom')) {
      $list.children('.ha-v-tabs-item').each(function () {
        var titleWrap = this.querySelector(':scope > .ha-v-tabs-title-wrap');
        track(titleWrap ? titleWrap.querySelector(':scope > .ha-v-tabs-service-title') : null);
      });
    }
    var next = Math.ceil(h) + 'px';
    if (list.style.getPropertyValue('--ha-v-tabs-content-height') !== next) {
      list.style.setProperty('--ha-v-tabs-content-height', next);
    }

    // Track the panels and their inner wrappers: media loads / lazy
    // content grow them without any DOM change. Observe each element
    // ONCE — ResizeObserver delivers an initial callback for every
    // observe() call, so a disconnect + re-observe cycle inside the
    // measure would re-schedule the measure every frame forever.
    if (ro) {
      track(list);
      $list.children('.ha-v-tabs-item').each(function () {
        var el = panelOf(this).content;
        if (!el) {
          return;
        }
        track(el);
        jQuery(el).find('.elementor-widget-container').each(function () {
          track(this);
        });
      });
    }
  };
  function schedule() {
    if (pending) {
      return;
    }
    pending = true;
    requestAnimationFrame(measure);
  }
  track(list);
  var mo = null;
  if (typeof MutationObserver !== 'undefined') {
    // DOM changes inside the list (e.g. Elementor re-renders) can
    // alter panel content — keep the locked height in sync.
    mo = new MutationObserver(schedule);
    mo.observe(list, {
      subtree: true,
      childList: true,
      attributeFilter: ['class']
    });
  }
  var onResize = function onResize() {
    schedule();
  };
  jQuery(window).on('resize.haVTabsHeight', onResize);
  schedule();
  $list.data('ha-v-tabs-heightsync', {
    ro: ro,
    mo: mo,
    onResize: onResize
  });
};

// Nested Service List Widget
var happynestedservicelist = function happynestedservicelist($scope) {
  var $serviceList = $scope.find('.ha-v-tabs-list');
  if (!$serviceList.length) {
    return;
  }
  var widgetId = $scope.data('id');

  // Atomic repeater linking (editor preview).
  var reindexItems = function reindexItems() {
    $serviceList.first().children('.ha-v-tabs-item').each(function (i) {
      var count = i + 1;
      jQuery(this).attr('data-service-index', count);
    });
  };
  var linkContainer = function linkContainer(e) {
    var detail = e && (e.detail || e.originalEvent && e.originalEvent.detail) || {};
    var container = detail.container;
    if (!container || !container.model) {
      return;
    }
    if (String(container.model.get('id')) !== String(widgetId)) {
      return;
    }
    var index = detail.index;
    var targetContainer = detail.targetContainer;
    var type = detail.action && detail.action.type;
    var $items = $serviceList.first().children('.ha-v-tabs-item');
    var itemNode = null;
    var contentNode = targetContainer && targetContainer.view ? targetContainer.view.$el[0] : null;
    if ('duplicate' === type) {
      itemNode = $items[index + 1];
    } else if ('move' === type) {
      itemNode = $items[index];
    }
    if (itemNode && contentNode) {
      itemNode.appendChild(contentNode);
    }
    reindexItems();
  };
  if (typeof elementorFrontend !== 'undefined' && elementorFrontend.elements && elementorFrontend.elements.$window) {
    elementorFrontend.elements.$window.on('elementor/nested-container/atomic-repeater', linkContainer);
  }

  // Frontend scroll behaviour is skipped inside the editor — the
  // editor runs its own height-sync mirror (happy-visual-tabs.js)
  // so the wrapper height follows the visible content there.
  if ($scope.hasClass('elementor-element-edit-mode')) {
    return;
  }
  $serviceList.each(function () {
    var $currentList = jQuery(this);
    var selectType = $currentList.data('select-type') || 'scroll';

    // Lock the list height to the tallest content panel so
    // absolute panels never overlap the following sections and
    // the Vertical Items Position alignment never jumps. Must
    // run before the GSAP guard: the no-GSAP fallback renders the
    // plain absolute panels that need this the most.
    syncVisualTabsContentHeight($currentList);
    if (typeof gsap === 'undefined') {
      return;
    }
    var inactiveOpacity = parseFloat($currentList.data('inactive-opacity') || '1');
    if (isNaN(inactiveOpacity)) {
      inactiveOpacity = 1;
    }
    var triggerStart = 'top 50%';
    var triggerEnd = 'bottom 50%';
    var doParallax = $currentList.data('parallax') === '1';
    var contentAnimation = $currentList.data('content-animation') || 'fade';
    var animationDuration = parseInt($currentList.data('content-animation-duration') || 400);
    var animationEasing = $currentList.data('content-animation-easing') || 'ease';
    var scrollSpeed = parseFloat($currentList.data('scroll-speed'));
    if (isNaN(scrollSpeed) || scrollSpeed <= 0) {
      scrollSpeed = 3;
    }
    var $items = $currentList.children('.ha-v-tabs-item');

    // Revert any previous GSAP context (animations + ScrollTriggers)
    // created for this list on a prior element_ready run, so we never
    // accumulate duplicate ScrollTriggers when Elementor re-renders.
    var prevCtx = $currentList.data('ha-v-tabs-ctx');
    if (prevCtx) {
      prevCtx.revert();
    }
    var ctx = gsap.context(function () {
      if (contentAnimation === 'none') {
        $items.each(function (i) {
          var $stickyWrap = jQuery(this).children('.ha-v-tabs-sticky-container');
          var $title = jQuery(this).children('.ha-v-tabs-title-wrap');
          gsap.set(jQuery(this), {
            opacity: 1,
            clearProps: 'all'
          });
          if ($stickyWrap.length) {
            gsap.set($stickyWrap, {
              opacity: 1,
              y: 0,
              x: 0,
              scale: 1,
              rotation: 0,
              rotationY: 0,
              filter: 'none',
              clipPath: 'none',
              clearProps: 'all'
            });
          }
          if ($title.length) {
            gsap.set($title, {
              opacity: i === 0 ? 1 : inactiveOpacity
            });
          }
        });
      }
      var easingMap = {
        'ease': 'power1.out',
        'ease-in': 'power2.in',
        'ease-out': 'power2.out',
        'ease-in-out': 'power2.inOut',
        'bounce': 'back.out(1.7)',
        'elastic': 'elastic.out(1, 0.75)'
      };
      var gsapEase = easingMap[animationEasing] || 'power1.out';
      function getAnimationProps(direction) {
        var dur = animationDuration / 1000;
        var props = {
          duration: dur,
          ease: gsapEase,
          overwrite: 'auto'
        };
        var selfScaled = {
          'zoom': true,
          'zoom-blur': true
        };
        var skipDefaultScale = contentAnimation === 'fade' || !!selfScaled[contentAnimation];
        if (direction === 'in') {
          if (!skipDefaultScale) {
            props.scale = 1;
          }
          switch (contentAnimation) {
            case 'fade':
              return Object.assign({}, props, {
                opacity: 1
              });
            case 'vertical-reveal':
              return Object.assign({}, props, {
                opacity: 1,
                clipPath: 'inset(0% 0 0 0)'
              });
            case 'reveal-bottom':
              return Object.assign({}, props, {
                opacity: 1,
                clipPath: 'inset(0 0 0% 0)'
              });
            case 'reveal-top':
              return Object.assign({}, props, {
                opacity: 1,
                clipPath: 'inset(0% 0 0 0)'
              });
            case 'square-reveal':
              return Object.assign({}, props, {
                opacity: 1,
                clipPath: 'inset(0% 0% 0% 0%)'
              });
            case 'mask-reveal':
              return Object.assign({}, props, {
                opacity: 1,
                clipPath: 'circle(100% at 50% 50%)'
              });
            case 'zoom':
              return Object.assign({}, props, {
                opacity: 1,
                scale: 1
              });
            case 'blur':
              return Object.assign({}, props, {
                opacity: 1,
                filter: 'blur(0px)'
              });
            case 'flip-3d':
              return Object.assign({}, props, {
                opacity: 1,
                rotationY: 0
              });
            case 'zoom-blur':
              return Object.assign({}, props, {
                opacity: 1,
                scale: 1,
                filter: 'blur(0px)'
              });
            case 'slide-down-reveal':
              return Object.assign({}, props, {
                opacity: 1,
                y: 0,
                clipPath: 'inset(0% 0 0 0)'
              });
            case 'slide-up-reveal':
              return Object.assign({}, props, {
                opacity: 1,
                y: 0,
                clipPath: 'inset(0 0 0% 0)'
              });
            default:
              return Object.assign({}, props, {
                opacity: 1
              });
          }
        } else {
          if (!skipDefaultScale) {
            props.scale = 0.95;
          }
          switch (contentAnimation) {
            case 'fade':
              return Object.assign({}, props, {
                opacity: 0
              });
            case 'vertical-reveal':
              return Object.assign({}, props, {
                opacity: 0,
                clipPath: 'inset(100% 0 0 0)'
              });
            case 'reveal-bottom':
              return Object.assign({}, props, {
                opacity: 0,
                clipPath: 'inset(100% 0 0 0)'
              });
            case 'reveal-top':
              return Object.assign({}, props, {
                opacity: 0,
                clipPath: 'inset(0 0 100% 0)'
              });
            case 'square-reveal':
              return Object.assign({}, props, {
                opacity: 0,
                clipPath: 'inset(100% 100% 100% 100%)'
              });
            case 'mask-reveal':
              return Object.assign({}, props, {
                opacity: 0,
                clipPath: 'circle(0% at 50% 50%)'
              });
            case 'zoom':
              return Object.assign({}, props, {
                opacity: 0,
                scale: 0.85
              });
            case 'blur':
              return Object.assign({}, props, {
                opacity: 0,
                filter: 'blur(20px)'
              });
            case 'flip-3d':
              return Object.assign({}, props, {
                opacity: 0,
                rotationY: -90
              });
            case 'zoom-blur':
              return Object.assign({}, props, {
                opacity: 0,
                scale: 0.5,
                filter: 'blur(12px)'
              });
            case 'slide-down-reveal':
              return Object.assign({}, props, {
                opacity: 0,
                y: 80,
                clipPath: 'inset(0 0 0% 0)'
              });
            case 'slide-up-reveal':
              return Object.assign({}, props, {
                opacity: 0,
                y: -80,
                clipPath: 'inset(0% 0 0 0)'
              });
            default:
              return Object.assign({}, props, {
                opacity: 0
              });
          }
        }
      }
      function setInitialOutState($stickyWrap) {
        if (!$stickyWrap || !$stickyWrap.length) return;
        var initProps = {
          opacity: 0
        };
        var selfScaledInit = {
          'zoom': true,
          'zoom-blur': true
        };
        if (contentAnimation !== 'fade' && !selfScaledInit[contentAnimation]) {
          initProps.scale = 0.95;
        }
        switch (contentAnimation) {
          case 'vertical-reveal':
            initProps.clipPath = 'inset(100% 0 0 0)';
            break;
          case 'reveal-bottom':
            initProps.clipPath = 'inset(0 0 100% 0)';
            break;
          case 'reveal-top':
            initProps.clipPath = 'inset(100% 0 0 0)';
            break;
          case 'square-reveal':
            initProps.clipPath = 'inset(100% 100% 100% 100%)';
            break;
          case 'mask-reveal':
            initProps.clipPath = 'circle(0% at 50% 50%)';
            break;
          case 'zoom':
            initProps.scale = 0.85;
            break;
          case 'blur':
            initProps.filter = 'blur(20px)';
            break;
          case 'flip-3d':
            initProps.rotationY = -90;
            break;
          case 'zoom-blur':
            initProps.scale = 0.5;
            initProps.filter = 'blur(12px)';
            break;
          case 'slide-down-reveal':
            initProps.y = 80;
            initProps.clipPath = 'inset(0 0 0% 0)';
            break;
          case 'slide-up-reveal':
            initProps.y = -80;
            initProps.clipPath = 'inset(0% 0 0 0)';
            break;
        }
        gsap.set($stickyWrap, initProps);
        gsap.set($stickyWrap, {
          display: 'none'
        });
      }
      function setupItem($item, i) {
        var $title = $item.children('.ha-v-tabs-title-wrap');
        var $container = $item.children('.e-con, .elementor-element').first();
        var $stickyWrap = $item.children('.ha-v-tabs-sticky-container');
        var $image = $item.find('.ha-v-tabs-parallax-img');
        if ($container.length && !$stickyWrap.length) {
          $container.wrap('<div class="ha-v-tabs-sticky-container"></div>');
          $stickyWrap = $item.children('.ha-v-tabs-sticky-container');
        }
        if ($title.length) {
          gsap.set($title, {
            opacity: i === 0 ? 1 : inactiveOpacity
          });
        }
        if ($stickyWrap.length) {
          if (i === 0) {
            var firstItemProps = {
              opacity: 1,
              y: 0,
              x: 0,
              scale: 1,
              rotation: 0,
              rotationY: 0,
              filter: 'none'
            };
            switch (contentAnimation) {
              case 'vertical-reveal':
                firstItemProps.clipPath = 'inset(0% 0 0 0)';
                break;
              case 'reveal-bottom':
                firstItemProps.clipPath = 'inset(0 0 0% 0)';
                break;
              case 'reveal-top':
                firstItemProps.clipPath = 'inset(0% 0 0 0)';
                break;
              case 'square-reveal':
                firstItemProps.clipPath = 'inset(0% 0% 0% 0%)';
                break;
              case 'mask-reveal':
                firstItemProps.clipPath = 'circle(100% at 50% 50%)';
                break;
              case 'slide-down-reveal':
                firstItemProps.clipPath = 'inset(0% 0 0 0)';
                firstItemProps.y = 0;
                break;
              case 'slide-up-reveal':
                firstItemProps.clipPath = 'inset(0 0 0% 0)';
                firstItemProps.y = 0;
                break;
              default:
                firstItemProps.clipPath = 'none';
            }
            gsap.set($stickyWrap, firstItemProps);
            gsap.set($stickyWrap, {
              display: 'block'
            });
          } else {
            setInitialOutState($stickyWrap);
          }
        }
        if ($image.length && doParallax && typeof ScrollTrigger !== 'undefined') {
          gsap.registerPlugin(ScrollTrigger);
          gsap.fromTo($image, {
            yPercent: -10
          }, {
            yPercent: 10,
            ease: 'none',
            scrollTrigger: {
              trigger: $item[0],
              start: 'top bottom',
              end: 'bottom top',
              scrub: 0.8
            }
          });
        }
        return {
          $title: $title,
          $stickyWrap: $stickyWrap,
          $item: $item
        };
      }
      var currentActiveIndex = 0;

      // Deferred display:none guard. Hides the panel ONLY if its item
      // is still inactive when the callback fires. Rapid hover/click
      // sequences (A→B→A within the animation window) re-activate an
      // item while an older swap timeline / fade-out is still in
      // flight; the late hide would stomp the freshly shown panel
      // (e-active + display:none — invisible content).
      function hideStickyWhenInactive($targetItem, $targetSticky) {
        return function () {
          if ($targetItem && $targetItem.length && $targetItem.hasClass('e-active')) {
            return;
          }
          gsap.set($targetSticky, {
            display: 'none'
          });
        };
      }
      function activateItem($item, $title, $stickyWrap, index) {
        var outRef = itemRefs[currentActiveIndex];
        var $outSticky = outRef && outRef.$stickyWrap;
        var useTimeline = contentAnimation !== 'none' && (contentAnimation === 'fade' || contentAnimation === 'vertical-reveal' || contentAnimation === 'reveal-bottom' || contentAnimation === 'reveal-top' || contentAnimation === 'square-reveal' || contentAnimation === 'mask-reveal' || contentAnimation === 'zoom' || contentAnimation === 'blur' || contentAnimation === 'flip-3d' || contentAnimation === 'zoom-blur' || contentAnimation === 'slide-down-reveal' || contentAnimation === 'slide-up-reveal');
        if ($title && $title.length) {
          if (contentAnimation === 'none') {
            gsap.set($title, {
              opacity: 1
            });
          } else {
            gsap.to($title, {
              opacity: 1,
              duration: 0.3,
              overwrite: 'auto'
            });
          }
        }
        if ($stickyWrap && $stickyWrap.length && useTimeline && $outSticky && $outSticky.length && currentActiveIndex !== index) {
          var tl = gsap.timeline({
            defaults: {
              overwrite: 'auto'
            }
          });
          var inProps = getAnimationProps('in');
          var outProps = getAnimationProps('out');

          // Show incoming BEFORE fade-in (synchronously — a deferred
          // set would leave a gap where the panel is still hidden);
          // hide outgoing AFTER fade-out, but only if it has not been
          // re-activated in the meantime.
          gsap.set($stickyWrap, {
            display: 'block'
          });
          tl.to($outSticky, outProps, 0);
          tl.call(hideStickyWhenInactive(outRef.$item, $outSticky));
          tl.fromTo($stickyWrap, getInitialProps(contentAnimation), inProps, 0);
        } else if ($stickyWrap && $stickyWrap.length) {
          if (contentAnimation === 'none') {
            gsap.set($stickyWrap, {
              opacity: 1,
              y: 0,
              x: 0,
              scale: 1,
              rotation: 0,
              rotationY: 0,
              filter: 'none',
              clipPath: 'none',
              clearProps: 'all'
            });
            gsap.set($stickyWrap, {
              display: 'block'
            });
          } else {
            gsap.set($stickyWrap, {
              display: 'block'
            });
            gsap.to($stickyWrap, getAnimationProps('in'));
          }
        }
        $item.addClass('e-active');
        currentActiveIndex = index;
      }
      function deactivateItem($item, $title, $stickyWrap) {
        if ($title && $title.length) {
          if (contentAnimation === 'none') {
            gsap.set($title, {
              opacity: inactiveOpacity
            });
          } else {
            gsap.to($title, {
              opacity: inactiveOpacity,
              duration: 0.3,
              overwrite: 'auto'
            });
          }
        }
        if ($stickyWrap && $stickyWrap.length) {
          if (contentAnimation === 'none') {
            gsap.set($stickyWrap, {
              opacity: 0,
              display: 'none'
            });
          } else {
            var hideOutProps = getAnimationProps('out');
            hideOutProps.onComplete = hideStickyWhenInactive($item, $stickyWrap);
            gsap.to($stickyWrap, hideOutProps);
          }
        }
        $item.removeClass('e-active');
      }
      function getInitialProps(animation) {
        var init = {
          opacity: 0
        };
        var selfScaledInit = {
          'zoom': true,
          'zoom-blur': true
        };
        if (animation !== 'fade' && !selfScaledInit[animation]) {
          init.scale = 0.95;
        }
        switch (animation) {
          case 'vertical-reveal':
            init.clipPath = 'inset(100% 0 0 0)';
            break;
          case 'reveal-bottom':
            init.clipPath = 'inset(0 0 100% 0)';
            break;
          case 'reveal-top':
            init.clipPath = 'inset(100% 0 0 0)';
            break;
          case 'square-reveal':
            init.clipPath = 'inset(100% 100% 100% 100%)';
            break;
          case 'mask-reveal':
            init.clipPath = 'circle(0% at 50% 50%)';
            break;
          case 'zoom':
            init.scale = 0.85;
            break;
          case 'blur':
            init.filter = 'blur(20px)';
            break;
          case 'flip-3d':
            init.rotationY = -90;
            break;
          case 'zoom-blur':
            init.scale = 0.5;
            init.filter = 'blur(12px)';
            break;
          case 'slide-down-reveal':
            init.y = 80;
            init.clipPath = 'inset(0 0 0% 0)';
            break;
          case 'slide-up-reveal':
            init.y = -80;
            init.clipPath = 'inset(0% 0 0 0)';
            break;
          default:
            init = {
              opacity: 0
            };
        }
        return init;
      }
      var itemRefs = [];
      $items.each(function (i) {
        itemRefs.push(setupItem(jQuery(this), i));
      });
      if (selectType === 'scroll') {
        // Pinned storytelling: a single scrubbed ScrollTrigger drives the
        // whole experience (title translation + content swap). The class
        // owns all geometry, pinning and animation and cleans itself up on
        // re-render via destroy().
        var prevScrollInstance = $currentList.data('ha-v-tabs-scroll');
        if (prevScrollInstance) {
          try {
            prevScrollInstance.destroy();
          } catch (e) {}
          $currentList.removeData('ha-v-tabs-scroll');
        }
        var scrollInstance = new HappyNestedServiceScroll($currentList[0], {
          inactiveOpacity: inactiveOpacity,
          contentAnimation: contentAnimation,
          duration: animationDuration,
          easing: gsapEase,
          scrollSpeed: scrollSpeed,
          // Reuse the shared animation-property builders so the scroll
          // path never duplicates the hover/click switch.
          getAnimIn: function getAnimIn() {
            return getAnimationProps('in');
          },
          getAnimOut: function getAnimOut() {
            return getAnimationProps('out');
          },
          getAnimFrom: function getAnimFrom() {
            return getInitialProps(contentAnimation);
          }
        });
        scrollInstance.init();
        $currentList.data('ha-v-tabs-scroll', scrollInstance);
        ScrollTrigger.refresh();
      } else if (selectType === 'hover') {
        var resetHoverToFirst = function resetHoverToFirst() {
          $items.each(function (j) {
            var other = itemRefs[j];
            if (j !== 0) {
              deactivateItem(other.$item, other.$title, other.$stickyWrap);
            }
          });
          var first = itemRefs[0];
          if (first && first.$item) {
            activateItem(first.$item, first.$title, first.$stickyWrap, 0);
          }
        };
        $items.each(function (i) {
          var ref = itemRefs[i];
          var $item = ref.$item;
          var $title = ref.$title;
          var $stickyWrap = ref.$stickyWrap;
          $item.on('mouseenter', function () {
            $items.each(function (j) {
              var other = itemRefs[j];
              if (j !== i) {
                deactivateItem(other.$item, other.$title, other.$stickyWrap);
              }
            });
            activateItem($item, $title, $stickyWrap, i);
          });

          // NO per-item reset: the row gap belongs to the list, not
          // to any item, so a mouseleave here fires while moving
          // BETWEEN items — resetting to the first item made the
          // sequence flash 1,1,2,1,3,1,4,1,5. The current item just
          // stays active until the pointer enters the next one.
        });

        // Reset to item 1 only when the pointer truly leaves the
        // whole list (gaps included) — the 1,2,3,4,5 workflow.
        // off() first: element_ready re-runs on re-render and must
        // never stack reset handlers on a surviving list node.
        $currentList.off('mouseleave.haVTabsHoverReset').on('mouseleave.haVTabsHoverReset', resetHoverToFirst);
      } else if (selectType === 'click') {
        $items.each(function (i) {
          var ref = itemRefs[i];
          var $item = ref.$item;
          var $title = ref.$title;
          var $stickyWrap = ref.$stickyWrap;
          $item.on('click', function () {
            var wasActive = $item.hasClass('e-active');
            $items.each(function (j) {
              var other = itemRefs[j];
              if (j !== i) {
                deactivateItem(other.$item, other.$title, other.$stickyWrap);
              }
            });
            if (!wasActive) {
              activateItem($item, $title, $stickyWrap, i);
            }
          });
        });
      }
    }, $currentList[0]);
    $currentList.data('ha-v-tabs-ctx', ctx);
  });
};
elementorFrontend.hooks.addAction('frontend/element_ready/ha-visual-tabs.default', happynestedservicelist);