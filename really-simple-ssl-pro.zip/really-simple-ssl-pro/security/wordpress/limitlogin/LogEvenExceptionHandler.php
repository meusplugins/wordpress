<?php

namespace RSSSLPRO\Wordpress\LimitLogin;

class LogEvenExceptionHandler extends \Exception {

}