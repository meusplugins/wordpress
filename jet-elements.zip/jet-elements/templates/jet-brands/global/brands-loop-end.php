<?php
/**
 * Brands loop end template
 */
?>
</div>
