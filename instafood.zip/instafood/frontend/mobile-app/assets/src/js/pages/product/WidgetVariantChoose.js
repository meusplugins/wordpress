import ProductUtils from '../../utils/ProductUtils';
import LanguageUtils from '../../utils/LanguageUtils';

class WidgetVariantChoose {
    _product;
    _parent_ui;
    _widget_ui;
    _onSelect;
    _product_variants = [];
    _product_variants_ui = [];
    _selectedVariantId = null;

    constructor(product, onSelect) {
        this._product = product;
        this._onSelect = onSelect;
        this._product_variants = _.get(product, 'meta.product_variations', []);
    }

    render(parent_ui) {
        this._parent_ui = parent_ui;
        const _this = this;

        const variantsArray = this._product_variants.map(variant => {
            const price_display = _.get(variant, 'price_display', '');
            const price_display_decoded = LanguageUtils.getInstance().decodeHtml(price_display);
            const variantTemplate = `
            <div class="widget_radio_entry" data-id="${variant.ID}">
                <div class="radio_symbol primary_color_border">
                    <div class="radio_fill primary_color_background show"></div>
                </div>
                <div class="variant_info">${ProductUtils.getVariationName(variant)}</div>
                <div class="variant_price">${price_display_decoded}</div>
            </div>
            `;
            return variantTemplate;
        })

        const requiredTemplate = _.template(LanguageUtils.getInstance().decodeHtml(LanguageUtils.getInstance().getLabel('product_required_option')));
        const compiledTemplate = requiredTemplate({ optionsNo: 1 })

        const product_variation = LanguageUtils.getInstance().getLabel('product_variation');

        const template = `
        <div class="product_widget">
            <div class="widget_info mb_15">
                <div class="widget_title">${ product_variation }</div>
                <div class="options_required_info">${ compiledTemplate }</div>
            </div>
            <div class="widget_entries">${variantsArray.join('')}</div>
        </div>
        `;
        this._widget_ui = jQuery(template);
        this._widget_ui.appendTo(this._parent_ui);
        this._widget_ui.find('.widget_radio_entry').each(function(index) {
            const widgetEntry = jQuery(this);
            widgetEntry.click(function(event) {
                event.preventDefault();
                const variantId = jQuery(this).attr('data-id');
                if (_this._selectedVariantId === variantId) {
                    return;
                }
                _this.selectItem(variantId);
            })
            _this._product_variants_ui.push(widgetEntry);
        })
    }

    selectItem(variantId, silent = false) {
        this._selectedVariantId = variantId;
        for (let i = 0; i < this._product_variants_ui.length; i++) {
            const entry = this._product_variants_ui[i];
            if (entry.attr('data-id') === variantId) {
                entry.addClass('selected');
            } else {
                entry.removeClass('selected');
            }
        }
        if (silent) {
            return;
        }
        this._onSelect(variantId);
    }


}
export default WidgetVariantChoose;