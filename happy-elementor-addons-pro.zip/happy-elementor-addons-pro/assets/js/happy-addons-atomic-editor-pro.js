/**
 * Happy Addons Pro — Elementor V4 (Atomic) editor control for the Global
 * Animation "Custom Properties" repeater.
 *
 * ha-anim-prop is one repeater item: a Property select and the value
 * field(s) of that property, like the Classic repeater. Loaded after the
 * Happy Addons Atomic editor script and registered on the same controls
 * registry (see Global_Animation in extensions/atomic/global-animation.php).
 */
(function (w) {
	'use strict';

	var v2 = w.elementorV2 || {};
	var panel = v2.editorEditingPanel;
	var controls = v2.editorControls;
	var props = v2.editorProps;
	var ui = v2.ui;
	var z = v2.schema && v2.schema.z;
	var React = w.React;

	if (!panel || !panel.controlsRegistry || !controls || !props || !ui || !z || !React) {
		return;
	}

	var registry = panel.controlsRegistry;

	if (registry.get('ha-anim-prop')) {
		return;
	}

	var h = React.createElement;
	var optional = function () {
		return z.any().nullable().optional();
	};

	var itemUtil = props.createPropUtils('ha-anim-prop', z.strictObject({
		property: optional(),
		value: optional(),
		value2: optional(),
		value3: optional(),
		value4: optional(),
		choice: optional(),
		choice2: optional(),
		color: optional(),
		'switch': optional()
	}));

	// Properties whose single "Value" is a text field, with the description they show.
	var TEXT = {
		opacity: 'opacity',
		x: 'position', y: 'position', width: 'position', height: 'position',
		maxWidth: 'size', maxHeight: 'size', minWidth: 'size', minHeight: 'size',
		scale: 'scale', scaleX: 'scale', scaleY: 'scale',
		rotate: 'rotate', rotateX: 'rotate', rotateY: 'rotate',
		transformPerspective: 'transformPerspective',
		padding: 'padding',
		borderRadius: 'borderRadius',
		blur: 'blur',
		delay: 'delay',
		duration: 'duration',
		repeat: 'repeat',
		repeatDelay: 'repeatDelay'
	};

	function unwrap(value) {
		while (value && 'object' === typeof value && '$$type' in value) {
			value = value.value;
		}

		return value;
	}

	// The Property select as a searchable list: type to filter the properties.
	var PropertyPicker = controls.createControl(function (pickerProps) {
		var bound = controls.useBoundProp(props.stringPropTypeUtil);
		var options = pickerProps.options || [];
		var current = options.filter(function (option) {
			return option.value === (bound.value || 'none');
		})[0] || null;

		return h(ui.Autocomplete, {
			fullWidth: true,
			size: 'tiny',
			sx: {width: '100%', minWidth: 0},
			// The list is at least 220px wide, so property names do not wrap.
			slotProps: {popper: {sx: {minWidth: '220px', width: 'auto !important'}}},
			disableClearable: true,
			disabled: bound.disabled,
			options: options,
			value: current,
			onChange: function (event, option) {
				bound.setValue(option ? option.value : 'none');
			},
			getOptionLabel: function (option) {
				return option.label;
			},
			isOptionEqualToValue: function (option, value) {
				return option.value === value.value;
			},
			renderInput: function (params) {
				return h(ui.TextField, Object.assign({}, params, {fullWidth: true}));
			}
		});
	});

	var AnimationProperty = controls.createControl(function (itemProps) {
		var bound = controls.useBoundProp(itemUtil);
		var context = Object.assign({}, bound);
		var value = bound.value || {};
		var labels = itemProps.labels || {};
		var descriptions = itemProps.descriptions || {};
		var property = unwrap(value.property) || 'none';

		delete context.value;
		delete context.setValue;

		function caption(text) {
			return text ? h(ui.Typography, {
				variant: 'caption',
				color: 'text.tertiary',
				sx: {display: 'block', fontSize: '11px', fontStyle: 'italic', lineHeight: 1.4}
			}, text) : null;
		}

		function field(label, bind, Control, controlProps, description) {
			return h(ui.Stack, {key: bind + label, gap: 0.5},
				h(ui.Box, {
					sx: {display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', alignItems: 'center', gap: 1}
				},
					h(panel.ControlLabel, null, label),
					h(controls.PropKeyProvider, {bind: bind}, h(Control, controlProps || {}))
				),
				caption(description)
			);
		}

		function text(label, bind, description) {
			return field(label, bind, controls.TextControl, {}, description);
		}

		function select(label, bind, options) {
			return field(label, bind, controls.SelectControl, {options: options});
		}

		function color(label) {
			return field(label, 'color', controls.ColorControl, {});
		}

		var fields = [];

		if (TEXT[property]) {
			fields.push(text(labels.value, 'value', descriptions[TEXT[property]]));
		} else {
			switch (property) {
				case 'skew':
					fields.push(text(labels.skewX, 'value', descriptions.skew));
					fields.push(text(labels.skewY, 'value2', descriptions.skew));
					break;

				case 'flip':
					fields.push(select(labels.flipType, 'choice', itemProps.flipTypes));
					fields.push(select(labels.direction, 'choice2', itemProps.flipDirections));

					if ('3d' === unwrap(value.choice)) {
						fields.push(text(labels.rotation, 'value', descriptions.flip));
					}
					break;

				case 'transformOrigin':
					fields.push(select(labels.value, 'choice', itemProps.origins));

					if ('custom' === unwrap(value.choice)) {
						fields.push(text(labels.custom, 'value', descriptions.transformOrigin));
					}
					break;

				case 'color':
				case 'background':
					fields.push(color(labels.value));
					break;

				case 'border':
					fields.push(text(labels.width, 'value'));
					fields.push(select(labels.style, 'choice', itemProps.borderStyles));
					fields.push(color(labels.color));
					break;

				case 'boxShadow':
					fields.push(text(labels.horizontal, 'value'));
					fields.push(text(labels.vertical, 'value2'));
					fields.push(text(labels.blur, 'value3'));
					fields.push(text(labels.spread, 'value4'));
					fields.push(color(labels.color));
					fields.push(select(labels.position, 'choice', itemProps.shadowPositions));
					break;

				case 'force3D':
				case 'yoyo':
					fields.push(field(labels.value, 'switch', controls.SwitchControl, {}, descriptions[property]));
					break;
			}
		}

		return h(controls.PropProvider, Object.assign({}, context, {value: bound.value, setValue: bound.setValue}),
			h(ui.Stack, {gap: 2},
				h(ui.Stack, {key: 'property', gap: 0.5, sx: {width: '100%', minWidth: 0, alignSelf: 'stretch'}},
					h(panel.ControlLabel, null, labels.property),
					h(controls.PropKeyProvider, {bind: 'property'}, h(PropertyPicker, {options: itemProps.properties}))
				),
				fields
			)
		);
	});

	registry.register('ha-anim-prop', AnimationProperty, 'full', itemUtil);
}(window));

/**
 * Happy Addons Pro — Elementor V4 (Atomic) editor control for the Display
 * Condition "Conditions" repeater.
 *
 * ha-display-condition is one repeater item: the condition (key), the
 * operator and the value field of that condition (select, multi select,
 * date, date range or time), like the Classic repeater. Loaded after the
 * Happy Addons Atomic editor script and registered on the same controls
 * registry (see Display_Condition in extensions/atomic/display-condition.php).
 */
(function (w) {
	'use strict';

	var v2 = w.elementorV2 || {};
	var panel = v2.editorEditingPanel;
	var controls = v2.editorControls;
	var props = v2.editorProps;
	var ui = v2.ui;
	var z = v2.schema && v2.schema.z;
	var React = w.React;

	if (!panel || !panel.controlsRegistry || !controls || !props || !ui || !z || !React) {
		return;
	}

	var registry = panel.controlsRegistry;

	if (registry.get('ha-display-condition')) {
		return;
	}

	var h = React.createElement;
	var optional = function () {
		return z.any().nullable().optional();
	};

	var itemUtil = props.createPropUtils('ha-display-condition', z.strictObject({
		key: optional(),
		operator: optional(),
		value: optional()
	}));

	function unwrap(value) {
		while (value && 'object' === typeof value && '$$type' in value) {
			value = value.value;
		}

		return value;
	}

	function str(value) {
		return props.stringPropTypeUtil.create(String(value));
	}

	// The Classic date format (d-m-Y) <-> the value of a native date input (Y-m-d).
	function toInput(value) {
		var m = /^(\d{2})-(\d{2})-(\d{4})$/.exec(value || '');

		return m ? m[3] + '-' + m[2] + '-' + m[1] : '';
	}

	function fromInput(value) {
		var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');

		return m ? m[3] + '-' + m[2] + '-' + m[1] : '';
	}

	var DisplayCondition = controls.createControl(function (itemProps) {
		var bound = controls.useBoundProp(itemUtil);
		var context = Object.assign({}, bound);
		var value = bound.value || {};
		var list = itemProps.conditions || [];
		var operators = itemProps.operators || [];

		delete context.value;
		delete context.setValue;

		var key = unwrap(value.key) || list[0].key;
		var current = list.filter(function (condition) {
			return condition.key === key;
		})[0] || list[0];
		var operator = unwrap(value.operator) || 'is';
		var stored = unwrap(value.value);
		var text = null !== stored && undefined !== stored && '' !== stored ? String(stored) : current.default;

		function change(part) {
			bound.setValue(Object.assign({}, value, part));
		}

		// A new item gets the first condition with its default value, as in Classic.
		React.useEffect(function () {
			if (!unwrap(value.key)) {
				change({key: str(current.key), operator: str(operator), value: str(text)});
			}
		}, []);

		function caption(content) {
			return content ? h(ui.Typography, {
				variant: 'caption',
				color: 'text.tertiary',
				sx: {display: 'block', fontSize: '11px', fontStyle: 'italic', lineHeight: 1.4}
			}, content) : null;
		}

		function picker(options, selected, onChange, multiple) {
			return h(ui.Autocomplete, {
				fullWidth: true,
				size: 'tiny',
				multiple: !!multiple,
				disableCloseOnSelect: !!multiple,
				sx: {width: '100%', minWidth: 0},
				slotProps: {popper: {sx: {minWidth: '220px', width: 'auto !important'}}},
				disableClearable: !multiple,
				disabled: bound.disabled,
				options: options,
				value: selected,
				onChange: function (event, option) {
					onChange(option);
				},
				getOptionLabel: function (option) {
					return option.label;
				},
				isOptionEqualToValue: function (option, chosen) {
					return option.value === chosen.value;
				},
				renderInput: function (params) {
					return h(ui.TextField, Object.assign({}, params, {fullWidth: true}));
				}
			});
		}

		function find(options, optionValue) {
			return options.filter(function (option) {
				return option.value === optionValue;
			})[0] || null;
		}

		function input(type, inputValue, onChange) {
			return h(ui.TextField, {
				fullWidth: true,
				size: 'tiny',
				type: type,
				disabled: bound.disabled,
				value: inputValue,
				onChange: function (event) {
					onChange(event.target.value);
				}
			});
		}

		var field;

		switch (current.type) {
			case 'multi':
				field = picker(
					current.options,
					text.split(',').map(function (code) {
						return find(current.options, code.trim());
					}).filter(Boolean),
					function (options) {
						change({value: str((options || []).map(function (option) {
							return option.value;
						}).join(','))});
					},
					true
				);
				break;

			case 'date':
				field = input('date', toInput(text), function (date) {
					change({value: str(fromInput(date))});
				});
				break;

			case 'time':
				field = input('time', text, function (time) {
					change({value: str(time)});
				});
				break;

			case 'date_range':
				var range = text.split(' to ');

				field = h(ui.Stack, {gap: 1},
					input('date', toInput(range[0]), function (date) {
						change({value: str(fromInput(date) + ' to ' + (range[1] || fromInput(date)))});
					}),
					input('date', toInput(range[1]), function (date) {
						change({value: str((range[0] || fromInput(date)) + ' to ' + fromInput(date))});
					})
				);
				break;

			default:
				field = picker(current.options, find(current.options, text), function (option) {
					change({value: str(option ? option.value : '')});
				});
		}

		return h(controls.PropProvider, Object.assign({}, context, {value: bound.value, setValue: bound.setValue}),
			h(ui.Stack, {gap: 1.5, sx: {width: '100%', minWidth: '260px'}},
				h(ui.Box, {key: 'key', sx: {width: '100%', minWidth: 0}},
					picker(
						list.map(function (condition) {
							return {value: condition.key, label: condition.title};
						}),
						{value: current.key, label: current.title},
						function (option) {
							var condition = list.filter(function (item) {
								return item.key === option.value;
							})[0];

							change({key: str(condition.key), value: str(condition.default)});
						}
					)
				),
				h(ui.Box, {key: 'operator', sx: {width: '100%', minWidth: 0}},
					picker(operators, find(operators, operator), function (option) {
						change({operator: str(option.value)});
					})
				),
				h(ui.Stack, {key: 'value', gap: 0.5, sx: {width: '100%', minWidth: 0}},
					field,
					caption(current.description)
				)
			)
		);
	});

	registry.register('ha-display-condition', DisplayCondition, 'full', itemUtil);
}(window));

/**
 * Happy Addons Pro — Elementor V4 (Atomic) editor controls of the Global Badge.
 *
 *  - ha-range        From/To dual slider (the Classic range slider), bound to a
 *                    "from,to" text
 *  - ha-icon-picker  searchable Font Awesome icon list, bound to the icon class
 *
 * Loaded after the Happy Addons Atomic editor script and registered on the
 * same controls registry (see Global_Badge in extensions/atomic/global-badge.php).
 */
(function (w) {
	'use strict';

	var v2 = w.elementorV2 || {};
	var panel = v2.editorEditingPanel;
	var controls = v2.editorControls;
	var props = v2.editorProps;
	var ui = v2.ui;
	var React = w.React;

	if (!panel || !panel.controlsRegistry || !controls || !props || !ui || !React) {
		return;
	}

	var registry = panel.controlsRegistry;
	var h = React.createElement;

	function register(type, component, layout, propTypeUtil) {
		if (!registry.get(type)) {
			registry.register(type, component, layout, propTypeUtil);
		}
	}

	function parse(value, min, max) {
		var parts = String(value || '').split(',');
		var from = parseFloat(parts[0]);
		var to = parseFloat(parts[1]);

		return [isNaN(from) ? min : from, isNaN(to) ? max : to];
	}

	/* ---------------------------------------------------------------- *
	 * ha-range
	 * ---------------------------------------------------------------- */
	var Range = controls.createControl(function (rangeProps) {
		var bound = controls.useBoundProp(props.stringPropTypeUtil);
		var min = rangeProps.min;
		var max = rangeProps.max;
		var step = rangeProps.step || 1;
		var pair = parse(bound.value, min, max);

		function save(from, to) {
			var clamp = function (value) {
				return Math.min(Math.max(value, min), max);
			};

			bound.setValue(clamp(from) + ',' + clamp(to));
		}

		function number(label, index) {
			return h(ui.Stack, {key: label, gap: 0.5, sx: {flex: 1, minWidth: 0}},
				h(ui.Typography, {variant: 'caption', color: 'text.tertiary'}, label),
				h(ui.TextField, {
					size: 'tiny',
					type: 'number',
					disabled: bound.disabled,
					inputProps: {min: min, max: max, step: step},
					value: pair[index],
					onChange: function (event) {
						var value = parseFloat(event.target.value);

						if (isNaN(value)) {
							return;
						}

						save(0 === index ? value : pair[0], 1 === index ? value : pair[1]);
					}
				})
			);
		}

		return h(ui.Stack, {gap: 1},
			h(ui.Box, {sx: {px: 1}},
				h(ui.Slider, {
					size: 'small',
					min: min,
					max: max,
					step: step,
					disabled: bound.disabled,
					value: pair,
					onChange: function (event, value) {
						save(value[0], value[1]);
					}
				})
			),
			h(ui.Stack, {direction: 'row', gap: 1}, number('From', 0), number('To', 1))
		);
	});

	/* ---------------------------------------------------------------- *
	 * ha-icon-picker
	 * ---------------------------------------------------------------- */
	var IconPicker = controls.createControl(function (pickerProps) {
		var bound = controls.useBoundProp(props.stringPropTypeUtil);
		var options = pickerProps.icons || [];
		var current = options.filter(function (option) {
			return option.value === bound.value;
		})[0] || null;

		return h(ui.Autocomplete, {
			fullWidth: true,
			size: 'tiny',
			sx: {width: '100%', minWidth: 0},
			slotProps: {popper: {sx: {minWidth: '240px', width: 'auto !important'}}},
			disableClearable: true,
			disabled: bound.disabled,
			options: options,
			value: current || {value: bound.value || '', label: bound.value || ''},
			// Thousands of icons: show the best matches only.
			filterOptions: function (all, state) {
				var query = String(state.inputValue || '').toLowerCase();

				if (!query || current && query === current.label.toLowerCase()) {
					return all.slice(0, 60);
				}

				return all.filter(function (option) {
					return option.label.toLowerCase().indexOf(query) !== -1;
				}).slice(0, 60);
			},
			onChange: function (event, option) {
				if (option) {
					bound.setValue(option.value);
				}
			},
			getOptionLabel: function (option) {
				return option.label;
			},
			isOptionEqualToValue: function (option, chosen) {
				return option.value === chosen.value;
			},
			renderOption: function (optionProps, option) {
				return h('li', Object.assign({}, optionProps, {key: option.value}),
					h('i', {className: option.value, style: {width: '24px', marginRight: '8px', textAlign: 'center'}, 'aria-hidden': 'true'}),
					option.label
				);
			},
			renderInput: function (params) {
				return h(ui.TextField, Object.assign({}, params, {fullWidth: true, placeholder: 'Search icon'}));
			}
		});
	});

	/* ---------------------------------------------------------------- *
	 * ha-font-family: the native Typography font family list
	 * ---------------------------------------------------------------- */
	var FontFamily = controls.createControl(function () {
		var families = controls.useFontFamilies();

		if (!families.length) {
			return null;
		}

		return h(controls.FontFamilyControl, {fontFamilies: families, sectionWidth: 320, ariaLabel: 'Font family'});
	});

	if (props.fontFamilyPropTypeUtil) {
		register('ha-font-family', FontFamily, 'full', props.fontFamilyPropTypeUtil);
	}

	/* ---------------------------------------------------------------- *
	 * ha-dimensions: the native Margin / Padding control (linked sizes)
	 * ---------------------------------------------------------------- */
	var Dimensions = controls.createControl(function (dimensionProps) {
		return h(controls.LinkedDimensionsControl, {label: dimensionProps.label || 'Padding', isSiteRtl: false, min: 0});
	});

	register('ha-dimensions', Dimensions, 'custom');
	register('ha-range', Range, 'full', props.stringPropTypeUtil);
	register('ha-icon-picker', IconPicker, 'full', props.stringPropTypeUtil);
}(window));

/**
 * Happy Addons Pro — Elementor V4 (Atomic) editor controls of Multi Layer Parallax.
 *
 *  - ha-mlp-layer    one layer of the Layers repeater: image, size, alignment,
 *                    position and the effect settings that apply to the chosen
 *                    Effect Type, like the Classic repeater item
 *  - ha-mlp-devices  device checkboxes (the Classic multiple select), bound to a
 *                    comma separated text ("none" when no device is checked)
 *
 * Loaded after the Happy Addons Atomic editor script and registered on the
 * same controls registry (see Multi_Layer_Parallax in extensions/atomic/multi-layer-parallax.php).
 */
(function (w) {
	'use strict';

	var v2 = w.elementorV2 || {};
	var panel = v2.editorEditingPanel;
	var controls = v2.editorControls;
	var props = v2.editorProps;
	var ui = v2.ui;
	var z = v2.schema && v2.schema.z;
	var React = w.React;

	if (!panel || !panel.controlsRegistry || !controls || !props || !ui || !z || !React) {
		return;
	}

	var registry = panel.controlsRegistry;
	var h = React.createElement;

	function unwrap(value) {
		while (value && 'object' === typeof value && '$$type' in value) {
			value = value.value;
		}

		return value;
	}

	function csv(value) {
		return String(unwrap(value) || '').split(',').map(function (item) {
			return item.trim();
		}).filter(Boolean);
	}

	/* ---------------------------------------------------------------- *
	 * ha-mlp-devices
	 * ---------------------------------------------------------------- */
	var Devices = controls.createControl(function (deviceProps) {
		var bound = controls.useBoundProp(props.stringPropTypeUtil);
		var devices = deviceProps.devices || [];
		var selected = csv(bound.value);

		function toggle(device, checked) {
			var next = devices.map(function (item) {
				return item.value;
			}).filter(function (value) {
				return value === device ? checked : selected.indexOf(value) !== -1;
			});

			bound.setValue(next.length ? next.join(',') : 'none');
		}

		return h(ui.Stack, {gap: 0},
			devices.map(function (device) {
				return h(ui.FormControlLabel, {
					key: device.value,
					label: device.label,
					disabled: bound.disabled,
					control: h(ui.Checkbox, {
						size: 'small',
						checked: selected.indexOf(device.value) !== -1,
						onChange: function (event) {
							toggle(device.value, event.target.checked);
						}
					})
				});
			})
		);
	});

	/* ---------------------------------------------------------------- *
	 * Slider + number input and the From / To range (Viewport)
	 * ---------------------------------------------------------------- */
	var Slide = controls.createControl(function (sliderProps) {
		var bound = controls.useBoundProp(props.numberPropTypeUtil);
		var min = sliderProps.min;
		var max = sliderProps.max;
		var step = sliderProps.step || 1;
		var current = Number(bound.value);

		if (null === bound.value || undefined === bound.value || isNaN(current)) {
			current = sliderProps.fallback;
		}

		return h(ui.Stack, {direction: 'row', alignItems: 'center', gap: 2},
			h(ui.Box, {sx: {flex: 1, px: 1}},
				h(ui.Slider, {
					size: 'small',
					min: min,
					max: max,
					step: step,
					disabled: bound.disabled,
					value: Math.min(Math.max(current, min), max),
					onChange: function (event, value) {
						bound.setValue(+(Math.round(value / step) * step).toFixed(4));
					}
				})
			),
			h(ui.Box, {sx: {width: '76px', flexShrink: 0}},
				h(controls.NumberControl, {min: min, max: max, step: step, shouldForceInt: false})
			)
		);
	});

	function parseRange(value) {
		var parts = String(unwrap(value) || '0,100').split(',');
		var from = parseFloat(parts[0]);
		var to = parseFloat(parts[1]);

		return [isNaN(from) ? 0 : from, isNaN(to) ? 100 : to];
	}

	var Range = controls.createControl(function (rangeProps) {
		var bound = controls.useBoundProp(props.stringPropTypeUtil);
		var pair = parseRange(bound.value);
		var labels = rangeProps.labels || ['Bottom', 'Top'];

		function save(from, to) {
			var clamp = function (value) {
				return Math.min(Math.max(value, 0), 100);
			};

			bound.setValue(clamp(from) + ',' + clamp(to));
		}

		function number(label, index) {
			return h(ui.Stack, {key: label, gap: 0.5, sx: {flex: 1, minWidth: 0}},
				h(ui.Typography, {variant: 'caption', color: 'text.tertiary'}, label),
				h(ui.TextField, {
					size: 'tiny',
					type: 'number',
					disabled: bound.disabled,
					inputProps: {min: 0, max: 100, step: 1},
					value: pair[index],
					onChange: function (event) {
						var value = parseFloat(event.target.value);

						if (isNaN(value)) {
							return;
						}

						save(0 === index ? value : pair[0], 1 === index ? value : pair[1]);
					}
				})
			);
		}

		return h(ui.Stack, {gap: 1},
			h(ui.Box, {sx: {px: 1}},
				h(ui.Slider, {
					size: 'small',
					min: 0,
					max: 100,
					step: 1,
					disabled: bound.disabled,
					value: pair,
					onChange: function (event, value) {
						save(value[0], value[1]);
					}
				})
			),
			h(ui.Stack, {direction: 'row', gap: 1}, number(labels[0], 0), number(labels[1], 1))
		);
	});

	/* ---------------------------------------------------------------- *
	 * ha-mlp-layer
	 * ---------------------------------------------------------------- */
	var optional = function () {
		return z.any().nullable().optional();
	};

	var itemUtil = props.createPropUtils('ha-mlp-layer', z.strictObject({
		label: optional(),
		hide: optional(),
		image: optional(),
		width: optional(),
		z_index: optional(),
		hor: optional(),
		hor_pos: optional(),
		ver: optional(),
		ver_pos: optional(),
		effect: optional(),
		rate: optional(),
		scroll_ver: optional(),
		direction: optional(),
		speed: optional(),
		view: optional(),
		scroll_hor: optional(),
		direction_hor: optional(),
		speed_hor: optional(),
		view_hor: optional(),
		show_on: optional()
	}));

	// A new layer is named "Item #N" (the next number after the existing layers). The repeater
	// builds the new item from itemUtil.create(initialValues), so the name is added there.
	function layerNumber() {
		try {
			var editor = w.elementor;
			var selected = editor && editor.selection && editor.selection.getElements && editor.selection.getElements()[0];
			var raw = selected && selected.settings && selected.settings.get('ha_mlp_layers');
			var items = unwrap(raw);
			var highest = 0;

			if (!Array.isArray(items)) {
				return 1;
			}

			items.forEach(function (item) {
				var match = /#(\d+)\s*$/.exec(String(unwrap(unwrap(item) && unwrap(item).label) || ''));

				highest = Math.max(highest, match ? parseInt(match[1], 10) : 0);
			});

			return Math.max(items.length, highest) + 1;
		} catch (e) {
			return 1;
		}
	}

	try {
		var baseCreate = itemUtil.create;

		itemUtil.create = function (value) {
			if (value && 'object' === typeof value && 'show_on' in value && !value.label) {
				value = Object.assign({}, value, {label: {$$type: 'string', value: 'Item #' + layerNumber()}});
			}

			return baseCreate.apply(this, arguments.length > 1 ? [value].concat([].slice.call(arguments, 1)) : [value]);
		};
	} catch (e) {}

	var Layer = controls.createControl(function (layerProps) {
		var bound = controls.useBoundProp(itemUtil);
		var context = Object.assign({}, bound);
		var value = bound.value || {};
		var labels = layerProps.labels || {};
		var descriptions = layerProps.descriptions || {};
		var options = layerProps.options || {};

		delete context.value;
		delete context.setValue;

		function read(key, fallback) {
			var item = unwrap(value[key]);

			return null === item || undefined === item || '' === item ? fallback : item;
		}

		function caption(text) {
			return text ? h(ui.Typography, {
				variant: 'caption',
				color: 'text.tertiary',
				sx: {display: 'block', fontSize: '11px', fontStyle: 'italic', lineHeight: 1.4}
			}, text) : null;
		}

		// Label beside the control (switch, select, number).
		function inline(key, Control, controlProps, label) {
			return h(ui.Stack, {key: key, gap: 0.5},
				h(ui.Box, {
					sx: {display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', alignItems: 'center', gap: 1}
				},
					h(panel.ControlLabel, null, label || labels[key]),
					h(controls.PropKeyProvider, {bind: key}, h(Control, controlProps || {}))
				),
				caption(descriptions[key])
			);
		}

		// Label above a wide control (slider, range, checkboxes, image).
		function stacked(key, Control, controlProps, label) {
			return h(ui.Stack, {key: key, gap: 0.5},
				label || labels[key] ? h(panel.ControlLabel, null, label || labels[key]) : null,
				h(controls.PropKeyProvider, {bind: key}, h(Control, controlProps || {})),
				caption(descriptions[key])
			);
		}

		function select(key, list) {
			return inline(key, controls.SelectControl, {options: list});
		}

		function toggle(key) {
			return inline(key, controls.SwitchControl, {});
		}

		function slider(key, min, max, step, fallback, label) {
			return stacked(key, Slide, {min: min, max: max, step: step, fallback: fallback}, label);
		}

		var fields = [];
		var scroll = 'mouse_track' !== read('effect', 'scroll_parallax');

		fields.push(toggle('hide'));
		fields.push(stacked('image', controls.ImageControl, {sizes: layerProps.sizes}));
		fields.push(slider('width', 0, 100, 1, 100));
		fields.push(inline('z_index', controls.NumberControl, {step: 1, shouldForceInt: true}));
		fields.push(select('hor', options.hor));

		if ('custom' === read('hor', 'custom')) {
			fields.push(slider('hor_pos', 0, 100, 1, 0));
		}

		fields.push(select('ver', options.ver));

		if ('custom' === read('ver', 'custom')) {
			fields.push(slider('ver_pos', 0, 100, 1, 0));
		}

		fields.push(h(ui.Divider, {key: 'divider'}));
		fields.push(select('effect', options.effect));

		if (!scroll) {
			fields.push(inline('rate', controls.NumberControl, {min: -20, max: 20, step: 1, shouldForceInt: true}));
		} else {
			fields.push(toggle('scroll_ver'));

			if (read('scroll_ver', true)) {
				fields.push(select('direction', options.direction));
				fields.push(slider('speed', 0, 10, 0.1, 4, labels.speed));
				fields.push(stacked('view', Range, {labels: [labels.bottom, labels.top]}));
				fields.push(h(ui.Divider, {key: 'divider-hor'}));
			}

			fields.push(toggle('scroll_hor'));

			if (read('scroll_hor', false)) {
				fields.push(select('direction_hor', options.direction_hor));
				fields.push(slider('speed_hor', 0, 10, 0.1, 4, labels.speed));
				fields.push(stacked('view_hor', Range, {labels: [labels.bottom, labels.top]}, labels.view));
			}
		}

		fields.push(h(ui.Divider, {key: 'divider-show'}));
		fields.push(stacked('show_on', Devices, {devices: layerProps.devices}));

		return h(controls.PropProvider, Object.assign({}, context, {value: bound.value, setValue: bound.setValue}),
			// The item opens in a popover under the panel header: its own scroll keeps it inside the screen.
			h(ui.Box, {sx: {maxHeight: '55vh', overflowY: 'auto', overflowX: 'hidden', pr: 1}},
				h(ui.Stack, {gap: 2}, fields)
			)
		);
	});

	if (!registry.get('ha-mlp-layer')) {
		registry.register('ha-mlp-layer', Layer, 'full', itemUtil);
	}

	if (!registry.get('ha-mlp-devices')) {
		registry.register('ha-mlp-devices', Devices, 'full', props.stringPropTypeUtil);
	}
}(window));
