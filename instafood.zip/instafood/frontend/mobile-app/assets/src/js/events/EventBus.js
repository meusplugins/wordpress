let instance;
const instanceKey = 'eent_bus92339';


export class Events {
    static OPEN_PRODUCT_SCREEN_REQUEST = 'OPEN_PRODUCT_SCREEN_REQUEST';
    static PRODUCT_SCREEN_OPEN_START = 'PRODUCT_SCREEN_OPEN_START';
    static PRODUCT_SCREEN_CLOSE_START = 'PRODUCT_SCREEN_CLOSE_START';
    static PRODUCT_SCREEN_CLOSE = 'PRODUCT_SCREEN_CLOSE';
    static OPEN_CART_SCREEN_REQUEST = 'OPEN_CART_SCREEN_REQUEST';
    static CLOSE_CART_SCREEN_REQUEST = 'CLOSE_CART_SCREEN_REQUEST';
    static CLOSE_CART_SCREEN_AND_OPEN_EDIT_PRODUCT = 'CLOSE_CART_SCREEN_AND_OPEN_EDIT_PRODUCT';
    static OPEN_ORDER_SCREEN_REQUEST = 'OPEN_ORDER_SCREEN_REQUEST';
    static CLOSE_ORDER_SCREEN_REQUEST = 'CLOSE_ORDER_SCREEN_REQUEST';
    static OPEN_ORDER_COMPLETE_SCREEN_REQUEST = 'OPEN_ORDER_COMPLETE_SCREEN_REQUEST';
    static CLOSE_ORDER_COMPLETE_SCREEN_REQUEST = 'CLOSE_ORDER_COMPLETE_SCREEN_REQUEST';
    
    static OPEN_SHOP_SCREEN_REQUEST = 'OPEN_SHOP_SCREEN_REQUEST';
    static CLOSE_SHOP_SCREEN_REQUEST = 'CLOSE_SHOP_SCREEN_REQUEST';

    static CART_CHANGED = 'CART_CHANGED';
    static ORDER_CONFIG_CHANGED = 'ORDER_CONFIG_CHANGED';
    static ORDER_PAYMENT_METHOD_CHANGED = 'ORDER_PAYMENT_METHOD_CHANGED';
    static SHOP_IS_OPEN_EVENT = 'SHOP_IS_OPEN_EVENT';
    static USER_TERMS_CHANGED = 'USER_TERMS_CHANGED';

    static ON_TOAST_REQUEST = 'ON_TOAST_REQUEST';
}

export class Event {
    constructor(key, callback, target = null) {
        this.key = key;
        this.callback = callback;
    }
}

class EventBus {

    _events = [];

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
    }

    registerEvent(event, callback) {
        if (!event instanceof Event) {
            throw new Error('Only Event instances are accepted');
        }
        if (!Events[event.key]) {
            throw new Error('Event key has not been registered');
        }
        if (this._eventExists(event) !== -1) {
            console.log('Cannot register Event. Already registered!');
            return;
        }
        this._events.push(event);
    }

    triggerEvent(key, payload) {
        if (!Events[key]) {
            throw new Error('triggerEvent: Event key has not been registered');
        }
        for (const event of this._events) {
            if (event.key === key) {
                if (_.isFunction(event.callback)) {
                    event.callback(payload);
                }
            }
        }
    }

    removeEvent(event) {
        if (!event instanceof Event) {
            throw new Error('Only Event instances are accepted');
        }
        if (!Events[event.key]) {
            throw new Error('Event key has not been registered');
        }
        const index = this._eventExists(event);
        if (index !== -1) {
            console.log('FOUND EV TO REMOVE at', index);
            this._events.splice(index, 1); 
        }
    }

    _eventExists(event) {
        let index = -1;
        for (let i = 0; i < this._events.length; i++) {
            if (_.isEqual(event, this._events[i])) {
                index = i;
                break;
            }
        }
        return index;
    }

    static getInstance() {
        if (!instance) {
            instance = new EventBus(instanceKey);
        }
        return instance;
    }
}
export default EventBus;