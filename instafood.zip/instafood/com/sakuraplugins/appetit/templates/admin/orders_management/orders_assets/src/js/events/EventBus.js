let instance;
const instanceKey = 'eentvent_1_bus92339';

export class Events {
    static LIVE_ORDERS_COUNT = 'LIVE_ORDERS_COUNT';
    static ORDER_CHANGED_STATUS = 'ORDER_CHANGED_STATUS';
    static RELOAD_REGULAR_ORDERS = 'RELOAD_REGULAR_ORDERS';
    static REQUEST_OPEN_SINGLE_ORDER = 'REQUEST_OPEN_SINGLE_ORDER';
    static LIVE_WAITER_CALLS_COUNT = 'LIVE_WAITER_CALLS_COUNT';
}

export class Event {
    constructor(key, callback, target = null) {
        this.key = key;
        this.callback = callback;
    }
}

class EventBus {

    _events = [];

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
    }

    registerEvent(event, callback) {
        if (!event instanceof Event) {
            throw new Error('Only Event instances are accepted');
        }
        if (!Events[event.key]) {
            throw new Error('Event key has not been registered');
        }
        if (this._eventExists(event) !== -1) {
            console.log('Cannot register Event. Already registered!');
            return;
        }
        this._events.push(event);
    }

    triggerEvent(key, payload) {
        if (!Events[key]) {
            throw new Error('triggerEvent: Event key has not been registered');
        }
        for (const event of this._events) {
            if (event.key === key) {
                if (lodash.isFunction(event.callback)) {
                    event.callback(payload);
                }
            }
        }
    }

    removeEvent(event) {
        if (!event instanceof Event) {
            throw new Error('Only Event instances are accepted');
        }
        if (!Events[event.key]) {
            throw new Error('Event key has not been registered');
        }
        const index = this._eventExists(event);
        if (index !== -1) {
            console.log('FOUND EV TO REMOVE at', index);
            this._events.splice(index, 1); 
        }
    }

    _eventExists(event) {
        let index = -1;
        for (let i = 0; i < this._events.length; i++) {
            if (lodash.isEqual(event, this._events[i])) {
                index = i;
                break;
            }
        }
        return index;
    }

    static getInstance() {
        if (!instance) {
            instance = new EventBus(instanceKey);
        }
        return instance;
    }
}
export default EventBus;