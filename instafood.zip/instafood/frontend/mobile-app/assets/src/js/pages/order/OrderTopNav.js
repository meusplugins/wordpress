import EventBus, { Event, Events } from '../../events/EventBus';
import LanguageUtils from '../../utils/LanguageUtils';

class OrderTopNav {

    _parrentUI;
    _ui;
    _onCartChangeEvent = null;
    
    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_top_nav');
    }

    render() {
        const templateCartHeader = `
            <div class="cart_top_nav_header_content_ui">
                <div class="cart_top_nav_header_content">
                    <div class="cart_nav">
                        <a class="round_nav_fill reverse-color close_page" href="#"><span class="icon-clear"></span></a>
                        <div class="title">${ LanguageUtils.getInstance().getLabel('order_page_title') }</div>
                    </div>
                </div>
            </div>
        `;
        jQuery(templateCartHeader).appendTo(this._ui);


        jQuery(this._ui.find('.close_page')).click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.CLOSE_ORDER_SCREEN_REQUEST);
        })
    }
}
export default OrderTopNav;