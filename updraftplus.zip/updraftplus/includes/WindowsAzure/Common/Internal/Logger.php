<?php
// phpcs:disable WordPress.PHP.DevelopmentFunctions.error_log_print_r -- print_r is intentionally used to convert an array into a readable string or for controlled logging purposes.

/**
 * LICENSE: Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * PHP version 5
 *
 * @category  Microsoft
 * @package   WindowsAzure\Common\Internal
 * @author    Azure PHP SDK <azurephpsdk@microsoft.com>
 * @copyright 2012 Microsoft Corporation
 * @license   http://www.apache.org/licenses/LICENSE-2.0  Apache License 2.0
 * @link      https://github.com/windowsazure/azure-sdk-for-php
 */
 
namespace WindowsAzure\Common\Internal;

/**
 * Logger class for debugging purpose.
 *
 * @category  Microsoft
 * @package   WindowsAzure\Common\Internal
 * @author    Azure PHP SDK <azurephpsdk@microsoft.com>
 * @copyright 2012 Microsoft Corporation
 * @license   http://www.apache.org/licenses/LICENSE-2.0  Apache License 2.0
 * @version   Release: 0.4.1_2015-03
 * @link      https://github.com/windowsazure/azure-sdk-for-php
 */
class Logger
{
    /**
     * @var string
     */
    private static $_filePath;

    /**
     * Logs $var to file.
     *
     * @param mix    $var The data to log.
     * @param string $tip The help message.
     * 
     * @static
     * 
     * @return none
     */
    public static function log($var, $tip = Resources::EMPTY_STRING)
    {
        if (!empty($tip)) {
            error_log($tip . "\n", 3, self::$_filePath); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- This code doesn’t seem to be getting triggered under any circumstances. There’s nothing in our codebase that calls this class.
        }
        
        if (is_array($var) || is_object($var)) {
            error_log(print_r($var, true), 3, self::$_filePath); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- This code doesn’t seem to be getting triggered under any circumstances. There’s nothing in our codebase that calls this class.
        } else {
            error_log($var . "\n", 3, self::$_filePath); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- This code doesn’t seem to be getting triggered under any circumstances. There’s nothing in our codebase that calls this class.
        }
    }
    
    /**
     * Sets file path to use.
     *
     * @param string $filePath The log file path.
     * 
     * @static
     * 
     * @return none
     */
    public static function setLogFile($filePath)
    {
        self::$_filePath = $filePath;
    }
}


