<?php
namespace com\sakuraplugins\appetit\mainmobile;

require_once(plugin_dir_path(__FILE__) . 'utils/DataAggregation.php');
require_once(plugin_dir_path(__FILE__) . 'utils/CustomCodeHelper.php');
require_once(plugin_dir_path(__FILE__) . 'utils/MetaHelper.php');
require_once(plugin_dir_path(__FILE__) . 'pages/homepage/Homepage.php');
require_once(plugin_dir_path(__FILE__) . 'pages/product/ProductPage.php');
require_once(plugin_dir_path(__FILE__) . 'pages/cart/CartPage.php');
require_once(plugin_dir_path(__FILE__) . 'pages/order/OrderPage.php');
require_once(plugin_dir_path(__FILE__) . 'pages/shop/AboutShop.php');
require_once(plugin_dir_path(__FILE__) . 'pages/order_complete/OrderComplete.php');
require_once(plugin_dir_path(__FILE__) . 'components/SplashScreen.php');

use com\sakuraplugins\appetit\utils\OptionUtil;

class AppetitMainMobileApp {

    private $pages = [Homepage::class, ProductPage::class, CartPage::class, 
    OrderPage::class, OrderComplete::class, AboutShop::class];

    private function _eContent() {
        ?>
        <!doctype html>
        <html class="no-js" lang="">

        <head>
        <meta charset="utf-8">
        <?php MetaHelper::_renderMeta() ?>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/icons/style.css') ?>">
        <link rel="stylesheet" href="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/datepicker/datepicker.min.css') ?>">
        <link rel="stylesheet" href="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/css/index.css') ?>">
        <meta name="theme-color" content="#fafafa">
        <?php \com\sakuraplugins\appetit\utils\RedirectUtils::processPaymentComplete(); ?>
        <?php $this->_e_reCaptchaScript() ?>
        <?php CustomCodeHelper::_ePrimaryColor() ?>
        <?php CustomCodeHelper::_eCustomCSS() ?>
        </head>

        <body>
        <div id="apt-main" class="apt-main">
            <textarea id="appetit_data" style="display: none;"><?= DataAggregation::getInstance()->getAll(true); ?></textarea>
            <?php
            $splashScreen = new SplashScreen();
            $splashScreen->render();
            ?>
            <?php
            foreach ($this->pages as $pageClass) {
                $page = new $pageClass();
                $page->render();
            }
            ?>
        </div>
        
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/jquery_3.6.0.js') ?>"></script>
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/jquery-ui.min.js') ?>"></script>
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/lodash.js') ?>"></script>
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/wNumb.min.js') ?>"></script>
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/vendor/datepicker/datepicker.min.js') ?>"></script>
        <script src="<?= esc_url(INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/js/Index.js') ?>"></script>
        <?= CustomCodeHelper::_eCustomJS() ?>
        <?php
            // from another plugin
            $extended_scripts = apply_filters('instafood_extended_js_scrips', '');
        ?>
        <?php if ($extended_scripts): ?>
            <?= $extended_scripts ?>
        <?php endif; ?>
        </body>

        </html>
        <?php
    }

    public function render(): void {
        \com\sakuraplugins\appetit\utils\RedirectUtils::process();
        ob_start();
        $this->_eContent();
        echo ob_get_clean();
    }

    private function _e_reCaptchaScript() {
        if (!OptionUtil::getInstance()->hasReCaptcha()) {
            return;
        }
        $recaptcha_site_key = OptionUtil::getInstance()->getOption('recaptcha_site_key', '');
        ?>
        <script>
            let IF_RECAPTCHA_SITE_KEY = "<?= trim($recaptcha_site_key) ?>";
        </script>
        <script src="https://www.google.com/recaptcha/api.js?render=<?= trim($recaptcha_site_key)  ?>"></script>
        <?php
    }
}
$mainMobileApp = new AppetitMainMobileApp();
$mainMobileApp->render();
?>