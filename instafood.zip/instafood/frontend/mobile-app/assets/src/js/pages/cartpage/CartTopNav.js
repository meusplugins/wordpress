import EventBus, { Event, Events } from '../../events/EventBus';
import LanguageUtils from '../../utils/LanguageUtils';
import Cart from '../../cart/Cart';
import DataUtils from '../../utils/DataUtils';

class CartTopNav {

    _parrentUI;
    _ui;
    _onCartChangeEvent = null;
    
    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_top_nav');

        this._onCartChangeEvent = new Event(Events.CART_CHANGED, ({ cartProduct }) => {
            this._handleCartChange();
        });
        EventBus.getInstance().registerEvent(this._onCartChangeEvent);
    }

    render() {
        const templateCartHeader = `
            <div class="cart_top_nav_header_content_ui">
                <div class="cart_top_nav_header_content">
                    <div class="cart_nav">
                        <a class="round_nav_fill reverse-color close_cart_page" href="#"><span class="icon-clear"></span></a>
                        <div class="title">${ LanguageUtils.getInstance().getLabel('cart_title') }</div>
                    </div>
                    <div class="total_info">
                        <div class="price_label">${ LanguageUtils.getInstance().getLabel('cart_top_nav_total') } <span class="price_total"></span></div>
                        <div class="price_info">${ LanguageUtils.getInstance().getLabel('cart_top_nav_vat_info') }</div>
                    </div>
                </div>
            </div>
        `;
        jQuery(templateCartHeader).appendTo(this._ui);


        jQuery(this._ui.find('.close_cart_page')).click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_REQUEST);
        })
    }

    _updateTotal() {
        let priceTotal = '';
        if (Cart.getInstance().cartHasItems()) {
            const t = DataUtils.getInstance().getOption('price_display_template');
            const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));
            const total = Cart.getInstance().getCartTotal();
            const formattedPrice = DataUtils.getInstance().getFormmatedPriceDisplay(total);
            priceTotal = priceTemplate({ price: formattedPrice });
        }
        this._ui.find('.price_total').html(`${ priceTotal }`);
    }

    _handleCartChange(data) {
        this._updateTotal();
    }
}
export default CartTopNav;