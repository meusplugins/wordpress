'use strict';

Vue.component( 'jet-elements-general-settings', {

	template: '#jet-dashboard-jet-elements-general-settings',

	data: function() {
		return {
			pageOptions: window.JetElementsSettingsConfig.settingsData,
			preparedOptions: {},
			savingStatus: false,
			clearCacheStatus: false,
			ajaxSaveHandler: null,
		};
	},

	watch: {
		pageOptions: {
			handler( options ) {
				let prepared = {};

				for ( let option in options ) {

					if ( options.hasOwnProperty( option ) ) {
						prepared[ option ] = options[option]['value'];
					}
				}

				this.preparedOptions = prepared;

				this.saveOptions();
			},
			deep: true
		}
	},

	methods: {
		clearCache: function() {
			if ( this.clearCacheStatus ) {
				return;
			}

			var self = this,
				config = window.JetElementsSettingsConfig;
			self.clearCacheStatus = true;

			return wp.apiFetch( {
				method: 'post',
				path: config.clearCacheApiUrl,
				headers: { 'X-Jet-Elements-Cache-Nonce': config.clearCacheNonce },
			} ).then( function( response ) {
				if ( ! response || 'success' !== response.status ) {
					throw new Error( 'clear-cache' );
				}
				self.$CXNotice.add( {
					message: config.messages.clearCacheSuccess,
					type: 'success',
					duration: 3000,
				} );
			} ).catch( function() {
				// Never render arbitrary server/proxy error HTML in notices.
				self.$CXNotice.add( {
					message: config.messages.clearCacheError,
					type: 'error',
					duration: 5000,
				} );
			} ).then( function() {
				self.clearCacheStatus = false;
			} );
		},

		saveOptions: function() {

			var self = this;

			self.savingStatus = true;

			wp.apiFetch( {
				method: 'post',
				path: window.JetElementsSettingsConfig.settingsApiUrl,
				data: self.preparedOptions
			} ).then( function( response ) {

				self.savingStatus = false;

				if ( 'success' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'success',
						duration: 3000,
					} );
				}

				if ( 'error' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'error',
						duration: 3000,
					} );
				}
				
			} ).catch( function( response ) {
				self.$CXNotice.add( {
					message: response.message,
					type: 'error',
					duration: 3000,
				} );
			} );

		},
	}
} );

Vue.component( 'jet-elements-integrations-settings', {

	template: '#jet-dashboard-jet-elements-integrations-settings',

	data: function() {
		return {
			pageOptions: window.JetElementsSettingsConfig.settingsData,
			preparedOptions: {},
			savingStatus: false,
			ajaxSaveHandler: null,
		};
	},

	watch: {
		pageOptions: {
			handler( options ) {
				let prepared = {};

				for ( let option in options ) {

					if ( options.hasOwnProperty( option ) ) {
						prepared[ option ] = options[option]['value'];
					}
				}

				this.preparedOptions = prepared;

				this.saveOptions();
			},
			deep: true
		}
	},

	methods: {

		saveOptions: function() {

			var self = this;

			self.savingStatus = true;

			wp.apiFetch( {
				method: 'post',
				path: window.JetElementsSettingsConfig.settingsApiUrl,
				data: self.preparedOptions
			} ).then( function( response ) {

				self.savingStatus = false;

				if ( 'success' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'success',
						duration: 3000,
					} );
				}

				if ( 'error' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'error',
						duration: 3000,
					} );
				}
				
			} ).catch( function( response ) {
				self.$CXNotice.add( {
					message: response.message,
					type: 'error',
					duration: 3000,
				} );
			} );
		},
	}
} );

Vue.component( 'jet-elements-avaliable-addons', {

	template: '#jet-dashboard-jet-elements-avaliable-addons',

	data: function() {
		return {
			pageOptions: window.JetElementsSettingsConfig.settingsData,
			preparedOptions: {},
			savingStatus: false,
			ajaxSaveHandler: null,
		};
	},

	watch: {
		pageOptions: {
			handler( options ) {
				let prepared = {};

				for ( let option in options ) {

					if ( options.hasOwnProperty( option ) ) {
						prepared[ option ] = options[option]['value'];
					}
				}

				this.preparedOptions = prepared;

				this.saveOptions();
			},
			deep: true
		}
	},

	methods: {

		saveOptions: function() {

			var self = this;

			self.savingStatus = true;

			wp.apiFetch( {
				method: 'post',
				path: window.JetElementsSettingsConfig.settingsApiUrl,
				data: self.preparedOptions
			} ).then( function( response ) {

				self.savingStatus = false;

				if ( 'success' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'success',
						duration: 3000,
					} );
				}

				if ( 'error' === response.status ) {
					self.$CXNotice.add( {
						message: response.message,
						type: 'error',
						duration: 3000,
					} );
				}
				
			} ).catch( function( response ) {
				self.$CXNotice.add( {
					message: response.message,
					type: 'error',
					duration: 3000,
				} );
			} );
		},
	}
} );
