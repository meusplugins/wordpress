<?php return array('dependencies' => array(), 'version' => '16388c90c6030109ec2c');
