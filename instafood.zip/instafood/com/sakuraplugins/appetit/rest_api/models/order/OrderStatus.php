<?php
namespace com\sakuraplugins\appetit\rest_api\models;
if (!defined('ABSPATH')) exit;

abstract class OrderStatus {
    const NEW_ORDER = 'NEW_ORDER';
    const ACCEPTED = 'ACCEPTED';
    const REJECTED = 'REJECTED';
    const PREPARED = 'PREPARED';
    const DELIVERED = 'DELIVERED';
    const CLOSED = 'CLOSED';

    static function getAll() {
        return [self::NEW_ORDER, self::ACCEPTED, self::REJECTED, self::PREPARED, self::DELIVERED, self::CLOSED];
    }

    static function getMappedToLabels() {
        return [
            self::NEW_ORDER => esc_html__('New', 'instafood'),
            self::ACCEPTED => esc_html__('Accepted', 'instafood'),
            self::REJECTED => esc_html__('Rejected', 'instafood'),
            self::PREPARED => esc_html__('Prepared', 'instafood'),
            self::DELIVERED => esc_html__('Delivered', 'instafood'),
            self::CLOSED => esc_html__('Closed', 'instafood'),
        ];
    }

    static function getMappedToColors() {
        return [
            self::NEW_ORDER => '#fff0a6',
            self::ACCEPTED => '#FEE5E0',
            self::REJECTED => '#fc736e',
            self::PREPARED => '#FED5D1',
            self::DELIVERED => '#CCEDE4',
            self::CLOSED => '#efefef',
        ];
    }
}
?>