<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;


require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');

use com\sakuraplugins\appetit\services\ProductSevice;
use com\sakuraplugins\appetit\services\ChoiceGroupsService;
use com\sakuraplugins\appetit\services\CategoriesService;
use com\sakuraplugins\appetit\services\LocalesService;
use com\sakuraplugins\appetit\services\OptionsService;


class GetAllDataController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/get-all-data', array(
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'getAllData'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * retrieve all data (products, options & such)
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function getAllData(\WP_REST_Request $request) {
        
        return ResponseHelper::respond(['all_data' => [
            'products' => ProductSevice::getInstance()->getAllProducts(),
            'choiceGroups' => ChoiceGroupsService::getInstance()->getGroups(),
            'choices' => ChoiceGroupsService::getInstance()->getAllChoices(),
            'product_categories' => CategoriesService::getInstance()->getCategories(),
            'locales' => LocalesService::getInstance()->getLocales(),
            'options' => OptionsService::getInstance()->getOptions(),
        ]]);
    }
}
?>