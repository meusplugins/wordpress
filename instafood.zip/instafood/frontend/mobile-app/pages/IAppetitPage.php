<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

interface IAppetitPage {
    public function render(): void;
}
?>