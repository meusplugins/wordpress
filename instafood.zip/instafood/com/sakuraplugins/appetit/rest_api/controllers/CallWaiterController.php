<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');
require_once(plugin_dir_path(__FILE__) . '../guards/Guards.php');
require_once(plugin_dir_path(__FILE__) . '../../services/WaiterService.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/Sanitizer.php');

use \com\sakuraplugins\appetit\rest_api\guards\Guards;
use \com\sakuraplugins\appetit\services\WaiterService;
use \com\sakuraplugins\appetit\utils\Sanitizer;

class CallWaiterController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/waiter', array(
            array(
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'callWaiter'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * create order
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function callWaiter(\WP_REST_Request $request) {
        $guardResult = Guards::use([Guards::RecaptchaGuard], $request);
        if($guardResult instanceof \WP_REST_Response) {
            return $guardResult;
        }

        $table = Sanitizer::sanitizeInput($request->get_param('table'));
        $ws = new WaiterService();
        $ws->addCall($table);
        
        return ResponseHelper::respond([]);
    }
}
?>