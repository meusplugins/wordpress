import EventBus, { Event, Events } from '../../events/EventBus';
import TopNav from './TopNav';
import BottomNav from './BottomNav';
import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';

let instance;
const instanceKey = '_order_complete_screen';

class AboutShopPage {

    _isOpen = false;
    _ui;
    _onOrderCompleteOpenEvent;
    _onOrderCompleteCloseEvent;
    _topNav;
    _bottomNav;

    _orderSummaryData;
    _isPickup;
    _isDinein;
    _isDelivery;

    init() {
        this._ui = jQuery('#apt_shop_about_screen');
        this._topNav = new TopNav(this._ui);
        this._topNav.render();
        this._bottomNav = new BottomNav(this._ui);
        this._bottomNav.render();
        this._content_ui = this._ui.find('.both_nav_apt_content_ui');
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderCompleteOpenEvent = new Event(Events.OPEN_SHOP_SCREEN_REQUEST, data => this._pageOpen(data));
        EventBus.getInstance().registerEvent(this._onOrderCompleteOpenEvent);
        this._onOrderCompleteCloseEvent = new Event(Events.CLOSE_SHOP_SCREEN_REQUEST, data => this._pageClose(data));
        EventBus.getInstance().registerEvent(this._onOrderCompleteCloseEvent);
    }

    _renderAbout() {
        const template = `
        <div class="apt_content_widget mt_20 bm_20 pickup_info_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-shop wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('restaurant_about_wdg_title') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="simple_text">${ LanguageUtils.getInstance().getLabel('restaurant_about') }</div>
                </div>
            </div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderAddress() {
        const template = `
        <div class="apt_content_widget mt_20 bm_20 pickup_info_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-location wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('restaurant_address_wdg_title') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="simple_text">${ DataUtils.getInstance().getOption('restaurant_address') }</div>
                </div>
            </div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderBusinessHours() {
        const business_hours = DataUtils.getInstance().getOption('business_hours');
        if (!Array.isArray(business_hours)) {
            return;
        }
        const lang_key = LanguageUtils.getInstance().getLang();
        let bh_html = ''
        business_hours.forEach(entry => {
            const day_intervals = _.get(entry, 'day_intervals', []);
            let intervalsHtml = '';
            day_intervals.forEach(interval => {
                const start = `${interval?.interval_start_hh}:${interval?.interval_start_mm}${interval?.am_pm_select_start.toLowerCase()}`
                const end = `${interval?.interval_stop_hh}:${interval?.interval_stop_mm}${interval?.am_pm_select_stop.toLowerCase()}`
                intervalsHtml += `<div class="hours_entry">${start} - ${end}</div>`;
            })
            bh_html += `
                <div class="business_hours_entry_main mb_10">
                    <div class="day_label">${ _.get(entry, `day_locale.${lang_key}`) }:</div>
                    <div class="business_hours_entry">
                        ${ intervalsHtml }
                    </div>
                </div>
            `
        });
        const template = `
        <div class="apt_content_widget mt_20 bm_20 pickup_info_widget bussiness_hours_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-calendar1 wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('restaurant_working_hours_wdg_title') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    ${bh_html}
                </div>
            </div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _populateContent() {
        this._renderAbout();
        this._renderAddress();
        this._renderBusinessHours();
    }

    _pageOpen(data) {

        this._onBeforePageOpen();
        this._ui.animate({
            top: 0
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageOpen();
        });
    }

    _onBeforePageOpen() {
        this._populateContent();
        this._ui.css('opacity', 1);
        this._ui.css('top', this._ui.height());
        if (this._ui.hasClass('hide')) {
            this._ui.removeClass('hide');
        }
    }

    _onAfterPageOpen() {
        this._isOpen = true;
    }

    _pageClose() {
        this._onBeforePageClose();
        this._ui.animate({
            top: this._ui.height()
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageClose();
        });
    }

    _onBeforePageClose() {}

    _onAfterPageClose() {
        this._isOpen = false;
        this._content_ui.empty();
        this._ui.css('opacity', 0);
    }

    static getInstance() {
        if (!instance) {
            instance = new AboutShopPage(instanceKey);
        }
        return instance;
    }
}
export default AboutShopPage;