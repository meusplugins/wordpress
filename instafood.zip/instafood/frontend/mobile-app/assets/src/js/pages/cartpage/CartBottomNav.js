import LanguageUtils from '../../utils/LanguageUtils';
import Cart from '../../cart/Cart';
import DataUtils from '../../utils/DataUtils';
import EventBus, { Events } from '../../events/EventBus';

class CartBottomNav {
    _parrentUI;
    _ui;

    _hasTable;
    _meetsMinOrderValue;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_nav_bottom');
    }
    
    render() {
        const _this = this;
        const template = `
            <div class="cart_nav_bottom">
                <span class="min_order_val_info"></span>
                <a href="#" class="apt_button primary review_order_btn inactive">
                ${ LanguageUtils.getInstance().getLabel('review_order_label') }
                </a>
            </div>
        `;
        jQuery(template).appendTo(this._ui);
        this._ui.find('.review_order_btn').click(function(event) {
            event.preventDefault();
            if (!_this._hasTable) {
                if (!_this._meetsMinOrderValue) {
                    return;
                }
            }
            EventBus.getInstance().triggerEvent(Events.OPEN_ORDER_SCREEN_REQUEST, {});
        })
    }

    update() {
        this._meetsMinOrderValue = DataUtils.getInstance().meetsMinOrderValue();
        this._hasTable = DataUtils.getInstance().hasCurrentTable();

        if (this._hasTable || (!this._hasTable && this._meetsMinOrderValue)) {
            this._ui.find('.min_order_val_info').empty();
            if (this._ui.find('.review_order_btn').hasClass('inactive')) {
                this._ui.find('.review_order_btn').removeClass('inactive');
            }
        } else {
            const t = DataUtils.getInstance().getOption('price_display_template');
            const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));
            const priceDif = DataUtils.getInstance().getDifMinOrder();
            const priceDifString = priceTemplate({ price: Number.parseFloat(priceDif).toFixed(2) });
            const priceInfotemplate = _.template(LanguageUtils.getInstance().decodeHtml(LanguageUtils.getInstance().getLabel('min_order_info')));
            if (isNaN(priceDif)) {
                return;
            }
            this._ui.find('.min_order_val_info').html(`<span class="info_min_order_template">${ priceInfotemplate({ minOrderValueDif: priceDifString }) }</span>`);
            if (!this._ui.find('.review_order_btn').hasClass('inactive')) {
                this._ui.find('.review_order_btn').addClass('inactive');
            }
        }
    }
}
export default CartBottomNav;