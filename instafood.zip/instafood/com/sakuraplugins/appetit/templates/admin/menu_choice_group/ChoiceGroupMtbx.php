<?php
namespace com\sakuraplugins\appetit\templates\admin\menu_item;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../../../cpt/ChoiceGroupsCpt.php');

use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt as ChoiceGroupsCpt;

class ChoiceGroupMtbx {
    private $post_meta = [];
    private $post_meta_key = '';

    function __construct() {
        global $post;
        $this->post_meta_key = ChoiceGroupsCpt::getMetaKey();
        $this->post_meta = get_post_meta($post->ID, $this->post_meta_key, true);
        if (!is_array($this->post_meta)) {
            $this->post_meta = [];
        }
    }

    public function renderGroupDetails(): void {
        $min_choices_num = isset($this->post_meta['min_choices_num']) ? $this->post_meta['min_choices_num'] : NULL;
        $max_choices_num = isset($this->post_meta['max_choices_num']) ? $this->post_meta['max_choices_num'] : NULL;
        $choices_ids = isset($this->post_meta['choices_ids']) && is_array($this->post_meta['choices_ids']) ? $this->post_meta['choices_ids'] : [];

        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="group_name_1"><?= esc_html__('Group name', 'instafood') ?>*</label>
                        <input type="text" value="<?= isset($this->post_meta['primary_lang_group_name']) ? esc_attr($this->post_meta['primary_lang_group_name']) : ''  ?>"
                         class="form-control" id="group_name_1" aria-describedby="group_name_1_help" required name="<?= esc_attr($this->post_meta_key . '[primary_lang_group_name]') ?>">
                        <small id="group_name_1_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="group_name_2"><?= esc_html__('Group name (Optional - secondary language)', 'instafood') ?></label>
                        <input type="text" value="<?= isset($this->post_meta['secondary_lang_group_name']) ? esc_attr($this->post_meta['secondary_lang_group_name']) : ''  ?>" class="form-control" id="group_name_2" 
                        aria-describedby="group_name_2_help" name="<?= esc_attr($this->post_meta_key . '[secondary_lang_group_name]') ?>">
                        <small id="group_name_2_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="col-md-6">
                    <label for="min_choices_select"><?= esc_html__('Minimum number of choices', 'instafood') ?></label>
                    <select id="min_choices_select" class="form-select d-block w-100" name="<?= esc_attr($this->post_meta_key . '[min_choices_num]') ?>">
                        <option selected><?= esc_html__('Select', 'instafood') ?></option>
                        <option value="0" <?= isset($min_choices_num) && $min_choices_num === '0' ? 'selected' : '' ?>><?= esc_html__('0 (Optional)', 'instafood') ?></option>
                        <?php if (sizeof($choices_ids) > 0): ?>
                            <?php for ($i=0; $i < sizeof($choices_ids); $i++): ?>
                                <?php $choiceNo = $i + 1; ?>
                                <option <?= $min_choices_num && (int) $min_choices_num === $choiceNo ? 'selected' : '' ?> value="<?= esc_attr($choiceNo) ?>"><?= $choiceNo ?></option>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </select>
                    <small class="form-text text-muted"><?= esc_html__('Enter "0" if this group is optional for your customers', 'instafood') ?></small>
                </div>
                <div class="col-md-6">
                    <label for="max_choices_select"><?= esc_html__('Maximum number of choices', 'instafood') ?></label>
                    <select id="max_choices_select" class="max_choices_select form-select d-block w-100" name="<?= esc_attr($this->post_meta_key . '[max_choices_num]') ?>">
                        <option selected><?= esc_html__('Select', 'instafood') ?></option>
                        <option value="0" <?= isset($max_choices_num) && $max_choices_num === '0' ? 'selected' : '' ?>><?= esc_html__('0 (Optional)', 'instafood') ?></option>
                        <?php if (sizeof($choices_ids) > 0): ?>
                            <?php for ($i=0; $i < sizeof($choices_ids); $i++): ?>
                                <?php $choiceNo = $i + 1; ?>
                                <option <?= $max_choices_num && (int) $max_choices_num === $choiceNo ? 'selected' : '' ?> value="<?= esc_attr($choiceNo) ?>"><?= $choiceNo ?></option>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </select>
                    <small class="form-text text-muted"><?= esc_html__('Enter "1" if your customers can only choose 1', 'instafood') ?></small>
                </div>
                <div class="col-md-12 mt_20">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Note! Possible values for both the Minimum & Maximum number of choices are being available once choices have been added to the group & the group has been updated/saved.", 'instafood') ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function renderGroupChoices() {
        $itemChoices = get_terms(['taxonomy' => ChoiceGroupsCpt::CHOICE_SLUG, 'hide_empty' => FALSE, 'parent' => 0]);
        $choices_ids = isset($this->post_meta['choices_ids']) && is_array($this->post_meta['choices_ids']) ? $this->post_meta['choices_ids'] : [];
        
        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-12" style="color: #696969;">
                    <?= esc_html__('Add choices for your customers to choose from.', 'instafood') ?>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="col-md-8">
                    <?php if (is_array($itemChoices) && sizeof($itemChoices) > 0): ?>
                        <select class="form-select d-block w-100 select_choice">
                            <option value=""><?= esc_html__('Select choice ...', 'instafood'); ?></option>
                            <?php foreach ($itemChoices as $choice): ?>
                                <?php
                                $choice_meta = get_term_meta($choice->term_id, ChoiceGroupsCpt::CHOICE_META_KEY, true);
                                $choice_name_1 = $choice->name;
                                $choice_name_2 = isset($choice_meta['choice_name_2']) ? $choice_meta['choice_name_2'] : '';
                                $choice_price = isset($choice_meta['choice_price']) ? $choice_meta['choice_price'] : 0;
                                ?>
                                <option data-choice-id="<?= esc_attr($choice->term_id) ?>" 
                                data-choice-name="<?= esc_attr($choice_name_1) ?>" 
                                data-choice-name-s="<?= esc_attr($choice_name_2) ?>" 
                                data-choice-price="<?= esc_attr($choice_price) ?>" 
                                value="<?= esc_attr($choice->term_id); ?>"><?= esc_html($choice->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <div class="alert alert-warning" role="alert">
                        <?= esc_html__('There are no available choices yet. In order to add a choice go to Appetit choice groups > Menu choices.', 'instafood') ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <button type="button" class="btn btn-secondary add_choice_btn w-100" disabled><?= esc_html__('Add choice', 'instafood') ?></button>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <?php if (is_array($itemChoices) && sizeof($itemChoices) > 0): ?>
                    <table class="choices_table">
                        <tr>
                            <th><?= esc_html__('Choice name', 'instafood') ?></th>
                            <th><?= esc_html__('Choice name (secondary language)', 'instafood') ?></th>
                            <th><?= esc_html__('Price', 'instafood') ?></th>
                            <th></th>
                        </tr>
                        <?php if (sizeof($choices_ids) > 0): ?>
                            <?php
                            $selectedChoices = get_terms(
                                [
                                    'taxonomy' => ChoiceGroupsCpt::CHOICE_SLUG,
                                    'include' => $choices_ids,
                                    'hide_empty' => FALSE,
                                    'parent' => 0
                                ]
                            );
                            ?>
                            <?php if (is_array($selectedChoices) && sizeof($selectedChoices)): ?>
                                <?php foreach ($selectedChoices as $selectedChoice): ?>
                                    <?php
                                    $choice_meta = get_term_meta($selectedChoice->term_id, ChoiceGroupsCpt::CHOICE_META_KEY, true);
                                    $choice_name_1 = $selectedChoice->name;
                                    $choice_name_2 = isset($choice_meta['choice_name_2']) ? $choice_meta['choice_name_2'] : '';
                                    $choice_price = isset($choice_meta['choice_price']) && $choice_meta['choice_price'] !== '' ? $choice_meta['choice_price'] : 0;
                                    ?>
                                    <tr class="choice_entry" data-choice-id="<?= $selectedChoice->term_id ?>">
                                        <td><?= esc_html($choice_name_1) ?><input type="hidden" value="<?= esc_attr($selectedChoice->term_id) ?>" name="<?= esc_attr($this->post_meta_key . '[choices_ids][]') ?>" /></td>
                                        <td><?= esc_html($choice_name_2) ?></td>
                                        <td><?= esc_html($choice_price) ?></td>
                                        <td><a class="delete_choice_btn" href="#"><?= esc_html__('Delete', 'instafood') ?></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
?>