<?php
namespace Jet_Engine\Query_Builder\Listings;

use Jet_Engine\Query_Builder\Manager as Query_Manager;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define listings manager class
 */
class Manager {

	public $source = 'query';
	public $source_meta = '_query_id';
	/**
	 * @var Filters
	 */
	public $filters = null;
	public $query = null;

	/**
	 * Constructor.
	 *
	 * Hooks into the query builder init action to register listing integrations
	 * after the query builder component is fully loaded.
	 */
	public function __construct() {
		add_action( 'jet-engine/query-builder/init', array( $this, 'init' ) );
	}

	/**
	 * Initialize listing integrations for the query builder.
	 *
	 * Registers filters and actions for listing source replacement, preview setup,
	 * item ID resolution, and popup object handling. Also boots Elementor, Blocks,
	 * and JetSmartFilters integrations when available.
	 *
	 * @return void
	 */
	public function init() {

		add_filter( 'jet-engine/templates/created', array( $this, 'add_meta_to_listing' ), 10, 2 );
		add_filter( 'jet-engine/listing/grid/source', array( $this, 'replace_listing_source' ), 10, 2 );

		require_once Query_Manager::instance()->component_path( 'listings/query.php' );

		$this->query = new Query();

		if ( jet_engine()->has_elementor() ) {
			require_once Query_Manager::instance()->component_path( 'listings/elementor.php' );
			new Elementor();
		}

		require_once Query_Manager::instance()->component_path( 'listings/blocks.php' );
		new Blocks();

		if ( function_exists( 'jet_smart_filters' ) ) {

			require_once Query_Manager::instance()->component_path( 'listings/filters.php' );
			require_once Query_Manager::instance()->component_path( 'listings/filters-options-source.php' );
			require_once Query_Manager::instance()->component_path( 'listings/filters-switch-query.php' );

			$this->filters = new Filters();

			new Filters_Options_Source();
			new Filters_Switch_Query();

		}

		add_action( 'jet-engine/listings/document/get-preview/' . $this->source, array( $this, 'setup_preview' ) );

		add_filter( 'jet-engine/listing/custom-post-id', array( $this, 'set_query_item_id' ), 10, 2 );

		require_once Query_Manager::instance()->component_path( 'listings/file-query-popup.php' );
		new File_Query_Popup( $this );

		$this->register_map_source();
	}

	/**
	 * Get the query ID associated with a listing.
	 *
	 * Returns the query ID stored in post meta, or the custom query ID from
	 * listing settings when a custom query override is enabled.
	 *
	 * @param int   $listing_id The listing post ID.
	 * @param array $settings   The listing widget/block settings.
	 * @return int The resolved query ID, or 0 if not set.
	 */
	public function get_query_id( $listing_id, $settings ) {

		$query_id        = get_post_meta( $listing_id, $this->source_meta, true );
		$is_custom_query = ! empty( $settings['custom_query'] ) ? filter_var( $settings['custom_query'], FILTER_VALIDATE_BOOLEAN ) : false;

		if ( $is_custom_query && ! empty( $settings['custom_query_id'] ) ) {
			$query_id = absint( $settings['custom_query_id'] );

			if ( ! $this->is_valid_request_query_id( $query_id, $listing_id ) ) {
				return false;
			}
		}

		return $query_id;

	}

	/**
	 * Validate that request-driven listing renders use the signed query id.
	 *
	 * @param int $query_id Widget/server-side query id.
	 * @param int $listing_id Listing used by the current renderer.
	 * @return bool
	 */
	protected function is_valid_request_query_id( $query_id, $listing_id = 0 ) {

		if ( ! jet_engine()->listings->is_listing_ajax( 'listing_load_more' ) && ! jet_engine()->listings->is_listing_ajax( 'get_listing' ) ) {
			return true;
		}

		$request_settings   = ! empty( $_REQUEST['widget_settings'] ) && is_array( $_REQUEST['widget_settings'] ) ? $_REQUEST['widget_settings'] : array();
		$request_listing_id = ! empty( $request_settings['lisitng_id'] ) ? absint( $request_settings['lisitng_id'] ) : 0;

		// Nested renderers use settings stored in the requested listing template.
		if ( $request_listing_id && absint( $listing_id ) !== $request_listing_id ) {
			return true;
		}

		if ( ! empty( $_REQUEST['query']['allowed_query_ids'] ) && in_array( $query_id, $_REQUEST['query']['allowed_query_ids'] ) ) {
			return true;
		}

		if ( empty( $_REQUEST['query'] ) || ! is_array( $_REQUEST['query'] ) || empty( $_REQUEST['query']['query_id'] ) ) {
			return false;
		}

		if ( empty( $_REQUEST['query']['custom_query_id'] ) ) {
			return false;
		}

		return absint( $_REQUEST['query']['query_id'] ) === absint( $query_id )
			&& absint( $_REQUEST['query']['custom_query_id'] ) === absint( $query_id );
	}

	/**
	 * Replace listing source if custom query is enabled
	 *
	 * Hooked into `jet-engine/listing/grid/source`. When the listing settings
	 * have a custom query configured, this method replaces the current source
	 * with the query source identifier and re-initialises the listing document
	 * with the selected query ID.
	 *
	 * @param string $source   The current listing data source.
	 * @param array  $settings The listing widget/block settings.
	 * @return string The (possibly replaced) listing data source.
	 */
	public function replace_listing_source( $source, $settings ) {

		$is_custom_query = ! empty( $settings['custom_query'] ) ? filter_var( $settings['custom_query'], FILTER_VALIDATE_BOOLEAN ) : false;

		if ( $is_custom_query && ! empty( $settings['custom_query_id'] ) ) {
			$source = $this->source;

			// Replace listing document.
			jet_engine()->listings->data->set_listing(
				jet_engine()->listings->get_new_doc(
					array(
						'listing_source' => $source,
						'_query_id'      => $settings['custom_query_id'],
					),
					absint( $settings['lisitng_id'] ) )
			);
		}

		return $source;

	}

	/**
	 * Persist the query ID as post meta when a new query-source listing is created.
	 *
	 * Hooked into `jet-engine/templates/created`. When the newly created listing
	 * uses the query source and a `_query_id` value is present in the request,
	 * the query ID is saved to post meta so it can be retrieved later.
	 *
	 * @param int   $listing_id The newly created listing post ID.
	 * @param array $data       The raw data used to create the listing.
	 * @return void
	 */
	public function add_meta_to_listing( $listing_id, $data ) {

		$source = ! empty( $_REQUEST['listing_source'] ) ? esc_attr( $_REQUEST['listing_source'] ) : 'posts';

		if ( $this->source === $source && ! empty( $_REQUEST['_query_id'] ) ) {
			update_post_meta( $listing_id, $this->source_meta, absint( $_REQUEST['_query_id'] ) );
		}

	}

	/**
	 * Set up the preview object for a query-source listing document.
	 *
	 * Hooked into `jet-engine/listings/document/get-preview/{source}`. Resolves
	 * the first item returned by the associated query and sets it as the current
	 * listing object so the editor preview is populated with real data.
	 *
	 * @param \Jet_Engine\Listings\Document|false $document The listing document instance, or false
	 *                                                      to use the currently active document.
	 * @return object|false The preview object, or false when none can be resolved.
	 */
	public function setup_preview( $document = false ) {

		if ( ! $document ) {
			$document = jet_engine()->listings->data->get_listing();
		}

		$source = $document->get_settings( 'listing_source' );

		if ( $this->source !== $source ) {
			return false;
		}

		$preview_object = $this->get_preview_object_for_document( $document->get_main_id() );

		jet_engine()->listings->data->set_current_object( $preview_object );

		return $preview_object;

	}

	/**
	 * Retrieve the first query result item to use as the preview object.
	 *
	 * Reads the query ID from the document post meta, executes the query, and
	 * returns the first item after stamping it with the query ID. Returns false
	 * when no query is configured or the query returns no results.
	 *
	 * @param int $document_id The listing document post ID.
	 * @return object|false The first query result item, or false on failure.
	 */
	public function get_preview_object_for_document( $document_id ) {

		$query_id = get_post_meta( $document_id, $this->source_meta, true );

		if ( ! $query_id ) {
			return false;
		}

		$query = Query_Manager::instance()->get_query_by_id( $query_id );

		if ( ! $query ) {
			return false;
		}

		$items = $query->get_items();
		$items = ! empty( $items ) ? array_values( $items ) : array();

		if ( ! empty( $items ) ) {

			$items[0]->_query_id = $query_id;

			jet_engine()->listings->data->set_current_object( $items[0] );

			return $items[0];
		} else {
			return false;
		}

	}

	/**
	 * Override the current post ID with the query item's own identifier.
	 *
	 * Hooked into `jet-engine/listing/custom-post-id`. SQL query items expose
	 * their ID via `sql_query_item_id` and file-query items via
	 * `__file_query_item_id`; either property takes precedence over the default
	 * post ID when present.
	 *
	 * @param int|string $id     The default post ID.
	 * @param object     $object The current listing object.
	 * @return int|string The resolved item ID.
	 */
	public function set_query_item_id( $id, $object ) {

		if ( isset( $object->sql_query_item_id ) ) {
			$id = $object->sql_query_item_id;
		}

		if ( isset( $object->__file_query_item_id ) ) {
			$id = $object->__file_query_item_id;
		}

		return $id;
	}

	/**
	 * Register the file-query map source with the Maps Listings module.
	 *
	 * Does nothing when the Maps Listings module is not active or its module
	 * class is unavailable.
	 *
	 * @return void
	 */
	public function register_map_source() {

		if (
			! jet_engine()->modules->is_module_active( 'maps-listings' )
			|| ! class_exists( 'Jet_Engine\Modules\Maps_Listings\Module' )
		) {
			return;
		}

		require_once Query_Manager::instance()->component_path( 'listings/maps-source.php' );

		\Jet_Engine\Modules\Maps_Listings\Module::instance()->sources->register_source( new File_Query_Maps_Source() );
	}

	/**
	 * Extract the numeric query ID prefix from a stable item identifier.
	 *
	 * File-query item IDs are formatted as `{queryId}-{itemIdentifier}`. This
	 * method parses and returns the leading numeric segment, or 0 when the
	 * format does not match.
	 *
	 * @param mixed $item_id The item identifier to parse.
	 * @return int The extracted query ID, or 0 if the format is not recognised.
	 */
	public function extract_query_id_from_item_id( $item_id ) {
		$item_id = is_scalar( $item_id ) ? (string) $item_id : '';

		if ( ! preg_match( '/^(\d+)-/', $item_id, $matches ) ) {
			return 0;
		}

		return absint( $matches[1] );
	}

}
