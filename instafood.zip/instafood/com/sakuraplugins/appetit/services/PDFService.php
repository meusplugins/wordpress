<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/OrderTypes.php');
require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../utils/PriceUtil.php');


use \com\sakuraplugins\appetit\rest_api\models\Order;
use \com\sakuraplugins\appetit\rest_api\models\OrderTypes;
use \com\sakuraplugins\appetit\utils\OptionUtil;
use \com\sakuraplugins\appetit\utils\PriceUtil;

class PDFHelper {
    private $order;

    private $restaurant_name;
    private $restaurant_address;
    private $restaurant_phone;
    private $lineItemsData;
    private $vat_percentage = false;

    function render() {
        if (!isset($_GET['opid'])) {
            ?>
            <?= esc_html__("Invalid public order id", 'instafood'); ?>
            <?php
            return;
        }

        $this->order = new Order();
        $ID = $this->order->findOneByPublicId(sanitize_text_field(wp_unslash($_GET['opid'])));
        if (!is_numeric($ID)) {
            ?>
            <?= esc_html__("Order does not exist", 'instafood'); ?>
            <?php
            return;
        }
        $this->order->populate();
        $this->lineItemsData = $this->order->getLineItemsData();

        $local_order_print_bill_table_no = OptionUtil::getInstance()->getOption("local_order_print_bill_table_no", '');
        
        $tableNoPrint = '';
        if ($local_order_print_bill_table_no === 'ON') {
            $orderAllData = $this->order->getAllProperties(); 
            $_orderType = $orderAllData['_orderType'] ?? '';
            if ($_orderType === OrderTypes::DINEIN) {
                $tableNoPrint = $orderAllData['_delivery_info']['_table'] ?? '';
            }
        }

        $this->restaurant_name = OptionUtil::getInstance()->getOption("restaurant_name", '');
        $this->restaurant_address = OptionUtil::getInstance()->getOption("restaurant_address", '');
        $this->restaurant_phone = OptionUtil::getInstance()->getOption("restaurant_phone", '');
        $vat = OptionUtil::getInstance()->getOption("vat_percentage", '');
        if ($vat !== '' && is_numeric(floatval($vat))) {
            $this->vat_percentage = floatval($vat);
        }
        ?>
        <!DOCTYPE html>
        <html lang="en-US">
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <meta charset="utf-8">
            <link href="//fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">
            <?php $this->renderCss(); ?>
            <title><?= esc_html__("Order #", 'instafood') . $this->order->getId() ?></title>
        </head>

            <body>
                <div class="container">
                    <div class="top">
                        <a class="btn_primary print_btn" href="#"><?= esc_html__("Print", 'instafood') ?></a>
                    </div>
                </div>
                <div class="container bg_white">
                    <div class="top-content">
                        <h3><?= esc_html__("Order #", 'instafood') . $this->order->getId() ?></h3>
                        <h4><?= esc_html__($this->restaurant_name) ?></h4>
                        <div><?= esc_html__($this->restaurant_address) ?></div>
                    </div>
                    <div class="hr mt_10 mb_10"></div>


                    <?php if ($tableNoPrint !== ''): ?>
                    <div class="table_info">
                        <h4><?= esc_html__("Table no:", 'instafood') ?> <?= esc_html($tableNoPrint) ?></h4>
                    </div>
                    <?php endif ?>

                    <div class="items">
                        <?= $this->_generateItemsInfo() ?>
                    </div>
                </div>
                <script src="//ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                <script>
                    jQuery(document).ready(function() {
                        jQuery('.print_btn').click(function(event) {
                            event.preventDefault();
                            window.print();
                        })
                    });
                </script>
            </body>

        </html>
        <?php
    }

    private function _generateItemsInfo(): string {

        $line_items = $this->lineItemsData['line_items'] ?? [];

        $lineItemsHtml = '';

        foreach ($line_items as $lineItem) {
            $type = $lineItem['type'] ?? '';
            if ($type === 'prduct') {
                $price = $lineItem['price'] ?? '';
                $quantity = $lineItem['quantity'] ?? '';
                $name = $quantity . 'x ' . $lineItem['name'] ?? '';
                $hasVariants = $lineItem['hasVariants'] ?? false;
                if ($hasVariants) {
                    $variantName = $lineItem['variant']['name'] ?? '';
                    $name .= " ($variantName)";
                }
                
                $choices = $lineItem['choices'] ?? [];
                $choicesHtml = '';
                if (sizeof($choices) > 0) {
                    for ($i = 0; $i < sizeof($choices); $i++) { 
                        $choiceName = $choices[$i]['name'] ?? '';
                        $choiceSeparator = $i < sizeof($choices) - 1 ? ', ' : '';
                        $choicesHtml .= $choiceName . $choiceSeparator;
                    }
                }
                $lineItemsHtml .= $this->_getLineItemHtml($name, $this->_priceUtil($price), $choicesHtml);
            }
            if ($type === 'tipping') {
                $tipName = $lineItem['name'] ?? '';
                $tipPrice = $lineItem['price'] ?? '';
                $lineItemsHtml .= $this->_getLineItemHtml($tipName, $this->_priceUtil($tipPrice));
            }
            if ($type === 'delivery_cost') {
                $deliveryName = $lineItem['name'] ?? '';
                $deliveryPrice = $lineItem['price'] ?? '';
                $lineItemsHtml .= $this->_getLineItemHtml($deliveryName, $this->_priceUtil($deliveryPrice));
            }
        }


        if (sizeof($line_items) > 0 && $this->vat_percentage && (int)$this->vat_percentage !== 0) {
            $order_total = $this->lineItemsData['total'] ?? '';
            $vatTotal = ($order_total * $this->vat_percentage) / 100;
            $totalNet = $order_total - $vatTotal;
            $totalNet = number_format((float)$totalNet, 2, '.', '');
            $vatTotal = number_format((float)$vatTotal, 2, '.', '');

            $lineItemsHtml .= '<tr><td style="padding: 1em;"></td><td></td><td></td></tr>';
            $lineItemsHtml .= $this->_getLineItemHtml(esc_html__("Subtotal", 'instafood'), $this->_priceUtil($totalNet), '', true);
            $lineItemsHtml .= $this->_getLineItemHtml(esc_html__("VAT", 'instafood'), $this->_priceUtil($vatTotal), '', true);
            $lineItemsHtml .= $this->_getLineItemHtml(esc_html__("Total", 'instafood'), $this->_priceUtil($order_total), '', true);
        }

        if (sizeof($line_items) > 0 && isset($this->vat_percentage) && (int)$this->vat_percentage === 0) {
            $order_total = $this->lineItemsData['total'] ?? '';
            $lineItemsHtml .= '<tr><td style="padding: 1em;"></td><td></td><td></td></tr>';
            $lineItemsHtml .= $this->_getLineItemHtml(esc_html__("Total", 'instafood'), $this->_priceUtil($order_total), '', true);
        }

        return '
            <h4>'. esc_html__("Items", 'instafood') .'</h4>
            <table style="width:100%;">
            '. $lineItemsHtml .'
            </table>
        ';
    }

    private function _getLineItemHtml($name, $price, $info = '', $isBold = false): string {
        $infoHtml = '';
        if ($info !== '') {
            $infoHtml = '<br><span style="color: #7a7a7a; font-size: 14px;">'. $info .'</span>';
        }
        $style = '';
        if ($isBold) {
            $style = 'font-weight: bold;';
        }

        return '
        <tr>
            <td style="padding: 5px 0;">
                <span style="'. $style .'">'. $name .'</span>'. $infoHtml .'<br>
            </td>
            <td></td>
            <td style="padding: 5px 0;">
                <span style="'. $style .'">'. $price .'</span>
            </td>
        </tr>
        ';
    }

    private function _priceUtil($price) {
        $formattedPrice = PriceUtil::getInstance()->numberTwoDecimals($price);
        $currencySymbol = $this->lineItemsData['currencySymbol'] ?? '';
        $currencyPosition = $this->lineItemsData['currencyPosition'] ?? '';
        if ($currencyPosition === 'BEFORE') {
            return $currencySymbol . $formattedPrice;
        }
        return $formattedPrice . $currencySymbol;
    }

    private function renderCss() {
        ?>
<style>
html, body {
    color: #323232;
    font-family: 'Roboto', sans-serif;
    margin: 0; padding: 0;
    background: #e9ecef
}
.container {
    max-width: 1000px;
    margin: auto;
    padding: 1em;
}
.bg_white {
    background: #FFFFFF;
}
.top {
    display: flex;
    justify-content: end;
}
.hr {
    width: 100%;
    height: 1px;
    background: #CCCCCC;
}
.btn_primary:link {
    padding: .4em 2.2em;
    background: #6d41f1;
    color: #FFFFFF;
    text-decoration: none;
    border-radius: 4px;
}
.btn_primary:visited {
    color: #FFFFFF;
}
.btn_primary:hover {
    color: #FFFFFF;
    background: #6339e3;
}
.btn_primary:active {
    color: #FFFFFF;
}
.mt_10 {
    margin-top: 10px;
}
.mb_10 {
    margin-bottom: 10px;
}
.items {
    margin-bottom: 2em;
}

@media print
{
    .no-print, .no-print *
    {
        display: none !important;
    }
}
</style>
        <?php
    }
}
$pdfHelper = new PDFHelper();
$pdfHelper->render();
?>