<?php
/**
 * Stacked Card integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Stacked_Card extends \Happy_Addons_Pro\Classes\WPML_Module_With_Items {

	/**
	 * Return the repeater index and item in the format expected by WPML.
	 *
	 * @return array
	 */
	public function update( $node_id, $element, \WPML_PB_String $string ) {
		$item = parent::update( $node_id, $element, $string );

		if ( null === $item ) {
			return [ null, null ];
		}

		$index = $item['index'];
		unset( $item['index'] );

		return [ $index, $item ];
	}

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'card_items';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'title',
			'editor',
			'btn_text',
			'btn_link' => [ 'url' ],
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'title':
				return __( 'Stacked Card: Title', 'happy-addons-pro' );
			case 'editor':
				return __( 'Stacked Card: Content', 'happy-addons-pro' );
			case 'btn_text':
				return __( 'Stacked Card: Button Text', 'happy-addons-pro' );
			case 'btn_link':
				return __( 'Stacked Card: Button Link', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'title':
				return 'AREA';
			case 'editor':
				return 'VISUAL';
			case 'btn_text':
				return 'LINE';
			case 'btn_link':
				return 'LINK';
			default:
				return '';
		}
	}
}
