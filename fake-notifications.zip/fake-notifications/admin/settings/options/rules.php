<?php


use HerdEffectsPro\Settings_Helper;

defined( 'ABSPATH' ) || exit;

$show = [
	'general_start' => __( 'General', 'wow-herd-effects-pro' ),
	'everywhere'    => __( 'Everywhere', 'wow-herd-effects-pro' ),
	'shortcode'     => __( 'Shortcode', 'wow-herd-effects-pro' ),
	'general_end'   => __( 'General', 'wow-herd-effects-pro' ),
	'post_start'    => __( 'Posts', 'wow-herd-effects-pro' ),
	'post_all'      => __( 'All posts', 'wow-herd-effects-pro' ),
	'post_selected' => __( 'Selected posts', 'wow-herd-effects-pro' ),
	'post_category' => __( 'Post has category', 'wow-herd-effects-pro' ),
	'post_tag'      => __( 'Post has tag', 'wow-herd-effects-pro' ),
	'post_end'      => __( 'Posts End', 'wow-herd-effects-pro' ),
	'page_start'    => __( 'Pages', 'wow-herd-effects-pro' ),
	'page_all'      => __( 'All pages', 'wow-herd-effects-pro' ),
	'page_selected' => __( 'Selected pages', 'wow-herd-effects-pro' ),
	'page_type'     => __( 'Page type', 'wow-herd-effects-pro' ),
	'page_end'      => __( 'Pages End', 'wow-herd-effects-pro' ),
	'archive_start' => __( 'Archives', 'wow-herd-effects-pro' ),
	'is_archive'    => __( 'All Archives', 'wow-herd-effects-pro' ),
	'is_category'   => __( 'All Categories', 'wow-herd-effects-pro' ),
	'is_tag'        => __( 'All Tags', 'wow-herd-effects-pro' ),
	'is_author'     => __( 'All Authors', 'wow-herd-effects-pro' ),
	'is_date'       => __( 'All Dates', 'wow-herd-effects-pro' ),
	'_is_category'  => __( 'Category', 'wow-herd-effects-pro' ),
	'_is_tag'       => __( 'Tag', 'wow-herd-effects-pro' ),
	'_is_author'    => __( 'Author', 'wow-herd-effects-pro' ),
	'archive_end'   => __( 'Archives End', 'wow-herd-effects-pro' ),

];

$post_types = get_post_types( [ 'public' => true, '_builtin' => false, ], 'objects' );

foreach ( $post_types as $key => $post_type ) {
	$taxonomies = get_object_taxonomies( $post_type->name, 'names' );

	$show[ $key . '_start' ]                = __( 'Custom Post:',
			'wow-herd-effects-pro' ) . ' ' . $post_type->labels->singular_name;
	$show[ 'custom_post_all_' . $key ]      = __( 'All', 'wow-herd-effects-pro' ) . ' ' . $post_type->labels->name;
	$show[ 'custom_post_selected_' . $key ] = __( 'Selected', 'wow-herd-effects-pro' ) . ' ' . $post_type->labels->name;

	if ( ! empty( $taxonomies ) && is_array( $taxonomies ) ) {
		foreach ( $taxonomies as $taxonomy ) {
			$show[ 'custom_post_tax_' . $key . '|' . $taxonomy ] = $post_type->labels->singular_name . ' has ' . $taxonomy;
		}
	}

	$show[ 'custom_post_taxonomy_' . $key ] = $post_type->labels->name . ' ' . __( 'taxonomy', 'wow-herd-effects-pro' );
	if ( $post_type->has_archive ) {
		$show[ 'custom_post_archive_' . $key ] = __( 'Archive', 'wow-herd-effects-pro' ) . ' ' . $post_type->labels->archives;
	}
	$show[ $key . '_end' ] = __( 'Custom Post:', 'wow-herd-effects-pro' ) . ' ' . $post_type->labels->singular_name;
}

$pages_type = [
	'is_front_page' => __( 'Home Page', 'wow-herd-effects-pro' ),
	'is_home'       => __( 'Posts Page', 'wow-herd-effects-pro' ),
	'is_search'     => __( 'Search Pages', 'wow-herd-effects-pro' ),
	'is_404'        => __( '404 Pages', 'wow-herd-effects-pro' ),
];

$operator = [
	'1' => 'is',
	'0' => 'is not',
];

$weekdays = [
	'none' => __( 'Everyday', 'wow-herd-effects-pro' ),
	'1'    => __( 'Monday', 'wow-herd-effects-pro' ),
	'2'    => __( 'Tuesday', 'wow-herd-effects-pro' ),
	'3'    => __( 'Wednesday', 'wow-herd-effects-pro' ),
	'4'    => __( 'Thursday', 'wow-herd-effects-pro' ),
	'5'    => __( 'Friday', 'wow-herd-effects-pro' ),
	'6'    => __( 'Saturday', 'wow-herd-effects-pro' ),
	'7'    => __( 'Sunday', 'wow-herd-effects-pro' ),
];

$args = [
	//region Display Rules
	'show' => [
		'type'  => 'select',
		'title' => __( 'Display', 'wow-herd-effects-pro' ),
		'val'   => 'everywhere',
		'atts'  => $show,
	],

	'operator' => [
		'type'  => 'select',
		'title' => __( 'Match', 'wow-herd-effects-pro' ),
		'atts'  => $operator,
		'val'   => '1',
		'class' => 'is-hidden',
	],

	'ids' => [
		'type'  => 'text',
		'title' => __( 'Enter ID\'s', 'wow-herd-effects-pro' ),
		'atts'  => [
			'placeholder' => __( 'Enter IDs, separated by comma.', 'wow-herd-effects-pro' )
		],
		'class' => 'is-hidden',
	],

	'page_type'      => [
		'type'  => 'select',
		'title' => __( 'Page type', 'wow-herd-effects-pro' ),
		'atts'  => $pages_type,
		'class' => 'is-hidden',
	],

	//endregion

	//region Users
	'users'          => [
		'type'  => 'select',
		'title' => __( 'Users', 'wow-herd-effects-pro' ),
		'atts'  => [
			1 => __( 'All users', 'wow-herd-effects-pro' ),
			2 => __( 'Authorized Users', 'wow-herd-effects-pro' ),
			3 => __( 'Unauthorized Users', 'wow-herd-effects-pro' ),
		],
	],
	//endregion

	//region Other
	'language' => [
		'type'  => 'select',
		'title' => [
			'label'  => __( 'Enable for specific language', 'wow-herd-effects-pro' ),
			'name'   => 'language_on',
			'toggle' => true,
		],
		'val'   => 'en_US',
		'atts'  => Settings_Helper::languages(),
	],

	'fontawesome' => [
		'type'  => 'checkbox',
		'title' => __( 'Disable Font Awesome Icon', 'wow-herd-effects-pro' ),
		'val'   => 0,
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'locale' => [
		'type'  => 'text',
		'title' => __( 'Locale', 'wow-herd-effects-pro' ),
		'val'   => '',
		'atts'  => [
			'placeholder' => 'for example: en_US',
		],
	],

	'geotargeting' => [
		'type'  => 'text',
		'title' => [
			'label'   => __( 'Geotargeting', 'wow-herd-effects-pro' ),
			'name'    => 'geotargeting_on',
			'toggle'  => true,
			'tooltip' => __( 'Country codes separated by comma' ),
		],
		'atts'  => [
			'placeholder' => __( 'Ex: US,CA,GB,UA' )
		],
	],

	'referrer_url' => [
		'type'  => 'text',
		'title' => [
			'label'  => __( 'Referrer URL', 'wow-herd-effects-pro' ),
			'name'   => 'referrer_url_on',
			'toggle' => true,
		],
		'atts' => [
			'placeholder' => 'producthunt.com'
		],
	],

	'content_url' => [
		'type'  => 'text',
		'title' => [
			'label'  => __( 'URL contains', 'wow-herd-effects-pro' ),
			'name'   => 'content_url_on',
			'toggle' => true,
		],
		'atts' => [
			'placeholder' => 'item=activate'
		],
	],
	
	//endregion

	//region Responsive Visibility
	'screen'       => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Hide on smaller screens', 'wow-herd-effects-pro' ),
			'name'   => 'include_mobile',
			'toggle' => true,
		],
		'val'   => 480,
		'addon' => 'px',
	],

	'screen_more' => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Hide on larger screens', 'wow-herd-effects-pro' ),
			'name'   => 'include_more_screen',
			'toggle' => true,
		],
		'val'   => 1024,
		'addon' => 'px'
	],

	'remove_mobile' => [
		'type'  => 'checkbox',
		'title' => __( 'Remove on Mobile', 'wow-herd-effects-pro' ),
		'label' => __( 'Enable', 'wow-herd-effects-pro' ),
	],

	'remove_desktop' => [
		'type'  => 'checkbox',
		'title' => __( 'Remove on Desktop', 'wow-herd-effects-pro' ),
		'label' => __( 'Enable', 'wow-herd-effects-pro' ),
	],
	//endregion

	//region Browsers
	'browser_opera'  => [
		'type'  => 'checkbox',
		'title' => __( 'Opera', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_edge' => [
		'type'  => 'checkbox',
		'title' => __( 'Microsoft Edge', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_chrome' => [
		'type'  => 'checkbox',
		'title' => __( 'Chrome', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_safari' => [
		'type'  => 'checkbox',
		'title' => __( 'Safari', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_firefox' => [
		'type'  => 'checkbox',
		'title' => __( 'Firefox', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_ie' => [
		'type'  => 'checkbox',
		'title' => __( 'Internet Explorer', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	'browser_other' => [
		'type'  => 'checkbox',
		'title' => __( 'Other', 'wow-herd-effects-pro' ),
		'label' => __( 'Disable', 'wow-herd-effects-pro' ),
	],

	//endregion

	//region Schedule
	'weekday'       => [
		'type'  => 'select',
		'title' => __( 'Weekday', 'wow-herd-effects-pro' ),
		'atts'  => $weekdays,
	],

	'time_start' => [
		'type'  => 'time',
		'title' => __( 'Start time', 'wow-herd-effects-pro' ),
	],

	'time_end' => [
		'type'  => 'time',
		'title' => __( 'End time', 'wow-herd-effects-pro' ),
	],

	'dates' => [
		'type'  => 'select',
		'title' => __( 'Define Dates', 'wow-herd-effects-pro' ),
		'atts'  => [
			'disabled' => __( 'Disabled', 'wow-herd-effects-pro' ),
			'enabled'  => __( 'Enabled', 'wow-herd-effects-pro' ),
		],
	],

	'date_start' => [
		'type'  => 'date',
		'title' => __( 'Date From', 'wow-herd-effects-pro' ),
	],

	'date_end' => [
		'type'  => 'date',
		'title' => __( 'Date To', 'wow-herd-effects-pro' ),
	],
	//endregion

];

foreach ( Settings_Helper::user_roles() as $key => $value ) {
	$args[ $key ] = $value;
}

return $args;
