<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

use com\sakuraplugins\appetit\services\ProductSevice;
use com\sakuraplugins\appetit\services\ChoiceGroupsService;
use com\sakuraplugins\appetit\services\CategoriesService;
use com\sakuraplugins\appetit\services\LocalesService;
use com\sakuraplugins\appetit\services\OptionsService;

class DataAggregation {
    private static $instance = null;
    private $data = [];

    public function getAll($json = false) {
        $this->data = [
            'products' => ProductSevice::getInstance()->getAllProducts(),
            'choiceGroups' => ChoiceGroupsService::getInstance()->getGroups(),
            'choices' => ChoiceGroupsService::getInstance()->getAllChoices(),
            'product_categories' => CategoriesService::getInstance()->getCategories(),
            'locales' => LocalesService::getInstance()->getLocales(),
            'options' => OptionsService::getInstance()->getOptions(),
        ];

        if ($json) {
            $json_string = '';
            try {
                $json_string = json_encode($this->data);
            } catch (Exception $e) {}
            return $json_string;
        }
        return $this->data;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new DataAggregation();
        }
        return self::$instance;
    }
}
?>