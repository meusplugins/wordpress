(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

document.querySelectorAll(".custom-select").forEach(customSelect => {
  const selectBtn = customSelect.querySelector(".select-button");
  const selectedValue = customSelect.querySelector(".selected-value");
  const handler = function (elm) {
    const customChangeEvent = new CustomEvent('custom-select-change', {
      detail: {
        selectedOption: elm
      }
    });
    selectedValue.textContent = elm.textContent;
    customSelect.classList.remove("active");
    customSelect.dispatchEvent(customChangeEvent);
  };
  selectBtn.addEventListener("click", () => {
    customSelect.classList.toggle("active");
    selectBtn.setAttribute("aria-expanded", selectBtn.getAttribute("aria-expanded") === "true" ? "false" : "true");
  });
  customSelect.addEventListener('click', function (e) {
    if (e.target.matches('label')) {
      const allItems = customSelect.querySelectorAll('li');
      allItems.forEach(item => item.classList.remove('active'));
      const clickedPlan = e.target.closest('li');
      if (clickedPlan) {
        clickedPlan.classList.add('active');
        handler(clickedPlan);
      }
    }
  });
  document.addEventListener("click", e => {
    if (!customSelect.contains(e.target)) {
      customSelect.classList.remove("active");
      selectBtn.setAttribute("aria-expanded", "false");
    }
  });
});

},{}],2:[function(require,module,exports){
"use strict";

var $ = jQuery;
$(document).ready(function () {
  /**
   * Refresh License data
   */
  var _isRefreshing = false;
  $('#wpr-action-refresh_account').on('click', function (e) {
    if (!_isRefreshing) {
      var button = $(this);
      var account = $('#wpr-account-data');
      var expire = $('#wpr-expiration-data');
      e.preventDefault();
      _isRefreshing = true;
      button.trigger('blur');

      // Start polling if not already running.addClass('wpr-isLoading');
      expire.removeClass('wpr-isValid wpr-isInvalid');
      $.post(ajaxurl, {
        action: 'rocket_refresh_customer_data',
        _ajax_nonce: rocket_ajax_data.nonce
      }, function (response) {
        button.removeClass('wpr-isLoading');
        button.addClass('wpr-isHidden');
        if (true === response.success) {
          account.html(response.data.license_type);
          expire.addClass(response.data.license_class).html(response.data.license_expiration);
          if (response.data.license_expiration_label) {
            document.getElementById('wpr-expiration-label').textContent = response.data.license_expiration_label;
          }
          setTimeout(function () {
            button.removeClass('wpr-icon-refresh wpr-isHidden');
            button.addClass('wpr-icon-check');
          }, 250);
        } else {
          setTimeout(function () {
            button.removeClass('wpr-icon-refresh wpr-isHidden');
            button.addClass('wpr-icon-close');
          }, 250);
        }
        setTimeout(function () {
          var vTL = new TimelineLite({
            onComplete: function () {
              _isRefreshing = false;
            }
          }).set(button, {
            css: {
              className: '+=wpr-isHidden'
            }
          }).set(button, {
            css: {
              className: '-=wpr-icon-check'
            }
          }, 0.25).set(button, {
            css: {
              className: '-=wpr-icon-close'
            }
          }).set(button, {
            css: {
              className: '+=wpr-icon-refresh'
            }
          }, 0.25).set(button, {
            css: {
              className: '-=wpr-isHidden'
            }
          });
        }, 2000);
      });
    }
    return false;
  });

  /**
   * Save Toggle option values on change
   */
  $('.wpr-radio input[type=checkbox]').on('change', function (e) {
    e.preventDefault();
    var name = $(this).attr('id');
    var value = $(this).prop('checked') ? 1 : 0;
    var excluded = ['cloudflare_auto_settings', 'cloudflare_devmode', 'analytics_enabled', 'wpr-rocketcdn-free-toggle', 'wpr-byocdn-toggle', 'wpr-rocketcdn-paid-toggle'];
    if (excluded.indexOf(name) >= 0) {
      return;
    }
    $.post(ajaxurl, {
      action: 'rocket_toggle_option',
      _ajax_nonce: rocket_ajax_data.nonce,
      option: {
        name: name,
        value: value
      }
    }, function (response) {});
  });

  /**
      * Save enable CPCSS for mobiles option.
      */
  $('#wpr-action-rocket_enable_mobile_cpcss').on('click', function (e) {
    e.preventDefault();
    $('#wpr-action-rocket_enable_mobile_cpcss').addClass('wpr-isLoading');
    $.post(ajaxurl, {
      action: 'rocket_enable_mobile_cpcss',
      _ajax_nonce: rocket_ajax_data.nonce
    }, function (response) {
      if (response.success) {
        // Hide Mobile CPCSS btn on success.
        $('#wpr-action-rocket_enable_mobile_cpcss').hide();
        $('.wpr-hide-on-click').hide();
        $('.wpr-show-on-click').show();
        $('#wpr-action-rocket_enable_mobile_cpcss').removeClass('wpr-isLoading');
      }
    });
  });

  /**
   * Save enable Google Fonts Optimization option.
   */
  $('#wpr-action-rocket_enable_google_fonts').on('click', function (e) {
    e.preventDefault();
    $('#wpr-action-rocket_enable_google_fonts').addClass('wpr-isLoading');
    $.post(ajaxurl, {
      action: 'rocket_enable_google_fonts',
      _ajax_nonce: rocket_ajax_data.nonce
    }, function (response) {
      if (response.success) {
        // Hide Mobile CPCSS btn on success.
        $('#wpr-action-rocket_enable_google_fonts').hide();
        $('.wpr-hide-on-click').hide();
        $('.wpr-show-on-click').show();
        $('#wpr-action-rocket_enable_google_fonts').removeClass('wpr-isLoading');
        $('#minify_google_fonts').val(1);
      }
    });
  });
  $('#rocket-dismiss-promotion').on('click', function (e) {
    e.preventDefault();
    $.post(ajaxurl, {
      action: 'rocket_dismiss_promo',
      nonce: rocket_ajax_data.nonce
    }, function (response) {
      if (response.success) {
        $('#rocket-promo-banner').hide('slow');
      }
    });
  });
  $('#rocket-dismiss-renewal').on('click', function (e) {
    e.preventDefault();
    $.post(ajaxurl, {
      action: 'rocket_dismiss_renewal',
      nonce: rocket_ajax_data.nonce
    }, function (response) {
      if (response.success) {
        $('#rocket-renewal-banner').hide('slow');
      }
    });
  });
  $('#wpr-update-exclusion-list').on('click', function (e) {
    e.preventDefault();
    $('#wpr-update-exclusion-msg').html('');
    $.ajax({
      url: rocket_ajax_data.rest_url,
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-WP-Nonce', rocket_ajax_data.rest_nonce);
        xhr.setRequestHeader('Accept', 'application/json, */*;q=0.1');
        xhr.setRequestHeader('Content-Type', 'application/json');
      },
      method: "PUT",
      success: function (responses) {
        let exclusion_msg_container = $('#wpr-update-exclusion-msg');
        exclusion_msg_container.html('');
        if (undefined !== responses['success']) {
          exclusion_msg_container.append('<div class="notice notice-error">' + responses['message'] + '</div>');
          return;
        }
        Object.keys(responses).forEach(response_key => {
          exclusion_msg_container.append('<strong>' + response_key + ': </strong>');
          exclusion_msg_container.append(responses[response_key]['message']);
          exclusion_msg_container.append('<br>');
        });
      }
    });
  });

  /**
   * Enable mobile cache option.
   */
  $('#wpr_enable_mobile_cache').on('click', function (e) {
    e.preventDefault();
    $('#wpr_enable_mobile_cache').addClass('wpr-isLoading');
    $.post(ajaxurl, {
      action: 'rocket_enable_mobile_cache',
      _ajax_nonce: rocket_ajax_data.nonce
    }, function (response) {
      if (response.success) {
        // Hide Mobile cache enable button on success.
        $('#wpr_enable_mobile_cache').hide();
        $('#wpr_mobile_cache_default').hide();
        $('#wpr_mobile_cache_response').show();
        $('#wpr_enable_mobile_cache').removeClass('wpr-isLoading');

        // Set values of mobile cache and separate cache files for mobiles option to 1.
        $('#cache_mobile').val(1);
        $('#do_caching_mobile_files').val(1);
      }
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  const analyticsCheckbox = document.getElementById('analytics_enabled');
  if (analyticsCheckbox) {
    analyticsCheckbox.addEventListener('change', function () {
      const isChecked = this.checked;

      // Update the global mixpanel data optin state immediately
      if (typeof rocket_mixpanel_data !== 'undefined') {
        rocket_mixpanel_data.optin_enabled = isChecked ? '1' : '0';
      }
      fetch(ajaxurl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          action: 'rocket_toggle_optin',
          value: isChecked ? 1 : 0,
          _ajax_nonce: rocket_ajax_data.nonce
        })
      });
    });
  }
});
document.addEventListener('DOMContentLoaded', function () {
  /**
   * Performance Monitoring with Progressive Polling.
   */

  // ==== Configuration ====
  const POLL_BASE_INTERVAL = 2000; // Start polling at 2 seconds
  const POLL_MAX_INTERVAL = 5000; // Max polling interval (5 seconds)

  // ==== State ====
  let rocketInsightsIds = Array.isArray(window.rocket_ajax_data?.rocket_insights_ids) ? window.rocket_ajax_data.rocket_insights_ids.slice() : [];
  let pollInterval = POLL_BASE_INTERVAL;
  let pollTimer = null;
  let hasCredit = true; // Track credit status
  let globalScoreData = {
    data: {
      status: '',
      score: 0,
      pages_num: 0
    },
    html: '',
    row_html: '',
    disabled_btn_html: {
      global_score_widget: '',
      rocket_insights: ''
    }
  };

  // Initialize globalScoreData from localized script data if available
  if (window.rocket_ajax_data?.global_score_data) {
    globalScoreData = window.rocket_ajax_data.global_score_data;
  }

  // ==== DOM Selectors ====
  const $pageUrlInput = $('#wpr-speed-radar-url-input');
  const $tableBody = $('.wpr-ri-urls-table tbody');
  const $table = $('.wpr-ri-urls-table');

  // ==== Utility Functions ====
  function isValidUrl(input) {
    try {
      const url = new URL(input);
      return url.hostname.includes('.') && url.hostname.split('.').pop().length > 0;
    } catch {
      return false;
    }
  }
  function addIds(newId) {
    if (!rocketInsightsIds.includes(newId)) {
      rocketInsightsIds.push(newId);
    }
  }
  function hasId(id) {
    return rocketInsightsIds.includes(id);
  }
  function removeId(id) {
    // Ensure that the id to be removed is an integer for accurate comparison.
    const idToRemove = parseInt(id, 10);
    rocketInsightsIds = rocketInsightsIds.filter(x => parseInt(x, 10) !== idToRemove);
  }
  function updateQuotaBanner(canAddPages) {
    const $summaryInfo = $('.wpr-ri-summary-info');
    const isFree = window.rocket_ajax_data?.is_free === '1';
    const $quotaBanner = isFree ? $('#wpr-ri-quota-banner') : $('#rocket_insights_survey');

    // Show banner if URL limit reached OR no credits left (matching PHP logic in Subscriber.php line 398).
    const shouldShowBanner = canAddPages === false || !hasCredit;
    if (shouldShowBanner) {
      $summaryInfo.hide();
      $quotaBanner.removeClass('hidden');
    } else {
      $summaryInfo.show();
      $quotaBanner.addClass('hidden');
    }
  }
  function updateCreditState(responseHasCredit) {
    if (responseHasCredit !== undefined && hasCredit !== responseHasCredit) {
      hasCredit = responseHasCredit;

      // Update all retest buttons when credit status changes
      updateAllRetestButtons();
    }
  }
  function updateAllRetestButtons() {
    const retestButtons = document.querySelectorAll('.wpr-action-speed_radar_refresh');
    retestButtons.forEach(button => {
      const row = button.closest('.wpr-ri-item');
      if (!row) return;

      // Get the row ID and check if it's currently being processed
      const rowId = parseInt(row.dataset.rocketInsightsId, 10);
      const isRunning = rocketInsightsIds.includes(rowId);
      if (!hasCredit || isRunning) {
        // Disable button
        button.classList.add('wpr-ri-action--disabled');
        button.setAttribute('disabled', 'true');
        if (!hasCredit) {
          // Add tooltip for no credit
          button.classList.add('wpr-btn-with-tool-tip');
          button.setAttribute('title', window.rocket_ajax_data?.rocket_insights_no_credit_tooltip || 'Upgrade your plan to get access to re-test performance or run new tests');
        }
      } else {
        // Enable button
        button.classList.remove('wpr-ri-action--disabled', 'wpr-btn-with-tool-tip');
        button.removeAttribute('disabled');
        button.removeAttribute('title');
      }
    });
  }
  function resetPolling() {
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
    }
    pollInterval = POLL_BASE_INTERVAL;
  }
  function schedulePolling() {
    if (rocketInsightsIds.length > 0) {
      pollTimer = setTimeout(() => {
        getResults();
      }, pollInterval);
    }
  }
  function incrementPolling() {
    pollInterval = Math.min(pollInterval * 1.3, POLL_MAX_INTERVAL); // Exponential backoff
  }
  function isOnDashboard() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('page') === 'wprocket' && window.location.hash === '#dashboard';
  }
  function isOnRocketInsights() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('page') === 'wprocket' && window.location.hash === '#rocket_insights';
  }
  function updateGlobalScoreRow(globalScoreData) {
    const $tableGlobalScore = $('.wpr-ri-urls-table .wpr-global-score');
    if ($tableGlobalScore.length > 0) {
      $tableGlobalScore.replaceWith(globalScoreData.row_html);
    } else if ($tableBody.length > 0) {
      $tableBody.prepend(globalScoreData.row_html);
    }
    decideGlobalScoreToUpdate();
  }

  /**
   * Updates the global score UI widget or table row based on the selected menu.
   * When the dashboard or rocket insights menu is clicked, this function updates
   * the corresponding global score display after a short delay.
   */
  function decideGlobalScoreToUpdate() {
    if ('' === globalScoreData.html) {
      return;
    }
    let globalScoreWidgets = $('.wpr-global-score-widget');
    if (globalScoreWidgets.length === 0) {
      return;
    }

    // Update all global score widget instances.
    globalScoreWidgets.html(globalScoreData.html);

    // Disable "Add Pages" button on global score widget.
    if (!('disabled_btn_html' in globalScoreData)) {
      return;
    }
    $('.wpr-global-score-widget .wpr-global-score-widget-btn-wrapper').html(globalScoreData.disabled_btn_html.global_score_widget);
  }

  // ==== AJAX Handlers ====
  function getResults() {
    if (rocketInsightsIds.length === 0) {
      resetPolling();
      return;
    }
    window.wp.apiFetch({
      path: window.wp.url.addQueryArgs('/wp-rocket/v1/rocket-insights/pages/progress', {
        ids: rocketInsightsIds
      })
    }).then(response => {
      if (response.success && Array.isArray(response.results)) {
        // Update credit status
        updateCreditState(response.has_credit);

        // Update quota banner visibility
        updateQuotaBanner(response.can_add_pages);

        // Update global score data and widget when status || page count changes.
        if (globalScoreData.data.status !== response.global_score_data.data.status || globalScoreData.data.pages_num !== response.global_score_data.data.pages_num) {
          // Update global score data.
          globalScoreData = response.global_score_data;

          // Update all global score widget instances.
          $('.wpr-global-score-widget').html(response.global_score_data.html);
          // Update global score row in table if on Rocket Insights page.
          updateGlobalScoreRow(globalScoreData);

          // Fire custom event for other widgets (like recommendations)
          document.dispatchEvent(new CustomEvent('wprGlobalScoreUpdated', {
            detail: globalScoreData.data
          }));
        }
        response.results.forEach(result => {
          const $row = $(`.wpr-ri-item[data-rocket-insights-id="${result.id}"]`);
          $row.replaceWith(result.html);
          $(document).trigger('rocket-insights-page-test-polling', [result.id]);

          // Trigger custom event only when test is completed and not failed, so we don't target an element that might be removed from the DOM after test completion.
          if (result.status === 'completed') {
            $(document).trigger('rocket-insights-page-test-completed', [result.id]);
          }
          if (result.status === 'completed' || result.status === 'failed') {
            removeId(result.id);
          }
        });
        incrementPolling();
        schedulePolling();
      } else {
        // On error, clear IDs and stop polling
        rocketInsightsIds = [];
        resetPolling();
        console.error('Polling error:', response.results || response);
      }
    });
  }
  function handleAddPage(e) {
    e.preventDefault();

    // check if has attr disabled
    if ($(this).attr('disabled')) {
      return;
    }
    const pageUrl = $pageUrlInput.val().trim();
    if (!isValidUrl(pageUrl)) {
      alert('Please enter a valid URL');
      return;
    }
    const source = $(this).data('source');
    window.wp.apiFetch({
      path: '/wp-rocket/v1/rocket-insights/pages/',
      method: 'POST',
      data: {
        page_url: pageUrl,
        source: source
      }
    }).then(response => {
      if (response.success) {
        if (!hasId(response.id)) {
          $pageUrlInput.val('');
          $tableBody.append(response.html);

          // Custom event when new page is added.
          $(document).trigger('rocket-insights-page-added');
          $table.removeClass('hidden');
          addIds(response.id);
          let pages_num_container = $('#rocket_rocket_insights_pages_num');
          pages_num_container.text(parseInt(pages_num_container.text()) + 1);

          // Update credit status
          updateCreditState(response.has_credit);

          // Update global score data.
          globalScoreData = response.global_score_data;

          // Update global score row in table if on Rocket Insights page.
          updateGlobalScoreRow(globalScoreData);
          if ('disabled_btn_html' in globalScoreData) {
            $('#wpr_rocket_insights_add_page_btn_wrapper').html(globalScoreData.disabled_btn_html.rocket_insights);
          }

          // Show/hide quota banner based on can_add_pages
          updateQuotaBanner(response.can_add_pages);
          if (pollTimer) {
            resetPolling();
          }
          schedulePolling();
        }
      } else {
        // Clear the input field on error
        $pageUrlInput.val('');

        // Handle URL limit reached error
        if (response?.message && response.message.includes('Maximum number of URLs reached')) {
          // Update UI state to reflect URL limit has been reached
          disableAddUrlElements();
          // Show quota banner (can_add_pages = false)
          updateQuotaBanner(response.can_add_pages !== undefined ? response.can_add_pages : false);
        }
        console.error(response?.message || response);
      }
    });
  }
  function handleResetPage(e) {
    e.preventDefault();
    const $button = $(this);
    let id = $button.parents('.wpr-ri-item').data('rocket-insights-id');
    if (!id) {
      return;
    }
    const source = $button.data('source');
    window.wp.apiFetch({
      path: '/wp-rocket/v1/rocket-insights/pages/' + id,
      method: 'PATCH',
      data: {
        source: source
      }
    }).then(response => {
      if (response.success) {
        addIds(response.id);
        $(`#ri_details_${response.id} .details-section-td`).remove();
        const $row = $(`[data-rocket-insights-id="${response.id}"]`);
        $row.replaceWith(response.html);

        // Custom event when page is retested.
        $(document).trigger('rocket-insights-page-retest', [response.id]);

        // Update credit status
        updateCreditState(response.has_credit);

        // Update quota banner visibility
        updateQuotaBanner(response.can_add_pages);

        // Update global score data.
        globalScoreData = response.global_score_data;

        // Update global score row in table if on Rocket Insights page.
        updateGlobalScoreRow(globalScoreData);
        if (pollTimer) {
          resetPolling();
        }
        schedulePolling();
      } else {
        console.error(response?.message || response);
      }
    });
  }

  // ==== Initialization ====
  // Bind event
  $(document).on('click', '#wpr-action-add_page_speed_radar', handleAddPage);
  $(document).on('click', '.wpr-action-speed_radar_refresh', handleResetPage);
  // Handle Enter key press on page url input.
  $(document).on('keypress', '#wpr-speed-radar-url-input', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      $('#wpr-action-add_page_speed_radar').click();
    }
  });

  // Only poll if on a wpr section that requires polling(dashboard|rocket_insights) (more robust check)
  function isValidPageForPolling() {
    const urlParams = new URLSearchParams(window.location.search);
    return 'wprocket' === urlParams.get('page');
  }

  // Resume polling if needed
  if (isValidPageForPolling() && rocketInsightsIds.length > 0) {
    if (pollTimer) {
      resetPolling();
    }
    schedulePolling();
  }

  // Handle UI update on the rocket insights tab when "Add Pages" button on the global score widget is clicked.
  $(document).on('click', '.wpr-percentage-score-widget .wpr-ri-add-url-button', function () {
    if (!this.textContent.includes('Add Pages')) {
      return;
    }

    // Delay UI update a bit till element is visible.
    setTimeout(() => {
      updateGlobalScoreRow(globalScoreData);
    }, 30);
  });

  // Handle collapseed styling for first load or dynamic row addition.
  function addCollapsedStylingToLastRow(onLoad = false) {
    $('.wpr-ri-item').last().find('td').addClass('border-bottom');
    if (onLoad) {
      // On load, remove wpr-last-expanded from elements that are not the last after being added from backend.
      $('.wpr-ri-item-toggle').not(':last').removeClass('wpr-last-expanded');
      $('.wpr-ri-item-actions').not(':last').removeClass('wpr-last-expanded');
      $('.details-section-td').not(':last').removeClass('wpr-last-expanded');

      // Bail early if last item is already expanded on load so as not to have conflicting styles.
      if ($('.details-section-td').last().hasClass('wpr-last-expanded')) {
        return;
      }
    }
    $('.wpr-ri-item-toggle').last().addClass('wpr-last-collapsed');
    $('.wpr-ri-item-actions').last().addClass('wpr-last-collapsed');
    $('.details-section-td').last().addClass('wpr-last-collapsed');
  }

  // Toggles the visibility of a single test details row, switches the caret icon, and updates styling for the last item.
  function toggleSingleRowVisibility(insightsId, source) {
    let $element = $(`#ri_details_${insightsId}`);
    let isVisible = $element.hasClass('wpr-ri-details--expanded');
    let isLast = $(`[data-rocket-insights-id="${insightsId}"] .wpr-ri-item-toggle-single`).is($('.wpr-ri-item-toggle-single').last());
    if (isVisible) {
      $element.removeClass('wpr-ri-details--expanded');
      $(`[data-rocket-insights-id="${insightsId}"]`).removeClass('wpr-ri-item--expanded');
      // Manipulate styling for last elements when details cell is not visible.
      if (isLast) {
        updateRowStylingForLastItem(false);
      }
      return;
    }
    $element.addClass('wpr-ri-details--expanded');
    $(`[data-rocket-insights-id="${insightsId}"]`).addClass('wpr-ri-item--expanded');

    // Track expand only expand metric action.
    handleMetricActionTracking('expand', insightsId, source);
    if (isLast) {
      updateRowStylingForLastItem();
    }
  }

  // Tracks user interactions with metric actions in Rocket Insights via AJAX.
  function handleMetricActionTracking(event, rowId, source) {
    $.post(ajaxurl, {
      action: 'rocket_insight_track_metric_actions',
      _ajax_nonce: rocket_ajax_data.nonce,
      event: event,
      row_id: rowId,
      source: source
    }, function (response) {
      if (!response.success) {
        console.error('Metric action tracking failed:', response?.data || response);
      }
    });
  }

  /**
   * Updates the border styling for the last row item in the Rocket Insights table.
   *
   * Manages border radius and bottom border styling based on whether the details
   * cell is expanded or collapsed to maintain proper visual appearance.
   */
  function updateRowStylingForLastItem(isExpanded = true) {
    const addState = isExpanded ? 'wpr-last-expanded' : 'wpr-last-collapsed';
    const removeState = isExpanded ? 'wpr-last-collapsed' : 'wpr-last-expanded';
    var $selectors = {
      lastToggle: $('.wpr-ri-item-toggle').last(),
      lastActions: $('.wpr-ri-item-actions').last()
    };
    $selectors.lastToggle.removeClass(removeState).addClass(addState);
    $selectors.lastActions.removeClass(removeState).addClass(addState);

    // Check if last detail row is not the last row in the table so as not to apply improper styling with border radius between rows.
    var $lastDetailsCell = $('.details-section-td').last();
    if ($lastDetailsCell.closest('tr').next('tr').length !== 0) {
      return;
    }
    $lastDetailsCell.removeClass(removeState).addClass(addState);
  }

  // Toggle single item.
  $(document).on('click', '.wpr-ri-item-toggle-single', function () {
    var insightsId = $(this).closest('.wpr-ri-item').data('rocket-insights-id');
    toggleSingleRowVisibility(insightsId, 'url_expand');
  });

  // Toggle all items.
  $(document).on('click', '.wpr-ri-item-toggle-all', function () {
    if ($('.wpr-ri-details--expanded').length > 0) {
      $('.wpr-ri-details').removeClass('wpr-ri-details--expanded');
      $('.wpr-ri-item').removeClass('wpr-ri-item--expanded');
      $(this).removeClass('wpr-ri-item-toggle-all--expanded');
      updateRowStylingForLastItem(false);
      return;
    }
    $('.wpr-ri-details').addClass('wpr-ri-details--expanded');
    $('.wpr-ri-item').addClass('wpr-ri-item--expanded');
    $(this).addClass('wpr-ri-item-toggle-all--expanded');
    updateRowStylingForLastItem();

    // Track single expand event for "Expand All" action with test_id as 'all'.
    handleMetricActionTracking('expand', 'all', 'global_expand');
  });

  // Track "See GTmetrix Report" clicks in Rocket Insights.
  $(document).on('click', '.wpr-ri-report', function (e) {
    // Only track if link is not disabled and mixpanel is available.
    if ($(this).hasClass('wpr-ri-action--disabled')) {
      return;
    }
    var insightsId = $(this).data('rocket-insights-row-id');
    handleMetricActionTracking('see_report', insightsId, 'see_report_button');
  });

  // Update table styling after new page is added.
  $(document).on('rocket-insights-page-test-completed', function (e, insightsId) {
    // Bail out if there is more than 1 result.
    if ($('.wpr-ri-item-result').length > 1) {
      return;
    }

    // Remove dynamic class when only one item exist in table.
    $('.wpr-last-collapsed').removeClass('wpr-last-collapsed');
  });

  // Update table styling after new page is added.
  $(document).on('rocket-insights-page-added', function (e) {
    // Remove dynamic class for last item if exists when new page is added.
    $('.wpr-last-collapsed').removeClass('wpr-last-collapsed');
    $('.wpr-last-expanded').removeClass('wpr-last-expanded');
    $('.border-bottom').removeClass('border-bottom');
  });

  // Update table styling after retest or polling update for last row.
  $(document).on('rocket-insights-page-retest rocket-insights-page-test-polling', function (e, insightsId) {
    // Check if item is the last.
    var isLast = $(`[data-rocket-insights-id="${insightsId}"]`).is($('.wpr-ri-item-result').last());
    if (isLast) {
      addCollapsedStylingToLastRow();
    }
  });
  $(document).on('rocket-insights-page-retest', function (e, insightsId) {
    $(`#ri_details_${insightsId}`).removeClass('wpr-ri-details--expanded');
    $(`[data-rocket-insights-id="${insightsId}"]`).removeClass('wpr-ri-item--expanded');
  });
  $(window).load(() => {
    if (!isOnRocketInsights()) {
      return;
    }

    // Add collapsed styling to the last row on initial load.
    addCollapsedStylingToLastRow(true);

    // Set initial expand/collapse state.
    const urlParams = new URLSearchParams(window.location.search);
    const testId = urlParams.get('ri_id');

    // Send mixpanel event for auto expanded row.
    let firstRowId = $('.wpr-ri-item--expanded')?.first()?.data('rocket-insights-id');

    // Check if ri_id was passed in query string to open specific test.
    if (!testId || testId === '') {
      if (firstRowId) {
        handleMetricActionTracking('expand', firstRowId, 'auto_expand_url');
      }
      return;
    }
    handleMetricActionTracking('expand', testId, 'post type listing');
    $('html, body').animate({
      scrollTop: $(`[data-rocket-insights-id="${testId}"]`).offset().top - 100
    }, 500);

    // Remove ri_id from URL without page reload
    urlParams.delete('ri_id');
    const newUrl = window.location.pathname + '?' + urlParams.toString() + window.location.hash;
    window.history.replaceState({}, '', newUrl);
  });
});

},{}],3:[function(require,module,exports){
"use strict";

require("../lib/greensock/TweenLite.min.js");
require("../lib/greensock/TimelineLite.min.js");
require("../lib/greensock/easing/EasePack.min.js");
require("../lib/greensock/plugins/CSSPlugin.min.js");
require("../lib/greensock/plugins/ScrollToPlugin.min.js");
require("../global/cdn-driver.js");
require("../global/pageManager.js");
require("../global/main.js");
require("../global/fields.js");
require("../global/beacon.js");
require("../global/ajax.js");
require("../global/recommendations-widget.js");
require("../global/rocketcdn.js");
require("../global/rocketcdn-subscription-polling.js");
require("../global/countdown.js");
require("../global/mixpanel.js");

},{"../global/ajax.js":2,"../global/beacon.js":4,"../global/cdn-driver.js":5,"../global/countdown.js":6,"../global/fields.js":7,"../global/main.js":8,"../global/mixpanel.js":9,"../global/pageManager.js":10,"../global/recommendations-widget.js":11,"../global/rocketcdn-subscription-polling.js":12,"../global/rocketcdn.js":13,"../lib/greensock/TimelineLite.min.js":14,"../lib/greensock/TweenLite.min.js":15,"../lib/greensock/easing/EasePack.min.js":16,"../lib/greensock/plugins/CSSPlugin.min.js":17,"../lib/greensock/plugins/ScrollToPlugin.min.js":18}],4:[function(require,module,exports){
"use strict";

var $ = jQuery;
$(document).ready(function () {
  if ('Beacon' in window) {
    /**
     * Show beacons on button "help" click
     */
    var $help = $('.wpr-infoAction--help');
    $help.on('click', function (e) {
      var ids = $(this).attr('data-beacon-id');
      var button = $(this).data('wpr_track_button') || 'Beacon Help';
      var context = $(this).data('wpr_track_context') || 'Settings';

      // Track with MixPanel JS SDK
      wprTrackHelpButton(button, context);

      // Continue with existing beacon functionality
      wprCallBeacon(ids);
      return false;
    });
    function wprCallBeacon(aID) {
      aID = aID.split(',');
      if (aID.length === 0) {
        return;
      }
      if (aID.length > 1) {
        window.Beacon("suggest", aID);
        setTimeout(function () {
          window.Beacon("open");
        }, 200);
      } else {
        window.Beacon("article", aID.toString());
      }
    }
  }
  $('.wpr-ri-report').on('click', function () {
    wprTrackHelpButton('rocket insights see gtmetrix report', 'performance summary');
  });

  // MixPanel tracking function
  function wprTrackHelpButton(button, context) {
    if (typeof mixpanel !== 'undefined' && mixpanel.track) {
      // Check if user has opted in using localized data
      if (typeof rocket_mixpanel_data === 'undefined' || !rocket_mixpanel_data.optin_enabled || rocket_mixpanel_data.optin_enabled === '0') {
        return;
      }

      // Identify user with hashed license email if available
      if (rocket_mixpanel_data.user_id && typeof mixpanel.identify === 'function') {
        mixpanel.identify(rocket_mixpanel_data.user_id);
      }
      mixpanel.track('Button Clicked', {
        'button': button,
        'button_context': context,
        'plugin': rocket_mixpanel_data.plugin,
        'brand': rocket_mixpanel_data.brand,
        'application': rocket_mixpanel_data.app,
        'context': rocket_mixpanel_data.context,
        'path': rocket_mixpanel_data.path,
        'interaction_channel': 'UI'
      });
    }
  }

  // Make function globally available
  window.wprTrackHelpButton = wprTrackHelpButton;
});

},{}],5:[function(require,module,exports){
"use strict";

(document => {
  'use strict';

  function notifyCdnStateChange() {
    document.dispatchEvent(new CustomEvent('wpr-cdn-state-change'));
  }

  /**
   * Keeps the hidden cdn_type and cdn_state form inputs in sync after a REST-driven
   * mode change so a subsequent form save doesn't send stale values and trigger
   * CdnStateBridge::reconcile() to recompute the wrong state.
   *
   * Mirrors the mapping in Rest::apply_cdn_mode():
   *   byocdn → cdn_type=byocdn; everything else → cdn_type=rocketcdn.
   *
   * @param {string} mode New cdn_state value ('rocketcdn_free', 'byocdn', 'nothing', etc.).
   */
  function syncCdnHiddenInputs(mode) {
    const stateInput = document.getElementById('cdn_state');
    if (stateInput) {
      stateInput.value = mode;
    }
    const typeInput = document.getElementById('cdn_type');
    if (typeInput) {
      typeInput.value = 'byocdn' === mode ? 'byocdn' : 'rocketcdn';
    }
    const cdnInput = document.querySelector('input[type="hidden"][name="wp_rocket_settings[cdn]"]');
    if (cdnInput) {
      cdnInput.value = 'nothing' === mode ? '0' : '1';
    }
  }
  document.addEventListener('DOMContentLoaded', () => {
    initCdnDriverTabs();
    initCdnModeToggle();
    initAddHomepage();
    initAddPage();
    initDeletePage();
    updateSubmitButtonStateOnSubscriptionLoading();
  });
  const addHomeButton = document.querySelector('#wpr_add_page_component .wpr-cdn-add-page__homepage');

  /**
   * Updates the status indicator component with new HTML content.
   *
   * The paid tier's indicator carries the same `.rocketcdn` class its section
   * header uses, since it has no separate content wrapper of its own - see
   * add_rocketcdn_paid_section() in Controller.php. That's what lets
   * toggleDriverSections() hide it while "Other CDN" is the active tab, by
   * toggling `wpr-isHidden` directly on it. The server-rendered replacement
   * markup has no notion of that client-only tab state, so a plain outerHTML
   * swap would drop the class and make it pop up outside its tab - carry it
   * over explicitly when present.
   *
   * @param {string} html - The HTML string to replace the status indicator with.
   * @returns {void}
   */
  function updateStatusIndicatorComponent(html) {
    // #wpr_cdn_status_indicator is shared by the free, paid AND "Your CDN" (BYOCDN)
    // templates - the free tier additionally wraps it in .wpr-cdn-built-in, the paid
    // tier does not, and both tab panels stay in the DOM at once (one merely hidden),
    // so a plain getElementById() can silently grab the BYOCDN copy instead and inject
    // RocketCDN's message into the "Other CDN" tab. Explicitly skip any match under
    // .your-own-cdn - see updateByocdnStatusIndicator(), which excludes RocketCDN's
    // copy the same way in reverse.
    const statusIndicator = Array.from(document.querySelectorAll('#wpr_cdn_status_indicator')).find(el => !el.closest('.your-own-cdn'));
    if (!statusIndicator) {
      if (html) {
        // Re-insert when the element was removed (e.g. count dropped back to 0 after
        // all pages were deleted, and the indicator was removed when count first hit 1).
        const addPageSection = document.querySelector('.wpr-cdn-built-in .wpr-cdn-add-page');
        if (addPageSection) {
          addPageSection.insertAdjacentHTML('beforebegin', html);
        }
      }
      return;
    }
    if (!html) {
      statusIndicator.remove();
      return;
    }
    const wasHidden = statusIndicator.classList.contains('wpr-isHidden');
    statusIndicator.outerHTML = html;
    if (wasHidden) {
      // Same duplicate-id caveat as above - re-run the same exclusion instead of
      // getElementById(), which would return the "Your CDN" copy if it precedes
      // this one in document order.
      const refreshed = Array.from(document.querySelectorAll('#wpr_cdn_status_indicator')).find(el => !el.closest('.your-own-cdn'));
      if (refreshed) {
        refreshed.classList.add('wpr-isHidden');
      }
    }
  }

  /**
   * Updates the "Other CDN" (BYOCDN) status indicator with new HTML content.
   *
   * Scoped to the "Your CDN" section container rather than the shared
   * #wpr_cdn_status_indicator id, since that id can also be present (hidden)
   * in the RocketCDN section markup at the same time - a global lookup would
   * risk updating the wrong one. Unlike RocketCDN's indicator, an empty
   * `html` here means "no status message at all", so the element is removed
   * rather than left untouched - along with its adjacent separator, which
   * the initial PHP render (your-own-cdn.php) only draws while the message
   * is showing.
   *
   * @param {string} html - The status indicator HTML to show, or an empty string to show none.
   * @returns {void}
   */
  function updateByocdnStatusIndicator(html) {
    const container = document.querySelector('.wpr-fieldsContainer-fieldset.your-own-cdn');
    if (!container) {
      return;
    }
    const existing = container.querySelector('#wpr_cdn_status_indicator');
    const separator = container.querySelector('.wpr-cdn-built-in__separator');
    if (existing) {
      if (html) {
        existing.outerHTML = html;
      } else {
        existing.remove();
      }
    } else if (html) {
      container.insertAdjacentHTML('afterbegin', html);
    }
    if (!html) {
      if (separator) {
        separator.remove();
      }
      return;
    }
    if (!separator) {
      const indicator = container.querySelector('#wpr_cdn_status_indicator');
      if (indicator) {
        indicator.insertAdjacentHTML('afterend', '<div class="wpr-cdn-built-in__separator"></div>');
      }
    }
  }

  /**
   * Toggles the disabled state of CDN-related UI elements based on the active driver.
   *
   * For the 'rocketcdn' driver, targets both shared CDN and RocketCDN sections.
   * For all other drivers, only targets the shared CDN section and always enables it.
   *
   * @param {string}  driver   The CDN driver identifier (e.g. 'rocketcdn').
   * @param {boolean} disabled Whether to disable the CDN UI elements.
   */
  function updateRocketCDNElementsState(driver, disabled) {
    if ('rocketcdn' === driver) {
      if (!disabled) {
        document.querySelectorAll('.cdn-shared-section, .rocketcdn-shared-section').forEach(el => {
          el.classList.remove('wpr-cdn-disabled');
        });
        return;
      }
      document.querySelectorAll('.cdn-shared-section, .rocketcdn-shared-section').forEach(el => {
        el.classList.add('wpr-cdn-disabled');
      });
      return;
    }
    document.querySelectorAll('.cdn-shared-section').forEach(el => {
      el.classList.remove('wpr-cdn-disabled');
    });
  }

  /**
   * Shows or hides the limit-reached tooltip on the ADD PAGE button.
   *
   * @param {boolean} limitReached Whether the free-tier page limit has been reached.
   * @returns {void}
   */
  function updateTooltipState(limitReached) {
    const tooltip = document.querySelector('.wpr-cdn-add-page__button-wrapper .wpr-tooltip');
    if (tooltip) {
      tooltip.classList.toggle('wpr-isHidden', !limitReached);
    }
  }

  /** Pending banner auto-expand timer ID, or null when no timer is active. */
  let autoExpandTimer = null;

  /**
   * Updates the RocketCDN CTA visibility and expansion state.
   *
   * When the page count reaches the limit, expansion is deferred by 15 seconds so the
   * user has time to react before the upsell banner opens. Any in-flight timer is
   * cancelled whenever this function is called (e.g. on page deletion), ensuring stale
   * expands never fire after the state has changed.
   *
   * @param {number} count Current number of free-tier pages.
   * @param {number} limit Free-tier page limit.
   * @returns {void}
   */
  function updateRocketCtaState(count, limit) {
    const cta = document.getElementById('wpr-rocketcdn-cta');
    const resellerBanner = document.getElementById('wpr-rocketcdn-reseller-limit-cta');
    if (!cta && !resellerBanner) {
      return;
    }

    // Cancel any pending expand — state has changed.
    if (autoExpandTimer !== null) {
      clearTimeout(autoExpandTimer);
      autoExpandTimer = null;
    }
    const atLimit = count >= limit;
    if (cta) {
      cta.classList.toggle('wpr-isHidden', count === 0);
    }
    if (resellerBanner) {
      resellerBanner.classList.toggle('wpr-isHidden', !atLimit);
    }
    if (cta) {
      if (atLimit) {
        // Always show "Nice work!" text immediately.
        cta.classList.add('wpr-rocketcdn-cta---max-limit');
        if (!cta.classList.contains('wpr-rocketcdn-cta--expanded')) {
          // Banner is collapsed — keep it collapsed for 15s then expand.
          cta.classList.add('wpr-rocketcdn-cta--collapsed');
          cta.classList.remove('wpr-rocketcdn-cta--expanded');
          autoExpandTimer = setTimeout(() => {
            autoExpandTimer = null;
            cta.classList.remove('wpr-rocketcdn-cta--collapsed');
            cta.classList.add('wpr-rocketcdn-cta--expanded');
            document.dispatchEvent(new CustomEvent('rocketCDNBannerAutoExpanded'));
          }, 15000);
        }
      } else {
        cta.classList.toggle('wpr-rocketcdn-cta--collapsed', count > 0);
        cta.classList.remove('wpr-rocketcdn-cta--expanded', 'wpr-rocketcdn-cta---max-limit');
      }
    }
  }

  // Cancel any pending banner expand when the user navigates away from the CDN tab.
  document.addEventListener('rocketJsAfterPageNavigation', e => {
    if (e.detail.pageId !== 'page_cdn' && autoExpandTimer !== null) {
      clearTimeout(autoExpandTimer);
      autoExpandTimer = null;
    }
  });

  /**
   * Listens for custom 'rocketJsAfterPageNavigation' event to update the state of the submit button
   * based on the presence of a CDN subscription loading indicator on the CDN settings page.
   *
   * Disables the submit button when navigating to the CDN page if a subscription loading indicator is present,
   * and re-enables it when navigating away from the CDN page.
   */
  function updateSubmitButtonStateOnSubscriptionLoading() {
    document.addEventListener('rocketJsAfterPageNavigation', e => {
      // Bail out if submit button is not visible for the current page.
      if (getComputedStyle(e.detail.submitButton).display === 'none') {
        return;
      }
      const classes = ['.wpr-icon-orange-loader', '.wpr-cdn-built-in--disabled'];
      const allPresent = classes.every(cls => document.querySelector(cls) !== null);

      // Re-enable submit button when page is not cdn and bail out.
      if (e.detail.pageId !== 'page_cdn') {
        if (e.detail.submitButton.classList.contains('wpr-cdn-disabled')) {
          e.detail.submitButton.classList.remove('wpr-cdn-disabled');
        }
        return;
      }

      // Bail out if no cdn subscription loader is present.
      if (!allPresent) {
        return;
      }

      // Disable submit button when on cdn page and subscription loader is present.
      e.detail.submitButton.classList.add('wpr-cdn-disabled');
    });
  }
  function setSubscriptionLoadingState() {
    const builtIn = document.querySelector('.wpr-cdn-built-in');
    if (builtIn) {
      builtIn.classList.add('wpr-cdn-built-in--disabled');
    }

    // Disable purge CDN cache section.
    const purgeSection = document.querySelector('.wpr-cdn-purge.rocketcdn');
    if (purgeSection) {
      purgeSection.classList.add('wpr-cdn-disabled');
    }

    // Disable exclusion fields and section header.
    document.querySelectorAll('.wpr-cdn-exclusions').forEach(el => {
      el.classList.add('wpr-cdn-disabled');
      const textarea = el.querySelector('textarea');
      if (textarea) {
        textarea.disabled = true;
      }
    });
    const submitButton = document.querySelector('#wpr-options-submit');
    if (submitButton) {
      submitButton.classList.add('wpr-cdn-disabled');
    }

    // Disable mode toggles to prevent state changes during subscription creation.
    document.querySelectorAll('.wpr-cdn-mode-toggle__input').forEach(modeToggle => {
      modeToggle.disabled = true;
    });

    // Create polling mechanism to send a request every 10 seconds to get the subscription status and once the subscription is active, we will refresh the page for now.
    document.dispatchEvent(new CustomEvent('rocketCDNSubscriptionLoading', {}));
  }

  /**
   * Updates the `wpr-cdn-active-indicator` class to reflect which CDN driver header
   * and tab are active.
   *
   * @param {Element|null} activeToggle Toggle whose parent header and matching tab should
   *                                    receive the class, or null to clear all.
   */
  function updateCdnActiveIndicator(activeToggle) {
    document.querySelectorAll('.wpr-cdn-active-indicator').forEach(el => {
      el.classList.remove('wpr-cdn-active-indicator');
    });
    if (activeToggle) {
      const header = activeToggle.closest('.wpr-optionHeader');
      if (header) {
        header.classList.add('wpr-cdn-active-indicator');
      }
      const mode = activeToggle.getAttribute('data-cdn-mode');
      const tabDriver = 'byocdn' === mode ? 'your-own-cdn' : 'rocketcdn';
      const tab = document.querySelector(`.wpr-cdn-tabs__tab[data-cdn-driver="${tabDriver}"]`);
      if (tab) {
        tab.classList.add('wpr-cdn-active-indicator');
      }
    }
  }

  /**
   * Updates the toggle checkboxes and active indicators to reflect RocketCDN Free
   * having just been activated server-side (auto-activation from the "nothing active"
   * state, or after a confirmed activation prompt), without a full page reload.
   */
  function activateFreeModeUI() {
    const freeToggle = document.querySelector('.wpr-cdn-mode-toggle__input[data-cdn-mode="rocketcdn_free"]');
    if (!freeToggle) {
      return;
    }
    document.querySelectorAll('.wpr-cdn-mode-toggle__input').forEach(other => {
      other.checked = other === freeToggle;
    });
    updateCdnActiveIndicator(freeToggle);
    toggleDriverSections('rocketcdn');
    setActiveTab('rocketcdn');
    notifyCdnStateChange();
    syncCdnHiddenInputs('rocketcdn_free');
  }

  /**
   * Initializes the CDN mode toggle checkboxes.
   *
   * Checking activates that mode; unchecking leaves all modes inactive ('nothing').
   * Only one mode can be active at a time — checking one unchecks the others.
   * The request fires immediately on toggle change.
   */
  function initCdnModeToggle() {
    document.addEventListener('change', event => {
      const toggle = event.target.closest('.wpr-cdn-mode-toggle__input');
      if (!toggle) {
        return;
      }
      const mode = toggle.getAttribute('data-cdn-mode');
      if (!mode) {
        return;
      }

      // The checkbox has already flipped by the time `change` fires - capture the
      // requested state, then hold the toggle at its previous state and disabled
      // until the request resolves, so nothing about it changes prematurely.
      const requestedChecked = toggle.checked;
      const requestedMode = requestedChecked ? mode : 'nothing';
      const sectionDriver = 'byocdn' === mode ? 'your-own-cdn' : 'rocketcdn';
      const toggleWrapper = toggle.closest('.wpr-cdn-mode-toggle');
      toggle.checked = !requestedChecked;
      toggle.disabled = true;
      if (toggleWrapper) {
        toggleWrapper.classList.add('wpr-cdn-mode-toggle--loading');
      }
      window.wp.apiFetch({
        path: '/wp-rocket/v1/rocketcdn/mode',
        method: 'POST',
        data: {
          mode: requestedMode
        }
      }).then(response => {
        toggle.checked = requestedChecked;
        if (toggleWrapper) {
          toggleWrapper.classList.remove('wpr-cdn-mode-toggle--loading');
        }
        if (requestedChecked) {
          // Uncheck all other mode toggles (mutually exclusive).
          document.querySelectorAll('.wpr-cdn-mode-toggle__input').forEach(other => {
            if (other !== toggle) {
              other.checked = false;
            }
          });
          toggleDriverSections(sectionDriver);
          setActiveTab(sectionDriver);
        }
        updateCdnActiveIndicator(requestedChecked ? toggle : null);
        notifyCdnStateChange();
        updateRocketCDNElementsState('byocdn' === mode ? 'byocdn' : 'rocketcdn', response.disable_rocket_cdn_elements);
        syncCdnHiddenInputs(requestedMode);

        // Enabling either driver changes the other's paused/active status too - e.g.
        // switching to Other CDN pauses RocketCDN, and vice versa - so refresh both
        // status indicators regardless of which toggle was just flipped, instead of
        // only the one matching `mode`. Safe to call unconditionally: both update
        // functions now scope themselves to their own tab (each explicitly excludes
        // the other's copy of #wpr_cdn_status_indicator), and every save_cdn_mode()
        // response already carries both HTML fragments, freshly rendered from the
        // just-persisted state.
        updateByocdnStatusIndicator(response.byocdn_status_indicator_html);
        refreshUIElements(response);
        if ('byocdn' === mode) {
          toggle.disabled = false;
          return;
        }

        // refreshUIElements() calls setSubscriptionLoadingState() above when the async
        // subscription creation is still in progress, which disables every mode toggle -
        // leave this one disabled too until the poller confirms it's live.
        if (!response.is_subscription_creation_loading) {
          toggle.disabled = false;
        }
      }).catch(() => {
        // Request failed - the toggle still reflects its pre-click state, just re-enable it.
        toggle.disabled = false;
        if (toggleWrapper) {
          toggleWrapper.classList.remove('wpr-cdn-mode-toggle--loading');
        }
      });
    });
  }

  /**
   * Toggles visibility of CDN driver sections using the hidden utility class.
   *
   * @param {string} activeDriver Active CDN driver slug ('rocketcdn' or 'your-own-cdn').
   */
  function toggleDriverSections(activeDriver) {
    document.querySelectorAll('.rocketcdn, .your-own-cdn').forEach(section => {
      section.classList.toggle('wpr-isHidden', !section.classList.contains(activeDriver));
    });
  }

  /**
   * Updates all .rocketcdn-driver-js spans to reflect the active driver label.
   *
   * @param {string} driver Active CDN driver slug ('rocketcdn' or 'your-own-cdn').
   */
  function updateDriverLabel(driver) {
    const tab = document.querySelector(`.wpr-cdn-tabs__tab[data-cdn-driver="${driver}"]`);
    if (!tab) {
      return;
    }
    const label = tab.getAttribute('data-title');
    if (!label) {
      return;
    }
    document.querySelectorAll('.rocketcdn-driver-js').forEach(span => {
      span.textContent = label;
    });
  }

  /**
   * Updates the "Need Help?" link href for the CDN Exclusions section
   * to point to the correct docs article for the active driver.
   *
   * @param {string} driver Active CDN driver slug ('rocketcdn' or 'your-own-cdn').
   */
  function updateExcludeCdnHelpUrl(driver) {
    const link = document.querySelector('.exclude-cdn-help-js');
    if (!link) {
      return;
    }
    const isRocketCdn = 'rocketcdn' === driver;
    const url = isRocketCdn ? link.dataset.rocketcdnUrl : link.dataset.otherCdnUrl;
    const id = isRocketCdn ? link.dataset.rocketcdnId : link.dataset.otherCdnId;
    if (url) {
      link.href = url;
    }
    if (id) {
      link.dataset.beaconId = id;
    }
  }

  /**
   * Sets the active driver tab and syncs all tab-dependent UI (label spans, help URL).
   *
   * @param {string} driver Active CDN driver slug ('rocketcdn' or 'your-own-cdn').
   */
  function setActiveTab(driver) {
    document.querySelectorAll('.wpr-cdn-tabs__tab').forEach(t => {
      t.classList.toggle('wpr-cdn-tabs__tab--active', t.getAttribute('data-cdn-driver') === driver);
    });
    updateDriverLabel(driver);
    updateExcludeCdnHelpUrl(driver);
  }

  /**
   * Initializes CDN driver tab switching behavior.
   *
   * Tabs are navigation only — no backend call on click.
   * Initial driver is derived from the PHP-rendered active-state header
   * (wpr-cdn-active-indicator), which reflects cdn_state even when the mode
   * toggle itself is hidden (e.g. rocket_display_cdn_mode_toggle returning
   * false for a hosting compatibility layer). Falls back to whichever
   * toggle is checked when no header is marked active (e.g. cdn_state is
   * 'nothing').
   */
  function initCdnDriverTabs() {
    const tabs = document.querySelectorAll('.wpr-cdn-tabs__tab');
    if (!tabs.length) {
      return;
    }
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const driver = tab.getAttribute('data-cdn-driver');
        if (!driver) {
          return;
        }
        setActiveTab(driver);
        toggleDriverSections(driver);
        notifyCdnStateChange();
      });
    });
    const activeHeader = document.querySelector('.wpr-optionHeader.wpr-cdn-active-indicator');
    let initialDriver;
    if (activeHeader) {
      initialDriver = activeHeader.classList.contains('your-own-cdn') ? 'your-own-cdn' : 'rocketcdn';
    } else {
      const checkedToggle = document.querySelector('.wpr-cdn-mode-toggle__input:checked');
      initialDriver = checkedToggle && 'byocdn' === checkedToggle.getAttribute('data-cdn-mode') ? 'your-own-cdn' : 'rocketcdn';
    }
    setActiveTab(initialDriver);
    toggleDriverSections(initialDriver);
    notifyCdnStateChange();
  }

  /**
   * Adds a page (or the homepage) to RocketCDN free-tier delivery, transparently
   * handling the "RocketCDN Free is inactive" activation prompt: on a 409
   * confirm-required error, shows a native confirmation dialog and retries with
   * `confirm_activation` if the user accepts. If the server auto-activated Free
   * (no mode was active at all), updates the toggle UI to reflect it.
   *
   * @param {string} path REST path to call ('/wp-rocket/v1/rocketcdn/pages' or '.../pages/homepage').
   * @param {Object} data Request body data (e.g. { url }).
   * @returns {Promise} Resolves with the REST response; rejects on final failure or cancellation.
   */
  function requestAddPage(path, data) {
    return window.wp.apiFetch({
      path,
      method: 'POST',
      data
    }).then(response => {
      if (response.free_activated) {
        activateFreeModeUI();
      }
      return response;
    }).catch(error => {
      if ('rocketcdn_free_inactive_confirm_required' === error.code && window.confirm(error.message)) {
        return requestAddPage(path, Object.assign({}, data, {
          confirm_activation: true
        }));
      }
      throw error;
    });
  }

  /**
   * Initializes the "ADD HOMEPAGE" button.
   *
   * Sends a POST request to the RocketCDN REST endpoint to add
   * the site homepage as a free-tier CDN page.
   */
  function initAddHomepage() {
    document.addEventListener('click', event => {
      const button = event.target.closest('#wpr_add_page_component .wpr-cdn-add-page__homepage');
      if (!button) {
        return;
      }
      button.disabled = true;
      const builtIn = document.querySelector('.wpr-cdn-built-in');
      if (builtIn) {
        builtIn.classList.add('wpr-cdn-built-in--disabled');
      }
      requestAddPage('/wp-rocket/v1/rocketcdn/pages/homepage', {}).then(response => {
        button.classList.add('wpr-isHidden');
        updateRocketCtaState(response.count, response.limit);
        if (builtIn) {
          builtIn.classList.remove('wpr-cdn-built-in--disabled');
        }
        if (response.items_html) {
          const existing = document.querySelector('.wpr-cdn-built-in .wpr-table-list');
          if (existing) {
            existing.remove();
          }
          const addPageSection = document.querySelector('.wpr-cdn-add-page');
          if (addPageSection) {
            addPageSection.insertAdjacentHTML('beforebegin', response.items_html);
          }
        }

        // Track banner view when first page is added and banner becomes visible.
        if (1 === response.count) {
          document.querySelector('.wpr-cdn-built-in .wpr-cdn-built-in__separator')?.remove();
          document.dispatchEvent(new CustomEvent('rocketCDNBannerFirstVisible'));
        }
        refreshUIElements(response);
      }).catch(() => {
        button.disabled = false;
        if (builtIn) {
          builtIn.classList.remove('wpr-cdn-built-in--disabled');
        }
      });
    });
  }
  /**
   * Initializes the "ADD PAGE" input and button.
   *
   * Sends a POST request to the RocketCDN REST endpoint to add
   * a page URL to the free-tier CDN page list.
   */
  function initAddPage() {
    const input = document.getElementById('wpr_cdn_add_page_input');
    const button = document.querySelector('.wpr-cdn-add-page__button');
    if (!input || !button) {
      return;
    }
    function isValidUrl(input) {
      try {
        const url = new URL(input);
        return url.hostname.includes('.') && url.hostname.split('.').pop().length > 0;
      } catch {
        return false;
      }
    }
    function submitPage() {
      const url = input.value.trim();
      if (!isValidUrl(url)) {
        alert('Please enter a valid URL');
        return;
      }

      // Prevent duplicate request while request is in flight.
      input.disabled = true;
      button.disabled = true;
      const builtIn = document.querySelector('.wpr-cdn-built-in');
      if (builtIn) {
        builtIn.classList.add('wpr-cdn-built-in--disabled');
      }
      requestAddPage('/wp-rocket/v1/rocketcdn/pages', {
        url
      }).then(response => {
        input.value = '';
        input.disabled = false;
        button.disabled = false;
        addHomeButton.classList.add('wpr-isHidden');
        updateRocketCtaState(response.count, response.limit);
        if (builtIn) {
          builtIn.classList.remove('wpr-cdn-built-in--disabled');
        }

        // Update page list with response.
        if (response.items_html) {
          const existing = document.querySelector('.wpr-cdn-built-in .wpr-table-list');
          if (existing) {
            existing.remove();
          }
          const addPageSection = document.querySelector('.wpr-cdn-add-page');
          if (addPageSection) {
            addPageSection.insertAdjacentHTML('beforebegin', response.items_html);
          }
        }

        // Track banner view when first page is added and banner becomes visible.
        if (1 === response.count) {
          document.querySelector('.wpr-cdn-built-in .wpr-cdn-built-in__separator')?.remove();
          document.dispatchEvent(new CustomEvent('rocketCDNBannerFirstVisible'));
        }
        if (response.limit === response.count) {
          // Disable input and button when page limit is reached.
          document.querySelector('.wpr-cdn-built-in').classList.add('wpr-cdn-built-in--disabled');
          const addPageWrapper = document.querySelector('.wpr-cdn-add-page__button-wrapper');
          if (addPageWrapper) {
            addPageWrapper.classList.add('wpr-btn-with-tool-tip');
          }
          const addPageBtn = document.querySelector('.wpr-cdn-add-page__button');
          if (addPageBtn) {
            addPageBtn.disabled = true;
          }
          updateTooltipState(true);
          document.dispatchEvent(new CustomEvent('rocketCDNBannerAutoExpanded'));
        }
        refreshUIElements(response);
      }).catch(() => {
        input.disabled = false;
        button.disabled = false;
        if (builtIn) {
          builtIn.classList.remove('wpr-cdn-built-in--disabled');
        }
      });
    }
    button.addEventListener('click', submitPage);
    input.addEventListener('keydown', e => {
      if ('Enter' === e.key) {
        e.preventDefault();
        submitPage();
      }
    });
  }
  function refreshUIElements(response) {
    // Set subscription loading state when first page is added.
    if (response.is_subscription_creation_loading) {
      setSubscriptionLoadingState();
    }

    // Only the mode-toggle response carries this - keeps the add-page controls
    // (homepage/add buttons, URL input) in sync with the server's authoritative
    // disabled state (limit reached / subscription loading / forced off) right
    // after enabling or disabling RocketCDN, instead of only on a page reload.
    if ('free_add_page_disabled' in response) {
      const builtIn = document.querySelector('.wpr-cdn-built-in');
      if (builtIn) {
        builtIn.classList.toggle('wpr-cdn-built-in--disabled', response.free_add_page_disabled);
      }
    }

    // Update status indicator component.
    updateStatusIndicatorComponent(response.status_indicator_html);
  }

  /**
   * Initializes delete buttons for CDN page rows.
   *
   * Uses event delegation on the built-in CDN container to handle
   * clicks on dynamically added delete buttons.
   */
  function initDeletePage() {
    const container = document.querySelector('#wpr_add_page_component');
    if (!container) {
      return;
    }
    container.parentElement.addEventListener('click', e => {
      const button = e.target.closest('.wpr-table-list__delete');
      if (!button) {
        return;
      }
      const id = button.dataset.id;
      if (!id) {
        return;
      }
      button.disabled = true;
      window.wp.apiFetch({
        path: `/wp-rocket/v1/rocketcdn/pages/${id}`,
        method: 'DELETE'
      }).then(response => {
        updateRocketCtaState(response.count, response.limit);

        // Update status indicator before the zero-count block so the separator
        // logic below can find the freshly-inserted element when count hits 0.
        updateStatusIndicatorComponent(response.status_indicator_html);
        if (response.items_html) {
          const existing = container.parentElement.querySelector('.wpr-cdn-built-in .wpr-table-list');
          if (existing) {
            existing.remove();
          }
          const addPageSection = container.parentElement.querySelector('.wpr-cdn-add-page');
          if (addPageSection) {
            addPageSection.insertAdjacentHTML('beforebegin', response.items_html);
          }
        }

        // Show re-add HOMEPAGE button and no-page notice when all pages are deleted.
        if (0 === response.count) {
          // Remove table list component.
          document.querySelector('.wpr-cdn-built-in .wpr-table-list').remove();
          const homepageBtn = container.querySelector('.wpr-cdn-add-page__homepage');
          if (homepageBtn) {
            homepageBtn.classList.remove('wpr-isHidden');
            homepageBtn.disabled = false;
          }

          // Restore separator between the status indicator and the add-page section.
          const indicator = document.querySelector('.wpr-cdn-built-in #wpr_cdn_status_indicator');
          if (indicator) {
            indicator.insertAdjacentHTML('afterend', '<div class="wpr-cdn-built-in__separator"></div>');
          }
        }
        if (response.limit > response.count) {
          // Re-enable input and button when page limit is not reached.
          document.querySelector('.wpr-cdn-built-in').classList.remove('wpr-cdn-built-in--disabled');
          const addPageWrapper = document.querySelector('.wpr-cdn-add-page__button-wrapper');
          if (addPageWrapper) {
            addPageWrapper.classList.remove('wpr-btn-with-tool-tip');
          }
          const addPageBtn = document.querySelector('.wpr-cdn-add-page__button');
          if (addPageBtn) {
            addPageBtn.disabled = false;
          }
          updateTooltipState(false);

          // Track auto-collapse when deletion drops count just below the limit.
          if (response.count === response.limit - 1) {
            document.dispatchEvent(new CustomEvent('rocketCDNBannerAutoCollapsed'));
          }
        }
      }).catch(() => {
        button.disabled = false;
      });
    });
  }
})(document);

},{}],6:[function(require,module,exports){
"use strict";

function getTimeRemaining(endtime) {
  const start = Date.now();
  const total = endtime * 1000 - start;
  const seconds = Math.floor(total / 1000 % 60);
  const minutes = Math.floor(total / 1000 / 60 % 60);
  const hours = Math.floor(total / (1000 * 60 * 60) % 24);
  const days = Math.floor(total / (1000 * 60 * 60 * 24));
  return {
    total,
    days,
    hours,
    minutes,
    seconds
  };
}
function initializeClock(id, endtime) {
  const clock = document.getElementById(id);
  if (clock === null) {
    return;
  }
  const daysSpan = clock.querySelector('.rocket-countdown-days');
  const hoursSpan = clock.querySelector('.rocket-countdown-hours');
  const minutesSpan = clock.querySelector('.rocket-countdown-minutes');
  const secondsSpan = clock.querySelector('.rocket-countdown-seconds');
  function updateClock() {
    const t = getTimeRemaining(endtime);
    if (t.total < 0) {
      clearInterval(timeinterval);
      return;
    }
    daysSpan.innerHTML = t.days;
    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);
  }
  updateClock();
  const timeinterval = setInterval(updateClock, 1000);
}
function rucssTimer(id, endtime) {
  const timer = document.getElementById(id);
  const notice = document.getElementById('rocket-notice-saas-processing');
  const success = document.getElementById('rocket-notice-saas-success');
  if (timer === null) {
    return;
  }
  function updateTimer() {
    const start = Date.now();
    const remaining = Math.floor((endtime * 1000 - start) / 1000);
    if (remaining <= 0) {
      clearInterval(timerInterval);
      if (notice !== null) {
        notice.classList.add('hidden');
      }
      if (success !== null) {
        success.classList.remove('hidden');
      }
      if (rocket_ajax_data.cron_disabled) {
        return;
      }
      const data = new FormData();
      data.append('action', 'rocket_spawn_cron');
      data.append('nonce', rocket_ajax_data.nonce);
      fetch(ajaxurl, {
        method: 'POST',
        credentials: 'same-origin',
        body: data
      });
      return;
    }
    timer.innerHTML = remaining;
  }
  updateTimer();
  const timerInterval = setInterval(updateTimer, 1000);
}
if (!Date.now) {
  Date.now = function now() {
    return new Date().getTime();
  };
}
if (typeof rocket_ajax_data.promo_end !== 'undefined') {
  initializeClock('rocket-promo-countdown', rocket_ajax_data.promo_end);
}
if (typeof rocket_ajax_data.license_expiration !== 'undefined') {
  initializeClock('rocket-renew-countdown', rocket_ajax_data.license_expiration);
}
if (typeof rocket_ajax_data.notice_end_time !== 'undefined') {
  rucssTimer('rocket-rucss-timer', rocket_ajax_data.notice_end_time);
}

},{}],7:[function(require,module,exports){
"use strict";

require("../custom/custom-select.js");
var $ = jQuery;
$(document).ready(function () {
  /***
  * Check parent / show children
  ***/

  function wprShowChildren(aElem) {
    var parentId, $children;
    aElem = $(aElem);
    parentId = aElem.attr('id');
    $children = $('[data-parent="' + parentId + '"]');

    // Test check for switch
    if (aElem.is(':checked')) {
      $children.addClass('wpr-isOpen');
      $children.each(function () {
        if ($(this).find('input[type=checkbox]').is(':checked')) {
          var id = $(this).find('input[type=checkbox]').attr('id');
          $('[data-parent="' + id + '"]').addClass('wpr-isOpen');
        }
      });
    } else {
      $children.removeClass('wpr-isOpen');
      $children.each(function () {
        var id = $(this).find('input[type=checkbox]').attr('id');
        $('[data-parent="' + id + '"]').removeClass('wpr-isOpen');
      });
    }
  }

  /**
   * Tell if the given child field has an active parent field.
   *
   * @param  object $field A jQuery object of a ".wpr-field" field.
   * @return bool|null
   */
  function wprIsParentActive($field) {
    var $parent;
    if (!$field.length) {
      // ¯\_(ツ)_/¯
      return null;
    }
    $parent = $field.data('parent');
    if (typeof $parent !== 'string') {
      // This field has no parent field: then we can display it.
      return true;
    }
    $parent = $parent.replace(/^\s+|\s+$/g, '');
    if ('' === $parent) {
      // This field has no parent field: then we can display it.
      return true;
    }
    $parent = $('#' + $parent);
    if (!$parent.length) {
      // This field's parent is missing: let's consider it's not active then.
      return false;
    }
    if (!$parent.is(':checked') && $parent.is('input')) {
      // This field's parent is checkbox and not checked: don't display the field then.
      return false;
    }
    if (!$parent.hasClass('radio-active') && $parent.is('button')) {
      // This field's parent button and is not active: don't display the field then.
      return false;
    }
    // Go recursive to the last parent.
    return wprIsParentActive($parent.closest('.wpr-field'));
  }

  /**
   * Masks sensitive information in an input field by replacing all but the last 4 characters with asterisks.
   *
   * @param {string} id_selector - The ID of the input field to be masked.
   * @returns {void} - Modifies the input field value in-place.
   *
   * @example
   * // HTML: <input type="text" id="creditCardInput" value="1234567890123456">
   * maskField('creditCardInput');
   * // Result: Updates the input field value to '************3456'.
   */
  function maskField(proxy_selector, concrete_selector) {
    var concrete = {
      'val': concrete_selector.val(),
      'length': concrete_selector.val().length
    };
    if (concrete.length > 4) {
      var hiddenPart = '\u2022'.repeat(Math.max(0, concrete.length - 4));
      var visiblePart = concrete.val.slice(-4);

      // Combine the hidden and visible parts
      var maskedValue = hiddenPart + visiblePart;
      proxy_selector.val(maskedValue);
    }
    // Ensure events are not added more than once
    if (!proxy_selector.data('eventsAttached')) {
      proxy_selector.on('input', handleInput);
      proxy_selector.on('focus', handleFocus);
      proxy_selector.data('eventsAttached', true);
    }

    /**
     * Handle the input event
     */
    function handleInput() {
      var proxyValue = proxy_selector.val();
      if (proxyValue.indexOf('\u2022') === -1) {
        concrete_selector.val(proxyValue);
      }
    }

    /**
     * Handle the focus event
     */
    function handleFocus() {
      var concrete_value = concrete_selector.val();
      proxy_selector.val(concrete_value);
    }
  }

  // Update the concrete field when the proxy is updated.

  maskField($('#cloudflare_api_key_mask'), $('#cloudflare_api_key'));
  maskField($('#cloudflare_zone_id_mask'), $('#cloudflare_zone_id'));

  // Display/Hide children fields on checkbox change.
  $('.wpr-isParent input[type=checkbox]').on('change', function () {
    wprShowChildren($(this));
  });

  // On page load, display the active fields.
  $('.wpr-field--children').each(function () {
    var $field = $(this);
    if (wprIsParentActive($field)) {
      $field.addClass('wpr-isOpen');
    }
  });

  /***
  * Warning fields
  ***/

  var $warningParent = $('.wpr-field--parent');
  var $warningParentInput = $('.wpr-field--parent input[type=checkbox]');

  // If already checked
  $warningParentInput.each(function () {
    wprShowChildren($(this));
  });
  $warningParent.on('change', function () {
    wprShowWarning($(this));
  });
  function wprShowWarning(aElem) {
    var $warningField = aElem.next('.wpr-fieldWarning'),
      $thisCheckbox = aElem.find('input[type=checkbox]'),
      $nextWarning = aElem.parent().next('.wpr-warningContainer'),
      $nextFields = $nextWarning.find('.wpr-field'),
      parentId = aElem.find('input[type=checkbox]').attr('id'),
      $children = $('[data-parent="' + parentId + '"]');

    // Check warning parent
    if ($thisCheckbox.is(':checked')) {
      $warningField.addClass('wpr-isOpen');
      $thisCheckbox.prop('checked', false);
      aElem.trigger('change');
      var $warningButton = $warningField.find('.wpr-button');

      // Validate the warning
      $warningButton.on('click', function () {
        $thisCheckbox.prop('checked', true);
        $warningField.removeClass('wpr-isOpen');
        $children.addClass('wpr-isOpen');

        // If next elem = disabled
        if ($nextWarning.length > 0) {
          $nextFields.removeClass('wpr-isDisabled');
          $nextFields.find('input').prop('disabled', false);
        }
        return false;
      });
    } else {
      $nextFields.addClass('wpr-isDisabled');
      $nextFields.find('input').prop('disabled', true);
      $nextFields.find('input[type=checkbox]').prop('checked', false);
      $children.removeClass('wpr-isOpen');
    }
  }

  /**
   * CNAMES add/remove lines
   */
  $(document).on('click', '.wpr-multiple-close', function (e) {
    e.preventDefault();
    $(this).parent().remove();
  });
  $('.wpr-button--addMulti').on('click', function (e) {
    e.preventDefault();
    $($('#wpr-cname-model').html()).appendTo('#wpr-cnames-list');
  });

  /***
   * Wpr Radio button
   ***/
  var disable_radio_warning = false;
  $(document).on('click', '.wpr-radio-buttons-container button', function (e) {
    e.preventDefault();
    if ($(this).hasClass('radio-active')) {
      return false;
    }
    var $parent = $(this).parents('.wpr-radio-buttons');
    $parent.find('.wpr-radio-buttons-container button').removeClass('radio-active');
    $parent.find('.wpr-extra-fields-container').removeClass('wpr-isOpen');
    $parent.find('.wpr-fieldWarning').removeClass('wpr-isOpen');
    $(this).addClass('radio-active');
    wprShowRadioWarning($(this));
  });
  function wprShowRadioWarning($elm) {
    disable_radio_warning = false;
    $elm.trigger("before_show_radio_warning", [$elm]);
    if (!$elm.hasClass('has-warning') || disable_radio_warning) {
      wprShowRadioButtonChildren($elm);
      $elm.trigger("radio_button_selected", [$elm]);
      return false;
    }
    var $warningField = $('[data-parent="' + $elm.attr('id') + '"].wpr-fieldWarning');
    $warningField.addClass('wpr-isOpen');
    var $warningButton = $warningField.find('.wpr-button');

    // Validate the warning
    $warningButton.on('click', function () {
      $warningField.removeClass('wpr-isOpen');
      wprShowRadioButtonChildren($elm);
      $elm.trigger("radio_button_selected", [$elm]);
      return false;
    });
  }
  function wprShowRadioButtonChildren($elm) {
    var $parent = $elm.parents('.wpr-radio-buttons');
    var $children = $('.wpr-extra-fields-container[data-parent="' + $elm.attr('id') + '"]');
    $children.addClass('wpr-isOpen');
  }

  /***
   * Wpr Optimize Css Delivery Field
   ***/
  var rucssActive = parseInt($('#remove_unused_css').val());
  $("#optimize_css_delivery_method .wpr-radio-buttons-container button").on("radio_button_selected", function (event, $elm) {
    toggleActiveOptimizeCssDeliveryMethod($elm);
  });
  $("#optimize_css_delivery").on("change", function () {
    if ($(this).is(":not(:checked)")) {
      disableOptimizeCssDelivery();
    } else {
      var default_radio_button_id = '#' + $('#optimize_css_delivery_method').data('default');
      $(default_radio_button_id).trigger('click');
    }
  });
  function toggleActiveOptimizeCssDeliveryMethod($elm) {
    var optimize_method = $elm.data('value');
    if ('remove_unused_css' === optimize_method) {
      $('#remove_unused_css').val(1);
      $('#async_css').val(0);
    } else {
      $('#remove_unused_css').val(0);
      $('#async_css').val(1);
    }
  }
  function disableOptimizeCssDelivery() {
    $('#remove_unused_css').val(0);
    $('#async_css').val(0);
  }
  $("#optimize_css_delivery_method .wpr-radio-buttons-container button").on("before_show_radio_warning", function (event, $elm) {
    disable_radio_warning = 'remove_unused_css' === $elm.data('value') && 1 === rucssActive;
  });
  $(".wpr-multiple-select .wpr-list-header").click(function (e) {
    $(e.target).closest('.wpr-multiple-select .wpr-list').toggleClass('open');
  });
  $('.wpr-multiple-select .wpr-checkbox').click(function (e) {
    const checkbox = $(this).find('input');
    const is_checked = checkbox.attr('checked') !== undefined;
    checkbox.attr('checked', is_checked ? null : 'checked');
    const sub_checkboxes = $(checkbox).closest('.wpr-list').find('.wpr-list-body input[type="checkbox"]');
    if (checkbox.hasClass('wpr-main-checkbox')) {
      $.map(sub_checkboxes, checkbox => {
        $(checkbox).attr('checked', is_checked ? null : 'checked');
      });
      return;
    }
    const main_checkbox = $(checkbox).closest('.wpr-list').find('.wpr-main-checkbox');
    const sub_checked = $.map(sub_checkboxes, checkbox => {
      if ($(checkbox).attr('checked') === undefined) {
        return;
      }
      return checkbox;
    });
    main_checkbox.attr('checked', sub_checked.length === sub_checkboxes.length ? 'checked' : null);
  });
  if ($('.wpr-main-checkbox').length > 0) {
    $('.wpr-main-checkbox').each((checkbox_key, checkbox) => {
      let parent_list = $(checkbox).parents('.wpr-list');
      let not_checked = parent_list.find('.wpr-list-body input[type=checkbox]:not(:checked)').length;
      $(checkbox).attr('checked', not_checked <= 0 ? 'checked' : null);
    });
  }
  let checkBoxCounter = {
    checked: {},
    total: {}
  };
  $('.wpr-field--categorizedmultiselect .wpr-list').each(function () {
    // Get the ID of the current element
    let id = $(this).attr('id');
    if (id) {
      checkBoxCounter.checked[id] = $(`#${id} input[type='checkbox']:checked`).length;
      checkBoxCounter.total[id] = $(`#${id} input[type='checkbox']:not(.wpr-main-checkbox)`).length;
      // Update the counter text
      $(`#${id} .wpr-badge-counter span`).text(checkBoxCounter.checked[id]);
      // Show or hide the counter badge based on the count
      $(`#${id} .wpr-badge-counter`).toggle(checkBoxCounter.checked[id] > 0);

      // Check the select all option if all exclusions are checked in a section.
      if (checkBoxCounter.checked[id] === checkBoxCounter.total[id]) {
        $(`#${id} .wpr-main-checkbox`).attr('checked', true);
      }
    }
  });

  /**
   * Delay JS Execution Safe Mode Field
   */
  var $dje_safe_mode_checkbox = $('#delay_js_execution_safe_mode');
  $('#delay_js').on('change', function () {
    if ($(this).is(':not(:checked)') && $dje_safe_mode_checkbox.is(':checked')) {
      $dje_safe_mode_checkbox.trigger('click');
    }
  });
  let stacked_select = document.getElementById('rocket_stacked_select');
  if (stacked_select) {
    stacked_select.addEventListener('custom-select-change', function (event) {
      let selected_option = $(event.detail.selectedOption);
      let name = selected_option.data('name');
      let saving = selected_option.data('saving');
      let regular_price = selected_option.data('regular-price');
      let price = selected_option.data('price');
      let url = selected_option.data('url');
      let parent_item = $(this).parents('.wpr-upgrade-item');
      if (saving) {
        parent_item.find('.wpr-upgrade-saving span').html(saving);
      }
      if (name) {
        parent_item.find('.wpr-upgrade-title').html(name);
      }
      if (regular_price) {
        parent_item.find('.wpr-upgrade-price-regular span').html(regular_price);
      }
      if (price) {
        parent_item.find('.wpr-upgrade-price-value').html(price);
      }
      if (url) {
        parent_item.find('.wpr-upgrade-link').attr('href', url);
      }
    });
  }
  $(document).on('click', '.wpr-confirm-delete', function (e) {
    return confirm($(this).data('wpr_confirm_msg'));
  });
});

},{"../custom/custom-select.js":1}],8:[function(require,module,exports){
"use strict";

var $ = jQuery;
$(document).ready(function () {
  /***
  * Dashboard notice
  ***/

  var $notice = $('.wpr-notice');
  var $noticeClose = $('#wpr-congratulations-notice');
  $noticeClose.on('click', function () {
    wprCloseDashboardNotice();
    return false;
  });
  function wprCloseDashboardNotice() {
    var vTL = new TimelineLite().to($notice, 1, {
      autoAlpha: 0,
      x: 40,
      ease: Power4.easeOut
    }).to($notice, 0.6, {
      height: 0,
      marginTop: 0,
      ease: Power4.easeOut
    }, '=-.4').set($notice, {
      'display': 'none'
    });
  }

  /**
   * Rocket Analytics notice info collect
   */
  $('.rocket-analytics-data-container').hide();
  $('.rocket-preview-analytics-data').on('click', function (e) {
    e.preventDefault();
    $(this).parent().next('.rocket-analytics-data-container').toggle();
  });

  /***
  * Hide / show Rocket addon tabs.
  ***/

  $('.wpr-toggle-button').each(function () {
    var $button = $(this);
    var $checkbox = $button.closest('.wpr-fieldsContainer-fieldset').find('.wpr-radio :checkbox');
    var $menuItem = $('[href="' + $button.attr('href') + '"].wpr-menuItem');
    $checkbox.on('change', function () {
      if ($checkbox.is(':checked')) {
        $menuItem.css('display', 'block');
        $button.css('display', 'inline-block');
      } else {
        $menuItem.css('display', 'none');
        $button.css('display', 'none');
      }
    }).trigger('change');
  });

  /***
  * Help Button Tracking
  ***/

  // Track clicks on various help elements with data attributes
  $(document).on('click', '[data-wpr_track_help]', function (e) {
    if (typeof window.wprTrackHelpButton === 'function') {
      var $el = $(this);
      var button = $el.data('wpr_track_help');
      var context = $el.data('wpr_track_context') || '';
      window.wprTrackHelpButton(button, context);
    }
  });

  // Track specific help resource clicks with explicit selectors
  $(document).on('click', '.wistia_embed', function () {
    if (typeof window.wprTrackHelpButton === 'function') {
      var title = $(this).text() || 'Getting Started Video';
      window.wprTrackHelpButton(title, 'Getting Started');
    }
  });

  // Track FAQ links
  $(document).on('click', 'a[data-beacon-article]', function () {
    if (typeof window.wprTrackHelpButton === 'function') {
      var href = $(this).attr('href');
      var text = $(this).text();

      // Check if it's in FAQ section or sidebar documentation
      if ($(this).closest('.wpr-fieldsContainer-fieldset').prev('.wpr-optionHeader').find('.wpr-title2').text().includes('Frequently Asked Questions')) {
        window.wprTrackHelpButton('FAQ - ' + text, 'Dashboard');
      } else if ($(this).closest('.wpr-documentation').length > 0) {
        window.wprTrackHelpButton('Documentation', 'Sidebar');
      } else {
        window.wprTrackHelpButton('Documentation Link', 'General');
      }
    }
  });

  // Track "How to measure loading time" link
  $(document).on('click', 'a[href*="how-to-test-wordpress-site-performance"]', function () {
    if (typeof window.wprTrackHelpButton === 'function') {
      window.wprTrackHelpButton('Loading Time Guide', 'Sidebar');
    }
  });

  // Track "Need help?" links (existing help buttons)
  $(document).on('click', '.wpr-infoAction--help:not([data-beacon-id])', function () {
    if (typeof window.wprTrackHelpButton === 'function') {
      window.wprTrackHelpButton('Need Help', 'General');
    }
  });

  /***
  * Show popin analytics
  ***/

  var $wprAnalyticsPopin = $('.wpr-Popin-Analytics'),
    $wprPopinOverlay = $('.wpr-Popin-overlay'),
    $wprAnalyticsClosePopin = $('.wpr-Popin-Analytics-close'),
    $wprAnalyticsPopinButton = $('.wpr-Popin-Analytics .wpr-button'),
    $wprAnalyticsOpenPopin = $('.wpr-js-popin');
  $wprAnalyticsOpenPopin.on('click', function (e) {
    e.preventDefault();
    wprOpenAnalytics();
    return false;
  });
  $wprAnalyticsClosePopin.on('click', function (e) {
    e.preventDefault();
    wprCloseAnalytics();
    return false;
  });
  $wprAnalyticsPopinButton.on('click', function (e) {
    e.preventDefault();
    wprActivateAnalytics();
    return false;
  });
  function wprOpenAnalytics() {
    var vTL = new TimelineLite().set($wprAnalyticsPopin, {
      'display': 'block'
    }).set($wprPopinOverlay, {
      'display': 'block'
    }).fromTo($wprPopinOverlay, 0.6, {
      autoAlpha: 0
    }, {
      autoAlpha: 1,
      ease: Power4.easeOut
    }).fromTo($wprAnalyticsPopin, 0.6, {
      autoAlpha: 0,
      marginTop: -24
    }, {
      autoAlpha: 1,
      marginTop: 0,
      ease: Power4.easeOut
    }, '=-.5');
  }
  function wprCloseAnalytics() {
    var vTL = new TimelineLite().fromTo($wprAnalyticsPopin, 0.6, {
      autoAlpha: 1,
      marginTop: 0
    }, {
      autoAlpha: 0,
      marginTop: -24,
      ease: Power4.easeOut
    }).fromTo($wprPopinOverlay, 0.6, {
      autoAlpha: 1
    }, {
      autoAlpha: 0,
      ease: Power4.easeOut
    }, '=-.5').set($wprAnalyticsPopin, {
      'display': 'none'
    }).set($wprPopinOverlay, {
      'display': 'none'
    });
  }
  function wprActivateAnalytics() {
    wprCloseAnalytics();
    $('#analytics_enabled').prop('checked', true);
    var analyticsEnabled = document.getElementById('analytics_enabled');
    if (analyticsEnabled) {
      var changeEvent = new Event('change', {
        bubbles: true
      });
      analyticsEnabled.dispatchEvent(changeEvent);
    }
  }

  // Display CTA within the popin `What info will we collect?`
  $('#analytics_enabled').on('change', function () {
    $('.wpr-rocket-analytics-cta').toggleClass('wpr-isHidden');
  });

  /***
  * Show popin upgrade
  ***/

  var $wprUpgradePopin = $('.wpr-Popin-Upgrade'),
    $wprUpgradeClosePopin = $('.wpr-Popin-Upgrade-close'),
    $wprUpgradeOpenPopin = $('.wpr-popin-upgrade-toggle');
  $wprUpgradeOpenPopin.on('click', function (e) {
    e.preventDefault();
    wprOpenUpgradePopin();
    return false;
  });
  $wprUpgradeClosePopin.on('click', function () {
    wprCloseUpgradePopin();
    return false;
  });
  function wprOpenUpgradePopin() {
    var vTL = new TimelineLite();
    vTL.set($wprUpgradePopin, {
      'display': 'block'
    }).set($wprPopinOverlay, {
      'display': 'block'
    }).fromTo($wprPopinOverlay, 0.6, {
      autoAlpha: 0
    }, {
      autoAlpha: 1,
      ease: Power4.easeOut
    }).fromTo($wprUpgradePopin, 0.6, {
      autoAlpha: 0,
      marginTop: -24
    }, {
      autoAlpha: 1,
      marginTop: 0,
      ease: Power4.easeOut
    }, '=-.5');
  }
  function wprCloseUpgradePopin() {
    var vTL = new TimelineLite();
    vTL.fromTo($wprUpgradePopin, 0.6, {
      autoAlpha: 1,
      marginTop: 0
    }, {
      autoAlpha: 0,
      marginTop: -24,
      ease: Power4.easeOut
    }).fromTo($wprPopinOverlay, 0.6, {
      autoAlpha: 1
    }, {
      autoAlpha: 0,
      ease: Power4.easeOut
    }, '=-.5').set($wprUpgradePopin, {
      'display': 'none'
    }).set($wprPopinOverlay, {
      'display': 'none'
    });
  }

  /***
  * Sidebar on/off
  ***/
  var $wprSidebar = $('.wpr-Sidebar');
  var $wprButtonTips = $('.wpr-js-tips');
  $wprButtonTips.on('change', function () {
    wprDetectTips($(this));
  });
  function wprDetectTips(aElem) {
    if (aElem.is(':checked')) {
      $wprSidebar.css('display', 'block');
      localStorage.setItem('wpr-show-sidebar', 'on');
    } else {
      $wprSidebar.css('display', 'none');
      localStorage.setItem('wpr-show-sidebar', 'off');
    }
  }

  /***
  * Detect Adblock
  ***/

  if (document.getElementById('LKgOcCRpwmAj')) {
    $('.wpr-adblock').css('display', 'none');
  } else {
    $('.wpr-adblock').css('display', 'block');
  }
  var $adblock = $('.wpr-adblock');
  var $adblockClose = $('.wpr-adblock-close');
  $adblockClose.on('click', function () {
    wprCloseAdblockNotice();
    return false;
  });
  function wprCloseAdblockNotice() {
    var vTL = new TimelineLite().to($adblock, 1, {
      autoAlpha: 0,
      x: 40,
      ease: Power4.easeOut
    }).to($adblock, 0.4, {
      height: 0,
      marginTop: 0,
      ease: Power4.easeOut
    }, '=-.4').set($adblock, {
      'display': 'none'
    });
  }

  // Handle expand/collapse of recommendations list.
  $(document).on('click', '#wpr-recommendations-load-more', function () {
    let $list = $('.wpr-recommendations__list');
    let $hiddenItems = $list.find('.wpr-recommendation-item:gt(2)');

    // Track Load More button click
    if (typeof window.wprTrackHelpButton === 'function') {
      window.wprTrackHelpButton('rocket insights recommendations load more', 'load_more');
    }
    if ($list.hasClass('is-expanded')) {
      $hiddenItems.slideUp(300, function () {
        $list.removeClass('is-expanded');
      });
      $(this).removeClass('is-expanded');
      return;
    }
    $list.addClass('is-expanded');
    $hiddenItems.slideDown(300);
    $(this).addClass('is-expanded');
  });

  // Track Rocket Insights Recommendation Activate button clicks
  $(document).on('click', '.wpr-recommendation-item__activate', function () {
    var recommendation = $(this).data('recommendation') || 'unknown';

    // If the element is visible, scroll to the element with id matching the recommendation value.
    // Delay scroll by 100ms to allow navigation to the section to complete and ensure the target element is in view.
    setTimeout(function () {
      var $target = $(`#${recommendation}`);
      if (!$target.length && !$target.is(':visible')) {
        return;
      }
      $target[0].scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }, 100);

    // Track directly with Mixpanel
    if (typeof mixpanel !== 'undefined' && mixpanel.track) {
      // Check if user has opted in
      if (typeof rocket_mixpanel_data !== 'undefined' && rocket_mixpanel_data.optin_enabled && rocket_mixpanel_data.optin_enabled !== '0') {
        // Identify user if available
        if (rocket_mixpanel_data.user_id && typeof mixpanel.identify === 'function') {
          mixpanel.identify(rocket_mixpanel_data.user_id);
        }

        // Track the Button Clicked event
        mixpanel.track('Button Clicked', {
          'button': 'rocket insights recommendation',
          'recommendation': recommendation,
          'plugin': rocket_mixpanel_data.plugin,
          'brand': rocket_mixpanel_data.brand,
          'application': rocket_mixpanel_data.app,
          'context': rocket_mixpanel_data.context,
          'path': rocket_mixpanel_data.path,
          'interaction_channel': 'UI'
        });
      }
    }
  });

  // Track CTA clicks for Rocket Insights in the settings saved notice.
  $(document).on('click', '#rocket_ri_new_test_save_settings_link', function () {
    // Track directly with Mixpanel
    if (typeof mixpanel === 'undefined' || !mixpanel.track) {
      return;
    }

    // Check if user has opted in
    if (typeof rocket_mixpanel_data === 'undefined' || !rocket_mixpanel_data.optin_enabled || rocket_mixpanel_data.optin_enabled === '0') {
      return;
    }

    // Identify user if available
    if (rocket_mixpanel_data.user_id && typeof mixpanel.identify === 'function') {
      mixpanel.identify(rocket_mixpanel_data.user_id);
    }

    // Track the Button Clicked event
    mixpanel.track('Rocket Insights CTA click from settings notice', {
      'button': 'CTA on save settings notice',
      'source': 'Settings Saved Notice',
      'plugin': rocket_mixpanel_data.plugin,
      'brand': rocket_mixpanel_data.brand,
      'application': rocket_mixpanel_data.app,
      'context': rocket_mixpanel_data.context,
      'path': rocket_mixpanel_data.path,
      'interaction_channel': 'UI'
    });
  });
});

},{}],9:[function(require,module,exports){
"use strict";

function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
class RocketMixpanel {
  constructor(config) {
    _defineProperty(this, "trackedTabs", ['dashboard', 'rocket_insights', 'page_cdn', 'file_optimization', 'media', 'preload', 'advanced_cache', 'database', 'heartbeat', 'addons', 'imagify', 'tutorials', 'plugins', 'tools']);
    this.config = config;
  }

  /**
   * Initializes the handler.
   */
  init() {
    if (typeof mixpanel === 'undefined' || !mixpanel.track) {
      return;
    }
    if (!this.config.optin_enabled || this.config.optin_enabled === '0') {
      return;
    }
    mixpanel.identify(this.config.user_id);
    this._initListeners(this);
  }

  /**
   * Initializes the event listeners.
   *
   * @param self instance of this object, used for binding "this" to the listeners.
   */
  _initListeners(self) {
    window.addEventListener('hashchange', self._onHashChange.bind(self));
    window.addEventListener('load', self._onPageLoad.bind(self));
  }

  /**
   * Event listener when the hash changed in a page.
   *
   * @param Event event Event instance.
   */
  _onHashChange(event) {
    const oldHash = this._cleanHash(new URL(event.oldURL).hash);
    const newHash = this._cleanHash(new URL(event.newURL).hash);
    if (!this._canTrackTab(newHash)) {
      return;
    }
    this._sendPageViewedEvent(this._getSource(oldHash), newHash);
  }
  _onPageLoad() {
    const newHash = this._cleanHash(window.location.hash);
    if (!this._canTrackTab(newHash)) {
      return;
    }
    this._sendPageViewedEvent(this._getSource(), newHash);
  }
  _cleanHash(tabHash) {
    if (!tabHash || !tabHash.startsWith('#')) {
      return tabHash;
    }
    return tabHash.substring(1);
  }
  _canTrackTab(tabHash) {
    return this.trackedTabs.includes(tabHash);
  }
  _getSource(oldHash = '') {
    if (oldHash) {
      return `settings_${oldHash}`;
    }
    let source = this._getSourceFromQueryStringAndRemoveIt();
    if (source) {
      return source;
    }
    return this._getSourceFromReferrer();
  }
  _getSourceFromQueryStringAndRemoveIt() {
    const url = new URL(window.location.href);
    const urlParams = url.searchParams;

    // 1. Check for explicit source param
    if (!urlParams.has('rocket_source')) {
      return '';
    }

    // 2. Get the value
    const sourceValue = urlParams.get('rocket_source');

    // 3. Delete the parameter from the URLSearchParams object
    urlParams.delete('rocket_source');

    // 4. Update the browser's URL using the History API
    // This removes the parameter from the URL bar without reloading the page.
    window.history.replaceState(null, '', url.search ? url.href : url.pathname);

    // 5. Return the retrieved value
    return sourceValue;
  }
  _getSourceFromReferrer() {
    const referrer = document.referrer;
    if (!referrer) {
      return 'noreferrer';
    }
    if (!referrer.includes(window.location.hostname)) {
      return 'external';
    }
    return 'internal';
  }
  _sendPageViewedEvent(source, newHash) {
    mixpanel.track('Page Viewed', {
      path: `/wp-admin/options-general.php?page=wprocket#${newHash}`,
      page_name: newHash.replace('_', ' '),
      source: source,
      plugin: rocket_mixpanel_data.plugin,
      brand: rocket_mixpanel_data.brand,
      application: rocket_mixpanel_data.app,
      context: rocket_mixpanel_data.context,
      interaction_channel: 'UI'
    });
  }

  /**
   * Named static constructor to encapsulate how to create the object.
   */
  static run() {
    // Bail out if the configuration not passed from the server.
    if (typeof rocket_mixpanel_data === 'undefined') {
      return;
    }
    const instance = new RocketMixpanel(rocket_mixpanel_data);
    instance.init();
  }
}
RocketMixpanel.run();

},{}],10:[function(require,module,exports){
"use strict";

document.addEventListener('DOMContentLoaded', function () {
  var $pageManager = document.querySelector(".wpr-Content");
  if ($pageManager) {
    new PageManager($pageManager);
  }
});

/*-----------------------------------------------*\
		CLASS PAGEMANAGER
\*-----------------------------------------------*/
/**
 * Manages the display of pages / section for WP Rocket plugin
 *
 * Public method :
     detectID - Detect ID with hash
     getBodyTop - Get body top position
	 change - Displays the corresponding page
 *
 */

function PageManager(aElem) {
  var refThis = this;
  this.$body = document.querySelector('.wpr-body');
  this.$menuItems = document.querySelectorAll('.wpr-menuItem');
  this.$submitButton = document.querySelector('.wpr-Content > form > #wpr-options-submit');
  this.$pages = document.querySelectorAll('.wpr-Page');
  this.$sidebar = document.querySelector('.wpr-Sidebar');
  this.$content = document.querySelector('.wpr-Content');
  this.$tips = document.querySelector('.wpr-Content-tips');
  this.$links = document.querySelectorAll('.wpr-body a');
  this.$menuItem = null;
  this.$page = null;
  this.pageId = null;
  this.bodyTop = 0;
  this.buttonText = this.$submitButton.value;
  refThis.getBodyTop();

  // If url page change
  window.onhashchange = function () {
    refThis.detectID();
  };

  // If hash already exist (after refresh page for example)
  if (window.location.hash) {
    this.bodyTop = 0;
    this.detectID();
  } else {
    var session = localStorage.getItem('wpr-hash');
    this.bodyTop = 0;
    if (session) {
      window.location.hash = session;
      this.detectID();
    } else {
      this.$menuItems[0].classList.add('isActive');
      localStorage.setItem('wpr-hash', 'dashboard');
      window.location.hash = '#dashboard';
    }
  }

  // Click link same hash
  for (var i = 0; i < this.$links.length; i++) {
    this.$links[i].onclick = function () {
      refThis.getBodyTop();
      var hrefSplit = this.href.split('#')[1];
      if (hrefSplit == refThis.pageId && hrefSplit != undefined) {
        refThis.detectID();
        return false;
      }
    };
  }

  // Click links not WP rocket to reset hash
  var $otherlinks = document.querySelectorAll('#adminmenumain a, #wpadminbar a');
  for (var i = 0; i < $otherlinks.length; i++) {
    $otherlinks[i].onclick = function () {
      localStorage.setItem('wpr-hash', '');
    };
  }
  document.addEventListener('wpr-cdn-state-change', function () {
    refThis.updateSubmitDisabledState();
  });
}

/*
* Page detect ID
*/
PageManager.prototype.detectID = function () {
  this.pageId = window.location.hash.split('#')[1];
  this.pageId = this.pageId.includes('=') ? this.pageId.split('=')[0] : this.pageId;
  localStorage.setItem('wpr-hash', this.pageId);
  this.$page = document.querySelector('.wpr-Page#' + this.pageId);
  this.$menuItem = document.getElementById('wpr-nav-' + this.pageId);
  this.change();
};

/*
* Get body top position
*/
PageManager.prototype.getBodyTop = function () {
  var bodyPos = this.$body.getBoundingClientRect();
  this.bodyTop = bodyPos.top + window.pageYOffset - 47; // #wpadminbar + padding-top .wpr-wrap - 1 - 47
};

/*
* Page change
*/
PageManager.prototype.change = function () {
  var refThis = this;
  document.documentElement.scrollTop = refThis.bodyTop;

  // Hide other pages
  for (var i = 0; i < this.$pages.length; i++) {
    this.$pages[i].style.display = 'none';
  }
  for (var i = 0; i < this.$menuItems.length; i++) {
    this.$menuItems[i].classList.remove('isActive');
  }

  // Show current default page
  this.$page.style.display = 'block';
  this.$submitButton.style.display = 'block';
  if (null === localStorage.getItem('wpr-show-sidebar')) {
    localStorage.setItem('wpr-show-sidebar', 'on');
  }
  if ('on' === localStorage.getItem('wpr-show-sidebar')) {
    this.$sidebar.style.display = 'flex';
  } else if ('off' === localStorage.getItem('wpr-show-sidebar')) {
    this.$sidebar.style.display = 'none';
    document.querySelector('#wpr-js-tips').removeAttribute('checked');
  }
  this.$tips.style.display = 'block';
  this.$menuItem.classList.add('isActive');
  this.$submitButton.value = this.buttonText;
  this.$content.classList.add('isNotFull');
  const pagesWithoutSubmit = ['dashboard', 'addons', 'database', 'tools', 'addons', 'imagify', 'tutorials', 'plugins'];
  const pagesWithoutSidebarToggle = ['dashboard', 'imagify', 'page_cdn'];

  // Exception for dashboard
  if (this.pageId == "dashboard") {
    this.$sidebar.style.display = 'none';
    this.$content.classList.remove('isNotFull');
  }
  if (this.pageId == "imagify") {
    this.$sidebar.style.display = 'none';
  }
  if (pagesWithoutSidebarToggle.includes(this.pageId)) {
    this.$tips.style.display = 'none';
  }
  if (pagesWithoutSubmit.includes(this.pageId)) {
    this.$submitButton.style.display = 'none';
  }
  this.updateSubmitDisabledState();

  // Dispatch custom event after page navigation for other scripts to hook into.
  document.dispatchEvent(new CustomEvent('rocketJsAfterPageNavigation', {
    detail: {
      pageId: this.pageId,
      submitButton: this.$submitButton
    }
  }));
};

/*
* Update submit button disabled state
*/
PageManager.prototype.updateSubmitDisabledState = function () {
  if (!this.$submitButton || 'none' === this.$submitButton.style.display) {
    return;
  }
  var isCdnPage = 'page_cdn' === this.pageId;
  var pausedRocketCdnBlock = document.querySelector('.wpr-Page#page_cdn .wpr-notice.wpr-ri-notice.wpr-cdn-expired__notice');
  this.$submitButton.disabled = isCdnPage && !!pausedRocketCdnBlock;
};

},{}],11:[function(require,module,exports){
"use strict";

/**
 * Recommendations Widget Handler
 *
 * Listens for Global Score updates and fetches/updates recommendations dynamically.
 */
var $ = jQuery;
$(document).ready(function () {
  /**
   * Updates the recommendations widget UI based on the fetched data.
   *
   * @param {Object} data - The recommendations data from the API.
   * @param {Array} data.recommendations - Array of recommendations details.
   * @param {string} data.recommendations.html - Recommendations HTML.
   */
  function updateRecommendationsWidget(data) {
    const widget = $('.wpr-recommendations');
    if (!widget || !data?.recommendations?.html) {
      return;
    }

    // Update the widget content with the new recommendations HTML
    widget.replaceWith(data?.recommendations?.html);
  }

  /**
   * Fetches the current recommendations status from the REST API.
   */
  function fetchRecommendationsStatus() {
    // Use WordPress REST API client if available
    if (window.wp && window.wp.apiFetch) {
      window.wp.apiFetch({
        path: '/wp-rocket/v1/recommendations'
      }).then(function (data) {
        updateRecommendationsWidget(data);
      }).catch(function (error) {
        console.error('Failed to fetch recommendations status:', error);
      });
    } else {
      // Fallback to fetch API
      fetch(window.wpApiSettings?.root + 'wp-rocket/v1/recommendations', {
        headers: {
          'X-WP-Nonce': window.wpApiSettings?.nonce || ''
        }
      }).then(function (response) {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      }).then(function (data) {
        updateRecommendationsWidget(data);
      }).catch(function (error) {
        console.error('Failed to fetch recommendations status:', error);
      });
    }
  }

  /**
   * Listen for Global Score update event.
   * This is fired by ajax.js when the Global Score polling detects a change.
   */
  $(document).on('wprGlobalScoreUpdated rocket-insights-page-added rocket-insights-page-retest', () => {
    fetchRecommendationsStatus();
  });
});

},{}],12:[function(require,module,exports){
"use strict";

(document => {
  'use strict';

  /**
   * Polls the RocketCDN subscription endpoint until is_loading becomes false.
   */
  class RocketCDNSubscriptionPoller {
    constructor() {
      this.path = '/wp-rocket/v1/rocketcdn/subscription';
      this.pollInterval = 10000; // 10 seconds.
      this.maxRetries = 60; // 10 minutes total.
      this.timerId = null;
      this.retryCount = 0;
      document.addEventListener('rocketCDNSubscriptionLoading', () => this.start());

      // Re-trigger polling after page refresh.
      const classes = ['.wpr-icon-orange-loader', '.wpr-cdn-built-in--disabled'];
      const allPresent = classes.every(cls => document.querySelector(cls) !== null);
      if (allPresent) {
        this.start();
      }
    }

    /**
     * Starts polling.
     */
    start() {
      if (this.timerId) {
        return;
      }
      this.retryCount = 0;
      this.poll();
    }

    /**
     * Stops polling.
     */
    stop() {
      if (this.timerId) {
        clearTimeout(this.timerId);
        this.timerId = null;
      }
    }

    /**
     * Performs a single poll and schedules the next one if still loading.
     */
    poll() {
      if (this.retryCount >= this.maxRetries) {
        this.stop();
        return;
      }
      this.retryCount++;
      window.wp.apiFetch({
        path: this.path,
        method: 'GET'
      }).then(response => {
        if (!response || !response.is_loading) {
          this.stop();
          window.location.reload();
          return;
        }
        this.timerId = setTimeout(() => this.poll(), this.pollInterval);
      }).catch(() => {
        this.timerId = setTimeout(() => this.poll(), this.pollInterval);
      });
    }
  }
  new RocketCDNSubscriptionPoller();
})(document);

},{}],13:[function(require,module,exports){
"use strict";

/*eslint-env es6, browser*/
/* global MicroModal, mixpanel, rocket_mixpanel_data, rocket_cdn_mixpanel_data, rocket_ajax_data, ajaxurl */
((document, window) => {
  'use strict';

  const BANNER_STATE = {
    OPENED: false,
    // Big CTA - opened state
    COLLAPSED: true // Small CTA - collapsed state
  };
  document.addEventListener('rocketCDNBannerAutoExpanded', () => trackRocketCDNUpsellBannerExpanded('auto_limit_reached'));
  document.addEventListener('rocketCDNBannerAutoCollapsed', () => trackRocketCDNUpsellBannerCollapsed('auto_limit_released'));
  document.addEventListener('rocketCDNBannerFirstVisible', () => trackRocketCDNUpsellBannerViewed(BANNER_STATE.COLLAPSED));
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.wpr-rocketcdn-open').forEach(el => {
      el.addEventListener('click', e => {
        e.preventDefault();
        const isCTA = el.classList.contains('wpr-rocketcdn-pricing--cta');
        checkButtonUrlAndOpen(isCTA);
      });
    });

    // Always initialize MicroModal to set up close handlers
    MicroModal.init({
      disableScroll: true
    });
    maybeOpenModalFromURL();

    // Only auto-open modal if there's no direct button URL
    if (!window.rocketcdnButtonUrl || window.rocketcdnButtonUrl === '') {
      maybeOpenModal();
      const iframe = document.getElementById('rocketcdn-iframe');
      const loader = document.getElementById('wpr-rocketcdn-modal-loader');
      if (iframe && loader) {
        iframe.addEventListener('load', function () {
          loader.style.display = 'none';
        });
      }
    }
  });

  /**
   * Checks if the user is currently on the CDN tab.
   *
   * @return {boolean} True if on CDN tab, false otherwise.
   */
  function isOnCDNTab() {
    return window.location.hash === '#page_cdn';
  }
  function maybeTrackBannerView() {
    const smallCTA = document.querySelector('#wpr-rocketcdn-cta-small');
    const bigCTA = document.querySelector('#wpr-rocketcdn-cta');

    // Only track if one of the banners is visible.
    if (bigCTA && !bigCTA.classList.contains('wpr-isHidden')) {
      trackRocketCDNUpsellBannerViewed(BANNER_STATE.OPENED);
    } else if (smallCTA && !smallCTA.classList.contains('wpr-isHidden')) {
      trackRocketCDNUpsellBannerViewed(BANNER_STATE.COLLAPSED);
    }
  }
  window.addEventListener('load', () => {
    let openCTA = document.querySelector('#wpr-rocketcdn-open-cta'),
      closeCTA = document.querySelector('#wpr-rocketcdn-close-cta'),
      smallCTA = document.querySelector('#wpr-rocketcdn-cta-small'),
      bigCTA = document.querySelector('#wpr-rocketcdn-cta'),
      inputToggle = document.querySelector('.wpr-rocketcdn-toggle--input');
    const ctaToggle = document.querySelectorAll('.wpr-rocketcdn-cta-toggle');

    /**
     * Toggles RocketCDN CTA internal collapsed/expanded state.
     *
     * @return {void}
     */
    function toggleBigCTAState() {
      if (!bigCTA || !ctaToggle.length) {
        return;
      }
      const isCollapsed = bigCTA.classList.toggle('wpr-rocketcdn-cta--collapsed');
      bigCTA.classList.toggle('wpr-rocketcdn-cta--expanded', !isCollapsed);
      ctaToggle.forEach(el => {
        el.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
      });
      if (!isCollapsed) {
        trackRocketCDNUpsellBannerExpanded('manual');
      } else {
        trackRocketCDNUpsellBannerCollapsed();
      }
    }
    if (ctaToggle.length && bigCTA) {
      ctaToggle.forEach(el => {
        el.addEventListener('click', toggleBigCTAState);
        el.addEventListener('keydown', event => {
          if ('Enter' === event.key || ' ' === event.key) {
            event.preventDefault();
            toggleBigCTAState();
          }
        });
      });
    }

    // Track banner view on page load if banner is visible and user is on CDN tab.
    maybeTrackBannerView();

    // Track banner view when user navigates to CDN tab.
    window.addEventListener('hashchange', () => {
      maybeTrackBannerView();
    });

    // Prices selectors for toggling visibility based on the billing cycle toggle state.
    const prices = {
      monthly: {
        regular: document.querySelectorAll('.wpr-rocketcdn-pricing-regular-price--monthly'),
        current: document.querySelectorAll('.wpr-rocketcdn-pricing--monthly'),
        period: document.querySelectorAll('.wpr-rocketcdn-pricing--billing-period--monthly')
      },
      yearly: {
        regular: document.querySelectorAll('.wpr-rocketcdn-pricing-regular-price--yearly'),
        current: document.querySelectorAll('.wpr-rocketcdn-pricing--annual'),
        period: document.querySelectorAll('.wpr-rocketcdn-pricing--billing-period--yearly')
      }
    };

    // Display the correct prices on page based on billing cycle toggle state.
    if (inputToggle) {
      inputToggle.addEventListener('change', function () {
        const isYearly = this.checked;
        if (isYearly) {
          Object.values(prices.monthly).forEach(list => list.forEach(el => el.classList.add('wpr-isHidden')));
          Object.values(prices.yearly).forEach(list => list.forEach(el => el.classList.remove('wpr-isHidden')));
        } else {
          Object.values(prices.monthly).forEach(list => list.forEach(el => el.classList.remove('wpr-isHidden')));
          Object.values(prices.yearly).forEach(list => list.forEach(el => el.classList.add('wpr-isHidden')));
        }

        // Update the button URL with the correct is_monthly parameter.
        updateButtonUrlBillingCycle(isYearly);
      });
    }

    // Track RocketCDN activation failed CTA click
    const activationCTA = document.querySelector('#wpr-rocketcdn-activation-cta');
    if (activationCTA) {
      activationCTA.addEventListener('click', () => {
        trackRocketCDNActivationCTA();
      });
    }
  });
  window.onmessage = e => {
    const iframeURL = rocket_ajax_data.origin_url;
    if (e.origin !== iframeURL) {
      return;
    }
    setCDNFrameHeight(e.data);
    closeModal(e.data);
    tokenHandler(e.data, iframeURL);
    processStatus(e.data);
    enableCDN(e.data, iframeURL);
    disableCDN(e.data, iframeURL);
    validateTokenAndCNAME(e.data);
  };
  function openRocketCDNModal() {
    const rocketcdnIframe = document.getElementById('rocketcdn-iframe');
    if (!rocketcdnIframe || !rocketcdnIframe.dataset || !rocketcdnIframe.dataset.src || rocketcdnIframe.dataset.src === rocketcdnIframe.src) {
      return;
    }
    rocketcdnIframe.src = rocketcdnIframe.dataset.src;
    MicroModal.show('wpr-rocketcdn-modal');
  }
  function checkButtonUrlAndOpen(isCTA) {
    let iframeVisit = !window.rocketcdnButtonUrl;
    // Track CTA click if this is the pricing CTA button.
    if (isCTA) {
      trackRocketCDNUpsellCTAClicked(iframeVisit);
    }

    // Which button was actually clicked - the dashboard-tab CTA or the upsell banner CTA -
    // can only be resolved here. Reused below whether the click leads to a redirect or the
    // iframe fallback, since both paths converge on the same shared button/modal.
    const source = isCTA ? 'banner_cta' : 'dashboard_upgrade';

    // Check if button URL was injected by PHP
    if (!iframeVisit) {
      window.rocketcdnButtonUrl = setSourceParam(window.rocketcdnButtonUrl, source);

      // Small delay to ensure Mixpanel event is sent before navigation
      setTimeout(function () {
        window.location.href = window.rocketcdnButtonUrl;
      }, 100);
    } else {
      // Remembered so enableCDN() can report which CTA led to this iframe checkout.
      window.rocketcdnIframeSource = source;

      // Show iframe modal as usual
      openRocketCDNModal();
    }
  }

  /**
   * Updates the button URL with the correct is_monthly parameter based on billing cycle toggle.
   *
   * @param {boolean} isYearly - True if yearly billing is selected, false for monthly.
   */
  function updateButtonUrlBillingCycle(isYearly) {
    if (!window.rocketcdnButtonUrl || window.rocketcdnButtonUrl === '') {
      return;
    }
    window.rocketcdnButtonUrl = setIsMonthlyParam(window.rocketcdnButtonUrl, isYearly);
  }
  function maybeOpenModal() {
    let postData = '';
    postData += 'action=rocketcdn_process_status';
    postData += '&nonce=' + rocket_ajax_data.nonce;
    const request = sendHTTPRequest(postData);
    request.onreadystatechange = () => {
      if (request.readyState === XMLHttpRequest.DONE && 200 === request.status) {
        let responseTxt = JSON.parse(request.responseText);
        if (true === responseTxt.success) {
          openRocketCDNModal();
        }
      }
    };
  }
  function maybeOpenModalFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('rocketcdn_open_iframe') && '1' === urlParams.get('rocketcdn_open_iframe')) {
      // Set hash to page_cdn to show CDN tab behind modal
      window.location.hash = '#page_cdn';
      openRocketCDNModal();

      // Clean up the URL to prevent re-triggering on refresh
      urlParams.delete('rocketcdn_open_iframe');
      const search = urlParams.toString();
      const newURL = window.location.pathname + (search ? '?' + search : '') + window.location.hash;
      window.history.replaceState({}, '', newURL);
    }
  }
  function closeModal(data) {
    if (!data.hasOwnProperty('cdnFrameClose')) {
      return;
    }
    MicroModal.close('wpr-rocketcdn-modal');
    // Ensure scroll is restored
    document.body.style.overflow = '';
    let pages = ['iframe-payment-success', 'iframe-unsubscribe-success'];
    if (!data.hasOwnProperty('cdn_page_message')) {
      return;
    }
    if (pages.indexOf(data.cdn_page_message) === -1) {
      return;
    }
    window.location.hash = '#page_cdn';
    document.location.reload();
  }
  function processStatus(data) {
    if (!data.hasOwnProperty('rocketcdn_process')) {
      return;
    }
    let postData = '';
    postData += 'action=rocketcdn_process_set';
    postData += '&status=' + data.rocketcdn_process;
    postData += '&nonce=' + rocket_ajax_data.nonce;
    sendHTTPRequest(postData);
  }
  function enableCDN(data, iframeURL) {
    let iframe = document.querySelector('#rocketcdn-iframe').contentWindow;
    if (!data.hasOwnProperty('rocketcdn_url')) {
      return;
    }
    let postData = '';
    postData += 'action=rocketcdn_enable';
    postData += '&cdn_url=' + data.rocketcdn_url;
    postData += '&nonce=' + rocket_ajax_data.nonce;
    // Only set when the iframe was opened via checkButtonUrlAndOpen() - absent when the modal
    // was auto-reopened (maybeOpenModal(), maybeOpenModalFromURL()) with no click to attribute.
    // Cleared immediately after reading so a later call with no fresh click doesn't reuse it.
    if (window.rocketcdnIframeSource) {
      postData += '&source=' + window.rocketcdnIframeSource;
      delete window.rocketcdnIframeSource;
    }
    const request = sendHTTPRequest(postData);
    request.onreadystatechange = () => {
      if (request.readyState === XMLHttpRequest.DONE && 200 === request.status) {
        let responseTxt = JSON.parse(request.responseText);
        iframe.postMessage({
          'success': responseTxt.success,
          'data': responseTxt.data,
          'rocketcdn': true
        }, iframeURL);
      }
    };
  }
  function setSourceParam(url, source) {
    // The redirect-back destination is nested, URL-encoded, inside the outer URL's
    // dashboard_url param (alongside rocketcdn_checkout) - so that's where rocketcdn_source
    // has to be added too, for handle_rocketcdn_checkout_parameter() to read it back.
    try {
      const outerUrl = new URL(url);
      const dashboardUrl = outerUrl.searchParams.get('dashboard_url');
      if (!dashboardUrl) {
        return url;
      }
      const innerUrl = new URL(dashboardUrl);
      innerUrl.searchParams.set('rocketcdn_source', source);
      outerUrl.searchParams.set('dashboard_url', innerUrl.toString());
      return outerUrl.toString();
    } catch (e) {
      return url;
    }
  }
  function setIsMonthlyParam(url, isYearly) {
    // Remove any existing is_monthly param
    let newUrl = url.replace(/([?&])is_monthly=[^&]*/g, '');
    // Add the new param
    const sep = newUrl.includes('?') ? '&' : '?';
    newUrl += sep + 'is_monthly=' + (isYearly ? '0' : '1');
    return newUrl;
  }
  function disableCDN(data, iframeURL) {
    let iframe = document.querySelector('#rocketcdn-iframe').contentWindow;
    if (!data.hasOwnProperty('rocketcdn_disable')) {
      return;
    }
    let postData = '';
    postData += 'action=rocketcdn_disable';
    postData += '&nonce=' + rocket_ajax_data.nonce;
    const request = sendHTTPRequest(postData);
    request.onreadystatechange = () => {
      if (request.readyState === XMLHttpRequest.DONE && 200 === request.status) {
        let responseTxt = JSON.parse(request.responseText);
        iframe.postMessage({
          'success': responseTxt.success,
          'data': responseTxt.data,
          'rocketcdn': true
        }, iframeURL);
      }
    };
  }
  function sendHTTPRequest(postData) {
    const httpRequest = new XMLHttpRequest();
    httpRequest.open('POST', ajaxurl);
    httpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    httpRequest.send(postData);
    return httpRequest;
  }
  function setCDNFrameHeight(data) {
    if (!data.hasOwnProperty('cdnFrameHeight')) {
      return;
    }
    document.getElementById('rocketcdn-iframe').style.height = `${data.cdnFrameHeight}px`;
  }
  function tokenHandler(data, iframeURL) {
    let iframe = document.querySelector('#rocketcdn-iframe').contentWindow;
    if (!data.hasOwnProperty('rocketcdn_token')) {
      let data = {
        process: "subscribe",
        message: "token_not_received"
      };
      iframe.postMessage({
        'success': false,
        'data': data,
        'rocketcdn': true
      }, iframeURL);
      return;
    }
    let postData = '';
    postData += 'action=save_rocketcdn_token';
    postData += '&value=' + data.rocketcdn_token;
    postData += '&nonce=' + rocket_ajax_data.nonce;
    const request = sendHTTPRequest(postData);
    request.onreadystatechange = () => {
      if (request.readyState === XMLHttpRequest.DONE && 200 === request.status) {
        let responseTxt = JSON.parse(request.responseText);
        iframe.postMessage({
          'success': responseTxt.success,
          'data': responseTxt.data,
          'rocketcdn': true
        }, iframeURL);
      }
    };
  }
  function validateTokenAndCNAME(data) {
    if (!data.hasOwnProperty('rocketcdn_validate_token') || !data.hasOwnProperty('rocketcdn_validate_cname')) {
      return;
    }
    let postData = '';
    postData += 'action=rocketcdn_validate_token_cname';
    postData += '&cdn_url=' + data.rocketcdn_validate_cname;
    postData += '&cdn_token=' + data.rocketcdn_validate_token;
    postData += '&nonce=' + rocket_ajax_data.nonce;
    const request = sendHTTPRequest(postData);
  }

  /**
   * Tracks RocketCDN activation failed CTA click with Mixpanel.
   */
  function trackRocketCDNActivationCTA() {
    trackRocketCDNUpsellMixpanelEvent('RocketCDN Activation Failed CTA Clicked');
  }

  /**
   * Tracks a RocketCDN upsell event with Mixpanel.
   *
   * @param {string} eventName   The Mixpanel event name.
   * @param {Object} [extraProps] Optional additional properties to merge.
   */
  function trackRocketCDNUpsellMixpanelEvent(eventName, extraProps) {
    if (typeof mixpanel === 'undefined' || !mixpanel.track) {
      return;
    }

    // Check if user has opted in.
    if (typeof rocket_mixpanel_data === 'undefined' || !rocket_mixpanel_data.optin_enabled || rocket_mixpanel_data.optin_enabled === '0') {
      return;
    }

    // Identify user if available - best-effort only, absence shouldn't block tracking.
    if (rocket_mixpanel_data.user_id && typeof mixpanel.identify === 'function') {
      mixpanel.identify(rocket_mixpanel_data.user_id);
    }
    var cdnData = typeof rocket_cdn_mixpanel_data !== 'undefined' ? rocket_cdn_mixpanel_data : {};
    var props = {
      context: rocket_mixpanel_data.context,
      plugin: rocket_mixpanel_data.plugin,
      brand: rocket_mixpanel_data.brand,
      application: rocket_mixpanel_data.app,
      path: rocket_mixpanel_data.path,
      cdn_mode: cdnData.cdn_mode,
      cdn_status: cdnData.cdn_status,
      interaction_channel: 'UI'
    };

    // Merge extra properties if provided and valid.
    if (extraProps && typeof extraProps === 'object') {
      for (var key in extraProps) {
        if (Object.prototype.hasOwnProperty.call(extraProps, key)) {
          props[key] = extraProps[key];
        }
      }
    }
    mixpanel.track(eventName, props);
  }

  /**
   * Tracks RocketCDN upsell banner view with Mixpanel.
   *
   * @param {boolean} [is_collapsed=false] Whether the small banner variant is displayed, Sends `collapsed` when true, otherwise `opened`.
   */
  function trackRocketCDNUpsellBannerViewed(is_collapsed = false) {
    if (!isOnCDNTab()) {
      return;
    }
    const hash = window.location.hash;
    const basePath = typeof rocket_mixpanel_data !== 'undefined' && rocket_mixpanel_data.path ? rocket_mixpanel_data.path : '';
    trackRocketCDNUpsellMixpanelEvent('RocketCDN Upsell Banner Viewed', {
      state: is_collapsed ? 'collapsed' : 'opened',
      page_name: hash,
      path: basePath + hash
    });
  }

  /**
   * Tracks RocketCDN upsell banner expanded with Mixpanel.
   *
   * @param {string} trigger 'manual' by default.
   */
  function trackRocketCDNUpsellBannerExpanded(trigger) {
    trackRocketCDNUpsellMixpanelEvent('RocketCDN Upsell Banner Expanded', {
      location: window.location.hash,
      trigger: trigger
    });
  }

  /**
   * Tracks RocketCDN upsell banner collapsed with Mixpanel.
   *
   * @param {string} [trigger='manual'] 'manual' when user clicks toggle, 'auto_limit_released' when a page deletion drops count below limit.
   */
  function trackRocketCDNUpsellBannerCollapsed(trigger = 'manual') {
    trackRocketCDNUpsellMixpanelEvent('RocketCDN Upsell Banner Collapsed', {
      location: window.location.hash,
      trigger: trigger
    });
  }

  /**
   * Tracks RocketCDN upsell CTA click with Mixpanel.
   */
  function trackRocketCDNUpsellCTAClicked(iframeVisit = false) {
    const tableList = document.querySelector('.wpr-cdn-built-in .wpr-table-list');
    const pagesCount = tableList ? tableList.querySelectorAll('[data-id]').length : 0;
    trackRocketCDNUpsellMixpanelEvent('RocketCDN Upsell CTA Clicked', {
      destination: iframeVisit ? 'iframe' : 'express-checkout',
      pages_count: pagesCount
    });
  }
})(document, window);

},{}],14:[function(require,module,exports){
"use strict";

/*!
 * VERSION: 1.12.1
 * DATE: 2014-06-26
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2014, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 */
(window._gsQueue || (window._gsQueue = [])).push(function () {
  "use strict";

  window._gsDefine("TimelineLite", ["core.Animation", "core.SimpleTimeline", "TweenLite"], function (t, e, i) {
    var s = function (t) {
        e.call(this, t), this._labels = {}, this.autoRemoveChildren = this.vars.autoRemoveChildren === !0, this.smoothChildTiming = this.vars.smoothChildTiming === !0, this._sortChildren = !0, this._onUpdate = this.vars.onUpdate;
        var i,
          s,
          r = this.vars;
        for (s in r) i = r[s], a(i) && -1 !== i.join("").indexOf("{self}") && (r[s] = this._swapSelfInParams(i));
        a(r.tweens) && this.add(r.tweens, 0, r.align, r.stagger);
      },
      r = 1e-10,
      n = i._internals.isSelector,
      a = i._internals.isArray,
      o = [],
      h = window._gsDefine.globals,
      l = function (t) {
        var e,
          i = {};
        for (e in t) i[e] = t[e];
        return i;
      },
      _ = function (t, e, i, s) {
        t._timeline.pause(t._startTime), e && e.apply(s || t._timeline, i || o);
      },
      u = o.slice,
      f = s.prototype = new e();
    return s.version = "1.12.1", f.constructor = s, f.kill()._gc = !1, f.to = function (t, e, s, r) {
      var n = s.repeat && h.TweenMax || i;
      return e ? this.add(new n(t, e, s), r) : this.set(t, s, r);
    }, f.from = function (t, e, s, r) {
      return this.add((s.repeat && h.TweenMax || i).from(t, e, s), r);
    }, f.fromTo = function (t, e, s, r, n) {
      var a = r.repeat && h.TweenMax || i;
      return e ? this.add(a.fromTo(t, e, s, r), n) : this.set(t, r, n);
    }, f.staggerTo = function (t, e, r, a, o, h, _, f) {
      var p,
        c = new s({
          onComplete: h,
          onCompleteParams: _,
          onCompleteScope: f,
          smoothChildTiming: this.smoothChildTiming
        });
      for ("string" == typeof t && (t = i.selector(t) || t), n(t) && (t = u.call(t, 0)), a = a || 0, p = 0; t.length > p; p++) r.startAt && (r.startAt = l(r.startAt)), c.to(t[p], e, l(r), p * a);
      return this.add(c, o);
    }, f.staggerFrom = function (t, e, i, s, r, n, a, o) {
      return i.immediateRender = 0 != i.immediateRender, i.runBackwards = !0, this.staggerTo(t, e, i, s, r, n, a, o);
    }, f.staggerFromTo = function (t, e, i, s, r, n, a, o, h) {
      return s.startAt = i, s.immediateRender = 0 != s.immediateRender && 0 != i.immediateRender, this.staggerTo(t, e, s, r, n, a, o, h);
    }, f.call = function (t, e, s, r) {
      return this.add(i.delayedCall(0, t, e, s), r);
    }, f.set = function (t, e, s) {
      return s = this._parseTimeOrLabel(s, 0, !0), null == e.immediateRender && (e.immediateRender = s === this._time && !this._paused), this.add(new i(t, 0, e), s);
    }, s.exportRoot = function (t, e) {
      t = t || {}, null == t.smoothChildTiming && (t.smoothChildTiming = !0);
      var r,
        n,
        a = new s(t),
        o = a._timeline;
      for (null == e && (e = !0), o._remove(a, !0), a._startTime = 0, a._rawPrevTime = a._time = a._totalTime = o._time, r = o._first; r;) n = r._next, e && r instanceof i && r.target === r.vars.onComplete || a.add(r, r._startTime - r._delay), r = n;
      return o.add(a, 0), a;
    }, f.add = function (r, n, o, h) {
      var l, _, u, f, p, c;
      if ("number" != typeof n && (n = this._parseTimeOrLabel(n, 0, !0, r)), !(r instanceof t)) {
        if (r instanceof Array || r && r.push && a(r)) {
          for (o = o || "normal", h = h || 0, l = n, _ = r.length, u = 0; _ > u; u++) a(f = r[u]) && (f = new s({
            tweens: f
          })), this.add(f, l), "string" != typeof f && "function" != typeof f && ("sequence" === o ? l = f._startTime + f.totalDuration() / f._timeScale : "start" === o && (f._startTime -= f.delay())), l += h;
          return this._uncache(!0);
        }
        if ("string" == typeof r) return this.addLabel(r, n);
        if ("function" != typeof r) throw "Cannot add " + r + " into the timeline; it is not a tween, timeline, function, or string.";
        r = i.delayedCall(0, r);
      }
      if (e.prototype.add.call(this, r, n), (this._gc || this._time === this._duration) && !this._paused && this._duration < this.duration()) for (p = this, c = p.rawTime() > r._startTime; p._timeline;) c && p._timeline.smoothChildTiming ? p.totalTime(p._totalTime, !0) : p._gc && p._enabled(!0, !1), p = p._timeline;
      return this;
    }, f.remove = function (e) {
      if (e instanceof t) return this._remove(e, !1);
      if (e instanceof Array || e && e.push && a(e)) {
        for (var i = e.length; --i > -1;) this.remove(e[i]);
        return this;
      }
      return "string" == typeof e ? this.removeLabel(e) : this.kill(null, e);
    }, f._remove = function (t, i) {
      e.prototype._remove.call(this, t, i);
      var s = this._last;
      return s ? this._time > s._startTime + s._totalDuration / s._timeScale && (this._time = this.duration(), this._totalTime = this._totalDuration) : this._time = this._totalTime = this._duration = this._totalDuration = 0, this;
    }, f.append = function (t, e) {
      return this.add(t, this._parseTimeOrLabel(null, e, !0, t));
    }, f.insert = f.insertMultiple = function (t, e, i, s) {
      return this.add(t, e || 0, i, s);
    }, f.appendMultiple = function (t, e, i, s) {
      return this.add(t, this._parseTimeOrLabel(null, e, !0, t), i, s);
    }, f.addLabel = function (t, e) {
      return this._labels[t] = this._parseTimeOrLabel(e), this;
    }, f.addPause = function (t, e, i, s) {
      return this.call(_, ["{self}", e, i, s], this, t);
    }, f.removeLabel = function (t) {
      return delete this._labels[t], this;
    }, f.getLabelTime = function (t) {
      return null != this._labels[t] ? this._labels[t] : -1;
    }, f._parseTimeOrLabel = function (e, i, s, r) {
      var n;
      if (r instanceof t && r.timeline === this) this.remove(r);else if (r && (r instanceof Array || r.push && a(r))) for (n = r.length; --n > -1;) r[n] instanceof t && r[n].timeline === this && this.remove(r[n]);
      if ("string" == typeof i) return this._parseTimeOrLabel(i, s && "number" == typeof e && null == this._labels[i] ? e - this.duration() : 0, s);
      if (i = i || 0, "string" != typeof e || !isNaN(e) && null == this._labels[e]) null == e && (e = this.duration());else {
        if (n = e.indexOf("="), -1 === n) return null == this._labels[e] ? s ? this._labels[e] = this.duration() + i : i : this._labels[e] + i;
        i = parseInt(e.charAt(n - 1) + "1", 10) * Number(e.substr(n + 1)), e = n > 1 ? this._parseTimeOrLabel(e.substr(0, n - 1), 0, s) : this.duration();
      }
      return Number(e) + i;
    }, f.seek = function (t, e) {
      return this.totalTime("number" == typeof t ? t : this._parseTimeOrLabel(t), e !== !1);
    }, f.stop = function () {
      return this.paused(!0);
    }, f.gotoAndPlay = function (t, e) {
      return this.play(t, e);
    }, f.gotoAndStop = function (t, e) {
      return this.pause(t, e);
    }, f.render = function (t, e, i) {
      this._gc && this._enabled(!0, !1);
      var s,
        n,
        a,
        h,
        l,
        _ = this._dirty ? this.totalDuration() : this._totalDuration,
        u = this._time,
        f = this._startTime,
        p = this._timeScale,
        c = this._paused;
      if (t >= _ ? (this._totalTime = this._time = _, this._reversed || this._hasPausedChild() || (n = !0, h = "onComplete", 0 === this._duration && (0 === t || 0 > this._rawPrevTime || this._rawPrevTime === r) && this._rawPrevTime !== t && this._first && (l = !0, this._rawPrevTime > r && (h = "onReverseComplete"))), this._rawPrevTime = this._duration || !e || t || this._rawPrevTime === t ? t : r, t = _ + 1e-4) : 1e-7 > t ? (this._totalTime = this._time = 0, (0 !== u || 0 === this._duration && this._rawPrevTime !== r && (this._rawPrevTime > 0 || 0 > t && this._rawPrevTime >= 0)) && (h = "onReverseComplete", n = this._reversed), 0 > t ? (this._active = !1, 0 === this._duration && this._rawPrevTime >= 0 && this._first && (l = !0), this._rawPrevTime = t) : (this._rawPrevTime = this._duration || !e || t || this._rawPrevTime === t ? t : r, t = 0, this._initted || (l = !0))) : this._totalTime = this._time = this._rawPrevTime = t, this._time !== u && this._first || i || l) {
        if (this._initted || (this._initted = !0), this._active || !this._paused && this._time !== u && t > 0 && (this._active = !0), 0 === u && this.vars.onStart && 0 !== this._time && (e || this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || o)), this._time >= u) for (s = this._first; s && (a = s._next, !this._paused || c);) (s._active || s._startTime <= this._time && !s._paused && !s._gc) && (s._reversed ? s.render((s._dirty ? s.totalDuration() : s._totalDuration) - (t - s._startTime) * s._timeScale, e, i) : s.render((t - s._startTime) * s._timeScale, e, i)), s = a;else for (s = this._last; s && (a = s._prev, !this._paused || c);) (s._active || u >= s._startTime && !s._paused && !s._gc) && (s._reversed ? s.render((s._dirty ? s.totalDuration() : s._totalDuration) - (t - s._startTime) * s._timeScale, e, i) : s.render((t - s._startTime) * s._timeScale, e, i)), s = a;
        this._onUpdate && (e || this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || o)), h && (this._gc || (f === this._startTime || p !== this._timeScale) && (0 === this._time || _ >= this.totalDuration()) && (n && (this._timeline.autoRemoveChildren && this._enabled(!1, !1), this._active = !1), !e && this.vars[h] && this.vars[h].apply(this.vars[h + "Scope"] || this, this.vars[h + "Params"] || o)));
      }
    }, f._hasPausedChild = function () {
      for (var t = this._first; t;) {
        if (t._paused || t instanceof s && t._hasPausedChild()) return !0;
        t = t._next;
      }
      return !1;
    }, f.getChildren = function (t, e, s, r) {
      r = r || -9999999999;
      for (var n = [], a = this._first, o = 0; a;) r > a._startTime || (a instanceof i ? e !== !1 && (n[o++] = a) : (s !== !1 && (n[o++] = a), t !== !1 && (n = n.concat(a.getChildren(!0, e, s)), o = n.length))), a = a._next;
      return n;
    }, f.getTweensOf = function (t, e) {
      var s,
        r,
        n = this._gc,
        a = [],
        o = 0;
      for (n && this._enabled(!0, !0), s = i.getTweensOf(t), r = s.length; --r > -1;) (s[r].timeline === this || e && this._contains(s[r])) && (a[o++] = s[r]);
      return n && this._enabled(!1, !0), a;
    }, f._contains = function (t) {
      for (var e = t.timeline; e;) {
        if (e === this) return !0;
        e = e.timeline;
      }
      return !1;
    }, f.shiftChildren = function (t, e, i) {
      i = i || 0;
      for (var s, r = this._first, n = this._labels; r;) r._startTime >= i && (r._startTime += t), r = r._next;
      if (e) for (s in n) n[s] >= i && (n[s] += t);
      return this._uncache(!0);
    }, f._kill = function (t, e) {
      if (!t && !e) return this._enabled(!1, !1);
      for (var i = e ? this.getTweensOf(e) : this.getChildren(!0, !0, !1), s = i.length, r = !1; --s > -1;) i[s]._kill(t, e) && (r = !0);
      return r;
    }, f.clear = function (t) {
      var e = this.getChildren(!1, !0, !0),
        i = e.length;
      for (this._time = this._totalTime = 0; --i > -1;) e[i]._enabled(!1, !1);
      return t !== !1 && (this._labels = {}), this._uncache(!0);
    }, f.invalidate = function () {
      for (var t = this._first; t;) t.invalidate(), t = t._next;
      return this;
    }, f._enabled = function (t, i) {
      if (t === this._gc) for (var s = this._first; s;) s._enabled(t, !0), s = s._next;
      return e.prototype._enabled.call(this, t, i);
    }, f.duration = function (t) {
      return arguments.length ? (0 !== this.duration() && 0 !== t && this.timeScale(this._duration / t), this) : (this._dirty && this.totalDuration(), this._duration);
    }, f.totalDuration = function (t) {
      if (!arguments.length) {
        if (this._dirty) {
          for (var e, i, s = 0, r = this._last, n = 999999999999; r;) e = r._prev, r._dirty && r.totalDuration(), r._startTime > n && this._sortChildren && !r._paused ? this.add(r, r._startTime - r._delay) : n = r._startTime, 0 > r._startTime && !r._paused && (s -= r._startTime, this._timeline.smoothChildTiming && (this._startTime += r._startTime / this._timeScale), this.shiftChildren(-r._startTime, !1, -9999999999), n = 0), i = r._startTime + r._totalDuration / r._timeScale, i > s && (s = i), r = e;
          this._duration = this._totalDuration = s, this._dirty = !1;
        }
        return this._totalDuration;
      }
      return 0 !== this.totalDuration() && 0 !== t && this.timeScale(this._totalDuration / t), this;
    }, f.usesFrames = function () {
      for (var e = this._timeline; e._timeline;) e = e._timeline;
      return e === t._rootFramesTimeline;
    }, f.rawTime = function () {
      return this._paused ? this._totalTime : (this._timeline.rawTime() - this._startTime) * this._timeScale;
    }, s;
  }, !0);
}), window._gsDefine && window._gsQueue.pop()();

},{}],15:[function(require,module,exports){
"use strict";

/*!
 * VERSION: 1.12.1
 * DATE: 2014-06-26
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2014, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 */
(function (t) {
  "use strict";

  var e = t.GreenSockGlobals || t;
  if (!e.TweenLite) {
    var i,
      s,
      n,
      r,
      a,
      o = function (t) {
        var i,
          s = t.split("."),
          n = e;
        for (i = 0; s.length > i; i++) n[s[i]] = n = n[s[i]] || {};
        return n;
      },
      l = o("com.greensock"),
      h = 1e-10,
      _ = [].slice,
      u = function () {},
      m = function () {
        var t = Object.prototype.toString,
          e = t.call([]);
        return function (i) {
          return null != i && (i instanceof Array || "object" == typeof i && !!i.push && t.call(i) === e);
        };
      }(),
      f = {},
      p = function (i, s, n, r) {
        this.sc = f[i] ? f[i].sc : [], f[i] = this, this.gsClass = null, this.func = n;
        var a = [];
        this.check = function (l) {
          for (var h, _, u, m, c = s.length, d = c; --c > -1;) (h = f[s[c]] || new p(s[c], [])).gsClass ? (a[c] = h.gsClass, d--) : l && h.sc.push(this);
          if (0 === d && n) for (_ = ("com.greensock." + i).split("."), u = _.pop(), m = o(_.join("."))[u] = this.gsClass = n.apply(n, a), r && (e[u] = m, "function" == typeof define && define.amd ? define((t.GreenSockAMDPath ? t.GreenSockAMDPath + "/" : "") + i.split(".").join("/"), [], function () {
            return m;
          }) : "undefined" != typeof module && module.exports && (module.exports = m)), c = 0; this.sc.length > c; c++) this.sc[c].check();
        }, this.check(!0);
      },
      c = t._gsDefine = function (t, e, i, s) {
        return new p(t, e, i, s);
      },
      d = l._class = function (t, e, i) {
        return e = e || function () {}, c(t, [], function () {
          return e;
        }, i), e;
      };
    c.globals = e;
    var v = [0, 0, 1, 1],
      g = [],
      T = d("easing.Ease", function (t, e, i, s) {
        this._func = t, this._type = i || 0, this._power = s || 0, this._params = e ? v.concat(e) : v;
      }, !0),
      y = T.map = {},
      w = T.register = function (t, e, i, s) {
        for (var n, r, a, o, h = e.split(","), _ = h.length, u = (i || "easeIn,easeOut,easeInOut").split(","); --_ > -1;) for (r = h[_], n = s ? d("easing." + r, null, !0) : l.easing[r] || {}, a = u.length; --a > -1;) o = u[a], y[r + "." + o] = y[o + r] = n[o] = t.getRatio ? t : t[o] || new t();
      };
    for (n = T.prototype, n._calcEnd = !1, n.getRatio = function (t) {
      if (this._func) return this._params[0] = t, this._func.apply(null, this._params);
      var e = this._type,
        i = this._power,
        s = 1 === e ? 1 - t : 2 === e ? t : .5 > t ? 2 * t : 2 * (1 - t);
      return 1 === i ? s *= s : 2 === i ? s *= s * s : 3 === i ? s *= s * s * s : 4 === i && (s *= s * s * s * s), 1 === e ? 1 - s : 2 === e ? s : .5 > t ? s / 2 : 1 - s / 2;
    }, i = ["Linear", "Quad", "Cubic", "Quart", "Quint,Strong"], s = i.length; --s > -1;) n = i[s] + ",Power" + s, w(new T(null, null, 1, s), n, "easeOut", !0), w(new T(null, null, 2, s), n, "easeIn" + (0 === s ? ",easeNone" : "")), w(new T(null, null, 3, s), n, "easeInOut");
    y.linear = l.easing.Linear.easeIn, y.swing = l.easing.Quad.easeInOut;
    var P = d("events.EventDispatcher", function (t) {
      this._listeners = {}, this._eventTarget = t || this;
    });
    n = P.prototype, n.addEventListener = function (t, e, i, s, n) {
      n = n || 0;
      var o,
        l,
        h = this._listeners[t],
        _ = 0;
      for (null == h && (this._listeners[t] = h = []), l = h.length; --l > -1;) o = h[l], o.c === e && o.s === i ? h.splice(l, 1) : 0 === _ && n > o.pr && (_ = l + 1);
      h.splice(_, 0, {
        c: e,
        s: i,
        up: s,
        pr: n
      }), this !== r || a || r.wake();
    }, n.removeEventListener = function (t, e) {
      var i,
        s = this._listeners[t];
      if (s) for (i = s.length; --i > -1;) if (s[i].c === e) return s.splice(i, 1), void 0;
    }, n.dispatchEvent = function (t) {
      var e,
        i,
        s,
        n = this._listeners[t];
      if (n) for (e = n.length, i = this._eventTarget; --e > -1;) s = n[e], s.up ? s.c.call(s.s || i, {
        type: t,
        target: i
      }) : s.c.call(s.s || i);
    };
    var k = t.requestAnimationFrame,
      b = t.cancelAnimationFrame,
      A = Date.now || function () {
        return new Date().getTime();
      },
      S = A();
    for (i = ["ms", "moz", "webkit", "o"], s = i.length; --s > -1 && !k;) k = t[i[s] + "RequestAnimationFrame"], b = t[i[s] + "CancelAnimationFrame"] || t[i[s] + "CancelRequestAnimationFrame"];
    d("Ticker", function (t, e) {
      var i,
        s,
        n,
        o,
        l,
        _ = this,
        m = A(),
        f = e !== !1 && k,
        p = 500,
        c = 33,
        d = function (t) {
          var e,
            r,
            a = A() - S;
          a > p && (m += a - c), S += a, _.time = (S - m) / 1e3, e = _.time - l, (!i || e > 0 || t === !0) && (_.frame++, l += e + (e >= o ? .004 : o - e), r = !0), t !== !0 && (n = s(d)), r && _.dispatchEvent("tick");
        };
      P.call(_), _.time = _.frame = 0, _.tick = function () {
        d(!0);
      }, _.lagSmoothing = function (t, e) {
        p = t || 1 / h, c = Math.min(e, p, 0);
      }, _.sleep = function () {
        null != n && (f && b ? b(n) : clearTimeout(n), s = u, n = null, _ === r && (a = !1));
      }, _.wake = function () {
        null !== n ? _.sleep() : _.frame > 10 && (S = A() - p + 5), s = 0 === i ? u : f && k ? k : function (t) {
          return setTimeout(t, 0 | 1e3 * (l - _.time) + 1);
        }, _ === r && (a = !0), d(2);
      }, _.fps = function (t) {
        return arguments.length ? (i = t, o = 1 / (i || 60), l = this.time + o, _.wake(), void 0) : i;
      }, _.useRAF = function (t) {
        return arguments.length ? (_.sleep(), f = t, _.fps(i), void 0) : f;
      }, _.fps(t), setTimeout(function () {
        f && (!n || 5 > _.frame) && _.useRAF(!1);
      }, 1500);
    }), n = l.Ticker.prototype = new l.events.EventDispatcher(), n.constructor = l.Ticker;
    var x = d("core.Animation", function (t, e) {
      if (this.vars = e = e || {}, this._duration = this._totalDuration = t || 0, this._delay = Number(e.delay) || 0, this._timeScale = 1, this._active = e.immediateRender === !0, this.data = e.data, this._reversed = e.reversed === !0, B) {
        a || r.wake();
        var i = this.vars.useFrames ? Q : B;
        i.add(this, i._time), this.vars.paused && this.paused(!0);
      }
    });
    r = x.ticker = new l.Ticker(), n = x.prototype, n._dirty = n._gc = n._initted = n._paused = !1, n._totalTime = n._time = 0, n._rawPrevTime = -1, n._next = n._last = n._onUpdate = n._timeline = n.timeline = null, n._paused = !1;
    var C = function () {
      a && A() - S > 2e3 && r.wake(), setTimeout(C, 2e3);
    };
    C(), n.play = function (t, e) {
      return null != t && this.seek(t, e), this.reversed(!1).paused(!1);
    }, n.pause = function (t, e) {
      return null != t && this.seek(t, e), this.paused(!0);
    }, n.resume = function (t, e) {
      return null != t && this.seek(t, e), this.paused(!1);
    }, n.seek = function (t, e) {
      return this.totalTime(Number(t), e !== !1);
    }, n.restart = function (t, e) {
      return this.reversed(!1).paused(!1).totalTime(t ? -this._delay : 0, e !== !1, !0);
    }, n.reverse = function (t, e) {
      return null != t && this.seek(t || this.totalDuration(), e), this.reversed(!0).paused(!1);
    }, n.render = function () {}, n.invalidate = function () {
      return this;
    }, n.isActive = function () {
      var t,
        e = this._timeline,
        i = this._startTime;
      return !e || !this._gc && !this._paused && e.isActive() && (t = e.rawTime()) >= i && i + this.totalDuration() / this._timeScale > t;
    }, n._enabled = function (t, e) {
      return a || r.wake(), this._gc = !t, this._active = this.isActive(), e !== !0 && (t && !this.timeline ? this._timeline.add(this, this._startTime - this._delay) : !t && this.timeline && this._timeline._remove(this, !0)), !1;
    }, n._kill = function () {
      return this._enabled(!1, !1);
    }, n.kill = function (t, e) {
      return this._kill(t, e), this;
    }, n._uncache = function (t) {
      for (var e = t ? this : this.timeline; e;) e._dirty = !0, e = e.timeline;
      return this;
    }, n._swapSelfInParams = function (t) {
      for (var e = t.length, i = t.concat(); --e > -1;) "{self}" === t[e] && (i[e] = this);
      return i;
    }, n.eventCallback = function (t, e, i, s) {
      if ("on" === (t || "").substr(0, 2)) {
        var n = this.vars;
        if (1 === arguments.length) return n[t];
        null == e ? delete n[t] : (n[t] = e, n[t + "Params"] = m(i) && -1 !== i.join("").indexOf("{self}") ? this._swapSelfInParams(i) : i, n[t + "Scope"] = s), "onUpdate" === t && (this._onUpdate = e);
      }
      return this;
    }, n.delay = function (t) {
      return arguments.length ? (this._timeline.smoothChildTiming && this.startTime(this._startTime + t - this._delay), this._delay = t, this) : this._delay;
    }, n.duration = function (t) {
      return arguments.length ? (this._duration = this._totalDuration = t, this._uncache(!0), this._timeline.smoothChildTiming && this._time > 0 && this._time < this._duration && 0 !== t && this.totalTime(this._totalTime * (t / this._duration), !0), this) : (this._dirty = !1, this._duration);
    }, n.totalDuration = function (t) {
      return this._dirty = !1, arguments.length ? this.duration(t) : this._totalDuration;
    }, n.time = function (t, e) {
      return arguments.length ? (this._dirty && this.totalDuration(), this.totalTime(t > this._duration ? this._duration : t, e)) : this._time;
    }, n.totalTime = function (t, e, i) {
      if (a || r.wake(), !arguments.length) return this._totalTime;
      if (this._timeline) {
        if (0 > t && !i && (t += this.totalDuration()), this._timeline.smoothChildTiming) {
          this._dirty && this.totalDuration();
          var s = this._totalDuration,
            n = this._timeline;
          if (t > s && !i && (t = s), this._startTime = (this._paused ? this._pauseTime : n._time) - (this._reversed ? s - t : t) / this._timeScale, n._dirty || this._uncache(!1), n._timeline) for (; n._timeline;) n._timeline._time !== (n._startTime + n._totalTime) / n._timeScale && n.totalTime(n._totalTime, !0), n = n._timeline;
        }
        this._gc && this._enabled(!0, !1), (this._totalTime !== t || 0 === this._duration) && (this.render(t, e, !1), z.length && q());
      }
      return this;
    }, n.progress = n.totalProgress = function (t, e) {
      return arguments.length ? this.totalTime(this.duration() * t, e) : this._time / this.duration();
    }, n.startTime = function (t) {
      return arguments.length ? (t !== this._startTime && (this._startTime = t, this.timeline && this.timeline._sortChildren && this.timeline.add(this, t - this._delay)), this) : this._startTime;
    }, n.timeScale = function (t) {
      if (!arguments.length) return this._timeScale;
      if (t = t || h, this._timeline && this._timeline.smoothChildTiming) {
        var e = this._pauseTime,
          i = e || 0 === e ? e : this._timeline.totalTime();
        this._startTime = i - (i - this._startTime) * this._timeScale / t;
      }
      return this._timeScale = t, this._uncache(!1);
    }, n.reversed = function (t) {
      return arguments.length ? (t != this._reversed && (this._reversed = t, this.totalTime(this._timeline && !this._timeline.smoothChildTiming ? this.totalDuration() - this._totalTime : this._totalTime, !0)), this) : this._reversed;
    }, n.paused = function (t) {
      if (!arguments.length) return this._paused;
      if (t != this._paused && this._timeline) {
        a || t || r.wake();
        var e = this._timeline,
          i = e.rawTime(),
          s = i - this._pauseTime;
        !t && e.smoothChildTiming && (this._startTime += s, this._uncache(!1)), this._pauseTime = t ? i : null, this._paused = t, this._active = this.isActive(), !t && 0 !== s && this._initted && this.duration() && this.render(e.smoothChildTiming ? this._totalTime : (i - this._startTime) / this._timeScale, !0, !0);
      }
      return this._gc && !t && this._enabled(!0, !1), this;
    };
    var R = d("core.SimpleTimeline", function (t) {
      x.call(this, 0, t), this.autoRemoveChildren = this.smoothChildTiming = !0;
    });
    n = R.prototype = new x(), n.constructor = R, n.kill()._gc = !1, n._first = n._last = null, n._sortChildren = !1, n.add = n.insert = function (t, e) {
      var i, s;
      if (t._startTime = Number(e || 0) + t._delay, t._paused && this !== t._timeline && (t._pauseTime = t._startTime + (this.rawTime() - t._startTime) / t._timeScale), t.timeline && t.timeline._remove(t, !0), t.timeline = t._timeline = this, t._gc && t._enabled(!0, !0), i = this._last, this._sortChildren) for (s = t._startTime; i && i._startTime > s;) i = i._prev;
      return i ? (t._next = i._next, i._next = t) : (t._next = this._first, this._first = t), t._next ? t._next._prev = t : this._last = t, t._prev = i, this._timeline && this._uncache(!0), this;
    }, n._remove = function (t, e) {
      return t.timeline === this && (e || t._enabled(!1, !0), t.timeline = null, t._prev ? t._prev._next = t._next : this._first === t && (this._first = t._next), t._next ? t._next._prev = t._prev : this._last === t && (this._last = t._prev), this._timeline && this._uncache(!0)), this;
    }, n.render = function (t, e, i) {
      var s,
        n = this._first;
      for (this._totalTime = this._time = this._rawPrevTime = t; n;) s = n._next, (n._active || t >= n._startTime && !n._paused) && (n._reversed ? n.render((n._dirty ? n.totalDuration() : n._totalDuration) - (t - n._startTime) * n._timeScale, e, i) : n.render((t - n._startTime) * n._timeScale, e, i)), n = s;
    }, n.rawTime = function () {
      return a || r.wake(), this._totalTime;
    };
    var D = d("TweenLite", function (e, i, s) {
        if (x.call(this, i, s), this.render = D.prototype.render, null == e) throw "Cannot tween a null target.";
        this.target = e = "string" != typeof e ? e : D.selector(e) || e;
        var n,
          r,
          a,
          o = e.jquery || e.length && e !== t && e[0] && (e[0] === t || e[0].nodeType && e[0].style && !e.nodeType),
          l = this.vars.overwrite;
        if (this._overwrite = l = null == l ? G[D.defaultOverwrite] : "number" == typeof l ? l >> 0 : G[l], (o || e instanceof Array || e.push && m(e)) && "number" != typeof e[0]) for (this._targets = a = _.call(e, 0), this._propLookup = [], this._siblings = [], n = 0; a.length > n; n++) r = a[n], r ? "string" != typeof r ? r.length && r !== t && r[0] && (r[0] === t || r[0].nodeType && r[0].style && !r.nodeType) ? (a.splice(n--, 1), this._targets = a = a.concat(_.call(r, 0))) : (this._siblings[n] = M(r, this, !1), 1 === l && this._siblings[n].length > 1 && $(r, this, null, 1, this._siblings[n])) : (r = a[n--] = D.selector(r), "string" == typeof r && a.splice(n + 1, 1)) : a.splice(n--, 1);else this._propLookup = {}, this._siblings = M(e, this, !1), 1 === l && this._siblings.length > 1 && $(e, this, null, 1, this._siblings);
        (this.vars.immediateRender || 0 === i && 0 === this._delay && this.vars.immediateRender !== !1) && (this._time = -h, this.render(-this._delay));
      }, !0),
      I = function (e) {
        return e.length && e !== t && e[0] && (e[0] === t || e[0].nodeType && e[0].style && !e.nodeType);
      },
      E = function (t, e) {
        var i,
          s = {};
        for (i in t) j[i] || i in e && "transform" !== i && "x" !== i && "y" !== i && "width" !== i && "height" !== i && "className" !== i && "border" !== i || !(!L[i] || L[i] && L[i]._autoCSS) || (s[i] = t[i], delete t[i]);
        t.css = s;
      };
    n = D.prototype = new x(), n.constructor = D, n.kill()._gc = !1, n.ratio = 0, n._firstPT = n._targets = n._overwrittenProps = n._startAt = null, n._notifyPluginsOfEnabled = n._lazy = !1, D.version = "1.12.1", D.defaultEase = n._ease = new T(null, null, 1, 1), D.defaultOverwrite = "auto", D.ticker = r, D.autoSleep = !0, D.lagSmoothing = function (t, e) {
      r.lagSmoothing(t, e);
    }, D.selector = t.$ || t.jQuery || function (e) {
      return t.$ ? (D.selector = t.$, t.$(e)) : t.document ? t.document.getElementById("#" === e.charAt(0) ? e.substr(1) : e) : e;
    };
    var z = [],
      O = {},
      N = D._internals = {
        isArray: m,
        isSelector: I,
        lazyTweens: z
      },
      L = D._plugins = {},
      U = N.tweenLookup = {},
      F = 0,
      j = N.reservedProps = {
        ease: 1,
        delay: 1,
        overwrite: 1,
        onComplete: 1,
        onCompleteParams: 1,
        onCompleteScope: 1,
        useFrames: 1,
        runBackwards: 1,
        startAt: 1,
        onUpdate: 1,
        onUpdateParams: 1,
        onUpdateScope: 1,
        onStart: 1,
        onStartParams: 1,
        onStartScope: 1,
        onReverseComplete: 1,
        onReverseCompleteParams: 1,
        onReverseCompleteScope: 1,
        onRepeat: 1,
        onRepeatParams: 1,
        onRepeatScope: 1,
        easeParams: 1,
        yoyo: 1,
        immediateRender: 1,
        repeat: 1,
        repeatDelay: 1,
        data: 1,
        paused: 1,
        reversed: 1,
        autoCSS: 1,
        lazy: 1
      },
      G = {
        none: 0,
        all: 1,
        auto: 2,
        concurrent: 3,
        allOnStart: 4,
        preexisting: 5,
        "true": 1,
        "false": 0
      },
      Q = x._rootFramesTimeline = new R(),
      B = x._rootTimeline = new R(),
      q = function () {
        var t = z.length;
        for (O = {}; --t > -1;) i = z[t], i && i._lazy !== !1 && (i.render(i._lazy, !1, !0), i._lazy = !1);
        z.length = 0;
      };
    B._startTime = r.time, Q._startTime = r.frame, B._active = Q._active = !0, setTimeout(q, 1), x._updateRoot = D.render = function () {
      var t, e, i;
      if (z.length && q(), B.render((r.time - B._startTime) * B._timeScale, !1, !1), Q.render((r.frame - Q._startTime) * Q._timeScale, !1, !1), z.length && q(), !(r.frame % 120)) {
        for (i in U) {
          for (e = U[i].tweens, t = e.length; --t > -1;) e[t]._gc && e.splice(t, 1);
          0 === e.length && delete U[i];
        }
        if (i = B._first, (!i || i._paused) && D.autoSleep && !Q._first && 1 === r._listeners.tick.length) {
          for (; i && i._paused;) i = i._next;
          i || r.sleep();
        }
      }
    }, r.addEventListener("tick", x._updateRoot);
    var M = function (t, e, i) {
        var s,
          n,
          r = t._gsTweenID;
        if (U[r || (t._gsTweenID = r = "t" + F++)] || (U[r] = {
          target: t,
          tweens: []
        }), e && (s = U[r].tweens, s[n = s.length] = e, i)) for (; --n > -1;) s[n] === e && s.splice(n, 1);
        return U[r].tweens;
      },
      $ = function (t, e, i, s, n) {
        var r, a, o, l;
        if (1 === s || s >= 4) {
          for (l = n.length, r = 0; l > r; r++) if ((o = n[r]) !== e) o._gc || o._enabled(!1, !1) && (a = !0);else if (5 === s) break;
          return a;
        }
        var _,
          u = e._startTime + h,
          m = [],
          f = 0,
          p = 0 === e._duration;
        for (r = n.length; --r > -1;) (o = n[r]) === e || o._gc || o._paused || (o._timeline !== e._timeline ? (_ = _ || K(e, 0, p), 0 === K(o, _, p) && (m[f++] = o)) : u >= o._startTime && o._startTime + o.totalDuration() / o._timeScale > u && ((p || !o._initted) && 2e-10 >= u - o._startTime || (m[f++] = o)));
        for (r = f; --r > -1;) o = m[r], 2 === s && o._kill(i, t) && (a = !0), (2 !== s || !o._firstPT && o._initted) && o._enabled(!1, !1) && (a = !0);
        return a;
      },
      K = function (t, e, i) {
        for (var s = t._timeline, n = s._timeScale, r = t._startTime; s._timeline;) {
          if (r += s._startTime, n *= s._timeScale, s._paused) return -100;
          s = s._timeline;
        }
        return r /= n, r > e ? r - e : i && r === e || !t._initted && 2 * h > r - e ? h : (r += t.totalDuration() / t._timeScale / n) > e + h ? 0 : r - e - h;
      };
    n._init = function () {
      var t,
        e,
        i,
        s,
        n,
        r = this.vars,
        a = this._overwrittenProps,
        o = this._duration,
        l = !!r.immediateRender,
        h = r.ease;
      if (r.startAt) {
        this._startAt && (this._startAt.render(-1, !0), this._startAt.kill()), n = {};
        for (s in r.startAt) n[s] = r.startAt[s];
        if (n.overwrite = !1, n.immediateRender = !0, n.lazy = l && r.lazy !== !1, n.startAt = n.delay = null, this._startAt = D.to(this.target, 0, n), l) if (this._time > 0) this._startAt = null;else if (0 !== o) return;
      } else if (r.runBackwards && 0 !== o) if (this._startAt) this._startAt.render(-1, !0), this._startAt.kill(), this._startAt = null;else {
        i = {};
        for (s in r) j[s] && "autoCSS" !== s || (i[s] = r[s]);
        if (i.overwrite = 0, i.data = "isFromStart", i.lazy = l && r.lazy !== !1, i.immediateRender = l, this._startAt = D.to(this.target, 0, i), l) {
          if (0 === this._time) return;
        } else this._startAt._init(), this._startAt._enabled(!1);
      }
      if (this._ease = h ? h instanceof T ? r.easeParams instanceof Array ? h.config.apply(h, r.easeParams) : h : "function" == typeof h ? new T(h, r.easeParams) : y[h] || D.defaultEase : D.defaultEase, this._easeType = this._ease._type, this._easePower = this._ease._power, this._firstPT = null, this._targets) for (t = this._targets.length; --t > -1;) this._initProps(this._targets[t], this._propLookup[t] = {}, this._siblings[t], a ? a[t] : null) && (e = !0);else e = this._initProps(this.target, this._propLookup, this._siblings, a);
      if (e && D._onPluginEvent("_onInitAllProps", this), a && (this._firstPT || "function" != typeof this.target && this._enabled(!1, !1)), r.runBackwards) for (i = this._firstPT; i;) i.s += i.c, i.c = -i.c, i = i._next;
      this._onUpdate = r.onUpdate, this._initted = !0;
    }, n._initProps = function (e, i, s, n) {
      var r, a, o, l, h, _;
      if (null == e) return !1;
      O[e._gsTweenID] && q(), this.vars.css || e.style && e !== t && e.nodeType && L.css && this.vars.autoCSS !== !1 && E(this.vars, e);
      for (r in this.vars) {
        if (_ = this.vars[r], j[r]) _ && (_ instanceof Array || _.push && m(_)) && -1 !== _.join("").indexOf("{self}") && (this.vars[r] = _ = this._swapSelfInParams(_, this));else if (L[r] && (l = new L[r]())._onInitTween(e, this.vars[r], this)) {
          for (this._firstPT = h = {
            _next: this._firstPT,
            t: l,
            p: "setRatio",
            s: 0,
            c: 1,
            f: !0,
            n: r,
            pg: !0,
            pr: l._priority
          }, a = l._overwriteProps.length; --a > -1;) i[l._overwriteProps[a]] = this._firstPT;
          (l._priority || l._onInitAllProps) && (o = !0), (l._onDisable || l._onEnable) && (this._notifyPluginsOfEnabled = !0);
        } else this._firstPT = i[r] = h = {
          _next: this._firstPT,
          t: e,
          p: r,
          f: "function" == typeof e[r],
          n: r,
          pg: !1,
          pr: 0
        }, h.s = h.f ? e[r.indexOf("set") || "function" != typeof e["get" + r.substr(3)] ? r : "get" + r.substr(3)]() : parseFloat(e[r]), h.c = "string" == typeof _ && "=" === _.charAt(1) ? parseInt(_.charAt(0) + "1", 10) * Number(_.substr(2)) : Number(_) - h.s || 0;
        h && h._next && (h._next._prev = h);
      }
      return n && this._kill(n, e) ? this._initProps(e, i, s, n) : this._overwrite > 1 && this._firstPT && s.length > 1 && $(e, this, i, this._overwrite, s) ? (this._kill(i, e), this._initProps(e, i, s, n)) : (this._firstPT && (this.vars.lazy !== !1 && this._duration || this.vars.lazy && !this._duration) && (O[e._gsTweenID] = !0), o);
    }, n.render = function (t, e, i) {
      var s,
        n,
        r,
        a,
        o = this._time,
        l = this._duration,
        _ = this._rawPrevTime;
      if (t >= l) this._totalTime = this._time = l, this.ratio = this._ease._calcEnd ? this._ease.getRatio(1) : 1, this._reversed || (s = !0, n = "onComplete"), 0 === l && (this._initted || !this.vars.lazy || i) && (this._startTime === this._timeline._duration && (t = 0), (0 === t || 0 > _ || _ === h) && _ !== t && (i = !0, _ > h && (n = "onReverseComplete")), this._rawPrevTime = a = !e || t || _ === t ? t : h);else if (1e-7 > t) this._totalTime = this._time = 0, this.ratio = this._ease._calcEnd ? this._ease.getRatio(0) : 0, (0 !== o || 0 === l && _ > 0 && _ !== h) && (n = "onReverseComplete", s = this._reversed), 0 > t ? (this._active = !1, 0 === l && (this._initted || !this.vars.lazy || i) && (_ >= 0 && (i = !0), this._rawPrevTime = a = !e || t || _ === t ? t : h)) : this._initted || (i = !0);else if (this._totalTime = this._time = t, this._easeType) {
        var u = t / l,
          m = this._easeType,
          f = this._easePower;
        (1 === m || 3 === m && u >= .5) && (u = 1 - u), 3 === m && (u *= 2), 1 === f ? u *= u : 2 === f ? u *= u * u : 3 === f ? u *= u * u * u : 4 === f && (u *= u * u * u * u), this.ratio = 1 === m ? 1 - u : 2 === m ? u : .5 > t / l ? u / 2 : 1 - u / 2;
      } else this.ratio = this._ease.getRatio(t / l);
      if (this._time !== o || i) {
        if (!this._initted) {
          if (this._init(), !this._initted || this._gc) return;
          if (!i && this._firstPT && (this.vars.lazy !== !1 && this._duration || this.vars.lazy && !this._duration)) return this._time = this._totalTime = o, this._rawPrevTime = _, z.push(this), this._lazy = t, void 0;
          this._time && !s ? this.ratio = this._ease.getRatio(this._time / l) : s && this._ease._calcEnd && (this.ratio = this._ease.getRatio(0 === this._time ? 0 : 1));
        }
        for (this._lazy !== !1 && (this._lazy = !1), this._active || !this._paused && this._time !== o && t >= 0 && (this._active = !0), 0 === o && (this._startAt && (t >= 0 ? this._startAt.render(t, e, i) : n || (n = "_dummyGS")), this.vars.onStart && (0 !== this._time || 0 === l) && (e || this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || g))), r = this._firstPT; r;) r.f ? r.t[r.p](r.c * this.ratio + r.s) : r.t[r.p] = r.c * this.ratio + r.s, r = r._next;
        this._onUpdate && (0 > t && this._startAt && this._startTime && this._startAt.render(t, e, i), e || (this._time !== o || s) && this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || g)), n && (this._gc || (0 > t && this._startAt && !this._onUpdate && this._startTime && this._startAt.render(t, e, i), s && (this._timeline.autoRemoveChildren && this._enabled(!1, !1), this._active = !1), !e && this.vars[n] && this.vars[n].apply(this.vars[n + "Scope"] || this, this.vars[n + "Params"] || g), 0 === l && this._rawPrevTime === h && a !== h && (this._rawPrevTime = 0)));
      }
    }, n._kill = function (t, e) {
      if ("all" === t && (t = null), null == t && (null == e || e === this.target)) return this._lazy = !1, this._enabled(!1, !1);
      e = "string" != typeof e ? e || this._targets || this.target : D.selector(e) || e;
      var i, s, n, r, a, o, l, h;
      if ((m(e) || I(e)) && "number" != typeof e[0]) for (i = e.length; --i > -1;) this._kill(t, e[i]) && (o = !0);else {
        if (this._targets) {
          for (i = this._targets.length; --i > -1;) if (e === this._targets[i]) {
            a = this._propLookup[i] || {}, this._overwrittenProps = this._overwrittenProps || [], s = this._overwrittenProps[i] = t ? this._overwrittenProps[i] || {} : "all";
            break;
          }
        } else {
          if (e !== this.target) return !1;
          a = this._propLookup, s = this._overwrittenProps = t ? this._overwrittenProps || {} : "all";
        }
        if (a) {
          l = t || a, h = t !== s && "all" !== s && t !== a && ("object" != typeof t || !t._tempKill);
          for (n in l) (r = a[n]) && (r.pg && r.t._kill(l) && (o = !0), r.pg && 0 !== r.t._overwriteProps.length || (r._prev ? r._prev._next = r._next : r === this._firstPT && (this._firstPT = r._next), r._next && (r._next._prev = r._prev), r._next = r._prev = null), delete a[n]), h && (s[n] = 1);
          !this._firstPT && this._initted && this._enabled(!1, !1);
        }
      }
      return o;
    }, n.invalidate = function () {
      return this._notifyPluginsOfEnabled && D._onPluginEvent("_onDisable", this), this._firstPT = null, this._overwrittenProps = null, this._onUpdate = null, this._startAt = null, this._initted = this._active = this._notifyPluginsOfEnabled = this._lazy = !1, this._propLookup = this._targets ? {} : [], this;
    }, n._enabled = function (t, e) {
      if (a || r.wake(), t && this._gc) {
        var i,
          s = this._targets;
        if (s) for (i = s.length; --i > -1;) this._siblings[i] = M(s[i], this, !0);else this._siblings = M(this.target, this, !0);
      }
      return x.prototype._enabled.call(this, t, e), this._notifyPluginsOfEnabled && this._firstPT ? D._onPluginEvent(t ? "_onEnable" : "_onDisable", this) : !1;
    }, D.to = function (t, e, i) {
      return new D(t, e, i);
    }, D.from = function (t, e, i) {
      return i.runBackwards = !0, i.immediateRender = 0 != i.immediateRender, new D(t, e, i);
    }, D.fromTo = function (t, e, i, s) {
      return s.startAt = i, s.immediateRender = 0 != s.immediateRender && 0 != i.immediateRender, new D(t, e, s);
    }, D.delayedCall = function (t, e, i, s, n) {
      return new D(e, 0, {
        delay: t,
        onComplete: e,
        onCompleteParams: i,
        onCompleteScope: s,
        onReverseComplete: e,
        onReverseCompleteParams: i,
        onReverseCompleteScope: s,
        immediateRender: !1,
        useFrames: n,
        overwrite: 0
      });
    }, D.set = function (t, e) {
      return new D(t, 0, e);
    }, D.getTweensOf = function (t, e) {
      if (null == t) return [];
      t = "string" != typeof t ? t : D.selector(t) || t;
      var i, s, n, r;
      if ((m(t) || I(t)) && "number" != typeof t[0]) {
        for (i = t.length, s = []; --i > -1;) s = s.concat(D.getTweensOf(t[i], e));
        for (i = s.length; --i > -1;) for (r = s[i], n = i; --n > -1;) r === s[n] && s.splice(i, 1);
      } else for (s = M(t).concat(), i = s.length; --i > -1;) (s[i]._gc || e && !s[i].isActive()) && s.splice(i, 1);
      return s;
    }, D.killTweensOf = D.killDelayedCallsTo = function (t, e, i) {
      "object" == typeof e && (i = e, e = !1);
      for (var s = D.getTweensOf(t, e), n = s.length; --n > -1;) s[n]._kill(i, t);
    };
    var H = d("plugins.TweenPlugin", function (t, e) {
      this._overwriteProps = (t || "").split(","), this._propName = this._overwriteProps[0], this._priority = e || 0, this._super = H.prototype;
    }, !0);
    if (n = H.prototype, H.version = "1.10.1", H.API = 2, n._firstPT = null, n._addTween = function (t, e, i, s, n, r) {
      var a, o;
      return null != s && (a = "number" == typeof s || "=" !== s.charAt(1) ? Number(s) - i : parseInt(s.charAt(0) + "1", 10) * Number(s.substr(2))) ? (this._firstPT = o = {
        _next: this._firstPT,
        t: t,
        p: e,
        s: i,
        c: a,
        f: "function" == typeof t[e],
        n: n || e,
        r: r
      }, o._next && (o._next._prev = o), o) : void 0;
    }, n.setRatio = function (t) {
      for (var e, i = this._firstPT, s = 1e-6; i;) e = i.c * t + i.s, i.r ? e = Math.round(e) : s > e && e > -s && (e = 0), i.f ? i.t[i.p](e) : i.t[i.p] = e, i = i._next;
    }, n._kill = function (t) {
      var e,
        i = this._overwriteProps,
        s = this._firstPT;
      if (null != t[this._propName]) this._overwriteProps = [];else for (e = i.length; --e > -1;) null != t[i[e]] && i.splice(e, 1);
      for (; s;) null != t[s.n] && (s._next && (s._next._prev = s._prev), s._prev ? (s._prev._next = s._next, s._prev = null) : this._firstPT === s && (this._firstPT = s._next)), s = s._next;
      return !1;
    }, n._roundProps = function (t, e) {
      for (var i = this._firstPT; i;) (t[this._propName] || null != i.n && t[i.n.split(this._propName + "_").join("")]) && (i.r = e), i = i._next;
    }, D._onPluginEvent = function (t, e) {
      var i,
        s,
        n,
        r,
        a,
        o = e._firstPT;
      if ("_onInitAllProps" === t) {
        for (; o;) {
          for (a = o._next, s = n; s && s.pr > o.pr;) s = s._next;
          (o._prev = s ? s._prev : r) ? o._prev._next = o : n = o, (o._next = s) ? s._prev = o : r = o, o = a;
        }
        o = e._firstPT = n;
      }
      for (; o;) o.pg && "function" == typeof o.t[t] && o.t[t]() && (i = !0), o = o._next;
      return i;
    }, H.activate = function (t) {
      for (var e = t.length; --e > -1;) t[e].API === H.API && (L[new t[e]()._propName] = t[e]);
      return !0;
    }, c.plugin = function (t) {
      if (!(t && t.propName && t.init && t.API)) throw "illegal plugin definition.";
      var e,
        i = t.propName,
        s = t.priority || 0,
        n = t.overwriteProps,
        r = {
          init: "_onInitTween",
          set: "setRatio",
          kill: "_kill",
          round: "_roundProps",
          initAll: "_onInitAllProps"
        },
        a = d("plugins." + i.charAt(0).toUpperCase() + i.substr(1) + "Plugin", function () {
          H.call(this, i, s), this._overwriteProps = n || [];
        }, t.global === !0),
        o = a.prototype = new H(i);
      o.constructor = a, a.API = t.API;
      for (e in r) "function" == typeof t[e] && (o[r[e]] = t[e]);
      return a.version = t.version, H.activate([a]), a;
    }, i = t._gsQueue) {
      for (s = 0; i.length > s; s++) i[s]();
      for (n in f) f[n].func || t.console.log("GSAP encountered missing dependency: com.greensock." + n);
    }
    a = !1;
  }
})(window);

},{}],16:[function(require,module,exports){
"use strict";

/*!
 * VERSION: beta 1.9.3
 * DATE: 2013-04-02
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2014, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 **/
(window._gsQueue || (window._gsQueue = [])).push(function () {
  "use strict";

  window._gsDefine("easing.Back", ["easing.Ease"], function (t) {
    var e,
      i,
      s,
      r = window.GreenSockGlobals || window,
      n = r.com.greensock,
      a = 2 * Math.PI,
      o = Math.PI / 2,
      h = n._class,
      l = function (e, i) {
        var s = h("easing." + e, function () {}, !0),
          r = s.prototype = new t();
        return r.constructor = s, r.getRatio = i, s;
      },
      _ = t.register || function () {},
      u = function (t, e, i, s) {
        var r = h("easing." + t, {
          easeOut: new e(),
          easeIn: new i(),
          easeInOut: new s()
        }, !0);
        return _(r, t), r;
      },
      c = function (t, e, i) {
        this.t = t, this.v = e, i && (this.next = i, i.prev = this, this.c = i.v - e, this.gap = i.t - t);
      },
      f = function (e, i) {
        var s = h("easing." + e, function (t) {
            this._p1 = t || 0 === t ? t : 1.70158, this._p2 = 1.525 * this._p1;
          }, !0),
          r = s.prototype = new t();
        return r.constructor = s, r.getRatio = i, r.config = function (t) {
          return new s(t);
        }, s;
      },
      p = u("Back", f("BackOut", function (t) {
        return (t -= 1) * t * ((this._p1 + 1) * t + this._p1) + 1;
      }), f("BackIn", function (t) {
        return t * t * ((this._p1 + 1) * t - this._p1);
      }), f("BackInOut", function (t) {
        return 1 > (t *= 2) ? .5 * t * t * ((this._p2 + 1) * t - this._p2) : .5 * ((t -= 2) * t * ((this._p2 + 1) * t + this._p2) + 2);
      })),
      m = h("easing.SlowMo", function (t, e, i) {
        e = e || 0 === e ? e : .7, null == t ? t = .7 : t > 1 && (t = 1), this._p = 1 !== t ? e : 0, this._p1 = (1 - t) / 2, this._p2 = t, this._p3 = this._p1 + this._p2, this._calcEnd = i === !0;
      }, !0),
      d = m.prototype = new t();
    return d.constructor = m, d.getRatio = function (t) {
      var e = t + (.5 - t) * this._p;
      return this._p1 > t ? this._calcEnd ? 1 - (t = 1 - t / this._p1) * t : e - (t = 1 - t / this._p1) * t * t * t * e : t > this._p3 ? this._calcEnd ? 1 - (t = (t - this._p3) / this._p1) * t : e + (t - e) * (t = (t - this._p3) / this._p1) * t * t * t : this._calcEnd ? 1 : e;
    }, m.ease = new m(.7, .7), d.config = m.config = function (t, e, i) {
      return new m(t, e, i);
    }, e = h("easing.SteppedEase", function (t) {
      t = t || 1, this._p1 = 1 / t, this._p2 = t + 1;
    }, !0), d = e.prototype = new t(), d.constructor = e, d.getRatio = function (t) {
      return 0 > t ? t = 0 : t >= 1 && (t = .999999999), (this._p2 * t >> 0) * this._p1;
    }, d.config = e.config = function (t) {
      return new e(t);
    }, i = h("easing.RoughEase", function (e) {
      e = e || {};
      for (var i, s, r, n, a, o, h = e.taper || "none", l = [], _ = 0, u = 0 | (e.points || 20), f = u, p = e.randomize !== !1, m = e.clamp === !0, d = e.template instanceof t ? e.template : null, g = "number" == typeof e.strength ? .4 * e.strength : .4; --f > -1;) i = p ? Math.random() : 1 / u * f, s = d ? d.getRatio(i) : i, "none" === h ? r = g : "out" === h ? (n = 1 - i, r = n * n * g) : "in" === h ? r = i * i * g : .5 > i ? (n = 2 * i, r = .5 * n * n * g) : (n = 2 * (1 - i), r = .5 * n * n * g), p ? s += Math.random() * r - .5 * r : f % 2 ? s += .5 * r : s -= .5 * r, m && (s > 1 ? s = 1 : 0 > s && (s = 0)), l[_++] = {
        x: i,
        y: s
      };
      for (l.sort(function (t, e) {
        return t.x - e.x;
      }), o = new c(1, 1, null), f = u; --f > -1;) a = l[f], o = new c(a.x, a.y, o);
      this._prev = new c(0, 0, 0 !== o.t ? o : o.next);
    }, !0), d = i.prototype = new t(), d.constructor = i, d.getRatio = function (t) {
      var e = this._prev;
      if (t > e.t) {
        for (; e.next && t >= e.t;) e = e.next;
        e = e.prev;
      } else for (; e.prev && e.t >= t;) e = e.prev;
      return this._prev = e, e.v + (t - e.t) / e.gap * e.c;
    }, d.config = function (t) {
      return new i(t);
    }, i.ease = new i(), u("Bounce", l("BounceOut", function (t) {
      return 1 / 2.75 > t ? 7.5625 * t * t : 2 / 2.75 > t ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375;
    }), l("BounceIn", function (t) {
      return 1 / 2.75 > (t = 1 - t) ? 1 - 7.5625 * t * t : 2 / 2.75 > t ? 1 - (7.5625 * (t -= 1.5 / 2.75) * t + .75) : 2.5 / 2.75 > t ? 1 - (7.5625 * (t -= 2.25 / 2.75) * t + .9375) : 1 - (7.5625 * (t -= 2.625 / 2.75) * t + .984375);
    }), l("BounceInOut", function (t) {
      var e = .5 > t;
      return t = e ? 1 - 2 * t : 2 * t - 1, t = 1 / 2.75 > t ? 7.5625 * t * t : 2 / 2.75 > t ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : 2.5 / 2.75 > t ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375, e ? .5 * (1 - t) : .5 * t + .5;
    })), u("Circ", l("CircOut", function (t) {
      return Math.sqrt(1 - (t -= 1) * t);
    }), l("CircIn", function (t) {
      return -(Math.sqrt(1 - t * t) - 1);
    }), l("CircInOut", function (t) {
      return 1 > (t *= 2) ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1);
    })), s = function (e, i, s) {
      var r = h("easing." + e, function (t, e) {
          this._p1 = t || 1, this._p2 = e || s, this._p3 = this._p2 / a * (Math.asin(1 / this._p1) || 0);
        }, !0),
        n = r.prototype = new t();
      return n.constructor = r, n.getRatio = i, n.config = function (t, e) {
        return new r(t, e);
      }, r;
    }, u("Elastic", s("ElasticOut", function (t) {
      return this._p1 * Math.pow(2, -10 * t) * Math.sin((t - this._p3) * a / this._p2) + 1;
    }, .3), s("ElasticIn", function (t) {
      return -(this._p1 * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - this._p3) * a / this._p2));
    }, .3), s("ElasticInOut", function (t) {
      return 1 > (t *= 2) ? -.5 * this._p1 * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - this._p3) * a / this._p2) : .5 * this._p1 * Math.pow(2, -10 * (t -= 1)) * Math.sin((t - this._p3) * a / this._p2) + 1;
    }, .45)), u("Expo", l("ExpoOut", function (t) {
      return 1 - Math.pow(2, -10 * t);
    }), l("ExpoIn", function (t) {
      return Math.pow(2, 10 * (t - 1)) - .001;
    }), l("ExpoInOut", function (t) {
      return 1 > (t *= 2) ? .5 * Math.pow(2, 10 * (t - 1)) : .5 * (2 - Math.pow(2, -10 * (t - 1)));
    })), u("Sine", l("SineOut", function (t) {
      return Math.sin(t * o);
    }), l("SineIn", function (t) {
      return -Math.cos(t * o) + 1;
    }), l("SineInOut", function (t) {
      return -.5 * (Math.cos(Math.PI * t) - 1);
    })), h("easing.EaseLookup", {
      find: function (e) {
        return t.map[e];
      }
    }, !0), _(r.SlowMo, "SlowMo", "ease,"), _(i, "RoughEase", "ease,"), _(e, "SteppedEase", "ease,"), p;
  }, !0);
}), window._gsDefine && window._gsQueue.pop()();

},{}],17:[function(require,module,exports){
"use strict";

/*!
 * VERSION: 1.12.1
 * DATE: 2014-06-26
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2014, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 */
(window._gsQueue || (window._gsQueue = [])).push(function () {
  "use strict";

  window._gsDefine("plugins.CSSPlugin", ["plugins.TweenPlugin", "TweenLite"], function (t, e) {
    var i,
      r,
      s,
      n,
      a = function () {
        t.call(this, "css"), this._overwriteProps.length = 0, this.setRatio = a.prototype.setRatio;
      },
      o = {},
      l = a.prototype = new t("css");
    l.constructor = a, a.version = "1.12.1", a.API = 2, a.defaultTransformPerspective = 0, a.defaultSkewType = "compensated", l = "px", a.suffixMap = {
      top: l,
      right: l,
      bottom: l,
      left: l,
      width: l,
      height: l,
      fontSize: l,
      padding: l,
      margin: l,
      perspective: l,
      lineHeight: ""
    };
    var h,
      u,
      f,
      _,
      p,
      c,
      d = /(?:\d|\-\d|\.\d|\-\.\d)+/g,
      m = /(?:\d|\-\d|\.\d|\-\.\d|\+=\d|\-=\d|\+=.\d|\-=\.\d)+/g,
      g = /(?:\+=|\-=|\-|\b)[\d\-\.]+[a-zA-Z0-9]*(?:%|\b)/gi,
      v = /[^\d\-\.]/g,
      y = /(?:\d|\-|\+|=|#|\.)*/g,
      T = /opacity *= *([^)]*)/i,
      w = /opacity:([^;]*)/i,
      x = /alpha\(opacity *=.+?\)/i,
      b = /^(rgb|hsl)/,
      P = /([A-Z])/g,
      S = /-([a-z])/gi,
      C = /(^(?:url\(\"|url\())|(?:(\"\))$|\)$)/gi,
      R = function (t, e) {
        return e.toUpperCase();
      },
      k = /(?:Left|Right|Width)/i,
      A = /(M11|M12|M21|M22)=[\d\-\.e]+/gi,
      O = /progid\:DXImageTransform\.Microsoft\.Matrix\(.+?\)/i,
      D = /,(?=[^\)]*(?:\(|$))/gi,
      M = Math.PI / 180,
      L = 180 / Math.PI,
      N = {},
      X = document,
      z = X.createElement("div"),
      I = X.createElement("img"),
      E = a._internals = {
        _specialProps: o
      },
      F = navigator.userAgent,
      Y = function () {
        var t,
          e = F.indexOf("Android"),
          i = X.createElement("div");
        return f = -1 !== F.indexOf("Safari") && -1 === F.indexOf("Chrome") && (-1 === e || Number(F.substr(e + 8, 1)) > 3), p = f && 6 > Number(F.substr(F.indexOf("Version/") + 8, 1)), _ = -1 !== F.indexOf("Firefox"), /MSIE ([0-9]{1,}[\.0-9]{0,})/.exec(F) && (c = parseFloat(RegExp.$1)), i.innerHTML = "<a style='top:1px;opacity:.55;'>a</a>", t = i.getElementsByTagName("a")[0], t ? /^0.55/.test(t.style.opacity) : !1;
      }(),
      B = function (t) {
        return T.test("string" == typeof t ? t : (t.currentStyle ? t.currentStyle.filter : t.style.filter) || "") ? parseFloat(RegExp.$1) / 100 : 1;
      },
      U = function (t) {
        window.console && console.log(t);
      },
      W = "",
      j = "",
      V = function (t, e) {
        e = e || z;
        var i,
          r,
          s = e.style;
        if (void 0 !== s[t]) return t;
        for (t = t.charAt(0).toUpperCase() + t.substr(1), i = ["O", "Moz", "ms", "Ms", "Webkit"], r = 5; --r > -1 && void 0 === s[i[r] + t];);
        return r >= 0 ? (j = 3 === r ? "ms" : i[r], W = "-" + j.toLowerCase() + "-", j + t) : null;
      },
      H = X.defaultView ? X.defaultView.getComputedStyle : function () {},
      q = a.getStyle = function (t, e, i, r, s) {
        var n;
        return Y || "opacity" !== e ? (!r && t.style[e] ? n = t.style[e] : (i = i || H(t)) ? n = i[e] || i.getPropertyValue(e) || i.getPropertyValue(e.replace(P, "-$1").toLowerCase()) : t.currentStyle && (n = t.currentStyle[e]), null == s || n && "none" !== n && "auto" !== n && "auto auto" !== n ? n : s) : B(t);
      },
      Q = E.convertToPixels = function (t, i, r, s, n) {
        if ("px" === s || !s) return r;
        if ("auto" === s || !r) return 0;
        var o,
          l,
          h,
          u = k.test(i),
          f = t,
          _ = z.style,
          p = 0 > r;
        if (p && (r = -r), "%" === s && -1 !== i.indexOf("border")) o = r / 100 * (u ? t.clientWidth : t.clientHeight);else {
          if (_.cssText = "border:0 solid red;position:" + q(t, "position") + ";line-height:0;", "%" !== s && f.appendChild) _[u ? "borderLeftWidth" : "borderTopWidth"] = r + s;else {
            if (f = t.parentNode || X.body, l = f._gsCache, h = e.ticker.frame, l && u && l.time === h) return l.width * r / 100;
            _[u ? "width" : "height"] = r + s;
          }
          f.appendChild(z), o = parseFloat(z[u ? "offsetWidth" : "offsetHeight"]), f.removeChild(z), u && "%" === s && a.cacheWidths !== !1 && (l = f._gsCache = f._gsCache || {}, l.time = h, l.width = 100 * (o / r)), 0 !== o || n || (o = Q(t, i, r, s, !0));
        }
        return p ? -o : o;
      },
      Z = E.calculateOffset = function (t, e, i) {
        if ("absolute" !== q(t, "position", i)) return 0;
        var r = "left" === e ? "Left" : "Top",
          s = q(t, "margin" + r, i);
        return t["offset" + r] - (Q(t, e, parseFloat(s), s.replace(y, "")) || 0);
      },
      $ = function (t, e) {
        var i,
          r,
          s = {};
        if (e = e || H(t, null)) {
          if (i = e.length) for (; --i > -1;) s[e[i].replace(S, R)] = e.getPropertyValue(e[i]);else for (i in e) s[i] = e[i];
        } else if (e = t.currentStyle || t.style) for (i in e) "string" == typeof i && void 0 === s[i] && (s[i.replace(S, R)] = e[i]);
        return Y || (s.opacity = B(t)), r = Pe(t, e, !1), s.rotation = r.rotation, s.skewX = r.skewX, s.scaleX = r.scaleX, s.scaleY = r.scaleY, s.x = r.x, s.y = r.y, xe && (s.z = r.z, s.rotationX = r.rotationX, s.rotationY = r.rotationY, s.scaleZ = r.scaleZ), s.filters && delete s.filters, s;
      },
      G = function (t, e, i, r, s) {
        var n,
          a,
          o,
          l = {},
          h = t.style;
        for (a in i) "cssText" !== a && "length" !== a && isNaN(a) && (e[a] !== (n = i[a]) || s && s[a]) && -1 === a.indexOf("Origin") && ("number" == typeof n || "string" == typeof n) && (l[a] = "auto" !== n || "left" !== a && "top" !== a ? "" !== n && "auto" !== n && "none" !== n || "string" != typeof e[a] || "" === e[a].replace(v, "") ? n : 0 : Z(t, a), void 0 !== h[a] && (o = new fe(h, a, h[a], o)));
        if (r) for (a in r) "className" !== a && (l[a] = r[a]);
        return {
          difs: l,
          firstMPT: o
        };
      },
      K = {
        width: ["Left", "Right"],
        height: ["Top", "Bottom"]
      },
      J = ["marginLeft", "marginRight", "marginTop", "marginBottom"],
      te = function (t, e, i) {
        var r = parseFloat("width" === e ? t.offsetWidth : t.offsetHeight),
          s = K[e],
          n = s.length;
        for (i = i || H(t, null); --n > -1;) r -= parseFloat(q(t, "padding" + s[n], i, !0)) || 0, r -= parseFloat(q(t, "border" + s[n] + "Width", i, !0)) || 0;
        return r;
      },
      ee = function (t, e) {
        (null == t || "" === t || "auto" === t || "auto auto" === t) && (t = "0 0");
        var i = t.split(" "),
          r = -1 !== t.indexOf("left") ? "0%" : -1 !== t.indexOf("right") ? "100%" : i[0],
          s = -1 !== t.indexOf("top") ? "0%" : -1 !== t.indexOf("bottom") ? "100%" : i[1];
        return null == s ? s = "0" : "center" === s && (s = "50%"), ("center" === r || isNaN(parseFloat(r)) && -1 === (r + "").indexOf("=")) && (r = "50%"), e && (e.oxp = -1 !== r.indexOf("%"), e.oyp = -1 !== s.indexOf("%"), e.oxr = "=" === r.charAt(1), e.oyr = "=" === s.charAt(1), e.ox = parseFloat(r.replace(v, "")), e.oy = parseFloat(s.replace(v, ""))), r + " " + s + (i.length > 2 ? " " + i[2] : "");
      },
      ie = function (t, e) {
        return "string" == typeof t && "=" === t.charAt(1) ? parseInt(t.charAt(0) + "1", 10) * parseFloat(t.substr(2)) : parseFloat(t) - parseFloat(e);
      },
      re = function (t, e) {
        return null == t ? e : "string" == typeof t && "=" === t.charAt(1) ? parseInt(t.charAt(0) + "1", 10) * Number(t.substr(2)) + e : parseFloat(t);
      },
      se = function (t, e, i, r) {
        var s,
          n,
          a,
          o,
          l = 1e-6;
        return null == t ? o = e : "number" == typeof t ? o = t : (s = 360, n = t.split("_"), a = Number(n[0].replace(v, "")) * (-1 === t.indexOf("rad") ? 1 : L) - ("=" === t.charAt(1) ? 0 : e), n.length && (r && (r[i] = e + a), -1 !== t.indexOf("short") && (a %= s, a !== a % (s / 2) && (a = 0 > a ? a + s : a - s)), -1 !== t.indexOf("_cw") && 0 > a ? a = (a + 9999999999 * s) % s - (0 | a / s) * s : -1 !== t.indexOf("ccw") && a > 0 && (a = (a - 9999999999 * s) % s - (0 | a / s) * s)), o = e + a), l > o && o > -l && (o = 0), o;
      },
      ne = {
        aqua: [0, 255, 255],
        lime: [0, 255, 0],
        silver: [192, 192, 192],
        black: [0, 0, 0],
        maroon: [128, 0, 0],
        teal: [0, 128, 128],
        blue: [0, 0, 255],
        navy: [0, 0, 128],
        white: [255, 255, 255],
        fuchsia: [255, 0, 255],
        olive: [128, 128, 0],
        yellow: [255, 255, 0],
        orange: [255, 165, 0],
        gray: [128, 128, 128],
        purple: [128, 0, 128],
        green: [0, 128, 0],
        red: [255, 0, 0],
        pink: [255, 192, 203],
        cyan: [0, 255, 255],
        transparent: [255, 255, 255, 0]
      },
      ae = function (t, e, i) {
        return t = 0 > t ? t + 1 : t > 1 ? t - 1 : t, 0 | 255 * (1 > 6 * t ? e + 6 * (i - e) * t : .5 > t ? i : 2 > 3 * t ? e + 6 * (i - e) * (2 / 3 - t) : e) + .5;
      },
      oe = function (t) {
        var e, i, r, s, n, a;
        return t && "" !== t ? "number" == typeof t ? [t >> 16, 255 & t >> 8, 255 & t] : ("," === t.charAt(t.length - 1) && (t = t.substr(0, t.length - 1)), ne[t] ? ne[t] : "#" === t.charAt(0) ? (4 === t.length && (e = t.charAt(1), i = t.charAt(2), r = t.charAt(3), t = "#" + e + e + i + i + r + r), t = parseInt(t.substr(1), 16), [t >> 16, 255 & t >> 8, 255 & t]) : "hsl" === t.substr(0, 3) ? (t = t.match(d), s = Number(t[0]) % 360 / 360, n = Number(t[1]) / 100, a = Number(t[2]) / 100, i = .5 >= a ? a * (n + 1) : a + n - a * n, e = 2 * a - i, t.length > 3 && (t[3] = Number(t[3])), t[0] = ae(s + 1 / 3, e, i), t[1] = ae(s, e, i), t[2] = ae(s - 1 / 3, e, i), t) : (t = t.match(d) || ne.transparent, t[0] = Number(t[0]), t[1] = Number(t[1]), t[2] = Number(t[2]), t.length > 3 && (t[3] = Number(t[3])), t)) : ne.black;
      },
      le = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#.+?\\b";
    for (l in ne) le += "|" + l + "\\b";
    le = RegExp(le + ")", "gi");
    var he = function (t, e, i, r) {
        if (null == t) return function (t) {
          return t;
        };
        var s,
          n = e ? (t.match(le) || [""])[0] : "",
          a = t.split(n).join("").match(g) || [],
          o = t.substr(0, t.indexOf(a[0])),
          l = ")" === t.charAt(t.length - 1) ? ")" : "",
          h = -1 !== t.indexOf(" ") ? " " : ",",
          u = a.length,
          f = u > 0 ? a[0].replace(d, "") : "";
        return u ? s = e ? function (t) {
          var e, _, p, c;
          if ("number" == typeof t) t += f;else if (r && D.test(t)) {
            for (c = t.replace(D, "|").split("|"), p = 0; c.length > p; p++) c[p] = s(c[p]);
            return c.join(",");
          }
          if (e = (t.match(le) || [n])[0], _ = t.split(e).join("").match(g) || [], p = _.length, u > p--) for (; u > ++p;) _[p] = i ? _[0 | (p - 1) / 2] : a[p];
          return o + _.join(h) + h + e + l + (-1 !== t.indexOf("inset") ? " inset" : "");
        } : function (t) {
          var e, n, _;
          if ("number" == typeof t) t += f;else if (r && D.test(t)) {
            for (n = t.replace(D, "|").split("|"), _ = 0; n.length > _; _++) n[_] = s(n[_]);
            return n.join(",");
          }
          if (e = t.match(g) || [], _ = e.length, u > _--) for (; u > ++_;) e[_] = i ? e[0 | (_ - 1) / 2] : a[_];
          return o + e.join(h) + l;
        } : function (t) {
          return t;
        };
      },
      ue = function (t) {
        return t = t.split(","), function (e, i, r, s, n, a, o) {
          var l,
            h = (i + "").split(" ");
          for (o = {}, l = 0; 4 > l; l++) o[t[l]] = h[l] = h[l] || h[(l - 1) / 2 >> 0];
          return s.parse(e, o, n, a);
        };
      },
      fe = (E._setPluginRatio = function (t) {
        this.plugin.setRatio(t);
        for (var e, i, r, s, n = this.data, a = n.proxy, o = n.firstMPT, l = 1e-6; o;) e = a[o.v], o.r ? e = Math.round(e) : l > e && e > -l && (e = 0), o.t[o.p] = e, o = o._next;
        if (n.autoRotate && (n.autoRotate.rotation = a.rotation), 1 === t) for (o = n.firstMPT; o;) {
          if (i = o.t, i.type) {
            if (1 === i.type) {
              for (s = i.xs0 + i.s + i.xs1, r = 1; i.l > r; r++) s += i["xn" + r] + i["xs" + (r + 1)];
              i.e = s;
            }
          } else i.e = i.s + i.xs0;
          o = o._next;
        }
      }, function (t, e, i, r, s) {
        this.t = t, this.p = e, this.v = i, this.r = s, r && (r._prev = this, this._next = r);
      }),
      _e = (E._parseToProxy = function (t, e, i, r, s, n) {
        var a,
          o,
          l,
          h,
          u,
          f = r,
          _ = {},
          p = {},
          c = i._transform,
          d = N;
        for (i._transform = null, N = e, r = u = i.parse(t, e, r, s), N = d, n && (i._transform = c, f && (f._prev = null, f._prev && (f._prev._next = null))); r && r !== f;) {
          if (1 >= r.type && (o = r.p, p[o] = r.s + r.c, _[o] = r.s, n || (h = new fe(r, "s", o, h, r.r), r.c = 0), 1 === r.type)) for (a = r.l; --a > 0;) l = "xn" + a, o = r.p + "_" + l, p[o] = r.data[l], _[o] = r[l], n || (h = new fe(r, l, o, h, r.rxp[l]));
          r = r._next;
        }
        return {
          proxy: _,
          end: p,
          firstMPT: h,
          pt: u
        };
      }, E.CSSPropTween = function (t, e, r, s, a, o, l, h, u, f, _) {
        this.t = t, this.p = e, this.s = r, this.c = s, this.n = l || e, t instanceof _e || n.push(this.n), this.r = h, this.type = o || 0, u && (this.pr = u, i = !0), this.b = void 0 === f ? r : f, this.e = void 0 === _ ? r + s : _, a && (this._next = a, a._prev = this);
      }),
      pe = a.parseComplex = function (t, e, i, r, s, n, a, o, l, u) {
        i = i || n || "", a = new _e(t, e, 0, 0, a, u ? 2 : 1, null, !1, o, i, r), r += "";
        var f,
          _,
          p,
          c,
          g,
          v,
          y,
          T,
          w,
          x,
          P,
          S,
          C = i.split(", ").join(",").split(" "),
          R = r.split(", ").join(",").split(" "),
          k = C.length,
          A = h !== !1;
        for ((-1 !== r.indexOf(",") || -1 !== i.indexOf(",")) && (C = C.join(" ").replace(D, ", ").split(" "), R = R.join(" ").replace(D, ", ").split(" "), k = C.length), k !== R.length && (C = (n || "").split(" "), k = C.length), a.plugin = l, a.setRatio = u, f = 0; k > f; f++) if (c = C[f], g = R[f], T = parseFloat(c), T || 0 === T) a.appendXtra("", T, ie(g, T), g.replace(m, ""), A && -1 !== g.indexOf("px"), !0);else if (s && ("#" === c.charAt(0) || ne[c] || b.test(c))) S = "," === g.charAt(g.length - 1) ? ")," : ")", c = oe(c), g = oe(g), w = c.length + g.length > 6, w && !Y && 0 === g[3] ? (a["xs" + a.l] += a.l ? " transparent" : "transparent", a.e = a.e.split(R[f]).join("transparent")) : (Y || (w = !1), a.appendXtra(w ? "rgba(" : "rgb(", c[0], g[0] - c[0], ",", !0, !0).appendXtra("", c[1], g[1] - c[1], ",", !0).appendXtra("", c[2], g[2] - c[2], w ? "," : S, !0), w && (c = 4 > c.length ? 1 : c[3], a.appendXtra("", c, (4 > g.length ? 1 : g[3]) - c, S, !1)));else if (v = c.match(d)) {
          if (y = g.match(m), !y || y.length !== v.length) return a;
          for (p = 0, _ = 0; v.length > _; _++) P = v[_], x = c.indexOf(P, p), a.appendXtra(c.substr(p, x - p), Number(P), ie(y[_], P), "", A && "px" === c.substr(x + P.length, 2), 0 === _), p = x + P.length;
          a["xs" + a.l] += c.substr(p);
        } else a["xs" + a.l] += a.l ? " " + c : c;
        if (-1 !== r.indexOf("=") && a.data) {
          for (S = a.xs0 + a.data.s, f = 1; a.l > f; f++) S += a["xs" + f] + a.data["xn" + f];
          a.e = S + a["xs" + f];
        }
        return a.l || (a.type = -1, a.xs0 = a.e), a.xfirst || a;
      },
      ce = 9;
    for (l = _e.prototype, l.l = l.pr = 0; --ce > 0;) l["xn" + ce] = 0, l["xs" + ce] = "";
    l.xs0 = "", l._next = l._prev = l.xfirst = l.data = l.plugin = l.setRatio = l.rxp = null, l.appendXtra = function (t, e, i, r, s, n) {
      var a = this,
        o = a.l;
      return a["xs" + o] += n && o ? " " + t : t || "", i || 0 === o || a.plugin ? (a.l++, a.type = a.setRatio ? 2 : 1, a["xs" + a.l] = r || "", o > 0 ? (a.data["xn" + o] = e + i, a.rxp["xn" + o] = s, a["xn" + o] = e, a.plugin || (a.xfirst = new _e(a, "xn" + o, e, i, a.xfirst || a, 0, a.n, s, a.pr), a.xfirst.xs0 = 0), a) : (a.data = {
        s: e + i
      }, a.rxp = {}, a.s = e, a.c = i, a.r = s, a)) : (a["xs" + o] += e + (r || ""), a);
    };
    var de = function (t, e) {
        e = e || {}, this.p = e.prefix ? V(t) || t : t, o[t] = o[this.p] = this, this.format = e.formatter || he(e.defaultValue, e.color, e.collapsible, e.multi), e.parser && (this.parse = e.parser), this.clrs = e.color, this.multi = e.multi, this.keyword = e.keyword, this.dflt = e.defaultValue, this.pr = e.priority || 0;
      },
      me = E._registerComplexSpecialProp = function (t, e, i) {
        "object" != typeof e && (e = {
          parser: i
        });
        var r,
          s,
          n = t.split(","),
          a = e.defaultValue;
        for (i = i || [a], r = 0; n.length > r; r++) e.prefix = 0 === r && e.prefix, e.defaultValue = i[r] || a, s = new de(n[r], e);
      },
      ge = function (t) {
        if (!o[t]) {
          var e = t.charAt(0).toUpperCase() + t.substr(1) + "Plugin";
          me(t, {
            parser: function (t, i, r, s, n, a, l) {
              var h = (window.GreenSockGlobals || window).com.greensock.plugins[e];
              return h ? (h._cssRegister(), o[r].parse(t, i, r, s, n, a, l)) : (U("Error: " + e + " js file not loaded."), n);
            }
          });
        }
      };
    l = de.prototype, l.parseComplex = function (t, e, i, r, s, n) {
      var a,
        o,
        l,
        h,
        u,
        f,
        _ = this.keyword;
      if (this.multi && (D.test(i) || D.test(e) ? (o = e.replace(D, "|").split("|"), l = i.replace(D, "|").split("|")) : _ && (o = [e], l = [i])), l) {
        for (h = l.length > o.length ? l.length : o.length, a = 0; h > a; a++) e = o[a] = o[a] || this.dflt, i = l[a] = l[a] || this.dflt, _ && (u = e.indexOf(_), f = i.indexOf(_), u !== f && (i = -1 === f ? l : o, i[a] += " " + _));
        e = o.join(", "), i = l.join(", ");
      }
      return pe(t, this.p, e, i, this.clrs, this.dflt, r, this.pr, s, n);
    }, l.parse = function (t, e, i, r, n, a) {
      return this.parseComplex(t.style, this.format(q(t, this.p, s, !1, this.dflt)), this.format(e), n, a);
    }, a.registerSpecialProp = function (t, e, i) {
      me(t, {
        parser: function (t, r, s, n, a, o) {
          var l = new _e(t, s, 0, 0, a, 2, s, !1, i);
          return l.plugin = o, l.setRatio = e(t, r, n._tween, s), l;
        },
        priority: i
      });
    };
    var ve = "scaleX,scaleY,scaleZ,x,y,z,skewX,skewY,rotation,rotationX,rotationY,perspective".split(","),
      ye = V("transform"),
      Te = W + "transform",
      we = V("transformOrigin"),
      xe = null !== V("perspective"),
      be = E.Transform = function () {
        this.skewY = 0;
      },
      Pe = E.getTransform = function (t, e, i, r) {
        if (t._gsTransform && i && !r) return t._gsTransform;
        var s,
          n,
          o,
          l,
          h,
          u,
          f,
          _,
          p,
          c,
          d,
          m,
          g,
          v = i ? t._gsTransform || new be() : new be(),
          y = 0 > v.scaleX,
          T = 2e-5,
          w = 1e5,
          x = 179.99,
          b = x * M,
          P = xe ? parseFloat(q(t, we, e, !1, "0 0 0").split(" ")[2]) || v.zOrigin || 0 : 0;
        for (ye ? s = q(t, Te, e, !0) : t.currentStyle && (s = t.currentStyle.filter.match(A), s = s && 4 === s.length ? [s[0].substr(4), Number(s[2].substr(4)), Number(s[1].substr(4)), s[3].substr(4), v.x || 0, v.y || 0].join(",") : ""), n = (s || "").match(/(?:\-|\b)[\d\-\.e]+\b/gi) || [], o = n.length; --o > -1;) l = Number(n[o]), n[o] = (h = l - (l |= 0)) ? (0 | h * w + (0 > h ? -.5 : .5)) / w + l : l;
        if (16 === n.length) {
          var S = n[8],
            C = n[9],
            R = n[10],
            k = n[12],
            O = n[13],
            D = n[14];
          if (v.zOrigin && (D = -v.zOrigin, k = S * D - n[12], O = C * D - n[13], D = R * D + v.zOrigin - n[14]), !i || r || null == v.rotationX) {
            var N,
              X,
              z,
              I,
              E,
              F,
              Y,
              B = n[0],
              U = n[1],
              W = n[2],
              j = n[3],
              V = n[4],
              H = n[5],
              Q = n[6],
              Z = n[7],
              $ = n[11],
              G = Math.atan2(Q, R),
              K = -b > G || G > b;
            v.rotationX = G * L, G && (I = Math.cos(-G), E = Math.sin(-G), N = V * I + S * E, X = H * I + C * E, z = Q * I + R * E, S = V * -E + S * I, C = H * -E + C * I, R = Q * -E + R * I, $ = Z * -E + $ * I, V = N, H = X, Q = z), G = Math.atan2(S, B), v.rotationY = G * L, G && (F = -b > G || G > b, I = Math.cos(-G), E = Math.sin(-G), N = B * I - S * E, X = U * I - C * E, z = W * I - R * E, C = U * E + C * I, R = W * E + R * I, $ = j * E + $ * I, B = N, U = X, W = z), G = Math.atan2(U, H), v.rotation = G * L, G && (Y = -b > G || G > b, I = Math.cos(-G), E = Math.sin(-G), B = B * I + V * E, X = U * I + H * E, H = U * -E + H * I, Q = W * -E + Q * I, U = X), Y && K ? v.rotation = v.rotationX = 0 : Y && F ? v.rotation = v.rotationY = 0 : F && K && (v.rotationY = v.rotationX = 0), v.scaleX = (0 | Math.sqrt(B * B + U * U) * w + .5) / w, v.scaleY = (0 | Math.sqrt(H * H + C * C) * w + .5) / w, v.scaleZ = (0 | Math.sqrt(Q * Q + R * R) * w + .5) / w, v.skewX = 0, v.perspective = $ ? 1 / (0 > $ ? -$ : $) : 0, v.x = k, v.y = O, v.z = D;
          }
        } else if (!(xe && !r && n.length && v.x === n[4] && v.y === n[5] && (v.rotationX || v.rotationY) || void 0 !== v.x && "none" === q(t, "display", e))) {
          var J = n.length >= 6,
            te = J ? n[0] : 1,
            ee = n[1] || 0,
            ie = n[2] || 0,
            re = J ? n[3] : 1;
          v.x = n[4] || 0, v.y = n[5] || 0, u = Math.sqrt(te * te + ee * ee), f = Math.sqrt(re * re + ie * ie), _ = te || ee ? Math.atan2(ee, te) * L : v.rotation || 0, p = ie || re ? Math.atan2(ie, re) * L + _ : v.skewX || 0, c = u - Math.abs(v.scaleX || 0), d = f - Math.abs(v.scaleY || 0), Math.abs(p) > 90 && 270 > Math.abs(p) && (y ? (u *= -1, p += 0 >= _ ? 180 : -180, _ += 0 >= _ ? 180 : -180) : (f *= -1, p += 0 >= p ? 180 : -180)), m = (_ - v.rotation) % 180, g = (p - v.skewX) % 180, (void 0 === v.skewX || c > T || -T > c || d > T || -T > d || m > -x && x > m && false | m * w || g > -x && x > g && false | g * w) && (v.scaleX = u, v.scaleY = f, v.rotation = _, v.skewX = p), xe && (v.rotationX = v.rotationY = v.z = 0, v.perspective = parseFloat(a.defaultTransformPerspective) || 0, v.scaleZ = 1);
        }
        v.zOrigin = P;
        for (o in v) T > v[o] && v[o] > -T && (v[o] = 0);
        return i && (t._gsTransform = v), v;
      },
      Se = function (t) {
        var e,
          i,
          r = this.data,
          s = -r.rotation * M,
          n = s + r.skewX * M,
          a = 1e5,
          o = (0 | Math.cos(s) * r.scaleX * a) / a,
          l = (0 | Math.sin(s) * r.scaleX * a) / a,
          h = (0 | Math.sin(n) * -r.scaleY * a) / a,
          u = (0 | Math.cos(n) * r.scaleY * a) / a,
          f = this.t.style,
          _ = this.t.currentStyle;
        if (_) {
          i = l, l = -h, h = -i, e = _.filter, f.filter = "";
          var p,
            d,
            m = this.t.offsetWidth,
            g = this.t.offsetHeight,
            v = "absolute" !== _.position,
            w = "progid:DXImageTransform.Microsoft.Matrix(M11=" + o + ", M12=" + l + ", M21=" + h + ", M22=" + u,
            x = r.x,
            b = r.y;
          if (null != r.ox && (p = (r.oxp ? .01 * m * r.ox : r.ox) - m / 2, d = (r.oyp ? .01 * g * r.oy : r.oy) - g / 2, x += p - (p * o + d * l), b += d - (p * h + d * u)), v ? (p = m / 2, d = g / 2, w += ", Dx=" + (p - (p * o + d * l) + x) + ", Dy=" + (d - (p * h + d * u) + b) + ")") : w += ", sizingMethod='auto expand')", f.filter = -1 !== e.indexOf("DXImageTransform.Microsoft.Matrix(") ? e.replace(O, w) : w + " " + e, (0 === t || 1 === t) && 1 === o && 0 === l && 0 === h && 1 === u && (v && -1 === w.indexOf("Dx=0, Dy=0") || T.test(e) && 100 !== parseFloat(RegExp.$1) || -1 === e.indexOf("gradient(" && e.indexOf("Alpha")) && f.removeAttribute("filter")), !v) {
            var P,
              S,
              C,
              R = 8 > c ? 1 : -1;
            for (p = r.ieOffsetX || 0, d = r.ieOffsetY || 0, r.ieOffsetX = Math.round((m - ((0 > o ? -o : o) * m + (0 > l ? -l : l) * g)) / 2 + x), r.ieOffsetY = Math.round((g - ((0 > u ? -u : u) * g + (0 > h ? -h : h) * m)) / 2 + b), ce = 0; 4 > ce; ce++) S = J[ce], P = _[S], i = -1 !== P.indexOf("px") ? parseFloat(P) : Q(this.t, S, parseFloat(P), P.replace(y, "")) || 0, C = i !== r[S] ? 2 > ce ? -r.ieOffsetX : -r.ieOffsetY : 2 > ce ? p - r.ieOffsetX : d - r.ieOffsetY, f[S] = (r[S] = Math.round(i - C * (0 === ce || 2 === ce ? 1 : R))) + "px";
          }
        }
      },
      Ce = E.set3DTransformRatio = function (t) {
        var e,
          i,
          r,
          s,
          n,
          a,
          o,
          l,
          h,
          u,
          f,
          p,
          c,
          d,
          m,
          g,
          v,
          y,
          T,
          w,
          x,
          b,
          P,
          S = this.data,
          C = this.t.style,
          R = S.rotation * M,
          k = S.scaleX,
          A = S.scaleY,
          O = S.scaleZ,
          D = S.perspective;
        if (!(1 !== t && 0 !== t || "auto" !== S.force3D || S.rotationY || S.rotationX || 1 !== O || D || S.z)) return Re.call(this, t), void 0;
        if (_) {
          var L = 1e-4;
          L > k && k > -L && (k = O = 2e-5), L > A && A > -L && (A = O = 2e-5), !D || S.z || S.rotationX || S.rotationY || (D = 0);
        }
        if (R || S.skewX) y = Math.cos(R), T = Math.sin(R), e = y, n = T, S.skewX && (R -= S.skewX * M, y = Math.cos(R), T = Math.sin(R), "simple" === S.skewType && (w = Math.tan(S.skewX * M), w = Math.sqrt(1 + w * w), y *= w, T *= w)), i = -T, a = y;else {
          if (!(S.rotationY || S.rotationX || 1 !== O || D)) return C[ye] = "translate3d(" + S.x + "px," + S.y + "px," + S.z + "px)" + (1 !== k || 1 !== A ? " scale(" + k + "," + A + ")" : ""), void 0;
          e = a = 1, i = n = 0;
        }
        f = 1, r = s = o = l = h = u = p = c = d = 0, m = D ? -1 / D : 0, g = S.zOrigin, v = 1e5, R = S.rotationY * M, R && (y = Math.cos(R), T = Math.sin(R), h = f * -T, c = m * -T, r = e * T, o = n * T, f *= y, m *= y, e *= y, n *= y), R = S.rotationX * M, R && (y = Math.cos(R), T = Math.sin(R), w = i * y + r * T, x = a * y + o * T, b = u * y + f * T, P = d * y + m * T, r = i * -T + r * y, o = a * -T + o * y, f = u * -T + f * y, m = d * -T + m * y, i = w, a = x, u = b, d = P), 1 !== O && (r *= O, o *= O, f *= O, m *= O), 1 !== A && (i *= A, a *= A, u *= A, d *= A), 1 !== k && (e *= k, n *= k, h *= k, c *= k), g && (p -= g, s = r * p, l = o * p, p = f * p + g), s = (w = (s += S.x) - (s |= 0)) ? (0 | w * v + (0 > w ? -.5 : .5)) / v + s : s, l = (w = (l += S.y) - (l |= 0)) ? (0 | w * v + (0 > w ? -.5 : .5)) / v + l : l, p = (w = (p += S.z) - (p |= 0)) ? (0 | w * v + (0 > w ? -.5 : .5)) / v + p : p, C[ye] = "matrix3d(" + [(0 | e * v) / v, (0 | n * v) / v, (0 | h * v) / v, (0 | c * v) / v, (0 | i * v) / v, (0 | a * v) / v, (0 | u * v) / v, (0 | d * v) / v, (0 | r * v) / v, (0 | o * v) / v, (0 | f * v) / v, (0 | m * v) / v, s, l, p, D ? 1 + -p / D : 1].join(",") + ")";
      },
      Re = E.set2DTransformRatio = function (t) {
        var e,
          i,
          r,
          s,
          n,
          a = this.data,
          o = this.t,
          l = o.style;
        return a.rotationX || a.rotationY || a.z || a.force3D === !0 || "auto" === a.force3D && 1 !== t && 0 !== t ? (this.setRatio = Ce, Ce.call(this, t), void 0) : (a.rotation || a.skewX ? (e = a.rotation * M, i = e - a.skewX * M, r = 1e5, s = a.scaleX * r, n = a.scaleY * r, l[ye] = "matrix(" + (0 | Math.cos(e) * s) / r + "," + (0 | Math.sin(e) * s) / r + "," + (0 | Math.sin(i) * -n) / r + "," + (0 | Math.cos(i) * n) / r + "," + a.x + "," + a.y + ")") : l[ye] = "matrix(" + a.scaleX + ",0,0," + a.scaleY + "," + a.x + "," + a.y + ")", void 0);
      };
    me("transform,scale,scaleX,scaleY,scaleZ,x,y,z,rotation,rotationX,rotationY,rotationZ,skewX,skewY,shortRotation,shortRotationX,shortRotationY,shortRotationZ,transformOrigin,transformPerspective,directionalRotation,parseTransform,force3D,skewType", {
      parser: function (t, e, i, r, n, o, l) {
        if (r._transform) return n;
        var h,
          u,
          f,
          _,
          p,
          c,
          d,
          m = r._transform = Pe(t, s, !0, l.parseTransform),
          g = t.style,
          v = 1e-6,
          y = ve.length,
          T = l,
          w = {};
        if ("string" == typeof T.transform && ye) f = z.style, f[ye] = T.transform, f.display = "block", f.position = "absolute", X.body.appendChild(z), h = Pe(z, null, !1), X.body.removeChild(z);else if ("object" == typeof T) {
          if (h = {
            scaleX: re(null != T.scaleX ? T.scaleX : T.scale, m.scaleX),
            scaleY: re(null != T.scaleY ? T.scaleY : T.scale, m.scaleY),
            scaleZ: re(T.scaleZ, m.scaleZ),
            x: re(T.x, m.x),
            y: re(T.y, m.y),
            z: re(T.z, m.z),
            perspective: re(T.transformPerspective, m.perspective)
          }, d = T.directionalRotation, null != d) if ("object" == typeof d) for (f in d) T[f] = d[f];else T.rotation = d;
          h.rotation = se("rotation" in T ? T.rotation : "shortRotation" in T ? T.shortRotation + "_short" : "rotationZ" in T ? T.rotationZ : m.rotation, m.rotation, "rotation", w), xe && (h.rotationX = se("rotationX" in T ? T.rotationX : "shortRotationX" in T ? T.shortRotationX + "_short" : m.rotationX || 0, m.rotationX, "rotationX", w), h.rotationY = se("rotationY" in T ? T.rotationY : "shortRotationY" in T ? T.shortRotationY + "_short" : m.rotationY || 0, m.rotationY, "rotationY", w)), h.skewX = null == T.skewX ? m.skewX : se(T.skewX, m.skewX), h.skewY = null == T.skewY ? m.skewY : se(T.skewY, m.skewY), (u = h.skewY - m.skewY) && (h.skewX += u, h.rotation += u);
        }
        for (xe && null != T.force3D && (m.force3D = T.force3D, c = !0), m.skewType = T.skewType || m.skewType || a.defaultSkewType, p = m.force3D || m.z || m.rotationX || m.rotationY || h.z || h.rotationX || h.rotationY || h.perspective, p || null == T.scale || (h.scaleZ = 1); --y > -1;) i = ve[y], _ = h[i] - m[i], (_ > v || -v > _ || null != N[i]) && (c = !0, n = new _e(m, i, m[i], _, n), i in w && (n.e = w[i]), n.xs0 = 0, n.plugin = o, r._overwriteProps.push(n.n));
        return _ = T.transformOrigin, (_ || xe && p && m.zOrigin) && (ye ? (c = !0, i = we, _ = (_ || q(t, i, s, !1, "50% 50%")) + "", n = new _e(g, i, 0, 0, n, -1, "transformOrigin"), n.b = g[i], n.plugin = o, xe ? (f = m.zOrigin, _ = _.split(" "), m.zOrigin = (_.length > 2 && (0 === f || "0px" !== _[2]) ? parseFloat(_[2]) : f) || 0, n.xs0 = n.e = _[0] + " " + (_[1] || "50%") + " 0px", n = new _e(m, "zOrigin", 0, 0, n, -1, n.n), n.b = f, n.xs0 = n.e = m.zOrigin) : n.xs0 = n.e = _) : ee(_ + "", m)), c && (r._transformType = p || 3 === this._transformType ? 3 : 2), n;
      },
      prefix: !0
    }), me("boxShadow", {
      defaultValue: "0px 0px 0px 0px #999",
      prefix: !0,
      color: !0,
      multi: !0,
      keyword: "inset"
    }), me("borderRadius", {
      defaultValue: "0px",
      parser: function (t, e, i, n, a) {
        e = this.format(e);
        var o,
          l,
          h,
          u,
          f,
          _,
          p,
          c,
          d,
          m,
          g,
          v,
          y,
          T,
          w,
          x,
          b = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"],
          P = t.style;
        for (d = parseFloat(t.offsetWidth), m = parseFloat(t.offsetHeight), o = e.split(" "), l = 0; b.length > l; l++) this.p.indexOf("border") && (b[l] = V(b[l])), f = u = q(t, b[l], s, !1, "0px"), -1 !== f.indexOf(" ") && (u = f.split(" "), f = u[0], u = u[1]), _ = h = o[l], p = parseFloat(f), v = f.substr((p + "").length), y = "=" === _.charAt(1), y ? (c = parseInt(_.charAt(0) + "1", 10), _ = _.substr(2), c *= parseFloat(_), g = _.substr((c + "").length - (0 > c ? 1 : 0)) || "") : (c = parseFloat(_), g = _.substr((c + "").length)), "" === g && (g = r[i] || v), g !== v && (T = Q(t, "borderLeft", p, v), w = Q(t, "borderTop", p, v), "%" === g ? (f = 100 * (T / d) + "%", u = 100 * (w / m) + "%") : "em" === g ? (x = Q(t, "borderLeft", 1, "em"), f = T / x + "em", u = w / x + "em") : (f = T + "px", u = w + "px"), y && (_ = parseFloat(f) + c + g, h = parseFloat(u) + c + g)), a = pe(P, b[l], f + " " + u, _ + " " + h, !1, "0px", a);
        return a;
      },
      prefix: !0,
      formatter: he("0px 0px 0px 0px", !1, !0)
    }), me("backgroundPosition", {
      defaultValue: "0 0",
      parser: function (t, e, i, r, n, a) {
        var o,
          l,
          h,
          u,
          f,
          _,
          p = "background-position",
          d = s || H(t, null),
          m = this.format((d ? c ? d.getPropertyValue(p + "-x") + " " + d.getPropertyValue(p + "-y") : d.getPropertyValue(p) : t.currentStyle.backgroundPositionX + " " + t.currentStyle.backgroundPositionY) || "0 0"),
          g = this.format(e);
        if (-1 !== m.indexOf("%") != (-1 !== g.indexOf("%")) && (_ = q(t, "backgroundImage").replace(C, ""), _ && "none" !== _)) {
          for (o = m.split(" "), l = g.split(" "), I.setAttribute("src", _), h = 2; --h > -1;) m = o[h], u = -1 !== m.indexOf("%"), u !== (-1 !== l[h].indexOf("%")) && (f = 0 === h ? t.offsetWidth - I.width : t.offsetHeight - I.height, o[h] = u ? parseFloat(m) / 100 * f + "px" : 100 * (parseFloat(m) / f) + "%");
          m = o.join(" ");
        }
        return this.parseComplex(t.style, m, g, n, a);
      },
      formatter: ee
    }), me("backgroundSize", {
      defaultValue: "0 0",
      formatter: ee
    }), me("perspective", {
      defaultValue: "0px",
      prefix: !0
    }), me("perspectiveOrigin", {
      defaultValue: "50% 50%",
      prefix: !0
    }), me("transformStyle", {
      prefix: !0
    }), me("backfaceVisibility", {
      prefix: !0
    }), me("userSelect", {
      prefix: !0
    }), me("margin", {
      parser: ue("marginTop,marginRight,marginBottom,marginLeft")
    }), me("padding", {
      parser: ue("paddingTop,paddingRight,paddingBottom,paddingLeft")
    }), me("clip", {
      defaultValue: "rect(0px,0px,0px,0px)",
      parser: function (t, e, i, r, n, a) {
        var o, l, h;
        return 9 > c ? (l = t.currentStyle, h = 8 > c ? " " : ",", o = "rect(" + l.clipTop + h + l.clipRight + h + l.clipBottom + h + l.clipLeft + ")", e = this.format(e).split(",").join(h)) : (o = this.format(q(t, this.p, s, !1, this.dflt)), e = this.format(e)), this.parseComplex(t.style, o, e, n, a);
      }
    }), me("textShadow", {
      defaultValue: "0px 0px 0px #999",
      color: !0,
      multi: !0
    }), me("autoRound,strictUnits", {
      parser: function (t, e, i, r, s) {
        return s;
      }
    }), me("border", {
      defaultValue: "0px solid #000",
      parser: function (t, e, i, r, n, a) {
        return this.parseComplex(t.style, this.format(q(t, "borderTopWidth", s, !1, "0px") + " " + q(t, "borderTopStyle", s, !1, "solid") + " " + q(t, "borderTopColor", s, !1, "#000")), this.format(e), n, a);
      },
      color: !0,
      formatter: function (t) {
        var e = t.split(" ");
        return e[0] + " " + (e[1] || "solid") + " " + (t.match(le) || ["#000"])[0];
      }
    }), me("borderWidth", {
      parser: ue("borderTopWidth,borderRightWidth,borderBottomWidth,borderLeftWidth")
    }), me("float,cssFloat,styleFloat", {
      parser: function (t, e, i, r, s) {
        var n = t.style,
          a = "cssFloat" in n ? "cssFloat" : "styleFloat";
        return new _e(n, a, 0, 0, s, -1, i, !1, 0, n[a], e);
      }
    });
    var ke = function (t) {
      var e,
        i = this.t,
        r = i.filter || q(this.data, "filter"),
        s = 0 | this.s + this.c * t;
      100 === s && (-1 === r.indexOf("atrix(") && -1 === r.indexOf("radient(") && -1 === r.indexOf("oader(") ? (i.removeAttribute("filter"), e = !q(this.data, "filter")) : (i.filter = r.replace(x, ""), e = !0)), e || (this.xn1 && (i.filter = r = r || "alpha(opacity=" + s + ")"), -1 === r.indexOf("pacity") ? 0 === s && this.xn1 || (i.filter = r + " alpha(opacity=" + s + ")") : i.filter = r.replace(T, "opacity=" + s));
    };
    me("opacity,alpha,autoAlpha", {
      defaultValue: "1",
      parser: function (t, e, i, r, n, a) {
        var o = parseFloat(q(t, "opacity", s, !1, "1")),
          l = t.style,
          h = "autoAlpha" === i;
        return "string" == typeof e && "=" === e.charAt(1) && (e = ("-" === e.charAt(0) ? -1 : 1) * parseFloat(e.substr(2)) + o), h && 1 === o && "hidden" === q(t, "visibility", s) && 0 !== e && (o = 0), Y ? n = new _e(l, "opacity", o, e - o, n) : (n = new _e(l, "opacity", 100 * o, 100 * (e - o), n), n.xn1 = h ? 1 : 0, l.zoom = 1, n.type = 2, n.b = "alpha(opacity=" + n.s + ")", n.e = "alpha(opacity=" + (n.s + n.c) + ")", n.data = t, n.plugin = a, n.setRatio = ke), h && (n = new _e(l, "visibility", 0, 0, n, -1, null, !1, 0, 0 !== o ? "inherit" : "hidden", 0 === e ? "hidden" : "inherit"), n.xs0 = "inherit", r._overwriteProps.push(n.n), r._overwriteProps.push(i)), n;
      }
    });
    var Ae = function (t, e) {
        e && (t.removeProperty ? ("ms" === e.substr(0, 2) && (e = "M" + e.substr(1)), t.removeProperty(e.replace(P, "-$1").toLowerCase())) : t.removeAttribute(e));
      },
      Oe = function (t) {
        if (this.t._gsClassPT = this, 1 === t || 0 === t) {
          this.t.setAttribute("class", 0 === t ? this.b : this.e);
          for (var e = this.data, i = this.t.style; e;) e.v ? i[e.p] = e.v : Ae(i, e.p), e = e._next;
          1 === t && this.t._gsClassPT === this && (this.t._gsClassPT = null);
        } else this.t.getAttribute("class") !== this.e && this.t.setAttribute("class", this.e);
      };
    me("className", {
      parser: function (t, e, r, n, a, o, l) {
        var h,
          u,
          f,
          _,
          p,
          c = t.getAttribute("class") || "",
          d = t.style.cssText;
        if (a = n._classNamePT = new _e(t, r, 0, 0, a, 2), a.setRatio = Oe, a.pr = -11, i = !0, a.b = c, u = $(t, s), f = t._gsClassPT) {
          for (_ = {}, p = f.data; p;) _[p.p] = 1, p = p._next;
          f.setRatio(1);
        }
        return t._gsClassPT = a, a.e = "=" !== e.charAt(1) ? e : c.replace(RegExp("\\s*\\b" + e.substr(2) + "\\b"), "") + ("+" === e.charAt(0) ? " " + e.substr(2) : ""), n._tween._duration && (t.setAttribute("class", a.e), h = G(t, u, $(t), l, _), t.setAttribute("class", c), a.data = h.firstMPT, t.style.cssText = d, a = a.xfirst = n.parse(t, h.difs, a, o)), a;
      }
    });
    var De = function (t) {
      if ((1 === t || 0 === t) && this.data._totalTime === this.data._totalDuration && "isFromStart" !== this.data.data) {
        var e,
          i,
          r,
          s,
          n = this.t.style,
          a = o.transform.parse;
        if ("all" === this.e) n.cssText = "", s = !0;else for (e = this.e.split(","), r = e.length; --r > -1;) i = e[r], o[i] && (o[i].parse === a ? s = !0 : i = "transformOrigin" === i ? we : o[i].p), Ae(n, i);
        s && (Ae(n, ye), this.t._gsTransform && delete this.t._gsTransform);
      }
    };
    for (me("clearProps", {
      parser: function (t, e, r, s, n) {
        return n = new _e(t, r, 0, 0, n, 2), n.setRatio = De, n.e = e, n.pr = -10, n.data = s._tween, i = !0, n;
      }
    }), l = "bezier,throwProps,physicsProps,physics2D".split(","), ce = l.length; ce--;) ge(l[ce]);
    l = a.prototype, l._firstPT = null, l._onInitTween = function (t, e, o) {
      if (!t.nodeType) return !1;
      this._target = t, this._tween = o, this._vars = e, h = e.autoRound, i = !1, r = e.suffixMap || a.suffixMap, s = H(t, ""), n = this._overwriteProps;
      var l,
        _,
        c,
        d,
        m,
        g,
        v,
        y,
        T,
        x = t.style;
      if (u && "" === x.zIndex && (l = q(t, "zIndex", s), ("auto" === l || "" === l) && this._addLazySet(x, "zIndex", 0)), "string" == typeof e && (d = x.cssText, l = $(t, s), x.cssText = d + ";" + e, l = G(t, l, $(t)).difs, !Y && w.test(e) && (l.opacity = parseFloat(RegExp.$1)), e = l, x.cssText = d), this._firstPT = _ = this.parse(t, e, null), this._transformType) {
        for (T = 3 === this._transformType, ye ? f && (u = !0, "" === x.zIndex && (v = q(t, "zIndex", s), ("auto" === v || "" === v) && this._addLazySet(x, "zIndex", 0)), p && this._addLazySet(x, "WebkitBackfaceVisibility", this._vars.WebkitBackfaceVisibility || (T ? "visible" : "hidden"))) : x.zoom = 1, c = _; c && c._next;) c = c._next;
        y = new _e(t, "transform", 0, 0, null, 2), this._linkCSSP(y, null, c), y.setRatio = T && xe ? Ce : ye ? Re : Se, y.data = this._transform || Pe(t, s, !0), n.pop();
      }
      if (i) {
        for (; _;) {
          for (g = _._next, c = d; c && c.pr > _.pr;) c = c._next;
          (_._prev = c ? c._prev : m) ? _._prev._next = _ : d = _, (_._next = c) ? c._prev = _ : m = _, _ = g;
        }
        this._firstPT = d;
      }
      return !0;
    }, l.parse = function (t, e, i, n) {
      var a,
        l,
        u,
        f,
        _,
        p,
        c,
        d,
        m,
        g,
        v = t.style;
      for (a in e) p = e[a], l = o[a], l ? i = l.parse(t, p, a, this, i, n, e) : (_ = q(t, a, s) + "", m = "string" == typeof p, "color" === a || "fill" === a || "stroke" === a || -1 !== a.indexOf("Color") || m && b.test(p) ? (m || (p = oe(p), p = (p.length > 3 ? "rgba(" : "rgb(") + p.join(",") + ")"), i = pe(v, a, _, p, !0, "transparent", i, 0, n)) : !m || -1 === p.indexOf(" ") && -1 === p.indexOf(",") ? (u = parseFloat(_), c = u || 0 === u ? _.substr((u + "").length) : "", ("" === _ || "auto" === _) && ("width" === a || "height" === a ? (u = te(t, a, s), c = "px") : "left" === a || "top" === a ? (u = Z(t, a, s), c = "px") : (u = "opacity" !== a ? 0 : 1, c = "")), g = m && "=" === p.charAt(1), g ? (f = parseInt(p.charAt(0) + "1", 10), p = p.substr(2), f *= parseFloat(p), d = p.replace(y, "")) : (f = parseFloat(p), d = m ? p.substr((f + "").length) || "" : ""), "" === d && (d = a in r ? r[a] : c), p = f || 0 === f ? (g ? f + u : f) + d : e[a], c !== d && "" !== d && (f || 0 === f) && u && (u = Q(t, a, u, c), "%" === d ? (u /= Q(t, a, 100, "%") / 100, e.strictUnits !== !0 && (_ = u + "%")) : "em" === d ? u /= Q(t, a, 1, "em") : "px" !== d && (f = Q(t, a, f, d), d = "px"), g && (f || 0 === f) && (p = f + u + d)), g && (f += u), !u && 0 !== u || !f && 0 !== f ? void 0 !== v[a] && (p || "NaN" != p + "" && null != p) ? (i = new _e(v, a, f || u || 0, 0, i, -1, a, !1, 0, _, p), i.xs0 = "none" !== p || "display" !== a && -1 === a.indexOf("Style") ? p : _) : U("invalid " + a + " tween value: " + e[a]) : (i = new _e(v, a, u, f - u, i, 0, a, h !== !1 && ("px" === d || "zIndex" === a), 0, _, p), i.xs0 = d)) : i = pe(v, a, _, p, !0, null, i, 0, n)), n && i && !i.plugin && (i.plugin = n);
      return i;
    }, l.setRatio = function (t) {
      var e,
        i,
        r,
        s = this._firstPT,
        n = 1e-6;
      if (1 !== t || this._tween._time !== this._tween._duration && 0 !== this._tween._time) {
        if (t || this._tween._time !== this._tween._duration && 0 !== this._tween._time || this._tween._rawPrevTime === -1e-6) for (; s;) {
          if (e = s.c * t + s.s, s.r ? e = Math.round(e) : n > e && e > -n && (e = 0), s.type) {
            if (1 === s.type) {
              if (r = s.l, 2 === r) s.t[s.p] = s.xs0 + e + s.xs1 + s.xn1 + s.xs2;else if (3 === r) s.t[s.p] = s.xs0 + e + s.xs1 + s.xn1 + s.xs2 + s.xn2 + s.xs3;else if (4 === r) s.t[s.p] = s.xs0 + e + s.xs1 + s.xn1 + s.xs2 + s.xn2 + s.xs3 + s.xn3 + s.xs4;else if (5 === r) s.t[s.p] = s.xs0 + e + s.xs1 + s.xn1 + s.xs2 + s.xn2 + s.xs3 + s.xn3 + s.xs4 + s.xn4 + s.xs5;else {
                for (i = s.xs0 + e + s.xs1, r = 1; s.l > r; r++) i += s["xn" + r] + s["xs" + (r + 1)];
                s.t[s.p] = i;
              }
            } else -1 === s.type ? s.t[s.p] = s.xs0 : s.setRatio && s.setRatio(t);
          } else s.t[s.p] = e + s.xs0;
          s = s._next;
        } else for (; s;) 2 !== s.type ? s.t[s.p] = s.b : s.setRatio(t), s = s._next;
      } else for (; s;) 2 !== s.type ? s.t[s.p] = s.e : s.setRatio(t), s = s._next;
    }, l._enableTransforms = function (t) {
      this._transformType = t || 3 === this._transformType ? 3 : 2, this._transform = this._transform || Pe(this._target, s, !0);
    };
    var Me = function () {
      this.t[this.p] = this.e, this.data._linkCSSP(this, this._next, null, !0);
    };
    l._addLazySet = function (t, e, i) {
      var r = this._firstPT = new _e(t, e, 0, 0, this._firstPT, 2);
      r.e = i, r.setRatio = Me, r.data = this;
    }, l._linkCSSP = function (t, e, i, r) {
      return t && (e && (e._prev = t), t._next && (t._next._prev = t._prev), t._prev ? t._prev._next = t._next : this._firstPT === t && (this._firstPT = t._next, r = !0), i ? i._next = t : r || null !== this._firstPT || (this._firstPT = t), t._next = e, t._prev = i), t;
    }, l._kill = function (e) {
      var i,
        r,
        s,
        n = e;
      if (e.autoAlpha || e.alpha) {
        n = {};
        for (r in e) n[r] = e[r];
        n.opacity = 1, n.autoAlpha && (n.visibility = 1);
      }
      return e.className && (i = this._classNamePT) && (s = i.xfirst, s && s._prev ? this._linkCSSP(s._prev, i._next, s._prev._prev) : s === this._firstPT && (this._firstPT = i._next), i._next && this._linkCSSP(i._next, i._next._next, s._prev), this._classNamePT = null), t.prototype._kill.call(this, n);
    };
    var Le = function (t, e, i) {
      var r, s, n, a;
      if (t.slice) for (s = t.length; --s > -1;) Le(t[s], e, i);else for (r = t.childNodes, s = r.length; --s > -1;) n = r[s], a = n.type, n.style && (e.push($(n)), i && i.push(n)), 1 !== a && 9 !== a && 11 !== a || !n.childNodes.length || Le(n, e, i);
    };
    return a.cascadeTo = function (t, i, r) {
      var s,
        n,
        a,
        o = e.to(t, i, r),
        l = [o],
        h = [],
        u = [],
        f = [],
        _ = e._internals.reservedProps;
      for (t = o._targets || o.target, Le(t, h, f), o.render(i, !0), Le(t, u), o.render(0, !0), o._enabled(!0), s = f.length; --s > -1;) if (n = G(f[s], h[s], u[s]), n.firstMPT) {
        n = n.difs;
        for (a in r) _[a] && (n[a] = r[a]);
        l.push(e.to(f[s], i, n));
      }
      return l;
    }, t.activate([a]), a;
  }, !0);
}), window._gsDefine && window._gsQueue.pop()();

},{}],18:[function(require,module,exports){
"use strict";

/*!
 * VERSION: 1.7.3
 * DATE: 2014-01-14
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2014, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 **/
(window._gsQueue || (window._gsQueue = [])).push(function () {
  "use strict";

  var t = document.documentElement,
    e = window,
    i = function (i, s) {
      var r = "x" === s ? "Width" : "Height",
        n = "scroll" + r,
        a = "client" + r,
        o = document.body;
      return i === e || i === t || i === o ? Math.max(t[n], o[n]) - (e["inner" + r] || Math.max(t[a], o[a])) : i[n] - i["offset" + r];
    },
    s = window._gsDefine.plugin({
      propName: "scrollTo",
      API: 2,
      version: "1.7.3",
      init: function (t, s, r) {
        return this._wdw = t === e, this._target = t, this._tween = r, "object" != typeof s && (s = {
          y: s
        }), this._autoKill = s.autoKill !== !1, this.x = this.xPrev = this.getX(), this.y = this.yPrev = this.getY(), null != s.x ? (this._addTween(this, "x", this.x, "max" === s.x ? i(t, "x") : s.x, "scrollTo_x", !0), this._overwriteProps.push("scrollTo_x")) : this.skipX = !0, null != s.y ? (this._addTween(this, "y", this.y, "max" === s.y ? i(t, "y") : s.y, "scrollTo_y", !0), this._overwriteProps.push("scrollTo_y")) : this.skipY = !0, !0;
      },
      set: function (t) {
        this._super.setRatio.call(this, t);
        var s = this._wdw || !this.skipX ? this.getX() : this.xPrev,
          r = this._wdw || !this.skipY ? this.getY() : this.yPrev,
          n = r - this.yPrev,
          a = s - this.xPrev;
        this._autoKill && (!this.skipX && (a > 7 || -7 > a) && i(this._target, "x") > s && (this.skipX = !0), !this.skipY && (n > 7 || -7 > n) && i(this._target, "y") > r && (this.skipY = !0), this.skipX && this.skipY && this._tween.kill()), this._wdw ? e.scrollTo(this.skipX ? s : this.x, this.skipY ? r : this.y) : (this.skipY || (this._target.scrollTop = this.y), this.skipX || (this._target.scrollLeft = this.x)), this.xPrev = this.x, this.yPrev = this.y;
      }
    }),
    r = s.prototype;
  s.max = i, r.getX = function () {
    return this._wdw ? null != e.pageXOffset ? e.pageXOffset : null != t.scrollLeft ? t.scrollLeft : document.body.scrollLeft : this._target.scrollLeft;
  }, r.getY = function () {
    return this._wdw ? null != e.pageYOffset ? e.pageYOffset : null != t.scrollTop ? t.scrollTop : document.body.scrollTop : this._target.scrollTop;
  }, r._kill = function (t) {
    return t.scrollTo_x && (this.skipX = !0), t.scrollTo_y && (this.skipY = !0), this._super._kill.call(this, t);
  };
}), window._gsDefine && window._gsQueue.pop()();

},{}]},{},[3])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvanMvY3VzdG9tL2N1c3RvbS1zZWxlY3QuanMiLCJzcmMvanMvZ2xvYmFsL2FqYXguanMiLCJzcmMvanMvZ2xvYmFsL2FwcC5qcyIsInNyYy9qcy9nbG9iYWwvYmVhY29uLmpzIiwic3JjL2pzL2dsb2JhbC9jZG4tZHJpdmVyLmpzIiwic3JjL2pzL2dsb2JhbC9jb3VudGRvd24uanMiLCJzcmMvanMvZ2xvYmFsL2ZpZWxkcy5qcyIsInNyYy9qcy9nbG9iYWwvbWFpbi5qcyIsInNyYy9qcy9nbG9iYWwvbWl4cGFuZWwuanMiLCJzcmMvanMvZ2xvYmFsL3BhZ2VNYW5hZ2VyLmpzIiwic3JjL2pzL2dsb2JhbC9yZWNvbW1lbmRhdGlvbnMtd2lkZ2V0LmpzIiwic3JjL2pzL2dsb2JhbC9yb2NrZXRjZG4tc3Vic2NyaXB0aW9uLXBvbGxpbmcuanMiLCJzcmMvanMvZ2xvYmFsL3JvY2tldGNkbi5qcyIsInNyYy9qcy9saWIvZ3JlZW5zb2NrL1RpbWVsaW5lTGl0ZS5taW4uanMiLCJzcmMvanMvbGliL2dyZWVuc29jay9Ud2VlbkxpdGUubWluLmpzIiwic3JjL2pzL2xpYi9ncmVlbnNvY2svZWFzaW5nL0Vhc2VQYWNrLm1pbi5qcyIsInNyYy9qcy9saWIvZ3JlZW5zb2NrL3BsdWdpbnMvQ1NTUGx1Z2luLm1pbi5qcyIsInNyYy9qcy9saWIvZ3JlZW5zb2NrL3BsdWdpbnMvU2Nyb2xsVG9QbHVnaW4ubWluLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7QUNBQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJO0VBQ25FLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7RUFDOUQsTUFBTSxhQUFhLEdBQUcsWUFBWSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztFQUNuRSxNQUFNLE9BQU8sR0FBRyxTQUFBLENBQVMsR0FBRyxFQUFFO0lBQzdCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxXQUFXLENBQUMsc0JBQXNCLEVBQUU7TUFDakUsTUFBTSxFQUFFO1FBQ1AsY0FBYyxFQUFFO01BQ2pCO0lBQ0QsQ0FBQyxDQUFDO0lBQ0YsYUFBYSxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUMsV0FBVztJQUMzQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7SUFDdkMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztFQUU5QyxDQUFDO0VBQ0QsU0FBUyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNO0lBQ3pDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztJQUN2QyxTQUFTLENBQUMsWUFBWSxDQUNyQixlQUFlLEVBQ2YsU0FBUyxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsS0FBSyxNQUFNLEdBQUcsT0FBTyxHQUFHLE1BQ2hFLENBQUM7RUFDRixDQUFDLENBQUM7RUFFRixZQUFZLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQ2xELElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFFOUIsTUFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQztNQUNwRCxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztNQUN6RCxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7TUFFMUMsSUFBSSxXQUFXLEVBQUU7UUFDaEIsV0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ25DLE9BQU8sQ0FBQyxXQUFXLENBQUM7TUFDckI7SUFDRDtFQUNELENBQUMsQ0FBQztFQUNGLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUcsQ0FBQyxJQUFLO0lBQ3pDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTtNQUNyQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7TUFDdkMsU0FBUyxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQ2pEO0VBQ0QsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDOzs7OztBQ3pDRixJQUFJLENBQUMsR0FBRyxNQUFNO0FBQ2QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFVO0VBQ3hCO0FBQ0o7QUFDQTtFQUNJLElBQUksYUFBYSxHQUFHLEtBQUs7RUFDekIsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTLENBQUMsRUFBRTtJQUNyRCxJQUFHLENBQUMsYUFBYSxFQUFDO01BQ2QsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztNQUNwQixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsbUJBQW1CLENBQUM7TUFDcEMsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixDQUFDO01BRXRDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztNQUNsQixhQUFhLEdBQUcsSUFBSTtNQUNwQixNQUFNLENBQUMsT0FBTyxDQUFFLE1BQU8sQ0FBQzs7TUFFakM7TUFDUyxNQUFNLENBQUMsV0FBVyxDQUFDLDJCQUEyQixDQUFDO01BRS9DLENBQUMsQ0FBQyxJQUFJLENBQ0YsT0FBTyxFQUNQO1FBQ0ksTUFBTSxFQUFFLDhCQUE4QjtRQUN0QyxXQUFXLEVBQUUsZ0JBQWdCLENBQUM7TUFDbEMsQ0FBQyxFQUNELFVBQVMsUUFBUSxFQUFFO1FBQ2YsTUFBTSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUM7UUFDbkMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7UUFFL0IsSUFBSyxJQUFJLEtBQUssUUFBUSxDQUFDLE9BQU8sRUFBRztVQUM3QixPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1VBQ3hDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztVQUNyRyxJQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQUc7WUFDeEIsUUFBUSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLHdCQUF3QjtVQUN4RztVQUNBLFVBQVUsQ0FBQyxZQUFXO1lBQ2xCLE1BQU0sQ0FBQyxXQUFXLENBQUMsK0JBQStCLENBQUM7WUFDbkQsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQztVQUNyQyxDQUFDLEVBQUUsR0FBRyxDQUFDO1FBQ1gsQ0FBQyxNQUNHO1VBQ0EsVUFBVSxDQUFDLFlBQVc7WUFDbEIsTUFBTSxDQUFDLFdBQVcsQ0FBQywrQkFBK0IsQ0FBQztZQUNuRCxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDO1VBQ3JDLENBQUMsRUFBRSxHQUFHLENBQUM7UUFDWDtRQUVBLFVBQVUsQ0FBQyxZQUFXO1VBQ2xCLElBQUksR0FBRyxHQUFHLElBQUksWUFBWSxDQUFDO1lBQUMsVUFBVSxFQUFDLFNBQUEsQ0FBQSxFQUFVO2NBQzdDLGFBQWEsR0FBRyxLQUFLO1lBQ3pCO1VBQUMsQ0FBQyxDQUFDLENBQ0EsR0FBRyxDQUFDLE1BQU0sRUFBRTtZQUFDLEdBQUcsRUFBQztjQUFDLFNBQVMsRUFBQztZQUFnQjtVQUFDLENBQUMsQ0FBQyxDQUMvQyxHQUFHLENBQUMsTUFBTSxFQUFFO1lBQUMsR0FBRyxFQUFDO2NBQUMsU0FBUyxFQUFDO1lBQWtCO1VBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUN2RCxHQUFHLENBQUMsTUFBTSxFQUFFO1lBQUMsR0FBRyxFQUFDO2NBQUMsU0FBUyxFQUFDO1lBQWtCO1VBQUMsQ0FBQyxDQUFDLENBQ2pELEdBQUcsQ0FBQyxNQUFNLEVBQUU7WUFBQyxHQUFHLEVBQUM7Y0FBQyxTQUFTLEVBQUM7WUFBb0I7VUFBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQ3pELEdBQUcsQ0FBQyxNQUFNLEVBQUU7WUFBQyxHQUFHLEVBQUM7Y0FBQyxTQUFTLEVBQUM7WUFBZ0I7VUFBQyxDQUFDLENBQUM7UUFFdEQsQ0FBQyxFQUFFLElBQUksQ0FBQztNQUNaLENBQ0osQ0FBQztJQUNMO0lBQ0EsT0FBTyxLQUFLO0VBQ2hCLENBQUMsQ0FBQzs7RUFFRjtBQUNKO0FBQ0E7RUFDSSxDQUFDLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQzFELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsQixJQUFJLElBQUksR0FBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztJQUM5QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBRWpELElBQUksUUFBUSxHQUFHLENBQ2QsMEJBQTBCLEVBQzFCLG9CQUFvQixFQUNwQixtQkFBbUIsRUFDbkIsMkJBQTJCLEVBQzNCLG1CQUFtQixFQUNuQiwyQkFBMkIsQ0FDM0I7SUFDRCxJQUFLLFFBQVEsQ0FBQyxPQUFPLENBQUUsSUFBSyxDQUFDLElBQUksQ0FBQyxFQUFHO01BQ3BDO0lBQ0Q7SUFFTSxDQUFDLENBQUMsSUFBSSxDQUNGLE9BQU8sRUFDUDtNQUNJLE1BQU0sRUFBRSxzQkFBc0I7TUFDOUIsV0FBVyxFQUFFLGdCQUFnQixDQUFDLEtBQUs7TUFDbkMsTUFBTSxFQUFFO1FBQ0osSUFBSSxFQUFFLElBQUk7UUFDVixLQUFLLEVBQUU7TUFDWDtJQUNKLENBQUMsRUFDRCxVQUFTLFFBQVEsRUFBRSxDQUFDLENBQ3hCLENBQUM7RUFDUixDQUFDLENBQUM7O0VBRUY7QUFDRDtBQUNBO0VBQ0ksQ0FBQyxDQUFDLHdDQUF3QyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTLENBQUMsRUFBRTtJQUNoRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFeEIsQ0FBQyxDQUFDLHdDQUF3QyxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQztJQUUvRCxDQUFDLENBQUMsSUFBSSxDQUNGLE9BQU8sRUFDUDtNQUNJLE1BQU0sRUFBRSw0QkFBNEI7TUFDcEMsV0FBVyxFQUFFLGdCQUFnQixDQUFDO0lBQ2xDLENBQUMsRUFDVixVQUFTLFFBQVEsRUFBRTtNQUNsQixJQUFLLFFBQVEsQ0FBQyxPQUFPLEVBQUc7UUFDdkI7UUFDQSxDQUFDLENBQUMsd0NBQXdDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsd0NBQXdDLENBQUMsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDO01BQ3pFO0lBQ0QsQ0FDSyxDQUFDO0VBQ0wsQ0FBQyxDQUFDOztFQUVGO0FBQ0o7QUFDQTtFQUNJLENBQUMsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBUyxDQUFDLEVBQUU7SUFDaEUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBRXhCLENBQUMsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUM7SUFFL0QsQ0FBQyxDQUFDLElBQUksQ0FDRixPQUFPLEVBQ1A7TUFDSSxNQUFNLEVBQUUsNEJBQTRCO01BQ3BDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQztJQUNsQyxDQUFDLEVBQ1YsVUFBUyxRQUFRLEVBQUU7TUFDbEIsSUFBSyxRQUFRLENBQUMsT0FBTyxFQUFHO1FBQ3ZCO1FBQ0EsQ0FBQyxDQUFDLHdDQUF3QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDOUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDZixDQUFDLENBQUMsd0NBQXdDLENBQUMsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDO1FBQ3hFLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7TUFDaEQ7SUFDRCxDQUNLLENBQUM7RUFDTCxDQUFDLENBQUM7RUFFRixDQUFDLENBQUUsMkJBQTRCLENBQUMsQ0FBQyxFQUFFLENBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxFQUFHO0lBQ3hELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUVsQixDQUFDLENBQUMsSUFBSSxDQUNGLE9BQU8sRUFDUDtNQUNJLE1BQU0sRUFBRSxzQkFBc0I7TUFDOUIsS0FBSyxFQUFFLGdCQUFnQixDQUFDO0lBQzVCLENBQUMsRUFDVixVQUFTLFFBQVEsRUFBRTtNQUNsQixJQUFLLFFBQVEsQ0FBQyxPQUFPLEVBQUc7UUFDdkIsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsSUFBSSxDQUFFLE1BQU8sQ0FBQztNQUN6QztJQUNELENBQ0ssQ0FBQztFQUNMLENBQUUsQ0FBQztFQUVILENBQUMsQ0FBRSx5QkFBMEIsQ0FBQyxDQUFDLEVBQUUsQ0FBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEVBQUc7SUFDdEQsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBRWxCLENBQUMsQ0FBQyxJQUFJLENBQ0YsT0FBTyxFQUNQO01BQ0ksTUFBTSxFQUFFLHdCQUF3QjtNQUNoQyxLQUFLLEVBQUUsZ0JBQWdCLENBQUM7SUFDNUIsQ0FBQyxFQUNWLFVBQVMsUUFBUSxFQUFFO01BQ2xCLElBQUssUUFBUSxDQUFDLE9BQU8sRUFBRztRQUN2QixDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxJQUFJLENBQUUsTUFBTyxDQUFDO01BQzNDO0lBQ0QsQ0FDSyxDQUFDO0VBQ0wsQ0FBRSxDQUFDO0VBQ04sQ0FBQyxDQUFFLDRCQUE2QixDQUFDLENBQUMsRUFBRSxDQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsRUFBRztJQUM1RCxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDbEIsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztJQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDO01BQ04sR0FBRyxFQUFFLGdCQUFnQixDQUFDLFFBQVE7TUFDOUIsVUFBVSxFQUFFLFNBQUEsQ0FBVyxHQUFHLEVBQUc7UUFDNUIsR0FBRyxDQUFDLGdCQUFnQixDQUFFLFlBQVksRUFBRSxnQkFBZ0IsQ0FBQyxVQUFXLENBQUM7UUFDakUsR0FBRyxDQUFDLGdCQUFnQixDQUFFLFFBQVEsRUFBRSw2QkFBOEIsQ0FBQztRQUMvRCxHQUFHLENBQUMsZ0JBQWdCLENBQUUsY0FBYyxFQUFFLGtCQUFtQixDQUFDO01BQzNELENBQUM7TUFDRCxNQUFNLEVBQUUsS0FBSztNQUNiLE9BQU8sRUFBRSxTQUFBLENBQVMsU0FBUyxFQUFFO1FBQzVCLElBQUksdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLDJCQUEyQixDQUFDO1FBQzVELHVCQUF1QixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDaEMsSUFBSyxTQUFTLEtBQUssU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFHO1VBQ3pDLHVCQUF1QixDQUFDLE1BQU0sQ0FBRSxtQ0FBbUMsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsUUFBUyxDQUFDO1VBQ3ZHO1FBQ0Q7UUFDQSxNQUFNLENBQUMsSUFBSSxDQUFFLFNBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBRyxZQUFZLElBQU07VUFDcEQsdUJBQXVCLENBQUMsTUFBTSxDQUFFLFVBQVUsR0FBRyxZQUFZLEdBQUcsYUFBYyxDQUFDO1VBQzNFLHVCQUF1QixDQUFDLE1BQU0sQ0FBRSxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFFLENBQUM7VUFDcEUsdUJBQXVCLENBQUMsTUFBTSxDQUFFLE1BQU8sQ0FBQztRQUN6QyxDQUFDLENBQUM7TUFDSDtJQUNELENBQUMsQ0FBQztFQUNILENBQUUsQ0FBQzs7RUFFQTtBQUNKO0FBQ0E7RUFDSSxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQ2xELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUV4QixDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDO0lBRWpELENBQUMsQ0FBQyxJQUFJLENBQ0YsT0FBTyxFQUNQO01BQ0ksTUFBTSxFQUFFLDRCQUE0QjtNQUNwQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUM7SUFDbEMsQ0FBQyxFQUNWLFVBQVMsUUFBUSxFQUFFO01BQ2xCLElBQUssUUFBUSxDQUFDLE9BQU8sRUFBRztRQUN2QjtRQUNBLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUM7O1FBRTFEO1FBQ0EsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDekIsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUNwRDtJQUNELENBQ0ssQ0FBQztFQUNMLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQztBQUVGLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxZQUFXO0VBQ3hELE1BQU0saUJBQWlCLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQztFQUV0RSxJQUFJLGlCQUFpQixFQUFFO0lBQ3RCLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxZQUFXO01BQ3ZELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPOztNQUU5QjtNQUNBLElBQUksT0FBTyxvQkFBb0IsS0FBSyxXQUFXLEVBQUU7UUFDaEQsb0JBQW9CLENBQUMsYUFBYSxHQUFHLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztNQUMzRDtNQUVBLEtBQUssQ0FBQyxPQUFPLEVBQUU7UUFDZCxNQUFNLEVBQUUsTUFBTTtRQUNkLE9BQU8sRUFBRTtVQUNSLGNBQWMsRUFBRTtRQUNqQixDQUFDO1FBQ0QsSUFBSSxFQUFFLElBQUksZUFBZSxDQUFDO1VBQ3pCLE1BQU0sRUFBRSxxQkFBcUI7VUFDN0IsS0FBSyxFQUFFLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQztVQUN4QixXQUFXLEVBQUUsZ0JBQWdCLENBQUM7UUFDL0IsQ0FBQztNQUNGLENBQUMsQ0FBQztJQUNILENBQUMsQ0FBQztFQUNIO0FBQ0QsQ0FBQyxDQUFDO0FBRUYsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixFQUFFLFlBQVc7RUFDeEQ7QUFDRDtBQUNBOztFQUVFO0VBQ0QsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsQ0FBRztFQUNuQyxNQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyxDQUFHOztFQUVsQztFQUNBLElBQUksaUJBQWlCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQzlJLElBQUksWUFBWSxHQUFHLGtCQUFrQjtFQUNyQyxJQUFJLFNBQVMsR0FBRyxJQUFJO0VBQ3BCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDO0VBQ25CLElBQUksZUFBZSxHQUFHO0lBQ2xCLElBQUksRUFBRTtNQUNGLE1BQU0sRUFBRSxFQUFFO01BQ1YsS0FBSyxFQUFFLENBQUM7TUFDUixTQUFTLEVBQUU7SUFDZixDQUFDO0lBQ0QsSUFBSSxFQUFFLEVBQUU7SUFDUixRQUFRLEVBQUUsRUFBRTtJQUNsQixpQkFBaUIsRUFBRTtNQUNsQixtQkFBbUIsRUFBRSxFQUFFO01BQ3ZCLGVBQWUsRUFBRTtJQUNsQjtFQUNFLENBQUM7O0VBRUQ7RUFDQSxJQUFJLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRTtJQUM1QyxlQUFlLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQjtFQUMvRDs7RUFFSDtFQUNBLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQztFQUNyRCxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsMEJBQTBCLENBQUM7RUFDaEQsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLG9CQUFvQixDQUFDOztFQUV0QztFQUNBLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRTtJQUMxQixJQUFJO01BQ0gsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDO01BQzFCLE9BQU8sR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQztJQUM5RSxDQUFDLENBQUMsTUFBTTtNQUNQLE9BQU8sS0FBSztJQUNiO0VBQ0Q7RUFFQSxTQUFTLE1BQU0sQ0FBQyxLQUFLLEVBQUU7SUFDdEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtNQUN2QyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQzlCO0VBQ0Q7RUFFQSxTQUFTLEtBQUssQ0FBQyxFQUFFLEVBQUU7SUFDbEIsT0FBTyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO0VBQ3RDO0VBRUEsU0FBUyxRQUFRLENBQUMsRUFBRSxFQUFFO0lBQ3JCO0lBQ0EsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUM7SUFDbkMsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLFVBQVUsQ0FBQztFQUNsRjtFQUVBLFNBQVMsaUJBQWlCLENBQUMsV0FBVyxFQUFFO0lBQ3ZDLE1BQU0sWUFBWSxHQUFNLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQztJQUNqRCxNQUFNLE1BQU0sR0FBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxLQUFLLEdBQUc7SUFDeEQsTUFBTSxZQUFZLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQzs7SUFFdEY7SUFDQSxNQUFNLGdCQUFnQixHQUFHLFdBQVcsS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTO0lBRTVELElBQUksZ0JBQWdCLEVBQUU7TUFDckIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO01BQ25CLFlBQVksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDO0lBQ25DLENBQUMsTUFBTTtNQUNOLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztNQUNuQixZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztJQUNoQztFQUNEO0VBRUEsU0FBUyxpQkFBaUIsQ0FBQyxpQkFBaUIsRUFBRTtJQUM3QyxJQUFJLGlCQUFpQixLQUFLLFNBQVMsSUFBSSxTQUFTLEtBQUssaUJBQWlCLEVBQUU7TUFDdkUsU0FBUyxHQUFHLGlCQUFpQjs7TUFFN0I7TUFDQSxzQkFBc0IsQ0FBQyxDQUFDO0lBQ3pCO0VBQ0Q7RUFFQSxTQUFTLHNCQUFzQixDQUFBLEVBQUc7SUFDakMsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGlDQUFpQyxDQUFDO0lBRWxGLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJO01BQy9CLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO01BQzFDLElBQUksQ0FBQyxHQUFHLEVBQUU7O01BRVY7TUFDQSxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUM7TUFDeEQsTUFBTSxTQUFTLEdBQUcsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztNQUVuRCxJQUFJLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtRQUM1QjtRQUNBLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDO1FBQy9DLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQztRQUV2QyxJQUFJLENBQUMsU0FBUyxFQUFFO1VBQ2Y7VUFDQSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQztVQUM3QyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsaUNBQWlDLElBQUkseUVBQXlFLENBQUM7UUFDdEs7TUFDRCxDQUFDLE1BQU07UUFDTjtRQUNBLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLHlCQUF5QixFQUFFLHVCQUF1QixDQUFDO1FBQzNFLE1BQU0sQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO01BQ2hDO0lBQ0QsQ0FBQyxDQUFDO0VBQ0g7RUFFQSxTQUFTLFlBQVksQ0FBQSxFQUFHO0lBQ3ZCLElBQUksU0FBUyxFQUFFO01BQ2QsWUFBWSxDQUFDLFNBQVMsQ0FBQztNQUN2QixTQUFTLEdBQUcsSUFBSTtJQUNqQjtJQUNBLFlBQVksR0FBRyxrQkFBa0I7RUFDbEM7RUFFQSxTQUFTLGVBQWUsQ0FBQSxFQUFHO0lBQzFCLElBQUksaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUNqQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU07UUFDNUIsVUFBVSxDQUFDLENBQUM7TUFDYixDQUFDLEVBQUUsWUFBWSxDQUFDO0lBQ2pCO0VBQ0Q7RUFFQSxTQUFTLGdCQUFnQixDQUFBLEVBQUc7SUFDM0IsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLEdBQUcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7RUFDakU7RUFFRyxTQUFTLGFBQWEsQ0FBQSxFQUFHO0lBQ3JCLE1BQU0sU0FBUyxHQUFHLElBQUksZUFBZSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0lBQzdELE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxVQUFVLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEtBQUssWUFBWTtFQUN4RjtFQUVILFNBQVMsa0JBQWtCLENBQUEsRUFBRztJQUM3QixNQUFNLFNBQVMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztJQUM3RCxPQUFPLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssVUFBVSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLGtCQUFrQjtFQUMzRjtFQUVBLFNBQVMsb0JBQW9CLENBQUMsZUFBZSxFQUFDO0lBQzdDLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLHNDQUFzQyxDQUFDO0lBQ25FLElBQUksaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBQztNQUNoQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztJQUN4RCxDQUFDLE1BQUssSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUNoQyxVQUFVLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7SUFDN0M7SUFDQSx5QkFBeUIsQ0FBQyxDQUFDO0VBQzVCOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLHlCQUF5QixDQUFBLEVBQUc7SUFDcEMsSUFBSSxFQUFFLEtBQUssZUFBZSxDQUFDLElBQUksRUFBRTtNQUNoQztJQUNEO0lBQ0EsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsMEJBQTBCLENBQUM7SUFFdEQsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQ3BDO0lBQ0Q7O0lBRUE7SUFDQSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQzs7SUFFN0M7SUFDQSxJQUFJLEVBQUUsbUJBQW1CLElBQUksZUFBZSxDQUFDLEVBQUU7TUFDOUM7SUFDRDtJQUVBLENBQUMsQ0FBQywrREFBK0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsbUJBQW1CLENBQUM7RUFDL0g7O0VBRUE7RUFDQSxTQUFTLFVBQVUsQ0FBQSxFQUFHO0lBQ3JCLElBQUksaUJBQWlCLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtNQUNuQyxZQUFZLENBQUMsQ0FBQztNQUNkO0lBQ0Q7SUFFQSxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FDakI7TUFDQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFFLDhDQUE4QyxFQUFFO1FBQUUsR0FBRyxFQUFFO01BQWtCLENBQUU7SUFDOUcsQ0FDRCxDQUFDLENBQUMsSUFBSSxDQUFJLFFBQVEsSUFBTTtNQUN2QixJQUFJLFFBQVEsQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDeEQ7UUFDQSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDOztRQUV0QztRQUNBLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7O1FBRXpDO1FBQ0EsSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtVQUMzSjtVQUNBLGVBQWUsR0FBRyxRQUFRLENBQUMsaUJBQWlCOztVQUU1QztVQUNBLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDO1VBQ25FO1VBQ0Esb0JBQW9CLENBQUMsZUFBZSxDQUFDOztVQUVyQztVQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsdUJBQXVCLEVBQUU7WUFBRSxNQUFNLEVBQUUsZUFBZSxDQUFDO1VBQUssQ0FBQyxDQUFDLENBQUM7UUFDbkc7UUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUk7VUFDbEMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLHlDQUF5QyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUM7VUFDdEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1VBRTdCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsbUNBQW1DLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7O1VBRXJFO1VBQ0EsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNsQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLHFDQUFxQyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1VBQ3hFO1VBRUEsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFFBQVEsRUFBRTtZQUNoRSxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztVQUNwQjtRQUNELENBQUMsQ0FBQztRQUVGLGdCQUFnQixDQUFDLENBQUM7UUFDbEIsZUFBZSxDQUFDLENBQUM7TUFDbEIsQ0FBQyxNQUFNO1FBQ047UUFDQSxpQkFBaUIsR0FBRyxFQUFFO1FBQ3RCLFlBQVksQ0FBQyxDQUFDO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUMsT0FBTyxJQUFJLFFBQVEsQ0FBQztNQUM5RDtJQUNELENBQUUsQ0FBQztFQUNKO0VBRUEsU0FBUyxhQUFhLENBQUMsQ0FBQyxFQUFFO0lBQ3pCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQzs7SUFFbEI7SUFDQSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUU7TUFDN0I7SUFDRDtJQUVBLE1BQU0sT0FBTyxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBRTFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDekIsS0FBSyxDQUFDLDBCQUEwQixDQUFDO01BQ2pDO0lBQ0Q7SUFFQSxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUVyQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FDakI7TUFDQyxJQUFJLEVBQUUsc0NBQXNDO01BQzVDLE1BQU0sRUFBRSxNQUFNO01BQ2QsSUFBSSxFQUFFO1FBQ0wsUUFBUSxFQUFFLE9BQU87UUFDakIsTUFBTSxFQUFFO01BQ1Q7SUFDRCxDQUNELENBQUMsQ0FBQyxJQUFJLENBQUksUUFBUSxJQUFNO01BQ3ZCLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtRQUNyQixJQUFLLENBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBRztVQUMzQixhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztVQUNyQixVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7O1VBRWhDO1VBQ0EsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQztVQUVqRCxNQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQztVQUM1QixNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztVQUNuQixJQUFJLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQztVQUNoRSxtQkFBbUIsQ0FBQyxJQUFJLENBQUUsUUFBUSxDQUFFLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUMsR0FBRyxDQUFFLENBQUM7O1VBRXRFO1VBQ0EsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQzs7VUFFdEM7VUFDQSxlQUFlLEdBQUcsUUFBUSxDQUFDLGlCQUFpQjs7VUFFNUM7VUFDQSxvQkFBb0IsQ0FBQyxlQUFlLENBQUM7VUFFckMsSUFBSSxtQkFBbUIsSUFBSSxlQUFlLEVBQUU7WUFDM0MsQ0FBQyxDQUFDLDJDQUEyQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUM7VUFDdkc7O1VBRUE7VUFDQSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDO1VBRXpDLElBQUksU0FBUyxFQUFFO1lBQ2QsWUFBWSxDQUFDLENBQUM7VUFDZjtVQUNBLGVBQWUsQ0FBQyxDQUFDO1FBQ2xCO01BRUQsQ0FBQyxNQUFNO1FBQ047UUFDQSxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQzs7UUFFckI7UUFDQSxJQUFJLFFBQVEsRUFBRSxPQUFPLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsZ0NBQWdDLENBQUMsRUFBRTtVQUNyRjtVQUNBLHFCQUFxQixDQUFDLENBQUM7VUFDdkI7VUFDQSxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsYUFBYSxLQUFLLFNBQVMsR0FBRyxRQUFRLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUN6RjtRQUVBLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE9BQU8sSUFBSSxRQUFRLENBQUM7TUFDN0M7SUFDRCxDQUFDLENBQUM7RUFDSDtFQUVBLFNBQVMsZUFBZSxDQUFDLENBQUMsRUFBRTtJQUMzQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFbEIsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUN2QixJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUNuRSxJQUFLLENBQUUsRUFBRSxFQUFHO01BQ1g7SUFDRDtJQUVBLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBRXJDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUNqQjtNQUNDLElBQUksRUFBRSxzQ0FBc0MsR0FBRyxFQUFFO01BQ2pELE1BQU0sRUFBRSxPQUFPO01BQ2YsSUFBSSxFQUFFO1FBQ0wsTUFBTSxFQUFFO01BQ1Q7SUFDRCxDQUNELENBQUMsQ0FBQyxJQUFJLENBQUksUUFBUSxJQUFNO01BQ3ZCLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtRQUNyQixNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztRQUVuQixDQUFDLENBQUMsZUFBZSxRQUFRLENBQUMsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVELE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyw2QkFBNkIsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDO1FBQzVELElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzs7UUFFL0I7UUFDTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLDZCQUE2QixFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDOztRQUV2RTtRQUNBLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7O1FBRXRDO1FBQ0EsaUJBQWlCLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQzs7UUFFN0I7UUFDQSxlQUFlLEdBQUcsUUFBUSxDQUFDLGlCQUFpQjs7UUFFeEQ7UUFDQSxvQkFBb0IsQ0FBQyxlQUFlLENBQUM7UUFFckMsSUFBSSxTQUFTLEVBQUU7VUFDZCxZQUFZLENBQUMsQ0FBQztRQUNmO1FBQ0EsZUFBZSxDQUFDLENBQUM7TUFDbEIsQ0FBQyxNQUFNO1FBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsT0FBTyxJQUFJLFFBQVEsQ0FBQztNQUM3QztJQUNELENBQUMsQ0FBQztFQUNIOztFQUVBO0VBQ0E7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFFLE9BQU8sRUFBRSxrQ0FBa0MsRUFBRSxhQUFjLENBQUM7RUFDNUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBRSxPQUFPLEVBQUUsaUNBQWlDLEVBQUUsZUFBZ0IsQ0FBQztFQUM3RTtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUUsVUFBVSxFQUFFLDRCQUE0QixFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQ3JFLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxPQUFPLEVBQUU7TUFDckIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO01BQ2xCLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9DO0VBQ0QsQ0FBQyxDQUFDOztFQUVGO0VBQ0csU0FBUyxxQkFBcUIsQ0FBQSxFQUFHO0lBQzdCLE1BQU0sU0FBUyxHQUFHLElBQUksZUFBZSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0lBQ25FLE9BQU8sVUFBVSxLQUFLLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0VBQ3pDOztFQUVIO0VBQ0EsSUFBSSxxQkFBcUIsQ0FBQyxDQUFDLElBQUksaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtJQUM1RCxJQUFJLFNBQVMsRUFBRTtNQUNkLFlBQVksQ0FBQyxDQUFDO0lBQ2Y7SUFDQSxlQUFlLENBQUMsQ0FBQztFQUNsQjs7RUFFQTtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLHFEQUFxRCxFQUFFLFlBQVc7SUFDekYsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO01BQzVDO0lBQ0Q7O0lBRUE7SUFDQSxVQUFVLENBQUMsTUFBTTtNQUNoQixvQkFBb0IsQ0FBQyxlQUFlLENBQUM7SUFDdEMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNQLENBQUMsQ0FBQzs7RUFFRjtFQUNBLFNBQVMsNEJBQTRCLENBQUMsTUFBTSxHQUFHLEtBQUssRUFBRTtJQUNyRCxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQztJQUU3RCxJQUFJLE1BQU0sRUFBRTtNQUNYO01BQ0EsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQztNQUN0RSxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUFDO01BQ3ZFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUM7O01BRXRFO01BQ0EsSUFBRyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO1FBQ2pFO01BQ0Q7SUFDRDtJQUNBLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDO0lBQzlELENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDO0lBQy9ELENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDO0VBQy9EOztFQUVBO0VBQ0EsU0FBUyx5QkFBeUIsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFO0lBQ3RELElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxlQUFlLFVBQVUsRUFBRSxDQUFDO0lBQzdDLElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUM7SUFDN0QsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixVQUFVLCtCQUErQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFFakksSUFBSyxTQUFTLEVBQUc7TUFDaEIsUUFBUSxDQUFDLFdBQVcsQ0FBQywwQkFBMEIsQ0FBQztNQUNoRCxDQUFDLENBQUMsNkJBQTZCLFVBQVUsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLHVCQUF1QixDQUFDO01BQ25GO01BQ0EsSUFBSSxNQUFNLEVBQUU7UUFDWCwyQkFBMkIsQ0FBQyxLQUFLLENBQUM7TUFDbkM7TUFFQTtJQUNEO0lBRUEsUUFBUSxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQztJQUM3QyxDQUFDLENBQUMsNkJBQTZCLFVBQVUsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDOztJQUVoRjtJQUNBLDBCQUEwQixDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsTUFBTSxDQUFDO0lBRXhELElBQUksTUFBTSxFQUFFO01BQ1gsMkJBQTJCLENBQUMsQ0FBQztJQUM5QjtFQUNEOztFQUVBO0VBQ0EsU0FBUywwQkFBMEIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRTtJQUN6RCxDQUFDLENBQUMsSUFBSSxDQUNMLE9BQU8sRUFDUDtNQUNDLE1BQU0sRUFBRSxxQ0FBcUM7TUFDN0MsV0FBVyxFQUFFLGdCQUFnQixDQUFDLEtBQUs7TUFDbkMsS0FBSyxFQUFFLEtBQUs7TUFDWixNQUFNLEVBQUUsS0FBSztNQUNiLE1BQU0sRUFBRTtJQUNULENBQUMsRUFDRCxVQUFTLFFBQVEsRUFBRTtNQUNsQixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRTtRQUN0QixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksUUFBUSxDQUFDO01BQzVFO0lBQ0QsQ0FDRCxDQUFDO0VBQ0Y7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUywyQkFBMkIsQ0FBQyxVQUFVLEdBQUcsSUFBSSxFQUFFO0lBQ3ZELE1BQU0sUUFBUSxHQUFHLFVBQVUsR0FBRyxtQkFBbUIsR0FBRyxvQkFBb0I7SUFDeEUsTUFBTSxXQUFXLEdBQUcsVUFBVSxHQUFHLG9CQUFvQixHQUFHLG1CQUFtQjtJQUUzRSxJQUFJLFVBQVUsR0FBRztNQUNoQixVQUFVLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7TUFDM0MsV0FBVyxFQUFFLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRUQsVUFBVSxDQUFDLFVBQVUsQ0FDbkIsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUN4QixRQUFRLENBQUMsUUFBUSxDQUFDO0lBRXBCLFVBQVUsQ0FBQyxXQUFXLENBQ3BCLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FDeEIsUUFBUSxDQUFDLFFBQVEsQ0FBQzs7SUFHcEI7SUFDQSxJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3RELElBQUksZ0JBQWdCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO01BQzNEO0lBQ0Q7SUFFQSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQ3hDLFFBQVEsQ0FBQyxRQUFRLENBQUM7RUFDcEI7O0VBRUE7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxZQUFXO0lBQ2hFLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDO0lBQzNFLHlCQUF5QixDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUM7RUFDcEQsQ0FBQyxDQUFDOztFQUVGO0VBQ0EsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUseUJBQXlCLEVBQUUsWUFBWTtJQUM5RCxJQUFJLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDOUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsV0FBVyxDQUFDLDBCQUEwQixDQUFDO01BQzVELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLENBQUMsdUJBQXVCLENBQUM7TUFDdEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxrQ0FBa0MsQ0FBQztNQUN2RCwyQkFBMkIsQ0FBQyxLQUFLLENBQUM7TUFFbEM7SUFDRDtJQUVBLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQztJQUN6RCxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDO0lBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsa0NBQWtDLENBQUM7SUFDcEQsMkJBQTJCLENBQUMsQ0FBQzs7SUFFN0I7SUFDQSwwQkFBMEIsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLGVBQWUsQ0FBQztFQUM3RCxDQUFDLENBQUM7O0VBRUY7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxVQUFTLENBQUMsRUFBRTtJQUFFO0lBQ3ZELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxFQUFFO01BQ2hEO0lBQ0Q7SUFFQSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO0lBQ3ZELDBCQUEwQixDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsbUJBQW1CLENBQUM7RUFDMUUsQ0FBQyxDQUFDOztFQUVGO0VBQ0EsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxxQ0FBcUMsRUFBRSxVQUFVLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFDOUU7SUFDQSxJQUFJLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDeEM7SUFDRDs7SUFFQTtJQUNBLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQztFQUMzRCxDQUFDLENBQUM7O0VBRUY7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLDRCQUE0QixFQUFFLFVBQVUsQ0FBQyxFQUFFO0lBQ3pEO0lBQ0EsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDO0lBQzFELENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQztJQUN4RCxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDO0VBQ2pELENBQUMsQ0FBQzs7RUFFRjtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsK0RBQStELEVBQUUsVUFBVSxDQUFDLEVBQUUsVUFBVSxFQUFFO0lBQ3hHO0lBQ0EsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixVQUFVLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRS9GLElBQUksTUFBTSxFQUFFO01BQ1gsNEJBQTRCLENBQUMsQ0FBQztJQUMvQjtFQUNELENBQUMsQ0FBQztFQUVGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsNkJBQTZCLEVBQUUsVUFBVSxDQUFDLEVBQUUsVUFBVSxFQUFFO0lBQ3RFLENBQUMsQ0FBQyxlQUFlLFVBQVUsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLDBCQUEwQixDQUFDO0lBQ3RFLENBQUMsQ0FBQyw2QkFBNkIsVUFBVSxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsdUJBQXVCLENBQUM7RUFDcEYsQ0FBQyxDQUFDO0VBRUYsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0lBQ3BCLElBQUssQ0FBRSxrQkFBa0IsQ0FBQyxDQUFDLEVBQUc7TUFDN0I7SUFDRDs7SUFFQTtJQUNBLDRCQUE0QixDQUFDLElBQUksQ0FBQzs7SUFFbEM7SUFDQSxNQUFNLFNBQVMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztJQUM3RCxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQzs7SUFFckM7SUFDQSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQzs7SUFFakY7SUFDQSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sS0FBSyxFQUFFLEVBQUU7TUFDN0IsSUFBSSxVQUFVLEVBQUU7UUFDZiwwQkFBMEIsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLGlCQUFpQixDQUFDO01BQ3BFO01BQ0E7SUFDRDtJQUVBLDBCQUEwQixDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsbUJBQW1CLENBQUM7SUFFakUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQztNQUN2QixTQUFTLEVBQUUsQ0FBQyxDQUFDLDZCQUE2QixNQUFNLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHO0lBQ3RFLENBQUMsRUFBRSxHQUFHLENBQUM7O0lBRVA7SUFDQSxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztJQUN6QixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJO0lBQzNGLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLENBQUM7RUFDNUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDOzs7OztBQ3YzQkYsT0FBQTtBQUNBLE9BQUE7QUFDQSxPQUFBO0FBQ0EsT0FBQTtBQUNBLE9BQUE7QUFHQSxPQUFBO0FBQ0EsT0FBQTtBQUNBLE9BQUE7QUFDQSxPQUFBO0FBQ0EsT0FBQTtBQUNBLE9BQUE7QUFDQSxPQUFBO0FBQ0EsT0FBQTtBQUNBLE9BQUE7QUFDQSxPQUFBO0FBQ0EsT0FBQTs7Ozs7QUNsQkEsSUFBSSxDQUFDLEdBQUcsTUFBTTtBQUNkLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBVTtFQUN4QixJQUFJLFFBQVEsSUFBSSxNQUFNLEVBQUU7SUFDcEI7QUFDUjtBQUNBO0lBQ1EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLHVCQUF1QixDQUFDO0lBQ3RDLEtBQUssQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFDO01BQ3pCLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7TUFDeEMsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLGFBQWE7TUFDOUQsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLFVBQVU7O01BRTdEO01BQ0Esa0JBQWtCLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzs7TUFFbkM7TUFDQSxhQUFhLENBQUMsR0FBRyxDQUFDO01BQ2xCLE9BQU8sS0FBSztJQUNoQixDQUFDLENBQUM7SUFFRixTQUFTLGFBQWEsQ0FBQyxHQUFHLEVBQUM7TUFDdkIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQ3BCLElBQUssR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUc7UUFDcEI7TUFDSjtNQUVJLElBQUssR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUc7UUFDbEIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDO1FBRTdCLFVBQVUsQ0FBQyxZQUFXO1VBQ2xCLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQ3pCLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDWCxDQUFDLE1BQU07UUFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztNQUM1QztJQUVSO0VBQ0o7RUFFSCxDQUFDLENBQUUsZ0JBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUUsT0FBTyxFQUFFLFlBQVc7SUFDN0Msa0JBQWtCLENBQUUscUNBQXFDLEVBQUUscUJBQXNCLENBQUM7RUFDbkYsQ0FBRSxDQUFDOztFQUVBO0VBQ0EsU0FBUyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFO0lBQ3pDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUU7TUFDbkQ7TUFDQSxJQUFJLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxJQUFJLG9CQUFvQixDQUFDLGFBQWEsS0FBSyxHQUFHLEVBQUU7UUFDbEk7TUFDSjs7TUFFQTtNQUNBLElBQUksb0JBQW9CLENBQUMsT0FBTyxJQUFJLE9BQU8sUUFBUSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7UUFDekUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUM7TUFDbkQ7TUFFQSxRQUFRLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFO1FBQzdCLFFBQVEsRUFBRSxNQUFNO1FBQzVCLGdCQUFnQixFQUFFLE9BQU87UUFDekIsUUFBUSxFQUFFLG9CQUFvQixDQUFDLE1BQU07UUFDekIsT0FBTyxFQUFFLG9CQUFvQixDQUFDLEtBQUs7UUFDbkMsYUFBYSxFQUFFLG9CQUFvQixDQUFDLEdBQUc7UUFDdkMsU0FBUyxFQUFFLG9CQUFvQixDQUFDLE9BQU87UUFDdkMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLElBQUk7UUFDakMscUJBQXFCLEVBQUU7TUFDM0IsQ0FBQyxDQUFDO0lBQ047RUFDSjs7RUFFQTtFQUNBLE1BQU0sQ0FBQyxrQkFBa0IsR0FBRyxrQkFBa0I7QUFDbEQsQ0FBQyxDQUFDOzs7OztBQ3ZFRixDQUFJLFFBQVEsSUFBTTtFQUNqQixZQUFZOztFQUVaLFNBQVMsb0JBQW9CLENBQUEsRUFBRztJQUMvQixRQUFRLENBQUMsYUFBYSxDQUFFLElBQUksV0FBVyxDQUFFLHNCQUF1QixDQUFFLENBQUM7RUFDcEU7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLG1CQUFtQixDQUFFLElBQUksRUFBRztJQUNwQyxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFFLFdBQVksQ0FBQztJQUN6RCxJQUFLLFVBQVUsRUFBRztNQUNqQixVQUFVLENBQUMsS0FBSyxHQUFHLElBQUk7SUFDeEI7SUFFQSxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFFLFVBQVcsQ0FBQztJQUN2RCxJQUFLLFNBQVMsRUFBRztNQUNoQixTQUFTLENBQUMsS0FBSyxHQUFHLFFBQVEsS0FBSyxJQUFJLEdBQUcsUUFBUSxHQUFHLFdBQVc7SUFDN0Q7SUFFQSxNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLHNEQUF1RCxDQUFDO0lBQ2pHLElBQUssUUFBUSxFQUFHO01BQ2YsUUFBUSxDQUFDLEtBQUssR0FBRyxTQUFTLEtBQUssSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQ2hEO0VBQ0Q7RUFFQSxRQUFRLENBQUMsZ0JBQWdCLENBQUUsa0JBQWtCLEVBQUUsTUFBTTtJQUNwRCxpQkFBaUIsQ0FBQyxDQUFDO0lBQ25CLGlCQUFpQixDQUFDLENBQUM7SUFDbkIsZUFBZSxDQUFDLENBQUM7SUFDakIsV0FBVyxDQUFDLENBQUM7SUFDYixjQUFjLENBQUMsQ0FBQztJQUNoQiw0Q0FBNEMsQ0FBQyxDQUFDO0VBQy9DLENBQUUsQ0FBQztFQUVILE1BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUscURBQXNELENBQUM7O0VBRXJHO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsOEJBQThCLENBQUUsSUFBSSxFQUFHO0lBQy9DO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUUsMkJBQTRCLENBQUUsQ0FBQyxDQUM1RixJQUFJLENBQUksRUFBRSxJQUFNLENBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBRSxlQUFnQixDQUFFLENBQUM7SUFFbkQsSUFBSyxDQUFFLGVBQWUsRUFBRztNQUN4QixJQUFLLElBQUksRUFBRztRQUNYO1FBQ0E7UUFDQSxNQUFNLGNBQWMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLHFDQUFzQyxDQUFDO1FBQ3RGLElBQUssY0FBYyxFQUFHO1VBQ3JCLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBRSxhQUFhLEVBQUUsSUFBSyxDQUFDO1FBQ3pEO01BQ0Q7TUFDQTtJQUNEO0lBRUEsSUFBSyxDQUFFLElBQUksRUFBRztNQUNiLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztNQUN4QjtJQUNEO0lBRUEsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUUsY0FBZSxDQUFDO0lBRXRFLGVBQWUsQ0FBQyxTQUFTLEdBQUcsSUFBSTtJQUVoQyxJQUFLLFNBQVMsRUFBRztNQUNoQjtNQUNBO01BQ0E7TUFDQSxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSwyQkFBNEIsQ0FBRSxDQUFDLENBQ3RGLElBQUksQ0FBSSxFQUFFLElBQU0sQ0FBRSxFQUFFLENBQUMsT0FBTyxDQUFFLGVBQWdCLENBQUUsQ0FBQztNQUVuRCxJQUFLLFNBQVMsRUFBRztRQUNoQixTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSxjQUFlLENBQUM7TUFDMUM7SUFDRDtFQUNEOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsMkJBQTJCLENBQUUsSUFBSSxFQUFHO0lBQzVDLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsNENBQTZDLENBQUM7SUFFeEYsSUFBSyxDQUFFLFNBQVMsRUFBRztNQUNsQjtJQUNEO0lBRUEsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLGFBQWEsQ0FBRSwyQkFBNEIsQ0FBQztJQUN2RSxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFFLDhCQUErQixDQUFDO0lBRTNFLElBQUssUUFBUSxFQUFHO01BQ2YsSUFBSyxJQUFJLEVBQUc7UUFDWCxRQUFRLENBQUMsU0FBUyxHQUFHLElBQUk7TUFDMUIsQ0FBQyxNQUFNO1FBQ04sUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO01BQ2xCO0lBQ0QsQ0FBQyxNQUFNLElBQUssSUFBSSxFQUFHO01BQ2xCLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBRSxZQUFZLEVBQUUsSUFBSyxDQUFDO0lBQ25EO0lBRUEsSUFBSyxDQUFFLElBQUksRUFBRztNQUNiLElBQUssU0FBUyxFQUFHO1FBQ2hCLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztNQUNuQjtNQUVBO0lBQ0Q7SUFFQSxJQUFLLENBQUUsU0FBUyxFQUFHO01BQ2xCLE1BQU0sU0FBUyxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUUsMkJBQTRCLENBQUM7TUFFeEUsSUFBSyxTQUFTLEVBQUc7UUFDaEIsU0FBUyxDQUFDLGtCQUFrQixDQUFFLFVBQVUsRUFBRSxpREFBa0QsQ0FBQztNQUM5RjtJQUNEO0VBQ0Q7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyw0QkFBNEIsQ0FBRSxNQUFNLEVBQUUsUUFBUSxFQUFHO0lBQ3pELElBQUssV0FBVyxLQUFLLE1BQU0sRUFBRztNQUM3QixJQUFLLENBQUUsUUFBUSxFQUFHO1FBQ2pCLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxnREFBaUQsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxFQUFFLElBQU07VUFDaEcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsa0JBQW1CLENBQUM7UUFDMUMsQ0FBRSxDQUFDO1FBRUg7TUFDRDtNQUVBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxnREFBaUQsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxFQUFFLElBQU07UUFDaEcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUUsa0JBQW1CLENBQUM7TUFDdkMsQ0FBRSxDQUFDO01BRUg7SUFDRDtJQUVBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxxQkFBc0IsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxFQUFFLElBQU07TUFDckUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsa0JBQW1CLENBQUM7SUFDMUMsQ0FBRSxDQUFDO0VBQ0o7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyxrQkFBa0IsQ0FBRSxZQUFZLEVBQUc7SUFDM0MsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxnREFBaUQsQ0FBQztJQUMxRixJQUFLLE9BQU8sRUFBRztNQUNkLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLGNBQWMsRUFBRSxDQUFFLFlBQWEsQ0FBQztJQUMzRDtFQUNEOztFQUVBO0VBQ0EsSUFBSSxlQUFlLEdBQUcsSUFBSTs7RUFFMUI7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyxvQkFBb0IsQ0FBRSxLQUFLLEVBQUUsS0FBSyxFQUFHO0lBQzdDLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUUsbUJBQW9CLENBQUM7SUFDMUQsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBRSxrQ0FBbUMsQ0FBQztJQUVwRixJQUFLLENBQUUsR0FBRyxJQUFJLENBQUUsY0FBYyxFQUFHO01BQ2hDO0lBQ0Q7O0lBRUE7SUFDQSxJQUFLLGVBQWUsS0FBSyxJQUFJLEVBQUc7TUFDL0IsWUFBWSxDQUFFLGVBQWdCLENBQUM7TUFDL0IsZUFBZSxHQUFHLElBQUk7SUFDdkI7SUFFQSxNQUFNLE9BQU8sR0FBSSxLQUFLLElBQUksS0FBSztJQUUvQixJQUFLLEdBQUcsRUFBRztNQUNWLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLGNBQWMsRUFBRSxLQUFLLEtBQUssQ0FBRSxDQUFDO0lBQ3BEO0lBRUEsSUFBSyxjQUFjLEVBQUc7TUFDckIsY0FBYyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsY0FBYyxFQUFFLENBQUUsT0FBUSxDQUFDO0lBQzdEO0lBRUEsSUFBSyxHQUFHLEVBQUc7TUFDVixJQUFLLE9BQU8sRUFBRztRQUNkO1FBQ0EsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUUsK0JBQWdDLENBQUM7UUFFcEQsSUFBSyxDQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFFLDZCQUE4QixDQUFDLEVBQUc7VUFDaEU7VUFDQSxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSw4QkFBK0IsQ0FBQztVQUNuRCxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw2QkFBOEIsQ0FBQztVQUVyRCxlQUFlLEdBQUcsVUFBVSxDQUFFLE1BQU07WUFDbkMsZUFBZSxHQUFHLElBQUk7WUFDdEIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsOEJBQStCLENBQUM7WUFDdEQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUUsNkJBQThCLENBQUM7WUFDbEQsUUFBUSxDQUFDLGFBQWEsQ0FBRSxJQUFJLFdBQVcsQ0FBRSw2QkFBOEIsQ0FBRSxDQUFDO1VBQzNFLENBQUMsRUFBRSxLQUFNLENBQUM7UUFDWDtNQUNELENBQUMsTUFBTTtRQUNOLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLDhCQUE4QixFQUFFLEtBQUssR0FBRyxDQUFFLENBQUM7UUFDakUsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsNkJBQTZCLEVBQUUsK0JBQWdDLENBQUM7TUFDdkY7SUFDRDtFQUNEOztFQUVBO0VBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFFLDZCQUE2QixFQUFJLENBQUMsSUFBTTtJQUNsRSxJQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFVBQVUsSUFBSSxlQUFlLEtBQUssSUFBSSxFQUFHO01BQ2pFLFlBQVksQ0FBRSxlQUFnQixDQUFDO01BQy9CLGVBQWUsR0FBRyxJQUFJO0lBQ3ZCO0VBQ0QsQ0FBRSxDQUFDOztFQUVIO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyw0Q0FBNEMsQ0FBQSxFQUFHO0lBQ3ZELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSw2QkFBNkIsRUFBSSxDQUFDLElBQU07TUFDbEU7TUFDQSxJQUFJLGdCQUFnQixDQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBYSxDQUFDLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRTtRQUNqRTtNQUNEO01BRUEsTUFBTSxPQUFPLEdBQUcsQ0FDZix5QkFBeUIsRUFDekIsNkJBQTZCLENBQzdCO01BRUQsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBRSxHQUFHLElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBRSxHQUFJLENBQUMsS0FBSyxJQUFLLENBQUM7O01BRWpGO01BQ0EsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxVQUFVLEVBQUU7UUFDbkMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFFLGtCQUFtQixDQUFDLEVBQUU7VUFDbkUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSxrQkFBbUIsQ0FBQztRQUM3RDtRQUVBO01BQ0Q7O01BRUE7TUFDQSxJQUFLLENBQUUsVUFBVSxFQUFHO1FBQ25CO01BQ0Q7O01BRUE7TUFDQSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLGtCQUFtQixDQUFDO0lBQzFELENBQUUsQ0FBQztFQUNKO0VBRUEsU0FBUywyQkFBMkIsQ0FBQSxFQUFHO0lBQ3RDLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsbUJBQW9CLENBQUM7SUFFN0QsSUFBSyxPQUFPLEVBQUc7TUFDZCxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSw0QkFBNkIsQ0FBQztJQUN0RDs7SUFFQTtJQUNBLE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMEJBQTJCLENBQUM7SUFFekUsSUFBSyxZQUFZLEVBQUc7TUFDbkIsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUUsa0JBQW1CLENBQUM7SUFDakQ7O0lBRUE7SUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUUscUJBQXNCLENBQUMsQ0FBQyxPQUFPLENBQUksRUFBRSxJQUFNO01BQ3JFLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLGtCQUFtQixDQUFDO01BRXRDLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUUsVUFBVyxDQUFDO01BRS9DLElBQUssUUFBUSxFQUFHO1FBQ2YsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJO01BQ3pCO0lBQ0QsQ0FBRSxDQUFDO0lBRUgsTUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxxQkFBc0IsQ0FBQztJQUNwRSxJQUFLLFlBQVksRUFBRztNQUNuQixZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSxrQkFBbUIsQ0FBQztJQUNqRDs7SUFFQTtJQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSw2QkFBOEIsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxVQUFVLElBQU07TUFDckYsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO0lBQzNCLENBQUUsQ0FBQzs7SUFFSDtJQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsOEJBQThCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM1RTs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsd0JBQXdCLENBQUUsWUFBWSxFQUFHO0lBQ2pELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSwyQkFBNEIsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxFQUFFLElBQU07TUFDM0UsRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsMEJBQTJCLENBQUM7SUFDbEQsQ0FBRSxDQUFDO0lBRUgsSUFBSyxZQUFZLEVBQUc7TUFDbkIsTUFBTSxNQUFNLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBRSxtQkFBb0IsQ0FBQztNQUMxRCxJQUFLLE1BQU0sRUFBRztRQUNiLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLDBCQUEyQixDQUFDO01BQ25EO01BRUEsTUFBTSxJQUFJLEdBQUcsWUFBWSxDQUFDLFlBQVksQ0FBRSxlQUFnQixDQUFDO01BQ3pELE1BQU0sU0FBUyxHQUFHLFFBQVEsS0FBSyxJQUFJLEdBQUcsY0FBYyxHQUFHLFdBQVc7TUFDbEUsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSx1Q0FBd0MsU0FBUyxJQUFNLENBQUM7TUFFNUYsSUFBSyxHQUFHLEVBQUc7UUFDVixHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSwwQkFBMkIsQ0FBQztNQUNoRDtJQUNEO0VBQ0Q7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsa0JBQWtCLENBQUEsRUFBRztJQUM3QixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLDZEQUE4RCxDQUFDO0lBRTFHLElBQUssQ0FBRSxVQUFVLEVBQUc7TUFDbkI7SUFDRDtJQUVBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSw2QkFBOEIsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxLQUFLLElBQU07TUFDaEYsS0FBSyxDQUFDLE9BQU8sR0FBSyxLQUFLLEtBQUssVUFBWTtJQUN6QyxDQUFFLENBQUM7SUFFSCx3QkFBd0IsQ0FBRSxVQUFXLENBQUM7SUFDdEMsb0JBQW9CLENBQUUsV0FBWSxDQUFDO0lBQ25DLFlBQVksQ0FBRSxXQUFZLENBQUM7SUFDM0Isb0JBQW9CLENBQUMsQ0FBQztJQUN0QixtQkFBbUIsQ0FBRSxnQkFBaUIsQ0FBQztFQUN4Qzs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsaUJBQWlCLENBQUEsRUFBRztJQUM1QixRQUFRLENBQUMsZ0JBQWdCLENBQUUsUUFBUSxFQUFJLEtBQUssSUFBTTtNQUNqRCxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBRSw2QkFBOEIsQ0FBQztNQUVwRSxJQUFLLENBQUUsTUFBTSxFQUFHO1FBQ2Y7TUFDRDtNQUVBLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUUsZUFBZ0IsQ0FBQztNQUVuRCxJQUFLLENBQUUsSUFBSSxFQUFHO1FBQ2I7TUFDRDs7TUFFQTtNQUNBO01BQ0E7TUFDQSxNQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxPQUFPO01BQ3ZDLE1BQU0sYUFBYSxHQUFNLGdCQUFnQixHQUFHLElBQUksR0FBRyxTQUFTO01BQzVELE1BQU0sYUFBYSxHQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUcsY0FBYyxHQUFHLFdBQVc7TUFDekUsTUFBTSxhQUFhLEdBQU0sTUFBTSxDQUFDLE9BQU8sQ0FBRSxzQkFBdUIsQ0FBQztNQUVqRSxNQUFNLENBQUMsT0FBTyxHQUFJLENBQUUsZ0JBQWdCO01BQ3BDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSTtNQUV0QixJQUFLLGFBQWEsRUFBRztRQUNwQixhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSw4QkFBK0IsQ0FBQztNQUM5RDtNQUVBLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFFO1FBQ25CLElBQUksRUFBRSw4QkFBOEI7UUFDcEMsTUFBTSxFQUFFLE1BQU07UUFDZCxJQUFJLEVBQUU7VUFBRSxJQUFJLEVBQUU7UUFBYztNQUM3QixDQUFFLENBQUMsQ0FBQyxJQUFJLENBQUksUUFBUSxJQUFNO1FBQ3pCLE1BQU0sQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCO1FBRWpDLElBQUssYUFBYSxFQUFHO1VBQ3BCLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLDhCQUErQixDQUFDO1FBQ2pFO1FBRUEsSUFBSyxnQkFBZ0IsRUFBRztVQUN2QjtVQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSw2QkFBOEIsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxLQUFLLElBQU07WUFDaEYsSUFBSyxLQUFLLEtBQUssTUFBTSxFQUFHO2NBQ3ZCLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSztZQUN0QjtVQUNELENBQUUsQ0FBQztVQUNILG9CQUFvQixDQUFFLGFBQWMsQ0FBQztVQUNyQyxZQUFZLENBQUUsYUFBYyxDQUFDO1FBQzlCO1FBRUEsd0JBQXdCLENBQUUsZ0JBQWdCLEdBQUcsTUFBTSxHQUFHLElBQUssQ0FBQztRQUM1RCxvQkFBb0IsQ0FBQyxDQUFDO1FBRXRCLDRCQUE0QixDQUMzQixRQUFRLEtBQUssSUFBSSxHQUFHLFFBQVEsR0FBRyxXQUFXLEVBQzFDLFFBQVEsQ0FBQywyQkFDVixDQUFDO1FBQ0QsbUJBQW1CLENBQUUsYUFBYyxDQUFDOztRQUVwQztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLENBQUUsUUFBUSxDQUFDLDRCQUE2QixDQUFDO1FBQ3BFLGlCQUFpQixDQUFFLFFBQVMsQ0FBQztRQUU3QixJQUFLLFFBQVEsS0FBSyxJQUFJLEVBQUc7VUFDeEIsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLO1VBRXZCO1FBQ0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsSUFBSyxDQUFFLFFBQVEsQ0FBQyxnQ0FBZ0MsRUFBRztVQUNsRCxNQUFNLENBQUMsUUFBUSxHQUFHLEtBQUs7UUFDeEI7TUFDRCxDQUFFLENBQUMsQ0FBQyxLQUFLLENBQUUsTUFBTTtRQUNoQjtRQUNBLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSztRQUV2QixJQUFLLGFBQWEsRUFBRztVQUNwQixhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw4QkFBK0IsQ0FBQztRQUNqRTtNQUNELENBQUUsQ0FBQztJQUNKLENBQUUsQ0FBQztFQUNKOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLG9CQUFvQixDQUFFLFlBQVksRUFBRztJQUM3QyxRQUFRLENBQUMsZ0JBQWdCLENBQUUsMkJBQTRCLENBQUMsQ0FBQyxPQUFPLENBQUksT0FBTyxJQUFNO01BQ2hGLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLGNBQWMsRUFBRSxDQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFFLFlBQWEsQ0FBRSxDQUFDO0lBQ3pGLENBQUUsQ0FBQztFQUNKOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLGlCQUFpQixDQUFFLE1BQU0sRUFBRztJQUNwQyxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLHVDQUF1QyxNQUFNLElBQUssQ0FBQztJQUV2RixJQUFLLENBQUUsR0FBRyxFQUFHO01BQ1o7SUFDRDtJQUVBLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUUsWUFBYSxDQUFDO0lBRTlDLElBQUssQ0FBRSxLQUFLLEVBQUc7TUFDZDtJQUNEO0lBRUEsUUFBUSxDQUFDLGdCQUFnQixDQUFFLHNCQUF1QixDQUFDLENBQUMsT0FBTyxDQUFJLElBQUksSUFBTTtNQUN4RSxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUs7SUFDekIsQ0FBRSxDQUFDO0VBQ0o7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyx1QkFBdUIsQ0FBRSxNQUFNLEVBQUc7SUFDMUMsTUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxzQkFBdUIsQ0FBQztJQUU3RCxJQUFLLENBQUUsSUFBSSxFQUFHO01BQ2I7SUFDRDtJQUVBLE1BQU0sV0FBVyxHQUFHLFdBQVcsS0FBSyxNQUFNO0lBQzFDLE1BQU0sR0FBRyxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7SUFDOUUsTUFBTSxFQUFFLEdBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVTtJQUU3RSxJQUFLLEdBQUcsRUFBRztNQUNWLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRztJQUNoQjtJQUVBLElBQUssRUFBRSxFQUFHO01BQ1QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsRUFBRTtJQUMzQjtFQUNEOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLFlBQVksQ0FBRSxNQUFNLEVBQUc7SUFDL0IsUUFBUSxDQUFDLGdCQUFnQixDQUFFLG9CQUFxQixDQUFDLENBQUMsT0FBTyxDQUFJLENBQUMsSUFBTTtNQUNuRSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSwyQkFBMkIsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFFLGlCQUFrQixDQUFDLEtBQUssTUFBTyxDQUFDO0lBQ2xHLENBQUUsQ0FBQztJQUVILGlCQUFpQixDQUFFLE1BQU8sQ0FBQztJQUMzQix1QkFBdUIsQ0FBRSxNQUFPLENBQUM7RUFDbEM7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsaUJBQWlCLENBQUEsRUFBRztJQUM1QixNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUUsb0JBQXFCLENBQUM7SUFFOUQsSUFBSyxDQUFFLElBQUksQ0FBQyxNQUFNLEVBQUc7TUFDcEI7SUFDRDtJQUVBLElBQUksQ0FBQyxPQUFPLENBQUksR0FBRyxJQUFNO01BQ3hCLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBRSxPQUFPLEVBQUUsTUFBTTtRQUNwQyxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFFLGlCQUFrQixDQUFDO1FBRXBELElBQUssQ0FBRSxNQUFNLEVBQUc7VUFDZjtRQUNEO1FBRUEsWUFBWSxDQUFFLE1BQU8sQ0FBQztRQUN0QixvQkFBb0IsQ0FBRSxNQUFPLENBQUM7UUFDOUIsb0JBQW9CLENBQUMsQ0FBQztNQUN2QixDQUFFLENBQUM7SUFDSixDQUFFLENBQUM7SUFFSCxNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLDRDQUE2QyxDQUFDO0lBQzNGLElBQUksYUFBYTtJQUVqQixJQUFLLFlBQVksRUFBRztNQUNuQixhQUFhLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUUsY0FBZSxDQUFDLEdBQUcsY0FBYyxHQUFHLFdBQVc7SUFDakcsQ0FBQyxNQUFNO01BQ04sTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxxQ0FBc0MsQ0FBQztNQUNyRixhQUFhLEdBQUcsYUFBYSxJQUFJLFFBQVEsS0FBSyxhQUFhLENBQUMsWUFBWSxDQUFFLGVBQWdCLENBQUMsR0FDeEYsY0FBYyxHQUNkLFdBQVc7SUFDZjtJQUVBLFlBQVksQ0FBRSxhQUFjLENBQUM7SUFDN0Isb0JBQW9CLENBQUUsYUFBYyxDQUFDO0lBQ3JDLG9CQUFvQixDQUFDLENBQUM7RUFDdkI7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsY0FBYyxDQUFFLElBQUksRUFBRSxJQUFJLEVBQUc7SUFDckMsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBRTtNQUMxQixJQUFJO01BQ0osTUFBTSxFQUFFLE1BQU07TUFDZDtJQUNELENBQUUsQ0FBQyxDQUFDLElBQUksQ0FBSSxRQUFRLElBQU07TUFDekIsSUFBSyxRQUFRLENBQUMsY0FBYyxFQUFHO1FBQzlCLGtCQUFrQixDQUFDLENBQUM7TUFDckI7TUFFQSxPQUFPLFFBQVE7SUFDaEIsQ0FBRSxDQUFDLENBQUMsS0FBSyxDQUFJLEtBQUssSUFBTTtNQUN2QixJQUFLLDBDQUEwQyxLQUFLLEtBQUssQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBRSxLQUFLLENBQUMsT0FBUSxDQUFDLEVBQUc7UUFDbkcsT0FBTyxjQUFjLENBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFO1VBQUUsa0JBQWtCLEVBQUU7UUFBSyxDQUFFLENBQUUsQ0FBQztNQUN2RjtNQUVBLE1BQU0sS0FBSztJQUNaLENBQUUsQ0FBQztFQUNKOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsZUFBZSxDQUFBLEVBQUc7SUFDMUIsUUFBUSxDQUFDLGdCQUFnQixDQUFFLE9BQU8sRUFBSSxLQUFLLElBQU07TUFDaEQsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUUscURBQXNELENBQUM7TUFDNUYsSUFBSyxDQUFFLE1BQU0sRUFBRztRQUNmO01BQ0Q7TUFFQSxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUk7TUFFdEIsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQztNQUU3RCxJQUFLLE9BQU8sRUFBRztRQUNkLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLDRCQUE2QixDQUFDO01BQ3REO01BRUEsY0FBYyxDQUFFLHdDQUF3QyxFQUFFLENBQUMsQ0FBRSxDQUFDLENBQUMsSUFBSSxDQUFJLFFBQVEsSUFBTTtRQUNwRixNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSxjQUFlLENBQUM7UUFDdEMsb0JBQW9CLENBQUUsUUFBUSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBTSxDQUFDO1FBRXRELElBQUssT0FBTyxFQUFHO1VBQ2QsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsNEJBQTZCLENBQUM7UUFDekQ7UUFFQSxJQUFLLFFBQVEsQ0FBQyxVQUFVLEVBQUc7VUFDMUIsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQ0FBb0MsQ0FBQztVQUU5RSxJQUFLLFFBQVEsRUFBRztZQUNmLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztVQUNsQjtVQUVBLE1BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsbUJBQW9CLENBQUM7VUFFcEUsSUFBSyxjQUFjLEVBQUc7WUFDckIsY0FBYyxDQUFDLGtCQUFrQixDQUFFLGFBQWEsRUFBRSxRQUFRLENBQUMsVUFBVyxDQUFDO1VBQ3hFO1FBQ0Q7O1FBRUE7UUFDQSxJQUFLLENBQUMsS0FBSyxRQUFRLENBQUMsS0FBSyxFQUFHO1VBQzNCLFFBQVEsQ0FBQyxhQUFhLENBQUUsZ0RBQWlELENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztVQUNwRixRQUFRLENBQUMsYUFBYSxDQUFFLElBQUksV0FBVyxDQUFFLDZCQUE4QixDQUFFLENBQUM7UUFDM0U7UUFFQSxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7TUFDNUIsQ0FBRSxDQUFDLENBQUMsS0FBSyxDQUFFLE1BQU07UUFDaEIsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLO1FBRXZCLElBQUssT0FBTyxFQUFHO1VBQ2QsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsNEJBQTZCLENBQUM7UUFDekQ7TUFDRCxDQUFFLENBQUM7SUFDSixDQUFFLENBQUM7RUFDSjtFQUNBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsV0FBVyxDQUFBLEVBQUc7SUFDdEIsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBRSx3QkFBeUIsQ0FBQztJQUNqRSxNQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLDJCQUE0QixDQUFDO0lBRXBFLElBQUssQ0FBRSxLQUFLLElBQUksQ0FBRSxNQUFNLEVBQUc7TUFDMUI7SUFDRDtJQUVBLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRTtNQUMxQixJQUFJO1FBQ0gsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQzFCLE9BQU8sR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQztNQUM5RSxDQUFDLENBQUMsTUFBTTtRQUNQLE9BQU8sS0FBSztNQUNiO0lBQ0Q7SUFFQSxTQUFTLFVBQVUsQ0FBQSxFQUFHO01BQ3JCLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7TUFFOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUNyQixLQUFLLENBQUMsMEJBQTBCLENBQUM7UUFDakM7TUFDRDs7TUFFQTtNQUNBLEtBQUssQ0FBQyxRQUFRLEdBQUcsSUFBSTtNQUNyQixNQUFNLENBQUMsUUFBUSxHQUFHLElBQUk7TUFDdEIsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQztNQUU3RCxJQUFLLE9BQU8sRUFBRztRQUNkLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLDRCQUE2QixDQUFDO01BQ3REO01BRUEsY0FBYyxDQUFFLCtCQUErQixFQUFFO1FBQUU7TUFBSSxDQUFFLENBQUMsQ0FBQyxJQUFJLENBQUksUUFBUSxJQUFNO1FBQ2hGLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUNoQixLQUFLLENBQUMsUUFBUSxHQUFHLEtBQUs7UUFDdEIsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLO1FBQ3ZCLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFFLGNBQWUsQ0FBQztRQUU3QyxvQkFBb0IsQ0FBRSxRQUFRLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFNLENBQUM7UUFFdEQsSUFBSyxPQUFPLEVBQUc7VUFDZCxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw0QkFBNkIsQ0FBQztRQUN6RDs7UUFFQTtRQUNBLElBQUssUUFBUSxDQUFDLFVBQVUsRUFBRztVQUMxQixNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLG1DQUFvQyxDQUFDO1VBRTlFLElBQUssUUFBUSxFQUFHO1lBQ2YsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1VBQ2xCO1VBRUEsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQztVQUVwRSxJQUFLLGNBQWMsRUFBRztZQUNyQixjQUFjLENBQUMsa0JBQWtCLENBQUUsYUFBYSxFQUFFLFFBQVEsQ0FBQyxVQUFXLENBQUM7VUFDeEU7UUFDRDs7UUFFQTtRQUNBLElBQUssQ0FBQyxLQUFLLFFBQVEsQ0FBQyxLQUFLLEVBQUc7VUFDM0IsUUFBUSxDQUFDLGFBQWEsQ0FBRSxnREFBaUQsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1VBQ3BGLFFBQVEsQ0FBQyxhQUFhLENBQUUsSUFBSSxXQUFXLENBQUUsNkJBQThCLENBQUUsQ0FBQztRQUMzRTtRQUVBLElBQUssUUFBUSxDQUFDLEtBQUssS0FBSyxRQUFRLENBQUMsS0FBSyxFQUFHO1VBQ3hDO1VBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUUsNEJBQTZCLENBQUM7VUFDM0YsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQ0FBb0MsQ0FBQztVQUNwRixJQUFLLGNBQWMsRUFBRztZQUNyQixjQUFjLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRSx1QkFBd0IsQ0FBQztVQUN4RDtVQUNBLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMkJBQTRCLENBQUM7VUFDeEUsSUFBSyxVQUFVLEVBQUc7WUFDakIsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO1VBQzNCO1VBQ0Esa0JBQWtCLENBQUUsSUFBSyxDQUFDO1VBQzFCLFFBQVEsQ0FBQyxhQUFhLENBQUUsSUFBSSxXQUFXLENBQUUsNkJBQThCLENBQUUsQ0FBQztRQUMzRTtRQUVBLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztNQUM1QixDQUFFLENBQUMsQ0FBQyxLQUFLLENBQUUsTUFBTTtRQUNoQixLQUFLLENBQUMsUUFBUSxHQUFHLEtBQUs7UUFDdEIsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLO1FBRXZCLElBQUssT0FBTyxFQUFHO1VBQ2QsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsNEJBQTZCLENBQUM7UUFDekQ7TUFDRCxDQUFFLENBQUM7SUFDSjtJQUVBLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBRSxPQUFPLEVBQUUsVUFBVyxDQUFDO0lBRTlDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBRSxTQUFTLEVBQUksQ0FBQyxJQUFNO01BQzNDLElBQUssT0FBTyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUc7UUFDeEIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCLFVBQVUsQ0FBQyxDQUFDO01BQ2I7SUFDRCxDQUFFLENBQUM7RUFDSjtFQUVBLFNBQVMsaUJBQWlCLENBQUUsUUFBUSxFQUFHO0lBQ3RDO0lBQ0EsSUFBSyxRQUFRLENBQUMsZ0NBQWdDLEVBQUc7TUFDaEQsMkJBQTJCLENBQUMsQ0FBQztJQUM5Qjs7SUFFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUssd0JBQXdCLElBQUksUUFBUSxFQUFHO01BQzNDLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsbUJBQW9CLENBQUM7TUFFN0QsSUFBSyxPQUFPLEVBQUc7UUFDZCxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw0QkFBNEIsRUFBRSxRQUFRLENBQUMsc0JBQXVCLENBQUM7TUFDMUY7SUFDRDs7SUFFQTtJQUNBLDhCQUE4QixDQUFFLFFBQVEsQ0FBQyxxQkFBc0IsQ0FBQztFQUNqRTs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLGNBQWMsQ0FBQSxFQUFHO0lBQ3pCLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUseUJBQTBCLENBQUM7SUFFckUsSUFBSyxDQUFFLFNBQVMsRUFBRztNQUNsQjtJQUNEO0lBRUEsU0FBUyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBRSxPQUFPLEVBQUksQ0FBQyxJQUFNO01BQzNELE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFFLHlCQUEwQixDQUFDO01BRTVELElBQUssQ0FBRSxNQUFNLEVBQUc7UUFDZjtNQUNEO01BRUEsTUFBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BRTVCLElBQUssQ0FBRSxFQUFFLEVBQUc7UUFDWDtNQUNEO01BRUEsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJO01BRXRCLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFFO1FBQ25CLElBQUksRUFBRSxpQ0FBa0MsRUFBRSxFQUFHO1FBQzdDLE1BQU0sRUFBRTtNQUNULENBQUUsQ0FBQyxDQUFDLElBQUksQ0FBSSxRQUFRLElBQU07UUFDekIsb0JBQW9CLENBQUUsUUFBUSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBTSxDQUFDOztRQUV0RDtRQUNBO1FBQ0EsOEJBQThCLENBQUUsUUFBUSxDQUFDLHFCQUFzQixDQUFDO1FBRWhFLElBQUssUUFBUSxDQUFDLFVBQVUsRUFBRztVQUMxQixNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBRSxtQ0FBb0MsQ0FBQztVQUU3RixJQUFLLFFBQVEsRUFBRztZQUNmLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztVQUNsQjtVQUVBLE1BQU0sY0FBYyxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFFLG1CQUFvQixDQUFDO1VBRW5GLElBQUssY0FBYyxFQUFHO1lBQ3JCLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBRSxhQUFhLEVBQUUsUUFBUSxDQUFDLFVBQVcsQ0FBQztVQUN4RTtRQUNEOztRQUVBO1FBQ0EsSUFBSyxDQUFDLEtBQUssUUFBUSxDQUFDLEtBQUssRUFBRztVQUMzQjtVQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUUsbUNBQW9DLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztVQUV0RSxNQUFNLFdBQVcsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFFLDZCQUE4QixDQUFDO1VBRTVFLElBQUssV0FBVyxFQUFHO1lBQ2xCLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFFLGNBQWUsQ0FBQztZQUM5QyxXQUFXLENBQUMsUUFBUSxHQUFHLEtBQUs7VUFDN0I7O1VBRUE7VUFDQSxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLDZDQUE4QyxDQUFDO1VBQ3pGLElBQUssU0FBUyxFQUFHO1lBQ2hCLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBRSxVQUFVLEVBQUUsaURBQWtELENBQUM7VUFDOUY7UUFDRDtRQUVBLElBQUssUUFBUSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxFQUFHO1VBQ3RDO1VBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUUsNEJBQTZCLENBQUM7VUFDOUYsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQ0FBb0MsQ0FBQztVQUNwRixJQUFLLGNBQWMsRUFBRztZQUNyQixjQUFjLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSx1QkFBd0IsQ0FBQztVQUMzRDtVQUNBLE1BQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMkJBQTRCLENBQUM7VUFDeEUsSUFBSyxVQUFVLEVBQUc7WUFDakIsVUFBVSxDQUFDLFFBQVEsR0FBRyxLQUFLO1VBQzVCO1VBQ0Esa0JBQWtCLENBQUUsS0FBTSxDQUFDOztVQUUzQjtVQUNBLElBQUssUUFBUSxDQUFDLEtBQUssS0FBSyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRztZQUM1QyxRQUFRLENBQUMsYUFBYSxDQUFFLElBQUksV0FBVyxDQUFFLDhCQUErQixDQUFFLENBQUM7VUFDNUU7UUFDRDtNQUVELENBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBRSxNQUFNO1FBQ2hCLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSztNQUN4QixDQUFFLENBQUM7SUFDSixDQUFFLENBQUM7RUFDSjtBQUNELENBQUMsRUFBSSxRQUFTLENBQUM7Ozs7O0FDOTZCZixTQUFTLGdCQUFnQixDQUFDLE9BQU8sRUFBQztFQUM5QixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDeEIsTUFBTSxLQUFLLEdBQUksT0FBTyxHQUFHLElBQUksR0FBSSxLQUFLO0VBQ3RDLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUcsS0FBSyxHQUFDLElBQUksR0FBSSxFQUFHLENBQUM7RUFDL0MsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBRyxLQUFLLEdBQUMsSUFBSSxHQUFDLEVBQUUsR0FBSSxFQUFHLENBQUM7RUFDbEQsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBRyxLQUFLLElBQUUsSUFBSSxHQUFDLEVBQUUsR0FBQyxFQUFFLENBQUMsR0FBSSxFQUFHLENBQUM7RUFDckQsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBRSxLQUFLLElBQUUsSUFBSSxHQUFDLEVBQUUsR0FBQyxFQUFFLEdBQUMsRUFBRSxDQUFFLENBQUM7RUFFaEQsT0FBTztJQUNILEtBQUs7SUFDTCxJQUFJO0lBQ0osS0FBSztJQUNMLE9BQU87SUFDUDtFQUNKLENBQUM7QUFDTDtBQUVBLFNBQVMsZUFBZSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7RUFDbEMsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7RUFFekMsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO0lBQ2hCO0VBQ0o7RUFFQSxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDO0VBQzlELE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMseUJBQXlCLENBQUM7RUFDaEUsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQywyQkFBMkIsQ0FBQztFQUNwRSxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLDJCQUEyQixDQUFDO0VBRXBFLFNBQVMsV0FBVyxDQUFBLEVBQUc7SUFDbkIsTUFBTSxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO0lBRW5DLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUU7TUFDYixhQUFhLENBQUMsWUFBWSxDQUFDO01BRTNCO0lBQ0o7SUFFQSxRQUFRLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJO0lBQzNCLFNBQVMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0MsV0FBVyxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNuRCxXQUFXLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3ZEO0VBRUEsV0FBVyxDQUFDLENBQUM7RUFDYixNQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQztBQUN2RDtBQUVBLFNBQVMsVUFBVSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7RUFDaEMsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7RUFDekMsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQywrQkFBK0IsQ0FBQztFQUN2RSxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLDRCQUE0QixDQUFDO0VBRXJFLElBQUksS0FBSyxLQUFLLElBQUksRUFBRTtJQUNuQjtFQUNEO0VBRUEsU0FBUyxXQUFXLENBQUEsRUFBRztJQUN0QixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDeEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBRSxDQUFHLE9BQU8sR0FBRyxJQUFJLEdBQUksS0FBSyxJQUFLLElBQUssQ0FBQztJQUVuRSxJQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUU7TUFDbkIsYUFBYSxDQUFDLGFBQWEsQ0FBQztNQUU1QixJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUU7UUFDcEIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO01BQy9CO01BRUEsSUFBSSxPQUFPLEtBQUssSUFBSSxFQUFFO1FBQ3JCLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztNQUNuQztNQUVBLElBQUssZ0JBQWdCLENBQUMsYUFBYSxFQUFHO1FBQ3JDO01BQ0Q7TUFFQSxNQUFNLElBQUksR0FBRyxJQUFJLFFBQVEsQ0FBQyxDQUFDO01BRTNCLElBQUksQ0FBQyxNQUFNLENBQUUsUUFBUSxFQUFFLG1CQUFvQixDQUFDO01BQzVDLElBQUksQ0FBQyxNQUFNLENBQUUsT0FBTyxFQUFFLGdCQUFnQixDQUFDLEtBQU0sQ0FBQztNQUU5QyxLQUFLLENBQUUsT0FBTyxFQUFFO1FBQ2YsTUFBTSxFQUFFLE1BQU07UUFDZCxXQUFXLEVBQUUsYUFBYTtRQUMxQixJQUFJLEVBQUU7TUFDUCxDQUFFLENBQUM7TUFFSDtJQUNEO0lBRUEsS0FBSyxDQUFDLFNBQVMsR0FBRyxTQUFTO0VBQzVCO0VBRUEsV0FBVyxDQUFDLENBQUM7RUFDYixNQUFNLGFBQWEsR0FBRyxXQUFXLENBQUUsV0FBVyxFQUFFLElBQUksQ0FBQztBQUN0RDtBQUVBLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO0VBQ1gsSUFBSSxDQUFDLEdBQUcsR0FBRyxTQUFTLEdBQUcsQ0FBQSxFQUFHO0lBQ3hCLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0VBQzdCLENBQUM7QUFDTDtBQUVBLElBQUksT0FBTyxnQkFBZ0IsQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO0VBQ25ELGVBQWUsQ0FBQyx3QkFBd0IsRUFBRSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7QUFDekU7QUFFQSxJQUFJLE9BQU8sZ0JBQWdCLENBQUMsa0JBQWtCLEtBQUssV0FBVyxFQUFFO0VBQzVELGVBQWUsQ0FBQyx3QkFBd0IsRUFBRSxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQztBQUNsRjtBQUVBLElBQUksT0FBTyxnQkFBZ0IsQ0FBQyxlQUFlLEtBQUssV0FBVyxFQUFFO0VBQ3pELFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxnQkFBZ0IsQ0FBQyxlQUFlLENBQUM7QUFDdEU7Ozs7O0FDakhBLE9BQUE7QUFFQSxJQUFJLENBQUMsR0FBRyxNQUFNO0FBQ2QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFVO0VBR3hCO0FBQ0o7QUFDQTs7RUFFQyxTQUFTLGVBQWUsQ0FBQyxLQUFLLEVBQUM7SUFDOUIsSUFBSSxRQUFRLEVBQUUsU0FBUztJQUV2QixLQUFLLEdBQU8sQ0FBQyxDQUFFLEtBQU0sQ0FBQztJQUN0QixRQUFRLEdBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDNUIsU0FBUyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDOztJQUVqRDtJQUNBLElBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBQztNQUN2QixTQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztNQUVoQyxTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVc7UUFDekIsSUFBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1VBQ3pELElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1VBRXhELENBQUMsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztRQUN2RDtNQUNELENBQUMsQ0FBQztJQUNILENBQUMsTUFDRztNQUNILFNBQVMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO01BRW5DLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBVztRQUN6QixJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUV4RCxDQUFDLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7TUFDMUQsQ0FBQyxDQUFDO0lBQ0g7RUFDRDs7RUFFRztBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSSxTQUFTLGlCQUFpQixDQUFFLE1BQU0sRUFBRztJQUNqQyxJQUFJLE9BQU87SUFFWCxJQUFLLENBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRztNQUNuQjtNQUNBLE9BQU8sSUFBSTtJQUNmO0lBRUEsT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUUsUUFBUyxDQUFDO0lBRWpDLElBQUssT0FBTyxPQUFPLEtBQUssUUFBUSxFQUFHO01BQy9CO01BQ0EsT0FBTyxJQUFJO0lBQ2Y7SUFFQSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBRSxZQUFZLEVBQUUsRUFBRyxDQUFDO0lBRTdDLElBQUssRUFBRSxLQUFLLE9BQU8sRUFBRztNQUNsQjtNQUNBLE9BQU8sSUFBSTtJQUNmO0lBRUEsT0FBTyxHQUFHLENBQUMsQ0FBRSxHQUFHLEdBQUcsT0FBUSxDQUFDO0lBRTVCLElBQUssQ0FBRSxPQUFPLENBQUMsTUFBTSxFQUFHO01BQ3BCO01BQ0EsT0FBTyxLQUFLO0lBQ2hCO0lBRUEsSUFBSyxDQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUUsVUFBVyxDQUFDLElBQUksT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwRDtNQUNBLE9BQU8sS0FBSztJQUNoQjtJQUVOLElBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUU7TUFDL0Q7TUFDQSxPQUFPLEtBQUs7SUFDYjtJQUNNO0lBQ0EsT0FBTyxpQkFBaUIsQ0FBRSxPQUFPLENBQUMsT0FBTyxDQUFFLFlBQWEsQ0FBRSxDQUFDO0VBQy9EOztFQUVIO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLFNBQVMsQ0FBQyxjQUFjLEVBQUUsaUJBQWlCLEVBQUU7SUFDckQsSUFBSSxRQUFRLEdBQUc7TUFDZCxLQUFLLEVBQUUsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7TUFDOUIsUUFBUSxFQUFFLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELElBQUksUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFFeEIsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO01BQ2xFLElBQUksV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOztNQUV4QztNQUNBLElBQUksV0FBVyxHQUFHLFVBQVUsR0FBRyxXQUFXO01BRTFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO0lBQ2hDO0lBQ0E7SUFDQSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO01BQzNDLGNBQWMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQztNQUN2QyxjQUFjLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUM7TUFDdkMsY0FBYyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUM7SUFDNUM7O0lBRUE7QUFDRjtBQUNBO0lBQ0UsU0FBUyxXQUFXLENBQUEsRUFBRztNQUN0QixJQUFJLFVBQVUsR0FBRyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7TUFDckMsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO1FBQ3hDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7TUFDbEM7SUFDRDs7SUFFQTtBQUNGO0FBQ0E7SUFDRSxTQUFTLFdBQVcsQ0FBQSxFQUFHO01BQ3RCLElBQUksY0FBYyxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQzVDLGNBQWMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO0lBQ25DO0VBRUQ7O0VBRUM7O0VBR0QsU0FBUyxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0VBQ2xFLFNBQVMsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQzs7RUFFbEU7RUFDRyxDQUFDLENBQUUsb0NBQXFDLENBQUMsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVc7SUFDOUQsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUM1QixDQUFDLENBQUM7O0VBRUY7RUFDQSxDQUFDLENBQUUsc0JBQXVCLENBQUMsQ0FBQyxJQUFJLENBQUUsWUFBVztJQUN6QyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUUsSUFBSyxDQUFDO0lBRXRCLElBQUssaUJBQWlCLENBQUUsTUFBTyxDQUFDLEVBQUc7TUFDL0IsTUFBTSxDQUFDLFFBQVEsQ0FBRSxZQUFhLENBQUM7SUFDbkM7RUFDSixDQUFFLENBQUM7O0VBS0g7QUFDSjtBQUNBOztFQUVJLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztFQUM1QyxJQUFJLG1CQUFtQixHQUFHLENBQUMsQ0FBQyx5Q0FBeUMsQ0FBQzs7RUFFdEU7RUFDQSxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsWUFBVTtJQUMvQixlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQzVCLENBQUMsQ0FBQztFQUVGLGNBQWMsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVc7SUFDbkMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUMzQixDQUFDLENBQUM7RUFFRixTQUFTLGNBQWMsQ0FBQyxLQUFLLEVBQUM7SUFDMUIsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztNQUMvQyxhQUFhLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztNQUNsRCxZQUFZLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO01BQzNELFdBQVcsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztNQUM3QyxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7TUFDeEQsU0FBUyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDOztJQUdyRDtJQUNBLElBQUcsYUFBYSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBQztNQUM1QixhQUFhLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztNQUNwQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUM7TUFDcEMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7TUFHdkIsSUFBSSxjQUFjLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7O01BRXREO01BQ0EsY0FBYyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBVTtRQUNqQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7UUFDbkMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7UUFDdkMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUM7O1FBRWhDO1FBQ0EsSUFBRyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBQztVQUN2QixXQUFXLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDO1VBQ3pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUM7UUFDckQ7UUFFQSxPQUFPLEtBQUs7TUFDaEIsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxNQUNHO01BQ0EsV0FBVyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQztNQUN0QyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDO01BQ2hELFdBQVcsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQztNQUMvRCxTQUFTLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQztJQUN2QztFQUNKOztFQUVBO0FBQ0o7QUFDQTtFQUNJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLHFCQUFxQixFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQzdELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUMxQixDQUFFLENBQUM7RUFFSCxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQ2xELENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDO0VBQ2hFLENBQUMsQ0FBQzs7RUFFTDtBQUNEO0FBQ0E7RUFDQyxJQUFJLHFCQUFxQixHQUFHLEtBQUs7RUFFakMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUscUNBQXFDLEVBQUUsVUFBUyxDQUFDLEVBQUU7SUFDMUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2xCLElBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBQztNQUNuQyxPQUFPLEtBQUs7SUFDYjtJQUNBLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUM7SUFDbkQsT0FBTyxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUM7SUFDL0UsT0FBTyxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7SUFDckUsT0FBTyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7SUFDM0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7SUFDaEMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBRTdCLENBQUUsQ0FBQztFQUdILFNBQVMsbUJBQW1CLENBQUMsSUFBSSxFQUFDO0lBQ2pDLHFCQUFxQixHQUFHLEtBQUs7SUFDN0IsSUFBSSxDQUFDLE9BQU8sQ0FBRSwyQkFBMkIsRUFBRSxDQUFFLElBQUksQ0FBRyxDQUFDO0lBQ3JELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLHFCQUFxQixFQUFFO01BQzNELDBCQUEwQixDQUFDLElBQUksQ0FBQztNQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFFLHVCQUF1QixFQUFFLENBQUUsSUFBSSxDQUFHLENBQUM7TUFDakQsT0FBTyxLQUFLO0lBQ2I7SUFDQSxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxxQkFBcUIsQ0FBQztJQUNqRixhQUFhLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztJQUNwQyxJQUFJLGNBQWMsR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQzs7SUFFdEQ7SUFDQSxjQUFjLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFVO01BQ3BDLGFBQWEsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO01BQ3ZDLDBCQUEwQixDQUFDLElBQUksQ0FBQztNQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFFLHVCQUF1QixFQUFFLENBQUUsSUFBSSxDQUFHLENBQUM7TUFDakQsT0FBTyxLQUFLO0lBQ2IsQ0FBQyxDQUFDO0VBQ0g7RUFFQSxTQUFTLDBCQUEwQixDQUFDLElBQUksRUFBRTtJQUN6QyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDO0lBQ2hELElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQywyQ0FBMkMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztJQUN2RixTQUFTLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztFQUNqQzs7RUFFQTtBQUNEO0FBQ0E7RUFDQyxJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUV6RCxDQUFDLENBQUUsbUVBQW9FLENBQUMsQ0FDdEUsRUFBRSxDQUFFLHVCQUF1QixFQUFFLFVBQVUsS0FBSyxFQUFFLElBQUksRUFBRztJQUNyRCxxQ0FBcUMsQ0FBQyxJQUFJLENBQUM7RUFDNUMsQ0FBQyxDQUFDO0VBRUgsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFVO0lBQ2xELElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO01BQ2pDLDBCQUEwQixDQUFDLENBQUM7SUFDN0IsQ0FBQyxNQUFJO01BQ0osSUFBSSx1QkFBdUIsR0FBRyxHQUFHLEdBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsSUFBSSxDQUFFLFNBQVUsQ0FBQztNQUN0RixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0lBQzVDO0VBQ0QsQ0FBQyxDQUFDO0VBRUYsU0FBUyxxQ0FBcUMsQ0FBQyxJQUFJLEVBQUU7SUFDcEQsSUFBSSxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDeEMsSUFBRyxtQkFBbUIsS0FBSyxlQUFlLEVBQUM7TUFDMUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUM5QixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2QixDQUFDLE1BQUk7TUFDSixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO01BQzlCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCO0VBRUQ7RUFFQSxTQUFTLDBCQUEwQixDQUFBLEVBQUc7SUFDckMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM5QixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUN2QjtFQUVBLENBQUMsQ0FBRSxtRUFBb0UsQ0FBQyxDQUN0RSxFQUFFLENBQUUsMkJBQTJCLEVBQUUsVUFBVSxLQUFLLEVBQUUsSUFBSSxFQUFHO0lBQ3pELHFCQUFxQixHQUFJLG1CQUFtQixLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVk7RUFDMUYsQ0FBQyxDQUFDO0VBRUgsQ0FBQyxDQUFFLHVDQUF3QyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFO0lBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztFQUMxRSxDQUFDLENBQUM7RUFFRixDQUFDLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUU7SUFDMUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDdEMsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFTO0lBQ3pELFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFVBQVUsR0FBRyxJQUFJLEdBQUcsU0FBVSxDQUFDO0lBQ3hELE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDO0lBQ3JHLElBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO01BQzFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLFFBQVEsSUFBSTtRQUNqQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFVLEdBQUcsSUFBSSxHQUFHLFNBQVUsQ0FBQztNQUM1RCxDQUFDLENBQUM7TUFDRjtJQUNEO0lBQ0EsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUM7SUFFakYsTUFBTSxXQUFXLEdBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsUUFBUSxJQUFJO01BQ3RELElBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFTLEVBQUU7UUFDN0M7TUFDRDtNQUNBLE9BQU8sUUFBUTtJQUNoQixDQUFDLENBQUM7SUFDRixhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsTUFBTSxLQUFLLGNBQWMsQ0FBQyxNQUFNLEdBQUcsU0FBUyxHQUFHLElBQUssQ0FBQztFQUNoRyxDQUFDLENBQUM7RUFFRixJQUFLLENBQUMsQ0FBRSxvQkFBcUIsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUc7SUFDM0MsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLFFBQVEsS0FBSztNQUN4RCxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQztNQUNsRCxJQUFJLFdBQVcsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFFLG1EQUFvRCxDQUFDLENBQUMsTUFBTTtNQUNoRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLElBQUksQ0FBQyxHQUFHLFNBQVMsR0FBRyxJQUFLLENBQUM7SUFDbEUsQ0FBQyxDQUFDO0VBQ0g7RUFFQSxJQUFJLGVBQWUsR0FBRztJQUNyQixPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ1gsS0FBSyxFQUFFLENBQUM7RUFDVCxDQUFDO0VBQ0QsQ0FBQyxDQUFDLDhDQUE4QyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVk7SUFDbEU7SUFDQSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMzQixJQUFJLEVBQUUsRUFBRTtNQUNQLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxpQ0FBaUMsQ0FBQyxDQUFDLE1BQU07TUFDL0UsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLGlEQUFpRCxDQUFDLENBQUMsTUFBTTtNQUM3RjtNQUNBLENBQUMsQ0FBQyxJQUFJLEVBQUUsMEJBQTBCLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztNQUNyRTtNQUNBLENBQUMsQ0FBQyxJQUFJLEVBQUUscUJBQXFCLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7O01BRXRFO01BQ0EsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUU7UUFDOUQsQ0FBQyxDQUFDLElBQUksRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO01BQ3JEO0lBQ0Q7RUFDRCxDQUFDLENBQUM7O0VBRUY7QUFDRDtBQUNBO0VBQ0MsSUFBSSx1QkFBdUIsR0FBRyxDQUFDLENBQUMsK0JBQStCLENBQUM7RUFDaEUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBWTtJQUN2QyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsSUFBSSx1QkFBdUIsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUU7TUFDM0UsdUJBQXVCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztJQUN6QztFQUNELENBQUMsQ0FBQztFQUVGLElBQUksY0FBYyxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUUsdUJBQXdCLENBQUM7RUFDdkUsSUFBSyxjQUFjLEVBQUc7SUFDckIsY0FBYyxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixFQUFDLFVBQVMsS0FBSyxFQUFDO01BRXJFLElBQUksZUFBZSxHQUFHLENBQUMsQ0FBRSxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQWUsQ0FBQztNQUV0RCxJQUFJLElBQUksR0FBRyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztNQUV2QyxJQUFJLE1BQU0sR0FBRyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztNQUMzQyxJQUFJLGFBQWEsR0FBSSxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztNQUMxRCxJQUFJLEtBQUssR0FBSSxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztNQUMxQyxJQUFJLEdBQUcsR0FBTSxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztNQUV4QyxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFFLG1CQUFvQixDQUFDO01BRXhELElBQUssTUFBTSxFQUFHO1FBQ2IsV0FBVyxDQUFDLElBQUksQ0FBRSwwQkFBMkIsQ0FBQyxDQUFDLElBQUksQ0FBRSxNQUFPLENBQUM7TUFDOUQ7TUFDQSxJQUFLLElBQUksRUFBRztRQUNYLFdBQVcsQ0FBQyxJQUFJLENBQUUsb0JBQXFCLENBQUMsQ0FBQyxJQUFJLENBQUUsSUFBSyxDQUFDO01BQ3REO01BQ0EsSUFBSyxhQUFhLEVBQUc7UUFDcEIsV0FBVyxDQUFDLElBQUksQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDLElBQUksQ0FBRSxhQUFjLENBQUM7TUFDNUU7TUFDQSxJQUFLLEtBQUssRUFBRztRQUNaLFdBQVcsQ0FBQyxJQUFJLENBQUUsMEJBQTJCLENBQUMsQ0FBQyxJQUFJLENBQUUsS0FBTSxDQUFDO01BQzdEO01BQ0EsSUFBSyxHQUFHLEVBQUc7UUFDVixXQUFXLENBQUMsSUFBSSxDQUFFLG1CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFFLE1BQU0sRUFBRSxHQUFJLENBQUM7TUFDNUQ7SUFFRCxDQUFFLENBQUM7RUFDSjtFQUVBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUUsT0FBTyxFQUFFLHFCQUFxQixFQUFFLFVBQVUsQ0FBQyxFQUFFO0lBQzVELE9BQU8sT0FBTyxDQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUUsQ0FBQztFQUNsRCxDQUFFLENBQUM7QUFFSixDQUFDLENBQUM7Ozs7O0FDM2FGLElBQUksQ0FBQyxHQUFHLE1BQU07QUFDZCxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVU7RUFHM0I7QUFDRDtBQUNBOztFQUVDLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7RUFDOUIsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QixDQUFDO0VBRW5ELFlBQVksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFlBQVc7SUFDbkMsdUJBQXVCLENBQUMsQ0FBQztJQUN6QixPQUFPLEtBQUs7RUFDYixDQUFDLENBQUM7RUFFRixTQUFTLHVCQUF1QixDQUFBLEVBQUU7SUFDakMsSUFBSSxHQUFHLEdBQUcsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUN6QixFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRTtNQUFDLFNBQVMsRUFBQyxDQUFDO01BQUUsQ0FBQyxFQUFDLEVBQUU7TUFBRSxJQUFJLEVBQUMsTUFBTSxDQUFDO0lBQU8sQ0FBQyxDQUFDLENBQ3hELEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO01BQUMsTUFBTSxFQUFFLENBQUM7TUFBRSxTQUFTLEVBQUMsQ0FBQztNQUFFLElBQUksRUFBQyxNQUFNLENBQUM7SUFBTyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQ3ZFLEdBQUcsQ0FBQyxPQUFPLEVBQUU7TUFBQyxTQUFTLEVBQUM7SUFBTSxDQUFDLENBQUM7RUFFcEM7O0VBRUE7QUFDRDtBQUNBO0VBQ0MsQ0FBQyxDQUFFLGtDQUFtQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFFLGdDQUFpQyxDQUFDLENBQUMsRUFBRSxDQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsRUFBRztJQUNoRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFFLGtDQUFtQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7RUFDckUsQ0FBRSxDQUFDOztFQUVIO0FBQ0Q7QUFDQTs7RUFFQyxDQUFDLENBQUUsb0JBQXFCLENBQUMsQ0FBQyxJQUFJLENBQUUsWUFBVztJQUMxQyxJQUFJLE9BQU8sR0FBSyxDQUFDLENBQUUsSUFBSyxDQUFDO0lBQ3pCLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUUsK0JBQWdDLENBQUMsQ0FBQyxJQUFJLENBQUUsc0JBQXVCLENBQUM7SUFDakcsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFFLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFFLE1BQU8sQ0FBQyxHQUFHLGlCQUFrQixDQUFDO0lBRTNFLFNBQVMsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVc7TUFDakMsSUFBSyxTQUFTLENBQUMsRUFBRSxDQUFFLFVBQVcsQ0FBQyxFQUFHO1FBQ2pDLFNBQVMsQ0FBQyxHQUFHLENBQUUsU0FBUyxFQUFFLE9BQVEsQ0FBQztRQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFFLFNBQVMsRUFBRSxjQUFlLENBQUM7TUFDekMsQ0FBQyxNQUFLO1FBQ0wsU0FBUyxDQUFDLEdBQUcsQ0FBRSxTQUFTLEVBQUUsTUFBTyxDQUFDO1FBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUUsU0FBUyxFQUFFLE1BQU8sQ0FBQztNQUNqQztJQUNELENBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBRSxRQUFTLENBQUM7RUFDeEIsQ0FBRSxDQUFDOztFQUVIO0FBQ0Q7QUFDQTs7RUFFQztFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQzVELElBQUksT0FBTyxNQUFNLENBQUMsa0JBQWtCLEtBQUssVUFBVSxFQUFFO01BQ3BELElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7TUFDakIsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztNQUN2QyxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRTtNQUVqRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQztJQUMzQztFQUNELENBQUMsQ0FBQzs7RUFFRjtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxZQUFXO0lBQ25ELElBQUksT0FBTyxNQUFNLENBQUMsa0JBQWtCLEtBQUssVUFBVSxFQUFFO01BQ3BELElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLHVCQUF1QjtNQUNyRCxNQUFNLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0lBQ3BEO0VBQ0QsQ0FBQyxDQUFDOztFQUVGO0VBQ0EsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsWUFBVztJQUM1RCxJQUFJLE9BQU8sTUFBTSxDQUFDLGtCQUFrQixLQUFLLFVBQVUsRUFBRTtNQUNwRCxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztNQUMvQixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7O01BRXpCO01BQ0EsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLCtCQUErQixDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEVBQUU7UUFDakosTUFBTSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsR0FBRyxJQUFJLEVBQUUsV0FBVyxDQUFDO01BQ3hELENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQzVELE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLEVBQUUsU0FBUyxDQUFDO01BQ3RELENBQUMsTUFBTTtRQUNOLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7TUFDM0Q7SUFDRDtFQUNELENBQUMsQ0FBQzs7RUFFRjtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLG1EQUFtRCxFQUFFLFlBQVc7SUFDdkYsSUFBSSxPQUFPLE1BQU0sQ0FBQyxrQkFBa0IsS0FBSyxVQUFVLEVBQUU7TUFDcEQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztJQUMzRDtFQUNELENBQUMsQ0FBQzs7RUFFRjtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLDZDQUE2QyxFQUFFLFlBQVc7SUFDakYsSUFBSSxPQUFPLE1BQU0sQ0FBQyxrQkFBa0IsS0FBSyxVQUFVLEVBQUU7TUFDcEQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUM7SUFDbEQ7RUFDRCxDQUFDLENBQUM7O0VBR0Y7QUFDRDtBQUNBOztFQUVDLElBQUksa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixDQUFDO0lBQ2pELGdCQUFnQixHQUFHLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztJQUMxQyx1QkFBdUIsR0FBRyxDQUFDLENBQUMsNEJBQTRCLENBQUM7SUFDekQsd0JBQXdCLEdBQUcsQ0FBQyxDQUFDLGtDQUFrQyxDQUFDO0lBQ2hFLHNCQUFzQixHQUFHLENBQUMsQ0FBQyxlQUFlLENBQUM7RUFHNUMsc0JBQXNCLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTLENBQUMsRUFBRTtJQUM5QyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDbEIsZ0JBQWdCLENBQUMsQ0FBQztJQUNsQixPQUFPLEtBQUs7RUFDYixDQUFDLENBQUM7RUFFRix1QkFBdUIsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQy9DLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsQixpQkFBaUIsQ0FBQyxDQUFDO0lBQ25CLE9BQU8sS0FBSztFQUNiLENBQUMsQ0FBQztFQUVGLHdCQUF3QixDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBUyxDQUFDLEVBQUU7SUFDaEQsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2xCLG9CQUFvQixDQUFDLENBQUM7SUFDdEIsT0FBTyxLQUFLO0VBQ2IsQ0FBQyxDQUFDO0VBRUYsU0FBUyxnQkFBZ0IsQ0FBQSxFQUFFO0lBQzFCLElBQUksR0FBRyxHQUFHLElBQUksWUFBWSxDQUFDLENBQUMsQ0FDekIsR0FBRyxDQUFDLGtCQUFrQixFQUFFO01BQUMsU0FBUyxFQUFDO0lBQU8sQ0FBQyxDQUFDLENBQzVDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRTtNQUFDLFNBQVMsRUFBQztJQUFPLENBQUMsQ0FBQyxDQUMxQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFO01BQUMsU0FBUyxFQUFDO0lBQUMsQ0FBQyxFQUFDO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxJQUFJLEVBQUMsTUFBTSxDQUFDO0lBQU8sQ0FBQyxDQUFDLENBQy9FLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLEVBQUU7TUFBQyxTQUFTLEVBQUMsQ0FBQztNQUFFLFNBQVMsRUFBRSxDQUFDO0lBQUUsQ0FBQyxFQUFFO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxTQUFTLEVBQUMsQ0FBQztNQUFFLElBQUksRUFBQyxNQUFNLENBQUM7SUFBTyxDQUFDLEVBQUUsTUFBTSxDQUFDO0VBRTNIO0VBRUEsU0FBUyxpQkFBaUIsQ0FBQSxFQUFFO0lBQzNCLElBQUksR0FBRyxHQUFHLElBQUksWUFBWSxDQUFDLENBQUMsQ0FDekIsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEdBQUcsRUFBRTtNQUFDLFNBQVMsRUFBQyxDQUFDO01BQUUsU0FBUyxFQUFFO0lBQUMsQ0FBQyxFQUFFO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxTQUFTLEVBQUMsQ0FBQyxFQUFFO01BQUUsSUFBSSxFQUFDLE1BQU0sQ0FBQztJQUFPLENBQUMsQ0FBQyxDQUMvRyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFO01BQUMsU0FBUyxFQUFDO0lBQUMsQ0FBQyxFQUFDO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxJQUFJLEVBQUMsTUFBTSxDQUFDO0lBQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUN2RixHQUFHLENBQUMsa0JBQWtCLEVBQUU7TUFBQyxTQUFTLEVBQUM7SUFBTSxDQUFDLENBQUMsQ0FDM0MsR0FBRyxDQUFDLGdCQUFnQixFQUFFO01BQUMsU0FBUyxFQUFDO0lBQU0sQ0FBQyxDQUFDO0VBRTdDO0VBRUEsU0FBUyxvQkFBb0IsQ0FBQSxFQUFFO0lBQzlCLGlCQUFpQixDQUFDLENBQUM7SUFDbkIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7SUFFN0MsSUFBSSxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDO0lBRW5FLElBQUssZ0JBQWdCLEVBQUc7TUFDdkIsSUFBSSxXQUFXLEdBQUcsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFO1FBQUUsT0FBTyxFQUFFO01BQUssQ0FBQyxDQUFDO01BQ3hELGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUM7SUFDNUM7RUFDRDs7RUFFQTtFQUNBLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBWTtJQUNoRCxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQzNELENBQUMsQ0FBQzs7RUFFRjtBQUNEO0FBQ0E7O0VBRUMsSUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsb0JBQW9CLENBQUM7SUFDOUMscUJBQXFCLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0lBQ3JELG9CQUFvQixHQUFHLENBQUMsQ0FBQywyQkFBMkIsQ0FBQztFQUVyRCxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQVMsQ0FBQyxFQUFFO0lBQzVDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsQixtQkFBbUIsQ0FBQyxDQUFDO0lBQ3JCLE9BQU8sS0FBSztFQUNiLENBQUMsQ0FBQztFQUVGLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBVztJQUM1QyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3RCLE9BQU8sS0FBSztFQUNiLENBQUMsQ0FBQztFQUVGLFNBQVMsbUJBQW1CLENBQUEsRUFBRTtJQUM3QixJQUFJLEdBQUcsR0FBRyxJQUFJLFlBQVksQ0FBQyxDQUFDO0lBRTVCLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUU7TUFBQyxTQUFTLEVBQUM7SUFBTyxDQUFDLENBQUMsQ0FDNUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFO01BQUMsU0FBUyxFQUFDO0lBQU8sQ0FBQyxDQUFDLENBQzFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLEVBQUU7TUFBQyxTQUFTLEVBQUM7SUFBQyxDQUFDLEVBQUM7TUFBQyxTQUFTLEVBQUMsQ0FBQztNQUFFLElBQUksRUFBQyxNQUFNLENBQUM7SUFBTyxDQUFDLENBQUMsQ0FDL0UsTUFBTSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsRUFBRTtNQUFDLFNBQVMsRUFBQyxDQUFDO01BQUUsU0FBUyxFQUFFLENBQUM7SUFBRSxDQUFDLEVBQUU7TUFBQyxTQUFTLEVBQUMsQ0FBQztNQUFFLFNBQVMsRUFBQyxDQUFDO01BQUUsSUFBSSxFQUFDLE1BQU0sQ0FBQztJQUFPLENBQUMsRUFBRSxNQUFNLENBQUM7RUFFeEg7RUFFQSxTQUFTLG9CQUFvQixDQUFBLEVBQUU7SUFDOUIsSUFBSSxHQUFHLEdBQUcsSUFBSSxZQUFZLENBQUMsQ0FBQztJQUU1QixHQUFHLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsRUFBRTtNQUFDLFNBQVMsRUFBQyxDQUFDO01BQUUsU0FBUyxFQUFFO0lBQUMsQ0FBQyxFQUFFO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxTQUFTLEVBQUMsQ0FBQyxFQUFFO01BQUUsSUFBSSxFQUFDLE1BQU0sQ0FBQztJQUFPLENBQUMsQ0FBQyxDQUMvRyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxFQUFFO01BQUMsU0FBUyxFQUFDO0lBQUMsQ0FBQyxFQUFDO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxJQUFJLEVBQUMsTUFBTSxDQUFDO0lBQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUN2RixHQUFHLENBQUMsZ0JBQWdCLEVBQUU7TUFBQyxTQUFTLEVBQUM7SUFBTSxDQUFDLENBQUMsQ0FDekMsR0FBRyxDQUFDLGdCQUFnQixFQUFFO01BQUMsU0FBUyxFQUFDO0lBQU0sQ0FBQyxDQUFDO0VBRTVDOztFQUVBO0FBQ0Q7QUFDQTtFQUNDLElBQUksV0FBVyxHQUFNLENBQUMsQ0FBRSxjQUFlLENBQUM7RUFDeEMsSUFBSSxjQUFjLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQztFQUV0QyxjQUFjLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFXO0lBQ3RDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDdkIsQ0FBQyxDQUFDO0VBRUYsU0FBUyxhQUFhLENBQUMsS0FBSyxFQUFDO0lBQzVCLElBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBQztNQUN2QixXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBQyxPQUFPLENBQUM7TUFDbEMsWUFBWSxDQUFDLE9BQU8sQ0FBRSxrQkFBa0IsRUFBRSxJQUFLLENBQUM7SUFDakQsQ0FBQyxNQUNHO01BQ0gsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUMsTUFBTSxDQUFDO01BQ2pDLFlBQVksQ0FBQyxPQUFPLENBQUUsa0JBQWtCLEVBQUUsS0FBTSxDQUFDO0lBQ2xEO0VBQ0Q7O0VBSUE7QUFDRDtBQUNBOztFQUVDLElBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBQztJQUMxQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUM7RUFDekMsQ0FBQyxNQUFNO0lBQ04sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDO0VBQzFDO0VBRUEsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQztFQUNoQyxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsb0JBQW9CLENBQUM7RUFFM0MsYUFBYSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBVztJQUNwQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3ZCLE9BQU8sS0FBSztFQUNiLENBQUMsQ0FBQztFQUVGLFNBQVMscUJBQXFCLENBQUEsRUFBRTtJQUMvQixJQUFJLEdBQUcsR0FBRyxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQ3pCLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFO01BQUMsU0FBUyxFQUFDLENBQUM7TUFBRSxDQUFDLEVBQUMsRUFBRTtNQUFFLElBQUksRUFBQyxNQUFNLENBQUM7SUFBTyxDQUFDLENBQUMsQ0FDekQsRUFBRSxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUU7TUFBQyxNQUFNLEVBQUUsQ0FBQztNQUFFLFNBQVMsRUFBQyxDQUFDO01BQUUsSUFBSSxFQUFDLE1BQU0sQ0FBQztJQUFPLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FDeEUsR0FBRyxDQUFDLFFBQVEsRUFBRTtNQUFDLFNBQVMsRUFBQztJQUFNLENBQUMsQ0FBQztFQUVyQzs7RUFFQTtFQUNBLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLGdDQUFnQyxFQUFFLFlBQVc7SUFDcEUsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0lBQzNDLElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLENBQUM7O0lBRS9EO0lBQ0EsSUFBSSxPQUFPLE1BQU0sQ0FBQyxrQkFBa0IsS0FBSyxVQUFVLEVBQUU7TUFDcEQsTUFBTSxDQUFDLGtCQUFrQixDQUFDLDJDQUEyQyxFQUFFLFdBQVcsQ0FBQztJQUNwRjtJQUVBLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRTtNQUNsQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxZQUFXO1FBQ3BDLEtBQUssQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDO01BQ2pDLENBQUMsQ0FBQztNQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDO01BQ2xDO0lBQ0Q7SUFFQSxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUM3QixZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztJQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztFQUNoQyxDQUFDLENBQUM7O0VBRUY7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxvQ0FBb0MsRUFBRSxZQUFXO0lBQ3hFLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxTQUFTOztJQUVoRTtJQUNBO0lBQ0EsVUFBVSxDQUFDLFlBQVc7TUFDckIsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLElBQUksY0FBYyxFQUFFLENBQUM7TUFFckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQy9DO01BQ0Q7TUFFQSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO1FBQUUsUUFBUSxFQUFFLFFBQVE7UUFBRSxLQUFLLEVBQUU7TUFBUyxDQUFDLENBQUM7SUFDbkUsQ0FBQyxFQUFFLEdBQUcsQ0FBQzs7SUFFUDtJQUNBLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUU7TUFDdEQ7TUFDQSxJQUFJLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxJQUFJLG9CQUFvQixDQUFDLGFBQWEsSUFBSSxvQkFBb0IsQ0FBQyxhQUFhLEtBQUssR0FBRyxFQUFFO1FBQ3BJO1FBQ0EsSUFBSSxvQkFBb0IsQ0FBQyxPQUFPLElBQUksT0FBTyxRQUFRLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtVQUM1RSxRQUFRLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQztRQUNoRDs7UUFFQTtRQUNBLFFBQVEsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUU7VUFDaEMsUUFBUSxFQUFFLGdDQUFnQztVQUMxQyxnQkFBZ0IsRUFBRSxjQUFjO1VBQ2hDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQyxNQUFNO1VBQ3JDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQyxLQUFLO1VBQ25DLGFBQWEsRUFBRSxvQkFBb0IsQ0FBQyxHQUFHO1VBQ3ZDLFNBQVMsRUFBRSxvQkFBb0IsQ0FBQyxPQUFPO1VBQ3ZDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQyxJQUFJO1VBQ2pDLHFCQUFxQixFQUFFO1FBQ3hCLENBQUMsQ0FBQztNQUNIO0lBQ0Q7RUFDRCxDQUFDLENBQUM7O0VBRUY7RUFDQSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSx3Q0FBd0MsRUFBRSxZQUFXO0lBQzVFO0lBQ0EsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO01BQ3ZEO0lBQ0Q7O0lBRUE7SUFDQSxJQUFJLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxJQUFJLG9CQUFvQixDQUFDLGFBQWEsS0FBSyxHQUFHLEVBQUU7TUFDckk7SUFDRDs7SUFFQTtJQUNBLElBQUksb0JBQW9CLENBQUMsT0FBTyxJQUFJLE9BQU8sUUFBUSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7TUFDNUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUM7SUFDaEQ7O0lBRUE7SUFDQSxRQUFRLENBQUMsS0FBSyxDQUFDLGdEQUFnRCxFQUFFO01BQ2hFLFFBQVEsRUFBRSw2QkFBNkI7TUFDdkMsUUFBUSxFQUFFLHVCQUF1QjtNQUNqQyxRQUFRLEVBQUUsb0JBQW9CLENBQUMsTUFBTTtNQUNyQyxPQUFPLEVBQUUsb0JBQW9CLENBQUMsS0FBSztNQUNuQyxhQUFhLEVBQUUsb0JBQW9CLENBQUMsR0FBRztNQUN2QyxTQUFTLEVBQUUsb0JBQW9CLENBQUMsT0FBTztNQUN2QyxNQUFNLEVBQUUsb0JBQW9CLENBQUMsSUFBSTtNQUNqQyxxQkFBcUIsRUFBRTtJQUN4QixDQUFDLENBQUM7RUFDSCxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7Ozs7Ozs7O0FDaldGLE1BQU0sY0FBYyxDQUFDO0VBbUJwQixXQUFXLENBQUUsTUFBTSxFQUFHO0lBQUEsZUFBQSxzQkFqQlIsQ0FDYixXQUFXLEVBQ1gsaUJBQWlCLEVBQ2pCLFVBQVUsRUFDVixtQkFBbUIsRUFDbkIsT0FBTyxFQUNQLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsVUFBVSxFQUNWLFdBQVcsRUFDWCxRQUFRLEVBQ1IsU0FBUyxFQUNULFdBQVcsRUFDWCxTQUFTLEVBQ1QsT0FBTyxDQUNQO0lBR0EsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNO0VBQ3JCOztFQUVBO0FBQ0Q7QUFDQTtFQUNDLElBQUksQ0FBQSxFQUFHO0lBQ04sSUFBSyxPQUFPLFFBQVEsS0FBSyxXQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFHO01BQ3pEO0lBQ0Q7SUFDQSxJQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEtBQUssR0FBRyxFQUFFO01BQ3JFO0lBQ0Q7SUFDQSxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0lBQ3RDLElBQUksQ0FBQyxjQUFjLENBQUUsSUFBSyxDQUFDO0VBQzVCOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxjQUFjLENBQUUsSUFBSSxFQUFHO0lBQ3RCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUUsSUFBSyxDQUFFLENBQUM7SUFDeEUsTUFBTSxDQUFDLGdCQUFnQixDQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBRSxJQUFLLENBQUUsQ0FBQztFQUNqRTs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsYUFBYSxDQUFFLEtBQUssRUFBRztJQUN0QixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDM0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0lBRTNELElBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFHO01BQ2xDO0lBQ0Q7SUFFQSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBRSxPQUFRLENBQUMsRUFBRSxPQUFPLENBQUM7RUFDL0Q7RUFFQSxXQUFXLENBQUEsRUFBRztJQUNiLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDckQsSUFBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUc7TUFDbEM7SUFDRDtJQUVBLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUM7RUFDdEQ7RUFFQSxVQUFVLENBQUUsT0FBTyxFQUFHO0lBQ3JCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQ3pDLE9BQU8sT0FBTztJQUNmO0lBQ0EsT0FBTyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztFQUM1QjtFQUVBLFlBQVksQ0FBQyxPQUFPLEVBQUU7SUFDckIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7RUFDMUM7RUFFQSxVQUFVLENBQUUsT0FBTyxHQUFHLEVBQUUsRUFBRztJQUMxQixJQUFLLE9BQU8sRUFBRztNQUNkLE9BQU8sWUFBWSxPQUFPLEVBQUU7SUFDN0I7SUFFQSxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsb0NBQW9DLENBQUMsQ0FBQztJQUN4RCxJQUFLLE1BQU0sRUFBRztNQUNiLE9BQU8sTUFBTTtJQUNkO0lBRUEsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztFQUNyQztFQUVBLG9DQUFvQyxDQUFBLEVBQUc7SUFDdEMsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDekMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLFlBQVk7O0lBRWxDO0lBQ0EsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLEVBQUU7TUFDcEMsT0FBTyxFQUFFO0lBQ1Y7O0lBRUE7SUFDQSxNQUFNLFdBQVcsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQzs7SUFFbEQ7SUFDQSxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQzs7SUFFakM7SUFDQTtJQUNBLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0lBRTNFO0lBQ0EsT0FBTyxXQUFXO0VBQ25CO0VBRUEsc0JBQXNCLENBQUEsRUFBRztJQUN4QixNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUTtJQUNsQyxJQUFJLENBQUMsUUFBUSxFQUFFO01BQ2QsT0FBTyxZQUFZO0lBQ3BCO0lBQ0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtNQUNqRCxPQUFPLFVBQVU7SUFDbEI7SUFDQSxPQUFPLFVBQVU7RUFDbEI7RUFFQSxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFO0lBQ3JDLFFBQVEsQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO01BQzdCLElBQUksRUFBRSwrQ0FBK0MsT0FBTyxFQUFFO01BQzlELFNBQVMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7TUFDcEMsTUFBTSxFQUFFLE1BQU07TUFDZCxNQUFNLEVBQUUsb0JBQW9CLENBQUMsTUFBTTtNQUNuQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsS0FBSztNQUNqQyxXQUFXLEVBQUUsb0JBQW9CLENBQUMsR0FBRztNQUNyQyxPQUFPLEVBQUUsb0JBQW9CLENBQUMsT0FBTztNQUNyQyxtQkFBbUIsRUFBRTtJQUN0QixDQUFDLENBQUM7RUFDSDs7RUFFQTtBQUNEO0FBQ0E7RUFDQyxPQUFPLEdBQUcsQ0FBQSxFQUFHO0lBQ1o7SUFDQSxJQUFLLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxFQUFHO01BQ2xEO0lBQ0Q7SUFFQSxNQUFNLFFBQVEsR0FBRyxJQUFJLGNBQWMsQ0FBRSxvQkFBcUIsQ0FBQztJQUMzRCxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDaEI7QUFDRDtBQUVBLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Ozs7QUM3SnBCLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxrQkFBa0IsRUFBRSxZQUFZO0VBRXZELElBQUksWUFBWSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDO0VBQ3pELElBQUcsWUFBWSxFQUFDO0lBQ1osSUFBSSxXQUFXLENBQUMsWUFBWSxDQUFDO0VBQ2pDO0FBRUosQ0FBQyxDQUFDOztBQUdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUU7RUFFeEIsSUFBSSxPQUFPLEdBQUcsSUFBSTtFQUVsQixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDO0VBQ2hELElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQztFQUM1RCxJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsMkNBQTJDLENBQUM7RUFDeEYsSUFBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDO0VBQ3BELElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7RUFDdEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztFQUN0RCxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUM7RUFDeEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO0VBQ3RELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSTtFQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7RUFDakIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJO0VBQ2xCLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQztFQUNoQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSztFQUUxQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7O0VBRXBCO0VBQ0EsTUFBTSxDQUFDLFlBQVksR0FBRyxZQUFXO0lBQzdCLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUN0QixDQUFDOztFQUVEO0VBQ0EsSUFBRyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBQztJQUNwQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUM7SUFDaEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ25CLENBQUMsTUFDRztJQUNBLElBQUksT0FBTyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0lBQzlDLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQztJQUVoQixJQUFHLE9BQU8sRUFBQztNQUNQLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLE9BQU87TUFDOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25CLENBQUMsTUFDRztNQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7TUFDNUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDO01BQzdDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLFlBQVk7SUFDdkM7RUFDSjs7RUFFQTtFQUNBLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxZQUFXO01BQ2hDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztNQUNwQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDdkMsSUFBRyxTQUFTLElBQUksT0FBTyxDQUFDLE1BQU0sSUFBSSxTQUFTLElBQUksU0FBUyxFQUFDO1FBQ3JELE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsQixPQUFPLEtBQUs7TUFDaEI7SUFDSixDQUFDO0VBQ0w7O0VBRUE7RUFDQSxJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsaUNBQWlDLENBQUM7RUFDOUUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDekMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxZQUFXO01BQ2hDLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0VBQ0w7RUFFQSxRQUFRLENBQUMsZ0JBQWdCLENBQUUsc0JBQXNCLEVBQUUsWUFBVztJQUMxRCxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztFQUN2QyxDQUFFLENBQUM7QUFFUDs7QUFHQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsR0FBRyxZQUFXO0VBQ3hDLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNoRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNO0VBQ2pGLFlBQVksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7RUFFN0MsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO0VBQy9ELElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztFQUVsRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakIsQ0FBQzs7QUFJRDtBQUNBO0FBQ0E7QUFDQSxXQUFXLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxZQUFXO0VBQzFDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztFQUNoRCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMxRCxDQUFDOztBQUlEO0FBQ0E7QUFDQTtBQUNBLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLFlBQVc7RUFFdEMsSUFBSSxPQUFPLEdBQUcsSUFBSTtFQUNsQixRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsT0FBTzs7RUFFcEQ7RUFDQSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU07RUFDekM7RUFDQSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztFQUNuRDs7RUFFQTtFQUNBLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPO0VBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPO0VBRTFDLElBQUssSUFBSSxLQUFLLFlBQVksQ0FBQyxPQUFPLENBQUUsa0JBQW1CLENBQUMsRUFBRztJQUN2RCxZQUFZLENBQUMsT0FBTyxDQUFFLGtCQUFrQixFQUFFLElBQUssQ0FBQztFQUNwRDtFQUVBLElBQUssSUFBSSxLQUFLLFlBQVksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRztJQUNyRCxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtFQUN4QyxDQUFDLE1BQU0sSUFBSyxLQUFLLEtBQUssWUFBWSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFHO0lBQzdELElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNO0lBQ3BDLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUMsZUFBZSxDQUFFLFNBQVUsQ0FBQztFQUN2RTtFQUVBLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPO0VBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7RUFDeEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVU7RUFDMUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztFQUV4QyxNQUFNLGtCQUFrQixHQUFHLENBQ3ZCLFdBQVcsRUFDWCxRQUFRLEVBQ1IsVUFBVSxFQUNWLE9BQU8sRUFDUCxRQUFRLEVBQ1IsU0FBUyxFQUNULFdBQVcsRUFDWCxTQUFTLENBQ1o7RUFFRCxNQUFNLHlCQUF5QixHQUFHLENBQzlCLFdBQVcsRUFDWCxTQUFTLEVBQ1QsVUFBVSxDQUNiOztFQUVEO0VBQ0EsSUFBRyxJQUFJLENBQUMsTUFBTSxJQUFJLFdBQVcsRUFBQztJQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtJQUNwQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0VBQy9DO0VBRUEsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRTtJQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtFQUN4QztFQUVBLElBQUkseUJBQXlCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtJQUNqRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtFQUNyQztFQUVBLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtJQUMxQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtFQUM3QztFQUVBLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDOztFQUVuQztFQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsNkJBQTZCLEVBQUU7SUFDckUsTUFBTSxFQUFFO01BQ1AsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO01BQ25CLFlBQVksRUFBRSxJQUFJLENBQUM7SUFDcEI7RUFDRCxDQUFFLENBQUUsQ0FBQztBQUNOLENBQUM7O0FBR0Q7QUFDQTtBQUNBO0FBQ0EsV0FBVyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsR0FBRyxZQUFXO0VBQzVELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUU7SUFDdkU7RUFDRDtFQUVBLElBQUksU0FBUyxHQUFHLFVBQVUsS0FBSyxJQUFJLENBQUMsTUFBTTtFQUMxQyxJQUFJLG9CQUFvQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQ2hELHNFQUNELENBQUM7RUFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxTQUFTLElBQUksQ0FBQyxDQUFDLG9CQUFvQjtBQUNsRSxDQUFDOzs7OztBQzFORDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxDQUFDLEdBQUcsTUFBTTtBQUNkLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBVTtFQUMzQjtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsMkJBQTJCLENBQUMsSUFBSSxFQUFFO0lBQzFDLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQztJQUV4QyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUU7TUFDNUM7SUFDRDs7SUFFQTtJQUNBLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDaEQ7O0VBSUE7QUFDRDtBQUNBO0VBQ0MsU0FBUywwQkFBMEIsQ0FBQSxFQUFHO0lBQ3JDO0lBQ0EsSUFBSSxNQUFNLENBQUMsRUFBRSxJQUFJLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFO01BQ3BDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDO1FBQ2xCLElBQUksRUFBRTtNQUNQLENBQUMsQ0FBQyxDQUNBLElBQUksQ0FBQyxVQUFVLElBQUksRUFBRTtRQUNyQiwyQkFBMkIsQ0FBQyxJQUFJLENBQUM7TUFDbEMsQ0FBQyxDQUFDLENBQ0QsS0FBSyxDQUFDLFVBQVUsS0FBSyxFQUFFO1FBQ3ZCLE9BQU8sQ0FBQyxLQUFLLENBQUMseUNBQXlDLEVBQUUsS0FBSyxDQUFDO01BQ2hFLENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTTtNQUNOO01BQ0EsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsSUFBSSxHQUFHLDhCQUE4QixFQUFFO1FBQ2xFLE9BQU8sRUFBRTtVQUNSLFlBQVksRUFBRSxNQUFNLENBQUMsYUFBYSxFQUFFLEtBQUssSUFBSTtRQUM5QztNQUNELENBQUMsQ0FBQyxDQUNBLElBQUksQ0FBQyxVQUFVLFFBQVEsRUFBRTtRQUN6QixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRTtVQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDO1FBQy9DO1FBQ0EsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7TUFDdkIsQ0FBQyxDQUFDLENBQ0QsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFO1FBQ3JCLDJCQUEyQixDQUFDLElBQUksQ0FBQztNQUNsQyxDQUFDLENBQUMsQ0FDRCxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUU7UUFDdkIsT0FBTyxDQUFDLEtBQUssQ0FBQyx5Q0FBeUMsRUFBRSxLQUFLLENBQUM7TUFDaEUsQ0FBQyxDQUFDO0lBQ0o7RUFDRDs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtFQUNDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsOEVBQThFLEVBQUUsTUFBTTtJQUNwRywwQkFBMEIsQ0FBQyxDQUFDO0VBQzdCLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQzs7Ozs7QUN2RUYsQ0FBSSxRQUFRLElBQU07RUFDakIsWUFBWTs7RUFFWjtBQUNEO0FBQ0E7RUFDQyxNQUFNLDJCQUEyQixDQUFDO0lBQ2pDLFdBQVcsQ0FBQSxFQUFHO01BQ2IsSUFBSSxDQUFDLElBQUksR0FBRyxzQ0FBc0M7TUFDbEQsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsQ0FBQztNQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQyxDQUFDO01BQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSTtNQUNuQixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUM7TUFFbkIsUUFBUSxDQUFDLGdCQUFnQixDQUFFLDhCQUE4QixFQUFFLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFFLENBQUM7O01BRS9FO01BQ0EsTUFBTSxPQUFPLEdBQUcsQ0FDZix5QkFBeUIsRUFDekIsNkJBQTZCLENBQzdCO01BRUQsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBRSxHQUFHLElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBRSxHQUFJLENBQUMsS0FBSyxJQUFLLENBQUM7TUFFakYsSUFBSyxVQUFVLEVBQUc7UUFDakIsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO01BQ2I7SUFDRDs7SUFFQTtBQUNGO0FBQ0E7SUFDRSxLQUFLLENBQUEsRUFBRztNQUNQLElBQUssSUFBSSxDQUFDLE9BQU8sRUFBRztRQUNuQjtNQUNEO01BRUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO01BQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNaOztJQUVBO0FBQ0Y7QUFDQTtJQUNFLElBQUksQ0FBQSxFQUFHO01BQ04sSUFBSyxJQUFJLENBQUMsT0FBTyxFQUFHO1FBQ25CLFlBQVksQ0FBRSxJQUFJLENBQUMsT0FBUSxDQUFDO1FBQzVCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSTtNQUNwQjtJQUNEOztJQUVBO0FBQ0Y7QUFDQTtJQUNFLElBQUksQ0FBQSxFQUFHO01BQ04sSUFBSyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUc7UUFDekMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ1g7TUFDRDtNQUVBLElBQUksQ0FBQyxVQUFVLEVBQUU7TUFFakIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUU7UUFDbkIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1FBQ2YsTUFBTSxFQUFFO01BQ1QsQ0FBRSxDQUFDLENBQUMsSUFBSSxDQUFJLFFBQVEsSUFBTTtRQUN6QixJQUFLLENBQUUsUUFBUSxJQUFJLENBQUUsUUFBUSxDQUFDLFVBQVUsRUFBRztVQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7VUFDWCxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1VBQ3hCO1FBQ0Q7UUFFQSxJQUFJLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBRSxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxZQUFhLENBQUM7TUFDbEUsQ0FBRSxDQUFDLENBQUMsS0FBSyxDQUFFLE1BQU07UUFDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUUsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBYSxDQUFDO01BQ2xFLENBQUUsQ0FBQztJQUNKO0VBQ0Q7RUFFQSxJQUFJLDJCQUEyQixDQUFDLENBQUM7QUFDbEMsQ0FBQyxFQUFJLFFBQVMsQ0FBQzs7Ozs7QUNoRmY7QUFDQTtBQUNBLENBQUUsQ0FBRSxRQUFRLEVBQUUsTUFBTSxLQUFNO0VBQ3pCLFlBQVk7O0VBRVosTUFBTSxZQUFZLEdBQUc7SUFDcEIsTUFBTSxFQUFFLEtBQUs7SUFBSztJQUNsQixTQUFTLEVBQUUsSUFBSSxDQUFHO0VBQ25CLENBQUM7RUFFRCxRQUFRLENBQUMsZ0JBQWdCLENBQUUsNkJBQTZCLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQyxvQkFBb0IsQ0FBRSxDQUFDO0VBQzFILFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSw4QkFBOEIsRUFBRSxNQUFNLG1DQUFtQyxDQUFFLHFCQUFzQixDQUFFLENBQUM7RUFDL0gsUUFBUSxDQUFDLGdCQUFnQixDQUFFLDZCQUE2QixFQUFFLE1BQU0sZ0NBQWdDLENBQUUsWUFBWSxDQUFDLFNBQVUsQ0FBRSxDQUFDO0VBRTVILFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxrQkFBa0IsRUFBRSxNQUFNO0lBQ3BELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBRSxxQkFBc0IsQ0FBQyxDQUFDLE9BQU8sQ0FBSSxFQUFFLElBQU07TUFDckUsRUFBRSxDQUFDLGdCQUFnQixDQUFFLE9BQU8sRUFBSSxDQUFDLElBQU07UUFDdEMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFFLDRCQUE2QixDQUFDO1FBQ25FLHFCQUFxQixDQUFFLEtBQU0sQ0FBQztNQUMvQixDQUFFLENBQUM7SUFDSixDQUFFLENBQUM7O0lBRUg7SUFDQSxVQUFVLENBQUMsSUFBSSxDQUFFO01BQ2hCLGFBQWEsRUFBRTtJQUNoQixDQUFFLENBQUM7SUFFSCxxQkFBcUIsQ0FBQyxDQUFDOztJQUV2QjtJQUNBLElBQUssQ0FBRSxNQUFNLENBQUMsa0JBQWtCLElBQUksTUFBTSxDQUFDLGtCQUFrQixLQUFLLEVBQUUsRUFBRztNQUN0RSxjQUFjLENBQUMsQ0FBQztNQUVoQixNQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDO01BQzFELE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsNEJBQTRCLENBQUM7TUFDcEUsSUFBSyxNQUFNLElBQUksTUFBTSxFQUFHO1FBQ3ZCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsWUFBVztVQUMxQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNO1FBQzlCLENBQUMsQ0FBQztNQUNIO0lBQ0Q7RUFDRCxDQUFFLENBQUM7O0VBRUg7QUFDRDtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsVUFBVSxDQUFBLEVBQUc7SUFDckIsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxXQUFXO0VBQzVDO0VBRUEsU0FBUyxvQkFBb0IsQ0FBQSxFQUFHO0lBQy9CLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMEJBQTJCLENBQUM7SUFDckUsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxvQkFBcUIsQ0FBQzs7SUFFN0Q7SUFDQSxJQUFLLE1BQU0sSUFBSSxDQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFFLGNBQWUsQ0FBQyxFQUFHO01BQzlELGdDQUFnQyxDQUFFLFlBQVksQ0FBQyxNQUFPLENBQUM7SUFDeEQsQ0FBQyxNQUFNLElBQUssUUFBUSxJQUFJLENBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUUsY0FBZSxDQUFDLEVBQUc7TUFDekUsZ0NBQWdDLENBQUUsWUFBWSxDQUFDLFNBQVUsQ0FBQztJQUMzRDtFQUNEO0VBRUEsTUFBTSxDQUFDLGdCQUFnQixDQUFFLE1BQU0sRUFBRSxNQUFNO0lBQ3RDLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUseUJBQTBCLENBQUM7TUFDaEUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMEJBQTJCLENBQUM7TUFDL0QsUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsMEJBQTJCLENBQUM7TUFDL0QsTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUUsb0JBQXFCLENBQUM7TUFDdkQsV0FBVyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsOEJBQThCLENBQUM7SUFFckUsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFFLDJCQUE0QixDQUFDOztJQUUxRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0lBQ0UsU0FBUyxpQkFBaUIsQ0FBQSxFQUFHO01BQzVCLElBQUssQ0FBRSxNQUFNLElBQUksQ0FBRSxTQUFTLENBQUMsTUFBTSxFQUFHO1FBQ3JDO01BQ0Q7TUFFQSxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw4QkFBK0IsQ0FBQztNQUM3RSxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBRSw2QkFBNkIsRUFBRSxDQUFFLFdBQVksQ0FBQztNQUN2RSxTQUFTLENBQUMsT0FBTyxDQUFJLEVBQUUsSUFBTTtRQUM1QixFQUFFLENBQUMsWUFBWSxDQUFFLGVBQWUsRUFBRSxXQUFXLEdBQUcsT0FBTyxHQUFHLE1BQU8sQ0FBQztNQUNuRSxDQUFFLENBQUM7TUFFSCxJQUFJLENBQUUsV0FBVyxFQUFHO1FBQ25CLGtDQUFrQyxDQUFFLFFBQVMsQ0FBQztNQUMvQyxDQUFDLE1BQU07UUFDTixtQ0FBbUMsQ0FBQyxDQUFDO01BQ3RDO0lBQ0Q7SUFFQSxJQUFLLFNBQVMsQ0FBQyxNQUFNLElBQUksTUFBTSxFQUFHO01BQ2pDLFNBQVMsQ0FBQyxPQUFPLENBQUksRUFBRSxJQUFNO1FBQzVCLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBRSxPQUFPLEVBQUUsaUJBQWtCLENBQUM7UUFDakQsRUFBRSxDQUFDLGdCQUFnQixDQUFFLFNBQVMsRUFBSSxLQUFLLElBQU07VUFDNUMsSUFBSyxPQUFPLEtBQUssS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUssS0FBSyxDQUFDLEdBQUcsRUFBRztZQUNqRCxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDdEIsaUJBQWlCLENBQUMsQ0FBQztVQUNwQjtRQUNELENBQUUsQ0FBQztNQUNKLENBQUUsQ0FBQztJQUNKOztJQUVBO0lBQ0Esb0JBQW9CLENBQUMsQ0FBQzs7SUFFdEI7SUFDQSxNQUFNLENBQUMsZ0JBQWdCLENBQUUsWUFBWSxFQUFFLE1BQU07TUFDNUMsb0JBQW9CLENBQUMsQ0FBQztJQUN2QixDQUFFLENBQUM7O0lBRUg7SUFDQSxNQUFNLE1BQU0sR0FBRztNQUNkLE9BQU8sRUFBRTtRQUNSLE9BQU8sRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsK0NBQStDLENBQUM7UUFDbkYsT0FBTyxFQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxpQ0FBaUMsQ0FBQztRQUNyRSxNQUFNLEVBQUUsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGlEQUFpRDtNQUNwRixDQUFDO01BQ0QsTUFBTSxFQUFFO1FBQ1AsT0FBTyxFQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyw4Q0FBOEMsQ0FBQztRQUNsRixPQUFPLEVBQUUsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGdDQUFnQyxDQUFDO1FBQ3BFLE1BQU0sRUFBRSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsZ0RBQWdEO01BQ25GO0lBQ0QsQ0FBQzs7SUFFRDtJQUNBLElBQUssV0FBVyxFQUFHO01BQ2xCLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsWUFBWTtRQUNsRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTztRQUU3QixJQUFJLFFBQVEsRUFBRTtVQUNiLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztVQUNuRyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7UUFDdEcsQ0FBQyxNQUFNO1VBQ04sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1VBQ3RHLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztRQUNuRzs7UUFFQTtRQUNBLDJCQUEyQixDQUFDLFFBQVEsQ0FBQztNQUN0QyxDQUFDLENBQUM7SUFDSDs7SUFFQTtJQUNBLE1BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsK0JBQStCLENBQUM7SUFDN0UsSUFBSSxhQUFhLEVBQUU7TUFDbEIsYUFBYSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNO1FBQzdDLDJCQUEyQixDQUFDLENBQUM7TUFDOUIsQ0FBQyxDQUFDO0lBQ0g7RUFFRCxDQUFFLENBQUM7RUFFSCxNQUFNLENBQUMsU0FBUyxHQUFLLENBQUMsSUFBTTtJQUMzQixNQUFNLFNBQVMsR0FBRyxnQkFBZ0IsQ0FBQyxVQUFVO0lBRTdDLElBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUc7TUFDN0I7SUFDRDtJQUVBLGlCQUFpQixDQUFFLENBQUMsQ0FBQyxJQUFLLENBQUM7SUFDM0IsVUFBVSxDQUFFLENBQUMsQ0FBQyxJQUFLLENBQUM7SUFDcEIsWUFBWSxDQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsU0FBVSxDQUFDO0lBQ2pDLGFBQWEsQ0FBRSxDQUFDLENBQUMsSUFBSyxDQUFDO0lBQ3ZCLFNBQVMsQ0FBRSxDQUFDLENBQUMsSUFBSSxFQUFFLFNBQVUsQ0FBQztJQUM5QixVQUFVLENBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxTQUFVLENBQUM7SUFDL0IscUJBQXFCLENBQUUsQ0FBQyxDQUFDLElBQUssQ0FBQztFQUNoQyxDQUFDO0VBRUQsU0FBUyxrQkFBa0IsQ0FBQSxFQUFHO0lBQzdCLE1BQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUM7SUFDbkUsSUFBSyxDQUFDLGVBQWUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSyxlQUFlLENBQUMsR0FBRyxFQUFHO01BQzFJO0lBQ0Q7SUFDQSxlQUFlLENBQUMsR0FBRyxHQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRztJQUNqRCxVQUFVLENBQUMsSUFBSSxDQUFFLHFCQUFzQixDQUFDO0VBQ3pDO0VBRUEsU0FBUyxxQkFBcUIsQ0FBRSxLQUFLLEVBQUc7SUFDdkMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxNQUFNLENBQUMsa0JBQWtCO0lBQzVDO0lBQ0EsSUFBSyxLQUFLLEVBQUc7TUFDWiw4QkFBOEIsQ0FBQyxXQUFXLENBQUM7SUFDNUM7O0lBRUE7SUFDQTtJQUNBO0lBQ0EsTUFBTSxNQUFNLEdBQUcsS0FBSyxHQUFHLFlBQVksR0FBRyxtQkFBbUI7O0lBRXpEO0lBQ0EsSUFBSyxDQUFDLFdBQVcsRUFBRztNQUNuQixNQUFNLENBQUMsa0JBQWtCLEdBQUcsY0FBYyxDQUFFLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxNQUFPLENBQUM7O01BRS9FO01BQ0EsVUFBVSxDQUFFLFlBQVc7UUFDdEIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLGtCQUFrQjtNQUNqRCxDQUFDLEVBQUUsR0FBSSxDQUFDO0lBQ1QsQ0FBQyxNQUFNO01BQ047TUFDQSxNQUFNLENBQUMscUJBQXFCLEdBQUcsTUFBTTs7TUFFckM7TUFDQSxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3JCO0VBQ0Q7O0VBRUE7QUFDRDtBQUNBO0FBQ0E7QUFDQTtFQUNDLFNBQVMsMkJBQTJCLENBQUUsUUFBUSxFQUFHO0lBQ2hELElBQUssQ0FBRSxNQUFNLENBQUMsa0JBQWtCLElBQUksTUFBTSxDQUFDLGtCQUFrQixLQUFLLEVBQUUsRUFBRztNQUN0RTtJQUNEO0lBRUEsTUFBTSxDQUFDLGtCQUFrQixHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUM7RUFDbkY7RUFFQSxTQUFTLGNBQWMsQ0FBQSxFQUFHO0lBQ3pCLElBQUksUUFBUSxHQUFHLEVBQUU7SUFFakIsUUFBUSxJQUFJLGlDQUFpQztJQUM3QyxRQUFRLElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLEtBQUs7SUFFOUMsTUFBTSxPQUFPLEdBQUcsZUFBZSxDQUFFLFFBQVMsQ0FBQztJQUUzQyxPQUFPLENBQUMsa0JBQWtCLEdBQUcsTUFBTTtNQUNsQyxJQUFLLE9BQU8sQ0FBQyxVQUFVLEtBQUssY0FBYyxDQUFDLElBQUksSUFBSSxHQUFHLEtBQUssT0FBTyxDQUFDLE1BQU0sRUFBRztRQUMzRSxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7UUFFbEQsSUFBSyxJQUFJLEtBQUssV0FBVyxDQUFDLE9BQU8sRUFBRztVQUNuQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ3JCO01BQ0Q7SUFDRCxDQUFDO0VBQ0Y7RUFFQSxTQUFTLHFCQUFxQixDQUFBLEVBQUc7SUFDaEMsTUFBTSxTQUFTLEdBQUcsSUFBSSxlQUFlLENBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFPLENBQUM7SUFFL0QsSUFBSyxTQUFTLENBQUMsR0FBRyxDQUFFLHVCQUF3QixDQUFDLElBQUksR0FBRyxLQUFLLFNBQVMsQ0FBQyxHQUFHLENBQUUsdUJBQXdCLENBQUMsRUFBRztNQUNuRztNQUNBLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLFdBQVc7TUFFbEMsa0JBQWtCLENBQUMsQ0FBQzs7TUFFcEI7TUFDQSxTQUFTLENBQUMsTUFBTSxDQUFFLHVCQUF3QixDQUFDO01BQzNDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztNQUNuQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsSUFBSyxNQUFNLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxFQUFFLENBQUUsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUk7TUFDL0YsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU8sQ0FBQztJQUM5QztFQUNEO0VBRUEsU0FBUyxVQUFVLENBQUUsSUFBSSxFQUFHO0lBQzNCLElBQUssQ0FBRSxJQUFJLENBQUMsY0FBYyxDQUFFLGVBQWdCLENBQUMsRUFBRztNQUMvQztJQUNEO0lBRUEsVUFBVSxDQUFDLEtBQUssQ0FBRSxxQkFBc0IsQ0FBQztJQUN6QztJQUNBLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxFQUFFO0lBRWpDLElBQUksS0FBSyxHQUFHLENBQUUsd0JBQXdCLEVBQUUsNEJBQTRCLENBQUU7SUFFdEUsSUFBSyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUUsa0JBQW1CLENBQUMsRUFBRztNQUNsRDtJQUNEO0lBRUEsSUFBSyxLQUFLLENBQUMsT0FBTyxDQUFFLElBQUksQ0FBQyxnQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFHO01BQ3BEO0lBQ0Q7SUFFQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxXQUFXO0lBQ2xDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7RUFDM0I7RUFFQSxTQUFTLGFBQWEsQ0FBRSxJQUFJLEVBQUc7SUFDOUIsSUFBSyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUUsbUJBQW9CLENBQUMsRUFBRztNQUNuRDtJQUNEO0lBRUEsSUFBSSxRQUFRLEdBQUcsRUFBRTtJQUVqQixRQUFRLElBQUksOEJBQThCO0lBQzFDLFFBQVEsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLGlCQUFpQjtJQUMvQyxRQUFRLElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLEtBQUs7SUFFOUMsZUFBZSxDQUFFLFFBQVMsQ0FBQztFQUM1QjtFQUVBLFNBQVMsU0FBUyxDQUFFLElBQUksRUFBRSxTQUFTLEVBQUc7SUFDckMsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQyxDQUFDLGFBQWE7SUFFeEUsSUFBSyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUUsZUFBZ0IsQ0FBQyxFQUFHO01BQy9DO0lBQ0Q7SUFFQSxJQUFJLFFBQVEsR0FBRyxFQUFFO0lBRWpCLFFBQVEsSUFBSSx5QkFBeUI7SUFDckMsUUFBUSxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYTtJQUM1QyxRQUFRLElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLEtBQUs7SUFDOUM7SUFDQTtJQUNBO0lBQ0EsSUFBSyxNQUFNLENBQUMscUJBQXFCLEVBQUc7TUFDbkMsUUFBUSxJQUFJLFVBQVUsR0FBRyxNQUFNLENBQUMscUJBQXFCO01BQ3JELE9BQU8sTUFBTSxDQUFDLHFCQUFxQjtJQUNwQztJQUVBLE1BQU0sT0FBTyxHQUFHLGVBQWUsQ0FBRSxRQUFTLENBQUM7SUFFM0MsT0FBTyxDQUFDLGtCQUFrQixHQUFHLE1BQU07TUFDbEMsSUFBSyxPQUFPLENBQUMsVUFBVSxLQUFLLGNBQWMsQ0FBQyxJQUFJLElBQUksR0FBRyxLQUFLLE9BQU8sQ0FBQyxNQUFNLEVBQUc7UUFDM0UsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO1FBQ2xELE1BQU0sQ0FBQyxXQUFXLENBQ2pCO1VBQ0MsU0FBUyxFQUFFLFdBQVcsQ0FBQyxPQUFPO1VBQzlCLE1BQU0sRUFBRSxXQUFXLENBQUMsSUFBSTtVQUN4QixXQUFXLEVBQUU7UUFDZCxDQUFDLEVBQ0QsU0FDRCxDQUFDO01BQ0Y7SUFDRCxDQUFDO0VBQ0Y7RUFFQSxTQUFTLGNBQWMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFO0lBQ3BDO0lBQ0E7SUFDQTtJQUNBLElBQUk7TUFDSCxNQUFNLFFBQVEsR0FBRyxJQUFJLEdBQUcsQ0FBRSxHQUFJLENBQUM7TUFDL0IsTUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUUsZUFBZ0IsQ0FBQztNQUVqRSxJQUFLLENBQUUsWUFBWSxFQUFHO1FBQ3JCLE9BQU8sR0FBRztNQUNYO01BRUEsTUFBTSxRQUFRLEdBQUcsSUFBSSxHQUFHLENBQUUsWUFBYSxDQUFDO01BQ3hDLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFFLGtCQUFrQixFQUFFLE1BQU8sQ0FBQztNQUN2RCxRQUFRLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBRSxlQUFlLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFFLENBQUM7TUFFakUsT0FBTyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDM0IsQ0FBQyxDQUFDLE9BQVEsQ0FBQyxFQUFHO01BQ2IsT0FBTyxHQUFHO0lBQ1g7RUFDRDtFQUVBLFNBQVMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRTtJQUN6QztJQUNBLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMseUJBQXlCLEVBQUUsRUFBRSxDQUFDO0lBQ3ZEO0lBQ0EsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRztJQUM1QyxNQUFNLElBQUksR0FBRyxHQUFHLGFBQWEsSUFBSSxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUN0RCxPQUFPLE1BQU07RUFDZDtFQUVBLFNBQVMsVUFBVSxDQUFFLElBQUksRUFBRSxTQUFTLEVBQUc7SUFDdEMsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQkFBb0IsQ0FBQyxDQUFDLGFBQWE7SUFFeEUsSUFBSyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUUsbUJBQW9CLENBQUMsRUFBRztNQUNuRDtJQUNEO0lBRUEsSUFBSSxRQUFRLEdBQUcsRUFBRTtJQUVqQixRQUFRLElBQUksMEJBQTBCO0lBQ3RDLFFBQVEsSUFBSSxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsS0FBSztJQUU5QyxNQUFNLE9BQU8sR0FBRyxlQUFlLENBQUUsUUFBUyxDQUFDO0lBRTNDLE9BQU8sQ0FBQyxrQkFBa0IsR0FBRyxNQUFNO01BQ2xDLElBQUssT0FBTyxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsSUFBSSxJQUFJLEdBQUcsS0FBSyxPQUFPLENBQUMsTUFBTSxFQUFHO1FBQzNFLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztRQUNsRCxNQUFNLENBQUMsV0FBVyxDQUNqQjtVQUNDLFNBQVMsRUFBRSxXQUFXLENBQUMsT0FBTztVQUM5QixNQUFNLEVBQUUsV0FBVyxDQUFDLElBQUk7VUFDeEIsV0FBVyxFQUFFO1FBQ2QsQ0FBQyxFQUNELFNBQ0QsQ0FBQztNQUNGO0lBQ0QsQ0FBQztFQUNGO0VBRUEsU0FBUyxlQUFlLENBQUUsUUFBUSxFQUFHO0lBQ3BDLE1BQU0sV0FBVyxHQUFHLElBQUksY0FBYyxDQUFDLENBQUM7SUFFeEMsV0FBVyxDQUFDLElBQUksQ0FBRSxNQUFNLEVBQUUsT0FBUSxDQUFDO0lBQ25DLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBRSxjQUFjLEVBQUUsbUNBQW9DLENBQUM7SUFDbkYsV0FBVyxDQUFDLElBQUksQ0FBRSxRQUFTLENBQUM7SUFFNUIsT0FBTyxXQUFXO0VBQ25CO0VBRUEsU0FBUyxpQkFBaUIsQ0FBRSxJQUFJLEVBQUc7SUFDbEMsSUFBSyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUUsZ0JBQWlCLENBQUMsRUFBRztNQUNoRDtJQUNEO0lBRUEsUUFBUSxDQUFDLGNBQWMsQ0FBRSxrQkFBbUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsR0FBSSxJQUFJLENBQUMsY0FBYyxJQUFLO0VBQzFGO0VBRUEsU0FBUyxZQUFZLENBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRztJQUN4QyxJQUFJLE1BQU0sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFFLG1CQUFvQixDQUFDLENBQUMsYUFBYTtJQUV4RSxJQUFLLENBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBRSxpQkFBa0IsQ0FBQyxFQUFHO01BQ2pELElBQUksSUFBSSxHQUFHO1FBQUMsT0FBTyxFQUFDLFdBQVc7UUFBRSxPQUFPLEVBQUM7TUFBb0IsQ0FBQztNQUM5RCxNQUFNLENBQUMsV0FBVyxDQUNqQjtRQUNDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE1BQU0sRUFBRSxJQUFJO1FBQ1osV0FBVyxFQUFFO01BQ2QsQ0FBQyxFQUNELFNBQ0QsQ0FBQztNQUNEO0lBQ0Q7SUFFQSxJQUFJLFFBQVEsR0FBRyxFQUFFO0lBRWpCLFFBQVEsSUFBSSw2QkFBNkI7SUFDekMsUUFBUSxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZUFBZTtJQUM1QyxRQUFRLElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLEtBQUs7SUFFOUMsTUFBTSxPQUFPLEdBQUcsZUFBZSxDQUFFLFFBQVMsQ0FBQztJQUUzQyxPQUFPLENBQUMsa0JBQWtCLEdBQUcsTUFBTTtNQUNsQyxJQUFLLE9BQU8sQ0FBQyxVQUFVLEtBQUssY0FBYyxDQUFDLElBQUksSUFBSSxHQUFHLEtBQUssT0FBTyxDQUFDLE1BQU0sRUFBRztRQUMzRSxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7UUFDbEQsTUFBTSxDQUFDLFdBQVcsQ0FDakI7VUFDQyxTQUFTLEVBQUUsV0FBVyxDQUFDLE9BQU87VUFDOUIsTUFBTSxFQUFFLFdBQVcsQ0FBQyxJQUFJO1VBQ3hCLFdBQVcsRUFBRTtRQUNkLENBQUMsRUFDRCxTQUNELENBQUM7TUFDRjtJQUNELENBQUM7RUFDRjtFQUVBLFNBQVMscUJBQXFCLENBQUUsSUFBSSxFQUFHO0lBQ3RDLElBQUssQ0FBRSxJQUFJLENBQUMsY0FBYyxDQUFFLDBCQUEyQixDQUFDLElBQUksQ0FBRSxJQUFJLENBQUMsY0FBYyxDQUFFLDBCQUEyQixDQUFDLEVBQUc7TUFDakg7SUFDRDtJQUVBLElBQUksUUFBUSxHQUFHLEVBQUU7SUFFakIsUUFBUSxJQUFJLHVDQUF1QztJQUNuRCxRQUFRLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyx3QkFBd0I7SUFDdkQsUUFBUSxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsd0JBQXdCO0lBQ3pELFFBQVEsSUFBSSxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsS0FBSztJQUU5QyxNQUFNLE9BQU8sR0FBRyxlQUFlLENBQUUsUUFBUyxDQUFDO0VBQzVDOztFQUVBO0FBQ0Q7QUFDQTtFQUNDLFNBQVMsMkJBQTJCLENBQUEsRUFBRztJQUN0QyxpQ0FBaUMsQ0FBRSx5Q0FBMEMsQ0FBQztFQUMvRTs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLGlDQUFpQyxDQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUc7SUFDbkUsSUFBSyxPQUFPLFFBQVEsS0FBSyxXQUFXLElBQUksQ0FBRSxRQUFRLENBQUMsS0FBSyxFQUFHO01BQzFEO0lBQ0Q7O0lBRUE7SUFDQSxJQUFLLE9BQU8sb0JBQW9CLEtBQUssV0FBVyxJQUFJLENBQUUsb0JBQW9CLENBQUMsYUFBYSxJQUFJLG9CQUFvQixDQUFDLGFBQWEsS0FBSyxHQUFHLEVBQUc7TUFDeEk7SUFDRDs7SUFFQTtJQUNBLElBQUssb0JBQW9CLENBQUMsT0FBTyxJQUFJLE9BQU8sUUFBUSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUc7TUFDOUUsUUFBUSxDQUFDLFFBQVEsQ0FBRSxvQkFBb0IsQ0FBQyxPQUFRLENBQUM7SUFDbEQ7SUFFQSxJQUFJLE9BQU8sR0FBRyxPQUFPLHdCQUF3QixLQUFLLFdBQVcsR0FBRyx3QkFBd0IsR0FBRyxDQUFDLENBQUM7SUFFN0YsSUFBSSxLQUFLLEdBQUc7TUFDWCxPQUFPLEVBQUUsb0JBQW9CLENBQUMsT0FBTztNQUNyQyxNQUFNLEVBQUUsb0JBQW9CLENBQUMsTUFBTTtNQUNuQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsS0FBSztNQUNqQyxXQUFXLEVBQUUsb0JBQW9CLENBQUMsR0FBRztNQUNyQyxJQUFJLEVBQUUsb0JBQW9CLENBQUMsSUFBSTtNQUMvQixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7TUFDMUIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO01BQzlCLG1CQUFtQixFQUFFO0lBQ3RCLENBQUM7O0lBRUQ7SUFDQSxJQUFLLFVBQVUsSUFBSSxPQUFPLFVBQVUsS0FBSyxRQUFRLEVBQUc7TUFDbkQsS0FBTSxJQUFJLEdBQUcsSUFBSSxVQUFVLEVBQUc7UUFDN0IsSUFBSyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUUsVUFBVSxFQUFFLEdBQUksQ0FBQyxFQUFHO1VBQzlELEtBQUssQ0FBRSxHQUFHLENBQUUsR0FBRyxVQUFVLENBQUUsR0FBRyxDQUFFO1FBQ2pDO01BQ0Q7SUFDRDtJQUVBLFFBQVEsQ0FBQyxLQUFLLENBQUUsU0FBUyxFQUFFLEtBQU0sQ0FBQztFQUNuQzs7RUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0VBQ0MsU0FBUyxnQ0FBZ0MsQ0FBRSxZQUFZLEdBQUcsS0FBSyxFQUFHO0lBQ2pFLElBQUssQ0FBRSxVQUFVLENBQUMsQ0FBQyxFQUFHO01BQ3JCO0lBQ0Q7SUFDQSxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUk7SUFDakMsTUFBTSxRQUFRLEdBQUssT0FBTyxvQkFBb0IsS0FBSyxXQUFXLElBQUksb0JBQW9CLENBQUMsSUFBSSxHQUFLLG9CQUFvQixDQUFDLElBQUksR0FBRyxFQUFFO0lBQzlILGlDQUFpQyxDQUFFLGdDQUFnQyxFQUFFO01BQ3BFLEtBQUssRUFBTSxZQUFZLEdBQUcsV0FBVyxHQUFHLFFBQVE7TUFDaEQsU0FBUyxFQUFFLElBQUk7TUFDZixJQUFJLEVBQU8sUUFBUSxHQUFHO0lBQ3ZCLENBQUUsQ0FBQztFQUNKOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLGtDQUFrQyxDQUFFLE9BQU8sRUFBRztJQUN0RCxpQ0FBaUMsQ0FBRSxrQ0FBa0MsRUFBRTtNQUN0RSxRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJO01BQzlCLE9BQU8sRUFBRTtJQUNWLENBQUUsQ0FBQztFQUNKOztFQUVBO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7RUFDQyxTQUFTLG1DQUFtQyxDQUFFLE9BQU8sR0FBRyxRQUFRLEVBQUc7SUFDbEUsaUNBQWlDLENBQUUsbUNBQW1DLEVBQUU7TUFDdkUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSTtNQUM5QixPQUFPLEVBQUU7SUFDVixDQUFFLENBQUM7RUFDSjs7RUFFQTtBQUNEO0FBQ0E7RUFDQyxTQUFTLDhCQUE4QixDQUFFLFdBQVcsR0FBRyxLQUFLLEVBQUc7SUFDOUQsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBRSxtQ0FBb0MsQ0FBQztJQUMvRSxNQUFNLFVBQVUsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLGdCQUFnQixDQUFFLFdBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDO0lBRW5GLGlDQUFpQyxDQUFFLDhCQUE4QixFQUFFO01BQ2xFLFdBQVcsRUFBRSxXQUFXLEdBQUcsUUFBUSxHQUFHLGtCQUFrQjtNQUN4RCxXQUFXLEVBQUU7SUFDZCxDQUFFLENBQUM7RUFDSjtBQUNELENBQUMsRUFBSSxRQUFRLEVBQUUsTUFBTyxDQUFDOzs7OztBQy9qQnZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUcsTUFBTSxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBVTtFQUFDLFlBQVk7O0VBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUMsQ0FBQyxnQkFBZ0IsRUFBQyxxQkFBcUIsRUFBQyxXQUFXLENBQUMsRUFBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO0lBQUMsSUFBSSxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGtCQUFrQixHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEtBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGlCQUFpQixHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEtBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGFBQWEsR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTtRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUk7UUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7TUFBQSxDQUFDO01BQUMsQ0FBQyxHQUFDLEtBQUs7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxVQUFVO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTztNQUFDLENBQUMsR0FBQyxFQUFFO01BQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLE9BQU8sQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLElBQUksQ0FBQyxDQUFELENBQUM7SUFBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEdBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBRSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUM7TUFBQyxPQUFPLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQztNQUFDLE9BQU8sQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDO1VBQUMsVUFBVSxFQUFDLENBQUM7VUFBQyxnQkFBZ0IsRUFBQyxDQUFDO1VBQUMsZUFBZSxFQUFDLENBQUM7VUFBQyxpQkFBaUIsRUFBQyxJQUFJLENBQUM7UUFBaUIsQ0FBQyxDQUFDO01BQUMsS0FBSSxRQUFRLElBQUUsT0FBTyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBRyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxDQUFDLGVBQWUsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLGVBQWUsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsYUFBYSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxDQUFDLEdBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLGVBQWUsS0FBRyxDQUFDLENBQUMsZUFBZSxHQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsS0FBSyxJQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDLElBQUksSUFBRSxDQUFDLENBQUMsaUJBQWlCLEtBQUcsQ0FBQyxDQUFDLGlCQUFpQixHQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVM7TUFBQyxLQUFJLElBQUksSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLElBQUUsQ0FBQyxZQUFZLENBQUMsSUFBRSxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDO01BQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQztNQUFDLElBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDLFlBQVksS0FBSyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsSUFBRSxRQUFRLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUM7WUFBQyxNQUFNLEVBQUM7VUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxVQUFVLElBQUUsT0FBTyxDQUFDLEtBQUcsVUFBVSxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxHQUFDLE9BQU8sS0FBRyxDQUFDLEtBQUcsQ0FBQyxDQUFDLFVBQVUsSUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUM7VUFBQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQTtRQUFDLElBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxFQUFDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBRyxVQUFVLElBQUUsT0FBTyxDQUFDLEVBQUMsTUFBSyxhQUFhLEdBQUMsQ0FBQyxHQUFDLHVFQUF1RTtRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7TUFBQTtNQUFDLElBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxLQUFLLEtBQUcsSUFBSSxDQUFDLFNBQVMsS0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxLQUFJLENBQUMsR0FBQyxJQUFJLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsR0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVM7TUFBQyxPQUFPLElBQUk7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUcsQ0FBQyxZQUFZLENBQUMsRUFBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsSUFBRyxDQUFDLFlBQVksS0FBSyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztRQUFDLEtBQUksSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLE9BQU8sSUFBSTtNQUFBO01BQUMsT0FBTSxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7TUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSztNQUFDLE9BQU8sQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsY0FBYyxHQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsY0FBYyxHQUFDLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsY0FBYyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsUUFBUSxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLElBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsaUJBQWlCLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7TUFBQyxJQUFHLENBQUMsWUFBWSxDQUFDLElBQUUsQ0FBQyxDQUFDLFFBQVEsS0FBRyxJQUFJLEVBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUcsQ0FBQyxLQUFHLENBQUMsWUFBWSxLQUFLLElBQUUsQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBVyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBRyxJQUFJLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxJQUFHLFFBQVEsSUFBRSxPQUFPLENBQUMsRUFBQyxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxJQUFJLElBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksSUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSTtRQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxFQUFDLE9BQU8sSUFBSSxJQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7TUFBQTtNQUFDLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsWUFBVTtNQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTSxHQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxjQUFjO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxPQUFPO01BQUMsSUFBRyxDQUFDLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLFlBQVksRUFBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLFNBQVMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsWUFBWSxJQUFFLElBQUksQ0FBQyxZQUFZLEtBQUcsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFlBQVksS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLE1BQU0sS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFlBQVksR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxZQUFZLEdBQUMsSUFBSSxDQUFDLFNBQVMsSUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksSUFBRSxJQUFJLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxJQUFJLENBQUMsU0FBUyxJQUFFLElBQUksQ0FBQyxZQUFZLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxZQUFZLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFlBQVksSUFBRSxDQUFDLENBQUMsTUFBSSxDQUFDLEdBQUMsbUJBQW1CLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLFlBQVksSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLE1BQU0sS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsWUFBWSxHQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsWUFBWSxHQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxZQUFZLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFVBQVUsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxZQUFZLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxNQUFNLElBQUUsQ0FBQyxJQUFFLENBQUMsRUFBQztRQUFDLElBQUcsSUFBSSxDQUFDLFFBQVEsS0FBRyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxDQUFDLEtBQUcsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLElBQUUsQ0FBQyxFQUFDLEtBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxNQUFNLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxDQUFDLFVBQVUsSUFBRSxJQUFJLENBQUMsS0FBSyxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQUksQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsY0FBYyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBSSxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxjQUFjLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsSUFBRSxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQztRQUFDLElBQUksQ0FBQyxTQUFTLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxVQUFVLElBQUUsQ0FBQyxLQUFHLElBQUksQ0FBQyxVQUFVLE1BQUksQ0FBQyxLQUFHLElBQUksQ0FBQyxLQUFLLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLE9BQU8sQ0FBQyxJQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxRQUFRLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGVBQWUsR0FBQyxZQUFVO01BQUMsS0FBSSxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBRTtRQUFDLElBQUcsQ0FBQyxDQUFDLE9BQU8sSUFBRSxDQUFDLFlBQVksQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFDLE9BQU0sQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO01BQUE7TUFBQyxPQUFNLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLFVBQVU7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLEVBQUUsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO01BQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRztRQUFDLENBQUMsR0FBQyxFQUFFO1FBQUMsQ0FBQyxHQUFDLENBQUM7TUFBQyxLQUFJLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFHLElBQUksSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxPQUFPLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsU0FBUyxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsS0FBSSxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxFQUFDLENBQUMsR0FBRTtRQUFDLElBQUcsQ0FBQyxLQUFHLElBQUksRUFBQyxPQUFNLENBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUTtNQUFBO01BQUMsT0FBTSxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDO01BQUMsS0FBSSxJQUFJLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE9BQU8sRUFBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLFVBQVUsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLFVBQVUsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7TUFBQyxJQUFHLENBQUMsRUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBRyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNO01BQUMsS0FBSSxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxPQUFPLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxHQUFDLFlBQVU7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztNQUFDLE9BQU8sSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxHQUFHLEVBQUMsS0FBSSxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztNQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxLQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksS0FBRyxJQUFJLENBQUMsTUFBTSxJQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFDO1FBQUMsSUFBRyxJQUFJLENBQUMsTUFBTSxFQUFDO1VBQUMsS0FBSSxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxDQUFDLEdBQUMsWUFBWSxFQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxhQUFhLElBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixLQUFHLElBQUksQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFVBQVUsR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLGNBQWMsR0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDO1VBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsY0FBYyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQztRQUFBO1FBQUMsT0FBTyxJQUFJLENBQUMsY0FBYztNQUFBO01BQUMsT0FBTyxDQUFDLEtBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxHQUFDLFlBQVU7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVM7TUFBQyxPQUFPLENBQUMsS0FBRyxDQUFDLENBQUMsbUJBQW1CO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsWUFBVTtNQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLENBQUMsVUFBVSxHQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLElBQUUsSUFBSSxDQUFDLFVBQVU7SUFBQSxDQUFDLEVBQUMsQ0FBQztFQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztBQUFBLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7O0FDWHhyVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxVQUFTLENBQUMsRUFBQztFQUFDLFlBQVk7O0VBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLGdCQUFnQixJQUFFLENBQUM7RUFBQyxJQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBQztJQUFDLElBQUksQ0FBQztNQUFDLENBQUM7TUFBQyxDQUFDO01BQUMsQ0FBQztNQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDO1FBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQztRQUFDLE9BQU8sQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQztNQUFDLENBQUMsR0FBQyxLQUFLO01BQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxLQUFLO01BQUMsQ0FBQyxHQUFDLFNBQUEsQ0FBQSxFQUFVLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxZQUFVO1FBQUMsSUFBSSxDQUFDLEdBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQUMsT0FBTyxVQUFTLENBQUMsRUFBQztVQUFDLE9BQU8sSUFBSSxJQUFFLENBQUMsS0FBRyxDQUFDLFlBQVksS0FBSyxJQUFFLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQztRQUFBLENBQUM7TUFBQSxDQUFDLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDO1FBQUMsSUFBSSxDQUFDLEdBQUMsRUFBRTtRQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUM7VUFBQyxLQUFJLElBQUksQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsRUFBRSxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxFQUFFLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztVQUFDLElBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEVBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxnQkFBZ0IsR0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLFVBQVUsSUFBRSxPQUFPLE1BQU0sSUFBRSxNQUFNLENBQUMsR0FBRyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsR0FBQyxDQUFDLENBQUMsZ0JBQWdCLEdBQUMsR0FBRyxHQUFDLEVBQUUsSUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBQyxFQUFFLEVBQUMsWUFBVTtZQUFDLE9BQU8sQ0FBQztVQUFBLENBQUMsQ0FBQyxHQUFDLFdBQVcsSUFBRSxPQUFPLE1BQU0sSUFBRSxNQUFNLENBQUMsT0FBTyxLQUFHLE1BQU0sQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQUEsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxJQUFFLFlBQVUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxFQUFFLEVBQUMsWUFBVTtVQUFDLE9BQU8sQ0FBQztRQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDO01BQUEsQ0FBQztJQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQztJQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLEVBQUU7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxLQUFJLElBQUksQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSwwQkFBMEIsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsQ0FBRCxDQUFDO01BQUEsQ0FBQztJQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsSUFBRyxJQUFJLENBQUMsS0FBSyxFQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7TUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTTtRQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsRUFBRSxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDO01BQUMsT0FBTyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsRUFBRSxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxRQUFRLEVBQUMsTUFBTSxFQUFDLE9BQU8sRUFBQyxPQUFPLEVBQUMsY0FBYyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxRQUFRLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxRQUFRLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxXQUFXLEdBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLFdBQVcsQ0FBQztJQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUztJQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyx3QkFBd0IsRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFlBQVksR0FBQyxDQUFDLElBQUUsSUFBSTtJQUFBLENBQUMsQ0FBQztJQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxnQkFBZ0IsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUM7TUFBQyxLQUFJLElBQUksSUFBRSxDQUFDLEtBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxFQUFDLENBQUM7UUFBQyxDQUFDLEVBQUMsQ0FBQztRQUFDLEVBQUUsRUFBQyxDQUFDO1FBQUMsRUFBRSxFQUFDO01BQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxLQUFHLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxtQkFBbUIsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7TUFBQyxJQUFHLENBQUMsRUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLElBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO01BQUMsSUFBRyxDQUFDLEVBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFlBQVksRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQztRQUFDLE1BQU0sRUFBQztNQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDO0lBQUEsQ0FBQztJQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxxQkFBcUI7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLG9CQUFvQjtNQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxJQUFFLFlBQVU7UUFBQyxPQUFPLElBQUksSUFBSSxDQUFELENBQUMsQ0FBRSxPQUFPLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsUUFBUSxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLHVCQUF1QixDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsc0JBQXNCLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLDZCQUE2QixDQUFDO0lBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLElBQUk7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxJQUFFLENBQUM7UUFBQyxDQUFDLEdBQUMsR0FBRztRQUFDLENBQUMsR0FBQyxFQUFFO1FBQUMsQ0FBQyxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUM7VUFBQyxJQUFJLENBQUM7WUFBQyxDQUFDO1lBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLEdBQUcsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7UUFBQSxDQUFDO01BQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsWUFBVTtRQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLFlBQVU7UUFBQyxJQUFJLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLEVBQUMsQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLFlBQVU7UUFBQyxJQUFJLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsRUFBRSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsVUFBUyxDQUFDLEVBQUM7VUFBQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFBLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxVQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBRSxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsSUFBRSxDQUFDO01BQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUssQ0FBQyxJQUFFLENBQUM7TUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxVQUFVLENBQUMsWUFBVTtRQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQSxDQUFDLEVBQUMsSUFBSSxDQUFDO0lBQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxHQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUQsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLE1BQU07SUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBRyxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsY0FBYyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsSUFBSSxDQUFDLE1BQU0sR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVSxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxlQUFlLEtBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQUMsSUFBSSxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsQ0FBQyxHQUFDLENBQUM7UUFBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBO0lBQUMsQ0FBQyxDQUFDO0lBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFELENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSSxDQUFDLEdBQUMsU0FBQSxDQUFBLEVBQVU7TUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDO0lBQUEsQ0FBQztJQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxJQUFFLENBQUMsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLFlBQVUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxZQUFVO01BQUMsT0FBTyxJQUFJO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsWUFBVTtNQUFDLElBQUksQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsVUFBVTtNQUFDLE9BQU0sQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLFlBQVU7TUFBQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLEtBQUksSUFBSSxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksR0FBQyxJQUFJLENBQUMsUUFBUSxFQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUTtNQUFDLE9BQU8sSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsaUJBQWlCLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLFFBQVEsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQztNQUFDLE9BQU8sQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsYUFBYSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBRyxJQUFJLEtBQUcsQ0FBQyxDQUFDLElBQUUsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSTtRQUFDLElBQUcsQ0FBQyxLQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBSSxJQUFFLENBQUMsR0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsUUFBUSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxPQUFPLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxVQUFVLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDO01BQUE7TUFBQyxPQUFPLElBQUk7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixJQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFDLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLElBQUksSUFBRSxJQUFJLENBQUMsTUFBTTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFFLElBQUksQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLGNBQWMsR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLElBQUUsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsU0FBUyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLEtBQUcsSUFBSSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEVBQUMsU0FBUyxDQUFDLE1BQU0sR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxjQUFjO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFFLElBQUksQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsS0FBSztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsU0FBUyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUMsT0FBTyxJQUFJLENBQUMsVUFBVTtNQUFDLElBQUcsSUFBSSxDQUFDLFNBQVMsRUFBQztRQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFDO1VBQUMsSUFBSSxDQUFDLE1BQU0sSUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7VUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsY0FBYztZQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUztVQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsS0FBSyxJQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsVUFBVSxFQUFDLENBQUMsQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsT0FBSyxDQUFDLENBQUMsU0FBUyxHQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxLQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTO1FBQUE7UUFBQyxJQUFJLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxJQUFJLENBQUMsU0FBUyxNQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBO01BQUMsT0FBTyxJQUFJO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBRSxDQUFDLEtBQUcsSUFBSSxDQUFDLFVBQVUsS0FBRyxJQUFJLENBQUMsVUFBVSxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsSUFBSSxJQUFFLElBQUksQ0FBQyxVQUFVO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxPQUFPLElBQUksQ0FBQyxVQUFVO01BQUMsSUFBRyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxJQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUM7UUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsVUFBVTtVQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLElBQUUsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDO01BQUE7TUFBQyxPQUFPLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBRSxDQUFDLElBQUUsSUFBSSxDQUFDLFNBQVMsS0FBRyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixHQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxJQUFFLElBQUksQ0FBQyxTQUFTO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxPQUFPLElBQUksQ0FBQyxPQUFPO01BQUMsSUFBRyxDQUFDLElBQUUsSUFBSSxDQUFDLE9BQU8sSUFBRSxJQUFJLENBQUMsU0FBUyxFQUFDO1FBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVO1FBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLGlCQUFpQixLQUFHLElBQUksQ0FBQyxVQUFVLElBQUUsQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsaUJBQWlCLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsVUFBVSxJQUFFLElBQUksQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQTtNQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsSUFBRSxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQUM7SUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGtCQUFrQixHQUFDLElBQUksQ0FBQyxpQkFBaUIsR0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLENBQUM7SUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQztNQUFDLElBQUcsQ0FBQyxDQUFDLFVBQVUsR0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBRSxJQUFJLEtBQUcsQ0FBQyxDQUFDLFNBQVMsS0FBRyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLGFBQWEsRUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7TUFBQyxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsS0FBRyxJQUFJLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLElBQUksRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLE1BQU0sS0FBRyxDQUFDLEtBQUcsSUFBSSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxLQUFLLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU07TUFBQyxLQUFJLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsWUFBWSxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sTUFBSSxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxjQUFjLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsSUFBRSxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLFlBQVU7TUFBQyxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVTtJQUFBLENBQUM7SUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsV0FBVyxFQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFDLElBQUksSUFBRSxDQUFDLEVBQUMsTUFBSyw2QkFBNkI7UUFBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO1FBQUMsSUFBRyxJQUFJLENBQUMsVUFBVSxHQUFDLENBQUMsR0FBQyxJQUFJLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxZQUFZLEtBQUssSUFBRSxDQUFDLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxRQUFRLElBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsS0FBSSxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsV0FBVyxHQUFDLEVBQUUsRUFBQyxJQUFJLENBQUMsU0FBUyxHQUFDLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLFdBQVcsR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxJQUFJLENBQUMsTUFBTSxJQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxLQUFHLENBQUMsQ0FBQyxNQUFJLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO1FBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUksQ0FBQyxJQUFFLFdBQVcsS0FBRyxDQUFDLElBQUUsR0FBRyxLQUFHLENBQUMsSUFBRSxHQUFHLEtBQUcsQ0FBQyxJQUFFLE9BQU8sS0FBRyxDQUFDLElBQUUsUUFBUSxLQUFHLENBQUMsSUFBRSxXQUFXLEtBQUcsQ0FBQyxJQUFFLFFBQVEsS0FBRyxDQUFDLElBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUM7TUFBQSxDQUFDO0lBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLGlCQUFpQixHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyx1QkFBdUIsR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsZ0JBQWdCLEdBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLElBQUUsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUM7SUFBQSxDQUFDO0lBQUMsSUFBSSxDQUFDLEdBQUMsRUFBRTtNQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQztRQUFDLE9BQU8sRUFBQyxDQUFDO1FBQUMsVUFBVSxFQUFDLENBQUM7UUFBQyxVQUFVLEVBQUM7TUFBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBQztRQUFDLElBQUksRUFBQyxDQUFDO1FBQUMsS0FBSyxFQUFDLENBQUM7UUFBQyxTQUFTLEVBQUMsQ0FBQztRQUFDLFVBQVUsRUFBQyxDQUFDO1FBQUMsZ0JBQWdCLEVBQUMsQ0FBQztRQUFDLGVBQWUsRUFBQyxDQUFDO1FBQUMsU0FBUyxFQUFDLENBQUM7UUFBQyxZQUFZLEVBQUMsQ0FBQztRQUFDLE9BQU8sRUFBQyxDQUFDO1FBQUMsUUFBUSxFQUFDLENBQUM7UUFBQyxjQUFjLEVBQUMsQ0FBQztRQUFDLGFBQWEsRUFBQyxDQUFDO1FBQUMsT0FBTyxFQUFDLENBQUM7UUFBQyxhQUFhLEVBQUMsQ0FBQztRQUFDLFlBQVksRUFBQyxDQUFDO1FBQUMsaUJBQWlCLEVBQUMsQ0FBQztRQUFDLHVCQUF1QixFQUFDLENBQUM7UUFBQyxzQkFBc0IsRUFBQyxDQUFDO1FBQUMsUUFBUSxFQUFDLENBQUM7UUFBQyxjQUFjLEVBQUMsQ0FBQztRQUFDLGFBQWEsRUFBQyxDQUFDO1FBQUMsVUFBVSxFQUFDLENBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQztRQUFDLGVBQWUsRUFBQyxDQUFDO1FBQUMsTUFBTSxFQUFDLENBQUM7UUFBQyxXQUFXLEVBQUMsQ0FBQztRQUFDLElBQUksRUFBQyxDQUFDO1FBQUMsTUFBTSxFQUFDLENBQUM7UUFBQyxRQUFRLEVBQUMsQ0FBQztRQUFDLE9BQU8sRUFBQyxDQUFDO1FBQUMsSUFBSSxFQUFDO01BQUMsQ0FBQztNQUFDLENBQUMsR0FBQztRQUFDLElBQUksRUFBQyxDQUFDO1FBQUMsR0FBRyxFQUFDLENBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQztRQUFDLFVBQVUsRUFBQyxDQUFDO1FBQUMsVUFBVSxFQUFDLENBQUM7UUFBQyxXQUFXLEVBQUMsQ0FBQztRQUFDLE1BQU0sRUFBQyxDQUFDO1FBQUMsT0FBTyxFQUFDO01BQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsbUJBQW1CLEdBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsYUFBYSxHQUFDLElBQUksQ0FBQyxDQUFELENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFBLEVBQVU7UUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtRQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQztNQUFBLENBQUM7SUFBQyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsRUFBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxZQUFVO01BQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQyxJQUFHLENBQUMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsVUFBVSxJQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLEdBQUcsQ0FBQyxFQUFDO1FBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFDO1VBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsTUFBTSxJQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFBO1FBQUMsSUFBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxPQUFPLEtBQUcsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUUsQ0FBQyxLQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQztVQUFDLE9BQUssQ0FBQyxJQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO1VBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUFBO01BQUM7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0lBQUMsSUFBSSxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVTtRQUFDLElBQUcsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQztVQUFDLE1BQU0sRUFBQyxDQUFDO1VBQUMsTUFBTSxFQUFDO1FBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxPQUFLLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUM7UUFBQyxJQUFHLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsRUFBQztVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDLElBQUcsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUcsQ0FBQyxLQUFHLENBQUMsRUFBQztVQUFNLE9BQU8sQ0FBQztRQUFBO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxFQUFFO1VBQUMsQ0FBQyxHQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxTQUFTO1FBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQUksQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFHLElBQUUsQ0FBQyxDQUFDLE9BQU8sS0FBRyxDQUFDLENBQUMsU0FBUyxLQUFHLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUcsS0FBSyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxLQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLFFBQVEsS0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTyxDQUFDO01BQUEsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRTtVQUFDLElBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBQyxPQUFNLENBQUMsR0FBRztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUztRQUFBO1FBQUMsT0FBTyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUM7TUFBQSxDQUFDO0lBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxZQUFVO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSTtRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCO1FBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxTQUFTO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZTtRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSTtNQUFDLElBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBQztRQUFDLElBQUksQ0FBQyxRQUFRLEtBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO1FBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFBQyxJQUFHLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGVBQWUsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxJQUFHLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDLEtBQUssSUFBRyxDQUFDLEtBQUcsQ0FBQyxFQUFDO01BQU0sQ0FBQyxNQUFLLElBQUcsQ0FBQyxDQUFDLFlBQVksSUFBRSxDQUFDLEtBQUcsQ0FBQyxFQUFDLElBQUcsSUFBSSxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLElBQUksQ0FBQyxLQUFJO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsU0FBUyxLQUFHLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBRyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLGFBQWEsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7VUFBQyxJQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsS0FBSyxFQUFDO1FBQU0sQ0FBQyxNQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBO01BQUMsSUFBRyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsR0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLFlBQVksS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUMsQ0FBQyxHQUFDLFVBQVUsSUFBRSxPQUFPLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsV0FBVyxHQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsS0FBSSxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsV0FBVyxFQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDO01BQUMsSUFBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsRUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLFFBQVEsSUFBRSxVQUFVLElBQUUsT0FBTyxJQUFJLENBQUMsTUFBTSxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUMsS0FBSSxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztNQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQyxJQUFHLElBQUksSUFBRSxDQUFDLEVBQUMsT0FBTSxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUUsQ0FBQyxDQUFDLEtBQUssSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBRyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUM7TUFBQyxLQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFDO1FBQUMsSUFBRyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsWUFBWSxLQUFLLElBQUUsQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRCxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxFQUFDO1VBQUMsS0FBSSxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsR0FBQztZQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsUUFBUTtZQUFDLENBQUMsRUFBQyxDQUFDO1lBQUMsQ0FBQyxFQUFDLFVBQVU7WUFBQyxDQUFDLEVBQUMsQ0FBQztZQUFDLENBQUMsRUFBQyxDQUFDO1lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztZQUFDLENBQUMsRUFBQyxDQUFDO1lBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQztZQUFDLEVBQUUsRUFBQyxDQUFDLENBQUM7VUFBUyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVE7VUFBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLGVBQWUsTUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLFNBQVMsTUFBSSxJQUFJLENBQUMsdUJBQXVCLEdBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQSxDQUFDLE1BQUssSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDO1VBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxRQUFRO1VBQUMsQ0FBQyxFQUFDLENBQUM7VUFBQyxDQUFDLEVBQUMsQ0FBQztVQUFDLENBQUMsRUFBQyxVQUFVLElBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxFQUFDLENBQUM7VUFBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDO1VBQUMsRUFBRSxFQUFDO1FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBRSxVQUFVLElBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUM7UUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUssS0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUM7TUFBQTtNQUFDLE9BQU8sQ0FBQyxJQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxRQUFRLEtBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUcsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFNBQVMsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsWUFBWTtNQUFDLElBQUcsQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxZQUFZLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxRQUFRLElBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsVUFBVSxLQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLG1CQUFtQixDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsWUFBWSxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFHLElBQUksR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFVBQVUsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLE1BQUksQ0FBQyxHQUFDLG1CQUFtQixFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsSUFBSSxDQUFDLFFBQVEsSUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFlBQVksR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFHLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsRUFBQztRQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxTQUFTO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVO1FBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxJQUFFLEVBQUUsTUFBSSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDO01BQUEsQ0FBQyxNQUFLLElBQUksQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztNQUFDLElBQUcsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLElBQUUsQ0FBQyxFQUFDO1FBQUMsSUFBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUM7VUFBQyxJQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsR0FBRyxFQUFDO1VBQU8sSUFBRyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxLQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFHLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxZQUFZLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsS0FBSyxDQUFDO1VBQUMsSUFBSSxDQUFDLEtBQUssSUFBRSxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFHLElBQUksQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUE7UUFBQyxLQUFJLElBQUksQ0FBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxPQUFPLElBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksQ0FBQyxLQUFLLEtBQUcsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLEtBQUcsSUFBSSxDQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsSUFBSSxDQUFDLFFBQVEsS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxLQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsS0FBSyxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7UUFBQyxJQUFJLENBQUMsU0FBUyxLQUFHLENBQUMsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsVUFBVSxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsR0FBRyxLQUFHLENBQUMsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsSUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUUsSUFBSSxDQUFDLFVBQVUsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxPQUFPLENBQUMsSUFBRSxJQUFJLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsUUFBUSxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxJQUFJLENBQUMsWUFBWSxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxZQUFZLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBRyxLQUFLLEtBQUcsQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLElBQUUsQ0FBQyxLQUFHLElBQUksSUFBRSxDQUFDLElBQUUsQ0FBQyxLQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBQyxPQUFPLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLElBQUUsSUFBSSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUM7TUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDO01BQUMsSUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSTtRQUFDLElBQUcsSUFBSSxDQUFDLFFBQVEsRUFBQztVQUFDLEtBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLElBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUM7WUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsaUJBQWlCLEdBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLEVBQUUsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsS0FBSztZQUFDO1VBQUs7UUFBQyxDQUFDLE1BQUk7VUFBQyxJQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsTUFBTSxFQUFDLE9BQU0sQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxXQUFXLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxpQkFBaUIsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLGlCQUFpQixJQUFFLENBQUMsQ0FBQyxHQUFDLEtBQUs7UUFBQTtRQUFDLElBQUcsQ0FBQyxFQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsS0FBSyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxLQUFHLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7VUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFJLENBQUMsQ0FBQyxFQUFFLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsTUFBTSxLQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLFFBQVEsS0FBRyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxLQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBRSxJQUFJLENBQUMsUUFBUSxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQTtNQUFDO01BQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsWUFBVTtNQUFDLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixJQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFDLElBQUksQ0FBQyxFQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxpQkFBaUIsR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLENBQUMsT0FBTyxHQUFDLElBQUksQ0FBQyx1QkFBdUIsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxXQUFXLEdBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLEVBQUMsSUFBSTtJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsR0FBRyxFQUFDO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsSUFBRyxDQUFDLEVBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztNQUFBO01BQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsdUJBQXVCLElBQUUsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBQyxXQUFXLEdBQUMsWUFBWSxFQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBRSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsZUFBZSxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsZUFBZSxFQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLEVBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxLQUFLLEVBQUMsQ0FBQztRQUFDLFVBQVUsRUFBQyxDQUFDO1FBQUMsZ0JBQWdCLEVBQUMsQ0FBQztRQUFDLGVBQWUsRUFBQyxDQUFDO1FBQUMsaUJBQWlCLEVBQUMsQ0FBQztRQUFDLHVCQUF1QixFQUFDLENBQUM7UUFBQyxzQkFBc0IsRUFBQyxDQUFDO1FBQUMsZUFBZSxFQUFDLENBQUMsQ0FBQztRQUFDLFNBQVMsRUFBQyxDQUFDO1FBQUMsU0FBUyxFQUFDO01BQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUcsSUFBSSxJQUFFLENBQUMsRUFBQyxPQUFNLEVBQUU7TUFBQyxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUM7TUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQyxJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxRQUFRLElBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7UUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsR0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxNQUFLLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7TUFBQyxPQUFPLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxDQUFDLENBQUMsa0JBQWtCLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLEtBQUksSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQztJQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsZUFBZSxHQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsSUFBSSxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxTQUFTO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLFFBQVEsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLElBQUksRUFBQyxDQUFDLENBQUMsU0FBUyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDO01BQUMsT0FBTyxJQUFJLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLElBQUUsR0FBRyxLQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsRUFBRSxDQUFDLEdBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLEdBQUMsQ0FBQyxHQUFDO1FBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxRQUFRO1FBQUMsQ0FBQyxFQUFDLENBQUM7UUFBQyxDQUFDLEVBQUMsQ0FBQztRQUFDLENBQUMsRUFBQyxDQUFDO1FBQUMsQ0FBQyxFQUFDLENBQUM7UUFBQyxDQUFDLEVBQUMsVUFBVSxJQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQztRQUFDLENBQUMsRUFBQztNQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxLQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxLQUFLLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLEtBQUksSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsQ0FBQyxHQUFDLElBQUksRUFBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLGVBQWU7UUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVE7TUFBQyxJQUFHLElBQUksSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFDLElBQUksQ0FBQyxlQUFlLEdBQUMsRUFBRSxDQUFDLEtBQUssS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxJQUFJLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFDLE9BQUssQ0FBQyxHQUFFLElBQUksSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLElBQUksSUFBRSxJQUFJLENBQUMsUUFBUSxLQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztNQUFDLE9BQU0sQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsS0FBSSxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsUUFBUSxFQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUUsSUFBSSxJQUFFLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGNBQWMsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRO01BQUMsSUFBRyxpQkFBaUIsS0FBRyxDQUFDLEVBQUM7UUFBQyxPQUFLLENBQUMsR0FBRTtVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsRUFBRSxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztVQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDO1FBQUE7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDO01BQUE7TUFBQyxPQUFLLENBQUMsR0FBRSxDQUFDLENBQUMsRUFBRSxJQUFFLFVBQVUsSUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO01BQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBRyxDQUFDLENBQUMsR0FBRyxLQUFHLENBQUMsQ0FBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRCxDQUFDLENBQUUsU0FBUyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsT0FBTSxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUcsRUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBQyxNQUFLLDRCQUE0QjtNQUFDLElBQUksQ0FBQztRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUTtRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGNBQWM7UUFBQyxDQUFDLEdBQUM7VUFBQyxJQUFJLEVBQUMsY0FBYztVQUFDLEdBQUcsRUFBQyxVQUFVO1VBQUMsSUFBSSxFQUFDLE9BQU87VUFBQyxLQUFLLEVBQUMsYUFBYTtVQUFDLE9BQU8sRUFBQztRQUFpQixDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsUUFBUSxFQUFDLFlBQVU7VUFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGVBQWUsR0FBQyxDQUFDLElBQUUsRUFBRTtRQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRztNQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxVQUFVLElBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUM7TUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxREFBcUQsR0FBQyxDQUFDLENBQUM7SUFBQTtJQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBRSxNQUFNLENBQUM7Ozs7O0FDWDE0dkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBRyxNQUFNLENBQUMsUUFBUSxHQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxZQUFVO0VBQUMsWUFBWTs7RUFBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBQyxDQUFDLGFBQWEsQ0FBQyxFQUFDLFVBQVMsQ0FBQyxFQUFDO0lBQUMsSUFBSSxDQUFDO01BQUMsQ0FBQztNQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsTUFBTSxDQUFDLGdCQUFnQixJQUFFLE1BQU07TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTO01BQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsRUFBRTtNQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsRUFBRSxHQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU07TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsRUFBQyxZQUFVLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQztRQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLEVBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxZQUFVLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEVBQUM7VUFBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQztVQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBRCxDQUFDO1VBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxDQUFEO1FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsQ0FBQyxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsSUFBSSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLElBQUksRUFBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsQ0FBQyxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEVBQUMsVUFBUyxDQUFDLEVBQUM7WUFBQyxJQUFJLENBQUMsR0FBRyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLEdBQUc7VUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLFVBQVMsQ0FBQyxFQUFDO1VBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsU0FBUyxFQUFDLFVBQVMsQ0FBQyxFQUFDO1FBQUMsT0FBTSxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxDQUFDO01BQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxVQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO01BQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBQyxVQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUMsRUFBRSxJQUFFLENBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFDLElBQUksSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsRUFBRSxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBRyxHQUFDLElBQUksQ0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDO01BQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQztJQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLEVBQUU7TUFBQyxPQUFPLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLG9CQUFvQixFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxHQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxFQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxHQUFHO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsa0JBQWtCLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQztNQUFDLEtBQUksSUFBSSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssSUFBRSxNQUFNLEVBQUMsQ0FBQyxHQUFDLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBRSxFQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxZQUFZLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxHQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQVEsR0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLE1BQU0sS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxLQUFLLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxJQUFJLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsRUFBRSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsRUFBRSxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUM7UUFBQyxDQUFDLEVBQUMsQ0FBQztRQUFDLENBQUMsRUFBQztNQUFDLENBQUM7TUFBQyxLQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUQsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSztNQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7UUFBQyxPQUFLLENBQUMsQ0FBQyxJQUFJLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJO01BQUEsQ0FBQyxNQUFLLE9BQUssQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUk7TUFBQyxPQUFPLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLElBQUksQ0FBQyxDQUFELENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsR0FBQyxJQUFJLEdBQUMsQ0FBQyxHQUFDLE1BQU0sR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLEdBQUMsQ0FBQyxHQUFDLE1BQU0sSUFBRSxDQUFDLElBQUUsR0FBRyxHQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsR0FBRyxHQUFDLElBQUksR0FBQyxDQUFDLEdBQUMsTUFBTSxJQUFFLENBQUMsSUFBRSxJQUFJLEdBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxHQUFDLEtBQUssR0FBQyxNQUFNLElBQUUsQ0FBQyxJQUFFLEtBQUssR0FBQyxJQUFJLENBQUMsR0FBQyxDQUFDLEdBQUMsT0FBTztJQUFBLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsR0FBQyxJQUFJLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsTUFBTSxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLE1BQU0sSUFBRSxDQUFDLElBQUUsR0FBRyxHQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxHQUFHLENBQUMsR0FBQyxHQUFHLEdBQUMsSUFBSSxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsTUFBTSxJQUFFLENBQUMsSUFBRSxJQUFJLEdBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxHQUFDLEtBQUssQ0FBQyxHQUFDLENBQUMsSUFBRSxNQUFNLElBQUUsQ0FBQyxJQUFFLEtBQUssR0FBQyxJQUFJLENBQUMsR0FBQyxDQUFDLEdBQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDO01BQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxHQUFDLENBQUMsR0FBQyxNQUFNLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxHQUFDLENBQUMsR0FBQyxNQUFNLElBQUUsQ0FBQyxJQUFFLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLEdBQUcsR0FBQyxJQUFJLEdBQUMsQ0FBQyxHQUFDLE1BQU0sSUFBRSxDQUFDLElBQUUsSUFBSSxHQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsR0FBQyxLQUFLLEdBQUMsTUFBTSxJQUFFLENBQUMsSUFBRSxLQUFLLEdBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxHQUFDLE9BQU8sRUFBQyxDQUFDLEdBQUMsRUFBRSxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLEVBQUU7SUFBQSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQztJQUFBLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFNLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLElBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLEVBQUUsSUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEVBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBRyxHQUFDLElBQUksQ0FBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBRSxDQUFDLENBQUM7UUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFDO01BQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLFlBQVksRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxPQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxFQUFFLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGNBQWMsRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUUsR0FBQyxJQUFJLENBQUMsR0FBRyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLEVBQUUsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxFQUFFLEdBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsU0FBUyxFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxVQUFTLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsRUFBRSxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUk7SUFBQSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxFQUFFLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxJQUFFLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUFBLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsU0FBUyxFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUM7SUFBQSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsV0FBVyxFQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsT0FBTSxDQUFDLEVBQUUsSUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsbUJBQW1CLEVBQUM7TUFBQyxJQUFJLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLFFBQVEsRUFBQyxPQUFPLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFdBQVcsRUFBQyxPQUFPLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLGFBQWEsRUFBQyxPQUFPLENBQUMsRUFBQyxDQUFDO0VBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUEsQ0FBQyxDQUFDLEVBQUMsTUFBTSxDQUFDLFNBQVMsSUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7QUNYdGxKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUcsTUFBTSxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBVTtFQUFDLFlBQVk7O0VBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBQyxDQUFDLHFCQUFxQixFQUFDLFdBQVcsQ0FBQyxFQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztJQUFDLElBQUksQ0FBQztNQUFDLENBQUM7TUFBQyxDQUFDO01BQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQUEsRUFBVTtRQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLEtBQUssQ0FBQyxFQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUTtNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLDJCQUEyQixHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsZUFBZSxHQUFDLGFBQWEsRUFBQyxDQUFDLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUM7TUFBQyxHQUFHLEVBQUMsQ0FBQztNQUFDLEtBQUssRUFBQyxDQUFDO01BQUMsTUFBTSxFQUFDLENBQUM7TUFBQyxJQUFJLEVBQUMsQ0FBQztNQUFDLEtBQUssRUFBQyxDQUFDO01BQUMsTUFBTSxFQUFDLENBQUM7TUFBQyxRQUFRLEVBQUMsQ0FBQztNQUFDLE9BQU8sRUFBQyxDQUFDO01BQUMsTUFBTSxFQUFDLENBQUM7TUFBQyxXQUFXLEVBQUMsQ0FBQztNQUFDLFVBQVUsRUFBQztJQUFFLENBQUM7SUFBQyxJQUFJLENBQUM7TUFBQyxDQUFDO01BQUMsQ0FBQztNQUFDLENBQUM7TUFBQyxDQUFDO01BQUMsQ0FBQztNQUFDLENBQUMsR0FBQywyQkFBMkI7TUFBQyxDQUFDLEdBQUMsc0RBQXNEO01BQUMsQ0FBQyxHQUFDLGtEQUFrRDtNQUFDLENBQUMsR0FBQyxZQUFZO01BQUMsQ0FBQyxHQUFDLHVCQUF1QjtNQUFDLENBQUMsR0FBQyxzQkFBc0I7TUFBQyxDQUFDLEdBQUMsa0JBQWtCO01BQUMsQ0FBQyxHQUFDLHlCQUF5QjtNQUFDLENBQUMsR0FBQyxZQUFZO01BQUMsQ0FBQyxHQUFDLFVBQVU7TUFBQyxDQUFDLEdBQUMsWUFBWTtNQUFDLENBQUMsR0FBQyx3Q0FBd0M7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsdUJBQXVCO01BQUMsQ0FBQyxHQUFDLGdDQUFnQztNQUFDLENBQUMsR0FBQyxxREFBcUQ7TUFBQyxDQUFDLEdBQUMsdUJBQXVCO01BQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxFQUFFLEdBQUMsR0FBRztNQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLEVBQUU7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLFFBQVE7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQztRQUFDLGFBQWEsRUFBQztNQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBUyxDQUFDLFNBQVM7TUFBQyxDQUFDLEdBQUMsWUFBVTtRQUFDLElBQUksQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUFDLE9BQU8sQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyx1Q0FBdUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQyxDQUFDLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBRyxFQUFFLENBQUMsR0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDO1FBQUMsTUFBTSxDQUFDLE9BQU8sSUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsRUFBRTtNQUFDLENBQUMsR0FBQyxFQUFFO01BQUMsQ0FBQyxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztRQUFDLElBQUcsS0FBSyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLE9BQU8sQ0FBQztRQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxRQUFRLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLEtBQUssQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUU7UUFBQyxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLElBQUk7TUFBQSxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsR0FBQyxZQUFVLENBQUMsQ0FBQztNQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztRQUFDLE9BQU8sQ0FBQyxJQUFFLFNBQVMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFlBQVksS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksSUFBRSxDQUFDLElBQUUsQ0FBQyxJQUFFLE1BQU0sS0FBRyxDQUFDLElBQUUsTUFBTSxLQUFHLENBQUMsSUFBRSxXQUFXLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGVBQWUsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFHLElBQUksS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDO1FBQUMsSUFBRyxNQUFNLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDLE9BQU8sQ0FBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUM7UUFBQyxJQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxHQUFHLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUk7VUFBQyxJQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUMsOEJBQThCLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxVQUFVLENBQUMsR0FBQyxpQkFBaUIsRUFBQyxHQUFHLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxpQkFBaUIsR0FBQyxnQkFBZ0IsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSTtZQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLElBQUUsQ0FBQyxDQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxLQUFHLENBQUMsRUFBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLEdBQUc7WUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sR0FBQyxRQUFRLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQztVQUFBO1VBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsYUFBYSxHQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsR0FBRyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsV0FBVyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFBO1FBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGVBQWUsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBRyxVQUFVLEtBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxVQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDO1FBQUMsSUFBSSxDQUFDLEdBQUMsTUFBTSxLQUFHLENBQUMsR0FBQyxNQUFNLEdBQUMsS0FBSztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQztVQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsT0FBSyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxPQUFLLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxZQUFZLElBQUUsQ0FBQyxDQUFDLEtBQUssRUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLEtBQUssQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxPQUFPLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsS0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxJQUFFLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBQyxDQUFDO01BQUEsQ0FBQztNQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztRQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxTQUFTLEtBQUcsQ0FBQyxJQUFFLFFBQVEsS0FBRyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLFFBQVEsSUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxNQUFNLEtBQUcsQ0FBQyxJQUFFLE1BQU0sS0FBRyxDQUFDLElBQUUsS0FBSyxLQUFHLENBQUMsR0FBQyxFQUFFLEtBQUcsQ0FBQyxJQUFFLE1BQU0sS0FBRyxDQUFDLElBQUUsTUFBTSxLQUFHLENBQUMsSUFBRSxRQUFRLElBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsRUFBRSxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBQyxJQUFHLENBQUMsRUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsV0FBVyxLQUFHLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTTtVQUFDLElBQUksRUFBQyxDQUFDO1VBQUMsUUFBUSxFQUFDO1FBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxDQUFDLEdBQUM7UUFBQyxLQUFLLEVBQUMsQ0FBQyxNQUFNLEVBQUMsT0FBTyxDQUFDO1FBQUMsTUFBTSxFQUFDLENBQUMsS0FBSyxFQUFDLFFBQVE7TUFBQyxDQUFDO01BQUMsQ0FBQyxHQUFDLENBQUMsWUFBWSxFQUFDLGFBQWEsRUFBQyxXQUFXLEVBQUMsY0FBYyxDQUFDO01BQUMsRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxHQUFDLFVBQVUsQ0FBQyxPQUFPLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNO1FBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxJQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsT0FBTyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQztRQUFDLE9BQU8sQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxDQUFDLElBQUksSUFBRSxDQUFDLElBQUUsRUFBRSxLQUFHLENBQUMsSUFBRSxNQUFNLEtBQUcsQ0FBQyxJQUFFLFdBQVcsS0FBRyxDQUFDLE1BQUksQ0FBQyxHQUFDLEtBQUssQ0FBQztRQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLE9BQU8sSUFBSSxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLFFBQVEsS0FBRyxDQUFDLEtBQUcsQ0FBQyxHQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsUUFBUSxLQUFHLENBQUMsSUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBSSxDQUFDLEdBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDO01BQUEsQ0FBQztNQUFDLEVBQUUsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU0sUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLEVBQUUsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU8sSUFBSSxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxJQUFFLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLEVBQUUsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUk7UUFBQyxPQUFPLElBQUksSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsR0FBRyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBRyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLFVBQVUsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsVUFBVSxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsRUFBRSxHQUFDO1FBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsQ0FBQztRQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDO1FBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7UUFBQyxNQUFNLEVBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUFDLElBQUksRUFBQyxDQUFDLENBQUMsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDO1FBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxHQUFHLENBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQztRQUFDLEtBQUssRUFBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDO1FBQUMsT0FBTyxFQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxHQUFHLENBQUM7UUFBQyxLQUFLLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLENBQUMsQ0FBQztRQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDO1FBQUMsTUFBTSxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsRUFBQyxDQUFDLENBQUM7UUFBQyxJQUFJLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQztRQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxDQUFDO1FBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLENBQUM7UUFBQyxHQUFHLEVBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUFDLElBQUksRUFBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsR0FBRyxDQUFDO1FBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUM7UUFBQyxXQUFXLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEdBQUcsRUFBQyxDQUFDO01BQUMsQ0FBQztNQUFDLEVBQUUsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxPQUFPLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLEVBQUU7TUFBQSxDQUFDO01BQUMsRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQztRQUFDLE9BQU8sQ0FBQyxJQUFFLEVBQUUsS0FBRyxDQUFDLEdBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBQyxHQUFHLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLElBQUUsR0FBRyxLQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxLQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxFQUFFLEVBQUMsR0FBRyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxJQUFFLEtBQUssS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxHQUFHLEVBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxHQUFDLEVBQUUsSUFBRSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxXQUFXLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLEtBQUs7TUFBQSxDQUFDO01BQUMsRUFBRSxHQUFDLHFEQUFxRDtJQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUUsRUFBQyxFQUFFLElBQUUsR0FBRyxHQUFDLENBQUMsR0FBQyxLQUFLO0lBQUMsRUFBRSxHQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUMsR0FBRyxFQUFDLElBQUksQ0FBQztJQUFDLElBQUksRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFHLElBQUksSUFBRSxDQUFDLEVBQUMsT0FBTyxVQUFTLENBQUMsRUFBQztVQUFDLE9BQU8sQ0FBQztRQUFBLENBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFDLEVBQUU7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUU7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUMsR0FBRyxHQUFDLEdBQUc7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU07VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsR0FBQyxFQUFFO1FBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxVQUFTLENBQUMsRUFBQztVQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQztVQUFDLElBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxJQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDO1lBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO1VBQUE7VUFBQyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLEVBQUMsT0FBSyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFDLFFBQVEsR0FBQyxFQUFFLENBQUM7UUFBQSxDQUFDLEdBQUMsVUFBUyxDQUFDLEVBQUM7VUFBQyxJQUFJLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQztVQUFDLElBQUcsUUFBUSxJQUFFLE9BQU8sQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxJQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDO1lBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO1VBQUE7VUFBQyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLEVBQUMsT0FBSyxDQUFDLEdBQUMsRUFBRSxDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDO1FBQUEsQ0FBQyxHQUFDLFVBQVMsQ0FBQyxFQUFDO1VBQUMsT0FBTyxDQUFDO1FBQUEsQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7VUFBQyxJQUFJLENBQUM7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUM7VUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDO1VBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztRQUFBLENBQUM7TUFBQSxDQUFDO01BQUMsRUFBRSxJQUFFLENBQUMsQ0FBQyxlQUFlLEdBQUMsVUFBUyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFBQyxLQUFJLElBQUksQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxFQUFDLENBQUMsR0FBQyxJQUFJLEVBQUMsQ0FBQyxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7UUFBQyxJQUFHLENBQUMsQ0FBQyxVQUFVLEtBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEVBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxDQUFDLEdBQUU7VUFBQyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUM7WUFBQyxJQUFHLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxFQUFDO2NBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQztjQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztZQUFBO1VBQUMsQ0FBQyxNQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztRQUFBO01BQUMsQ0FBQyxFQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBSyxHQUFDLElBQUksRUFBQyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsQ0FBQztNQUFDLEVBQUUsSUFBRSxDQUFDLENBQUMsYUFBYSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVTtVQUFDLENBQUMsR0FBQyxDQUFDO1FBQUMsS0FBSSxDQUFDLENBQUMsVUFBVSxHQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEtBQUssS0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUU7VUFBQyxJQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsSUFBSSxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO1FBQUE7UUFBQyxPQUFNO1VBQUMsS0FBSyxFQUFDLENBQUM7VUFBQyxHQUFHLEVBQUMsQ0FBQztVQUFDLFFBQVEsRUFBQyxDQUFDO1VBQUMsRUFBRSxFQUFDO1FBQUMsQ0FBQztNQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLFlBQVksRUFBRSxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxJQUFJLEdBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLEVBQUUsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxLQUFLLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLEtBQUssQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUM7TUFBQSxDQUFDLENBQUM7TUFBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLEVBQUUsRUFBQyxDQUFDLEdBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsRUFBRTtRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtVQUFDLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDO1FBQUMsS0FBSSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUcsQ0FBQyxLQUFHLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxHQUFDLEdBQUcsRUFBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQyxjQUFjLEdBQUMsYUFBYSxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBQyxPQUFPLEdBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUMsT0FBTyxDQUFDO1VBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxFQUFDLENBQUMsSUFBRSxJQUFJLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtVQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQUEsQ0FBQyxNQUFLLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsR0FBQyxDQUFDO1FBQUMsSUFBRyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUM7VUFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDO1VBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUM7UUFBQTtRQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLElBQUUsQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsQ0FBQztJQUFDLEtBQUksQ0FBQyxHQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxHQUFDLENBQUMsRUFBQyxFQUFFLEVBQUUsR0FBQyxDQUFDLEdBQUUsQ0FBQyxDQUFDLElBQUksR0FBQyxFQUFFLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxFQUFFLENBQUMsR0FBQyxFQUFFO0lBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEdBQUMsSUFBSTtRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQztNQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsRUFBRSxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBRyxDQUFDLENBQUMsTUFBTSxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLEdBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLElBQUksR0FBQztRQUFDLENBQUMsRUFBQyxDQUFDLEdBQUM7TUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLElBQUUsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQztJQUFDLElBQUksRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsWUFBWSxFQUFDLElBQUksQ0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDO01BQUEsQ0FBQztNQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsMkJBQTJCLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsS0FBRyxDQUFDLEdBQUM7VUFBQyxNQUFNLEVBQUM7UUFBQyxDQUFDLENBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxZQUFZO1FBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUM7UUFBQyxJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsUUFBUTtVQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUM7WUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztjQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixJQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Y0FBQyxPQUFPLENBQUMsSUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxHQUFDLHNCQUFzQixDQUFDLEVBQUMsQ0FBQyxDQUFDO1lBQUE7VUFBQyxDQUFDLENBQUM7UUFBQTtNQUFDLENBQUM7SUFBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLFNBQVMsRUFBQyxDQUFDLENBQUMsWUFBWSxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsT0FBTztNQUFDLElBQUcsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsS0FBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQUE7TUFBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLG1CQUFtQixHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxFQUFFLENBQUMsQ0FBQyxFQUFDO1FBQUMsTUFBTSxFQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztVQUFDLElBQUksQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7VUFBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDO1FBQUEsQ0FBQztRQUFDLFFBQVEsRUFBQztNQUFDLENBQUMsQ0FBQztJQUFBLENBQUM7SUFBQyxJQUFJLEVBQUUsR0FBQyxpRkFBaUYsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7TUFBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLFdBQVc7TUFBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO01BQUMsRUFBRSxHQUFDLElBQUksS0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDO01BQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsWUFBVTtRQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLFlBQVksR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUcsQ0FBQyxDQUFDLFlBQVksSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsWUFBWTtRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFlBQVksSUFBRSxJQUFJLEVBQUUsQ0FBRCxDQUFDLEdBQUMsSUFBSSxFQUFFLENBQUQsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU07VUFBQyxDQUFDLEdBQUMsSUFBSTtVQUFDLENBQUMsR0FBQyxHQUFHO1VBQUMsQ0FBQyxHQUFDLE1BQU07VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsRUFBRSxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLE9BQU8sSUFBRSxDQUFDLEdBQUMsQ0FBQztRQUFDLEtBQUksRUFBRSxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsWUFBWSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMseUJBQXlCLENBQUMsSUFBRSxFQUFFLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLEdBQUMsRUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDO1FBQUMsSUFBRyxFQUFFLEtBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBQztVQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1VBQUMsSUFBRyxDQUFDLENBQUMsT0FBTyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxJQUFJLElBQUUsQ0FBQyxDQUFDLFNBQVMsRUFBQztZQUFDLElBQUksQ0FBQztjQUFDLENBQUM7Y0FBQyxDQUFDO2NBQUMsQ0FBQztjQUFDLENBQUM7Y0FBQyxDQUFDO2NBQUMsQ0FBQztjQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztjQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7Y0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDO1lBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxFQUFFLElBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsRUFBRSxJQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEVBQUUsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztVQUFBO1FBQUMsQ0FBQyxNQUFLLElBQUcsRUFBRSxFQUFFLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBRSxLQUFLLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFFLE1BQU0sS0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO1VBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBRSxDQUFDO1lBQUMsRUFBRSxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztZQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQztZQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQztZQUFDLEVBQUUsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUM7VUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBQyxFQUFFLEdBQUMsRUFBRSxHQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBQyxFQUFFLEdBQUMsRUFBRSxHQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxFQUFFLElBQUUsRUFBRSxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsRUFBRSxJQUFFLEVBQUUsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLElBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxJQUFFLEdBQUcsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUcsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxHQUFHLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLElBQUUsR0FBRyxFQUFDLENBQUMsS0FBSyxDQUFDLEtBQUcsQ0FBQyxDQUFDLEtBQUssSUFBRSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsSUFBRSxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsSUFBRSxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsS0FBRyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDO1FBQUE7UUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUM7UUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLE9BQU8sQ0FBQyxLQUFHLENBQUMsQ0FBQyxZQUFZLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUk7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxHQUFHO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLElBQUUsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxJQUFFLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxJQUFFLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsSUFBRSxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSztVQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVk7UUFBQyxJQUFHLENBQUMsRUFBQztVQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLEVBQUU7VUFBQyxJQUFJLENBQUM7WUFBQyxDQUFDO1lBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVztZQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVk7WUFBQyxDQUFDLEdBQUMsVUFBVSxLQUFHLENBQUMsQ0FBQyxRQUFRO1lBQUMsQ0FBQyxHQUFDLCtDQUErQyxHQUFDLENBQUMsR0FBQyxRQUFRLEdBQUMsQ0FBQyxHQUFDLFFBQVEsR0FBQyxDQUFDLEdBQUMsUUFBUSxHQUFDLENBQUM7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7VUFBQyxJQUFHLElBQUksSUFBRSxDQUFDLENBQUMsRUFBRSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsR0FBRyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxFQUFFLElBQUUsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsRUFBRSxJQUFFLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxPQUFPLElBQUUsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sSUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxJQUFFLENBQUMsSUFBRSwrQkFBK0IsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsb0NBQW9DLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUUsR0FBRyxLQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLElBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQztZQUFDLElBQUksQ0FBQztjQUFDLENBQUM7Y0FBQyxDQUFDO2NBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztZQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsU0FBUyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEVBQUUsRUFBQyxFQUFFLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsRUFBRSxJQUFFLENBQUMsS0FBRyxFQUFFLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSTtVQUFBO1FBQUM7TUFBQyxDQUFDO01BQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxtQkFBbUIsR0FBQyxVQUFTLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUk7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTTtVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsV0FBVztRQUFDLElBQUcsRUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsTUFBTSxLQUFHLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUssQ0FBQztRQUFDLElBQUcsQ0FBQyxFQUFDO1VBQUMsSUFBSSxDQUFDLEdBQUMsSUFBSTtVQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLFNBQVMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDO1FBQUE7UUFBQyxJQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxRQUFRLEtBQUcsQ0FBQyxDQUFDLFFBQVEsS0FBRyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFJO1VBQUMsSUFBRyxFQUFFLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLGNBQWMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEtBQUssSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsU0FBUyxHQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxFQUFFLENBQUMsRUFBQyxLQUFLLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUM7UUFBQTtRQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBQyxDQUFDLEdBQUMsR0FBRyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBRSxHQUFDLEVBQUUsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLEdBQUMsRUFBRSxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUUsR0FBQyxFQUFFLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsV0FBVyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFDLEdBQUc7TUFBQSxDQUFDO01BQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxtQkFBbUIsR0FBQyxVQUFTLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUk7VUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7UUFBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxPQUFPLEtBQUcsQ0FBQyxDQUFDLElBQUUsTUFBTSxLQUFHLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLEdBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLEtBQUssQ0FBQyxLQUFHLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLEtBQUssSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLElBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLFNBQVMsR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxLQUFLLENBQUMsQ0FBQztNQUFBLENBQUM7SUFBQyxFQUFFLENBQUMsbVBBQW1QLEVBQUM7TUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsY0FBYyxDQUFDO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO1VBQUMsQ0FBQyxHQUFDLElBQUk7VUFBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLE1BQU07VUFBQyxDQUFDLEdBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUM7UUFBQyxJQUFHLFFBQVEsSUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUUsRUFBRSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBVSxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBRyxRQUFRLElBQUUsT0FBTyxDQUFDLEVBQUM7VUFBQyxJQUFHLENBQUMsR0FBQztZQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsSUFBSSxJQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLElBQUksSUFBRSxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxXQUFXLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsRUFBQyxDQUFDLENBQUMsV0FBVztVQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLG1CQUFtQixFQUFDLElBQUksSUFBRSxDQUFDLEVBQUMsSUFBRyxRQUFRLElBQUUsT0FBTyxDQUFDLEVBQUMsS0FBSSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUM7VUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLEVBQUUsQ0FBQyxVQUFVLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsZUFBZSxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsYUFBYSxHQUFDLFFBQVEsR0FBQyxXQUFXLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQyxDQUFDLENBQUMsUUFBUSxFQUFDLFVBQVUsRUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLEtBQUcsQ0FBQyxDQUFDLFNBQVMsR0FBQyxFQUFFLENBQUMsV0FBVyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLGdCQUFnQixJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsY0FBYyxHQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsU0FBUyxFQUFDLFdBQVcsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsU0FBUyxHQUFDLEVBQUUsQ0FBQyxXQUFXLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsZ0JBQWdCLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsV0FBVyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLElBQUksSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssTUFBSSxDQUFDLENBQUMsS0FBSyxJQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsQ0FBQztRQUFBO1FBQUMsS0FBSSxFQUFFLElBQUUsSUFBSSxJQUFFLENBQUMsQ0FBQyxPQUFPLEtBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsT0FBTyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsUUFBUSxJQUFFLENBQUMsQ0FBQyxlQUFlLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxPQUFPLElBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsQ0FBQyxTQUFTLElBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBQyxDQUFDLElBQUUsSUFBSSxJQUFFLENBQUMsQ0FBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsSUFBSSxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUksQ0FBQyxLQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBQyxDQUFDLENBQUMsSUFBRSxFQUFFLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxPQUFPLE1BQUksRUFBRSxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsRUFBRSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsU0FBUyxDQUFDLElBQUUsRUFBRSxFQUFDLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLGlCQUFpQixDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsRUFBRSxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLEtBQUssS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxLQUFHLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsSUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLEdBQUMsTUFBTSxFQUFDLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsU0FBUyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBRSxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxjQUFjLEdBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxJQUFJLENBQUMsY0FBYyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDO01BQUEsQ0FBQztNQUFDLE1BQU0sRUFBQyxDQUFDO0lBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLFdBQVcsRUFBQztNQUFDLFlBQVksRUFBQyxzQkFBc0I7TUFBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDO01BQUMsS0FBSyxFQUFDLENBQUMsQ0FBQztNQUFDLEtBQUssRUFBQyxDQUFDLENBQUM7TUFBQyxPQUFPLEVBQUM7SUFBTyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsY0FBYyxFQUFDO01BQUMsWUFBWSxFQUFDLEtBQUs7TUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxxQkFBcUIsRUFBQyxzQkFBc0IsRUFBQyx5QkFBeUIsRUFBQyx3QkFBd0IsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztRQUFDLEtBQUksQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUMsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBQyxDQUFDLEdBQUMsR0FBRyxLQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLEVBQUUsTUFBTSxJQUFFLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsRUFBRSxLQUFHLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUMsRUFBRSxLQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsWUFBWSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxXQUFXLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLEdBQUcsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxFQUFDLENBQUMsR0FBQyxHQUFHLElBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsSUFBRSxJQUFJLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFlBQVksRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQztRQUFDLE9BQU8sQ0FBQztNQUFBLENBQUM7TUFBQyxNQUFNLEVBQUMsQ0FBQyxDQUFDO01BQUMsU0FBUyxFQUFDLEVBQUUsQ0FBQyxpQkFBaUIsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsb0JBQW9CLEVBQUM7TUFBQyxZQUFZLEVBQUMsS0FBSztNQUFDLE1BQU0sRUFBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxxQkFBcUI7VUFBQyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsbUJBQW1CLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsbUJBQW1CLEtBQUcsS0FBSyxDQUFDO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBRyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxJQUFFLE1BQU0sS0FBRyxDQUFDLENBQUMsRUFBQztVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsTUFBSSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxZQUFZLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxHQUFDLElBQUksR0FBQyxHQUFHLElBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQztVQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUFBO1FBQUMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLFNBQVMsRUFBQztJQUFFLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBQztNQUFDLFlBQVksRUFBQyxLQUFLO01BQUMsU0FBUyxFQUFDO0lBQUUsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLGFBQWEsRUFBQztNQUFDLFlBQVksRUFBQyxLQUFLO01BQUMsTUFBTSxFQUFDLENBQUM7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsbUJBQW1CLEVBQUM7TUFBQyxZQUFZLEVBQUMsU0FBUztNQUFDLE1BQU0sRUFBQyxDQUFDO0lBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLGdCQUFnQixFQUFDO01BQUMsTUFBTSxFQUFDLENBQUM7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsb0JBQW9CLEVBQUM7TUFBQyxNQUFNLEVBQUMsQ0FBQztJQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUM7TUFBQyxNQUFNLEVBQUMsQ0FBQztJQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUM7TUFBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLCtDQUErQztJQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUM7TUFBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLG1EQUFtRDtJQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUM7TUFBQyxZQUFZLEVBQUMsdUJBQXVCO01BQUMsTUFBTSxFQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQUMsT0FBTyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsWUFBWSxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxHQUFHLEVBQUMsQ0FBQyxHQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsT0FBTyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsUUFBUSxHQUFDLEdBQUcsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUE7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsWUFBWSxFQUFDO01BQUMsWUFBWSxFQUFDLGtCQUFrQjtNQUFDLEtBQUssRUFBQyxDQUFDLENBQUM7TUFBQyxLQUFLLEVBQUMsQ0FBQztJQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyx1QkFBdUIsRUFBQztNQUFDLE1BQU0sRUFBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQztNQUFBO0lBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLFFBQVEsRUFBQztNQUFDLFlBQVksRUFBQyxnQkFBZ0I7TUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO1FBQUMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLGdCQUFnQixFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxnQkFBZ0IsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLEdBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsZ0JBQWdCLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQztNQUFDLEtBQUssRUFBQyxDQUFDLENBQUM7TUFBQyxTQUFTLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsR0FBRyxJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRSxPQUFPLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO01BQUE7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsYUFBYSxFQUFDO01BQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxtRUFBbUU7SUFBQyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsMkJBQTJCLEVBQUM7TUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztVQUFDLENBQUMsR0FBQyxVQUFVLElBQUcsQ0FBQyxHQUFDLFVBQVUsR0FBQyxZQUFZO1FBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztNQUFBO0lBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSSxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLFFBQVEsQ0FBQztRQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLENBQUM7TUFBQyxHQUFHLEtBQUcsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsUUFBUSxDQUFDLEtBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsR0FBRyxLQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxnQkFBZ0IsR0FBQyxDQUFDLEdBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEdBQUMsaUJBQWlCLEdBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQztJQUFDLEVBQUUsQ0FBQyx5QkFBeUIsRUFBQztNQUFDLFlBQVksRUFBQyxHQUFHO01BQUMsTUFBTSxFQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQyxHQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7VUFBQyxDQUFDLEdBQUMsV0FBVyxLQUFHLENBQUM7UUFBQyxPQUFNLFFBQVEsSUFBRSxPQUFPLENBQUMsSUFBRSxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxRQUFRLEtBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxZQUFZLEVBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsU0FBUyxFQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsU0FBUyxFQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsR0FBRyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsZ0JBQWdCLEdBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxnQkFBZ0IsSUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxZQUFZLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLFNBQVMsR0FBQyxRQUFRLEVBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxRQUFRLEdBQUMsU0FBUyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztNQUFBO0lBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSSxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUM7UUFBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLGNBQWMsSUFBRSxJQUFJLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUFBLENBQUM7TUFBQyxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQztRQUFDLElBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsSUFBSSxFQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsRUFBQztVQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztVQUFDLEtBQUksSUFBSSxDQUFDLEdBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztVQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUcsSUFBSSxLQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztRQUFBLENBQUMsTUFBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQUEsQ0FBQztJQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUM7TUFBQyxNQUFNLEVBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBRSxFQUFFO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTztRQUFDLElBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxZQUFZLEdBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsRUFBRSxHQUFDLENBQUMsRUFBRSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBQztVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxFQUFDLENBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7VUFBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUFBO1FBQUMsT0FBTyxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsS0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxLQUFLLENBQUMsRUFBQyxFQUFFLENBQUMsSUFBRSxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsS0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQTtJQUFDLENBQUMsQ0FBQztJQUFDLElBQUksRUFBRSxHQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUM7TUFBQyxJQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxLQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxJQUFFLGFBQWEsS0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQztRQUFDLElBQUksQ0FBQztVQUFDLENBQUM7VUFBQyxDQUFDO1VBQUMsQ0FBQztVQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7VUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLO1FBQUMsSUFBRyxLQUFLLEtBQUcsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsT0FBTyxHQUFDLEVBQUUsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFJLENBQUMsR0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLGlCQUFpQixLQUFHLENBQUMsR0FBQyxFQUFFLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLElBQUUsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztNQUFBO0lBQUMsQ0FBQztJQUFDLEtBQUksRUFBRSxDQUFDLFlBQVksRUFBQztNQUFDLE1BQU0sRUFBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU8sQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxFQUFFLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7TUFBQTtJQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQywwQ0FBMEMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUMsRUFBRSxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxFQUFFLEdBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxZQUFZLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFDLE9BQU0sQ0FBQyxDQUFDO01BQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUyxJQUFFLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxlQUFlO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7TUFBQyxJQUFHLENBQUMsSUFBRSxFQUFFLEtBQUcsQ0FBQyxDQUFDLE1BQU0sS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxNQUFNLEtBQUcsQ0FBQyxJQUFFLEVBQUUsS0FBRyxDQUFDLEtBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsUUFBUSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsUUFBUSxJQUFFLE9BQU8sQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxHQUFDLEdBQUcsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEVBQUMsSUFBSSxDQUFDLGNBQWMsRUFBQztRQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsY0FBYyxFQUFDLEVBQUUsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsS0FBRyxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLE1BQU0sS0FBRyxDQUFDLElBQUUsRUFBRSxLQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsMEJBQTBCLEVBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsS0FBRyxDQUFDLEdBQUMsU0FBUyxHQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztRQUFDLENBQUMsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsV0FBVyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLElBQUksRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLENBQUMsSUFBRSxFQUFFLEdBQUMsRUFBRSxHQUFDLEVBQUUsR0FBQyxFQUFFLEdBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsSUFBSSxDQUFDLFVBQVUsSUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztNQUFBO01BQUMsSUFBRyxDQUFDLEVBQUM7UUFBQyxPQUFLLENBQUMsR0FBRTtVQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBQyxDQUFDLENBQUMsRUFBRSxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsS0FBSztVQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDO1FBQUE7UUFBQyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUM7TUFBQTtNQUFDLE9BQU0sQ0FBQyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7TUFBQyxLQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFDLENBQUMsR0FBQyxRQUFRLElBQUUsT0FBTyxDQUFDLEVBQUMsT0FBTyxLQUFHLENBQUMsSUFBRSxNQUFNLEtBQUcsQ0FBQyxJQUFFLFFBQVEsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFDLENBQUMsR0FBQyxPQUFPLEdBQUMsTUFBTSxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsYUFBYSxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxHQUFDLEVBQUUsRUFBQyxDQUFDLEVBQUUsS0FBRyxDQUFDLElBQUUsTUFBTSxLQUFHLENBQUMsTUFBSSxPQUFPLEtBQUcsQ0FBQyxJQUFFLFFBQVEsS0FBRyxDQUFDLElBQUUsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLElBQUUsTUFBTSxLQUFHLENBQUMsSUFBRSxLQUFLLEtBQUcsQ0FBQyxJQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxLQUFHLENBQUMsR0FBQyxTQUFTLEtBQUcsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxHQUFHLEtBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxFQUFFLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLElBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLElBQUUsRUFBRSxHQUFDLEVBQUUsQ0FBQyxFQUFDLEVBQUUsS0FBRyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsSUFBSSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsRUFBRSxLQUFHLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsS0FBRyxDQUFDLElBQUUsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsR0FBQyxHQUFHLEVBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBRyxDQUFDLENBQUMsS0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFDLEdBQUcsQ0FBQyxJQUFFLElBQUksS0FBRyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBQyxJQUFJLEtBQUcsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFFLENBQUMsS0FBRyxDQUFDLEdBQUMsS0FBSyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxLQUFLLElBQUUsQ0FBQyxHQUFDLEVBQUUsSUFBRSxJQUFJLElBQUUsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxJQUFFLENBQUMsSUFBRSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsR0FBRyxHQUFDLE1BQU0sS0FBRyxDQUFDLElBQUUsU0FBUyxLQUFHLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLEdBQUMsZ0JBQWdCLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxHQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsQ0FBQyxLQUFHLElBQUksS0FBRyxDQUFDLElBQUUsUUFBUSxLQUFHLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFDO01BQUMsT0FBTyxDQUFDO0lBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsVUFBUyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsUUFBUTtRQUFDLENBQUMsR0FBQyxJQUFJO01BQUMsSUFBRyxDQUFDLEtBQUcsQ0FBQyxJQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFFLENBQUMsS0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7UUFBQyxJQUFHLENBQUMsSUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBRSxDQUFDLEtBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEtBQUcsQ0FBQyxJQUFJLEVBQUMsT0FBSyxDQUFDLEdBQUU7VUFBQyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJO1lBQUMsSUFBRyxDQUFDLEtBQUcsQ0FBQyxDQUFDLElBQUk7Y0FBQyxJQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsS0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFHLENBQUMsS0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBRyxDQUFDLEtBQUcsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFHLENBQUMsS0FBRyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSTtnQkFBQyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxHQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUksSUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQztjQUFBO1lBQUMsT0FBSSxDQUFDLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztVQUFDLE9BQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFHO1VBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLO1FBQUEsQ0FBQyxNQUFLLE9BQUssQ0FBQyxHQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7TUFBQyxPQUFLLE9BQUssQ0FBQyxHQUFFLENBQUMsS0FBRyxDQUFDLENBQUMsSUFBSSxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLEtBQUs7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLGlCQUFpQixHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLGNBQWMsR0FBQyxDQUFDLElBQUUsQ0FBQyxLQUFHLElBQUksQ0FBQyxjQUFjLEdBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQyxVQUFVLElBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQUEsQ0FBQztJQUFDLElBQUksRUFBRSxHQUFDLFNBQUEsQ0FBQSxFQUFVO01BQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDO0lBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEdBQUMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLFFBQVEsRUFBQyxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxHQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsSUFBSSxHQUFDLElBQUk7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBQyxVQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLE9BQU8sQ0FBQyxLQUFHLENBQUMsS0FBRyxDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsUUFBUSxLQUFHLENBQUMsS0FBRyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLENBQUMsSUFBRSxJQUFJLEtBQUcsSUFBSSxDQUFDLFFBQVEsS0FBRyxJQUFJLENBQUMsUUFBUSxHQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztJQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsS0FBSyxHQUFDLFVBQVMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsQ0FBQztNQUFDLElBQUcsQ0FBQyxDQUFDLFNBQVMsSUFBRSxDQUFDLENBQUMsS0FBSyxFQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQztRQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxTQUFTLEtBQUcsQ0FBQyxDQUFDLFVBQVUsR0FBQyxDQUFDLENBQUM7TUFBQTtNQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsS0FBRyxDQUFDLEdBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFHLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxRQUFRLEtBQUcsSUFBSSxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEtBQUssSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFDLElBQUksQ0FBQyxZQUFZLEdBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDO0lBQUMsSUFBSSxFQUFFLEdBQUMsU0FBQSxDQUFTLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO01BQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDO01BQUMsSUFBRyxDQUFDLENBQUMsS0FBSyxFQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFJLENBQUMsR0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEVBQUUsQ0FBQyxHQUFDLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLEtBQUssS0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxJQUFFLEVBQUUsS0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQSxDQUFDO0lBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFDLFVBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7TUFBQyxJQUFJLENBQUM7UUFBQyxDQUFDO1FBQUMsQ0FBQztRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDO1FBQUMsQ0FBQyxHQUFDLEVBQUU7UUFBQyxDQUFDLEdBQUMsRUFBRTtRQUFDLENBQUMsR0FBQyxFQUFFO1FBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsYUFBYTtNQUFDLEtBQUksQ0FBQyxHQUFDLENBQUMsQ0FBQyxRQUFRLElBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEdBQUMsQ0FBQyxDQUFDLEdBQUUsSUFBRyxDQUFDLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQztRQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsSUFBSTtRQUNseCtCLEtBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO01BQUE7TUFBQyxPQUFPLENBQUM7SUFBQSxDQUFDLEVBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztFQUFBLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztBQUFBLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7O0FDWmhJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUcsTUFBTSxDQUFDLFFBQVEsR0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBVTtFQUFDLFlBQVk7O0VBQUMsSUFBSSxDQUFDLEdBQUMsUUFBUSxDQUFDLGVBQWU7SUFBQyxDQUFDLEdBQUMsTUFBTTtJQUFDLENBQUMsR0FBQyxTQUFBLENBQVMsQ0FBQyxFQUFDLENBQUMsRUFBQztNQUFDLElBQUksQ0FBQyxHQUFDLEdBQUcsS0FBRyxDQUFDLEdBQUMsT0FBTyxHQUFDLFFBQVE7UUFBQyxDQUFDLEdBQUMsUUFBUSxHQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsUUFBUSxHQUFDLENBQUM7UUFBQyxDQUFDLEdBQUMsUUFBUSxDQUFDLElBQUk7TUFBQyxPQUFPLENBQUMsS0FBRyxDQUFDLElBQUUsQ0FBQyxLQUFHLENBQUMsSUFBRSxDQUFDLEtBQUcsQ0FBQyxHQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxDQUFDLENBQUM7SUFBQSxDQUFDO0lBQUMsQ0FBQyxHQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO01BQUMsUUFBUSxFQUFDLFVBQVU7TUFBQyxHQUFHLEVBQUMsQ0FBQztNQUFDLE9BQU8sRUFBQyxPQUFPO01BQUMsSUFBSSxFQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztRQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLEtBQUcsQ0FBQyxFQUFDLElBQUksQ0FBQyxPQUFPLEdBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUFDLFFBQVEsSUFBRSxPQUFPLENBQUMsS0FBRyxDQUFDLEdBQUM7VUFBQyxDQUFDLEVBQUM7UUFBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsWUFBWSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUUsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLENBQUMsRUFBQyxLQUFLLEtBQUcsQ0FBQyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsWUFBWSxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUUsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7TUFBQSxDQUFDO01BQUMsR0FBRyxFQUFDLFNBQUEsQ0FBUyxDQUFDLEVBQUM7UUFBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztRQUFDLElBQUksQ0FBQyxHQUFDLElBQUksQ0FBQyxJQUFJLElBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLO1VBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxJQUFJLElBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLO1VBQUMsQ0FBQyxHQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSztVQUFDLENBQUMsR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLEtBQUs7UUFBQyxJQUFJLENBQUMsU0FBUyxLQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBRyxDQUFDLEdBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxHQUFDLENBQUMsQ0FBQyxJQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFDLEdBQUcsQ0FBQyxHQUFDLENBQUMsS0FBRyxJQUFJLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFHLENBQUMsR0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLEdBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUMsR0FBRyxDQUFDLEdBQUMsQ0FBQyxLQUFHLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsS0FBSyxJQUFFLElBQUksQ0FBQyxLQUFLLElBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLElBQUksR0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxLQUFLLEtBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEtBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsSUFBSSxDQUFDLENBQUM7TUFBQTtJQUFDLENBQUMsQ0FBQztJQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsU0FBUztFQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsWUFBVTtJQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksR0FBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLENBQUMsV0FBVyxHQUFDLElBQUksSUFBRSxDQUFDLENBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVO0VBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsWUFBVTtJQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksR0FBQyxJQUFJLElBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBQyxDQUFDLENBQUMsV0FBVyxHQUFDLElBQUksSUFBRSxDQUFDLENBQUMsU0FBUyxHQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTO0VBQUEsQ0FBQyxFQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUMsVUFBUyxDQUFDLEVBQUM7SUFBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUcsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDO0VBQUEsQ0FBQztBQUFBLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCJkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmN1c3RvbS1zZWxlY3RcIikuZm9yRWFjaChjdXN0b21TZWxlY3QgPT4ge1xuXHRjb25zdCBzZWxlY3RCdG4gPSBjdXN0b21TZWxlY3QucXVlcnlTZWxlY3RvcihcIi5zZWxlY3QtYnV0dG9uXCIpO1xuXHRjb25zdCBzZWxlY3RlZFZhbHVlID0gY3VzdG9tU2VsZWN0LnF1ZXJ5U2VsZWN0b3IoXCIuc2VsZWN0ZWQtdmFsdWVcIik7XG5cdGNvbnN0IGhhbmRsZXIgPSBmdW5jdGlvbihlbG0pIHtcblx0XHRjb25zdCBjdXN0b21DaGFuZ2VFdmVudCA9IG5ldyBDdXN0b21FdmVudCgnY3VzdG9tLXNlbGVjdC1jaGFuZ2UnLCB7XG5cdFx0XHRkZXRhaWw6IHtcblx0XHRcdFx0c2VsZWN0ZWRPcHRpb246IGVsbVxuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHNlbGVjdGVkVmFsdWUudGV4dENvbnRlbnQgPSBlbG0udGV4dENvbnRlbnQ7XG5cdFx0Y3VzdG9tU2VsZWN0LmNsYXNzTGlzdC5yZW1vdmUoXCJhY3RpdmVcIik7XG5cdFx0Y3VzdG9tU2VsZWN0LmRpc3BhdGNoRXZlbnQoY3VzdG9tQ2hhbmdlRXZlbnQpO1xuXG5cdH1cblx0c2VsZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG5cdFx0Y3VzdG9tU2VsZWN0LmNsYXNzTGlzdC50b2dnbGUoXCJhY3RpdmVcIik7XG5cdFx0c2VsZWN0QnRuLnNldEF0dHJpYnV0ZShcblx0XHRcdFwiYXJpYS1leHBhbmRlZFwiLFxuXHRcdFx0c2VsZWN0QnRuLmdldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIikgPT09IFwidHJ1ZVwiID8gXCJmYWxzZVwiIDogXCJ0cnVlXCJcblx0XHQpO1xuXHR9KTtcblxuXHRjdXN0b21TZWxlY3QuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBmdW5jdGlvbihlKSB7XG5cdFx0aWYgKGUudGFyZ2V0Lm1hdGNoZXMoJ2xhYmVsJykpIHtcblxuXHRcdFx0Y29uc3QgYWxsSXRlbXMgPSBjdXN0b21TZWxlY3QucXVlcnlTZWxlY3RvckFsbCgnbGknKTtcblx0XHRcdGFsbEl0ZW1zLmZvckVhY2goaXRlbSA9PiBpdGVtLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpKTtcblx0XHRcdGNvbnN0IGNsaWNrZWRQbGFuID0gZS50YXJnZXQuY2xvc2VzdCgnbGknKTtcblxuXHRcdFx0aWYgKGNsaWNrZWRQbGFuKSB7XG5cdFx0XHRcdGNsaWNrZWRQbGFuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuXHRcdFx0XHRoYW5kbGVyKGNsaWNrZWRQbGFuKTtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcblx0XHRpZiAoIWN1c3RvbVNlbGVjdC5jb250YWlucyhlLnRhcmdldCkpIHtcblx0XHRcdGN1c3RvbVNlbGVjdC5jbGFzc0xpc3QucmVtb3ZlKFwiYWN0aXZlXCIpO1xuXHRcdFx0c2VsZWN0QnRuLnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIiwgXCJmYWxzZVwiKTtcblx0XHR9XG5cdH0pO1xufSk7IiwidmFyICQgPSBqUXVlcnk7XG4kKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpe1xuICAgIC8qKlxuICAgICAqIFJlZnJlc2ggTGljZW5zZSBkYXRhXG4gICAgICovXG4gICAgdmFyIF9pc1JlZnJlc2hpbmcgPSBmYWxzZTtcbiAgICAkKCcjd3ByLWFjdGlvbi1yZWZyZXNoX2FjY291bnQnKS5vbignY2xpY2snLCBmdW5jdGlvbihlKSB7XG4gICAgICAgIGlmKCFfaXNSZWZyZXNoaW5nKXtcbiAgICAgICAgICAgIHZhciBidXR0b24gPSAkKHRoaXMpO1xuICAgICAgICAgICAgdmFyIGFjY291bnQgPSAkKCcjd3ByLWFjY291bnQtZGF0YScpO1xuICAgICAgICAgICAgdmFyIGV4cGlyZSA9ICQoJyN3cHItZXhwaXJhdGlvbi1kYXRhJyk7XG5cbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIF9pc1JlZnJlc2hpbmcgPSB0cnVlO1xuICAgICAgICAgICAgYnV0dG9uLnRyaWdnZXIoICdibHVyJyApO1xuXG5cdFx0XHQvLyBTdGFydCBwb2xsaW5nIGlmIG5vdCBhbHJlYWR5IHJ1bm5pbmcuYWRkQ2xhc3MoJ3dwci1pc0xvYWRpbmcnKTtcbiAgICAgICAgICAgIGV4cGlyZS5yZW1vdmVDbGFzcygnd3ByLWlzVmFsaWQgd3ByLWlzSW52YWxpZCcpO1xuXG4gICAgICAgICAgICAkLnBvc3QoXG4gICAgICAgICAgICAgICAgYWpheHVybCxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbjogJ3JvY2tldF9yZWZyZXNoX2N1c3RvbWVyX2RhdGEnLFxuICAgICAgICAgICAgICAgICAgICBfYWpheF9ub25jZTogcm9ja2V0X2FqYXhfZGF0YS5ub25jZSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbi5yZW1vdmVDbGFzcygnd3ByLWlzTG9hZGluZycpO1xuICAgICAgICAgICAgICAgICAgICBidXR0b24uYWRkQ2xhc3MoJ3dwci1pc0hpZGRlbicpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmICggdHJ1ZSA9PT0gcmVzcG9uc2Uuc3VjY2VzcyApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY291bnQuaHRtbChyZXNwb25zZS5kYXRhLmxpY2Vuc2VfdHlwZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBleHBpcmUuYWRkQ2xhc3MocmVzcG9uc2UuZGF0YS5saWNlbnNlX2NsYXNzKS5odG1sKHJlc3BvbnNlLmRhdGEubGljZW5zZV9leHBpcmF0aW9uKTtcblx0XHRcdFx0XHRcdGlmICggcmVzcG9uc2UuZGF0YS5saWNlbnNlX2V4cGlyYXRpb25fbGFiZWwgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dwci1leHBpcmF0aW9uLWxhYmVsJykudGV4dENvbnRlbnQgPSByZXNwb25zZS5kYXRhLmxpY2Vuc2VfZXhwaXJhdGlvbl9sYWJlbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uLnJlbW92ZUNsYXNzKCd3cHItaWNvbi1yZWZyZXNoIHdwci1pc0hpZGRlbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbi5hZGRDbGFzcygnd3ByLWljb24tY2hlY2snKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIDI1MCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uLnJlbW92ZUNsYXNzKCd3cHItaWNvbi1yZWZyZXNoIHdwci1pc0hpZGRlbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvbi5hZGRDbGFzcygnd3ByLWljb24tY2xvc2UnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIDI1MCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZUTCA9IG5ldyBUaW1lbGluZUxpdGUoe29uQ29tcGxldGU6ZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfaXNSZWZyZXNoaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnNldChidXR0b24sIHtjc3M6e2NsYXNzTmFtZTonKz13cHItaXNIaWRkZW4nfX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zZXQoYnV0dG9uLCB7Y3NzOntjbGFzc05hbWU6Jy09d3ByLWljb24tY2hlY2snfX0sIDAuMjUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zZXQoYnV0dG9uLCB7Y3NzOntjbGFzc05hbWU6Jy09d3ByLWljb24tY2xvc2UnfX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zZXQoYnV0dG9uLCB7Y3NzOntjbGFzc05hbWU6Jys9d3ByLWljb24tcmVmcmVzaCd9fSwgMC4yNSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnNldChidXR0b24sIHtjc3M6e2NsYXNzTmFtZTonLT13cHItaXNIaWRkZW4nfX0pXG4gICAgICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgIH0sIDIwMDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuXG4gICAgLyoqXG4gICAgICogU2F2ZSBUb2dnbGUgb3B0aW9uIHZhbHVlcyBvbiBjaGFuZ2VcbiAgICAgKi9cbiAgICAkKCcud3ByLXJhZGlvIGlucHV0W3R5cGU9Y2hlY2tib3hdJykub24oJ2NoYW5nZScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB2YXIgbmFtZSAgPSAkKHRoaXMpLmF0dHIoJ2lkJyk7XG4gICAgICAgIHZhciB2YWx1ZSA9ICQodGhpcykucHJvcCgnY2hlY2tlZCcpID8gMSA6IDA7XG5cblx0XHR2YXIgZXhjbHVkZWQgPSBbXG5cdFx0XHQnY2xvdWRmbGFyZV9hdXRvX3NldHRpbmdzJyxcblx0XHRcdCdjbG91ZGZsYXJlX2Rldm1vZGUnLFxuXHRcdFx0J2FuYWx5dGljc19lbmFibGVkJyxcblx0XHRcdCd3cHItcm9ja2V0Y2RuLWZyZWUtdG9nZ2xlJyxcblx0XHRcdCd3cHItYnlvY2RuLXRvZ2dsZScsXG5cdFx0XHQnd3ByLXJvY2tldGNkbi1wYWlkLXRvZ2dsZSdcblx0XHRdO1xuXHRcdGlmICggZXhjbHVkZWQuaW5kZXhPZiggbmFtZSApID49IDAgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG4gICAgICAgICQucG9zdChcbiAgICAgICAgICAgIGFqYXh1cmwsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAncm9ja2V0X3RvZ2dsZV9vcHRpb24nLFxuICAgICAgICAgICAgICAgIF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlLFxuICAgICAgICAgICAgICAgIG9wdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdmFsdWVcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZnVuY3Rpb24ocmVzcG9uc2UpIHt9XG4gICAgICAgICk7XG5cdH0pO1xuXG5cdC8qKlxuICAgICAqIFNhdmUgZW5hYmxlIENQQ1NTIGZvciBtb2JpbGVzIG9wdGlvbi5cbiAgICAgKi9cbiAgICAkKCcjd3ByLWFjdGlvbi1yb2NrZXRfZW5hYmxlX21vYmlsZV9jcGNzcycpLm9uKCdjbGljaycsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG5cdFx0JCgnI3dwci1hY3Rpb24tcm9ja2V0X2VuYWJsZV9tb2JpbGVfY3Bjc3MnKS5hZGRDbGFzcygnd3ByLWlzTG9hZGluZycpO1xuXG4gICAgICAgICQucG9zdChcbiAgICAgICAgICAgIGFqYXh1cmwsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAncm9ja2V0X2VuYWJsZV9tb2JpbGVfY3Bjc3MnLFxuICAgICAgICAgICAgICAgIF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlXG4gICAgICAgICAgICB9LFxuXHRcdFx0ZnVuY3Rpb24ocmVzcG9uc2UpIHtcblx0XHRcdFx0aWYgKCByZXNwb25zZS5zdWNjZXNzICkge1xuXHRcdFx0XHRcdC8vIEhpZGUgTW9iaWxlIENQQ1NTIGJ0biBvbiBzdWNjZXNzLlxuXHRcdFx0XHRcdCQoJyN3cHItYWN0aW9uLXJvY2tldF9lbmFibGVfbW9iaWxlX2NwY3NzJykuaGlkZSgpO1xuXHRcdFx0XHRcdCQoJy53cHItaGlkZS1vbi1jbGljaycpLmhpZGUoKTtcblx0XHRcdFx0XHQkKCcud3ByLXNob3ctb24tY2xpY2snKS5zaG93KCk7XG5cdFx0XHRcdFx0JCgnI3dwci1hY3Rpb24tcm9ja2V0X2VuYWJsZV9tb2JpbGVfY3Bjc3MnKS5yZW1vdmVDbGFzcygnd3ByLWlzTG9hZGluZycpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG4gICAgICAgICk7XG4gICAgfSk7XG5cbiAgICAvKipcbiAgICAgKiBTYXZlIGVuYWJsZSBHb29nbGUgRm9udHMgT3B0aW1pemF0aW9uIG9wdGlvbi5cbiAgICAgKi9cbiAgICAkKCcjd3ByLWFjdGlvbi1yb2NrZXRfZW5hYmxlX2dvb2dsZV9mb250cycpLm9uKCdjbGljaycsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG5cdFx0JCgnI3dwci1hY3Rpb24tcm9ja2V0X2VuYWJsZV9nb29nbGVfZm9udHMnKS5hZGRDbGFzcygnd3ByLWlzTG9hZGluZycpO1xuXG4gICAgICAgICQucG9zdChcbiAgICAgICAgICAgIGFqYXh1cmwsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAncm9ja2V0X2VuYWJsZV9nb29nbGVfZm9udHMnLFxuICAgICAgICAgICAgICAgIF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlXG4gICAgICAgICAgICB9LFxuXHRcdFx0ZnVuY3Rpb24ocmVzcG9uc2UpIHtcblx0XHRcdFx0aWYgKCByZXNwb25zZS5zdWNjZXNzICkge1xuXHRcdFx0XHRcdC8vIEhpZGUgTW9iaWxlIENQQ1NTIGJ0biBvbiBzdWNjZXNzLlxuXHRcdFx0XHRcdCQoJyN3cHItYWN0aW9uLXJvY2tldF9lbmFibGVfZ29vZ2xlX2ZvbnRzJykuaGlkZSgpO1xuXHRcdFx0XHRcdCQoJy53cHItaGlkZS1vbi1jbGljaycpLmhpZGUoKTtcblx0XHRcdFx0XHQkKCcud3ByLXNob3ctb24tY2xpY2snKS5zaG93KCk7XG4gICAgICAgICAgICAgICAgICAgICQoJyN3cHItYWN0aW9uLXJvY2tldF9lbmFibGVfZ29vZ2xlX2ZvbnRzJykucmVtb3ZlQ2xhc3MoJ3dwci1pc0xvYWRpbmcnKTtcbiAgICAgICAgICAgICAgICAgICAgJCgnI21pbmlmeV9nb29nbGVfZm9udHMnKS52YWwoMSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cbiAgICAgICAgKTtcbiAgICB9KTtcblxuICAgICQoICcjcm9ja2V0LWRpc21pc3MtcHJvbW90aW9uJyApLm9uKCAnY2xpY2snLCBmdW5jdGlvbiggZSApIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgICQucG9zdChcbiAgICAgICAgICAgIGFqYXh1cmwsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAncm9ja2V0X2Rpc21pc3NfcHJvbW8nLFxuICAgICAgICAgICAgICAgIG5vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlXG4gICAgICAgICAgICB9LFxuXHRcdFx0ZnVuY3Rpb24ocmVzcG9uc2UpIHtcblx0XHRcdFx0aWYgKCByZXNwb25zZS5zdWNjZXNzICkge1xuXHRcdFx0XHRcdCQoJyNyb2NrZXQtcHJvbW8tYmFubmVyJykuaGlkZSggJ3Nsb3cnICk7XG5cdFx0XHRcdH1cblx0XHRcdH1cbiAgICAgICAgKTtcbiAgICB9ICk7XG5cbiAgICAkKCAnI3JvY2tldC1kaXNtaXNzLXJlbmV3YWwnICkub24oICdjbGljaycsIGZ1bmN0aW9uKCBlICkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgJC5wb3N0KFxuICAgICAgICAgICAgYWpheHVybCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY3Rpb246ICdyb2NrZXRfZGlzbWlzc19yZW5ld2FsJyxcbiAgICAgICAgICAgICAgICBub25jZTogcm9ja2V0X2FqYXhfZGF0YS5ub25jZVxuICAgICAgICAgICAgfSxcblx0XHRcdGZ1bmN0aW9uKHJlc3BvbnNlKSB7XG5cdFx0XHRcdGlmICggcmVzcG9uc2Uuc3VjY2VzcyApIHtcblx0XHRcdFx0XHQkKCcjcm9ja2V0LXJlbmV3YWwtYmFubmVyJykuaGlkZSggJ3Nsb3cnICk7XG5cdFx0XHRcdH1cblx0XHRcdH1cbiAgICAgICAgKTtcbiAgICB9ICk7XG5cdCQoICcjd3ByLXVwZGF0ZS1leGNsdXNpb24tbGlzdCcgKS5vbiggJ2NsaWNrJywgZnVuY3Rpb24oIGUgKSB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdCQoJyN3cHItdXBkYXRlLWV4Y2x1c2lvbi1tc2cnKS5odG1sKCcnKTtcblx0XHQkLmFqYXgoe1xuXHRcdFx0dXJsOiByb2NrZXRfYWpheF9kYXRhLnJlc3RfdXJsLFxuXHRcdFx0YmVmb3JlU2VuZDogZnVuY3Rpb24gKCB4aHIgKSB7XG5cdFx0XHRcdHhoci5zZXRSZXF1ZXN0SGVhZGVyKCAnWC1XUC1Ob25jZScsIHJvY2tldF9hamF4X2RhdGEucmVzdF9ub25jZSApO1xuXHRcdFx0XHR4aHIuc2V0UmVxdWVzdEhlYWRlciggJ0FjY2VwdCcsICdhcHBsaWNhdGlvbi9qc29uLCAqLyo7cT0wLjEnICk7XG5cdFx0XHRcdHhoci5zZXRSZXF1ZXN0SGVhZGVyKCAnQ29udGVudC1UeXBlJywgJ2FwcGxpY2F0aW9uL2pzb24nICk7XG5cdFx0XHR9LFxuXHRcdFx0bWV0aG9kOiBcIlBVVFwiLFxuXHRcdFx0c3VjY2VzczogZnVuY3Rpb24ocmVzcG9uc2VzKSB7XG5cdFx0XHRcdGxldCBleGNsdXNpb25fbXNnX2NvbnRhaW5lciA9ICQoJyN3cHItdXBkYXRlLWV4Y2x1c2lvbi1tc2cnKTtcblx0XHRcdFx0ZXhjbHVzaW9uX21zZ19jb250YWluZXIuaHRtbCgnJyk7XG5cdFx0XHRcdGlmICggdW5kZWZpbmVkICE9PSByZXNwb25zZXNbJ3N1Y2Nlc3MnXSApIHtcblx0XHRcdFx0XHRleGNsdXNpb25fbXNnX2NvbnRhaW5lci5hcHBlbmQoICc8ZGl2IGNsYXNzPVwibm90aWNlIG5vdGljZS1lcnJvclwiPicgKyByZXNwb25zZXNbJ21lc3NhZ2UnXSArICc8L2Rpdj4nICk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHRcdE9iamVjdC5rZXlzKCByZXNwb25zZXMgKS5mb3JFYWNoKCggcmVzcG9uc2Vfa2V5ICkgPT4ge1xuXHRcdFx0XHRcdGV4Y2x1c2lvbl9tc2dfY29udGFpbmVyLmFwcGVuZCggJzxzdHJvbmc+JyArIHJlc3BvbnNlX2tleSArICc6IDwvc3Ryb25nPicgKTtcblx0XHRcdFx0XHRleGNsdXNpb25fbXNnX2NvbnRhaW5lci5hcHBlbmQoIHJlc3BvbnNlc1tyZXNwb25zZV9rZXldWydtZXNzYWdlJ10gKTtcblx0XHRcdFx0XHRleGNsdXNpb25fbXNnX2NvbnRhaW5lci5hcHBlbmQoICc8YnI+JyApO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9KTtcblx0fSApO1xuXG4gICAgLyoqXG4gICAgICogRW5hYmxlIG1vYmlsZSBjYWNoZSBvcHRpb24uXG4gICAgICovXG4gICAgJCgnI3dwcl9lbmFibGVfbW9iaWxlX2NhY2hlJykub24oJ2NsaWNrJywgZnVuY3Rpb24oZSkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG5cblx0XHQkKCcjd3ByX2VuYWJsZV9tb2JpbGVfY2FjaGUnKS5hZGRDbGFzcygnd3ByLWlzTG9hZGluZycpO1xuXG4gICAgICAgICQucG9zdChcbiAgICAgICAgICAgIGFqYXh1cmwsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAncm9ja2V0X2VuYWJsZV9tb2JpbGVfY2FjaGUnLFxuICAgICAgICAgICAgICAgIF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlXG4gICAgICAgICAgICB9LFxuXHRcdFx0ZnVuY3Rpb24ocmVzcG9uc2UpIHtcblx0XHRcdFx0aWYgKCByZXNwb25zZS5zdWNjZXNzICkge1xuXHRcdFx0XHRcdC8vIEhpZGUgTW9iaWxlIGNhY2hlIGVuYWJsZSBidXR0b24gb24gc3VjY2Vzcy5cblx0XHRcdFx0XHQkKCcjd3ByX2VuYWJsZV9tb2JpbGVfY2FjaGUnKS5oaWRlKCk7XG5cdFx0XHRcdFx0JCgnI3dwcl9tb2JpbGVfY2FjaGVfZGVmYXVsdCcpLmhpZGUoKTtcblx0XHRcdFx0XHQkKCcjd3ByX21vYmlsZV9jYWNoZV9yZXNwb25zZScpLnNob3coKTtcbiAgICAgICAgICAgICAgICAgICAgJCgnI3dwcl9lbmFibGVfbW9iaWxlX2NhY2hlJykucmVtb3ZlQ2xhc3MoJ3dwci1pc0xvYWRpbmcnKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdmFsdWVzIG9mIG1vYmlsZSBjYWNoZSBhbmQgc2VwYXJhdGUgY2FjaGUgZmlsZXMgZm9yIG1vYmlsZXMgb3B0aW9uIHRvIDEuXG4gICAgICAgICAgICAgICAgICAgICQoJyNjYWNoZV9tb2JpbGUnKS52YWwoMSk7XG4gICAgICAgICAgICAgICAgICAgICQoJyNkb19jYWNoaW5nX21vYmlsZV9maWxlcycpLnZhbCgxKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuICAgICAgICApO1xuICAgIH0pO1xufSk7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ0RPTUNvbnRlbnRMb2FkZWQnLCBmdW5jdGlvbigpIHtcblx0Y29uc3QgYW5hbHl0aWNzQ2hlY2tib3ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYW5hbHl0aWNzX2VuYWJsZWQnKTtcblxuXHRpZiAoYW5hbHl0aWNzQ2hlY2tib3gpIHtcblx0XHRhbmFseXRpY3NDaGVja2JveC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBmdW5jdGlvbigpIHtcblx0XHRcdGNvbnN0IGlzQ2hlY2tlZCA9IHRoaXMuY2hlY2tlZDtcblxuXHRcdFx0Ly8gVXBkYXRlIHRoZSBnbG9iYWwgbWl4cGFuZWwgZGF0YSBvcHRpbiBzdGF0ZSBpbW1lZGlhdGVseVxuXHRcdFx0aWYgKHR5cGVvZiByb2NrZXRfbWl4cGFuZWxfZGF0YSAhPT0gJ3VuZGVmaW5lZCcpIHtcblx0XHRcdFx0cm9ja2V0X21peHBhbmVsX2RhdGEub3B0aW5fZW5hYmxlZCA9IGlzQ2hlY2tlZCA/ICcxJyA6ICcwJztcblx0XHRcdH1cblxuXHRcdFx0ZmV0Y2goYWpheHVybCwge1xuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdFx0aGVhZGVyczoge1xuXHRcdFx0XHRcdCdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0Ym9keTogbmV3IFVSTFNlYXJjaFBhcmFtcyh7XG5cdFx0XHRcdFx0YWN0aW9uOiAncm9ja2V0X3RvZ2dsZV9vcHRpbicsXG5cdFx0XHRcdFx0dmFsdWU6IGlzQ2hlY2tlZCA/IDEgOiAwLFxuXHRcdFx0XHRcdF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlLFxuXHRcdFx0XHR9KVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn0pO1xuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgZnVuY3Rpb24oKSB7XG5cdC8qKlxuXHQgKiBQZXJmb3JtYW5jZSBNb25pdG9yaW5nIHdpdGggUHJvZ3Jlc3NpdmUgUG9sbGluZy5cblx0ICovXG5cblx0XHQvLyA9PT09IENvbmZpZ3VyYXRpb24gPT09PVxuXHRjb25zdCBQT0xMX0JBU0VfSU5URVJWQUwgPSAyMDAwOyAgIC8vIFN0YXJ0IHBvbGxpbmcgYXQgMiBzZWNvbmRzXG5cdGNvbnN0IFBPTExfTUFYX0lOVEVSVkFMID0gNTAwMDsgICAvLyBNYXggcG9sbGluZyBpbnRlcnZhbCAoNSBzZWNvbmRzKVxuXG5cdC8vID09PT0gU3RhdGUgPT09PVxuXHRsZXQgcm9ja2V0SW5zaWdodHNJZHMgPSBBcnJheS5pc0FycmF5KHdpbmRvdy5yb2NrZXRfYWpheF9kYXRhPy5yb2NrZXRfaW5zaWdodHNfaWRzKSA/IHdpbmRvdy5yb2NrZXRfYWpheF9kYXRhLnJvY2tldF9pbnNpZ2h0c19pZHMuc2xpY2UoKSA6IFtdO1xuXHRsZXQgcG9sbEludGVydmFsID0gUE9MTF9CQVNFX0lOVEVSVkFMO1xuXHRsZXQgcG9sbFRpbWVyID0gbnVsbDtcblx0bGV0IGhhc0NyZWRpdCA9IHRydWU7IC8vIFRyYWNrIGNyZWRpdCBzdGF0dXNcbiAgICBsZXQgZ2xvYmFsU2NvcmVEYXRhID0ge1xuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBzdGF0dXM6ICcnLFxuICAgICAgICAgICAgc2NvcmU6IDAsXG4gICAgICAgICAgICBwYWdlc19udW06IDBcbiAgICAgICAgfSxcbiAgICAgICAgaHRtbDogJycsXG4gICAgICAgIHJvd19odG1sOiAnJyxcblx0XHRkaXNhYmxlZF9idG5faHRtbDoge1xuXHRcdFx0Z2xvYmFsX3Njb3JlX3dpZGdldDogJycsXG5cdFx0XHRyb2NrZXRfaW5zaWdodHM6ICcnXG5cdFx0fVxuICAgIH07XG5cbiAgICAvLyBJbml0aWFsaXplIGdsb2JhbFNjb3JlRGF0YSBmcm9tIGxvY2FsaXplZCBzY3JpcHQgZGF0YSBpZiBhdmFpbGFibGVcbiAgICBpZiAod2luZG93LnJvY2tldF9hamF4X2RhdGE/Lmdsb2JhbF9zY29yZV9kYXRhKSB7XG4gICAgICAgIGdsb2JhbFNjb3JlRGF0YSA9IHdpbmRvdy5yb2NrZXRfYWpheF9kYXRhLmdsb2JhbF9zY29yZV9kYXRhO1xuICAgIH1cblxuXHQvLyA9PT09IERPTSBTZWxlY3RvcnMgPT09PVxuXHRjb25zdCAkcGFnZVVybElucHV0ID0gJCgnI3dwci1zcGVlZC1yYWRhci11cmwtaW5wdXQnKTtcblx0Y29uc3QgJHRhYmxlQm9keSA9ICQoJy53cHItcmktdXJscy10YWJsZSB0Ym9keScpO1xuXHRjb25zdCAkdGFibGUgPSAkKCcud3ByLXJpLXVybHMtdGFibGUnKTtcblxuXHQvLyA9PT09IFV0aWxpdHkgRnVuY3Rpb25zID09PT1cblx0ZnVuY3Rpb24gaXNWYWxpZFVybChpbnB1dCkge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGlucHV0KTtcblx0XHRcdHJldHVybiB1cmwuaG9zdG5hbWUuaW5jbHVkZXMoJy4nKSAmJiB1cmwuaG9zdG5hbWUuc3BsaXQoJy4nKS5wb3AoKS5sZW5ndGggPiAwO1xuXHRcdH0gY2F0Y2gge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIGFkZElkcyhuZXdJZCkge1xuXHRcdGlmICghcm9ja2V0SW5zaWdodHNJZHMuaW5jbHVkZXMobmV3SWQpKSB7XG5cdFx0XHRyb2NrZXRJbnNpZ2h0c0lkcy5wdXNoKG5ld0lkKTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBoYXNJZChpZCkge1xuXHRcdHJldHVybiByb2NrZXRJbnNpZ2h0c0lkcy5pbmNsdWRlcyhpZCk7XG5cdH1cblxuXHRmdW5jdGlvbiByZW1vdmVJZChpZCkge1xuXHRcdC8vIEVuc3VyZSB0aGF0IHRoZSBpZCB0byBiZSByZW1vdmVkIGlzIGFuIGludGVnZXIgZm9yIGFjY3VyYXRlIGNvbXBhcmlzb24uXG5cdFx0Y29uc3QgaWRUb1JlbW92ZSA9IHBhcnNlSW50KGlkLCAxMCk7XG5cdFx0cm9ja2V0SW5zaWdodHNJZHMgPSByb2NrZXRJbnNpZ2h0c0lkcy5maWx0ZXIoeCA9PiBwYXJzZUludCh4LCAxMCkgIT09IGlkVG9SZW1vdmUpO1xuXHR9XG5cblx0ZnVuY3Rpb24gdXBkYXRlUXVvdGFCYW5uZXIoY2FuQWRkUGFnZXMpIHtcblx0XHRjb25zdCAkc3VtbWFyeUluZm8gICAgPSAkKCcud3ByLXJpLXN1bW1hcnktaW5mbycpO1xuXHRcdGNvbnN0IGlzRnJlZSAgPSB3aW5kb3cucm9ja2V0X2FqYXhfZGF0YT8uaXNfZnJlZSA9PT0gJzEnO1xuXHRcdGNvbnN0ICRxdW90YUJhbm5lciA9IGlzRnJlZSA/ICQoJyN3cHItcmktcXVvdGEtYmFubmVyJykgOiAkKCcjcm9ja2V0X2luc2lnaHRzX3N1cnZleScpO1xuXG5cdFx0Ly8gU2hvdyBiYW5uZXIgaWYgVVJMIGxpbWl0IHJlYWNoZWQgT1Igbm8gY3JlZGl0cyBsZWZ0IChtYXRjaGluZyBQSFAgbG9naWMgaW4gU3Vic2NyaWJlci5waHAgbGluZSAzOTgpLlxuXHRcdGNvbnN0IHNob3VsZFNob3dCYW5uZXIgPSBjYW5BZGRQYWdlcyA9PT0gZmFsc2UgfHwgIWhhc0NyZWRpdDtcblxuXHRcdGlmIChzaG91bGRTaG93QmFubmVyKSB7XG5cdFx0XHQkc3VtbWFyeUluZm8uaGlkZSgpO1xuXHRcdFx0JHF1b3RhQmFubmVyLnJlbW92ZUNsYXNzKCdoaWRkZW4nKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0JHN1bW1hcnlJbmZvLnNob3coKTtcblx0XHRcdCRxdW90YUJhbm5lci5hZGRDbGFzcygnaGlkZGVuJyk7XG5cdFx0fVxuXHR9XG5cblx0ZnVuY3Rpb24gdXBkYXRlQ3JlZGl0U3RhdGUocmVzcG9uc2VIYXNDcmVkaXQpIHtcblx0XHRpZiAocmVzcG9uc2VIYXNDcmVkaXQgIT09IHVuZGVmaW5lZCAmJiBoYXNDcmVkaXQgIT09IHJlc3BvbnNlSGFzQ3JlZGl0KSB7XG5cdFx0XHRoYXNDcmVkaXQgPSByZXNwb25zZUhhc0NyZWRpdDtcblxuXHRcdFx0Ly8gVXBkYXRlIGFsbCByZXRlc3QgYnV0dG9ucyB3aGVuIGNyZWRpdCBzdGF0dXMgY2hhbmdlc1xuXHRcdFx0dXBkYXRlQWxsUmV0ZXN0QnV0dG9ucygpO1xuXHRcdH1cblx0fVxuXG5cdGZ1bmN0aW9uIHVwZGF0ZUFsbFJldGVzdEJ1dHRvbnMoKSB7XG5cdFx0Y29uc3QgcmV0ZXN0QnV0dG9ucyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy53cHItYWN0aW9uLXNwZWVkX3JhZGFyX3JlZnJlc2gnKTtcblxuXHRcdHJldGVzdEJ1dHRvbnMuZm9yRWFjaChidXR0b24gPT4ge1xuXHRcdFx0Y29uc3Qgcm93ID0gYnV0dG9uLmNsb3Nlc3QoJy53cHItcmktaXRlbScpO1xuXHRcdFx0aWYgKCFyb3cpIHJldHVybjtcblxuXHRcdFx0Ly8gR2V0IHRoZSByb3cgSUQgYW5kIGNoZWNrIGlmIGl0J3MgY3VycmVudGx5IGJlaW5nIHByb2Nlc3NlZFxuXHRcdFx0Y29uc3Qgcm93SWQgPSBwYXJzZUludChyb3cuZGF0YXNldC5yb2NrZXRJbnNpZ2h0c0lkLCAxMCk7XG5cdFx0XHRjb25zdCBpc1J1bm5pbmcgPSByb2NrZXRJbnNpZ2h0c0lkcy5pbmNsdWRlcyhyb3dJZCk7XG5cblx0XHRcdGlmICghaGFzQ3JlZGl0IHx8IGlzUnVubmluZykge1xuXHRcdFx0XHQvLyBEaXNhYmxlIGJ1dHRvblxuXHRcdFx0XHRidXR0b24uY2xhc3NMaXN0LmFkZCgnd3ByLXJpLWFjdGlvbi0tZGlzYWJsZWQnKTtcblx0XHRcdFx0YnV0dG9uLnNldEF0dHJpYnV0ZSgnZGlzYWJsZWQnLCAndHJ1ZScpO1xuXG5cdFx0XHRcdGlmICghaGFzQ3JlZGl0KSB7XG5cdFx0XHRcdFx0Ly8gQWRkIHRvb2x0aXAgZm9yIG5vIGNyZWRpdFxuXHRcdFx0XHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCd3cHItYnRuLXdpdGgtdG9vbC10aXAnKTtcblx0XHRcdFx0XHRidXR0b24uc2V0QXR0cmlidXRlKCd0aXRsZScsIHdpbmRvdy5yb2NrZXRfYWpheF9kYXRhPy5yb2NrZXRfaW5zaWdodHNfbm9fY3JlZGl0X3Rvb2x0aXAgfHwgJ1VwZ3JhZGUgeW91ciBwbGFuIHRvIGdldCBhY2Nlc3MgdG8gcmUtdGVzdCBwZXJmb3JtYW5jZSBvciBydW4gbmV3IHRlc3RzJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdC8vIEVuYWJsZSBidXR0b25cblx0XHRcdFx0YnV0dG9uLmNsYXNzTGlzdC5yZW1vdmUoJ3dwci1yaS1hY3Rpb24tLWRpc2FibGVkJywgJ3dwci1idG4td2l0aC10b29sLXRpcCcpO1xuXHRcdFx0XHRidXR0b24ucmVtb3ZlQXR0cmlidXRlKCdkaXNhYmxlZCcpO1xuXHRcdFx0XHRidXR0b24ucmVtb3ZlQXR0cmlidXRlKCd0aXRsZScpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0ZnVuY3Rpb24gcmVzZXRQb2xsaW5nKCkge1xuXHRcdGlmIChwb2xsVGltZXIpIHtcblx0XHRcdGNsZWFyVGltZW91dChwb2xsVGltZXIpO1xuXHRcdFx0cG9sbFRpbWVyID0gbnVsbDtcblx0XHR9XG5cdFx0cG9sbEludGVydmFsID0gUE9MTF9CQVNFX0lOVEVSVkFMO1xuXHR9XG5cblx0ZnVuY3Rpb24gc2NoZWR1bGVQb2xsaW5nKCkge1xuXHRcdGlmIChyb2NrZXRJbnNpZ2h0c0lkcy5sZW5ndGggPiAwKSB7XG5cdFx0XHRwb2xsVGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0Z2V0UmVzdWx0cygpO1xuXHRcdFx0fSwgcG9sbEludGVydmFsKTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBpbmNyZW1lbnRQb2xsaW5nKCkge1xuXHRcdHBvbGxJbnRlcnZhbCA9IE1hdGgubWluKHBvbGxJbnRlcnZhbCAqIDEuMywgUE9MTF9NQVhfSU5URVJWQUwpOyAvLyBFeHBvbmVudGlhbCBiYWNrb2ZmXG5cdH1cblxuICAgIGZ1bmN0aW9uIGlzT25EYXNoYm9hcmQoKSB7XG4gICAgICAgIGNvbnN0IHVybFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XG4gICAgICAgIHJldHVybiB1cmxQYXJhbXMuZ2V0KCdwYWdlJykgPT09ICd3cHJvY2tldCcgJiYgd2luZG93LmxvY2F0aW9uLmhhc2ggPT09ICcjZGFzaGJvYXJkJztcbiAgICB9XG5cblx0ZnVuY3Rpb24gaXNPblJvY2tldEluc2lnaHRzKCkge1xuXHRcdGNvbnN0IHVybFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XG5cdFx0cmV0dXJuIHVybFBhcmFtcy5nZXQoJ3BhZ2UnKSA9PT0gJ3dwcm9ja2V0JyAmJiB3aW5kb3cubG9jYXRpb24uaGFzaCA9PT0gJyNyb2NrZXRfaW5zaWdodHMnO1xuXHR9XG5cblx0ZnVuY3Rpb24gdXBkYXRlR2xvYmFsU2NvcmVSb3coZ2xvYmFsU2NvcmVEYXRhKXtcblx0XHRjb25zdCAkdGFibGVHbG9iYWxTY29yZSA9ICQoJy53cHItcmktdXJscy10YWJsZSAud3ByLWdsb2JhbC1zY29yZScpO1xuXHRcdGlmICgkdGFibGVHbG9iYWxTY29yZS5sZW5ndGggPiAwKXtcblx0XHRcdCR0YWJsZUdsb2JhbFNjb3JlLnJlcGxhY2VXaXRoKGdsb2JhbFNjb3JlRGF0YS5yb3dfaHRtbCk7XG5cdFx0fWVsc2UgaWYgKCR0YWJsZUJvZHkubGVuZ3RoID4gMCkge1xuXHRcdFx0JHRhYmxlQm9keS5wcmVwZW5kKGdsb2JhbFNjb3JlRGF0YS5yb3dfaHRtbCk7XG5cdFx0fVxuXHRcdGRlY2lkZUdsb2JhbFNjb3JlVG9VcGRhdGUoKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSBnbG9iYWwgc2NvcmUgVUkgd2lkZ2V0IG9yIHRhYmxlIHJvdyBiYXNlZCBvbiB0aGUgc2VsZWN0ZWQgbWVudS5cblx0ICogV2hlbiB0aGUgZGFzaGJvYXJkIG9yIHJvY2tldCBpbnNpZ2h0cyBtZW51IGlzIGNsaWNrZWQsIHRoaXMgZnVuY3Rpb24gdXBkYXRlc1xuXHQgKiB0aGUgY29ycmVzcG9uZGluZyBnbG9iYWwgc2NvcmUgZGlzcGxheSBhZnRlciBhIHNob3J0IGRlbGF5LlxuXHQgKi9cblx0ZnVuY3Rpb24gZGVjaWRlR2xvYmFsU2NvcmVUb1VwZGF0ZSgpIHtcblx0XHRpZiAoJycgPT09IGdsb2JhbFNjb3JlRGF0YS5odG1sKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGxldCBnbG9iYWxTY29yZVdpZGdldHMgPSAkKCcud3ByLWdsb2JhbC1zY29yZS13aWRnZXQnKTtcblxuXHRcdGlmIChnbG9iYWxTY29yZVdpZGdldHMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gVXBkYXRlIGFsbCBnbG9iYWwgc2NvcmUgd2lkZ2V0IGluc3RhbmNlcy5cblx0XHRnbG9iYWxTY29yZVdpZGdldHMuaHRtbChnbG9iYWxTY29yZURhdGEuaHRtbCk7XG5cblx0XHQvLyBEaXNhYmxlIFwiQWRkIFBhZ2VzXCIgYnV0dG9uIG9uIGdsb2JhbCBzY29yZSB3aWRnZXQuXG5cdFx0aWYgKCEoJ2Rpc2FibGVkX2J0bl9odG1sJyBpbiBnbG9iYWxTY29yZURhdGEpKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0JCgnLndwci1nbG9iYWwtc2NvcmUtd2lkZ2V0IC53cHItZ2xvYmFsLXNjb3JlLXdpZGdldC1idG4td3JhcHBlcicpLmh0bWwoZ2xvYmFsU2NvcmVEYXRhLmRpc2FibGVkX2J0bl9odG1sLmdsb2JhbF9zY29yZV93aWRnZXQpO1xuXHR9XG5cblx0Ly8gPT09PSBBSkFYIEhhbmRsZXJzID09PT1cblx0ZnVuY3Rpb24gZ2V0UmVzdWx0cygpIHtcblx0XHRpZiAocm9ja2V0SW5zaWdodHNJZHMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRyZXNldFBvbGxpbmcoKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR3aW5kb3cud3AuYXBpRmV0Y2goXG5cdFx0XHR7XG5cdFx0XHRcdHBhdGg6IHdpbmRvdy53cC51cmwuYWRkUXVlcnlBcmdzKCAnL3dwLXJvY2tldC92MS9yb2NrZXQtaW5zaWdodHMvcGFnZXMvcHJvZ3Jlc3MnLCB7IGlkczogcm9ja2V0SW5zaWdodHNJZHMgfSApLFxuXHRcdFx0fVxuXHRcdCkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdGlmIChyZXNwb25zZS5zdWNjZXNzICYmIEFycmF5LmlzQXJyYXkocmVzcG9uc2UucmVzdWx0cykpIHtcblx0XHRcdFx0Ly8gVXBkYXRlIGNyZWRpdCBzdGF0dXNcblx0XHRcdFx0dXBkYXRlQ3JlZGl0U3RhdGUocmVzcG9uc2UuaGFzX2NyZWRpdCk7XG5cblx0XHRcdFx0Ly8gVXBkYXRlIHF1b3RhIGJhbm5lciB2aXNpYmlsaXR5XG5cdFx0XHRcdHVwZGF0ZVF1b3RhQmFubmVyKHJlc3BvbnNlLmNhbl9hZGRfcGFnZXMpO1xuXG5cdFx0XHRcdC8vIFVwZGF0ZSBnbG9iYWwgc2NvcmUgZGF0YSBhbmQgd2lkZ2V0IHdoZW4gc3RhdHVzIHx8IHBhZ2UgY291bnQgY2hhbmdlcy5cblx0XHRcdFx0aWYgKGdsb2JhbFNjb3JlRGF0YS5kYXRhLnN0YXR1cyAhPT0gcmVzcG9uc2UuZ2xvYmFsX3Njb3JlX2RhdGEuZGF0YS5zdGF0dXMgfHwgZ2xvYmFsU2NvcmVEYXRhLmRhdGEucGFnZXNfbnVtICE9PSByZXNwb25zZS5nbG9iYWxfc2NvcmVfZGF0YS5kYXRhLnBhZ2VzX251bSkge1xuXHRcdFx0XHRcdC8vIFVwZGF0ZSBnbG9iYWwgc2NvcmUgZGF0YS5cblx0XHRcdFx0XHRnbG9iYWxTY29yZURhdGEgPSByZXNwb25zZS5nbG9iYWxfc2NvcmVfZGF0YTtcblxuXHRcdFx0XHRcdC8vIFVwZGF0ZSBhbGwgZ2xvYmFsIHNjb3JlIHdpZGdldCBpbnN0YW5jZXMuXG5cdFx0XHRcdFx0JCgnLndwci1nbG9iYWwtc2NvcmUtd2lkZ2V0JykuaHRtbChyZXNwb25zZS5nbG9iYWxfc2NvcmVfZGF0YS5odG1sKTtcblx0XHRcdFx0XHQvLyBVcGRhdGUgZ2xvYmFsIHNjb3JlIHJvdyBpbiB0YWJsZSBpZiBvbiBSb2NrZXQgSW5zaWdodHMgcGFnZS5cblx0XHRcdFx0XHR1cGRhdGVHbG9iYWxTY29yZVJvdyhnbG9iYWxTY29yZURhdGEpO1xuXG5cdFx0XHRcdFx0Ly8gRmlyZSBjdXN0b20gZXZlbnQgZm9yIG90aGVyIHdpZGdldHMgKGxpa2UgcmVjb21tZW5kYXRpb25zKVxuXHRcdFx0XHRcdGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCd3cHJHbG9iYWxTY29yZVVwZGF0ZWQnLCB7IGRldGFpbDogZ2xvYmFsU2NvcmVEYXRhLmRhdGEgfSkpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJlc3BvbnNlLnJlc3VsdHMuZm9yRWFjaChyZXN1bHQgPT4ge1xuXHRcdFx0XHRcdGNvbnN0ICRyb3cgPSAkKGAud3ByLXJpLWl0ZW1bZGF0YS1yb2NrZXQtaW5zaWdodHMtaWQ9XCIke3Jlc3VsdC5pZH1cIl1gKTtcblx0XHRcdFx0XHQkcm93LnJlcGxhY2VXaXRoKHJlc3VsdC5odG1sKTtcblxuXHRcdFx0XHRcdCQoZG9jdW1lbnQpLnRyaWdnZXIoJ3JvY2tldC1pbnNpZ2h0cy1wYWdlLXRlc3QtcG9sbGluZycsIFtyZXN1bHQuaWRdKTtcblxuXHRcdFx0XHRcdC8vIFRyaWdnZXIgY3VzdG9tIGV2ZW50IG9ubHkgd2hlbiB0ZXN0IGlzIGNvbXBsZXRlZCBhbmQgbm90IGZhaWxlZCwgc28gd2UgZG9uJ3QgdGFyZ2V0IGFuIGVsZW1lbnQgdGhhdCBtaWdodCBiZSByZW1vdmVkIGZyb20gdGhlIERPTSBhZnRlciB0ZXN0IGNvbXBsZXRpb24uXG5cdFx0XHRcdFx0aWYgKHJlc3VsdC5zdGF0dXMgPT09ICdjb21wbGV0ZWQnKSB7XG5cdFx0XHRcdFx0XHQkKGRvY3VtZW50KS50cmlnZ2VyKCdyb2NrZXQtaW5zaWdodHMtcGFnZS10ZXN0LWNvbXBsZXRlZCcsIFtyZXN1bHQuaWRdKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRpZiAocmVzdWx0LnN0YXR1cyA9PT0gJ2NvbXBsZXRlZCcgfHwgcmVzdWx0LnN0YXR1cyA9PT0gJ2ZhaWxlZCcpIHtcblx0XHRcdFx0XHRcdHJlbW92ZUlkKHJlc3VsdC5pZCk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblxuXHRcdFx0XHRpbmNyZW1lbnRQb2xsaW5nKCk7XG5cdFx0XHRcdHNjaGVkdWxlUG9sbGluZygpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Ly8gT24gZXJyb3IsIGNsZWFyIElEcyBhbmQgc3RvcCBwb2xsaW5nXG5cdFx0XHRcdHJvY2tldEluc2lnaHRzSWRzID0gW107XG5cdFx0XHRcdHJlc2V0UG9sbGluZygpO1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKCdQb2xsaW5nIGVycm9yOicsIHJlc3BvbnNlLnJlc3VsdHMgfHwgcmVzcG9uc2UpO1xuXHRcdFx0fVxuXHRcdH0gKTtcblx0fVxuXG5cdGZ1bmN0aW9uIGhhbmRsZUFkZFBhZ2UoZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblxuXHRcdC8vIGNoZWNrIGlmIGhhcyBhdHRyIGRpc2FibGVkXG5cdFx0aWYgKCQodGhpcykuYXR0cignZGlzYWJsZWQnKSkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IHBhZ2VVcmwgPSAkcGFnZVVybElucHV0LnZhbCgpLnRyaW0oKTtcblxuXHRcdGlmICghaXNWYWxpZFVybChwYWdlVXJsKSkge1xuXHRcdFx0YWxlcnQoJ1BsZWFzZSBlbnRlciBhIHZhbGlkIFVSTCcpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IHNvdXJjZSA9ICQodGhpcykuZGF0YSgnc291cmNlJyk7XG5cblx0XHR3aW5kb3cud3AuYXBpRmV0Y2goXG5cdFx0XHR7XG5cdFx0XHRcdHBhdGg6ICcvd3Atcm9ja2V0L3YxL3JvY2tldC1pbnNpZ2h0cy9wYWdlcy8nLFxuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdFx0ZGF0YToge1xuXHRcdFx0XHRcdHBhZ2VfdXJsOiBwYWdlVXJsLFxuXHRcdFx0XHRcdHNvdXJjZTogc291cmNlXG5cdFx0XHRcdH0sXG5cdFx0XHR9XG5cdFx0KS50aGVuKCAoIHJlc3BvbnNlICkgPT4ge1xuXHRcdFx0aWYgKHJlc3BvbnNlLnN1Y2Nlc3MpIHtcblx0XHRcdFx0aWYgKCAhIGhhc0lkKHJlc3BvbnNlLmlkKSApIHtcblx0XHRcdFx0XHQkcGFnZVVybElucHV0LnZhbCgnJyk7XG5cdFx0XHRcdFx0JHRhYmxlQm9keS5hcHBlbmQocmVzcG9uc2UuaHRtbCk7XG5cblx0XHRcdFx0XHQvLyBDdXN0b20gZXZlbnQgd2hlbiBuZXcgcGFnZSBpcyBhZGRlZC5cblx0XHRcdFx0XHQkKGRvY3VtZW50KS50cmlnZ2VyKCdyb2NrZXQtaW5zaWdodHMtcGFnZS1hZGRlZCcpO1xuXG5cdFx0XHRcdFx0JHRhYmxlLnJlbW92ZUNsYXNzKCdoaWRkZW4nKTtcblx0XHRcdFx0XHRhZGRJZHMocmVzcG9uc2UuaWQpO1xuXHRcdFx0XHRcdGxldCBwYWdlc19udW1fY29udGFpbmVyID0gJCgnI3JvY2tldF9yb2NrZXRfaW5zaWdodHNfcGFnZXNfbnVtJyk7XG5cdFx0XHRcdFx0cGFnZXNfbnVtX2NvbnRhaW5lci50ZXh0KCBwYXJzZUludCggcGFnZXNfbnVtX2NvbnRhaW5lci50ZXh0KCkgKSArIDEgKTtcblxuXHRcdFx0XHRcdC8vIFVwZGF0ZSBjcmVkaXQgc3RhdHVzXG5cdFx0XHRcdFx0dXBkYXRlQ3JlZGl0U3RhdGUocmVzcG9uc2UuaGFzX2NyZWRpdCk7XG5cblx0XHRcdFx0XHQvLyBVcGRhdGUgZ2xvYmFsIHNjb3JlIGRhdGEuXG5cdFx0XHRcdFx0Z2xvYmFsU2NvcmVEYXRhID0gcmVzcG9uc2UuZ2xvYmFsX3Njb3JlX2RhdGE7XG5cblx0XHRcdFx0XHQvLyBVcGRhdGUgZ2xvYmFsIHNjb3JlIHJvdyBpbiB0YWJsZSBpZiBvbiBSb2NrZXQgSW5zaWdodHMgcGFnZS5cblx0XHRcdFx0XHR1cGRhdGVHbG9iYWxTY29yZVJvdyhnbG9iYWxTY29yZURhdGEpO1xuXG5cdFx0XHRcdFx0aWYgKCdkaXNhYmxlZF9idG5faHRtbCcgaW4gZ2xvYmFsU2NvcmVEYXRhKSB7XG5cdFx0XHRcdFx0XHQkKCcjd3ByX3JvY2tldF9pbnNpZ2h0c19hZGRfcGFnZV9idG5fd3JhcHBlcicpLmh0bWwoZ2xvYmFsU2NvcmVEYXRhLmRpc2FibGVkX2J0bl9odG1sLnJvY2tldF9pbnNpZ2h0cyk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Ly8gU2hvdy9oaWRlIHF1b3RhIGJhbm5lciBiYXNlZCBvbiBjYW5fYWRkX3BhZ2VzXG5cdFx0XHRcdFx0dXBkYXRlUXVvdGFCYW5uZXIocmVzcG9uc2UuY2FuX2FkZF9wYWdlcyk7XG5cblx0XHRcdFx0XHRpZiAocG9sbFRpbWVyKSB7XG5cdFx0XHRcdFx0XHRyZXNldFBvbGxpbmcoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0c2NoZWR1bGVQb2xsaW5nKCk7XG5cdFx0XHRcdH1cblxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Ly8gQ2xlYXIgdGhlIGlucHV0IGZpZWxkIG9uIGVycm9yXG5cdFx0XHRcdCRwYWdlVXJsSW5wdXQudmFsKCcnKTtcblxuXHRcdFx0XHQvLyBIYW5kbGUgVVJMIGxpbWl0IHJlYWNoZWQgZXJyb3Jcblx0XHRcdFx0aWYgKHJlc3BvbnNlPy5tZXNzYWdlICYmIHJlc3BvbnNlLm1lc3NhZ2UuaW5jbHVkZXMoJ01heGltdW0gbnVtYmVyIG9mIFVSTHMgcmVhY2hlZCcpKSB7XG5cdFx0XHRcdFx0Ly8gVXBkYXRlIFVJIHN0YXRlIHRvIHJlZmxlY3QgVVJMIGxpbWl0IGhhcyBiZWVuIHJlYWNoZWRcblx0XHRcdFx0XHRkaXNhYmxlQWRkVXJsRWxlbWVudHMoKTtcblx0XHRcdFx0XHQvLyBTaG93IHF1b3RhIGJhbm5lciAoY2FuX2FkZF9wYWdlcyA9IGZhbHNlKVxuXHRcdFx0XHRcdHVwZGF0ZVF1b3RhQmFubmVyKHJlc3BvbnNlLmNhbl9hZGRfcGFnZXMgIT09IHVuZGVmaW5lZCA/IHJlc3BvbnNlLmNhbl9hZGRfcGFnZXMgOiBmYWxzZSk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zb2xlLmVycm9yKHJlc3BvbnNlPy5tZXNzYWdlIHx8IHJlc3BvbnNlKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXG5cdGZ1bmN0aW9uIGhhbmRsZVJlc2V0UGFnZShlKSB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG5cdFx0Y29uc3QgJGJ1dHRvbiA9ICQodGhpcyk7XG5cdFx0bGV0IGlkID0gJGJ1dHRvbi5wYXJlbnRzKCcud3ByLXJpLWl0ZW0nKS5kYXRhKCdyb2NrZXQtaW5zaWdodHMtaWQnKTtcblx0XHRpZiAoICEgaWQgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Y29uc3Qgc291cmNlID0gJGJ1dHRvbi5kYXRhKCdzb3VyY2UnKTtcblxuXHRcdHdpbmRvdy53cC5hcGlGZXRjaChcblx0XHRcdHtcblx0XHRcdFx0cGF0aDogJy93cC1yb2NrZXQvdjEvcm9ja2V0LWluc2lnaHRzL3BhZ2VzLycgKyBpZCxcblx0XHRcdFx0bWV0aG9kOiAnUEFUQ0gnLFxuXHRcdFx0XHRkYXRhOiB7XG5cdFx0XHRcdFx0c291cmNlOiBzb3VyY2Vcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdCkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdGlmIChyZXNwb25zZS5zdWNjZXNzKSB7XG5cdFx0XHRcdGFkZElkcyhyZXNwb25zZS5pZCk7XG5cblx0XHRcdFx0JChgI3JpX2RldGFpbHNfJHtyZXNwb25zZS5pZH0gLmRldGFpbHMtc2VjdGlvbi10ZGApLnJlbW92ZSgpO1xuXHRcdFx0XHRjb25zdCAkcm93ID0gJChgW2RhdGEtcm9ja2V0LWluc2lnaHRzLWlkPVwiJHtyZXNwb25zZS5pZH1cIl1gKTtcblx0XHRcdFx0JHJvdy5yZXBsYWNlV2l0aChyZXNwb25zZS5odG1sKTtcblxuXHRcdFx0XHQvLyBDdXN0b20gZXZlbnQgd2hlbiBwYWdlIGlzIHJldGVzdGVkLlxuICAgICAgICBcdFx0JChkb2N1bWVudCkudHJpZ2dlcigncm9ja2V0LWluc2lnaHRzLXBhZ2UtcmV0ZXN0JywgW3Jlc3BvbnNlLmlkXSk7XG5cblx0XHRcdFx0Ly8gVXBkYXRlIGNyZWRpdCBzdGF0dXNcblx0XHRcdFx0dXBkYXRlQ3JlZGl0U3RhdGUocmVzcG9uc2UuaGFzX2NyZWRpdCk7XG5cblx0XHRcdFx0Ly8gVXBkYXRlIHF1b3RhIGJhbm5lciB2aXNpYmlsaXR5XG5cdFx0XHRcdHVwZGF0ZVF1b3RhQmFubmVyKHJlc3BvbnNlLmNhbl9hZGRfcGFnZXMpO1xuXG4gICAgICAgICAgICAgICAgLy8gVXBkYXRlIGdsb2JhbCBzY29yZSBkYXRhLlxuICAgICAgICAgICAgICAgIGdsb2JhbFNjb3JlRGF0YSA9IHJlc3BvbnNlLmdsb2JhbF9zY29yZV9kYXRhO1xuXG5cdFx0XHRcdC8vIFVwZGF0ZSBnbG9iYWwgc2NvcmUgcm93IGluIHRhYmxlIGlmIG9uIFJvY2tldCBJbnNpZ2h0cyBwYWdlLlxuXHRcdFx0XHR1cGRhdGVHbG9iYWxTY29yZVJvdyhnbG9iYWxTY29yZURhdGEpO1xuXG5cdFx0XHRcdGlmIChwb2xsVGltZXIpIHtcblx0XHRcdFx0XHRyZXNldFBvbGxpbmcoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRzY2hlZHVsZVBvbGxpbmcoKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNvbnNvbGUuZXJyb3IocmVzcG9uc2U/Lm1lc3NhZ2UgfHwgcmVzcG9uc2UpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cblx0Ly8gPT09PSBJbml0aWFsaXphdGlvbiA9PT09XG5cdC8vIEJpbmQgZXZlbnRcblx0JChkb2N1bWVudCkub24oICdjbGljaycsICcjd3ByLWFjdGlvbi1hZGRfcGFnZV9zcGVlZF9yYWRhcicsIGhhbmRsZUFkZFBhZ2UgKTtcblx0JChkb2N1bWVudCkub24oICdjbGljaycsICcud3ByLWFjdGlvbi1zcGVlZF9yYWRhcl9yZWZyZXNoJywgaGFuZGxlUmVzZXRQYWdlICk7XG5cdC8vIEhhbmRsZSBFbnRlciBrZXkgcHJlc3Mgb24gcGFnZSB1cmwgaW5wdXQuXG5cdCQoZG9jdW1lbnQpLm9uKCAna2V5cHJlc3MnLCAnI3dwci1zcGVlZC1yYWRhci11cmwtaW5wdXQnLCBmdW5jdGlvbihlKSB7XG5cdFx0aWYgKGUua2V5ID09PSAnRW50ZXInKSB7XG5cdFx0ICBlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0ICAkKCcjd3ByLWFjdGlvbi1hZGRfcGFnZV9zcGVlZF9yYWRhcicpLmNsaWNrKCk7XG5cdFx0fVxuXHR9KTtcblxuXHQvLyBPbmx5IHBvbGwgaWYgb24gYSB3cHIgc2VjdGlvbiB0aGF0IHJlcXVpcmVzIHBvbGxpbmcoZGFzaGJvYXJkfHJvY2tldF9pbnNpZ2h0cykgKG1vcmUgcm9idXN0IGNoZWNrKVxuICAgIGZ1bmN0aW9uIGlzVmFsaWRQYWdlRm9yUG9sbGluZygpIHtcbiAgICAgICAgY29uc3QgdXJsUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcblx0XHRyZXR1cm4gJ3dwcm9ja2V0JyA9PT0gdXJsUGFyYW1zLmdldCgncGFnZScpO1xuICAgIH1cblxuXHQvLyBSZXN1bWUgcG9sbGluZyBpZiBuZWVkZWRcblx0aWYgKGlzVmFsaWRQYWdlRm9yUG9sbGluZygpICYmIHJvY2tldEluc2lnaHRzSWRzLmxlbmd0aCA+IDApIHtcblx0XHRpZiAocG9sbFRpbWVyKSB7XG5cdFx0XHRyZXNldFBvbGxpbmcoKTtcblx0XHR9XG5cdFx0c2NoZWR1bGVQb2xsaW5nKCk7XG5cdH1cblxuXHQvLyBIYW5kbGUgVUkgdXBkYXRlIG9uIHRoZSByb2NrZXQgaW5zaWdodHMgdGFiIHdoZW4gXCJBZGQgUGFnZXNcIiBidXR0b24gb24gdGhlIGdsb2JhbCBzY29yZSB3aWRnZXQgaXMgY2xpY2tlZC5cblx0JChkb2N1bWVudCkub24oJ2NsaWNrJywgJy53cHItcGVyY2VudGFnZS1zY29yZS13aWRnZXQgLndwci1yaS1hZGQtdXJsLWJ1dHRvbicsIGZ1bmN0aW9uKCkge1xuXHRcdGlmICghdGhpcy50ZXh0Q29udGVudC5pbmNsdWRlcygnQWRkIFBhZ2VzJykpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBEZWxheSBVSSB1cGRhdGUgYSBiaXQgdGlsbCBlbGVtZW50IGlzIHZpc2libGUuXG5cdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR1cGRhdGVHbG9iYWxTY29yZVJvdyhnbG9iYWxTY29yZURhdGEpO1xuXHRcdH0sIDMwKTtcblx0fSk7XG5cblx0Ly8gSGFuZGxlIGNvbGxhcHNlZWQgc3R5bGluZyBmb3IgZmlyc3QgbG9hZCBvciBkeW5hbWljIHJvdyBhZGRpdGlvbi5cblx0ZnVuY3Rpb24gYWRkQ29sbGFwc2VkU3R5bGluZ1RvTGFzdFJvdyhvbkxvYWQgPSBmYWxzZSkge1xuXHRcdCQoJy53cHItcmktaXRlbScpLmxhc3QoKS5maW5kKCd0ZCcpLmFkZENsYXNzKCdib3JkZXItYm90dG9tJyk7XG5cblx0XHRpZiAob25Mb2FkKSB7XG5cdFx0XHQvLyBPbiBsb2FkLCByZW1vdmUgd3ByLWxhc3QtZXhwYW5kZWQgZnJvbSBlbGVtZW50cyB0aGF0IGFyZSBub3QgdGhlIGxhc3QgYWZ0ZXIgYmVpbmcgYWRkZWQgZnJvbSBiYWNrZW5kLlxuXHRcdFx0JCgnLndwci1yaS1pdGVtLXRvZ2dsZScpLm5vdCgnOmxhc3QnKS5yZW1vdmVDbGFzcygnd3ByLWxhc3QtZXhwYW5kZWQnKTtcblx0XHRcdCQoJy53cHItcmktaXRlbS1hY3Rpb25zJykubm90KCc6bGFzdCcpLnJlbW92ZUNsYXNzKCd3cHItbGFzdC1leHBhbmRlZCcpO1xuXHRcdFx0JCgnLmRldGFpbHMtc2VjdGlvbi10ZCcpLm5vdCgnOmxhc3QnKS5yZW1vdmVDbGFzcygnd3ByLWxhc3QtZXhwYW5kZWQnKTtcblxuXHRcdFx0Ly8gQmFpbCBlYXJseSBpZiBsYXN0IGl0ZW0gaXMgYWxyZWFkeSBleHBhbmRlZCBvbiBsb2FkIHNvIGFzIG5vdCB0byBoYXZlIGNvbmZsaWN0aW5nIHN0eWxlcy5cblx0XHRcdGlmKCQoJy5kZXRhaWxzLXNlY3Rpb24tdGQnKS5sYXN0KCkuaGFzQ2xhc3MoJ3dwci1sYXN0LWV4cGFuZGVkJykpIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdH1cblx0XHQkKCcud3ByLXJpLWl0ZW0tdG9nZ2xlJykubGFzdCgpLmFkZENsYXNzKCd3cHItbGFzdC1jb2xsYXBzZWQnKTtcblx0XHQkKCcud3ByLXJpLWl0ZW0tYWN0aW9ucycpLmxhc3QoKS5hZGRDbGFzcygnd3ByLWxhc3QtY29sbGFwc2VkJyk7XG5cdFx0JCgnLmRldGFpbHMtc2VjdGlvbi10ZCcpLmxhc3QoKS5hZGRDbGFzcygnd3ByLWxhc3QtY29sbGFwc2VkJyk7XG5cdH1cblxuXHQvLyBUb2dnbGVzIHRoZSB2aXNpYmlsaXR5IG9mIGEgc2luZ2xlIHRlc3QgZGV0YWlscyByb3csIHN3aXRjaGVzIHRoZSBjYXJldCBpY29uLCBhbmQgdXBkYXRlcyBzdHlsaW5nIGZvciB0aGUgbGFzdCBpdGVtLlxuXHRmdW5jdGlvbiB0b2dnbGVTaW5nbGVSb3dWaXNpYmlsaXR5KGluc2lnaHRzSWQsIHNvdXJjZSkge1xuXHRcdGxldCAkZWxlbWVudCA9ICQoYCNyaV9kZXRhaWxzXyR7aW5zaWdodHNJZH1gKTtcblx0XHRsZXQgaXNWaXNpYmxlID0gJGVsZW1lbnQuaGFzQ2xhc3MoJ3dwci1yaS1kZXRhaWxzLS1leHBhbmRlZCcpO1xuXHRcdGxldCBpc0xhc3QgPSAkKGBbZGF0YS1yb2NrZXQtaW5zaWdodHMtaWQ9XCIke2luc2lnaHRzSWR9XCJdIC53cHItcmktaXRlbS10b2dnbGUtc2luZ2xlYCkuaXMoJCgnLndwci1yaS1pdGVtLXRvZ2dsZS1zaW5nbGUnKS5sYXN0KCkpO1xuXG5cdFx0aWYgKCBpc1Zpc2libGUgKSB7XG5cdFx0XHQkZWxlbWVudC5yZW1vdmVDbGFzcygnd3ByLXJpLWRldGFpbHMtLWV4cGFuZGVkJyk7XG5cdFx0XHQkKGBbZGF0YS1yb2NrZXQtaW5zaWdodHMtaWQ9XCIke2luc2lnaHRzSWR9XCJdYCkucmVtb3ZlQ2xhc3MoJ3dwci1yaS1pdGVtLS1leHBhbmRlZCcpO1xuXHRcdFx0Ly8gTWFuaXB1bGF0ZSBzdHlsaW5nIGZvciBsYXN0IGVsZW1lbnRzIHdoZW4gZGV0YWlscyBjZWxsIGlzIG5vdCB2aXNpYmxlLlxuXHRcdFx0aWYgKGlzTGFzdCkge1xuXHRcdFx0XHR1cGRhdGVSb3dTdHlsaW5nRm9yTGFzdEl0ZW0oZmFsc2UpO1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0JGVsZW1lbnQuYWRkQ2xhc3MoJ3dwci1yaS1kZXRhaWxzLS1leHBhbmRlZCcpO1xuXHRcdCQoYFtkYXRhLXJvY2tldC1pbnNpZ2h0cy1pZD1cIiR7aW5zaWdodHNJZH1cIl1gKS5hZGRDbGFzcygnd3ByLXJpLWl0ZW0tLWV4cGFuZGVkJyk7XG5cblx0XHQvLyBUcmFjayBleHBhbmQgb25seSBleHBhbmQgbWV0cmljIGFjdGlvbi5cblx0XHRoYW5kbGVNZXRyaWNBY3Rpb25UcmFja2luZygnZXhwYW5kJywgaW5zaWdodHNJZCwgc291cmNlKTtcblxuXHRcdGlmIChpc0xhc3QpIHtcblx0XHRcdHVwZGF0ZVJvd1N0eWxpbmdGb3JMYXN0SXRlbSgpO1xuXHRcdH1cblx0fVxuXG5cdC8vIFRyYWNrcyB1c2VyIGludGVyYWN0aW9ucyB3aXRoIG1ldHJpYyBhY3Rpb25zIGluIFJvY2tldCBJbnNpZ2h0cyB2aWEgQUpBWC5cblx0ZnVuY3Rpb24gaGFuZGxlTWV0cmljQWN0aW9uVHJhY2tpbmcoZXZlbnQsIHJvd0lkLCBzb3VyY2UpIHtcblx0XHQkLnBvc3QoXG5cdFx0XHRhamF4dXJsLFxuXHRcdFx0e1xuXHRcdFx0XHRhY3Rpb246ICdyb2NrZXRfaW5zaWdodF90cmFja19tZXRyaWNfYWN0aW9ucycsXG5cdFx0XHRcdF9hamF4X25vbmNlOiByb2NrZXRfYWpheF9kYXRhLm5vbmNlLFxuXHRcdFx0XHRldmVudDogZXZlbnQsXG5cdFx0XHRcdHJvd19pZDogcm93SWQsXG5cdFx0XHRcdHNvdXJjZTogc291cmNlXG5cdFx0XHR9LFxuXHRcdFx0ZnVuY3Rpb24ocmVzcG9uc2UpIHtcblx0XHRcdFx0aWYgKCFyZXNwb25zZS5zdWNjZXNzKSB7XG5cdFx0XHRcdFx0Y29uc29sZS5lcnJvcignTWV0cmljIGFjdGlvbiB0cmFja2luZyBmYWlsZWQ6JywgcmVzcG9uc2U/LmRhdGEgfHwgcmVzcG9uc2UpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0KTtcblx0fVxuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSBib3JkZXIgc3R5bGluZyBmb3IgdGhlIGxhc3Qgcm93IGl0ZW0gaW4gdGhlIFJvY2tldCBJbnNpZ2h0cyB0YWJsZS5cblx0ICpcblx0ICogTWFuYWdlcyBib3JkZXIgcmFkaXVzIGFuZCBib3R0b20gYm9yZGVyIHN0eWxpbmcgYmFzZWQgb24gd2hldGhlciB0aGUgZGV0YWlsc1xuXHQgKiBjZWxsIGlzIGV4cGFuZGVkIG9yIGNvbGxhcHNlZCB0byBtYWludGFpbiBwcm9wZXIgdmlzdWFsIGFwcGVhcmFuY2UuXG5cdCAqL1xuXHRmdW5jdGlvbiB1cGRhdGVSb3dTdHlsaW5nRm9yTGFzdEl0ZW0oaXNFeHBhbmRlZCA9IHRydWUpIHtcblx0XHRjb25zdCBhZGRTdGF0ZSA9IGlzRXhwYW5kZWQgPyAnd3ByLWxhc3QtZXhwYW5kZWQnIDogJ3dwci1sYXN0LWNvbGxhcHNlZCc7XG5cdFx0Y29uc3QgcmVtb3ZlU3RhdGUgPSBpc0V4cGFuZGVkID8gJ3dwci1sYXN0LWNvbGxhcHNlZCcgOiAnd3ByLWxhc3QtZXhwYW5kZWQnO1xuXG5cdFx0dmFyICRzZWxlY3RvcnMgPSB7XG5cdFx0XHRsYXN0VG9nZ2xlOiAkKCcud3ByLXJpLWl0ZW0tdG9nZ2xlJykubGFzdCgpLFxuXHRcdFx0bGFzdEFjdGlvbnM6ICQoJy53cHItcmktaXRlbS1hY3Rpb25zJykubGFzdCgpXG5cdFx0fTtcblxuXHRcdCRzZWxlY3RvcnMubGFzdFRvZ2dsZVxuXHRcdFx0LnJlbW92ZUNsYXNzKHJlbW92ZVN0YXRlKVxuXHRcdFx0LmFkZENsYXNzKGFkZFN0YXRlKTtcblxuXHRcdCRzZWxlY3RvcnMubGFzdEFjdGlvbnNcblx0XHRcdC5yZW1vdmVDbGFzcyhyZW1vdmVTdGF0ZSlcblx0XHRcdC5hZGRDbGFzcyhhZGRTdGF0ZSk7XG5cblxuXHRcdC8vIENoZWNrIGlmIGxhc3QgZGV0YWlsIHJvdyBpcyBub3QgdGhlIGxhc3Qgcm93IGluIHRoZSB0YWJsZSBzbyBhcyBub3QgdG8gYXBwbHkgaW1wcm9wZXIgc3R5bGluZyB3aXRoIGJvcmRlciByYWRpdXMgYmV0d2VlbiByb3dzLlxuXHRcdHZhciAkbGFzdERldGFpbHNDZWxsID0gJCgnLmRldGFpbHMtc2VjdGlvbi10ZCcpLmxhc3QoKTtcblx0XHRpZiAoJGxhc3REZXRhaWxzQ2VsbC5jbG9zZXN0KCd0cicpLm5leHQoJ3RyJykubGVuZ3RoICE9PSAwKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0JGxhc3REZXRhaWxzQ2VsbC5yZW1vdmVDbGFzcyhyZW1vdmVTdGF0ZSlcblx0XHQuYWRkQ2xhc3MoYWRkU3RhdGUpO1xuXHR9XG5cblx0Ly8gVG9nZ2xlIHNpbmdsZSBpdGVtLlxuXHQkKGRvY3VtZW50KS5vbignY2xpY2snLCAnLndwci1yaS1pdGVtLXRvZ2dsZS1zaW5nbGUnLCBmdW5jdGlvbigpIHtcblx0XHR2YXIgaW5zaWdodHNJZCA9ICQodGhpcykuY2xvc2VzdCgnLndwci1yaS1pdGVtJykuZGF0YSgncm9ja2V0LWluc2lnaHRzLWlkJyk7XG5cdFx0dG9nZ2xlU2luZ2xlUm93VmlzaWJpbGl0eShpbnNpZ2h0c0lkLCAndXJsX2V4cGFuZCcpO1xuXHR9KTtcblxuXHQvLyBUb2dnbGUgYWxsIGl0ZW1zLlxuXHQkKGRvY3VtZW50KS5vbignY2xpY2snLCAnLndwci1yaS1pdGVtLXRvZ2dsZS1hbGwnLCBmdW5jdGlvbiAoKSB7XG5cdFx0aWYgKCQoJy53cHItcmktZGV0YWlscy0tZXhwYW5kZWQnKS5sZW5ndGggPiAwKSB7XG5cdFx0XHQkKCcud3ByLXJpLWRldGFpbHMnKS5yZW1vdmVDbGFzcygnd3ByLXJpLWRldGFpbHMtLWV4cGFuZGVkJyk7XG5cdFx0XHQkKCcud3ByLXJpLWl0ZW0nKS5yZW1vdmVDbGFzcygnd3ByLXJpLWl0ZW0tLWV4cGFuZGVkJyk7XG5cdFx0XHQkKHRoaXMpLnJlbW92ZUNsYXNzKCd3cHItcmktaXRlbS10b2dnbGUtYWxsLS1leHBhbmRlZCcpO1xuXHRcdFx0dXBkYXRlUm93U3R5bGluZ0Zvckxhc3RJdGVtKGZhbHNlKTtcblxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdCQoJy53cHItcmktZGV0YWlscycpLmFkZENsYXNzKCd3cHItcmktZGV0YWlscy0tZXhwYW5kZWQnKTtcblx0XHQkKCcud3ByLXJpLWl0ZW0nKS5hZGRDbGFzcygnd3ByLXJpLWl0ZW0tLWV4cGFuZGVkJyk7XG5cdFx0JCh0aGlzKS5hZGRDbGFzcygnd3ByLXJpLWl0ZW0tdG9nZ2xlLWFsbC0tZXhwYW5kZWQnKTtcblx0XHR1cGRhdGVSb3dTdHlsaW5nRm9yTGFzdEl0ZW0oKTtcblxuXHRcdC8vIFRyYWNrIHNpbmdsZSBleHBhbmQgZXZlbnQgZm9yIFwiRXhwYW5kIEFsbFwiIGFjdGlvbiB3aXRoIHRlc3RfaWQgYXMgJ2FsbCcuXG5cdFx0aGFuZGxlTWV0cmljQWN0aW9uVHJhY2tpbmcoJ2V4cGFuZCcsICdhbGwnLCAnZ2xvYmFsX2V4cGFuZCcpO1xuXHR9KTtcblxuXHQvLyBUcmFjayBcIlNlZSBHVG1ldHJpeCBSZXBvcnRcIiBjbGlja3MgaW4gUm9ja2V0IEluc2lnaHRzLlxuXHQkKGRvY3VtZW50KS5vbignY2xpY2snLCAnLndwci1yaS1yZXBvcnQnLCBmdW5jdGlvbihlKSB7XHQvLyBPbmx5IHRyYWNrIGlmIGxpbmsgaXMgbm90IGRpc2FibGVkIGFuZCBtaXhwYW5lbCBpcyBhdmFpbGFibGUuXG5cdFx0aWYgKCQodGhpcykuaGFzQ2xhc3MoJ3dwci1yaS1hY3Rpb24tLWRpc2FibGVkJykpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR2YXIgaW5zaWdodHNJZCA9ICQodGhpcykuZGF0YSgncm9ja2V0LWluc2lnaHRzLXJvdy1pZCcpO1xuXHRcdGhhbmRsZU1ldHJpY0FjdGlvblRyYWNraW5nKCdzZWVfcmVwb3J0JywgaW5zaWdodHNJZCwgJ3NlZV9yZXBvcnRfYnV0dG9uJyk7XG5cdH0pO1xuXG5cdC8vIFVwZGF0ZSB0YWJsZSBzdHlsaW5nIGFmdGVyIG5ldyBwYWdlIGlzIGFkZGVkLlxuXHQkKGRvY3VtZW50KS5vbigncm9ja2V0LWluc2lnaHRzLXBhZ2UtdGVzdC1jb21wbGV0ZWQnLCBmdW5jdGlvbiAoZSwgaW5zaWdodHNJZCkge1xuXHRcdC8vIEJhaWwgb3V0IGlmIHRoZXJlIGlzIG1vcmUgdGhhbiAxIHJlc3VsdC5cblx0XHRpZiAoJCgnLndwci1yaS1pdGVtLXJlc3VsdCcpLmxlbmd0aCA+IDEpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBSZW1vdmUgZHluYW1pYyBjbGFzcyB3aGVuIG9ubHkgb25lIGl0ZW0gZXhpc3QgaW4gdGFibGUuXG5cdFx0JCgnLndwci1sYXN0LWNvbGxhcHNlZCcpLnJlbW92ZUNsYXNzKCd3cHItbGFzdC1jb2xsYXBzZWQnKTtcblx0fSk7XG5cblx0Ly8gVXBkYXRlIHRhYmxlIHN0eWxpbmcgYWZ0ZXIgbmV3IHBhZ2UgaXMgYWRkZWQuXG5cdCQoZG9jdW1lbnQpLm9uKCdyb2NrZXQtaW5zaWdodHMtcGFnZS1hZGRlZCcsIGZ1bmN0aW9uIChlKSB7XG5cdFx0Ly8gUmVtb3ZlIGR5bmFtaWMgY2xhc3MgZm9yIGxhc3QgaXRlbSBpZiBleGlzdHMgd2hlbiBuZXcgcGFnZSBpcyBhZGRlZC5cblx0XHQkKCcud3ByLWxhc3QtY29sbGFwc2VkJykucmVtb3ZlQ2xhc3MoJ3dwci1sYXN0LWNvbGxhcHNlZCcpO1xuXHRcdCQoJy53cHItbGFzdC1leHBhbmRlZCcpLnJlbW92ZUNsYXNzKCd3cHItbGFzdC1leHBhbmRlZCcpO1xuXHRcdCQoJy5ib3JkZXItYm90dG9tJykucmVtb3ZlQ2xhc3MoJ2JvcmRlci1ib3R0b20nKTtcblx0fSk7XG5cblx0Ly8gVXBkYXRlIHRhYmxlIHN0eWxpbmcgYWZ0ZXIgcmV0ZXN0IG9yIHBvbGxpbmcgdXBkYXRlIGZvciBsYXN0IHJvdy5cblx0JChkb2N1bWVudCkub24oJ3JvY2tldC1pbnNpZ2h0cy1wYWdlLXJldGVzdCByb2NrZXQtaW5zaWdodHMtcGFnZS10ZXN0LXBvbGxpbmcnLCBmdW5jdGlvbiAoZSwgaW5zaWdodHNJZCkge1xuXHRcdC8vIENoZWNrIGlmIGl0ZW0gaXMgdGhlIGxhc3QuXG5cdFx0dmFyIGlzTGFzdCA9ICQoYFtkYXRhLXJvY2tldC1pbnNpZ2h0cy1pZD1cIiR7aW5zaWdodHNJZH1cIl1gKS5pcygkKCcud3ByLXJpLWl0ZW0tcmVzdWx0JykubGFzdCgpKTtcblxuXHRcdGlmIChpc0xhc3QpIHtcblx0XHRcdGFkZENvbGxhcHNlZFN0eWxpbmdUb0xhc3RSb3coKTtcblx0XHR9XG5cdH0pO1xuXG5cdCQoZG9jdW1lbnQpLm9uKCdyb2NrZXQtaW5zaWdodHMtcGFnZS1yZXRlc3QnLCBmdW5jdGlvbiAoZSwgaW5zaWdodHNJZCkge1xuXHRcdCQoYCNyaV9kZXRhaWxzXyR7aW5zaWdodHNJZH1gKS5yZW1vdmVDbGFzcygnd3ByLXJpLWRldGFpbHMtLWV4cGFuZGVkJyk7XG5cdFx0JChgW2RhdGEtcm9ja2V0LWluc2lnaHRzLWlkPVwiJHtpbnNpZ2h0c0lkfVwiXWApLnJlbW92ZUNsYXNzKCd3cHItcmktaXRlbS0tZXhwYW5kZWQnKTtcblx0fSk7XG5cblx0JCh3aW5kb3cpLmxvYWQoKCkgPT4ge1xuXHRcdGlmICggISBpc09uUm9ja2V0SW5zaWdodHMoKSApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBBZGQgY29sbGFwc2VkIHN0eWxpbmcgdG8gdGhlIGxhc3Qgcm93IG9uIGluaXRpYWwgbG9hZC5cblx0XHRhZGRDb2xsYXBzZWRTdHlsaW5nVG9MYXN0Um93KHRydWUpO1xuXG5cdFx0Ly8gU2V0IGluaXRpYWwgZXhwYW5kL2NvbGxhcHNlIHN0YXRlLlxuXHRcdGNvbnN0IHVybFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XG5cdFx0Y29uc3QgdGVzdElkID0gdXJsUGFyYW1zLmdldCgncmlfaWQnKTtcblxuXHRcdC8vIFNlbmQgbWl4cGFuZWwgZXZlbnQgZm9yIGF1dG8gZXhwYW5kZWQgcm93LlxuXHRcdGxldCBmaXJzdFJvd0lkID0gJCgnLndwci1yaS1pdGVtLS1leHBhbmRlZCcpPy5maXJzdCgpPy5kYXRhKCdyb2NrZXQtaW5zaWdodHMtaWQnKTtcblxuXHRcdC8vIENoZWNrIGlmIHJpX2lkIHdhcyBwYXNzZWQgaW4gcXVlcnkgc3RyaW5nIHRvIG9wZW4gc3BlY2lmaWMgdGVzdC5cblx0XHRpZiAoIXRlc3RJZCB8fCB0ZXN0SWQgPT09ICcnKSB7XG5cdFx0XHRpZiAoZmlyc3RSb3dJZCkge1xuXHRcdFx0XHRoYW5kbGVNZXRyaWNBY3Rpb25UcmFja2luZygnZXhwYW5kJywgZmlyc3RSb3dJZCwgJ2F1dG9fZXhwYW5kX3VybCcpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGhhbmRsZU1ldHJpY0FjdGlvblRyYWNraW5nKCdleHBhbmQnLCB0ZXN0SWQsICdwb3N0IHR5cGUgbGlzdGluZycpO1xuXG5cdFx0JCgnaHRtbCwgYm9keScpLmFuaW1hdGUoe1xuXHRcdFx0c2Nyb2xsVG9wOiAkKGBbZGF0YS1yb2NrZXQtaW5zaWdodHMtaWQ9XCIke3Rlc3RJZH1cIl1gKS5vZmZzZXQoKS50b3AgLSAxMDBcblx0XHR9LCA1MDApO1xuXG5cdFx0Ly8gUmVtb3ZlIHJpX2lkIGZyb20gVVJMIHdpdGhvdXQgcGFnZSByZWxvYWRcblx0XHR1cmxQYXJhbXMuZGVsZXRlKCdyaV9pZCcpO1xuXHRcdGNvbnN0IG5ld1VybCA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArICc/JyArIHVybFBhcmFtcy50b1N0cmluZygpICsgd2luZG93LmxvY2F0aW9uLmhhc2g7XG5cdFx0d2luZG93Lmhpc3RvcnkucmVwbGFjZVN0YXRlKHt9LCAnJywgbmV3VXJsKTtcblx0fSk7XG59KTtcbiIsIi8vIEFkZCBncmVlbnNvY2sgbGliIGZvciBhbmltYXRpb25zXHJcbmltcG9ydCAnLi4vbGliL2dyZWVuc29jay9Ud2VlbkxpdGUubWluLmpzJztcclxuaW1wb3J0ICcuLi9saWIvZ3JlZW5zb2NrL1RpbWVsaW5lTGl0ZS5taW4uanMnO1xyXG5pbXBvcnQgJy4uL2xpYi9ncmVlbnNvY2svZWFzaW5nL0Vhc2VQYWNrLm1pbi5qcyc7XHJcbmltcG9ydCAnLi4vbGliL2dyZWVuc29jay9wbHVnaW5zL0NTU1BsdWdpbi5taW4uanMnO1xyXG5pbXBvcnQgJy4uL2xpYi9ncmVlbnNvY2svcGx1Z2lucy9TY3JvbGxUb1BsdWdpbi5taW4uanMnO1xyXG5cclxuLy8gQWRkIHNjcmlwdHNcclxuaW1wb3J0ICcuLi9nbG9iYWwvY2RuLWRyaXZlci5qcyc7XHJcbmltcG9ydCAnLi4vZ2xvYmFsL3BhZ2VNYW5hZ2VyLmpzJztcclxuaW1wb3J0ICcuLi9nbG9iYWwvbWFpbi5qcyc7XHJcbmltcG9ydCAnLi4vZ2xvYmFsL2ZpZWxkcy5qcyc7XHJcbmltcG9ydCAnLi4vZ2xvYmFsL2JlYWNvbi5qcyc7XHJcbmltcG9ydCAnLi4vZ2xvYmFsL2FqYXguanMnO1xyXG5pbXBvcnQgJy4uL2dsb2JhbC9yZWNvbW1lbmRhdGlvbnMtd2lkZ2V0LmpzJztcclxuaW1wb3J0ICcuLi9nbG9iYWwvcm9ja2V0Y2RuLmpzJztcclxuaW1wb3J0ICcuLi9nbG9iYWwvcm9ja2V0Y2RuLXN1YnNjcmlwdGlvbi1wb2xsaW5nLmpzJztcclxuaW1wb3J0ICcuLi9nbG9iYWwvY291bnRkb3duLmpzJztcclxuaW1wb3J0ICcuLi9nbG9iYWwvbWl4cGFuZWwuanMnIiwidmFyICQgPSBqUXVlcnk7XG4kKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpe1xuICAgIGlmICgnQmVhY29uJyBpbiB3aW5kb3cpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNob3cgYmVhY29ucyBvbiBidXR0b24gXCJoZWxwXCIgY2xpY2tcbiAgICAgICAgICovXG4gICAgICAgIHZhciAkaGVscCA9ICQoJy53cHItaW5mb0FjdGlvbi0taGVscCcpO1xuICAgICAgICAkaGVscC5vbignY2xpY2snLCBmdW5jdGlvbihlKXtcbiAgICAgICAgICAgIHZhciBpZHMgPSAkKHRoaXMpLmF0dHIoJ2RhdGEtYmVhY29uLWlkJyk7XG4gICAgICAgICAgICB2YXIgYnV0dG9uID0gJCh0aGlzKS5kYXRhKCd3cHJfdHJhY2tfYnV0dG9uJykgfHwgJ0JlYWNvbiBIZWxwJztcbiAgICAgICAgICAgIHZhciBjb250ZXh0ID0gJCh0aGlzKS5kYXRhKCd3cHJfdHJhY2tfY29udGV4dCcpIHx8ICdTZXR0aW5ncyc7XG5cbiAgICAgICAgICAgIC8vIFRyYWNrIHdpdGggTWl4UGFuZWwgSlMgU0RLXG4gICAgICAgICAgICB3cHJUcmFja0hlbHBCdXR0b24oYnV0dG9uLCBjb250ZXh0KTtcblxuICAgICAgICAgICAgLy8gQ29udGludWUgd2l0aCBleGlzdGluZyBiZWFjb24gZnVuY3Rpb25hbGl0eVxuICAgICAgICAgICAgd3ByQ2FsbEJlYWNvbihpZHMpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9KTtcblxuICAgICAgICBmdW5jdGlvbiB3cHJDYWxsQmVhY29uKGFJRCl7XG4gICAgICAgICAgICBhSUQgPSBhSUQuc3BsaXQoJywnKTtcbiAgICAgICAgICAgIGlmICggYUlELmxlbmd0aCA9PT0gMCApIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoIGFJRC5sZW5ndGggPiAxICkge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuQmVhY29uKFwic3VnZ2VzdFwiLCBhSUQpO1xuXG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuQmVhY29uKFwib3BlblwiKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgMjAwKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuQmVhY29uKFwiYXJ0aWNsZVwiLCBhSUQudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgIH1cbiAgICB9XG5cblx0JCggJy53cHItcmktcmVwb3J0JyApLm9uKCAnY2xpY2snLCBmdW5jdGlvbigpIHtcblx0XHR3cHJUcmFja0hlbHBCdXR0b24oICdyb2NrZXQgaW5zaWdodHMgc2VlIGd0bWV0cml4IHJlcG9ydCcsICdwZXJmb3JtYW5jZSBzdW1tYXJ5JyApO1xuXHR9ICk7XG5cbiAgICAvLyBNaXhQYW5lbCB0cmFja2luZyBmdW5jdGlvblxuICAgIGZ1bmN0aW9uIHdwclRyYWNrSGVscEJ1dHRvbihidXR0b24sIGNvbnRleHQpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBtaXhwYW5lbCAhPT0gJ3VuZGVmaW5lZCcgJiYgbWl4cGFuZWwudHJhY2spIHtcbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHVzZXIgaGFzIG9wdGVkIGluIHVzaW5nIGxvY2FsaXplZCBkYXRhXG4gICAgICAgICAgICBpZiAodHlwZW9mIHJvY2tldF9taXhwYW5lbF9kYXRhID09PSAndW5kZWZpbmVkJyB8fCAhcm9ja2V0X21peHBhbmVsX2RhdGEub3B0aW5fZW5hYmxlZCB8fCByb2NrZXRfbWl4cGFuZWxfZGF0YS5vcHRpbl9lbmFibGVkID09PSAnMCcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIElkZW50aWZ5IHVzZXIgd2l0aCBoYXNoZWQgbGljZW5zZSBlbWFpbCBpZiBhdmFpbGFibGVcbiAgICAgICAgICAgIGlmIChyb2NrZXRfbWl4cGFuZWxfZGF0YS51c2VyX2lkICYmIHR5cGVvZiBtaXhwYW5lbC5pZGVudGlmeSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIG1peHBhbmVsLmlkZW50aWZ5KHJvY2tldF9taXhwYW5lbF9kYXRhLnVzZXJfaWQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBtaXhwYW5lbC50cmFjaygnQnV0dG9uIENsaWNrZWQnLCB7XG4gICAgICAgICAgICAgICAgJ2J1dHRvbic6IGJ1dHRvbixcblx0XHRcdFx0J2J1dHRvbl9jb250ZXh0JzogY29udGV4dCxcblx0XHRcdFx0J3BsdWdpbic6IHJvY2tldF9taXhwYW5lbF9kYXRhLnBsdWdpbixcbiAgICAgICAgICAgICAgICAnYnJhbmQnOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5icmFuZCxcbiAgICAgICAgICAgICAgICAnYXBwbGljYXRpb24nOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5hcHAsXG4gICAgICAgICAgICAgICAgJ2NvbnRleHQnOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5jb250ZXh0LFxuICAgICAgICAgICAgICAgICdwYXRoJzogcm9ja2V0X21peHBhbmVsX2RhdGEucGF0aCxcbiAgICAgICAgICAgICAgICAnaW50ZXJhY3Rpb25fY2hhbm5lbCc6ICdVSSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gTWFrZSBmdW5jdGlvbiBnbG9iYWxseSBhdmFpbGFibGVcbiAgICB3aW5kb3cud3ByVHJhY2tIZWxwQnV0dG9uID0gd3ByVHJhY2tIZWxwQnV0dG9uO1xufSk7XG4iLCIoICggZG9jdW1lbnQgKSA9PiB7XG5cdCd1c2Ugc3RyaWN0JztcblxuXHRmdW5jdGlvbiBub3RpZnlDZG5TdGF0ZUNoYW5nZSgpIHtcblx0XHRkb2N1bWVudC5kaXNwYXRjaEV2ZW50KCBuZXcgQ3VzdG9tRXZlbnQoICd3cHItY2RuLXN0YXRlLWNoYW5nZScgKSApO1xuXHR9XG5cblx0LyoqXG5cdCAqIEtlZXBzIHRoZSBoaWRkZW4gY2RuX3R5cGUgYW5kIGNkbl9zdGF0ZSBmb3JtIGlucHV0cyBpbiBzeW5jIGFmdGVyIGEgUkVTVC1kcml2ZW5cblx0ICogbW9kZSBjaGFuZ2Ugc28gYSBzdWJzZXF1ZW50IGZvcm0gc2F2ZSBkb2Vzbid0IHNlbmQgc3RhbGUgdmFsdWVzIGFuZCB0cmlnZ2VyXG5cdCAqIENkblN0YXRlQnJpZGdlOjpyZWNvbmNpbGUoKSB0byByZWNvbXB1dGUgdGhlIHdyb25nIHN0YXRlLlxuXHQgKlxuXHQgKiBNaXJyb3JzIHRoZSBtYXBwaW5nIGluIFJlc3Q6OmFwcGx5X2Nkbl9tb2RlKCk6XG5cdCAqICAgYnlvY2RuIOKGkiBjZG5fdHlwZT1ieW9jZG47IGV2ZXJ5dGhpbmcgZWxzZSDihpIgY2RuX3R5cGU9cm9ja2V0Y2RuLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gbW9kZSBOZXcgY2RuX3N0YXRlIHZhbHVlICgncm9ja2V0Y2RuX2ZyZWUnLCAnYnlvY2RuJywgJ25vdGhpbmcnLCBldGMuKS5cblx0ICovXG5cdGZ1bmN0aW9uIHN5bmNDZG5IaWRkZW5JbnB1dHMoIG1vZGUgKSB7XG5cdFx0Y29uc3Qgc3RhdGVJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnY2RuX3N0YXRlJyApO1xuXHRcdGlmICggc3RhdGVJbnB1dCApIHtcblx0XHRcdHN0YXRlSW5wdXQudmFsdWUgPSBtb2RlO1xuXHRcdH1cblxuXHRcdGNvbnN0IHR5cGVJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnY2RuX3R5cGUnICk7XG5cdFx0aWYgKCB0eXBlSW5wdXQgKSB7XG5cdFx0XHR0eXBlSW5wdXQudmFsdWUgPSAnYnlvY2RuJyA9PT0gbW9kZSA/ICdieW9jZG4nIDogJ3JvY2tldGNkbic7XG5cdFx0fVxuXG5cdFx0Y29uc3QgY2RuSW5wdXQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnaW5wdXRbdHlwZT1cImhpZGRlblwiXVtuYW1lPVwid3Bfcm9ja2V0X3NldHRpbmdzW2Nkbl1cIl0nICk7XG5cdFx0aWYgKCBjZG5JbnB1dCApIHtcblx0XHRcdGNkbklucHV0LnZhbHVlID0gJ25vdGhpbmcnID09PSBtb2RlID8gJzAnIDogJzEnO1xuXHRcdH1cblx0fVxuXG5cdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoICdET01Db250ZW50TG9hZGVkJywgKCkgPT4ge1xuXHRcdGluaXRDZG5Ecml2ZXJUYWJzKCk7XG5cdFx0aW5pdENkbk1vZGVUb2dnbGUoKTtcblx0XHRpbml0QWRkSG9tZXBhZ2UoKTtcblx0XHRpbml0QWRkUGFnZSgpO1xuXHRcdGluaXREZWxldGVQYWdlKCk7XG5cdFx0dXBkYXRlU3VibWl0QnV0dG9uU3RhdGVPblN1YnNjcmlwdGlvbkxvYWRpbmcoKTtcblx0fSApO1xuXG5cdGNvbnN0IGFkZEhvbWVCdXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnI3dwcl9hZGRfcGFnZV9jb21wb25lbnQgLndwci1jZG4tYWRkLXBhZ2VfX2hvbWVwYWdlJyApO1xuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSBzdGF0dXMgaW5kaWNhdG9yIGNvbXBvbmVudCB3aXRoIG5ldyBIVE1MIGNvbnRlbnQuXG5cdCAqXG5cdCAqIFRoZSBwYWlkIHRpZXIncyBpbmRpY2F0b3IgY2FycmllcyB0aGUgc2FtZSBgLnJvY2tldGNkbmAgY2xhc3MgaXRzIHNlY3Rpb25cblx0ICogaGVhZGVyIHVzZXMsIHNpbmNlIGl0IGhhcyBubyBzZXBhcmF0ZSBjb250ZW50IHdyYXBwZXIgb2YgaXRzIG93biAtIHNlZVxuXHQgKiBhZGRfcm9ja2V0Y2RuX3BhaWRfc2VjdGlvbigpIGluIENvbnRyb2xsZXIucGhwLiBUaGF0J3Mgd2hhdCBsZXRzXG5cdCAqIHRvZ2dsZURyaXZlclNlY3Rpb25zKCkgaGlkZSBpdCB3aGlsZSBcIk90aGVyIENETlwiIGlzIHRoZSBhY3RpdmUgdGFiLCBieVxuXHQgKiB0b2dnbGluZyBgd3ByLWlzSGlkZGVuYCBkaXJlY3RseSBvbiBpdC4gVGhlIHNlcnZlci1yZW5kZXJlZCByZXBsYWNlbWVudFxuXHQgKiBtYXJrdXAgaGFzIG5vIG5vdGlvbiBvZiB0aGF0IGNsaWVudC1vbmx5IHRhYiBzdGF0ZSwgc28gYSBwbGFpbiBvdXRlckhUTUxcblx0ICogc3dhcCB3b3VsZCBkcm9wIHRoZSBjbGFzcyBhbmQgbWFrZSBpdCBwb3AgdXAgb3V0c2lkZSBpdHMgdGFiIC0gY2FycnkgaXRcblx0ICogb3ZlciBleHBsaWNpdGx5IHdoZW4gcHJlc2VudC5cblx0ICpcblx0ICogQHBhcmFtIHtzdHJpbmd9IGh0bWwgLSBUaGUgSFRNTCBzdHJpbmcgdG8gcmVwbGFjZSB0aGUgc3RhdHVzIGluZGljYXRvciB3aXRoLlxuXHQgKiBAcmV0dXJucyB7dm9pZH1cblx0ICovXG5cdGZ1bmN0aW9uIHVwZGF0ZVN0YXR1c0luZGljYXRvckNvbXBvbmVudCggaHRtbCApIHtcblx0XHQvLyAjd3ByX2Nkbl9zdGF0dXNfaW5kaWNhdG9yIGlzIHNoYXJlZCBieSB0aGUgZnJlZSwgcGFpZCBBTkQgXCJZb3VyIENETlwiIChCWU9DRE4pXG5cdFx0Ly8gdGVtcGxhdGVzIC0gdGhlIGZyZWUgdGllciBhZGRpdGlvbmFsbHkgd3JhcHMgaXQgaW4gLndwci1jZG4tYnVpbHQtaW4sIHRoZSBwYWlkXG5cdFx0Ly8gdGllciBkb2VzIG5vdCwgYW5kIGJvdGggdGFiIHBhbmVscyBzdGF5IGluIHRoZSBET00gYXQgb25jZSAob25lIG1lcmVseSBoaWRkZW4pLFxuXHRcdC8vIHNvIGEgcGxhaW4gZ2V0RWxlbWVudEJ5SWQoKSBjYW4gc2lsZW50bHkgZ3JhYiB0aGUgQllPQ0ROIGNvcHkgaW5zdGVhZCBhbmQgaW5qZWN0XG5cdFx0Ly8gUm9ja2V0Q0ROJ3MgbWVzc2FnZSBpbnRvIHRoZSBcIk90aGVyIENETlwiIHRhYi4gRXhwbGljaXRseSBza2lwIGFueSBtYXRjaCB1bmRlclxuXHRcdC8vIC55b3VyLW93bi1jZG4gLSBzZWUgdXBkYXRlQnlvY2RuU3RhdHVzSW5kaWNhdG9yKCksIHdoaWNoIGV4Y2x1ZGVzIFJvY2tldENETidzXG5cdFx0Ly8gY29weSB0aGUgc2FtZSB3YXkgaW4gcmV2ZXJzZS5cblx0XHRjb25zdCBzdGF0dXNJbmRpY2F0b3IgPSBBcnJheS5mcm9tKCBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnI3dwcl9jZG5fc3RhdHVzX2luZGljYXRvcicgKSApXG5cdFx0XHQuZmluZCggKCBlbCApID0+ICEgZWwuY2xvc2VzdCggJy55b3VyLW93bi1jZG4nICkgKTtcblxuXHRcdGlmICggISBzdGF0dXNJbmRpY2F0b3IgKSB7XG5cdFx0XHRpZiAoIGh0bWwgKSB7XG5cdFx0XHRcdC8vIFJlLWluc2VydCB3aGVuIHRoZSBlbGVtZW50IHdhcyByZW1vdmVkIChlLmcuIGNvdW50IGRyb3BwZWQgYmFjayB0byAwIGFmdGVyXG5cdFx0XHRcdC8vIGFsbCBwYWdlcyB3ZXJlIGRlbGV0ZWQsIGFuZCB0aGUgaW5kaWNhdG9yIHdhcyByZW1vdmVkIHdoZW4gY291bnQgZmlyc3QgaGl0IDEpLlxuXHRcdFx0XHRjb25zdCBhZGRQYWdlU2VjdGlvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1idWlsdC1pbiAud3ByLWNkbi1hZGQtcGFnZScgKTtcblx0XHRcdFx0aWYgKCBhZGRQYWdlU2VjdGlvbiApIHtcblx0XHRcdFx0XHRhZGRQYWdlU2VjdGlvbi5pbnNlcnRBZGphY2VudEhUTUwoICdiZWZvcmViZWdpbicsIGh0bWwgKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGlmICggISBodG1sICkge1xuXHRcdFx0c3RhdHVzSW5kaWNhdG9yLnJlbW92ZSgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IHdhc0hpZGRlbiA9IHN0YXR1c0luZGljYXRvci5jbGFzc0xpc3QuY29udGFpbnMoICd3cHItaXNIaWRkZW4nICk7XG5cblx0XHRzdGF0dXNJbmRpY2F0b3Iub3V0ZXJIVE1MID0gaHRtbDtcblxuXHRcdGlmICggd2FzSGlkZGVuICkge1xuXHRcdFx0Ly8gU2FtZSBkdXBsaWNhdGUtaWQgY2F2ZWF0IGFzIGFib3ZlIC0gcmUtcnVuIHRoZSBzYW1lIGV4Y2x1c2lvbiBpbnN0ZWFkIG9mXG5cdFx0XHQvLyBnZXRFbGVtZW50QnlJZCgpLCB3aGljaCB3b3VsZCByZXR1cm4gdGhlIFwiWW91ciBDRE5cIiBjb3B5IGlmIGl0IHByZWNlZGVzXG5cdFx0XHQvLyB0aGlzIG9uZSBpbiBkb2N1bWVudCBvcmRlci5cblx0XHRcdGNvbnN0IHJlZnJlc2hlZCA9IEFycmF5LmZyb20oIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoICcjd3ByX2Nkbl9zdGF0dXNfaW5kaWNhdG9yJyApIClcblx0XHRcdFx0LmZpbmQoICggZWwgKSA9PiAhIGVsLmNsb3Nlc3QoICcueW91ci1vd24tY2RuJyApICk7XG5cblx0XHRcdGlmICggcmVmcmVzaGVkICkge1xuXHRcdFx0XHRyZWZyZXNoZWQuY2xhc3NMaXN0LmFkZCggJ3dwci1pc0hpZGRlbicgKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogVXBkYXRlcyB0aGUgXCJPdGhlciBDRE5cIiAoQllPQ0ROKSBzdGF0dXMgaW5kaWNhdG9yIHdpdGggbmV3IEhUTUwgY29udGVudC5cblx0ICpcblx0ICogU2NvcGVkIHRvIHRoZSBcIllvdXIgQ0ROXCIgc2VjdGlvbiBjb250YWluZXIgcmF0aGVyIHRoYW4gdGhlIHNoYXJlZFxuXHQgKiAjd3ByX2Nkbl9zdGF0dXNfaW5kaWNhdG9yIGlkLCBzaW5jZSB0aGF0IGlkIGNhbiBhbHNvIGJlIHByZXNlbnQgKGhpZGRlbilcblx0ICogaW4gdGhlIFJvY2tldENETiBzZWN0aW9uIG1hcmt1cCBhdCB0aGUgc2FtZSB0aW1lIC0gYSBnbG9iYWwgbG9va3VwIHdvdWxkXG5cdCAqIHJpc2sgdXBkYXRpbmcgdGhlIHdyb25nIG9uZS4gVW5saWtlIFJvY2tldENETidzIGluZGljYXRvciwgYW4gZW1wdHlcblx0ICogYGh0bWxgIGhlcmUgbWVhbnMgXCJubyBzdGF0dXMgbWVzc2FnZSBhdCBhbGxcIiwgc28gdGhlIGVsZW1lbnQgaXMgcmVtb3ZlZFxuXHQgKiByYXRoZXIgdGhhbiBsZWZ0IHVudG91Y2hlZCAtIGFsb25nIHdpdGggaXRzIGFkamFjZW50IHNlcGFyYXRvciwgd2hpY2hcblx0ICogdGhlIGluaXRpYWwgUEhQIHJlbmRlciAoeW91ci1vd24tY2RuLnBocCkgb25seSBkcmF3cyB3aGlsZSB0aGUgbWVzc2FnZVxuXHQgKiBpcyBzaG93aW5nLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gaHRtbCAtIFRoZSBzdGF0dXMgaW5kaWNhdG9yIEhUTUwgdG8gc2hvdywgb3IgYW4gZW1wdHkgc3RyaW5nIHRvIHNob3cgbm9uZS5cblx0ICogQHJldHVybnMge3ZvaWR9XG5cdCAqL1xuXHRmdW5jdGlvbiB1cGRhdGVCeW9jZG5TdGF0dXNJbmRpY2F0b3IoIGh0bWwgKSB7XG5cdFx0Y29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItZmllbGRzQ29udGFpbmVyLWZpZWxkc2V0LnlvdXItb3duLWNkbicgKTtcblxuXHRcdGlmICggISBjb250YWluZXIgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Y29uc3QgZXhpc3RpbmcgPSBjb250YWluZXIucXVlcnlTZWxlY3RvciggJyN3cHJfY2RuX3N0YXR1c19pbmRpY2F0b3InICk7XG5cdFx0Y29uc3Qgc2VwYXJhdG9yID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1idWlsdC1pbl9fc2VwYXJhdG9yJyApO1xuXG5cdFx0aWYgKCBleGlzdGluZyApIHtcblx0XHRcdGlmICggaHRtbCApIHtcblx0XHRcdFx0ZXhpc3Rpbmcub3V0ZXJIVE1MID0gaHRtbDtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGV4aXN0aW5nLnJlbW92ZSgpO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAoIGh0bWwgKSB7XG5cdFx0XHRjb250YWluZXIuaW5zZXJ0QWRqYWNlbnRIVE1MKCAnYWZ0ZXJiZWdpbicsIGh0bWwgKTtcblx0XHR9XG5cblx0XHRpZiAoICEgaHRtbCApIHtcblx0XHRcdGlmICggc2VwYXJhdG9yICkge1xuXHRcdFx0XHRzZXBhcmF0b3IucmVtb3ZlKCk7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRpZiAoICEgc2VwYXJhdG9yICkge1xuXHRcdFx0Y29uc3QgaW5kaWNhdG9yID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoICcjd3ByX2Nkbl9zdGF0dXNfaW5kaWNhdG9yJyApO1xuXG5cdFx0XHRpZiAoIGluZGljYXRvciApIHtcblx0XHRcdFx0aW5kaWNhdG9yLmluc2VydEFkamFjZW50SFRNTCggJ2FmdGVyZW5kJywgJzxkaXYgY2xhc3M9XCJ3cHItY2RuLWJ1aWx0LWluX19zZXBhcmF0b3JcIj48L2Rpdj4nICk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFRvZ2dsZXMgdGhlIGRpc2FibGVkIHN0YXRlIG9mIENETi1yZWxhdGVkIFVJIGVsZW1lbnRzIGJhc2VkIG9uIHRoZSBhY3RpdmUgZHJpdmVyLlxuXHQgKlxuXHQgKiBGb3IgdGhlICdyb2NrZXRjZG4nIGRyaXZlciwgdGFyZ2V0cyBib3RoIHNoYXJlZCBDRE4gYW5kIFJvY2tldENETiBzZWN0aW9ucy5cblx0ICogRm9yIGFsbCBvdGhlciBkcml2ZXJzLCBvbmx5IHRhcmdldHMgdGhlIHNoYXJlZCBDRE4gc2VjdGlvbiBhbmQgYWx3YXlzIGVuYWJsZXMgaXQuXG5cdCAqXG5cdCAqIEBwYXJhbSB7c3RyaW5nfSAgZHJpdmVyICAgVGhlIENETiBkcml2ZXIgaWRlbnRpZmllciAoZS5nLiAncm9ja2V0Y2RuJykuXG5cdCAqIEBwYXJhbSB7Ym9vbGVhbn0gZGlzYWJsZWQgV2hldGhlciB0byBkaXNhYmxlIHRoZSBDRE4gVUkgZWxlbWVudHMuXG5cdCAqL1xuXHRmdW5jdGlvbiB1cGRhdGVSb2NrZXRDRE5FbGVtZW50c1N0YXRlKCBkcml2ZXIsIGRpc2FibGVkICkge1xuXHRcdGlmICggJ3JvY2tldGNkbicgPT09IGRyaXZlciApIHtcblx0XHRcdGlmICggISBkaXNhYmxlZCApIHtcblx0XHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCggJy5jZG4tc2hhcmVkLXNlY3Rpb24sIC5yb2NrZXRjZG4tc2hhcmVkLXNlY3Rpb24nICkuZm9yRWFjaCggKCBlbCApID0+IHtcblx0XHRcdFx0XHRlbC5jbGFzc0xpc3QucmVtb3ZlKCAnd3ByLWNkbi1kaXNhYmxlZCcgKTtcblx0XHRcdFx0fSApO1xuXG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCggJy5jZG4tc2hhcmVkLXNlY3Rpb24sIC5yb2NrZXRjZG4tc2hhcmVkLXNlY3Rpb24nICkuZm9yRWFjaCggKCBlbCApID0+IHtcblx0XHRcdFx0ZWwuY2xhc3NMaXN0LmFkZCggJ3dwci1jZG4tZGlzYWJsZWQnICk7XG5cdFx0XHR9ICk7XG5cblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnLmNkbi1zaGFyZWQtc2VjdGlvbicgKS5mb3JFYWNoKCAoIGVsICkgPT4ge1xuXHRcdFx0ZWwuY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1jZG4tZGlzYWJsZWQnICk7XG5cdFx0fSApO1xuXHR9XG5cblx0LyoqXG5cdCAqIFNob3dzIG9yIGhpZGVzIHRoZSBsaW1pdC1yZWFjaGVkIHRvb2x0aXAgb24gdGhlIEFERCBQQUdFIGJ1dHRvbi5cblx0ICpcblx0ICogQHBhcmFtIHtib29sZWFufSBsaW1pdFJlYWNoZWQgV2hldGhlciB0aGUgZnJlZS10aWVyIHBhZ2UgbGltaXQgaGFzIGJlZW4gcmVhY2hlZC5cblx0ICogQHJldHVybnMge3ZvaWR9XG5cdCAqL1xuXHRmdW5jdGlvbiB1cGRhdGVUb29sdGlwU3RhdGUoIGxpbWl0UmVhY2hlZCApIHtcblx0XHRjb25zdCB0b29sdGlwID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWFkZC1wYWdlX19idXR0b24td3JhcHBlciAud3ByLXRvb2x0aXAnICk7XG5cdFx0aWYgKCB0b29sdGlwICkge1xuXHRcdFx0dG9vbHRpcC5jbGFzc0xpc3QudG9nZ2xlKCAnd3ByLWlzSGlkZGVuJywgISBsaW1pdFJlYWNoZWQgKTtcblx0XHR9XG5cdH1cblxuXHQvKiogUGVuZGluZyBiYW5uZXIgYXV0by1leHBhbmQgdGltZXIgSUQsIG9yIG51bGwgd2hlbiBubyB0aW1lciBpcyBhY3RpdmUuICovXG5cdGxldCBhdXRvRXhwYW5kVGltZXIgPSBudWxsO1xuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSBSb2NrZXRDRE4gQ1RBIHZpc2liaWxpdHkgYW5kIGV4cGFuc2lvbiBzdGF0ZS5cblx0ICpcblx0ICogV2hlbiB0aGUgcGFnZSBjb3VudCByZWFjaGVzIHRoZSBsaW1pdCwgZXhwYW5zaW9uIGlzIGRlZmVycmVkIGJ5IDE1IHNlY29uZHMgc28gdGhlXG5cdCAqIHVzZXIgaGFzIHRpbWUgdG8gcmVhY3QgYmVmb3JlIHRoZSB1cHNlbGwgYmFubmVyIG9wZW5zLiBBbnkgaW4tZmxpZ2h0IHRpbWVyIGlzXG5cdCAqIGNhbmNlbGxlZCB3aGVuZXZlciB0aGlzIGZ1bmN0aW9uIGlzIGNhbGxlZCAoZS5nLiBvbiBwYWdlIGRlbGV0aW9uKSwgZW5zdXJpbmcgc3RhbGVcblx0ICogZXhwYW5kcyBuZXZlciBmaXJlIGFmdGVyIHRoZSBzdGF0ZSBoYXMgY2hhbmdlZC5cblx0ICpcblx0ICogQHBhcmFtIHtudW1iZXJ9IGNvdW50IEN1cnJlbnQgbnVtYmVyIG9mIGZyZWUtdGllciBwYWdlcy5cblx0ICogQHBhcmFtIHtudW1iZXJ9IGxpbWl0IEZyZWUtdGllciBwYWdlIGxpbWl0LlxuXHQgKiBAcmV0dXJucyB7dm9pZH1cblx0ICovXG5cdGZ1bmN0aW9uIHVwZGF0ZVJvY2tldEN0YVN0YXRlKCBjb3VudCwgbGltaXQgKSB7XG5cdFx0Y29uc3QgY3RhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoICd3cHItcm9ja2V0Y2RuLWN0YScgKTtcblx0XHRjb25zdCByZXNlbGxlckJhbm5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnd3ByLXJvY2tldGNkbi1yZXNlbGxlci1saW1pdC1jdGEnICk7XG5cblx0XHRpZiAoICEgY3RhICYmICEgcmVzZWxsZXJCYW5uZXIgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gQ2FuY2VsIGFueSBwZW5kaW5nIGV4cGFuZCDigJQgc3RhdGUgaGFzIGNoYW5nZWQuXG5cdFx0aWYgKCBhdXRvRXhwYW5kVGltZXIgIT09IG51bGwgKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQoIGF1dG9FeHBhbmRUaW1lciApO1xuXHRcdFx0YXV0b0V4cGFuZFRpbWVyID0gbnVsbDtcblx0XHR9XG5cblx0XHRjb25zdCBhdExpbWl0ICA9IGNvdW50ID49IGxpbWl0O1xuXG5cdFx0aWYgKCBjdGEgKSB7XG5cdFx0XHRjdGEuY2xhc3NMaXN0LnRvZ2dsZSggJ3dwci1pc0hpZGRlbicsIGNvdW50ID09PSAwICk7XG5cdFx0fVxuXG5cdFx0aWYgKCByZXNlbGxlckJhbm5lciApIHtcblx0XHRcdHJlc2VsbGVyQmFubmVyLmNsYXNzTGlzdC50b2dnbGUoICd3cHItaXNIaWRkZW4nLCAhIGF0TGltaXQgKTtcblx0XHR9XG5cblx0XHRpZiAoIGN0YSApIHtcblx0XHRcdGlmICggYXRMaW1pdCApIHtcblx0XHRcdFx0Ly8gQWx3YXlzIHNob3cgXCJOaWNlIHdvcmshXCIgdGV4dCBpbW1lZGlhdGVseS5cblx0XHRcdFx0Y3RhLmNsYXNzTGlzdC5hZGQoICd3cHItcm9ja2V0Y2RuLWN0YS0tLW1heC1saW1pdCcgKTtcblxuXHRcdFx0XHRpZiAoICEgY3RhLmNsYXNzTGlzdC5jb250YWlucyggJ3dwci1yb2NrZXRjZG4tY3RhLS1leHBhbmRlZCcgKSApIHtcblx0XHRcdFx0XHQvLyBCYW5uZXIgaXMgY29sbGFwc2VkIOKAlCBrZWVwIGl0IGNvbGxhcHNlZCBmb3IgMTVzIHRoZW4gZXhwYW5kLlxuXHRcdFx0XHRcdGN0YS5jbGFzc0xpc3QuYWRkKCAnd3ByLXJvY2tldGNkbi1jdGEtLWNvbGxhcHNlZCcgKTtcblx0XHRcdFx0XHRjdGEuY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1yb2NrZXRjZG4tY3RhLS1leHBhbmRlZCcgKTtcblxuXHRcdFx0XHRcdGF1dG9FeHBhbmRUaW1lciA9IHNldFRpbWVvdXQoICgpID0+IHtcblx0XHRcdFx0XHRcdGF1dG9FeHBhbmRUaW1lciA9IG51bGw7XG5cdFx0XHRcdFx0XHRjdGEuY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1yb2NrZXRjZG4tY3RhLS1jb2xsYXBzZWQnICk7XG5cdFx0XHRcdFx0XHRjdGEuY2xhc3NMaXN0LmFkZCggJ3dwci1yb2NrZXRjZG4tY3RhLS1leHBhbmRlZCcgKTtcblx0XHRcdFx0XHRcdGRvY3VtZW50LmRpc3BhdGNoRXZlbnQoIG5ldyBDdXN0b21FdmVudCggJ3JvY2tldENETkJhbm5lckF1dG9FeHBhbmRlZCcgKSApO1xuXHRcdFx0XHRcdH0sIDE1MDAwICk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGN0YS5jbGFzc0xpc3QudG9nZ2xlKCAnd3ByLXJvY2tldGNkbi1jdGEtLWNvbGxhcHNlZCcsIGNvdW50ID4gMCApO1xuXHRcdFx0XHRjdGEuY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1yb2NrZXRjZG4tY3RhLS1leHBhbmRlZCcsICd3cHItcm9ja2V0Y2RuLWN0YS0tLW1heC1saW1pdCcgKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvLyBDYW5jZWwgYW55IHBlbmRpbmcgYmFubmVyIGV4cGFuZCB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcyBhd2F5IGZyb20gdGhlIENETiB0YWIuXG5cdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoICdyb2NrZXRKc0FmdGVyUGFnZU5hdmlnYXRpb24nLCAoIGUgKSA9PiB7XG5cdFx0aWYgKCBlLmRldGFpbC5wYWdlSWQgIT09ICdwYWdlX2NkbicgJiYgYXV0b0V4cGFuZFRpbWVyICE9PSBudWxsICkge1xuXHRcdFx0Y2xlYXJUaW1lb3V0KCBhdXRvRXhwYW5kVGltZXIgKTtcblx0XHRcdGF1dG9FeHBhbmRUaW1lciA9IG51bGw7XG5cdFx0fVxuXHR9ICk7XG5cblx0LyoqXG5cdCAqIExpc3RlbnMgZm9yIGN1c3RvbSAncm9ja2V0SnNBZnRlclBhZ2VOYXZpZ2F0aW9uJyBldmVudCB0byB1cGRhdGUgdGhlIHN0YXRlIG9mIHRoZSBzdWJtaXQgYnV0dG9uXG5cdCAqIGJhc2VkIG9uIHRoZSBwcmVzZW5jZSBvZiBhIENETiBzdWJzY3JpcHRpb24gbG9hZGluZyBpbmRpY2F0b3Igb24gdGhlIENETiBzZXR0aW5ncyBwYWdlLlxuXHQgKlxuXHQgKiBEaXNhYmxlcyB0aGUgc3VibWl0IGJ1dHRvbiB3aGVuIG5hdmlnYXRpbmcgdG8gdGhlIENETiBwYWdlIGlmIGEgc3Vic2NyaXB0aW9uIGxvYWRpbmcgaW5kaWNhdG9yIGlzIHByZXNlbnQsXG5cdCAqIGFuZCByZS1lbmFibGVzIGl0IHdoZW4gbmF2aWdhdGluZyBhd2F5IGZyb20gdGhlIENETiBwYWdlLlxuXHQgKi9cblx0ZnVuY3Rpb24gdXBkYXRlU3VibWl0QnV0dG9uU3RhdGVPblN1YnNjcmlwdGlvbkxvYWRpbmcoKSB7XG5cdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciggJ3JvY2tldEpzQWZ0ZXJQYWdlTmF2aWdhdGlvbicsICggZSApID0+IHtcblx0XHRcdC8vIEJhaWwgb3V0IGlmIHN1Ym1pdCBidXR0b24gaXMgbm90IHZpc2libGUgZm9yIHRoZSBjdXJyZW50IHBhZ2UuXG5cdFx0XHRpZiAoZ2V0Q29tcHV0ZWRTdHlsZSggZS5kZXRhaWwuc3VibWl0QnV0dG9uICkuZGlzcGxheSA9PT0gJ25vbmUnKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgY2xhc3NlcyA9IFtcblx0XHRcdFx0Jy53cHItaWNvbi1vcmFuZ2UtbG9hZGVyJyxcblx0XHRcdFx0Jy53cHItY2RuLWJ1aWx0LWluLS1kaXNhYmxlZCcsXG5cdFx0XHRdO1xuXG5cdFx0XHRjb25zdCBhbGxQcmVzZW50ID0gY2xhc3Nlcy5ldmVyeSggY2xzID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIGNscyApICE9PSBudWxsICk7XG5cblx0XHRcdC8vIFJlLWVuYWJsZSBzdWJtaXQgYnV0dG9uIHdoZW4gcGFnZSBpcyBub3QgY2RuIGFuZCBiYWlsIG91dC5cblx0XHRcdGlmIChlLmRldGFpbC5wYWdlSWQgIT09ICdwYWdlX2NkbicpIHtcblx0XHRcdFx0aWYgKGUuZGV0YWlsLnN1Ym1pdEJ1dHRvbi5jbGFzc0xpc3QuY29udGFpbnMoICd3cHItY2RuLWRpc2FibGVkJyApKSB7XG5cdFx0XHRcdFx0ZS5kZXRhaWwuc3VibWl0QnV0dG9uLmNsYXNzTGlzdC5yZW1vdmUoICd3cHItY2RuLWRpc2FibGVkJyApO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBCYWlsIG91dCBpZiBubyBjZG4gc3Vic2NyaXB0aW9uIGxvYWRlciBpcyBwcmVzZW50LlxuXHRcdFx0aWYgKCAhIGFsbFByZXNlbnQgKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Ly8gRGlzYWJsZSBzdWJtaXQgYnV0dG9uIHdoZW4gb24gY2RuIHBhZ2UgYW5kIHN1YnNjcmlwdGlvbiBsb2FkZXIgaXMgcHJlc2VudC5cblx0XHRcdGUuZGV0YWlsLnN1Ym1pdEJ1dHRvbi5jbGFzc0xpc3QuYWRkKCAnd3ByLWNkbi1kaXNhYmxlZCcgKTtcblx0XHR9ICk7XG5cdH1cblxuXHRmdW5jdGlvbiBzZXRTdWJzY3JpcHRpb25Mb2FkaW5nU3RhdGUoKSB7XG5cdFx0Y29uc3QgYnVpbHRJbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1idWlsdC1pbicgKTtcblxuXHRcdGlmICggYnVpbHRJbiApIHtcblx0XHRcdGJ1aWx0SW4uY2xhc3NMaXN0LmFkZCggJ3dwci1jZG4tYnVpbHQtaW4tLWRpc2FibGVkJyApO1xuXHRcdH1cblxuXHRcdC8vIERpc2FibGUgcHVyZ2UgQ0ROIGNhY2hlIHNlY3Rpb24uXG5cdFx0Y29uc3QgcHVyZ2VTZWN0aW9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLXB1cmdlLnJvY2tldGNkbicgKTtcblxuXHRcdGlmICggcHVyZ2VTZWN0aW9uICkge1xuXHRcdFx0cHVyZ2VTZWN0aW9uLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWRpc2FibGVkJyApO1xuXHRcdH1cblxuXHRcdC8vIERpc2FibGUgZXhjbHVzaW9uIGZpZWxkcyBhbmQgc2VjdGlvbiBoZWFkZXIuXG5cdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCggJy53cHItY2RuLWV4Y2x1c2lvbnMnICkuZm9yRWFjaCggKCBlbCApID0+IHtcblx0XHRcdGVsLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWRpc2FibGVkJyApO1xuXG5cdFx0XHRjb25zdCB0ZXh0YXJlYSA9IGVsLnF1ZXJ5U2VsZWN0b3IoICd0ZXh0YXJlYScgKTtcblxuXHRcdFx0aWYgKCB0ZXh0YXJlYSApIHtcblx0XHRcdFx0dGV4dGFyZWEuZGlzYWJsZWQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH0gKTtcblxuXHRcdGNvbnN0IHN1Ym1pdEJ1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcjd3ByLW9wdGlvbnMtc3VibWl0JyApO1xuXHRcdGlmICggc3VibWl0QnV0dG9uICkge1xuXHRcdFx0c3VibWl0QnV0dG9uLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWRpc2FibGVkJyApO1xuXHRcdH1cblxuXHRcdC8vIERpc2FibGUgbW9kZSB0b2dnbGVzIHRvIHByZXZlbnQgc3RhdGUgY2hhbmdlcyBkdXJpbmcgc3Vic2NyaXB0aW9uIGNyZWF0aW9uLlxuXHRcdGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoICcud3ByLWNkbi1tb2RlLXRvZ2dsZV9faW5wdXQnICkuZm9yRWFjaCggKCBtb2RlVG9nZ2xlICkgPT4ge1xuXHRcdFx0bW9kZVRvZ2dsZS5kaXNhYmxlZCA9IHRydWU7XG5cdFx0fSApO1xuXG5cdFx0Ly8gQ3JlYXRlIHBvbGxpbmcgbWVjaGFuaXNtIHRvIHNlbmQgYSByZXF1ZXN0IGV2ZXJ5IDEwIHNlY29uZHMgdG8gZ2V0IHRoZSBzdWJzY3JpcHRpb24gc3RhdHVzIGFuZCBvbmNlIHRoZSBzdWJzY3JpcHRpb24gaXMgYWN0aXZlLCB3ZSB3aWxsIHJlZnJlc2ggdGhlIHBhZ2UgZm9yIG5vdy5cblx0XHRkb2N1bWVudC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncm9ja2V0Q0ROU3Vic2NyaXB0aW9uTG9hZGluZycsIHt9KSk7XG5cdH1cblxuXHQvKipcblx0ICogVXBkYXRlcyB0aGUgYHdwci1jZG4tYWN0aXZlLWluZGljYXRvcmAgY2xhc3MgdG8gcmVmbGVjdCB3aGljaCBDRE4gZHJpdmVyIGhlYWRlclxuXHQgKiBhbmQgdGFiIGFyZSBhY3RpdmUuXG5cdCAqXG5cdCAqIEBwYXJhbSB7RWxlbWVudHxudWxsfSBhY3RpdmVUb2dnbGUgVG9nZ2xlIHdob3NlIHBhcmVudCBoZWFkZXIgYW5kIG1hdGNoaW5nIHRhYiBzaG91bGRcblx0ICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWNlaXZlIHRoZSBjbGFzcywgb3IgbnVsbCB0byBjbGVhciBhbGwuXG5cdCAqL1xuXHRmdW5jdGlvbiB1cGRhdGVDZG5BY3RpdmVJbmRpY2F0b3IoIGFjdGl2ZVRvZ2dsZSApIHtcblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnLndwci1jZG4tYWN0aXZlLWluZGljYXRvcicgKS5mb3JFYWNoKCAoIGVsICkgPT4ge1xuXHRcdFx0ZWwuY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1jZG4tYWN0aXZlLWluZGljYXRvcicgKTtcblx0XHR9ICk7XG5cblx0XHRpZiAoIGFjdGl2ZVRvZ2dsZSApIHtcblx0XHRcdGNvbnN0IGhlYWRlciA9IGFjdGl2ZVRvZ2dsZS5jbG9zZXN0KCAnLndwci1vcHRpb25IZWFkZXInICk7XG5cdFx0XHRpZiAoIGhlYWRlciApIHtcblx0XHRcdFx0aGVhZGVyLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWFjdGl2ZS1pbmRpY2F0b3InICk7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IG1vZGUgPSBhY3RpdmVUb2dnbGUuZ2V0QXR0cmlidXRlKCAnZGF0YS1jZG4tbW9kZScgKTtcblx0XHRcdGNvbnN0IHRhYkRyaXZlciA9ICdieW9jZG4nID09PSBtb2RlID8gJ3lvdXItb3duLWNkbicgOiAncm9ja2V0Y2RuJztcblx0XHRcdGNvbnN0IHRhYiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoIGAud3ByLWNkbi10YWJzX190YWJbZGF0YS1jZG4tZHJpdmVyPVwiJHsgdGFiRHJpdmVyIH1cIl1gICk7XG5cblx0XHRcdGlmICggdGFiICkge1xuXHRcdFx0XHR0YWIuY2xhc3NMaXN0LmFkZCggJ3dwci1jZG4tYWN0aXZlLWluZGljYXRvcicgKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogVXBkYXRlcyB0aGUgdG9nZ2xlIGNoZWNrYm94ZXMgYW5kIGFjdGl2ZSBpbmRpY2F0b3JzIHRvIHJlZmxlY3QgUm9ja2V0Q0ROIEZyZWVcblx0ICogaGF2aW5nIGp1c3QgYmVlbiBhY3RpdmF0ZWQgc2VydmVyLXNpZGUgKGF1dG8tYWN0aXZhdGlvbiBmcm9tIHRoZSBcIm5vdGhpbmcgYWN0aXZlXCJcblx0ICogc3RhdGUsIG9yIGFmdGVyIGEgY29uZmlybWVkIGFjdGl2YXRpb24gcHJvbXB0KSwgd2l0aG91dCBhIGZ1bGwgcGFnZSByZWxvYWQuXG5cdCAqL1xuXHRmdW5jdGlvbiBhY3RpdmF0ZUZyZWVNb2RlVUkoKSB7XG5cdFx0Y29uc3QgZnJlZVRvZ2dsZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1tb2RlLXRvZ2dsZV9faW5wdXRbZGF0YS1jZG4tbW9kZT1cInJvY2tldGNkbl9mcmVlXCJdJyApO1xuXG5cdFx0aWYgKCAhIGZyZWVUb2dnbGUgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCggJy53cHItY2RuLW1vZGUtdG9nZ2xlX19pbnB1dCcgKS5mb3JFYWNoKCAoIG90aGVyICkgPT4ge1xuXHRcdFx0b3RoZXIuY2hlY2tlZCA9ICggb3RoZXIgPT09IGZyZWVUb2dnbGUgKTtcblx0XHR9ICk7XG5cblx0XHR1cGRhdGVDZG5BY3RpdmVJbmRpY2F0b3IoIGZyZWVUb2dnbGUgKTtcblx0XHR0b2dnbGVEcml2ZXJTZWN0aW9ucyggJ3JvY2tldGNkbicgKTtcblx0XHRzZXRBY3RpdmVUYWIoICdyb2NrZXRjZG4nICk7XG5cdFx0bm90aWZ5Q2RuU3RhdGVDaGFuZ2UoKTtcblx0XHRzeW5jQ2RuSGlkZGVuSW5wdXRzKCAncm9ja2V0Y2RuX2ZyZWUnICk7XG5cdH1cblxuXHQvKipcblx0ICogSW5pdGlhbGl6ZXMgdGhlIENETiBtb2RlIHRvZ2dsZSBjaGVja2JveGVzLlxuXHQgKlxuXHQgKiBDaGVja2luZyBhY3RpdmF0ZXMgdGhhdCBtb2RlOyB1bmNoZWNraW5nIGxlYXZlcyBhbGwgbW9kZXMgaW5hY3RpdmUgKCdub3RoaW5nJykuXG5cdCAqIE9ubHkgb25lIG1vZGUgY2FuIGJlIGFjdGl2ZSBhdCBhIHRpbWUg4oCUIGNoZWNraW5nIG9uZSB1bmNoZWNrcyB0aGUgb3RoZXJzLlxuXHQgKiBUaGUgcmVxdWVzdCBmaXJlcyBpbW1lZGlhdGVseSBvbiB0b2dnbGUgY2hhbmdlLlxuXHQgKi9cblx0ZnVuY3Rpb24gaW5pdENkbk1vZGVUb2dnbGUoKSB7XG5cdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciggJ2NoYW5nZScsICggZXZlbnQgKSA9PiB7XG5cdFx0XHRjb25zdCB0b2dnbGUgPSBldmVudC50YXJnZXQuY2xvc2VzdCggJy53cHItY2RuLW1vZGUtdG9nZ2xlX19pbnB1dCcgKTtcblxuXHRcdFx0aWYgKCAhIHRvZ2dsZSApIHtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHRjb25zdCBtb2RlID0gdG9nZ2xlLmdldEF0dHJpYnV0ZSggJ2RhdGEtY2RuLW1vZGUnICk7XG5cblx0XHRcdGlmICggISBtb2RlICkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdC8vIFRoZSBjaGVja2JveCBoYXMgYWxyZWFkeSBmbGlwcGVkIGJ5IHRoZSB0aW1lIGBjaGFuZ2VgIGZpcmVzIC0gY2FwdHVyZSB0aGVcblx0XHRcdC8vIHJlcXVlc3RlZCBzdGF0ZSwgdGhlbiBob2xkIHRoZSB0b2dnbGUgYXQgaXRzIHByZXZpb3VzIHN0YXRlIGFuZCBkaXNhYmxlZFxuXHRcdFx0Ly8gdW50aWwgdGhlIHJlcXVlc3QgcmVzb2x2ZXMsIHNvIG5vdGhpbmcgYWJvdXQgaXQgY2hhbmdlcyBwcmVtYXR1cmVseS5cblx0XHRcdGNvbnN0IHJlcXVlc3RlZENoZWNrZWQgPSB0b2dnbGUuY2hlY2tlZDtcblx0XHRcdGNvbnN0IHJlcXVlc3RlZE1vZGUgICAgPSByZXF1ZXN0ZWRDaGVja2VkID8gbW9kZSA6ICdub3RoaW5nJztcblx0XHRcdGNvbnN0IHNlY3Rpb25Ecml2ZXIgICAgPSAnYnlvY2RuJyA9PT0gbW9kZSA/ICd5b3VyLW93bi1jZG4nIDogJ3JvY2tldGNkbic7XG5cdFx0XHRjb25zdCB0b2dnbGVXcmFwcGVyICAgID0gdG9nZ2xlLmNsb3Nlc3QoICcud3ByLWNkbi1tb2RlLXRvZ2dsZScgKTtcblxuXHRcdFx0dG9nZ2xlLmNoZWNrZWQgID0gISByZXF1ZXN0ZWRDaGVja2VkO1xuXHRcdFx0dG9nZ2xlLmRpc2FibGVkID0gdHJ1ZTtcblxuXHRcdFx0aWYgKCB0b2dnbGVXcmFwcGVyICkge1xuXHRcdFx0XHR0b2dnbGVXcmFwcGVyLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLW1vZGUtdG9nZ2xlLS1sb2FkaW5nJyApO1xuXHRcdFx0fVxuXG5cdFx0XHR3aW5kb3cud3AuYXBpRmV0Y2goIHtcblx0XHRcdFx0cGF0aDogJy93cC1yb2NrZXQvdjEvcm9ja2V0Y2RuL21vZGUnLFxuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdFx0ZGF0YTogeyBtb2RlOiByZXF1ZXN0ZWRNb2RlIH0sXG5cdFx0XHR9ICkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdFx0dG9nZ2xlLmNoZWNrZWQgPSByZXF1ZXN0ZWRDaGVja2VkO1xuXG5cdFx0XHRcdGlmICggdG9nZ2xlV3JhcHBlciApIHtcblx0XHRcdFx0XHR0b2dnbGVXcmFwcGVyLmNsYXNzTGlzdC5yZW1vdmUoICd3cHItY2RuLW1vZGUtdG9nZ2xlLS1sb2FkaW5nJyApO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKCByZXF1ZXN0ZWRDaGVja2VkICkge1xuXHRcdFx0XHRcdC8vIFVuY2hlY2sgYWxsIG90aGVyIG1vZGUgdG9nZ2xlcyAobXV0dWFsbHkgZXhjbHVzaXZlKS5cblx0XHRcdFx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnLndwci1jZG4tbW9kZS10b2dnbGVfX2lucHV0JyApLmZvckVhY2goICggb3RoZXIgKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAoIG90aGVyICE9PSB0b2dnbGUgKSB7XG5cdFx0XHRcdFx0XHRcdG90aGVyLmNoZWNrZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9ICk7XG5cdFx0XHRcdFx0dG9nZ2xlRHJpdmVyU2VjdGlvbnMoIHNlY3Rpb25Ecml2ZXIgKTtcblx0XHRcdFx0XHRzZXRBY3RpdmVUYWIoIHNlY3Rpb25Ecml2ZXIgKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHVwZGF0ZUNkbkFjdGl2ZUluZGljYXRvciggcmVxdWVzdGVkQ2hlY2tlZCA/IHRvZ2dsZSA6IG51bGwgKTtcblx0XHRcdFx0bm90aWZ5Q2RuU3RhdGVDaGFuZ2UoKTtcblxuXHRcdFx0XHR1cGRhdGVSb2NrZXRDRE5FbGVtZW50c1N0YXRlKFxuXHRcdFx0XHRcdCdieW9jZG4nID09PSBtb2RlID8gJ2J5b2NkbicgOiAncm9ja2V0Y2RuJyxcblx0XHRcdFx0XHRyZXNwb25zZS5kaXNhYmxlX3JvY2tldF9jZG5fZWxlbWVudHNcblx0XHRcdFx0KTtcblx0XHRcdFx0c3luY0NkbkhpZGRlbklucHV0cyggcmVxdWVzdGVkTW9kZSApO1xuXG5cdFx0XHRcdC8vIEVuYWJsaW5nIGVpdGhlciBkcml2ZXIgY2hhbmdlcyB0aGUgb3RoZXIncyBwYXVzZWQvYWN0aXZlIHN0YXR1cyB0b28gLSBlLmcuXG5cdFx0XHRcdC8vIHN3aXRjaGluZyB0byBPdGhlciBDRE4gcGF1c2VzIFJvY2tldENETiwgYW5kIHZpY2UgdmVyc2EgLSBzbyByZWZyZXNoIGJvdGhcblx0XHRcdFx0Ly8gc3RhdHVzIGluZGljYXRvcnMgcmVnYXJkbGVzcyBvZiB3aGljaCB0b2dnbGUgd2FzIGp1c3QgZmxpcHBlZCwgaW5zdGVhZCBvZlxuXHRcdFx0XHQvLyBvbmx5IHRoZSBvbmUgbWF0Y2hpbmcgYG1vZGVgLiBTYWZlIHRvIGNhbGwgdW5jb25kaXRpb25hbGx5OiBib3RoIHVwZGF0ZVxuXHRcdFx0XHQvLyBmdW5jdGlvbnMgbm93IHNjb3BlIHRoZW1zZWx2ZXMgdG8gdGhlaXIgb3duIHRhYiAoZWFjaCBleHBsaWNpdGx5IGV4Y2x1ZGVzXG5cdFx0XHRcdC8vIHRoZSBvdGhlcidzIGNvcHkgb2YgI3dwcl9jZG5fc3RhdHVzX2luZGljYXRvciksIGFuZCBldmVyeSBzYXZlX2Nkbl9tb2RlKClcblx0XHRcdFx0Ly8gcmVzcG9uc2UgYWxyZWFkeSBjYXJyaWVzIGJvdGggSFRNTCBmcmFnbWVudHMsIGZyZXNobHkgcmVuZGVyZWQgZnJvbSB0aGVcblx0XHRcdFx0Ly8ganVzdC1wZXJzaXN0ZWQgc3RhdGUuXG5cdFx0XHRcdHVwZGF0ZUJ5b2NkblN0YXR1c0luZGljYXRvciggcmVzcG9uc2UuYnlvY2RuX3N0YXR1c19pbmRpY2F0b3JfaHRtbCApO1xuXHRcdFx0XHRyZWZyZXNoVUlFbGVtZW50cyggcmVzcG9uc2UgKTtcblxuXHRcdFx0XHRpZiAoICdieW9jZG4nID09PSBtb2RlICkge1xuXHRcdFx0XHRcdHRvZ2dsZS5kaXNhYmxlZCA9IGZhbHNlO1xuXG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gcmVmcmVzaFVJRWxlbWVudHMoKSBjYWxscyBzZXRTdWJzY3JpcHRpb25Mb2FkaW5nU3RhdGUoKSBhYm92ZSB3aGVuIHRoZSBhc3luY1xuXHRcdFx0XHQvLyBzdWJzY3JpcHRpb24gY3JlYXRpb24gaXMgc3RpbGwgaW4gcHJvZ3Jlc3MsIHdoaWNoIGRpc2FibGVzIGV2ZXJ5IG1vZGUgdG9nZ2xlIC1cblx0XHRcdFx0Ly8gbGVhdmUgdGhpcyBvbmUgZGlzYWJsZWQgdG9vIHVudGlsIHRoZSBwb2xsZXIgY29uZmlybXMgaXQncyBsaXZlLlxuXHRcdFx0XHRpZiAoICEgcmVzcG9uc2UuaXNfc3Vic2NyaXB0aW9uX2NyZWF0aW9uX2xvYWRpbmcgKSB7XG5cdFx0XHRcdFx0dG9nZ2xlLmRpc2FibGVkID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdH0gKS5jYXRjaCggKCkgPT4ge1xuXHRcdFx0XHQvLyBSZXF1ZXN0IGZhaWxlZCAtIHRoZSB0b2dnbGUgc3RpbGwgcmVmbGVjdHMgaXRzIHByZS1jbGljayBzdGF0ZSwganVzdCByZS1lbmFibGUgaXQuXG5cdFx0XHRcdHRvZ2dsZS5kaXNhYmxlZCA9IGZhbHNlO1xuXG5cdFx0XHRcdGlmICggdG9nZ2xlV3JhcHBlciApIHtcblx0XHRcdFx0XHR0b2dnbGVXcmFwcGVyLmNsYXNzTGlzdC5yZW1vdmUoICd3cHItY2RuLW1vZGUtdG9nZ2xlLS1sb2FkaW5nJyApO1xuXHRcdFx0XHR9XG5cdFx0XHR9ICk7XG5cdFx0fSApO1xuXHR9XG5cblx0LyoqXG5cdCAqIFRvZ2dsZXMgdmlzaWJpbGl0eSBvZiBDRE4gZHJpdmVyIHNlY3Rpb25zIHVzaW5nIHRoZSBoaWRkZW4gdXRpbGl0eSBjbGFzcy5cblx0ICpcblx0ICogQHBhcmFtIHtzdHJpbmd9IGFjdGl2ZURyaXZlciBBY3RpdmUgQ0ROIGRyaXZlciBzbHVnICgncm9ja2V0Y2RuJyBvciAneW91ci1vd24tY2RuJykuXG5cdCAqL1xuXHRmdW5jdGlvbiB0b2dnbGVEcml2ZXJTZWN0aW9ucyggYWN0aXZlRHJpdmVyICkge1xuXHRcdGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoICcucm9ja2V0Y2RuLCAueW91ci1vd24tY2RuJyApLmZvckVhY2goICggc2VjdGlvbiApID0+IHtcblx0XHRcdHNlY3Rpb24uY2xhc3NMaXN0LnRvZ2dsZSggJ3dwci1pc0hpZGRlbicsICEgc2VjdGlvbi5jbGFzc0xpc3QuY29udGFpbnMoIGFjdGl2ZURyaXZlciApICk7XG5cdFx0fSApO1xuXHR9XG5cblx0LyoqXG5cdCAqIFVwZGF0ZXMgYWxsIC5yb2NrZXRjZG4tZHJpdmVyLWpzIHNwYW5zIHRvIHJlZmxlY3QgdGhlIGFjdGl2ZSBkcml2ZXIgbGFiZWwuXG5cdCAqXG5cdCAqIEBwYXJhbSB7c3RyaW5nfSBkcml2ZXIgQWN0aXZlIENETiBkcml2ZXIgc2x1ZyAoJ3JvY2tldGNkbicgb3IgJ3lvdXItb3duLWNkbicpLlxuXHQgKi9cblx0ZnVuY3Rpb24gdXBkYXRlRHJpdmVyTGFiZWwoIGRyaXZlciApIHtcblx0XHRjb25zdCB0YWIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCBgLndwci1jZG4tdGFic19fdGFiW2RhdGEtY2RuLWRyaXZlcj1cIiR7ZHJpdmVyfVwiXWAgKTtcblxuXHRcdGlmICggISB0YWIgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Y29uc3QgbGFiZWwgPSB0YWIuZ2V0QXR0cmlidXRlKCAnZGF0YS10aXRsZScgKTtcblxuXHRcdGlmICggISBsYWJlbCApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnLnJvY2tldGNkbi1kcml2ZXItanMnICkuZm9yRWFjaCggKCBzcGFuICkgPT4ge1xuXHRcdFx0c3Bhbi50ZXh0Q29udGVudCA9IGxhYmVsO1xuXHRcdH0gKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSBcIk5lZWQgSGVscD9cIiBsaW5rIGhyZWYgZm9yIHRoZSBDRE4gRXhjbHVzaW9ucyBzZWN0aW9uXG5cdCAqIHRvIHBvaW50IHRvIHRoZSBjb3JyZWN0IGRvY3MgYXJ0aWNsZSBmb3IgdGhlIGFjdGl2ZSBkcml2ZXIuXG5cdCAqXG5cdCAqIEBwYXJhbSB7c3RyaW5nfSBkcml2ZXIgQWN0aXZlIENETiBkcml2ZXIgc2x1ZyAoJ3JvY2tldGNkbicgb3IgJ3lvdXItb3duLWNkbicpLlxuXHQgKi9cblx0ZnVuY3Rpb24gdXBkYXRlRXhjbHVkZUNkbkhlbHBVcmwoIGRyaXZlciApIHtcblx0XHRjb25zdCBsaW5rID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy5leGNsdWRlLWNkbi1oZWxwLWpzJyApO1xuXG5cdFx0aWYgKCAhIGxpbmsgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Y29uc3QgaXNSb2NrZXRDZG4gPSAncm9ja2V0Y2RuJyA9PT0gZHJpdmVyO1xuXHRcdGNvbnN0IHVybCA9IGlzUm9ja2V0Q2RuID8gbGluay5kYXRhc2V0LnJvY2tldGNkblVybCA6IGxpbmsuZGF0YXNldC5vdGhlckNkblVybDtcblx0XHRjb25zdCBpZCAgPSBpc1JvY2tldENkbiA/IGxpbmsuZGF0YXNldC5yb2NrZXRjZG5JZCAgOiBsaW5rLmRhdGFzZXQub3RoZXJDZG5JZDtcblxuXHRcdGlmICggdXJsICkge1xuXHRcdFx0bGluay5ocmVmID0gdXJsO1xuXHRcdH1cblxuXHRcdGlmICggaWQgKSB7XG5cdFx0XHRsaW5rLmRhdGFzZXQuYmVhY29uSWQgPSBpZDtcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogU2V0cyB0aGUgYWN0aXZlIGRyaXZlciB0YWIgYW5kIHN5bmNzIGFsbCB0YWItZGVwZW5kZW50IFVJIChsYWJlbCBzcGFucywgaGVscCBVUkwpLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gZHJpdmVyIEFjdGl2ZSBDRE4gZHJpdmVyIHNsdWcgKCdyb2NrZXRjZG4nIG9yICd5b3VyLW93bi1jZG4nKS5cblx0ICovXG5cdGZ1bmN0aW9uIHNldEFjdGl2ZVRhYiggZHJpdmVyICkge1xuXHRcdGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoICcud3ByLWNkbi10YWJzX190YWInICkuZm9yRWFjaCggKCB0ICkgPT4ge1xuXHRcdFx0dC5jbGFzc0xpc3QudG9nZ2xlKCAnd3ByLWNkbi10YWJzX190YWItLWFjdGl2ZScsIHQuZ2V0QXR0cmlidXRlKCAnZGF0YS1jZG4tZHJpdmVyJyApID09PSBkcml2ZXIgKTtcblx0XHR9ICk7XG5cblx0XHR1cGRhdGVEcml2ZXJMYWJlbCggZHJpdmVyICk7XG5cdFx0dXBkYXRlRXhjbHVkZUNkbkhlbHBVcmwoIGRyaXZlciApO1xuXHR9XG5cblx0LyoqXG5cdCAqIEluaXRpYWxpemVzIENETiBkcml2ZXIgdGFiIHN3aXRjaGluZyBiZWhhdmlvci5cblx0ICpcblx0ICogVGFicyBhcmUgbmF2aWdhdGlvbiBvbmx5IOKAlCBubyBiYWNrZW5kIGNhbGwgb24gY2xpY2suXG5cdCAqIEluaXRpYWwgZHJpdmVyIGlzIGRlcml2ZWQgZnJvbSB0aGUgUEhQLXJlbmRlcmVkIGFjdGl2ZS1zdGF0ZSBoZWFkZXJcblx0ICogKHdwci1jZG4tYWN0aXZlLWluZGljYXRvciksIHdoaWNoIHJlZmxlY3RzIGNkbl9zdGF0ZSBldmVuIHdoZW4gdGhlIG1vZGVcblx0ICogdG9nZ2xlIGl0c2VsZiBpcyBoaWRkZW4gKGUuZy4gcm9ja2V0X2Rpc3BsYXlfY2RuX21vZGVfdG9nZ2xlIHJldHVybmluZ1xuXHQgKiBmYWxzZSBmb3IgYSBob3N0aW5nIGNvbXBhdGliaWxpdHkgbGF5ZXIpLiBGYWxscyBiYWNrIHRvIHdoaWNoZXZlclxuXHQgKiB0b2dnbGUgaXMgY2hlY2tlZCB3aGVuIG5vIGhlYWRlciBpcyBtYXJrZWQgYWN0aXZlIChlLmcuIGNkbl9zdGF0ZSBpc1xuXHQgKiAnbm90aGluZycpLlxuXHQgKi9cblx0ZnVuY3Rpb24gaW5pdENkbkRyaXZlclRhYnMoKSB7XG5cdFx0Y29uc3QgdGFicyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoICcud3ByLWNkbi10YWJzX190YWInICk7XG5cblx0XHRpZiAoICEgdGFicy5sZW5ndGggKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0dGFicy5mb3JFYWNoKCAoIHRhYiApID0+IHtcblx0XHRcdHRhYi5hZGRFdmVudExpc3RlbmVyKCAnY2xpY2snLCAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGRyaXZlciA9IHRhYi5nZXRBdHRyaWJ1dGUoICdkYXRhLWNkbi1kcml2ZXInICk7XG5cblx0XHRcdFx0aWYgKCAhIGRyaXZlciApIHtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRzZXRBY3RpdmVUYWIoIGRyaXZlciApO1xuXHRcdFx0XHR0b2dnbGVEcml2ZXJTZWN0aW9ucyggZHJpdmVyICk7XG5cdFx0XHRcdG5vdGlmeUNkblN0YXRlQ2hhbmdlKCk7XG5cdFx0XHR9ICk7XG5cdFx0fSApO1xuXG5cdFx0Y29uc3QgYWN0aXZlSGVhZGVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItb3B0aW9uSGVhZGVyLndwci1jZG4tYWN0aXZlLWluZGljYXRvcicgKTtcblx0XHRsZXQgaW5pdGlhbERyaXZlcjtcblxuXHRcdGlmICggYWN0aXZlSGVhZGVyICkge1xuXHRcdFx0aW5pdGlhbERyaXZlciA9IGFjdGl2ZUhlYWRlci5jbGFzc0xpc3QuY29udGFpbnMoICd5b3VyLW93bi1jZG4nICkgPyAneW91ci1vd24tY2RuJyA6ICdyb2NrZXRjZG4nO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBjaGVja2VkVG9nZ2xlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLW1vZGUtdG9nZ2xlX19pbnB1dDpjaGVja2VkJyApO1xuXHRcdFx0aW5pdGlhbERyaXZlciA9IGNoZWNrZWRUb2dnbGUgJiYgJ2J5b2NkbicgPT09IGNoZWNrZWRUb2dnbGUuZ2V0QXR0cmlidXRlKCAnZGF0YS1jZG4tbW9kZScgKVxuXHRcdFx0XHQ/ICd5b3VyLW93bi1jZG4nXG5cdFx0XHRcdDogJ3JvY2tldGNkbic7XG5cdFx0fVxuXG5cdFx0c2V0QWN0aXZlVGFiKCBpbml0aWFsRHJpdmVyICk7XG5cdFx0dG9nZ2xlRHJpdmVyU2VjdGlvbnMoIGluaXRpYWxEcml2ZXIgKTtcblx0XHRub3RpZnlDZG5TdGF0ZUNoYW5nZSgpO1xuXHR9XG5cblx0LyoqXG5cdCAqIEFkZHMgYSBwYWdlIChvciB0aGUgaG9tZXBhZ2UpIHRvIFJvY2tldENETiBmcmVlLXRpZXIgZGVsaXZlcnksIHRyYW5zcGFyZW50bHlcblx0ICogaGFuZGxpbmcgdGhlIFwiUm9ja2V0Q0ROIEZyZWUgaXMgaW5hY3RpdmVcIiBhY3RpdmF0aW9uIHByb21wdDogb24gYSA0MDlcblx0ICogY29uZmlybS1yZXF1aXJlZCBlcnJvciwgc2hvd3MgYSBuYXRpdmUgY29uZmlybWF0aW9uIGRpYWxvZyBhbmQgcmV0cmllcyB3aXRoXG5cdCAqIGBjb25maXJtX2FjdGl2YXRpb25gIGlmIHRoZSB1c2VyIGFjY2VwdHMuIElmIHRoZSBzZXJ2ZXIgYXV0by1hY3RpdmF0ZWQgRnJlZVxuXHQgKiAobm8gbW9kZSB3YXMgYWN0aXZlIGF0IGFsbCksIHVwZGF0ZXMgdGhlIHRvZ2dsZSBVSSB0byByZWZsZWN0IGl0LlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gcGF0aCBSRVNUIHBhdGggdG8gY2FsbCAoJy93cC1yb2NrZXQvdjEvcm9ja2V0Y2RuL3BhZ2VzJyBvciAnLi4uL3BhZ2VzL2hvbWVwYWdlJykuXG5cdCAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIFJlcXVlc3QgYm9keSBkYXRhIChlLmcuIHsgdXJsIH0pLlxuXHQgKiBAcmV0dXJucyB7UHJvbWlzZX0gUmVzb2x2ZXMgd2l0aCB0aGUgUkVTVCByZXNwb25zZTsgcmVqZWN0cyBvbiBmaW5hbCBmYWlsdXJlIG9yIGNhbmNlbGxhdGlvbi5cblx0ICovXG5cdGZ1bmN0aW9uIHJlcXVlc3RBZGRQYWdlKCBwYXRoLCBkYXRhICkge1xuXHRcdHJldHVybiB3aW5kb3cud3AuYXBpRmV0Y2goIHtcblx0XHRcdHBhdGgsXG5cdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdGRhdGEsXG5cdFx0fSApLnRoZW4oICggcmVzcG9uc2UgKSA9PiB7XG5cdFx0XHRpZiAoIHJlc3BvbnNlLmZyZWVfYWN0aXZhdGVkICkge1xuXHRcdFx0XHRhY3RpdmF0ZUZyZWVNb2RlVUkoKTtcblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHJlc3BvbnNlO1xuXHRcdH0gKS5jYXRjaCggKCBlcnJvciApID0+IHtcblx0XHRcdGlmICggJ3JvY2tldGNkbl9mcmVlX2luYWN0aXZlX2NvbmZpcm1fcmVxdWlyZWQnID09PSBlcnJvci5jb2RlICYmIHdpbmRvdy5jb25maXJtKCBlcnJvci5tZXNzYWdlICkgKSB7XG5cdFx0XHRcdHJldHVybiByZXF1ZXN0QWRkUGFnZSggcGF0aCwgT2JqZWN0LmFzc2lnbigge30sIGRhdGEsIHsgY29uZmlybV9hY3RpdmF0aW9uOiB0cnVlIH0gKSApO1xuXHRcdFx0fVxuXG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9ICk7XG5cdH1cblxuXHQvKipcblx0ICogSW5pdGlhbGl6ZXMgdGhlIFwiQUREIEhPTUVQQUdFXCIgYnV0dG9uLlxuXHQgKlxuXHQgKiBTZW5kcyBhIFBPU1QgcmVxdWVzdCB0byB0aGUgUm9ja2V0Q0ROIFJFU1QgZW5kcG9pbnQgdG8gYWRkXG5cdCAqIHRoZSBzaXRlIGhvbWVwYWdlIGFzIGEgZnJlZS10aWVyIENETiBwYWdlLlxuXHQgKi9cblx0ZnVuY3Rpb24gaW5pdEFkZEhvbWVwYWdlKCkge1xuXHRcdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoICdjbGljaycsICggZXZlbnQgKSA9PiB7XG5cdFx0XHRjb25zdCBidXR0b24gPSBldmVudC50YXJnZXQuY2xvc2VzdCggJyN3cHJfYWRkX3BhZ2VfY29tcG9uZW50IC53cHItY2RuLWFkZC1wYWdlX19ob21lcGFnZScgKTtcblx0XHRcdGlmICggISBidXR0b24gKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0YnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcblxuXHRcdFx0Y29uc3QgYnVpbHRJbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1idWlsdC1pbicgKTtcblxuXHRcdFx0aWYgKCBidWlsdEluICkge1xuXHRcdFx0XHRidWlsdEluLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWJ1aWx0LWluLS1kaXNhYmxlZCcgKTtcblx0XHRcdH1cblxuXHRcdFx0cmVxdWVzdEFkZFBhZ2UoICcvd3Atcm9ja2V0L3YxL3JvY2tldGNkbi9wYWdlcy9ob21lcGFnZScsIHt9ICkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdFx0YnV0dG9uLmNsYXNzTGlzdC5hZGQoICd3cHItaXNIaWRkZW4nICk7XG5cdFx0XHRcdHVwZGF0ZVJvY2tldEN0YVN0YXRlKCByZXNwb25zZS5jb3VudCwgcmVzcG9uc2UubGltaXQgKTtcblxuXHRcdFx0XHRpZiAoIGJ1aWx0SW4gKSB7XG5cdFx0XHRcdFx0YnVpbHRJbi5jbGFzc0xpc3QucmVtb3ZlKCAnd3ByLWNkbi1idWlsdC1pbi0tZGlzYWJsZWQnICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoIHJlc3BvbnNlLml0ZW1zX2h0bWwgKSB7XG5cdFx0XHRcdFx0Y29uc3QgZXhpc3RpbmcgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gLndwci10YWJsZS1saXN0JyApO1xuXG5cdFx0XHRcdFx0aWYgKCBleGlzdGluZyApIHtcblx0XHRcdFx0XHRcdGV4aXN0aW5nLnJlbW92ZSgpO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGNvbnN0IGFkZFBhZ2VTZWN0aW9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWFkZC1wYWdlJyApO1xuXG5cdFx0XHRcdFx0aWYgKCBhZGRQYWdlU2VjdGlvbiApIHtcblx0XHRcdFx0XHRcdGFkZFBhZ2VTZWN0aW9uLmluc2VydEFkamFjZW50SFRNTCggJ2JlZm9yZWJlZ2luJywgcmVzcG9uc2UuaXRlbXNfaHRtbCApO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFRyYWNrIGJhbm5lciB2aWV3IHdoZW4gZmlyc3QgcGFnZSBpcyBhZGRlZCBhbmQgYmFubmVyIGJlY29tZXMgdmlzaWJsZS5cblx0XHRcdFx0aWYgKCAxID09PSByZXNwb25zZS5jb3VudCApIHtcblx0XHRcdFx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gLndwci1jZG4tYnVpbHQtaW5fX3NlcGFyYXRvcicgKT8ucmVtb3ZlKCk7XG5cdFx0XHRcdFx0ZG9jdW1lbnQuZGlzcGF0Y2hFdmVudCggbmV3IEN1c3RvbUV2ZW50KCAncm9ja2V0Q0ROQmFubmVyRmlyc3RWaXNpYmxlJyApICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZWZyZXNoVUlFbGVtZW50cyhyZXNwb25zZSk7XG5cdFx0XHR9ICkuY2F0Y2goICgpID0+IHtcblx0XHRcdFx0YnV0dG9uLmRpc2FibGVkID0gZmFsc2U7XG5cblx0XHRcdFx0aWYgKCBidWlsdEluICkge1xuXHRcdFx0XHRcdGJ1aWx0SW4uY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1jZG4tYnVpbHQtaW4tLWRpc2FibGVkJyApO1xuXHRcdFx0XHR9XG5cdFx0XHR9ICk7XG5cdFx0fSApO1xuXHR9XG5cdC8qKlxuXHQgKiBJbml0aWFsaXplcyB0aGUgXCJBREQgUEFHRVwiIGlucHV0IGFuZCBidXR0b24uXG5cdCAqXG5cdCAqIFNlbmRzIGEgUE9TVCByZXF1ZXN0IHRvIHRoZSBSb2NrZXRDRE4gUkVTVCBlbmRwb2ludCB0byBhZGRcblx0ICogYSBwYWdlIFVSTCB0byB0aGUgZnJlZS10aWVyIENETiBwYWdlIGxpc3QuXG5cdCAqL1xuXHRmdW5jdGlvbiBpbml0QWRkUGFnZSgpIHtcblx0XHRjb25zdCBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnd3ByX2Nkbl9hZGRfcGFnZV9pbnB1dCcgKTtcblx0XHRjb25zdCBidXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYWRkLXBhZ2VfX2J1dHRvbicgKTtcblxuXHRcdGlmICggISBpbnB1dCB8fCAhIGJ1dHRvbiApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRmdW5jdGlvbiBpc1ZhbGlkVXJsKGlucHV0KSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGlucHV0KTtcblx0XHRcdFx0cmV0dXJuIHVybC5ob3N0bmFtZS5pbmNsdWRlcygnLicpICYmIHVybC5ob3N0bmFtZS5zcGxpdCgnLicpLnBvcCgpLmxlbmd0aCA+IDA7XG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGZ1bmN0aW9uIHN1Ym1pdFBhZ2UoKSB7XG5cdFx0XHRjb25zdCB1cmwgPSBpbnB1dC52YWx1ZS50cmltKCk7XG5cblx0XHRcdGlmICghaXNWYWxpZFVybCh1cmwpKSB7XG5cdFx0XHRcdGFsZXJ0KCdQbGVhc2UgZW50ZXIgYSB2YWxpZCBVUkwnKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBQcmV2ZW50IGR1cGxpY2F0ZSByZXF1ZXN0IHdoaWxlIHJlcXVlc3QgaXMgaW4gZmxpZ2h0LlxuXHRcdFx0aW5wdXQuZGlzYWJsZWQgPSB0cnVlO1xuXHRcdFx0YnV0dG9uLmRpc2FibGVkID0gdHJ1ZTtcblx0XHRcdGNvbnN0IGJ1aWx0SW4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4nICk7XG5cblx0XHRcdGlmICggYnVpbHRJbiApIHtcblx0XHRcdFx0YnVpbHRJbi5jbGFzc0xpc3QuYWRkKCAnd3ByLWNkbi1idWlsdC1pbi0tZGlzYWJsZWQnICk7XG5cdFx0XHR9XG5cblx0XHRcdHJlcXVlc3RBZGRQYWdlKCAnL3dwLXJvY2tldC92MS9yb2NrZXRjZG4vcGFnZXMnLCB7IHVybCB9ICkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdFx0aW5wdXQudmFsdWUgPSAnJztcblx0XHRcdFx0aW5wdXQuZGlzYWJsZWQgPSBmYWxzZTtcblx0XHRcdFx0YnV0dG9uLmRpc2FibGVkID0gZmFsc2U7XG5cdFx0XHRcdGFkZEhvbWVCdXR0b24uY2xhc3NMaXN0LmFkZCggJ3dwci1pc0hpZGRlbicgKTtcblxuXHRcdFx0XHR1cGRhdGVSb2NrZXRDdGFTdGF0ZSggcmVzcG9uc2UuY291bnQsIHJlc3BvbnNlLmxpbWl0ICk7XG5cblx0XHRcdFx0aWYgKCBidWlsdEluICkge1xuXHRcdFx0XHRcdGJ1aWx0SW4uY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1jZG4tYnVpbHQtaW4tLWRpc2FibGVkJyApO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gVXBkYXRlIHBhZ2UgbGlzdCB3aXRoIHJlc3BvbnNlLlxuXHRcdFx0XHRpZiAoIHJlc3BvbnNlLml0ZW1zX2h0bWwgKSB7XG5cdFx0XHRcdFx0Y29uc3QgZXhpc3RpbmcgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gLndwci10YWJsZS1saXN0JyApO1xuXG5cdFx0XHRcdFx0aWYgKCBleGlzdGluZyApIHtcblx0XHRcdFx0XHRcdGV4aXN0aW5nLnJlbW92ZSgpO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGNvbnN0IGFkZFBhZ2VTZWN0aW9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWFkZC1wYWdlJyApO1xuXG5cdFx0XHRcdFx0aWYgKCBhZGRQYWdlU2VjdGlvbiApIHtcblx0XHRcdFx0XHRcdGFkZFBhZ2VTZWN0aW9uLmluc2VydEFkamFjZW50SFRNTCggJ2JlZm9yZWJlZ2luJywgcmVzcG9uc2UuaXRlbXNfaHRtbCApO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIFRyYWNrIGJhbm5lciB2aWV3IHdoZW4gZmlyc3QgcGFnZSBpcyBhZGRlZCBhbmQgYmFubmVyIGJlY29tZXMgdmlzaWJsZS5cblx0XHRcdFx0aWYgKCAxID09PSByZXNwb25zZS5jb3VudCApIHtcblx0XHRcdFx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gLndwci1jZG4tYnVpbHQtaW5fX3NlcGFyYXRvcicgKT8ucmVtb3ZlKCk7XG5cdFx0XHRcdFx0ZG9jdW1lbnQuZGlzcGF0Y2hFdmVudCggbmV3IEN1c3RvbUV2ZW50KCAncm9ja2V0Q0ROQmFubmVyRmlyc3RWaXNpYmxlJyApICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoIHJlc3BvbnNlLmxpbWl0ID09PSByZXNwb25zZS5jb3VudCApIHtcblx0XHRcdFx0XHQvLyBEaXNhYmxlIGlucHV0IGFuZCBidXR0b24gd2hlbiBwYWdlIGxpbWl0IGlzIHJlYWNoZWQuXG5cdFx0XHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWJ1aWx0LWluJyApLmNsYXNzTGlzdC5hZGQoICd3cHItY2RuLWJ1aWx0LWluLS1kaXNhYmxlZCcgKTtcblx0XHRcdFx0XHRjb25zdCBhZGRQYWdlV3JhcHBlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1hZGQtcGFnZV9fYnV0dG9uLXdyYXBwZXInICk7XG5cdFx0XHRcdFx0aWYgKCBhZGRQYWdlV3JhcHBlciApIHtcblx0XHRcdFx0XHRcdGFkZFBhZ2VXcmFwcGVyLmNsYXNzTGlzdC5hZGQoICd3cHItYnRuLXdpdGgtdG9vbC10aXAnICk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbnN0IGFkZFBhZ2VCdG4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYWRkLXBhZ2VfX2J1dHRvbicgKTtcblx0XHRcdFx0XHRpZiAoIGFkZFBhZ2VCdG4gKSB7XG5cdFx0XHRcdFx0XHRhZGRQYWdlQnRuLmRpc2FibGVkID0gdHJ1ZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dXBkYXRlVG9vbHRpcFN0YXRlKCB0cnVlICk7XG5cdFx0XHRcdFx0ZG9jdW1lbnQuZGlzcGF0Y2hFdmVudCggbmV3IEN1c3RvbUV2ZW50KCAncm9ja2V0Q0ROQmFubmVyQXV0b0V4cGFuZGVkJyApICk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZWZyZXNoVUlFbGVtZW50cyhyZXNwb25zZSk7XG5cdFx0XHR9ICkuY2F0Y2goICgpID0+IHtcblx0XHRcdFx0aW5wdXQuZGlzYWJsZWQgPSBmYWxzZTtcblx0XHRcdFx0YnV0dG9uLmRpc2FibGVkID0gZmFsc2U7XG5cblx0XHRcdFx0aWYgKCBidWlsdEluICkge1xuXHRcdFx0XHRcdGJ1aWx0SW4uY2xhc3NMaXN0LnJlbW92ZSggJ3dwci1jZG4tYnVpbHQtaW4tLWRpc2FibGVkJyApO1xuXHRcdFx0XHR9XG5cdFx0XHR9ICk7XG5cdFx0fVxuXG5cdFx0YnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoICdjbGljaycsIHN1Ym1pdFBhZ2UgKTtcblxuXHRcdGlucHV0LmFkZEV2ZW50TGlzdGVuZXIoICdrZXlkb3duJywgKCBlICkgPT4ge1xuXHRcdFx0aWYgKCAnRW50ZXInID09PSBlLmtleSApIHtcblx0XHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0XHRzdWJtaXRQYWdlKCk7XG5cdFx0XHR9XG5cdFx0fSApO1xuXHR9XG5cblx0ZnVuY3Rpb24gcmVmcmVzaFVJRWxlbWVudHMoIHJlc3BvbnNlICkge1xuXHRcdC8vIFNldCBzdWJzY3JpcHRpb24gbG9hZGluZyBzdGF0ZSB3aGVuIGZpcnN0IHBhZ2UgaXMgYWRkZWQuXG5cdFx0aWYgKCByZXNwb25zZS5pc19zdWJzY3JpcHRpb25fY3JlYXRpb25fbG9hZGluZyApIHtcblx0XHRcdHNldFN1YnNjcmlwdGlvbkxvYWRpbmdTdGF0ZSgpO1xuXHRcdH1cblxuXHRcdC8vIE9ubHkgdGhlIG1vZGUtdG9nZ2xlIHJlc3BvbnNlIGNhcnJpZXMgdGhpcyAtIGtlZXBzIHRoZSBhZGQtcGFnZSBjb250cm9sc1xuXHRcdC8vIChob21lcGFnZS9hZGQgYnV0dG9ucywgVVJMIGlucHV0KSBpbiBzeW5jIHdpdGggdGhlIHNlcnZlcidzIGF1dGhvcml0YXRpdmVcblx0XHQvLyBkaXNhYmxlZCBzdGF0ZSAobGltaXQgcmVhY2hlZCAvIHN1YnNjcmlwdGlvbiBsb2FkaW5nIC8gZm9yY2VkIG9mZikgcmlnaHRcblx0XHQvLyBhZnRlciBlbmFibGluZyBvciBkaXNhYmxpbmcgUm9ja2V0Q0ROLCBpbnN0ZWFkIG9mIG9ubHkgb24gYSBwYWdlIHJlbG9hZC5cblx0XHRpZiAoICdmcmVlX2FkZF9wYWdlX2Rpc2FibGVkJyBpbiByZXNwb25zZSApIHtcblx0XHRcdGNvbnN0IGJ1aWx0SW4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4nICk7XG5cblx0XHRcdGlmICggYnVpbHRJbiApIHtcblx0XHRcdFx0YnVpbHRJbi5jbGFzc0xpc3QudG9nZ2xlKCAnd3ByLWNkbi1idWlsdC1pbi0tZGlzYWJsZWQnLCByZXNwb25zZS5mcmVlX2FkZF9wYWdlX2Rpc2FibGVkICk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gVXBkYXRlIHN0YXR1cyBpbmRpY2F0b3IgY29tcG9uZW50LlxuXHRcdHVwZGF0ZVN0YXR1c0luZGljYXRvckNvbXBvbmVudCggcmVzcG9uc2Uuc3RhdHVzX2luZGljYXRvcl9odG1sICk7XG5cdH1cblxuXHQvKipcblx0ICogSW5pdGlhbGl6ZXMgZGVsZXRlIGJ1dHRvbnMgZm9yIENETiBwYWdlIHJvd3MuXG5cdCAqXG5cdCAqIFVzZXMgZXZlbnQgZGVsZWdhdGlvbiBvbiB0aGUgYnVpbHQtaW4gQ0ROIGNvbnRhaW5lciB0byBoYW5kbGVcblx0ICogY2xpY2tzIG9uIGR5bmFtaWNhbGx5IGFkZGVkIGRlbGV0ZSBidXR0b25zLlxuXHQgKi9cblx0ZnVuY3Rpb24gaW5pdERlbGV0ZVBhZ2UoKSB7XG5cdFx0Y29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJyN3cHJfYWRkX3BhZ2VfY29tcG9uZW50JyApO1xuXG5cdFx0aWYgKCAhIGNvbnRhaW5lciApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRjb250YWluZXIucGFyZW50RWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCAnY2xpY2snLCAoIGUgKSA9PiB7XG5cdFx0XHRjb25zdCBidXR0b24gPSBlLnRhcmdldC5jbG9zZXN0KCAnLndwci10YWJsZS1saXN0X19kZWxldGUnICk7XG5cblx0XHRcdGlmICggISBidXR0b24gKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgaWQgPSBidXR0b24uZGF0YXNldC5pZDtcblxuXHRcdFx0aWYgKCAhIGlkICkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG5cblx0XHRcdHdpbmRvdy53cC5hcGlGZXRjaCgge1xuXHRcdFx0XHRwYXRoOiBgL3dwLXJvY2tldC92MS9yb2NrZXRjZG4vcGFnZXMvJHsgaWQgfWAsXG5cdFx0XHRcdG1ldGhvZDogJ0RFTEVURScsXG5cdFx0XHR9ICkudGhlbiggKCByZXNwb25zZSApID0+IHtcblx0XHRcdFx0dXBkYXRlUm9ja2V0Q3RhU3RhdGUoIHJlc3BvbnNlLmNvdW50LCByZXNwb25zZS5saW1pdCApO1xuXG5cdFx0XHRcdC8vIFVwZGF0ZSBzdGF0dXMgaW5kaWNhdG9yIGJlZm9yZSB0aGUgemVyby1jb3VudCBibG9jayBzbyB0aGUgc2VwYXJhdG9yXG5cdFx0XHRcdC8vIGxvZ2ljIGJlbG93IGNhbiBmaW5kIHRoZSBmcmVzaGx5LWluc2VydGVkIGVsZW1lbnQgd2hlbiBjb3VudCBoaXRzIDAuXG5cdFx0XHRcdHVwZGF0ZVN0YXR1c0luZGljYXRvckNvbXBvbmVudCggcmVzcG9uc2Uuc3RhdHVzX2luZGljYXRvcl9odG1sICk7XG5cblx0XHRcdFx0aWYgKCByZXNwb25zZS5pdGVtc19odG1sICkge1xuXHRcdFx0XHRcdGNvbnN0IGV4aXN0aW5nID0gY29udGFpbmVyLnBhcmVudEVsZW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWJ1aWx0LWluIC53cHItdGFibGUtbGlzdCcgKTtcblxuXHRcdFx0XHRcdGlmICggZXhpc3RpbmcgKSB7XG5cdFx0XHRcdFx0XHRleGlzdGluZy5yZW1vdmUoKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRjb25zdCBhZGRQYWdlU2VjdGlvbiA9IGNvbnRhaW5lci5wYXJlbnRFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1hZGQtcGFnZScgKTtcblxuXHRcdFx0XHRcdGlmICggYWRkUGFnZVNlY3Rpb24gKSB7XG5cdFx0XHRcdFx0XHRhZGRQYWdlU2VjdGlvbi5pbnNlcnRBZGphY2VudEhUTUwoICdiZWZvcmViZWdpbicsIHJlc3BvbnNlLml0ZW1zX2h0bWwgKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQvLyBTaG93IHJlLWFkZCBIT01FUEFHRSBidXR0b24gYW5kIG5vLXBhZ2Ugbm90aWNlIHdoZW4gYWxsIHBhZ2VzIGFyZSBkZWxldGVkLlxuXHRcdFx0XHRpZiAoIDAgPT09IHJlc3BvbnNlLmNvdW50ICkge1xuXHRcdFx0XHRcdC8vIFJlbW92ZSB0YWJsZSBsaXN0IGNvbXBvbmVudC5cblx0XHRcdFx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gLndwci10YWJsZS1saXN0JyApLnJlbW92ZSgpO1xuXG5cdFx0XHRcdFx0Y29uc3QgaG9tZXBhZ2VCdG4gPSBjb250YWluZXIucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWFkZC1wYWdlX19ob21lcGFnZScgKTtcblxuXHRcdFx0XHRcdGlmICggaG9tZXBhZ2VCdG4gKSB7XG5cdFx0XHRcdFx0XHRob21lcGFnZUJ0bi5jbGFzc0xpc3QucmVtb3ZlKCAnd3ByLWlzSGlkZGVuJyApO1xuXHRcdFx0XHRcdFx0aG9tZXBhZ2VCdG4uZGlzYWJsZWQgPSBmYWxzZTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvLyBSZXN0b3JlIHNlcGFyYXRvciBiZXR3ZWVuIHRoZSBzdGF0dXMgaW5kaWNhdG9yIGFuZCB0aGUgYWRkLXBhZ2Ugc2VjdGlvbi5cblx0XHRcdFx0XHRjb25zdCBpbmRpY2F0b3IgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYnVpbHQtaW4gI3dwcl9jZG5fc3RhdHVzX2luZGljYXRvcicgKTtcblx0XHRcdFx0XHRpZiAoIGluZGljYXRvciApIHtcblx0XHRcdFx0XHRcdGluZGljYXRvci5pbnNlcnRBZGphY2VudEhUTUwoICdhZnRlcmVuZCcsICc8ZGl2IGNsYXNzPVwid3ByLWNkbi1idWlsdC1pbl9fc2VwYXJhdG9yXCI+PC9kaXY+JyApO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmICggcmVzcG9uc2UubGltaXQgPiByZXNwb25zZS5jb3VudCApIHtcblx0XHRcdFx0XHQvLyBSZS1lbmFibGUgaW5wdXQgYW5kIGJ1dHRvbiB3aGVuIHBhZ2UgbGltaXQgaXMgbm90IHJlYWNoZWQuXG5cdFx0XHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWJ1aWx0LWluJyApLmNsYXNzTGlzdC5yZW1vdmUoICd3cHItY2RuLWJ1aWx0LWluLS1kaXNhYmxlZCcgKTtcblx0XHRcdFx0XHRjb25zdCBhZGRQYWdlV3JhcHBlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcud3ByLWNkbi1hZGQtcGFnZV9fYnV0dG9uLXdyYXBwZXInICk7XG5cdFx0XHRcdFx0aWYgKCBhZGRQYWdlV3JhcHBlciApIHtcblx0XHRcdFx0XHRcdGFkZFBhZ2VXcmFwcGVyLmNsYXNzTGlzdC5yZW1vdmUoICd3cHItYnRuLXdpdGgtdG9vbC10aXAnICk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbnN0IGFkZFBhZ2VCdG4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLndwci1jZG4tYWRkLXBhZ2VfX2J1dHRvbicgKTtcblx0XHRcdFx0XHRpZiAoIGFkZFBhZ2VCdG4gKSB7XG5cdFx0XHRcdFx0XHRhZGRQYWdlQnRuLmRpc2FibGVkID0gZmFsc2U7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHVwZGF0ZVRvb2x0aXBTdGF0ZSggZmFsc2UgKTtcblxuXHRcdFx0XHRcdC8vIFRyYWNrIGF1dG8tY29sbGFwc2Ugd2hlbiBkZWxldGlvbiBkcm9wcyBjb3VudCBqdXN0IGJlbG93IHRoZSBsaW1pdC5cblx0XHRcdFx0XHRpZiAoIHJlc3BvbnNlLmNvdW50ID09PSByZXNwb25zZS5saW1pdCAtIDEgKSB7XG5cdFx0XHRcdFx0XHRkb2N1bWVudC5kaXNwYXRjaEV2ZW50KCBuZXcgQ3VzdG9tRXZlbnQoICdyb2NrZXRDRE5CYW5uZXJBdXRvQ29sbGFwc2VkJyApICk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdH0gKS5jYXRjaCggKCkgPT4ge1xuXHRcdFx0XHRidXR0b24uZGlzYWJsZWQgPSBmYWxzZTtcblx0XHRcdH0gKTtcblx0XHR9ICk7XG5cdH1cbn0gKSggZG9jdW1lbnQgKTtcbiIsImZ1bmN0aW9uIGdldFRpbWVSZW1haW5pbmcoZW5kdGltZSl7XG4gICAgY29uc3Qgc3RhcnQgPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IHRvdGFsID0gKGVuZHRpbWUgKiAxMDAwKSAtIHN0YXJ0O1xuICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLmZsb29yKCAodG90YWwvMTAwMCkgJSA2MCApO1xuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKCAodG90YWwvMTAwMC82MCkgJSA2MCApO1xuICAgIGNvbnN0IGhvdXJzID0gTWF0aC5mbG9vciggKHRvdGFsLygxMDAwKjYwKjYwKSkgJSAyNCApO1xuICAgIGNvbnN0IGRheXMgPSBNYXRoLmZsb29yKCB0b3RhbC8oMTAwMCo2MCo2MCoyNCkgKTtcblxuICAgIHJldHVybiB7XG4gICAgICAgIHRvdGFsLFxuICAgICAgICBkYXlzLFxuICAgICAgICBob3VycyxcbiAgICAgICAgbWludXRlcyxcbiAgICAgICAgc2Vjb25kc1xuICAgIH07XG59XG5cbmZ1bmN0aW9uIGluaXRpYWxpemVDbG9jayhpZCwgZW5kdGltZSkge1xuICAgIGNvbnN0IGNsb2NrID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuXG4gICAgaWYgKGNsb2NrID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBkYXlzU3BhbiA9IGNsb2NrLnF1ZXJ5U2VsZWN0b3IoJy5yb2NrZXQtY291bnRkb3duLWRheXMnKTtcbiAgICBjb25zdCBob3Vyc1NwYW4gPSBjbG9jay5xdWVyeVNlbGVjdG9yKCcucm9ja2V0LWNvdW50ZG93bi1ob3VycycpO1xuICAgIGNvbnN0IG1pbnV0ZXNTcGFuID0gY2xvY2sucXVlcnlTZWxlY3RvcignLnJvY2tldC1jb3VudGRvd24tbWludXRlcycpO1xuICAgIGNvbnN0IHNlY29uZHNTcGFuID0gY2xvY2sucXVlcnlTZWxlY3RvcignLnJvY2tldC1jb3VudGRvd24tc2Vjb25kcycpO1xuXG4gICAgZnVuY3Rpb24gdXBkYXRlQ2xvY2soKSB7XG4gICAgICAgIGNvbnN0IHQgPSBnZXRUaW1lUmVtYWluaW5nKGVuZHRpbWUpO1xuXG4gICAgICAgIGlmICh0LnRvdGFsIDwgMCkge1xuICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aW1laW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBkYXlzU3Bhbi5pbm5lckhUTUwgPSB0LmRheXM7XG4gICAgICAgIGhvdXJzU3Bhbi5pbm5lckhUTUwgPSAoJzAnICsgdC5ob3Vycykuc2xpY2UoLTIpO1xuICAgICAgICBtaW51dGVzU3Bhbi5pbm5lckhUTUwgPSAoJzAnICsgdC5taW51dGVzKS5zbGljZSgtMik7XG4gICAgICAgIHNlY29uZHNTcGFuLmlubmVySFRNTCA9ICgnMCcgKyB0LnNlY29uZHMpLnNsaWNlKC0yKTtcbiAgICB9XG5cbiAgICB1cGRhdGVDbG9jaygpO1xuICAgIGNvbnN0IHRpbWVpbnRlcnZhbCA9IHNldEludGVydmFsKHVwZGF0ZUNsb2NrLCAxMDAwKTtcbn1cblxuZnVuY3Rpb24gcnVjc3NUaW1lcihpZCwgZW5kdGltZSkge1xuXHRjb25zdCB0aW1lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcblx0Y29uc3Qgbm90aWNlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JvY2tldC1ub3RpY2Utc2Fhcy1wcm9jZXNzaW5nJyk7XG5cdGNvbnN0IHN1Y2Nlc3MgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9ja2V0LW5vdGljZS1zYWFzLXN1Y2Nlc3MnKTtcblxuXHRpZiAodGltZXIgPT09IG51bGwpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHRmdW5jdGlvbiB1cGRhdGVUaW1lcigpIHtcblx0XHRjb25zdCBzdGFydCA9IERhdGUubm93KCk7XG5cdFx0Y29uc3QgcmVtYWluaW5nID0gTWF0aC5mbG9vciggKCAoZW5kdGltZSAqIDEwMDApIC0gc3RhcnQgKSAvIDEwMDAgKTtcblxuXHRcdGlmIChyZW1haW5pbmcgPD0gMCkge1xuXHRcdFx0Y2xlYXJJbnRlcnZhbCh0aW1lckludGVydmFsKTtcblxuXHRcdFx0aWYgKG5vdGljZSAhPT0gbnVsbCkge1xuXHRcdFx0XHRub3RpY2UuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG5cdFx0XHR9XG5cblx0XHRcdGlmIChzdWNjZXNzICE9PSBudWxsKSB7XG5cdFx0XHRcdHN1Y2Nlc3MuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG5cdFx0XHR9XG5cblx0XHRcdGlmICggcm9ja2V0X2FqYXhfZGF0YS5jcm9uX2Rpc2FibGVkICkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGRhdGEgPSBuZXcgRm9ybURhdGEoKTtcblxuXHRcdFx0ZGF0YS5hcHBlbmQoICdhY3Rpb24nLCAncm9ja2V0X3NwYXduX2Nyb24nICk7XG5cdFx0XHRkYXRhLmFwcGVuZCggJ25vbmNlJywgcm9ja2V0X2FqYXhfZGF0YS5ub25jZSApO1xuXG5cdFx0XHRmZXRjaCggYWpheHVybCwge1xuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdFx0Y3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbicsXG5cdFx0XHRcdGJvZHk6IGRhdGFcblx0XHRcdH0gKTtcblxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdHRpbWVyLmlubmVySFRNTCA9IHJlbWFpbmluZztcblx0fVxuXG5cdHVwZGF0ZVRpbWVyKCk7XG5cdGNvbnN0IHRpbWVySW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCggdXBkYXRlVGltZXIsIDEwMDApO1xufVxuXG5pZiAoIURhdGUubm93KSB7XG4gICAgRGF0ZS5ub3cgPSBmdW5jdGlvbiBub3coKSB7XG4gICAgICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgfTtcbn1cblxuaWYgKHR5cGVvZiByb2NrZXRfYWpheF9kYXRhLnByb21vX2VuZCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBpbml0aWFsaXplQ2xvY2soJ3JvY2tldC1wcm9tby1jb3VudGRvd24nLCByb2NrZXRfYWpheF9kYXRhLnByb21vX2VuZCk7XG59XG5cbmlmICh0eXBlb2Ygcm9ja2V0X2FqYXhfZGF0YS5saWNlbnNlX2V4cGlyYXRpb24gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgaW5pdGlhbGl6ZUNsb2NrKCdyb2NrZXQtcmVuZXctY291bnRkb3duJywgcm9ja2V0X2FqYXhfZGF0YS5saWNlbnNlX2V4cGlyYXRpb24pO1xufVxuXG5pZiAodHlwZW9mIHJvY2tldF9hamF4X2RhdGEubm90aWNlX2VuZF90aW1lICE9PSAndW5kZWZpbmVkJykge1xuICAgIHJ1Y3NzVGltZXIoJ3JvY2tldC1ydWNzcy10aW1lcicsIHJvY2tldF9hamF4X2RhdGEubm90aWNlX2VuZF90aW1lKTtcbn0iLCJpbXBvcnQgJy4uL2N1c3RvbS9jdXN0b20tc2VsZWN0LmpzJztcblxudmFyICQgPSBqUXVlcnk7XG4kKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpe1xuXG5cbiAgICAvKioqXG4gICAgKiBDaGVjayBwYXJlbnQgLyBzaG93IGNoaWxkcmVuXG4gICAgKioqL1xuXG5cdGZ1bmN0aW9uIHdwclNob3dDaGlsZHJlbihhRWxlbSl7XG5cdFx0dmFyIHBhcmVudElkLCAkY2hpbGRyZW47XG5cblx0XHRhRWxlbSAgICAgPSAkKCBhRWxlbSApO1xuXHRcdHBhcmVudElkICA9IGFFbGVtLmF0dHIoJ2lkJyk7XG5cdFx0JGNoaWxkcmVuID0gJCgnW2RhdGEtcGFyZW50PVwiJyArIHBhcmVudElkICsgJ1wiXScpO1xuXG5cdFx0Ly8gVGVzdCBjaGVjayBmb3Igc3dpdGNoXG5cdFx0aWYoYUVsZW0uaXMoJzpjaGVja2VkJykpe1xuXHRcdFx0JGNoaWxkcmVuLmFkZENsYXNzKCd3cHItaXNPcGVuJyk7XG5cblx0XHRcdCRjaGlsZHJlbi5lYWNoKGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRpZiAoICQodGhpcykuZmluZCgnaW5wdXRbdHlwZT1jaGVja2JveF0nKS5pcygnOmNoZWNrZWQnKSkge1xuXHRcdFx0XHRcdHZhciBpZCA9ICQodGhpcykuZmluZCgnaW5wdXRbdHlwZT1jaGVja2JveF0nKS5hdHRyKCdpZCcpO1xuXG5cdFx0XHRcdFx0JCgnW2RhdGEtcGFyZW50PVwiJyArIGlkICsgJ1wiXScpLmFkZENsYXNzKCd3cHItaXNPcGVuJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH1cblx0XHRlbHNle1xuXHRcdFx0JGNoaWxkcmVuLnJlbW92ZUNsYXNzKCd3cHItaXNPcGVuJyk7XG5cblx0XHRcdCRjaGlsZHJlbi5lYWNoKGZ1bmN0aW9uKCkge1xuXHRcdFx0XHR2YXIgaWQgPSAkKHRoaXMpLmZpbmQoJ2lucHV0W3R5cGU9Y2hlY2tib3hdJykuYXR0cignaWQnKTtcblxuXHRcdFx0XHQkKCdbZGF0YS1wYXJlbnQ9XCInICsgaWQgKyAnXCJdJykucmVtb3ZlQ2xhc3MoJ3dwci1pc09wZW4nKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXG4gICAgLyoqXG4gICAgICogVGVsbCBpZiB0aGUgZ2l2ZW4gY2hpbGQgZmllbGQgaGFzIGFuIGFjdGl2ZSBwYXJlbnQgZmllbGQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gIG9iamVjdCAkZmllbGQgQSBqUXVlcnkgb2JqZWN0IG9mIGEgXCIud3ByLWZpZWxkXCIgZmllbGQuXG4gICAgICogQHJldHVybiBib29sfG51bGxcbiAgICAgKi9cbiAgICBmdW5jdGlvbiB3cHJJc1BhcmVudEFjdGl2ZSggJGZpZWxkICkge1xuICAgICAgICB2YXIgJHBhcmVudDtcblxuICAgICAgICBpZiAoICEgJGZpZWxkLmxlbmd0aCApIHtcbiAgICAgICAgICAgIC8vIMKvXFxfKOODhClfL8KvXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgICRwYXJlbnQgPSAkZmllbGQuZGF0YSggJ3BhcmVudCcgKTtcblxuICAgICAgICBpZiAoIHR5cGVvZiAkcGFyZW50ICE9PSAnc3RyaW5nJyApIHtcbiAgICAgICAgICAgIC8vIFRoaXMgZmllbGQgaGFzIG5vIHBhcmVudCBmaWVsZDogdGhlbiB3ZSBjYW4gZGlzcGxheSBpdC5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgJHBhcmVudCA9ICRwYXJlbnQucmVwbGFjZSggL15cXHMrfFxccyskL2csICcnICk7XG5cbiAgICAgICAgaWYgKCAnJyA9PT0gJHBhcmVudCApIHtcbiAgICAgICAgICAgIC8vIFRoaXMgZmllbGQgaGFzIG5vIHBhcmVudCBmaWVsZDogdGhlbiB3ZSBjYW4gZGlzcGxheSBpdC5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgJHBhcmVudCA9ICQoICcjJyArICRwYXJlbnQgKTtcblxuICAgICAgICBpZiAoICEgJHBhcmVudC5sZW5ndGggKSB7XG4gICAgICAgICAgICAvLyBUaGlzIGZpZWxkJ3MgcGFyZW50IGlzIG1pc3Npbmc6IGxldCdzIGNvbnNpZGVyIGl0J3Mgbm90IGFjdGl2ZSB0aGVuLlxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCAhICRwYXJlbnQuaXMoICc6Y2hlY2tlZCcgKSAmJiAkcGFyZW50LmlzKCdpbnB1dCcpKSB7XG4gICAgICAgICAgICAvLyBUaGlzIGZpZWxkJ3MgcGFyZW50IGlzIGNoZWNrYm94IGFuZCBub3QgY2hlY2tlZDogZG9uJ3QgZGlzcGxheSB0aGUgZmllbGQgdGhlbi5cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG5cdFx0aWYgKCAhJHBhcmVudC5oYXNDbGFzcygncmFkaW8tYWN0aXZlJykgJiYgJHBhcmVudC5pcygnYnV0dG9uJykpIHtcblx0XHRcdC8vIFRoaXMgZmllbGQncyBwYXJlbnQgYnV0dG9uIGFuZCBpcyBub3QgYWN0aXZlOiBkb24ndCBkaXNwbGF5IHRoZSBmaWVsZCB0aGVuLlxuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cbiAgICAgICAgLy8gR28gcmVjdXJzaXZlIHRvIHRoZSBsYXN0IHBhcmVudC5cbiAgICAgICAgcmV0dXJuIHdwcklzUGFyZW50QWN0aXZlKCAkcGFyZW50LmNsb3Nlc3QoICcud3ByLWZpZWxkJyApICk7XG4gICAgfVxuXG5cdC8qKlxuXHQgKiBNYXNrcyBzZW5zaXRpdmUgaW5mb3JtYXRpb24gaW4gYW4gaW5wdXQgZmllbGQgYnkgcmVwbGFjaW5nIGFsbCBidXQgdGhlIGxhc3QgNCBjaGFyYWN0ZXJzIHdpdGggYXN0ZXJpc2tzLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gaWRfc2VsZWN0b3IgLSBUaGUgSUQgb2YgdGhlIGlucHV0IGZpZWxkIHRvIGJlIG1hc2tlZC5cblx0ICogQHJldHVybnMge3ZvaWR9IC0gTW9kaWZpZXMgdGhlIGlucHV0IGZpZWxkIHZhbHVlIGluLXBsYWNlLlxuXHQgKlxuXHQgKiBAZXhhbXBsZVxuXHQgKiAvLyBIVE1MOiA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cImNyZWRpdENhcmRJbnB1dFwiIHZhbHVlPVwiMTIzNDU2Nzg5MDEyMzQ1NlwiPlxuXHQgKiBtYXNrRmllbGQoJ2NyZWRpdENhcmRJbnB1dCcpO1xuXHQgKiAvLyBSZXN1bHQ6IFVwZGF0ZXMgdGhlIGlucHV0IGZpZWxkIHZhbHVlIHRvICcqKioqKioqKioqKiozNDU2Jy5cblx0ICovXG5cdGZ1bmN0aW9uIG1hc2tGaWVsZChwcm94eV9zZWxlY3RvciwgY29uY3JldGVfc2VsZWN0b3IpIHtcblx0XHR2YXIgY29uY3JldGUgPSB7XG5cdFx0XHQndmFsJzogY29uY3JldGVfc2VsZWN0b3IudmFsKCksXG5cdFx0XHQnbGVuZ3RoJzogY29uY3JldGVfc2VsZWN0b3IudmFsKCkubGVuZ3RoXG5cdFx0fVxuXG5cdFx0aWYgKGNvbmNyZXRlLmxlbmd0aCA+IDQpIHtcblxuXHRcdFx0dmFyIGhpZGRlblBhcnQgPSAnXFx1MjAyMicucmVwZWF0KE1hdGgubWF4KDAsIGNvbmNyZXRlLmxlbmd0aCAtIDQpKTtcblx0XHRcdHZhciB2aXNpYmxlUGFydCA9IGNvbmNyZXRlLnZhbC5zbGljZSgtNCk7XG5cblx0XHRcdC8vIENvbWJpbmUgdGhlIGhpZGRlbiBhbmQgdmlzaWJsZSBwYXJ0c1xuXHRcdFx0dmFyIG1hc2tlZFZhbHVlID0gaGlkZGVuUGFydCArIHZpc2libGVQYXJ0O1xuXG5cdFx0XHRwcm94eV9zZWxlY3Rvci52YWwobWFza2VkVmFsdWUpO1xuXHRcdH1cblx0XHQvLyBFbnN1cmUgZXZlbnRzIGFyZSBub3QgYWRkZWQgbW9yZSB0aGFuIG9uY2Vcblx0XHRpZiAoIXByb3h5X3NlbGVjdG9yLmRhdGEoJ2V2ZW50c0F0dGFjaGVkJykpIHtcblx0XHRcdHByb3h5X3NlbGVjdG9yLm9uKCdpbnB1dCcsIGhhbmRsZUlucHV0KTtcblx0XHRcdHByb3h5X3NlbGVjdG9yLm9uKCdmb2N1cycsIGhhbmRsZUZvY3VzKTtcblx0XHRcdHByb3h5X3NlbGVjdG9yLmRhdGEoJ2V2ZW50c0F0dGFjaGVkJywgdHJ1ZSk7XG5cdFx0fVxuXG5cdFx0LyoqXG5cdFx0ICogSGFuZGxlIHRoZSBpbnB1dCBldmVudFxuXHRcdCAqL1xuXHRcdGZ1bmN0aW9uIGhhbmRsZUlucHV0KCkge1xuXHRcdFx0dmFyIHByb3h5VmFsdWUgPSBwcm94eV9zZWxlY3Rvci52YWwoKTtcblx0XHRcdGlmIChwcm94eVZhbHVlLmluZGV4T2YoJ1xcdTIwMjInKSA9PT0gLTEpIHtcblx0XHRcdFx0Y29uY3JldGVfc2VsZWN0b3IudmFsKHByb3h5VmFsdWUpO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8qKlxuXHRcdCAqIEhhbmRsZSB0aGUgZm9jdXMgZXZlbnRcblx0XHQgKi9cblx0XHRmdW5jdGlvbiBoYW5kbGVGb2N1cygpIHtcblx0XHRcdHZhciBjb25jcmV0ZV92YWx1ZSA9IGNvbmNyZXRlX3NlbGVjdG9yLnZhbCgpO1xuXHRcdFx0cHJveHlfc2VsZWN0b3IudmFsKGNvbmNyZXRlX3ZhbHVlKTtcblx0XHR9XG5cblx0fVxuXG5cdFx0Ly8gVXBkYXRlIHRoZSBjb25jcmV0ZSBmaWVsZCB3aGVuIHRoZSBwcm94eSBpcyB1cGRhdGVkLlxuXG5cblx0bWFza0ZpZWxkKCQoJyNjbG91ZGZsYXJlX2FwaV9rZXlfbWFzaycpLCAkKCcjY2xvdWRmbGFyZV9hcGlfa2V5JykpO1xuXHRtYXNrRmllbGQoJCgnI2Nsb3VkZmxhcmVfem9uZV9pZF9tYXNrJyksICQoJyNjbG91ZGZsYXJlX3pvbmVfaWQnKSk7XG5cblx0Ly8gRGlzcGxheS9IaWRlIGNoaWxkcmVuIGZpZWxkcyBvbiBjaGVja2JveCBjaGFuZ2UuXG4gICAgJCggJy53cHItaXNQYXJlbnQgaW5wdXRbdHlwZT1jaGVja2JveF0nICkub24oJ2NoYW5nZScsIGZ1bmN0aW9uKCkge1xuICAgICAgICB3cHJTaG93Q2hpbGRyZW4oJCh0aGlzKSk7XG4gICAgfSk7XG5cbiAgICAvLyBPbiBwYWdlIGxvYWQsIGRpc3BsYXkgdGhlIGFjdGl2ZSBmaWVsZHMuXG4gICAgJCggJy53cHItZmllbGQtLWNoaWxkcmVuJyApLmVhY2goIGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgJGZpZWxkID0gJCggdGhpcyApO1xuXG4gICAgICAgIGlmICggd3BySXNQYXJlbnRBY3RpdmUoICRmaWVsZCApICkge1xuICAgICAgICAgICAgJGZpZWxkLmFkZENsYXNzKCAnd3ByLWlzT3BlbicgKTtcbiAgICAgICAgfVxuICAgIH0gKTtcblxuXG5cblxuICAgIC8qKipcbiAgICAqIFdhcm5pbmcgZmllbGRzXG4gICAgKioqL1xuXG4gICAgdmFyICR3YXJuaW5nUGFyZW50ID0gJCgnLndwci1maWVsZC0tcGFyZW50Jyk7XG4gICAgdmFyICR3YXJuaW5nUGFyZW50SW5wdXQgPSAkKCcud3ByLWZpZWxkLS1wYXJlbnQgaW5wdXRbdHlwZT1jaGVja2JveF0nKTtcblxuICAgIC8vIElmIGFscmVhZHkgY2hlY2tlZFxuICAgICR3YXJuaW5nUGFyZW50SW5wdXQuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICB3cHJTaG93Q2hpbGRyZW4oJCh0aGlzKSk7XG4gICAgfSk7XG5cbiAgICAkd2FybmluZ1BhcmVudC5vbignY2hhbmdlJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIHdwclNob3dXYXJuaW5nKCQodGhpcykpO1xuICAgIH0pO1xuXG4gICAgZnVuY3Rpb24gd3ByU2hvd1dhcm5pbmcoYUVsZW0pe1xuICAgICAgICB2YXIgJHdhcm5pbmdGaWVsZCA9IGFFbGVtLm5leHQoJy53cHItZmllbGRXYXJuaW5nJyksXG4gICAgICAgICAgICAkdGhpc0NoZWNrYm94ID0gYUVsZW0uZmluZCgnaW5wdXRbdHlwZT1jaGVja2JveF0nKSxcbiAgICAgICAgICAgICRuZXh0V2FybmluZyA9IGFFbGVtLnBhcmVudCgpLm5leHQoJy53cHItd2FybmluZ0NvbnRhaW5lcicpLFxuICAgICAgICAgICAgJG5leHRGaWVsZHMgPSAkbmV4dFdhcm5pbmcuZmluZCgnLndwci1maWVsZCcpLFxuICAgICAgICAgICAgcGFyZW50SWQgPSBhRWxlbS5maW5kKCdpbnB1dFt0eXBlPWNoZWNrYm94XScpLmF0dHIoJ2lkJyksXG4gICAgICAgICAgICAkY2hpbGRyZW4gPSAkKCdbZGF0YS1wYXJlbnQ9XCInICsgcGFyZW50SWQgKyAnXCJdJylcbiAgICAgICAgO1xuXG4gICAgICAgIC8vIENoZWNrIHdhcm5pbmcgcGFyZW50XG4gICAgICAgIGlmKCR0aGlzQ2hlY2tib3guaXMoJzpjaGVja2VkJykpe1xuICAgICAgICAgICAgJHdhcm5pbmdGaWVsZC5hZGRDbGFzcygnd3ByLWlzT3BlbicpO1xuICAgICAgICAgICAgJHRoaXNDaGVja2JveC5wcm9wKCdjaGVja2VkJywgZmFsc2UpO1xuICAgICAgICAgICAgYUVsZW0udHJpZ2dlcignY2hhbmdlJyk7XG5cblxuICAgICAgICAgICAgdmFyICR3YXJuaW5nQnV0dG9uID0gJHdhcm5pbmdGaWVsZC5maW5kKCcud3ByLWJ1dHRvbicpO1xuXG4gICAgICAgICAgICAvLyBWYWxpZGF0ZSB0aGUgd2FybmluZ1xuICAgICAgICAgICAgJHdhcm5pbmdCdXR0b24ub24oJ2NsaWNrJywgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAkdGhpc0NoZWNrYm94LnByb3AoJ2NoZWNrZWQnLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAkd2FybmluZ0ZpZWxkLnJlbW92ZUNsYXNzKCd3cHItaXNPcGVuJyk7XG4gICAgICAgICAgICAgICAgJGNoaWxkcmVuLmFkZENsYXNzKCd3cHItaXNPcGVuJyk7XG5cbiAgICAgICAgICAgICAgICAvLyBJZiBuZXh0IGVsZW0gPSBkaXNhYmxlZFxuICAgICAgICAgICAgICAgIGlmKCRuZXh0V2FybmluZy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgJG5leHRGaWVsZHMucmVtb3ZlQ2xhc3MoJ3dwci1pc0Rpc2FibGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICRuZXh0RmllbGRzLmZpbmQoJ2lucHV0JykucHJvcCgnZGlzYWJsZWQnLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICRuZXh0RmllbGRzLmFkZENsYXNzKCd3cHItaXNEaXNhYmxlZCcpO1xuICAgICAgICAgICAgJG5leHRGaWVsZHMuZmluZCgnaW5wdXQnKS5wcm9wKCdkaXNhYmxlZCcsIHRydWUpO1xuICAgICAgICAgICAgJG5leHRGaWVsZHMuZmluZCgnaW5wdXRbdHlwZT1jaGVja2JveF0nKS5wcm9wKCdjaGVja2VkJywgZmFsc2UpO1xuICAgICAgICAgICAgJGNoaWxkcmVuLnJlbW92ZUNsYXNzKCd3cHItaXNPcGVuJyk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDTkFNRVMgYWRkL3JlbW92ZSBsaW5lc1xuICAgICAqL1xuICAgICQoZG9jdW1lbnQpLm9uKCdjbGljaycsICcud3ByLW11bHRpcGxlLWNsb3NlJywgZnVuY3Rpb24oZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHQkKHRoaXMpLnBhcmVudCgpLnJlbW92ZSgpO1xuXHR9ICk7XG5cblx0JCgnLndwci1idXR0b24tLWFkZE11bHRpJykub24oJ2NsaWNrJywgZnVuY3Rpb24oZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgJCgkKCcjd3ByLWNuYW1lLW1vZGVsJykuaHRtbCgpKS5hcHBlbmRUbygnI3dwci1jbmFtZXMtbGlzdCcpO1xuICAgIH0pO1xuXG5cdC8qKipcblx0ICogV3ByIFJhZGlvIGJ1dHRvblxuXHQgKioqL1xuXHR2YXIgZGlzYWJsZV9yYWRpb193YXJuaW5nID0gZmFsc2U7XG5cblx0JChkb2N1bWVudCkub24oJ2NsaWNrJywgJy53cHItcmFkaW8tYnV0dG9ucy1jb250YWluZXIgYnV0dG9uJywgZnVuY3Rpb24oZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRpZigkKHRoaXMpLmhhc0NsYXNzKCdyYWRpby1hY3RpdmUnKSl7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHZhciAkcGFyZW50ID0gJCh0aGlzKS5wYXJlbnRzKCcud3ByLXJhZGlvLWJ1dHRvbnMnKTtcblx0XHQkcGFyZW50LmZpbmQoJy53cHItcmFkaW8tYnV0dG9ucy1jb250YWluZXIgYnV0dG9uJykucmVtb3ZlQ2xhc3MoJ3JhZGlvLWFjdGl2ZScpO1xuXHRcdCRwYXJlbnQuZmluZCgnLndwci1leHRyYS1maWVsZHMtY29udGFpbmVyJykucmVtb3ZlQ2xhc3MoJ3dwci1pc09wZW4nKTtcblx0XHQkcGFyZW50LmZpbmQoJy53cHItZmllbGRXYXJuaW5nJykucmVtb3ZlQ2xhc3MoJ3dwci1pc09wZW4nKTtcblx0XHQkKHRoaXMpLmFkZENsYXNzKCdyYWRpby1hY3RpdmUnKTtcblx0XHR3cHJTaG93UmFkaW9XYXJuaW5nKCQodGhpcykpO1xuXG5cdH0gKTtcblxuXG5cdGZ1bmN0aW9uIHdwclNob3dSYWRpb1dhcm5pbmcoJGVsbSl7XG5cdFx0ZGlzYWJsZV9yYWRpb193YXJuaW5nID0gZmFsc2U7XG5cdFx0JGVsbS50cmlnZ2VyKCBcImJlZm9yZV9zaG93X3JhZGlvX3dhcm5pbmdcIiwgWyAkZWxtIF0gKTtcblx0XHRpZiAoISRlbG0uaGFzQ2xhc3MoJ2hhcy13YXJuaW5nJykgfHwgZGlzYWJsZV9yYWRpb193YXJuaW5nKSB7XG5cdFx0XHR3cHJTaG93UmFkaW9CdXR0b25DaGlsZHJlbigkZWxtKTtcblx0XHRcdCRlbG0udHJpZ2dlciggXCJyYWRpb19idXR0b25fc2VsZWN0ZWRcIiwgWyAkZWxtIF0gKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0dmFyICR3YXJuaW5nRmllbGQgPSAkKCdbZGF0YS1wYXJlbnQ9XCInICsgJGVsbS5hdHRyKCdpZCcpICsgJ1wiXS53cHItZmllbGRXYXJuaW5nJyk7XG5cdFx0JHdhcm5pbmdGaWVsZC5hZGRDbGFzcygnd3ByLWlzT3BlbicpO1xuXHRcdHZhciAkd2FybmluZ0J1dHRvbiA9ICR3YXJuaW5nRmllbGQuZmluZCgnLndwci1idXR0b24nKTtcblxuXHRcdC8vIFZhbGlkYXRlIHRoZSB3YXJuaW5nXG5cdFx0JHdhcm5pbmdCdXR0b24ub24oJ2NsaWNrJywgZnVuY3Rpb24oKXtcblx0XHRcdCR3YXJuaW5nRmllbGQucmVtb3ZlQ2xhc3MoJ3dwci1pc09wZW4nKTtcblx0XHRcdHdwclNob3dSYWRpb0J1dHRvbkNoaWxkcmVuKCRlbG0pO1xuXHRcdFx0JGVsbS50cmlnZ2VyKCBcInJhZGlvX2J1dHRvbl9zZWxlY3RlZFwiLCBbICRlbG0gXSApO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH0pO1xuXHR9XG5cblx0ZnVuY3Rpb24gd3ByU2hvd1JhZGlvQnV0dG9uQ2hpbGRyZW4oJGVsbSkge1xuXHRcdHZhciAkcGFyZW50ID0gJGVsbS5wYXJlbnRzKCcud3ByLXJhZGlvLWJ1dHRvbnMnKTtcblx0XHR2YXIgJGNoaWxkcmVuID0gJCgnLndwci1leHRyYS1maWVsZHMtY29udGFpbmVyW2RhdGEtcGFyZW50PVwiJyArICRlbG0uYXR0cignaWQnKSArICdcIl0nKTtcblx0XHQkY2hpbGRyZW4uYWRkQ2xhc3MoJ3dwci1pc09wZW4nKTtcblx0fVxuXG5cdC8qKipcblx0ICogV3ByIE9wdGltaXplIENzcyBEZWxpdmVyeSBGaWVsZFxuXHQgKioqL1xuXHR2YXIgcnVjc3NBY3RpdmUgPSBwYXJzZUludCgkKCcjcmVtb3ZlX3VudXNlZF9jc3MnKS52YWwoKSk7XG5cblx0JCggXCIjb3B0aW1pemVfY3NzX2RlbGl2ZXJ5X21ldGhvZCAud3ByLXJhZGlvLWJ1dHRvbnMtY29udGFpbmVyIGJ1dHRvblwiIClcblx0XHQub24oIFwicmFkaW9fYnV0dG9uX3NlbGVjdGVkXCIsIGZ1bmN0aW9uKCBldmVudCwgJGVsbSApIHtcblx0XHRcdHRvZ2dsZUFjdGl2ZU9wdGltaXplQ3NzRGVsaXZlcnlNZXRob2QoJGVsbSk7XG5cdFx0fSk7XG5cblx0JChcIiNvcHRpbWl6ZV9jc3NfZGVsaXZlcnlcIikub24oXCJjaGFuZ2VcIiwgZnVuY3Rpb24oKXtcblx0XHRpZiggJCh0aGlzKS5pcyhcIjpub3QoOmNoZWNrZWQpXCIpICl7XG5cdFx0XHRkaXNhYmxlT3B0aW1pemVDc3NEZWxpdmVyeSgpO1xuXHRcdH1lbHNle1xuXHRcdFx0dmFyIGRlZmF1bHRfcmFkaW9fYnV0dG9uX2lkID0gJyMnKyQoJyNvcHRpbWl6ZV9jc3NfZGVsaXZlcnlfbWV0aG9kJykuZGF0YSggJ2RlZmF1bHQnICk7XG5cdFx0XHQkKGRlZmF1bHRfcmFkaW9fYnV0dG9uX2lkKS50cmlnZ2VyKCdjbGljaycpO1xuXHRcdH1cblx0fSk7XG5cblx0ZnVuY3Rpb24gdG9nZ2xlQWN0aXZlT3B0aW1pemVDc3NEZWxpdmVyeU1ldGhvZCgkZWxtKSB7XG5cdFx0dmFyIG9wdGltaXplX21ldGhvZCA9ICRlbG0uZGF0YSgndmFsdWUnKTtcblx0XHRpZigncmVtb3ZlX3VudXNlZF9jc3MnID09PSBvcHRpbWl6ZV9tZXRob2Qpe1xuXHRcdFx0JCgnI3JlbW92ZV91bnVzZWRfY3NzJykudmFsKDEpO1xuXHRcdFx0JCgnI2FzeW5jX2NzcycpLnZhbCgwKTtcblx0XHR9ZWxzZXtcblx0XHRcdCQoJyNyZW1vdmVfdW51c2VkX2NzcycpLnZhbCgwKTtcblx0XHRcdCQoJyNhc3luY19jc3MnKS52YWwoMSk7XG5cdFx0fVxuXG5cdH1cblxuXHRmdW5jdGlvbiBkaXNhYmxlT3B0aW1pemVDc3NEZWxpdmVyeSgpIHtcblx0XHQkKCcjcmVtb3ZlX3VudXNlZF9jc3MnKS52YWwoMCk7XG5cdFx0JCgnI2FzeW5jX2NzcycpLnZhbCgwKTtcblx0fVxuXG5cdCQoIFwiI29wdGltaXplX2Nzc19kZWxpdmVyeV9tZXRob2QgLndwci1yYWRpby1idXR0b25zLWNvbnRhaW5lciBidXR0b25cIiApXG5cdFx0Lm9uKCBcImJlZm9yZV9zaG93X3JhZGlvX3dhcm5pbmdcIiwgZnVuY3Rpb24oIGV2ZW50LCAkZWxtICkge1xuXHRcdFx0ZGlzYWJsZV9yYWRpb193YXJuaW5nID0gKCdyZW1vdmVfdW51c2VkX2NzcycgPT09ICRlbG0uZGF0YSgndmFsdWUnKSAmJiAxID09PSBydWNzc0FjdGl2ZSlcblx0XHR9KTtcblxuXHQkKCBcIi53cHItbXVsdGlwbGUtc2VsZWN0IC53cHItbGlzdC1oZWFkZXJcIiApLmNsaWNrKGZ1bmN0aW9uIChlKSB7XG5cdFx0JChlLnRhcmdldCkuY2xvc2VzdCgnLndwci1tdWx0aXBsZS1zZWxlY3QgLndwci1saXN0JykudG9nZ2xlQ2xhc3MoJ29wZW4nKTtcblx0fSk7XG5cblx0JCgnLndwci1tdWx0aXBsZS1zZWxlY3QgLndwci1jaGVja2JveCcpLmNsaWNrKGZ1bmN0aW9uIChlKSB7XG5cdFx0Y29uc3QgY2hlY2tib3ggPSAkKHRoaXMpLmZpbmQoJ2lucHV0Jyk7XG5cdFx0Y29uc3QgaXNfY2hlY2tlZCA9IGNoZWNrYm94LmF0dHIoJ2NoZWNrZWQnKSAhPT0gdW5kZWZpbmVkO1xuXHRcdGNoZWNrYm94LmF0dHIoJ2NoZWNrZWQnLCBpc19jaGVja2VkID8gbnVsbCA6ICdjaGVja2VkJyApO1xuXHRcdGNvbnN0IHN1Yl9jaGVja2JveGVzID0gJChjaGVja2JveCkuY2xvc2VzdCgnLndwci1saXN0JykuZmluZCgnLndwci1saXN0LWJvZHkgaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdJyk7XG5cdFx0aWYoY2hlY2tib3guaGFzQ2xhc3MoJ3dwci1tYWluLWNoZWNrYm94JykpIHtcblx0XHRcdCQubWFwKHN1Yl9jaGVja2JveGVzLCBjaGVja2JveCA9PiB7XG5cdFx0XHRcdCQoY2hlY2tib3gpLmF0dHIoJ2NoZWNrZWQnLCBpc19jaGVja2VkID8gbnVsbCA6ICdjaGVja2VkJyApO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IG1haW5fY2hlY2tib3ggPSAkKGNoZWNrYm94KS5jbG9zZXN0KCcud3ByLWxpc3QnKS5maW5kKCcud3ByLW1haW4tY2hlY2tib3gnKTtcblxuXHRcdGNvbnN0IHN1Yl9jaGVja2VkID0gICQubWFwKHN1Yl9jaGVja2JveGVzLCBjaGVja2JveCA9PiB7XG5cdFx0XHRpZigkKGNoZWNrYm94KS5hdHRyKCdjaGVja2VkJykgPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRyZXR1cm4gO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGNoZWNrYm94O1xuXHRcdH0pO1xuXHRcdG1haW5fY2hlY2tib3guYXR0cignY2hlY2tlZCcsIHN1Yl9jaGVja2VkLmxlbmd0aCA9PT0gc3ViX2NoZWNrYm94ZXMubGVuZ3RoID8gJ2NoZWNrZWQnIDogbnVsbCApO1xuXHR9KTtcblxuXHRpZiAoICQoICcud3ByLW1haW4tY2hlY2tib3gnICkubGVuZ3RoID4gMCApIHtcblx0XHQkKCcud3ByLW1haW4tY2hlY2tib3gnKS5lYWNoKChjaGVja2JveF9rZXksIGNoZWNrYm94KSA9PiB7XG5cdFx0XHRsZXQgcGFyZW50X2xpc3QgPSAkKGNoZWNrYm94KS5wYXJlbnRzKCcud3ByLWxpc3QnKTtcblx0XHRcdGxldCBub3RfY2hlY2tlZCA9IHBhcmVudF9saXN0LmZpbmQoICcud3ByLWxpc3QtYm9keSBpbnB1dFt0eXBlPWNoZWNrYm94XTpub3QoOmNoZWNrZWQpJyApLmxlbmd0aDtcblx0XHRcdCQoY2hlY2tib3gpLmF0dHIoJ2NoZWNrZWQnLCBub3RfY2hlY2tlZCA8PSAwID8gJ2NoZWNrZWQnIDogbnVsbCApO1xuXHRcdH0pO1xuXHR9XG5cblx0bGV0IGNoZWNrQm94Q291bnRlciA9IHtcblx0XHRjaGVja2VkOiB7fSxcblx0XHR0b3RhbDoge31cblx0fTtcblx0JCgnLndwci1maWVsZC0tY2F0ZWdvcml6ZWRtdWx0aXNlbGVjdCAud3ByLWxpc3QnKS5lYWNoKGZ1bmN0aW9uICgpIHtcblx0XHQvLyBHZXQgdGhlIElEIG9mIHRoZSBjdXJyZW50IGVsZW1lbnRcblx0XHRsZXQgaWQgPSAkKHRoaXMpLmF0dHIoJ2lkJyk7XG5cdFx0aWYgKGlkKSB7XG5cdFx0XHRjaGVja0JveENvdW50ZXIuY2hlY2tlZFtpZF0gPSAkKGAjJHtpZH0gaW5wdXRbdHlwZT0nY2hlY2tib3gnXTpjaGVja2VkYCkubGVuZ3RoO1xuXHRcdFx0Y2hlY2tCb3hDb3VudGVyLnRvdGFsW2lkXSA9ICQoYCMke2lkfSBpbnB1dFt0eXBlPSdjaGVja2JveCddOm5vdCgud3ByLW1haW4tY2hlY2tib3gpYCkubGVuZ3RoO1xuXHRcdFx0Ly8gVXBkYXRlIHRoZSBjb3VudGVyIHRleHRcblx0XHRcdCQoYCMke2lkfSAud3ByLWJhZGdlLWNvdW50ZXIgc3BhbmApLnRleHQoY2hlY2tCb3hDb3VudGVyLmNoZWNrZWRbaWRdKTtcblx0XHRcdC8vIFNob3cgb3IgaGlkZSB0aGUgY291bnRlciBiYWRnZSBiYXNlZCBvbiB0aGUgY291bnRcblx0XHRcdCQoYCMke2lkfSAud3ByLWJhZGdlLWNvdW50ZXJgKS50b2dnbGUoY2hlY2tCb3hDb3VudGVyLmNoZWNrZWRbaWRdID4gMCk7XG5cblx0XHRcdC8vIENoZWNrIHRoZSBzZWxlY3QgYWxsIG9wdGlvbiBpZiBhbGwgZXhjbHVzaW9ucyBhcmUgY2hlY2tlZCBpbiBhIHNlY3Rpb24uXG5cdFx0XHRpZiAoY2hlY2tCb3hDb3VudGVyLmNoZWNrZWRbaWRdID09PSBjaGVja0JveENvdW50ZXIudG90YWxbaWRdKSB7XG5cdFx0XHRcdCQoYCMke2lkfSAud3ByLW1haW4tY2hlY2tib3hgKS5hdHRyKCdjaGVja2VkJywgdHJ1ZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9KTtcblxuXHQvKipcblx0ICogRGVsYXkgSlMgRXhlY3V0aW9uIFNhZmUgTW9kZSBGaWVsZFxuXHQgKi9cblx0dmFyICRkamVfc2FmZV9tb2RlX2NoZWNrYm94ID0gJCgnI2RlbGF5X2pzX2V4ZWN1dGlvbl9zYWZlX21vZGUnKTtcblx0JCgnI2RlbGF5X2pzJykub24oJ2NoYW5nZScsIGZ1bmN0aW9uICgpIHtcblx0XHRpZiAoJCh0aGlzKS5pcygnOm5vdCg6Y2hlY2tlZCknKSAmJiAkZGplX3NhZmVfbW9kZV9jaGVja2JveC5pcygnOmNoZWNrZWQnKSkge1xuXHRcdFx0JGRqZV9zYWZlX21vZGVfY2hlY2tib3gudHJpZ2dlcignY2xpY2snKTtcblx0XHR9XG5cdH0pO1xuXG5cdGxldCBzdGFja2VkX3NlbGVjdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAncm9ja2V0X3N0YWNrZWRfc2VsZWN0JyApO1xuXHRpZiAoIHN0YWNrZWRfc2VsZWN0ICkge1xuXHRcdHN0YWNrZWRfc2VsZWN0LmFkZEV2ZW50TGlzdGVuZXIoJ2N1c3RvbS1zZWxlY3QtY2hhbmdlJyxmdW5jdGlvbihldmVudCl7XG5cblx0XHRcdGxldCBzZWxlY3RlZF9vcHRpb24gPSAkKCBldmVudC5kZXRhaWwuc2VsZWN0ZWRPcHRpb24gKTtcblxuXHRcdFx0bGV0IG5hbWUgPSBzZWxlY3RlZF9vcHRpb24uZGF0YSgnbmFtZScpO1xuXG5cdFx0XHRsZXQgc2F2aW5nID0gc2VsZWN0ZWRfb3B0aW9uLmRhdGEoJ3NhdmluZycpO1xuXHRcdFx0bGV0IHJlZ3VsYXJfcHJpY2UgID0gc2VsZWN0ZWRfb3B0aW9uLmRhdGEoJ3JlZ3VsYXItcHJpY2UnKTtcblx0XHRcdGxldCBwcmljZSAgPSBzZWxlY3RlZF9vcHRpb24uZGF0YSgncHJpY2UnKTtcblx0XHRcdGxldCB1cmwgICAgPSBzZWxlY3RlZF9vcHRpb24uZGF0YSgndXJsJyk7XG5cblx0XHRcdGxldCBwYXJlbnRfaXRlbSA9ICQodGhpcykucGFyZW50cyggJy53cHItdXBncmFkZS1pdGVtJyApO1xuXG5cdFx0XHRpZiAoIHNhdmluZyApIHtcblx0XHRcdFx0cGFyZW50X2l0ZW0uZmluZCggJy53cHItdXBncmFkZS1zYXZpbmcgc3BhbicgKS5odG1sKCBzYXZpbmcgKTtcblx0XHRcdH1cblx0XHRcdGlmICggbmFtZSApIHtcblx0XHRcdFx0cGFyZW50X2l0ZW0uZmluZCggJy53cHItdXBncmFkZS10aXRsZScgKS5odG1sKCBuYW1lICk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIHJlZ3VsYXJfcHJpY2UgKSB7XG5cdFx0XHRcdHBhcmVudF9pdGVtLmZpbmQoICcud3ByLXVwZ3JhZGUtcHJpY2UtcmVndWxhciBzcGFuJyApLmh0bWwoIHJlZ3VsYXJfcHJpY2UgKTtcblx0XHRcdH1cblx0XHRcdGlmICggcHJpY2UgKSB7XG5cdFx0XHRcdHBhcmVudF9pdGVtLmZpbmQoICcud3ByLXVwZ3JhZGUtcHJpY2UtdmFsdWUnICkuaHRtbCggcHJpY2UgKTtcblx0XHRcdH1cblx0XHRcdGlmICggdXJsICkge1xuXHRcdFx0XHRwYXJlbnRfaXRlbS5maW5kKCAnLndwci11cGdyYWRlLWxpbmsnICkuYXR0ciggJ2hyZWYnLCB1cmwgKTtcblx0XHRcdH1cblxuXHRcdH0gKTtcblx0fVxuXG5cdCQoZG9jdW1lbnQpLm9uKCAnY2xpY2snLCAnLndwci1jb25maXJtLWRlbGV0ZScsIGZ1bmN0aW9uIChlKSB7XG5cdFx0cmV0dXJuIGNvbmZpcm0oICQodGhpcykuZGF0YSgnd3ByX2NvbmZpcm1fbXNnJykgKTtcblx0fSApO1xuXG59KTtcbiIsInZhciAkID0galF1ZXJ5O1xuJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKXtcblxuXG5cdC8qKipcblx0KiBEYXNoYm9hcmQgbm90aWNlXG5cdCoqKi9cblxuXHR2YXIgJG5vdGljZSA9ICQoJy53cHItbm90aWNlJyk7XG5cdHZhciAkbm90aWNlQ2xvc2UgPSAkKCcjd3ByLWNvbmdyYXR1bGF0aW9ucy1ub3RpY2UnKTtcblxuXHQkbm90aWNlQ2xvc2Uub24oJ2NsaWNrJywgZnVuY3Rpb24oKSB7XG5cdFx0d3ByQ2xvc2VEYXNoYm9hcmROb3RpY2UoKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0pO1xuXG5cdGZ1bmN0aW9uIHdwckNsb3NlRGFzaGJvYXJkTm90aWNlKCl7XG5cdFx0dmFyIHZUTCA9IG5ldyBUaW1lbGluZUxpdGUoKVxuXHRcdCAgLnRvKCRub3RpY2UsIDEsIHthdXRvQWxwaGE6MCwgeDo0MCwgZWFzZTpQb3dlcjQuZWFzZU91dH0pXG5cdFx0ICAudG8oJG5vdGljZSwgMC42LCB7aGVpZ2h0OiAwLCBtYXJnaW5Ub3A6MCwgZWFzZTpQb3dlcjQuZWFzZU91dH0sICc9LS40Jylcblx0XHQgIC5zZXQoJG5vdGljZSwgeydkaXNwbGF5Jzonbm9uZSd9KVxuXHRcdDtcblx0fVxuXG5cdC8qKlxuXHQgKiBSb2NrZXQgQW5hbHl0aWNzIG5vdGljZSBpbmZvIGNvbGxlY3Rcblx0ICovXG5cdCQoICcucm9ja2V0LWFuYWx5dGljcy1kYXRhLWNvbnRhaW5lcicgKS5oaWRlKCk7XG5cdCQoICcucm9ja2V0LXByZXZpZXctYW5hbHl0aWNzLWRhdGEnICkub24oICdjbGljaycsIGZ1bmN0aW9uKCBlICkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblxuXHRcdCQodGhpcykucGFyZW50KCkubmV4dCggJy5yb2NrZXQtYW5hbHl0aWNzLWRhdGEtY29udGFpbmVyJyApLnRvZ2dsZSgpO1xuXHR9ICk7XG5cblx0LyoqKlxuXHQqIEhpZGUgLyBzaG93IFJvY2tldCBhZGRvbiB0YWJzLlxuXHQqKiovXG5cblx0JCggJy53cHItdG9nZ2xlLWJ1dHRvbicgKS5lYWNoKCBmdW5jdGlvbigpIHtcblx0XHR2YXIgJGJ1dHRvbiAgID0gJCggdGhpcyApO1xuXHRcdHZhciAkY2hlY2tib3ggPSAkYnV0dG9uLmNsb3Nlc3QoICcud3ByLWZpZWxkc0NvbnRhaW5lci1maWVsZHNldCcgKS5maW5kKCAnLndwci1yYWRpbyA6Y2hlY2tib3gnICk7XG5cdFx0dmFyICRtZW51SXRlbSA9ICQoICdbaHJlZj1cIicgKyAkYnV0dG9uLmF0dHIoICdocmVmJyApICsgJ1wiXS53cHItbWVudUl0ZW0nICk7XG5cblx0XHQkY2hlY2tib3gub24oJ2NoYW5nZScsIGZ1bmN0aW9uKCkge1xuXHRcdFx0aWYgKCAkY2hlY2tib3guaXMoICc6Y2hlY2tlZCcgKSApIHtcblx0XHRcdFx0JG1lbnVJdGVtLmNzcyggJ2Rpc3BsYXknLCAnYmxvY2snICk7XG5cdFx0XHRcdCRidXR0b24uY3NzKCAnZGlzcGxheScsICdpbmxpbmUtYmxvY2snICk7XG5cdFx0XHR9IGVsc2V7XG5cdFx0XHRcdCRtZW51SXRlbS5jc3MoICdkaXNwbGF5JywgJ25vbmUnICk7XG5cdFx0XHRcdCRidXR0b24uY3NzKCAnZGlzcGxheScsICdub25lJyApO1xuXHRcdFx0fVxuXHRcdH0gKS50cmlnZ2VyKCAnY2hhbmdlJyApO1xuXHR9ICk7XG5cblx0LyoqKlxuXHQqIEhlbHAgQnV0dG9uIFRyYWNraW5nXG5cdCoqKi9cblxuXHQvLyBUcmFjayBjbGlja3Mgb24gdmFyaW91cyBoZWxwIGVsZW1lbnRzIHdpdGggZGF0YSBhdHRyaWJ1dGVzXG5cdCQoZG9jdW1lbnQpLm9uKCdjbGljaycsICdbZGF0YS13cHJfdHJhY2tfaGVscF0nLCBmdW5jdGlvbihlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cud3ByVHJhY2tIZWxwQnV0dG9uID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHR2YXIgJGVsID0gJCh0aGlzKTtcblx0XHRcdHZhciBidXR0b24gPSAkZWwuZGF0YSgnd3ByX3RyYWNrX2hlbHAnKTtcblx0XHRcdHZhciBjb250ZXh0ID0gJGVsLmRhdGEoJ3dwcl90cmFja19jb250ZXh0JykgfHwgJyc7XG5cblx0XHRcdHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24oYnV0dG9uLCBjb250ZXh0KTtcblx0XHR9XG5cdH0pO1xuXG5cdC8vIFRyYWNrIHNwZWNpZmljIGhlbHAgcmVzb3VyY2UgY2xpY2tzIHdpdGggZXhwbGljaXQgc2VsZWN0b3JzXG5cdCQoZG9jdW1lbnQpLm9uKCdjbGljaycsICcud2lzdGlhX2VtYmVkJywgZnVuY3Rpb24oKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cud3ByVHJhY2tIZWxwQnV0dG9uID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHR2YXIgdGl0bGUgPSAkKHRoaXMpLnRleHQoKSB8fCAnR2V0dGluZyBTdGFydGVkIFZpZGVvJztcblx0XHRcdHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24odGl0bGUsICdHZXR0aW5nIFN0YXJ0ZWQnKTtcblx0XHR9XG5cdH0pO1xuXG5cdC8vIFRyYWNrIEZBUSBsaW5rc1xuXHQkKGRvY3VtZW50KS5vbignY2xpY2snLCAnYVtkYXRhLWJlYWNvbi1hcnRpY2xlXScsIGZ1bmN0aW9uKCkge1xuXHRcdGlmICh0eXBlb2Ygd2luZG93LndwclRyYWNrSGVscEJ1dHRvbiA9PT0gJ2Z1bmN0aW9uJykge1xuXHRcdFx0dmFyIGhyZWYgPSAkKHRoaXMpLmF0dHIoJ2hyZWYnKTtcblx0XHRcdHZhciB0ZXh0ID0gJCh0aGlzKS50ZXh0KCk7XG5cblx0XHRcdC8vIENoZWNrIGlmIGl0J3MgaW4gRkFRIHNlY3Rpb24gb3Igc2lkZWJhciBkb2N1bWVudGF0aW9uXG5cdFx0XHRpZiAoJCh0aGlzKS5jbG9zZXN0KCcud3ByLWZpZWxkc0NvbnRhaW5lci1maWVsZHNldCcpLnByZXYoJy53cHItb3B0aW9uSGVhZGVyJykuZmluZCgnLndwci10aXRsZTInKS50ZXh0KCkuaW5jbHVkZXMoJ0ZyZXF1ZW50bHkgQXNrZWQgUXVlc3Rpb25zJykpIHtcblx0XHRcdFx0d2luZG93LndwclRyYWNrSGVscEJ1dHRvbignRkFRIC0gJyArIHRleHQsICdEYXNoYm9hcmQnKTtcblx0XHRcdH0gZWxzZSBpZiAoJCh0aGlzKS5jbG9zZXN0KCcud3ByLWRvY3VtZW50YXRpb24nKS5sZW5ndGggPiAwKSB7XG5cdFx0XHRcdHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24oJ0RvY3VtZW50YXRpb24nLCAnU2lkZWJhcicpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0d2luZG93LndwclRyYWNrSGVscEJ1dHRvbignRG9jdW1lbnRhdGlvbiBMaW5rJywgJ0dlbmVyYWwnKTtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXG5cdC8vIFRyYWNrIFwiSG93IHRvIG1lYXN1cmUgbG9hZGluZyB0aW1lXCIgbGlua1xuXHQkKGRvY3VtZW50KS5vbignY2xpY2snLCAnYVtocmVmKj1cImhvdy10by10ZXN0LXdvcmRwcmVzcy1zaXRlLXBlcmZvcm1hbmNlXCJdJywgZnVuY3Rpb24oKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cud3ByVHJhY2tIZWxwQnV0dG9uID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHR3aW5kb3cud3ByVHJhY2tIZWxwQnV0dG9uKCdMb2FkaW5nIFRpbWUgR3VpZGUnLCAnU2lkZWJhcicpO1xuXHRcdH1cblx0fSk7XG5cblx0Ly8gVHJhY2sgXCJOZWVkIGhlbHA/XCIgbGlua3MgKGV4aXN0aW5nIGhlbHAgYnV0dG9ucylcblx0JChkb2N1bWVudCkub24oJ2NsaWNrJywgJy53cHItaW5mb0FjdGlvbi0taGVscDpub3QoW2RhdGEtYmVhY29uLWlkXSknLCBmdW5jdGlvbigpIHtcblx0XHRpZiAodHlwZW9mIHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24gPT09ICdmdW5jdGlvbicpIHtcblx0XHRcdHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24oJ05lZWQgSGVscCcsICdHZW5lcmFsJyk7XG5cdFx0fVxuXHR9KTtcblxuXG5cdC8qKipcblx0KiBTaG93IHBvcGluIGFuYWx5dGljc1xuXHQqKiovXG5cblx0dmFyICR3cHJBbmFseXRpY3NQb3BpbiA9ICQoJy53cHItUG9waW4tQW5hbHl0aWNzJyksXG5cdFx0JHdwclBvcGluT3ZlcmxheSA9ICQoJy53cHItUG9waW4tb3ZlcmxheScpLFxuXHRcdCR3cHJBbmFseXRpY3NDbG9zZVBvcGluID0gJCgnLndwci1Qb3Bpbi1BbmFseXRpY3MtY2xvc2UnKSxcblx0XHQkd3ByQW5hbHl0aWNzUG9waW5CdXR0b24gPSAkKCcud3ByLVBvcGluLUFuYWx5dGljcyAud3ByLWJ1dHRvbicpLFxuXHRcdCR3cHJBbmFseXRpY3NPcGVuUG9waW4gPSAkKCcud3ByLWpzLXBvcGluJylcblx0O1xuXG5cdCR3cHJBbmFseXRpY3NPcGVuUG9waW4ub24oJ2NsaWNrJywgZnVuY3Rpb24oZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHR3cHJPcGVuQW5hbHl0aWNzKCk7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9KTtcblxuXHQkd3ByQW5hbHl0aWNzQ2xvc2VQb3Bpbi5vbignY2xpY2snLCBmdW5jdGlvbihlKSB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdHdwckNsb3NlQW5hbHl0aWNzKCk7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9KTtcblxuXHQkd3ByQW5hbHl0aWNzUG9waW5CdXR0b24ub24oJ2NsaWNrJywgZnVuY3Rpb24oZSkge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHR3cHJBY3RpdmF0ZUFuYWx5dGljcygpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSk7XG5cblx0ZnVuY3Rpb24gd3ByT3BlbkFuYWx5dGljcygpe1xuXHRcdHZhciB2VEwgPSBuZXcgVGltZWxpbmVMaXRlKClcblx0XHQgIC5zZXQoJHdwckFuYWx5dGljc1BvcGluLCB7J2Rpc3BsYXknOidibG9jayd9KVxuXHRcdCAgLnNldCgkd3ByUG9waW5PdmVybGF5LCB7J2Rpc3BsYXknOidibG9jayd9KVxuXHRcdCAgLmZyb21Ubygkd3ByUG9waW5PdmVybGF5LCAwLjYsIHthdXRvQWxwaGE6MH0se2F1dG9BbHBoYToxLCBlYXNlOlBvd2VyNC5lYXNlT3V0fSlcblx0XHQgIC5mcm9tVG8oJHdwckFuYWx5dGljc1BvcGluLCAwLjYsIHthdXRvQWxwaGE6MCwgbWFyZ2luVG9wOiAtMjR9LCB7YXV0b0FscGhhOjEsIG1hcmdpblRvcDowLCBlYXNlOlBvd2VyNC5lYXNlT3V0fSwgJz0tLjUnKVxuXHRcdDtcblx0fVxuXG5cdGZ1bmN0aW9uIHdwckNsb3NlQW5hbHl0aWNzKCl7XG5cdFx0dmFyIHZUTCA9IG5ldyBUaW1lbGluZUxpdGUoKVxuXHRcdCAgLmZyb21Ubygkd3ByQW5hbHl0aWNzUG9waW4sIDAuNiwge2F1dG9BbHBoYToxLCBtYXJnaW5Ub3A6IDB9LCB7YXV0b0FscGhhOjAsIG1hcmdpblRvcDotMjQsIGVhc2U6UG93ZXI0LmVhc2VPdXR9KVxuXHRcdCAgLmZyb21Ubygkd3ByUG9waW5PdmVybGF5LCAwLjYsIHthdXRvQWxwaGE6MX0se2F1dG9BbHBoYTowLCBlYXNlOlBvd2VyNC5lYXNlT3V0fSwgJz0tLjUnKVxuXHRcdCAgLnNldCgkd3ByQW5hbHl0aWNzUG9waW4sIHsnZGlzcGxheSc6J25vbmUnfSlcblx0XHQgIC5zZXQoJHdwclBvcGluT3ZlcmxheSwgeydkaXNwbGF5Jzonbm9uZSd9KVxuXHRcdDtcblx0fVxuXG5cdGZ1bmN0aW9uIHdwckFjdGl2YXRlQW5hbHl0aWNzKCl7XG5cdFx0d3ByQ2xvc2VBbmFseXRpY3MoKTtcblx0XHQkKCcjYW5hbHl0aWNzX2VuYWJsZWQnKS5wcm9wKCdjaGVja2VkJywgdHJ1ZSk7XG5cblx0XHR2YXIgYW5hbHl0aWNzRW5hYmxlZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhbmFseXRpY3NfZW5hYmxlZCcpO1xuXG5cdFx0aWYgKCBhbmFseXRpY3NFbmFibGVkICkge1xuXHRcdFx0dmFyIGNoYW5nZUV2ZW50ID0gbmV3IEV2ZW50KCdjaGFuZ2UnLCB7IGJ1YmJsZXM6IHRydWUgfSk7XG5cdFx0XHRhbmFseXRpY3NFbmFibGVkLmRpc3BhdGNoRXZlbnQoY2hhbmdlRXZlbnQpO1xuXHRcdH1cblx0fVxuXG5cdC8vIERpc3BsYXkgQ1RBIHdpdGhpbiB0aGUgcG9waW4gYFdoYXQgaW5mbyB3aWxsIHdlIGNvbGxlY3Q/YFxuXHQkKCcjYW5hbHl0aWNzX2VuYWJsZWQnKS5vbignY2hhbmdlJywgZnVuY3Rpb24gKCkge1xuXHRcdCQoJy53cHItcm9ja2V0LWFuYWx5dGljcy1jdGEnKS50b2dnbGVDbGFzcygnd3ByLWlzSGlkZGVuJyk7XG5cdH0pO1xuXG5cdC8qKipcblx0KiBTaG93IHBvcGluIHVwZ3JhZGVcblx0KioqL1xuXG5cdHZhciAkd3ByVXBncmFkZVBvcGluID0gJCgnLndwci1Qb3Bpbi1VcGdyYWRlJyksXG5cdCR3cHJVcGdyYWRlQ2xvc2VQb3BpbiA9ICQoJy53cHItUG9waW4tVXBncmFkZS1jbG9zZScpLFxuXHQkd3ByVXBncmFkZU9wZW5Qb3BpbiA9ICQoJy53cHItcG9waW4tdXBncmFkZS10b2dnbGUnKTtcblxuXHQkd3ByVXBncmFkZU9wZW5Qb3Bpbi5vbignY2xpY2snLCBmdW5jdGlvbihlKSB7XG5cdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdHdwck9wZW5VcGdyYWRlUG9waW4oKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0pO1xuXG5cdCR3cHJVcGdyYWRlQ2xvc2VQb3Bpbi5vbignY2xpY2snLCBmdW5jdGlvbigpIHtcblx0XHR3cHJDbG9zZVVwZ3JhZGVQb3BpbigpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSk7XG5cblx0ZnVuY3Rpb24gd3ByT3BlblVwZ3JhZGVQb3Bpbigpe1xuXHRcdHZhciB2VEwgPSBuZXcgVGltZWxpbmVMaXRlKCk7XG5cblx0XHR2VEwuc2V0KCR3cHJVcGdyYWRlUG9waW4sIHsnZGlzcGxheSc6J2Jsb2NrJ30pXG5cdFx0XHQuc2V0KCR3cHJQb3Bpbk92ZXJsYXksIHsnZGlzcGxheSc6J2Jsb2NrJ30pXG5cdFx0XHQuZnJvbVRvKCR3cHJQb3Bpbk92ZXJsYXksIDAuNiwge2F1dG9BbHBoYTowfSx7YXV0b0FscGhhOjEsIGVhc2U6UG93ZXI0LmVhc2VPdXR9KVxuXHRcdFx0LmZyb21Ubygkd3ByVXBncmFkZVBvcGluLCAwLjYsIHthdXRvQWxwaGE6MCwgbWFyZ2luVG9wOiAtMjR9LCB7YXV0b0FscGhhOjEsIG1hcmdpblRvcDowLCBlYXNlOlBvd2VyNC5lYXNlT3V0fSwgJz0tLjUnKVxuXHRcdDtcblx0fVxuXG5cdGZ1bmN0aW9uIHdwckNsb3NlVXBncmFkZVBvcGluKCl7XG5cdFx0dmFyIHZUTCA9IG5ldyBUaW1lbGluZUxpdGUoKTtcblxuXHRcdHZUTC5mcm9tVG8oJHdwclVwZ3JhZGVQb3BpbiwgMC42LCB7YXV0b0FscGhhOjEsIG1hcmdpblRvcDogMH0sIHthdXRvQWxwaGE6MCwgbWFyZ2luVG9wOi0yNCwgZWFzZTpQb3dlcjQuZWFzZU91dH0pXG5cdFx0XHQuZnJvbVRvKCR3cHJQb3Bpbk92ZXJsYXksIDAuNiwge2F1dG9BbHBoYToxfSx7YXV0b0FscGhhOjAsIGVhc2U6UG93ZXI0LmVhc2VPdXR9LCAnPS0uNScpXG5cdFx0XHQuc2V0KCR3cHJVcGdyYWRlUG9waW4sIHsnZGlzcGxheSc6J25vbmUnfSlcblx0XHRcdC5zZXQoJHdwclBvcGluT3ZlcmxheSwgeydkaXNwbGF5Jzonbm9uZSd9KVxuXHRcdDtcblx0fVxuXG5cdC8qKipcblx0KiBTaWRlYmFyIG9uL29mZlxuXHQqKiovXG5cdHZhciAkd3ByU2lkZWJhciAgICA9ICQoICcud3ByLVNpZGViYXInICk7XG5cdHZhciAkd3ByQnV0dG9uVGlwcyA9ICQoJy53cHItanMtdGlwcycpO1xuXG5cdCR3cHJCdXR0b25UaXBzLm9uKCdjaGFuZ2UnLCBmdW5jdGlvbigpIHtcblx0XHR3cHJEZXRlY3RUaXBzKCQodGhpcykpO1xuXHR9KTtcblxuXHRmdW5jdGlvbiB3cHJEZXRlY3RUaXBzKGFFbGVtKXtcblx0XHRpZihhRWxlbS5pcygnOmNoZWNrZWQnKSl7XG5cdFx0XHQkd3ByU2lkZWJhci5jc3MoJ2Rpc3BsYXknLCdibG9jaycpO1xuXHRcdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oICd3cHItc2hvdy1zaWRlYmFyJywgJ29uJyApO1xuXHRcdH1cblx0XHRlbHNle1xuXHRcdFx0JHdwclNpZGViYXIuY3NzKCdkaXNwbGF5Jywnbm9uZScpO1xuXHRcdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oICd3cHItc2hvdy1zaWRlYmFyJywgJ29mZicgKTtcblx0XHR9XG5cdH1cblxuXG5cblx0LyoqKlxuXHQqIERldGVjdCBBZGJsb2NrXG5cdCoqKi9cblxuXHRpZihkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnTEtnT2NDUnB3bUFqJykpe1xuXHRcdCQoJy53cHItYWRibG9jaycpLmNzcygnZGlzcGxheScsICdub25lJyk7XG5cdH0gZWxzZSB7XG5cdFx0JCgnLndwci1hZGJsb2NrJykuY3NzKCdkaXNwbGF5JywgJ2Jsb2NrJyk7XG5cdH1cblxuXHR2YXIgJGFkYmxvY2sgPSAkKCcud3ByLWFkYmxvY2snKTtcblx0dmFyICRhZGJsb2NrQ2xvc2UgPSAkKCcud3ByLWFkYmxvY2stY2xvc2UnKTtcblxuXHQkYWRibG9ja0Nsb3NlLm9uKCdjbGljaycsIGZ1bmN0aW9uKCkge1xuXHRcdHdwckNsb3NlQWRibG9ja05vdGljZSgpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSk7XG5cblx0ZnVuY3Rpb24gd3ByQ2xvc2VBZGJsb2NrTm90aWNlKCl7XG5cdFx0dmFyIHZUTCA9IG5ldyBUaW1lbGluZUxpdGUoKVxuXHRcdCAgLnRvKCRhZGJsb2NrLCAxLCB7YXV0b0FscGhhOjAsIHg6NDAsIGVhc2U6UG93ZXI0LmVhc2VPdXR9KVxuXHRcdCAgLnRvKCRhZGJsb2NrLCAwLjQsIHtoZWlnaHQ6IDAsIG1hcmdpblRvcDowLCBlYXNlOlBvd2VyNC5lYXNlT3V0fSwgJz0tLjQnKVxuXHRcdCAgLnNldCgkYWRibG9jaywgeydkaXNwbGF5Jzonbm9uZSd9KVxuXHRcdDtcblx0fVxuXG5cdC8vIEhhbmRsZSBleHBhbmQvY29sbGFwc2Ugb2YgcmVjb21tZW5kYXRpb25zIGxpc3QuXG5cdCQoZG9jdW1lbnQpLm9uKCdjbGljaycsICcjd3ByLXJlY29tbWVuZGF0aW9ucy1sb2FkLW1vcmUnLCBmdW5jdGlvbigpIHtcblx0XHRsZXQgJGxpc3QgPSAkKCcud3ByLXJlY29tbWVuZGF0aW9uc19fbGlzdCcpO1xuXHRcdGxldCAkaGlkZGVuSXRlbXMgPSAkbGlzdC5maW5kKCcud3ByLXJlY29tbWVuZGF0aW9uLWl0ZW06Z3QoMiknKTtcblxuXHRcdC8vIFRyYWNrIExvYWQgTW9yZSBidXR0b24gY2xpY2tcblx0XHRpZiAodHlwZW9mIHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24gPT09ICdmdW5jdGlvbicpIHtcblx0XHRcdHdpbmRvdy53cHJUcmFja0hlbHBCdXR0b24oJ3JvY2tldCBpbnNpZ2h0cyByZWNvbW1lbmRhdGlvbnMgbG9hZCBtb3JlJywgJ2xvYWRfbW9yZScpO1xuXHRcdH1cblxuXHRcdGlmICgkbGlzdC5oYXNDbGFzcygnaXMtZXhwYW5kZWQnKSkge1xuXHRcdFx0JGhpZGRlbkl0ZW1zLnNsaWRlVXAoMzAwLCBmdW5jdGlvbigpIHtcblx0XHRcdFx0JGxpc3QucmVtb3ZlQ2xhc3MoJ2lzLWV4cGFuZGVkJyk7XG5cdFx0XHR9KTtcblx0XHRcdCQodGhpcykucmVtb3ZlQ2xhc3MoJ2lzLWV4cGFuZGVkJyk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0JGxpc3QuYWRkQ2xhc3MoJ2lzLWV4cGFuZGVkJyk7XG5cdFx0JGhpZGRlbkl0ZW1zLnNsaWRlRG93bigzMDApO1xuXHRcdCQodGhpcykuYWRkQ2xhc3MoJ2lzLWV4cGFuZGVkJyk7XG5cdH0pO1xuXG5cdC8vIFRyYWNrIFJvY2tldCBJbnNpZ2h0cyBSZWNvbW1lbmRhdGlvbiBBY3RpdmF0ZSBidXR0b24gY2xpY2tzXG5cdCQoZG9jdW1lbnQpLm9uKCdjbGljaycsICcud3ByLXJlY29tbWVuZGF0aW9uLWl0ZW1fX2FjdGl2YXRlJywgZnVuY3Rpb24oKSB7XG5cdFx0dmFyIHJlY29tbWVuZGF0aW9uID0gJCh0aGlzKS5kYXRhKCdyZWNvbW1lbmRhdGlvbicpIHx8ICd1bmtub3duJztcblxuXHRcdC8vIElmIHRoZSBlbGVtZW50IGlzIHZpc2libGUsIHNjcm9sbCB0byB0aGUgZWxlbWVudCB3aXRoIGlkIG1hdGNoaW5nIHRoZSByZWNvbW1lbmRhdGlvbiB2YWx1ZS5cblx0XHQvLyBEZWxheSBzY3JvbGwgYnkgMTAwbXMgdG8gYWxsb3cgbmF2aWdhdGlvbiB0byB0aGUgc2VjdGlvbiB0byBjb21wbGV0ZSBhbmQgZW5zdXJlIHRoZSB0YXJnZXQgZWxlbWVudCBpcyBpbiB2aWV3LlxuXHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgJHRhcmdldCA9ICQoYCMke3JlY29tbWVuZGF0aW9ufWApO1xuXHRcdFx0XG5cdFx0XHRpZiAoISR0YXJnZXQubGVuZ3RoICYmICEkdGFyZ2V0LmlzKCc6dmlzaWJsZScpKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0JHRhcmdldFswXS5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJywgYmxvY2s6ICdjZW50ZXInIH0pO1xuXHRcdH0sIDEwMCk7XG5cdFx0XG5cdFx0Ly8gVHJhY2sgZGlyZWN0bHkgd2l0aCBNaXhwYW5lbFxuXHRcdGlmICh0eXBlb2YgbWl4cGFuZWwgIT09ICd1bmRlZmluZWQnICYmIG1peHBhbmVsLnRyYWNrKSB7XG5cdFx0XHQvLyBDaGVjayBpZiB1c2VyIGhhcyBvcHRlZCBpblxuXHRcdFx0aWYgKHR5cGVvZiByb2NrZXRfbWl4cGFuZWxfZGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgcm9ja2V0X21peHBhbmVsX2RhdGEub3B0aW5fZW5hYmxlZCAmJiByb2NrZXRfbWl4cGFuZWxfZGF0YS5vcHRpbl9lbmFibGVkICE9PSAnMCcpIHtcblx0XHRcdFx0Ly8gSWRlbnRpZnkgdXNlciBpZiBhdmFpbGFibGVcblx0XHRcdFx0aWYgKHJvY2tldF9taXhwYW5lbF9kYXRhLnVzZXJfaWQgJiYgdHlwZW9mIG1peHBhbmVsLmlkZW50aWZ5ID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRcdFx0bWl4cGFuZWwuaWRlbnRpZnkocm9ja2V0X21peHBhbmVsX2RhdGEudXNlcl9pZCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC8vIFRyYWNrIHRoZSBCdXR0b24gQ2xpY2tlZCBldmVudFxuXHRcdFx0XHRtaXhwYW5lbC50cmFjaygnQnV0dG9uIENsaWNrZWQnLCB7XG5cdFx0XHRcdFx0J2J1dHRvbic6ICdyb2NrZXQgaW5zaWdodHMgcmVjb21tZW5kYXRpb24nLFxuXHRcdFx0XHRcdCdyZWNvbW1lbmRhdGlvbic6IHJlY29tbWVuZGF0aW9uLFxuXHRcdFx0XHRcdCdwbHVnaW4nOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5wbHVnaW4sXG5cdFx0XHRcdFx0J2JyYW5kJzogcm9ja2V0X21peHBhbmVsX2RhdGEuYnJhbmQsXG5cdFx0XHRcdFx0J2FwcGxpY2F0aW9uJzogcm9ja2V0X21peHBhbmVsX2RhdGEuYXBwLFxuXHRcdFx0XHRcdCdjb250ZXh0Jzogcm9ja2V0X21peHBhbmVsX2RhdGEuY29udGV4dCxcblx0XHRcdFx0XHQncGF0aCc6IHJvY2tldF9taXhwYW5lbF9kYXRhLnBhdGgsXG5cdFx0XHRcdFx0J2ludGVyYWN0aW9uX2NoYW5uZWwnOiAnVUknXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0fSk7XG5cblx0Ly8gVHJhY2sgQ1RBIGNsaWNrcyBmb3IgUm9ja2V0IEluc2lnaHRzIGluIHRoZSBzZXR0aW5ncyBzYXZlZCBub3RpY2UuXG5cdCQoZG9jdW1lbnQpLm9uKCdjbGljaycsICcjcm9ja2V0X3JpX25ld190ZXN0X3NhdmVfc2V0dGluZ3NfbGluaycsIGZ1bmN0aW9uKCkge1xuXHRcdC8vIFRyYWNrIGRpcmVjdGx5IHdpdGggTWl4cGFuZWxcblx0XHRpZiAodHlwZW9mIG1peHBhbmVsID09PSAndW5kZWZpbmVkJyB8fCAhbWl4cGFuZWwudHJhY2spIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBDaGVjayBpZiB1c2VyIGhhcyBvcHRlZCBpblxuXHRcdGlmICh0eXBlb2Ygcm9ja2V0X21peHBhbmVsX2RhdGEgPT09ICd1bmRlZmluZWQnIHx8ICFyb2NrZXRfbWl4cGFuZWxfZGF0YS5vcHRpbl9lbmFibGVkIHx8IHJvY2tldF9taXhwYW5lbF9kYXRhLm9wdGluX2VuYWJsZWQgPT09ICcwJykge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdC8vIElkZW50aWZ5IHVzZXIgaWYgYXZhaWxhYmxlXG5cdFx0aWYgKHJvY2tldF9taXhwYW5lbF9kYXRhLnVzZXJfaWQgJiYgdHlwZW9mIG1peHBhbmVsLmlkZW50aWZ5ID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRtaXhwYW5lbC5pZGVudGlmeShyb2NrZXRfbWl4cGFuZWxfZGF0YS51c2VyX2lkKTtcblx0XHR9XG5cblx0XHQvLyBUcmFjayB0aGUgQnV0dG9uIENsaWNrZWQgZXZlbnRcblx0XHRtaXhwYW5lbC50cmFjaygnUm9ja2V0IEluc2lnaHRzIENUQSBjbGljayBmcm9tIHNldHRpbmdzIG5vdGljZScsIHtcblx0XHRcdCdidXR0b24nOiAnQ1RBIG9uIHNhdmUgc2V0dGluZ3Mgbm90aWNlJyxcblx0XHRcdCdzb3VyY2UnOiAnU2V0dGluZ3MgU2F2ZWQgTm90aWNlJyxcblx0XHRcdCdwbHVnaW4nOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5wbHVnaW4sXG5cdFx0XHQnYnJhbmQnOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5icmFuZCxcblx0XHRcdCdhcHBsaWNhdGlvbic6IHJvY2tldF9taXhwYW5lbF9kYXRhLmFwcCxcblx0XHRcdCdjb250ZXh0Jzogcm9ja2V0X21peHBhbmVsX2RhdGEuY29udGV4dCxcblx0XHRcdCdwYXRoJzogcm9ja2V0X21peHBhbmVsX2RhdGEucGF0aCxcblx0XHRcdCdpbnRlcmFjdGlvbl9jaGFubmVsJzogJ1VJJ1xuXHRcdH0pO1xuXHR9KTtcbn0pO1xuIiwiY2xhc3MgUm9ja2V0TWl4cGFuZWwge1xuXG5cdHRyYWNrZWRUYWJzID0gW1xuXHRcdCdkYXNoYm9hcmQnLFxuXHRcdCdyb2NrZXRfaW5zaWdodHMnLFxuXHRcdCdwYWdlX2NkbicsXG5cdFx0J2ZpbGVfb3B0aW1pemF0aW9uJyxcblx0XHQnbWVkaWEnLFxuXHRcdCdwcmVsb2FkJyxcblx0XHQnYWR2YW5jZWRfY2FjaGUnLFxuXHRcdCdkYXRhYmFzZScsXG5cdFx0J2hlYXJ0YmVhdCcsXG5cdFx0J2FkZG9ucycsXG5cdFx0J2ltYWdpZnknLFxuXHRcdCd0dXRvcmlhbHMnLFxuXHRcdCdwbHVnaW5zJyxcblx0XHQndG9vbHMnXG5cdF07XG5cblx0Y29uc3RydWN0b3IoIGNvbmZpZyApIHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0fVxuXG5cdC8qKlxuXHQgKiBJbml0aWFsaXplcyB0aGUgaGFuZGxlci5cblx0ICovXG5cdGluaXQoKSB7XG5cdFx0aWYgKCB0eXBlb2YgbWl4cGFuZWwgPT09ICd1bmRlZmluZWQnIHx8ICFtaXhwYW5lbC50cmFjayApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKCAhdGhpcy5jb25maWcub3B0aW5fZW5hYmxlZCB8fCB0aGlzLmNvbmZpZy5vcHRpbl9lbmFibGVkID09PSAnMCcpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0bWl4cGFuZWwuaWRlbnRpZnkodGhpcy5jb25maWcudXNlcl9pZCk7XG5cdFx0dGhpcy5faW5pdExpc3RlbmVycyggdGhpcyApO1xuXHR9XG5cblx0LyoqXG5cdCAqIEluaXRpYWxpemVzIHRoZSBldmVudCBsaXN0ZW5lcnMuXG5cdCAqXG5cdCAqIEBwYXJhbSBzZWxmIGluc3RhbmNlIG9mIHRoaXMgb2JqZWN0LCB1c2VkIGZvciBiaW5kaW5nIFwidGhpc1wiIHRvIHRoZSBsaXN0ZW5lcnMuXG5cdCAqL1xuXHRfaW5pdExpc3RlbmVycyggc2VsZiApIHtcblx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lciggJ2hhc2hjaGFuZ2UnLCBzZWxmLl9vbkhhc2hDaGFuZ2UuYmluZCggc2VsZiApICk7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoICdsb2FkJywgc2VsZi5fb25QYWdlTG9hZC5iaW5kKCBzZWxmICkgKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBFdmVudCBsaXN0ZW5lciB3aGVuIHRoZSBoYXNoIGNoYW5nZWQgaW4gYSBwYWdlLlxuXHQgKlxuXHQgKiBAcGFyYW0gRXZlbnQgZXZlbnQgRXZlbnQgaW5zdGFuY2UuXG5cdCAqL1xuXHRfb25IYXNoQ2hhbmdlKCBldmVudCApIHtcblx0XHRjb25zdCBvbGRIYXNoID0gdGhpcy5fY2xlYW5IYXNoKG5ldyBVUkwoZXZlbnQub2xkVVJMKS5oYXNoKTtcblx0XHRjb25zdCBuZXdIYXNoID0gdGhpcy5fY2xlYW5IYXNoKG5ldyBVUkwoZXZlbnQubmV3VVJMKS5oYXNoKTtcblxuXHRcdGlmICggIXRoaXMuX2NhblRyYWNrVGFiKG5ld0hhc2gpICkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdHRoaXMuX3NlbmRQYWdlVmlld2VkRXZlbnQodGhpcy5fZ2V0U291cmNlKCBvbGRIYXNoICksIG5ld0hhc2gpO1xuXHR9XG5cblx0X29uUGFnZUxvYWQoKSB7XG5cdFx0Y29uc3QgbmV3SGFzaCA9IHRoaXMuX2NsZWFuSGFzaCh3aW5kb3cubG9jYXRpb24uaGFzaCk7XG5cdFx0aWYgKCAhdGhpcy5fY2FuVHJhY2tUYWIobmV3SGFzaCkgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0dGhpcy5fc2VuZFBhZ2VWaWV3ZWRFdmVudCh0aGlzLl9nZXRTb3VyY2UoKSwgbmV3SGFzaCk7XG5cdH1cblxuXHRfY2xlYW5IYXNoKCB0YWJIYXNoICkge1xuXHRcdGlmICghdGFiSGFzaCB8fCAhdGFiSGFzaC5zdGFydHNXaXRoKCcjJykpIHtcblx0XHRcdHJldHVybiB0YWJIYXNoO1xuXHRcdH1cblx0XHRyZXR1cm4gdGFiSGFzaC5zdWJzdHJpbmcoMSk7XG5cdH1cblxuXHRfY2FuVHJhY2tUYWIodGFiSGFzaCkge1xuXHRcdHJldHVybiB0aGlzLnRyYWNrZWRUYWJzLmluY2x1ZGVzKHRhYkhhc2gpO1xuXHR9XG5cblx0X2dldFNvdXJjZSggb2xkSGFzaCA9ICcnICkge1xuXHRcdGlmICggb2xkSGFzaCApIHtcblx0XHRcdHJldHVybiBgc2V0dGluZ3NfJHtvbGRIYXNofWA7XG5cdFx0fVxuXG5cdFx0bGV0IHNvdXJjZSA9IHRoaXMuX2dldFNvdXJjZUZyb21RdWVyeVN0cmluZ0FuZFJlbW92ZUl0KCk7XG5cdFx0aWYgKCBzb3VyY2UgKSB7XG5cdFx0XHRyZXR1cm4gc291cmNlO1xuXHRcdH1cblxuXHRcdHJldHVybiB0aGlzLl9nZXRTb3VyY2VGcm9tUmVmZXJyZXIoKTtcblx0fVxuXG5cdF9nZXRTb3VyY2VGcm9tUXVlcnlTdHJpbmdBbmRSZW1vdmVJdCgpIHtcblx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcblx0XHRjb25zdCB1cmxQYXJhbXMgPSB1cmwuc2VhcmNoUGFyYW1zO1xuXG5cdFx0Ly8gMS4gQ2hlY2sgZm9yIGV4cGxpY2l0IHNvdXJjZSBwYXJhbVxuXHRcdGlmICghdXJsUGFyYW1zLmhhcygncm9ja2V0X3NvdXJjZScpKSB7XG5cdFx0XHRyZXR1cm4gJyc7XG5cdFx0fVxuXG5cdFx0Ly8gMi4gR2V0IHRoZSB2YWx1ZVxuXHRcdGNvbnN0IHNvdXJjZVZhbHVlID0gdXJsUGFyYW1zLmdldCgncm9ja2V0X3NvdXJjZScpO1xuXG5cdFx0Ly8gMy4gRGVsZXRlIHRoZSBwYXJhbWV0ZXIgZnJvbSB0aGUgVVJMU2VhcmNoUGFyYW1zIG9iamVjdFxuXHRcdHVybFBhcmFtcy5kZWxldGUoJ3JvY2tldF9zb3VyY2UnKTtcblxuXHRcdC8vIDQuIFVwZGF0ZSB0aGUgYnJvd3NlcidzIFVSTCB1c2luZyB0aGUgSGlzdG9yeSBBUElcblx0XHQvLyBUaGlzIHJlbW92ZXMgdGhlIHBhcmFtZXRlciBmcm9tIHRoZSBVUkwgYmFyIHdpdGhvdXQgcmVsb2FkaW5nIHRoZSBwYWdlLlxuXHRcdHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZShudWxsLCAnJywgdXJsLnNlYXJjaCA/IHVybC5ocmVmIDogdXJsLnBhdGhuYW1lKTtcblxuXHRcdC8vIDUuIFJldHVybiB0aGUgcmV0cmlldmVkIHZhbHVlXG5cdFx0cmV0dXJuIHNvdXJjZVZhbHVlO1xuXHR9XG5cblx0X2dldFNvdXJjZUZyb21SZWZlcnJlcigpIHtcblx0XHRjb25zdCByZWZlcnJlciA9IGRvY3VtZW50LnJlZmVycmVyO1xuXHRcdGlmICghcmVmZXJyZXIpIHtcblx0XHRcdHJldHVybiAnbm9yZWZlcnJlcic7XG5cdFx0fVxuXHRcdGlmICghcmVmZXJyZXIuaW5jbHVkZXMod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lKSkge1xuXHRcdFx0cmV0dXJuICdleHRlcm5hbCc7XG5cdFx0fVxuXHRcdHJldHVybiAnaW50ZXJuYWwnO1xuXHR9XG5cblx0X3NlbmRQYWdlVmlld2VkRXZlbnQoc291cmNlLCBuZXdIYXNoKSB7XG5cdFx0bWl4cGFuZWwudHJhY2soJ1BhZ2UgVmlld2VkJywge1xuXHRcdFx0cGF0aDogYC93cC1hZG1pbi9vcHRpb25zLWdlbmVyYWwucGhwP3BhZ2U9d3Byb2NrZXQjJHtuZXdIYXNofWAsXG5cdFx0XHRwYWdlX25hbWU6IG5ld0hhc2gucmVwbGFjZSgnXycsICcgJyksXG5cdFx0XHRzb3VyY2U6IHNvdXJjZSxcblx0XHRcdHBsdWdpbjogcm9ja2V0X21peHBhbmVsX2RhdGEucGx1Z2luLFxuXHRcdFx0YnJhbmQ6IHJvY2tldF9taXhwYW5lbF9kYXRhLmJyYW5kLFxuXHRcdFx0YXBwbGljYXRpb246IHJvY2tldF9taXhwYW5lbF9kYXRhLmFwcCxcblx0XHRcdGNvbnRleHQ6IHJvY2tldF9taXhwYW5lbF9kYXRhLmNvbnRleHQsXG5cdFx0XHRpbnRlcmFjdGlvbl9jaGFubmVsOiAnVUknXG5cdFx0fSk7XG5cdH1cblxuXHQvKipcblx0ICogTmFtZWQgc3RhdGljIGNvbnN0cnVjdG9yIHRvIGVuY2Fwc3VsYXRlIGhvdyB0byBjcmVhdGUgdGhlIG9iamVjdC5cblx0ICovXG5cdHN0YXRpYyBydW4oKSB7XG5cdFx0Ly8gQmFpbCBvdXQgaWYgdGhlIGNvbmZpZ3VyYXRpb24gbm90IHBhc3NlZCBmcm9tIHRoZSBzZXJ2ZXIuXG5cdFx0aWYgKCB0eXBlb2Ygcm9ja2V0X21peHBhbmVsX2RhdGEgPT09ICd1bmRlZmluZWQnICkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IGluc3RhbmNlID0gbmV3IFJvY2tldE1peHBhbmVsKCByb2NrZXRfbWl4cGFuZWxfZGF0YSApO1xuXHRcdGluc3RhbmNlLmluaXQoKTtcblx0fVxufVxuXG5Sb2NrZXRNaXhwYW5lbC5ydW4oKTtcbiIsImRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoICdET01Db250ZW50TG9hZGVkJywgZnVuY3Rpb24gKCkge1xuXG4gICAgdmFyICRwYWdlTWFuYWdlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIud3ByLUNvbnRlbnRcIik7XG4gICAgaWYoJHBhZ2VNYW5hZ2VyKXtcbiAgICAgICAgbmV3IFBhZ2VNYW5hZ2VyKCRwYWdlTWFuYWdlcik7XG4gICAgfVxuXG59KTtcblxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKlxcXG5cdFx0Q0xBU1MgUEFHRU1BTkFHRVJcblxcKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogTWFuYWdlcyB0aGUgZGlzcGxheSBvZiBwYWdlcyAvIHNlY3Rpb24gZm9yIFdQIFJvY2tldCBwbHVnaW5cbiAqXG4gKiBQdWJsaWMgbWV0aG9kIDpcbiAgICAgZGV0ZWN0SUQgLSBEZXRlY3QgSUQgd2l0aCBoYXNoXG4gICAgIGdldEJvZHlUb3AgLSBHZXQgYm9keSB0b3AgcG9zaXRpb25cblx0IGNoYW5nZSAtIERpc3BsYXlzIHRoZSBjb3JyZXNwb25kaW5nIHBhZ2VcbiAqXG4gKi9cblxuZnVuY3Rpb24gUGFnZU1hbmFnZXIoYUVsZW0pIHtcblxuICAgIHZhciByZWZUaGlzID0gdGhpcztcblxuICAgIHRoaXMuJGJvZHkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcud3ByLWJvZHknKTtcbiAgICB0aGlzLiRtZW51SXRlbXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcud3ByLW1lbnVJdGVtJyk7XG4gICAgdGhpcy4kc3VibWl0QnV0dG9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLndwci1Db250ZW50ID4gZm9ybSA+ICN3cHItb3B0aW9ucy1zdWJtaXQnKTtcbiAgICB0aGlzLiRwYWdlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy53cHItUGFnZScpO1xuICAgIHRoaXMuJHNpZGViYXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcud3ByLVNpZGViYXInKTtcbiAgICB0aGlzLiRjb250ZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLndwci1Db250ZW50Jyk7XG4gICAgdGhpcy4kdGlwcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy53cHItQ29udGVudC10aXBzJyk7XG4gICAgdGhpcy4kbGlua3MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcud3ByLWJvZHkgYScpO1xuICAgIHRoaXMuJG1lbnVJdGVtID0gbnVsbDtcbiAgICB0aGlzLiRwYWdlID0gbnVsbDtcbiAgICB0aGlzLnBhZ2VJZCA9IG51bGw7XG4gICAgdGhpcy5ib2R5VG9wID0gMDtcbiAgICB0aGlzLmJ1dHRvblRleHQgPSB0aGlzLiRzdWJtaXRCdXR0b24udmFsdWU7XG5cbiAgICByZWZUaGlzLmdldEJvZHlUb3AoKTtcblxuICAgIC8vIElmIHVybCBwYWdlIGNoYW5nZVxuICAgIHdpbmRvdy5vbmhhc2hjaGFuZ2UgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmVmVGhpcy5kZXRlY3RJRCgpO1xuICAgIH1cblxuICAgIC8vIElmIGhhc2ggYWxyZWFkeSBleGlzdCAoYWZ0ZXIgcmVmcmVzaCBwYWdlIGZvciBleGFtcGxlKVxuICAgIGlmKHdpbmRvdy5sb2NhdGlvbi5oYXNoKXtcbiAgICAgICAgdGhpcy5ib2R5VG9wID0gMDtcbiAgICAgICAgdGhpcy5kZXRlY3RJRCgpO1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgICB2YXIgc2Vzc2lvbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd3cHItaGFzaCcpO1xuICAgICAgICB0aGlzLmJvZHlUb3AgPSAwO1xuXG4gICAgICAgIGlmKHNlc3Npb24pe1xuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhhc2ggPSBzZXNzaW9uO1xuICAgICAgICAgICAgdGhpcy5kZXRlY3RJRCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICB0aGlzLiRtZW51SXRlbXNbMF0uY2xhc3NMaXN0LmFkZCgnaXNBY3RpdmUnKTtcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd3cHItaGFzaCcsICdkYXNoYm9hcmQnKTtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5oYXNoID0gJyNkYXNoYm9hcmQnO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ2xpY2sgbGluayBzYW1lIGhhc2hcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuJGxpbmtzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMuJGxpbmtzW2ldLm9uY2xpY2sgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJlZlRoaXMuZ2V0Qm9keVRvcCgpO1xuICAgICAgICAgICAgdmFyIGhyZWZTcGxpdCA9IHRoaXMuaHJlZi5zcGxpdCgnIycpWzFdO1xuICAgICAgICAgICAgaWYoaHJlZlNwbGl0ID09IHJlZlRoaXMucGFnZUlkICYmIGhyZWZTcGxpdCAhPSB1bmRlZmluZWQpe1xuICAgICAgICAgICAgICAgIHJlZlRoaXMuZGV0ZWN0SUQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLy8gQ2xpY2sgbGlua3Mgbm90IFdQIHJvY2tldCB0byByZXNldCBoYXNoXG4gICAgdmFyICRvdGhlcmxpbmtzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnI2FkbWlubWVudW1haW4gYSwgI3dwYWRtaW5iYXIgYScpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgJG90aGVybGlua3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgJG90aGVybGlua3NbaV0ub25jbGljayA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3dwci1oYXNoJywgJycpO1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoICd3cHItY2RuLXN0YXRlLWNoYW5nZScsIGZ1bmN0aW9uKCkge1xuICAgICAgICByZWZUaGlzLnVwZGF0ZVN1Ym1pdERpc2FibGVkU3RhdGUoKTtcbiAgICB9ICk7XG5cbn1cblxuXG4vKlxuKiBQYWdlIGRldGVjdCBJRFxuKi9cblBhZ2VNYW5hZ2VyLnByb3RvdHlwZS5kZXRlY3RJRCA9IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMucGFnZUlkID0gd2luZG93LmxvY2F0aW9uLmhhc2guc3BsaXQoJyMnKVsxXTtcbiAgICB0aGlzLnBhZ2VJZCA9IHRoaXMucGFnZUlkLmluY2x1ZGVzKCc9JykgPyB0aGlzLnBhZ2VJZC5zcGxpdCgnPScpWzBdIDogdGhpcy5wYWdlSWQ7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3dwci1oYXNoJywgdGhpcy5wYWdlSWQpO1xuXG4gICAgdGhpcy4kcGFnZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy53cHItUGFnZSMnICsgdGhpcy5wYWdlSWQpO1xuICAgIHRoaXMuJG1lbnVJdGVtID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3dwci1uYXYtJyArIHRoaXMucGFnZUlkKTtcblxuICAgIHRoaXMuY2hhbmdlKCk7XG59XG5cblxuXG4vKlxuKiBHZXQgYm9keSB0b3AgcG9zaXRpb25cbiovXG5QYWdlTWFuYWdlci5wcm90b3R5cGUuZ2V0Qm9keVRvcCA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBib2R5UG9zID0gdGhpcy4kYm9keS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICB0aGlzLmJvZHlUb3AgPSBib2R5UG9zLnRvcCArIHdpbmRvdy5wYWdlWU9mZnNldCAtIDQ3OyAvLyAjd3BhZG1pbmJhciArIHBhZGRpbmctdG9wIC53cHItd3JhcCAtIDEgLSA0N1xufVxuXG5cblxuLypcbiogUGFnZSBjaGFuZ2VcbiovXG5QYWdlTWFuYWdlci5wcm90b3R5cGUuY2hhbmdlID0gZnVuY3Rpb24oKSB7XG5cbiAgICB2YXIgcmVmVGhpcyA9IHRoaXM7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbFRvcCA9IHJlZlRoaXMuYm9keVRvcDtcblxuICAgIC8vIEhpZGUgb3RoZXIgcGFnZXNcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuJHBhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMuJHBhZ2VzW2ldLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgfVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy4kbWVudUl0ZW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMuJG1lbnVJdGVtc1tpXS5jbGFzc0xpc3QucmVtb3ZlKCdpc0FjdGl2ZScpO1xuICAgIH1cblxuICAgIC8vIFNob3cgY3VycmVudCBkZWZhdWx0IHBhZ2VcbiAgICB0aGlzLiRwYWdlLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snO1xuICAgIHRoaXMuJHN1Ym1pdEJ1dHRvbi5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcblxuICAgIGlmICggbnVsbCA9PT0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oICd3cHItc2hvdy1zaWRlYmFyJyApICkge1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSggJ3dwci1zaG93LXNpZGViYXInLCAnb24nICk7XG4gICAgfVxuXG4gICAgaWYgKCAnb24nID09PSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnd3ByLXNob3ctc2lkZWJhcicpICkge1xuICAgICAgICB0aGlzLiRzaWRlYmFyLnN0eWxlLmRpc3BsYXkgPSAnZmxleCc7XG4gICAgfSBlbHNlIGlmICggJ29mZicgPT09IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd3cHItc2hvdy1zaWRlYmFyJykgKSB7XG4gICAgICAgIHRoaXMuJHNpZGViYXIuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI3dwci1qcy10aXBzJykucmVtb3ZlQXR0cmlidXRlKCAnY2hlY2tlZCcgKTtcbiAgICB9XG5cbiAgICB0aGlzLiR0aXBzLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snO1xuICAgIHRoaXMuJG1lbnVJdGVtLmNsYXNzTGlzdC5hZGQoJ2lzQWN0aXZlJyk7XG4gICAgdGhpcy4kc3VibWl0QnV0dG9uLnZhbHVlID0gdGhpcy5idXR0b25UZXh0O1xuICAgIHRoaXMuJGNvbnRlbnQuY2xhc3NMaXN0LmFkZCgnaXNOb3RGdWxsJyk7XG5cbiAgICBjb25zdCBwYWdlc1dpdGhvdXRTdWJtaXQgPSBbXG4gICAgICAgICdkYXNoYm9hcmQnLFxuICAgICAgICAnYWRkb25zJyxcbiAgICAgICAgJ2RhdGFiYXNlJyxcbiAgICAgICAgJ3Rvb2xzJyxcbiAgICAgICAgJ2FkZG9ucycsXG4gICAgICAgICdpbWFnaWZ5JyxcbiAgICAgICAgJ3R1dG9yaWFscycsXG4gICAgICAgICdwbHVnaW5zJyxcbiAgICBdO1xuXG4gICAgY29uc3QgcGFnZXNXaXRob3V0U2lkZWJhclRvZ2dsZSA9IFtcbiAgICAgICAgJ2Rhc2hib2FyZCcsXG4gICAgICAgICdpbWFnaWZ5JyxcbiAgICAgICAgJ3BhZ2VfY2RuJyxcbiAgICBdO1xuXG4gICAgLy8gRXhjZXB0aW9uIGZvciBkYXNoYm9hcmRcbiAgICBpZih0aGlzLnBhZ2VJZCA9PSBcImRhc2hib2FyZFwiKXtcbiAgICAgICAgdGhpcy4kc2lkZWJhci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICB0aGlzLiRjb250ZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2lzTm90RnVsbCcpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnBhZ2VJZCA9PSBcImltYWdpZnlcIikge1xuICAgICAgICB0aGlzLiRzaWRlYmFyLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgfVxuXG4gICAgaWYgKHBhZ2VzV2l0aG91dFNpZGViYXJUb2dnbGUuaW5jbHVkZXModGhpcy5wYWdlSWQpKSB7XG4gICAgICAgIHRoaXMuJHRpcHMuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICB9XG5cbiAgICBpZiAocGFnZXNXaXRob3V0U3VibWl0LmluY2x1ZGVzKHRoaXMucGFnZUlkKSkge1xuICAgICAgICB0aGlzLiRzdWJtaXRCdXR0b24uc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICB9XG5cbiAgICB0aGlzLnVwZGF0ZVN1Ym1pdERpc2FibGVkU3RhdGUoKTtcblxuXHQvLyBEaXNwYXRjaCBjdXN0b20gZXZlbnQgYWZ0ZXIgcGFnZSBuYXZpZ2F0aW9uIGZvciBvdGhlciBzY3JpcHRzIHRvIGhvb2sgaW50by5cblx0ZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ3JvY2tldEpzQWZ0ZXJQYWdlTmF2aWdhdGlvbicsIHtcblx0XHRkZXRhaWw6IHtcblx0XHRcdHBhZ2VJZDogdGhpcy5wYWdlSWQsXG5cdFx0XHRzdWJtaXRCdXR0b246IHRoaXMuJHN1Ym1pdEJ1dHRvbixcblx0XHR9XG5cdH0gKSApO1xufTtcblxuXG4vKlxuKiBVcGRhdGUgc3VibWl0IGJ1dHRvbiBkaXNhYmxlZCBzdGF0ZVxuKi9cblBhZ2VNYW5hZ2VyLnByb3RvdHlwZS51cGRhdGVTdWJtaXREaXNhYmxlZFN0YXRlID0gZnVuY3Rpb24oKSB7XG5cdGlmICghdGhpcy4kc3VibWl0QnV0dG9uIHx8ICdub25lJyA9PT0gdGhpcy4kc3VibWl0QnV0dG9uLnN0eWxlLmRpc3BsYXkpIHtcblx0XHRyZXR1cm47XG5cdH1cblxuXHR2YXIgaXNDZG5QYWdlID0gJ3BhZ2VfY2RuJyA9PT0gdGhpcy5wYWdlSWQ7XG5cdHZhciBwYXVzZWRSb2NrZXRDZG5CbG9jayA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXG5cdFx0Jy53cHItUGFnZSNwYWdlX2NkbiAud3ByLW5vdGljZS53cHItcmktbm90aWNlLndwci1jZG4tZXhwaXJlZF9fbm90aWNlJ1xuXHQpO1xuXG5cdHRoaXMuJHN1Ym1pdEJ1dHRvbi5kaXNhYmxlZCA9IGlzQ2RuUGFnZSAmJiAhIXBhdXNlZFJvY2tldENkbkJsb2NrO1xufTtcbiIsIi8qKlxuICogUmVjb21tZW5kYXRpb25zIFdpZGdldCBIYW5kbGVyXG4gKlxuICogTGlzdGVucyBmb3IgR2xvYmFsIFNjb3JlIHVwZGF0ZXMgYW5kIGZldGNoZXMvdXBkYXRlcyByZWNvbW1lbmRhdGlvbnMgZHluYW1pY2FsbHkuXG4gKi9cbnZhciAkID0galF1ZXJ5O1xuJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKXtcblx0LyoqXG5cdCAqIFVwZGF0ZXMgdGhlIHJlY29tbWVuZGF0aW9ucyB3aWRnZXQgVUkgYmFzZWQgb24gdGhlIGZldGNoZWQgZGF0YS5cblx0ICpcblx0ICogQHBhcmFtIHtPYmplY3R9IGRhdGEgLSBUaGUgcmVjb21tZW5kYXRpb25zIGRhdGEgZnJvbSB0aGUgQVBJLlxuXHQgKiBAcGFyYW0ge0FycmF5fSBkYXRhLnJlY29tbWVuZGF0aW9ucyAtIEFycmF5IG9mIHJlY29tbWVuZGF0aW9ucyBkZXRhaWxzLlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gZGF0YS5yZWNvbW1lbmRhdGlvbnMuaHRtbCAtIFJlY29tbWVuZGF0aW9ucyBIVE1MLlxuXHQgKi9cblx0ZnVuY3Rpb24gdXBkYXRlUmVjb21tZW5kYXRpb25zV2lkZ2V0KGRhdGEpIHtcblx0XHRjb25zdCB3aWRnZXQgPSAkKCcud3ByLXJlY29tbWVuZGF0aW9ucycpO1xuXG5cdFx0aWYgKCF3aWRnZXQgfHwgIWRhdGE/LnJlY29tbWVuZGF0aW9ucz8uaHRtbCkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdC8vIFVwZGF0ZSB0aGUgd2lkZ2V0IGNvbnRlbnQgd2l0aCB0aGUgbmV3IHJlY29tbWVuZGF0aW9ucyBIVE1MXG5cdFx0d2lkZ2V0LnJlcGxhY2VXaXRoKGRhdGE/LnJlY29tbWVuZGF0aW9ucz8uaHRtbCk7XG5cdH1cblxuXG5cblx0LyoqXG5cdCAqIEZldGNoZXMgdGhlIGN1cnJlbnQgcmVjb21tZW5kYXRpb25zIHN0YXR1cyBmcm9tIHRoZSBSRVNUIEFQSS5cblx0ICovXG5cdGZ1bmN0aW9uIGZldGNoUmVjb21tZW5kYXRpb25zU3RhdHVzKCkge1xuXHRcdC8vIFVzZSBXb3JkUHJlc3MgUkVTVCBBUEkgY2xpZW50IGlmIGF2YWlsYWJsZVxuXHRcdGlmICh3aW5kb3cud3AgJiYgd2luZG93LndwLmFwaUZldGNoKSB7XG5cdFx0XHR3aW5kb3cud3AuYXBpRmV0Y2goe1xuXHRcdFx0XHRwYXRoOiAnL3dwLXJvY2tldC92MS9yZWNvbW1lbmRhdGlvbnMnXG5cdFx0XHR9KVxuXHRcdFx0XHQudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuXHRcdFx0XHRcdHVwZGF0ZVJlY29tbWVuZGF0aW9uc1dpZGdldChkYXRhKTtcblx0XHRcdFx0fSlcblx0XHRcdFx0LmNhdGNoKGZ1bmN0aW9uIChlcnJvcikge1xuXHRcdFx0XHRcdGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBmZXRjaCByZWNvbW1lbmRhdGlvbnMgc3RhdHVzOicsIGVycm9yKTtcblx0XHRcdFx0fSk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIEZhbGxiYWNrIHRvIGZldGNoIEFQSVxuXHRcdFx0ZmV0Y2god2luZG93LndwQXBpU2V0dGluZ3M/LnJvb3QgKyAnd3Atcm9ja2V0L3YxL3JlY29tbWVuZGF0aW9ucycsIHtcblx0XHRcdFx0aGVhZGVyczoge1xuXHRcdFx0XHRcdCdYLVdQLU5vbmNlJzogd2luZG93LndwQXBpU2V0dGluZ3M/Lm5vbmNlIHx8ICcnXG5cdFx0XHRcdH1cblx0XHRcdH0pXG5cdFx0XHRcdC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuXHRcdFx0XHRcdGlmICghcmVzcG9uc2Uub2spIHtcblx0XHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignTmV0d29yayByZXNwb25zZSB3YXMgbm90IG9rJyk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiByZXNwb25zZS5qc29uKCk7XG5cdFx0XHRcdH0pXG5cdFx0XHRcdC50aGVuKGZ1bmN0aW9uIChkYXRhKSB7XG5cdFx0XHRcdFx0dXBkYXRlUmVjb21tZW5kYXRpb25zV2lkZ2V0KGRhdGEpO1xuXHRcdFx0XHR9KVxuXHRcdFx0XHQuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG5cdFx0XHRcdFx0Y29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIHJlY29tbWVuZGF0aW9ucyBzdGF0dXM6JywgZXJyb3IpO1xuXHRcdFx0XHR9KTtcblx0XHR9XG5cdH1cblxuXHQvKipcblx0ICogTGlzdGVuIGZvciBHbG9iYWwgU2NvcmUgdXBkYXRlIGV2ZW50LlxuXHQgKiBUaGlzIGlzIGZpcmVkIGJ5IGFqYXguanMgd2hlbiB0aGUgR2xvYmFsIFNjb3JlIHBvbGxpbmcgZGV0ZWN0cyBhIGNoYW5nZS5cblx0ICovXG5cdCQoZG9jdW1lbnQpLm9uKCd3cHJHbG9iYWxTY29yZVVwZGF0ZWQgcm9ja2V0LWluc2lnaHRzLXBhZ2UtYWRkZWQgcm9ja2V0LWluc2lnaHRzLXBhZ2UtcmV0ZXN0JywgKCkgPT4ge1xuXHRcdGZldGNoUmVjb21tZW5kYXRpb25zU3RhdHVzKCk7XG5cdH0pXG59KTtcbiIsIiggKCBkb2N1bWVudCApID0+IHtcblx0J3VzZSBzdHJpY3QnO1xuXG5cdC8qKlxuXHQgKiBQb2xscyB0aGUgUm9ja2V0Q0ROIHN1YnNjcmlwdGlvbiBlbmRwb2ludCB1bnRpbCBpc19sb2FkaW5nIGJlY29tZXMgZmFsc2UuXG5cdCAqL1xuXHRjbGFzcyBSb2NrZXRDRE5TdWJzY3JpcHRpb25Qb2xsZXIge1xuXHRcdGNvbnN0cnVjdG9yKCkge1xuXHRcdFx0dGhpcy5wYXRoID0gJy93cC1yb2NrZXQvdjEvcm9ja2V0Y2RuL3N1YnNjcmlwdGlvbic7XG5cdFx0XHR0aGlzLnBvbGxJbnRlcnZhbCA9IDEwMDAwOyAvLyAxMCBzZWNvbmRzLlxuXHRcdFx0dGhpcy5tYXhSZXRyaWVzID0gNjA7IC8vIDEwIG1pbnV0ZXMgdG90YWwuXG5cdFx0XHR0aGlzLnRpbWVySWQgPSBudWxsO1xuXHRcdFx0dGhpcy5yZXRyeUNvdW50ID0gMDtcblxuXHRcdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciggJ3JvY2tldENETlN1YnNjcmlwdGlvbkxvYWRpbmcnLCAoKSA9PiB0aGlzLnN0YXJ0KCkgKTtcblxuXHRcdFx0Ly8gUmUtdHJpZ2dlciBwb2xsaW5nIGFmdGVyIHBhZ2UgcmVmcmVzaC5cblx0XHRcdGNvbnN0IGNsYXNzZXMgPSBbXG5cdFx0XHRcdCcud3ByLWljb24tb3JhbmdlLWxvYWRlcicsXG5cdFx0XHRcdCcud3ByLWNkbi1idWlsdC1pbi0tZGlzYWJsZWQnLFxuXHRcdFx0XTtcblxuXHRcdFx0Y29uc3QgYWxsUHJlc2VudCA9IGNsYXNzZXMuZXZlcnkoIGNscyA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCBjbHMgKSAhPT0gbnVsbCApO1xuXG5cdFx0XHRpZiAoIGFsbFByZXNlbnQgKSB7XG5cdFx0XHRcdHRoaXMuc3RhcnQoKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8qKlxuXHRcdCAqIFN0YXJ0cyBwb2xsaW5nLlxuXHRcdCAqL1xuXHRcdHN0YXJ0KCkge1xuXHRcdFx0aWYgKCB0aGlzLnRpbWVySWQgKSB7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblxuXHRcdFx0dGhpcy5yZXRyeUNvdW50ID0gMDtcblx0XHRcdHRoaXMucG9sbCgpO1xuXHRcdH1cblxuXHRcdC8qKlxuXHRcdCAqIFN0b3BzIHBvbGxpbmcuXG5cdFx0ICovXG5cdFx0c3RvcCgpIHtcblx0XHRcdGlmICggdGhpcy50aW1lcklkICkge1xuXHRcdFx0XHRjbGVhclRpbWVvdXQoIHRoaXMudGltZXJJZCApO1xuXHRcdFx0XHR0aGlzLnRpbWVySWQgPSBudWxsO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdC8qKlxuXHRcdCAqIFBlcmZvcm1zIGEgc2luZ2xlIHBvbGwgYW5kIHNjaGVkdWxlcyB0aGUgbmV4dCBvbmUgaWYgc3RpbGwgbG9hZGluZy5cblx0XHQgKi9cblx0XHRwb2xsKCkge1xuXHRcdFx0aWYgKCB0aGlzLnJldHJ5Q291bnQgPj0gdGhpcy5tYXhSZXRyaWVzICkge1xuXHRcdFx0XHR0aGlzLnN0b3AoKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXG5cdFx0XHR0aGlzLnJldHJ5Q291bnQrKztcblxuXHRcdFx0d2luZG93LndwLmFwaUZldGNoKCB7XG5cdFx0XHRcdHBhdGg6IHRoaXMucGF0aCxcblx0XHRcdFx0bWV0aG9kOiAnR0VUJyxcblx0XHRcdH0gKS50aGVuKCAoIHJlc3BvbnNlICkgPT4ge1xuXHRcdFx0XHRpZiAoICEgcmVzcG9uc2UgfHwgISByZXNwb25zZS5pc19sb2FkaW5nICkge1xuXHRcdFx0XHRcdHRoaXMuc3RvcCgpO1xuXHRcdFx0XHRcdHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR0aGlzLnRpbWVySWQgPSBzZXRUaW1lb3V0KCAoKSA9PiB0aGlzLnBvbGwoKSwgdGhpcy5wb2xsSW50ZXJ2YWwgKTtcblx0XHRcdH0gKS5jYXRjaCggKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnRpbWVySWQgPSBzZXRUaW1lb3V0KCAoKSA9PiB0aGlzLnBvbGwoKSwgdGhpcy5wb2xsSW50ZXJ2YWwgKTtcblx0XHRcdH0gKTtcblx0XHR9XG5cdH1cblxuXHRuZXcgUm9ja2V0Q0ROU3Vic2NyaXB0aW9uUG9sbGVyKCk7XG59ICkoIGRvY3VtZW50ICk7IiwiLyplc2xpbnQtZW52IGVzNiwgYnJvd3NlciovXG4vKiBnbG9iYWwgTWljcm9Nb2RhbCwgbWl4cGFuZWwsIHJvY2tldF9taXhwYW5lbF9kYXRhLCByb2NrZXRfY2RuX21peHBhbmVsX2RhdGEsIHJvY2tldF9hamF4X2RhdGEsIGFqYXh1cmwgKi9cbiggKCBkb2N1bWVudCwgd2luZG93ICkgPT4ge1xuXHQndXNlIHN0cmljdCc7XG5cblx0Y29uc3QgQkFOTkVSX1NUQVRFID0ge1xuXHRcdE9QRU5FRDogZmFsc2UsICAgIC8vIEJpZyBDVEEgLSBvcGVuZWQgc3RhdGVcblx0XHRDT0xMQVBTRUQ6IHRydWUgICAvLyBTbWFsbCBDVEEgLSBjb2xsYXBzZWQgc3RhdGVcblx0fTtcblxuXHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCAncm9ja2V0Q0ROQmFubmVyQXV0b0V4cGFuZGVkJywgKCkgPT4gdHJhY2tSb2NrZXRDRE5VcHNlbGxCYW5uZXJFeHBhbmRlZCgnYXV0b19saW1pdF9yZWFjaGVkJykgKTtcblx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciggJ3JvY2tldENETkJhbm5lckF1dG9Db2xsYXBzZWQnLCAoKSA9PiB0cmFja1JvY2tldENETlVwc2VsbEJhbm5lckNvbGxhcHNlZCggJ2F1dG9fbGltaXRfcmVsZWFzZWQnICkgKTtcblx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lciggJ3JvY2tldENETkJhbm5lckZpcnN0VmlzaWJsZScsICgpID0+IHRyYWNrUm9ja2V0Q0ROVXBzZWxsQmFubmVyVmlld2VkKCBCQU5ORVJfU1RBVEUuQ09MTEFQU0VEICkgKTtcblxuXHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCAnRE9NQ29udGVudExvYWRlZCcsICgpID0+IHtcblx0XHRkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCAnLndwci1yb2NrZXRjZG4tb3BlbicgKS5mb3JFYWNoKCAoIGVsICkgPT4ge1xuXHRcdFx0ZWwuYWRkRXZlbnRMaXN0ZW5lciggJ2NsaWNrJywgKCBlICkgPT4ge1xuXHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRcdGNvbnN0IGlzQ1RBID0gZWwuY2xhc3NMaXN0LmNvbnRhaW5zKCAnd3ByLXJvY2tldGNkbi1wcmljaW5nLS1jdGEnICk7XG5cdFx0XHRcdGNoZWNrQnV0dG9uVXJsQW5kT3BlbiggaXNDVEEgKTtcblx0XHRcdH0gKTtcblx0XHR9ICk7XG5cblx0XHQvLyBBbHdheXMgaW5pdGlhbGl6ZSBNaWNyb01vZGFsIHRvIHNldCB1cCBjbG9zZSBoYW5kbGVyc1xuXHRcdE1pY3JvTW9kYWwuaW5pdCgge1xuXHRcdFx0ZGlzYWJsZVNjcm9sbDogdHJ1ZVxuXHRcdH0gKTtcblxuXHRcdG1heWJlT3Blbk1vZGFsRnJvbVVSTCgpO1xuXG5cdFx0Ly8gT25seSBhdXRvLW9wZW4gbW9kYWwgaWYgdGhlcmUncyBubyBkaXJlY3QgYnV0dG9uIFVSTFxuXHRcdGlmICggISB3aW5kb3cucm9ja2V0Y2RuQnV0dG9uVXJsIHx8IHdpbmRvdy5yb2NrZXRjZG5CdXR0b25VcmwgPT09ICcnICkge1xuXHRcdFx0bWF5YmVPcGVuTW9kYWwoKTtcblxuXHRcdFx0Y29uc3QgaWZyYW1lID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JvY2tldGNkbi1pZnJhbWUnKTtcblx0XHRcdGNvbnN0IGxvYWRlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd3cHItcm9ja2V0Y2RuLW1vZGFsLWxvYWRlcicpO1xuXHRcdFx0aWYgKCBpZnJhbWUgJiYgbG9hZGVyICkge1xuXHRcdFx0XHRpZnJhbWUuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsIGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRcdGxvYWRlci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9XG5cdH0gKTtcblxuXHQvKipcblx0ICogQ2hlY2tzIGlmIHRoZSB1c2VyIGlzIGN1cnJlbnRseSBvbiB0aGUgQ0ROIHRhYi5cblx0ICpcblx0ICogQHJldHVybiB7Ym9vbGVhbn0gVHJ1ZSBpZiBvbiBDRE4gdGFiLCBmYWxzZSBvdGhlcndpc2UuXG5cdCAqL1xuXHRmdW5jdGlvbiBpc09uQ0ROVGFiKCkge1xuXHRcdHJldHVybiB3aW5kb3cubG9jYXRpb24uaGFzaCA9PT0gJyNwYWdlX2Nkbic7XG5cdH1cblxuXHRmdW5jdGlvbiBtYXliZVRyYWNrQmFubmVyVmlldygpIHtcblx0XHRjb25zdCBzbWFsbENUQSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcjd3ByLXJvY2tldGNkbi1jdGEtc21hbGwnICk7XG5cdFx0Y29uc3QgYmlnQ1RBID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJyN3cHItcm9ja2V0Y2RuLWN0YScgKTtcblxuXHRcdC8vIE9ubHkgdHJhY2sgaWYgb25lIG9mIHRoZSBiYW5uZXJzIGlzIHZpc2libGUuXG5cdFx0aWYgKCBiaWdDVEEgJiYgISBiaWdDVEEuY2xhc3NMaXN0LmNvbnRhaW5zKCAnd3ByLWlzSGlkZGVuJyApICkge1xuXHRcdFx0dHJhY2tSb2NrZXRDRE5VcHNlbGxCYW5uZXJWaWV3ZWQoIEJBTk5FUl9TVEFURS5PUEVORUQgKTtcblx0XHR9IGVsc2UgaWYgKCBzbWFsbENUQSAmJiAhIHNtYWxsQ1RBLmNsYXNzTGlzdC5jb250YWlucyggJ3dwci1pc0hpZGRlbicgKSApIHtcblx0XHRcdHRyYWNrUm9ja2V0Q0ROVXBzZWxsQmFubmVyVmlld2VkKCBCQU5ORVJfU1RBVEUuQ09MTEFQU0VEICk7XG5cdFx0fVxuXHR9XG5cblx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoICdsb2FkJywgKCkgPT4ge1xuXHRcdGxldCBvcGVuQ1RBID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJyN3cHItcm9ja2V0Y2RuLW9wZW4tY3RhJyApLFxuXHRcdFx0Y2xvc2VDVEEgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnI3dwci1yb2NrZXRjZG4tY2xvc2UtY3RhJyApLFxuXHRcdFx0c21hbGxDVEEgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnI3dwci1yb2NrZXRjZG4tY3RhLXNtYWxsJyApLFxuXHRcdFx0YmlnQ1RBID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJyN3cHItcm9ja2V0Y2RuLWN0YScgKSxcblx0XHRcdGlucHV0VG9nZ2xlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLndwci1yb2NrZXRjZG4tdG9nZ2xlLS1pbnB1dCcpO1xuXG5cdFx0Y29uc3QgY3RhVG9nZ2xlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCggJy53cHItcm9ja2V0Y2RuLWN0YS10b2dnbGUnICk7XG5cblx0XHQvKipcblx0XHQgKiBUb2dnbGVzIFJvY2tldENETiBDVEEgaW50ZXJuYWwgY29sbGFwc2VkL2V4cGFuZGVkIHN0YXRlLlxuXHRcdCAqXG5cdFx0ICogQHJldHVybiB7dm9pZH1cblx0XHQgKi9cblx0XHRmdW5jdGlvbiB0b2dnbGVCaWdDVEFTdGF0ZSgpIHtcblx0XHRcdGlmICggISBiaWdDVEEgfHwgISBjdGFUb2dnbGUubGVuZ3RoICkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGlzQ29sbGFwc2VkID0gYmlnQ1RBLmNsYXNzTGlzdC50b2dnbGUoICd3cHItcm9ja2V0Y2RuLWN0YS0tY29sbGFwc2VkJyApO1xuXHRcdFx0YmlnQ1RBLmNsYXNzTGlzdC50b2dnbGUoICd3cHItcm9ja2V0Y2RuLWN0YS0tZXhwYW5kZWQnLCAhIGlzQ29sbGFwc2VkICk7XG5cdFx0XHRjdGFUb2dnbGUuZm9yRWFjaCggKCBlbCApID0+IHtcblx0XHRcdFx0ZWwuc2V0QXR0cmlidXRlKCAnYXJpYS1leHBhbmRlZCcsIGlzQ29sbGFwc2VkID8gJ2ZhbHNlJyA6ICd0cnVlJyApO1xuXHRcdFx0fSApO1xuXG5cdFx0XHRpZiggISBpc0NvbGxhcHNlZCApIHtcblx0XHRcdFx0dHJhY2tSb2NrZXRDRE5VcHNlbGxCYW5uZXJFeHBhbmRlZCggJ21hbnVhbCcgKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHRyYWNrUm9ja2V0Q0ROVXBzZWxsQmFubmVyQ29sbGFwc2VkKCk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0aWYgKCBjdGFUb2dnbGUubGVuZ3RoICYmIGJpZ0NUQSApIHtcblx0XHRcdGN0YVRvZ2dsZS5mb3JFYWNoKCAoIGVsICkgPT4ge1xuXHRcdFx0XHRlbC5hZGRFdmVudExpc3RlbmVyKCAnY2xpY2snLCB0b2dnbGVCaWdDVEFTdGF0ZSApO1xuXHRcdFx0XHRlbC5hZGRFdmVudExpc3RlbmVyKCAna2V5ZG93bicsICggZXZlbnQgKSA9PiB7XG5cdFx0XHRcdFx0aWYgKCAnRW50ZXInID09PSBldmVudC5rZXkgfHwgJyAnID09PSBldmVudC5rZXkgKSB7XG5cdFx0XHRcdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0XHRcdFx0dG9nZ2xlQmlnQ1RBU3RhdGUoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gKTtcblx0XHRcdH0gKTtcblx0XHR9XG5cblx0XHQvLyBUcmFjayBiYW5uZXIgdmlldyBvbiBwYWdlIGxvYWQgaWYgYmFubmVyIGlzIHZpc2libGUgYW5kIHVzZXIgaXMgb24gQ0ROIHRhYi5cblx0XHRtYXliZVRyYWNrQmFubmVyVmlldygpO1xuXG5cdFx0Ly8gVHJhY2sgYmFubmVyIHZpZXcgd2hlbiB1c2VyIG5hdmlnYXRlcyB0byBDRE4gdGFiLlxuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCAnaGFzaGNoYW5nZScsICgpID0+IHtcblx0XHRcdG1heWJlVHJhY2tCYW5uZXJWaWV3KCk7XG5cdFx0fSApO1xuXG5cdFx0Ly8gUHJpY2VzIHNlbGVjdG9ycyBmb3IgdG9nZ2xpbmcgdmlzaWJpbGl0eSBiYXNlZCBvbiB0aGUgYmlsbGluZyBjeWNsZSB0b2dnbGUgc3RhdGUuXG5cdFx0Y29uc3QgcHJpY2VzID0ge1xuXHRcdFx0bW9udGhseToge1xuXHRcdFx0XHRyZWd1bGFyOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcud3ByLXJvY2tldGNkbi1wcmljaW5nLXJlZ3VsYXItcHJpY2UtLW1vbnRobHknKSxcblx0XHRcdFx0Y3VycmVudDogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLndwci1yb2NrZXRjZG4tcHJpY2luZy0tbW9udGhseScpLFxuXHRcdFx0XHRwZXJpb2Q6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy53cHItcm9ja2V0Y2RuLXByaWNpbmctLWJpbGxpbmctcGVyaW9kLS1tb250aGx5Jylcblx0XHRcdH0sXG5cdFx0XHR5ZWFybHk6IHtcblx0XHRcdFx0cmVndWxhcjogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLndwci1yb2NrZXRjZG4tcHJpY2luZy1yZWd1bGFyLXByaWNlLS15ZWFybHknKSxcblx0XHRcdFx0Y3VycmVudDogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLndwci1yb2NrZXRjZG4tcHJpY2luZy0tYW5udWFsJyksXG5cdFx0XHRcdHBlcmlvZDogZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLndwci1yb2NrZXRjZG4tcHJpY2luZy0tYmlsbGluZy1wZXJpb2QtLXllYXJseScpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ly8gRGlzcGxheSB0aGUgY29ycmVjdCBwcmljZXMgb24gcGFnZSBiYXNlZCBvbiBiaWxsaW5nIGN5Y2xlIHRvZ2dsZSBzdGF0ZS5cblx0XHRpZiAoIGlucHV0VG9nZ2xlICkge1xuXHRcdFx0aW5wdXRUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgZnVuY3Rpb24gKCkge1xuXHRcdFx0XHRjb25zdCBpc1llYXJseSA9IHRoaXMuY2hlY2tlZDtcblxuXHRcdFx0XHRpZiAoaXNZZWFybHkpIHtcblx0XHRcdFx0XHRPYmplY3QudmFsdWVzKHByaWNlcy5tb250aGx5KS5mb3JFYWNoKGxpc3QgPT4gbGlzdC5mb3JFYWNoKGVsID0+IGVsLmNsYXNzTGlzdC5hZGQoJ3dwci1pc0hpZGRlbicpKSk7XG5cdFx0XHRcdFx0T2JqZWN0LnZhbHVlcyhwcmljZXMueWVhcmx5KS5mb3JFYWNoKGxpc3QgPT4gbGlzdC5mb3JFYWNoKGVsID0+IGVsLmNsYXNzTGlzdC5yZW1vdmUoJ3dwci1pc0hpZGRlbicpKSk7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0T2JqZWN0LnZhbHVlcyhwcmljZXMubW9udGhseSkuZm9yRWFjaChsaXN0ID0+IGxpc3QuZm9yRWFjaChlbCA9PiBlbC5jbGFzc0xpc3QucmVtb3ZlKCd3cHItaXNIaWRkZW4nKSkpO1xuXHRcdFx0XHRcdE9iamVjdC52YWx1ZXMocHJpY2VzLnllYXJseSkuZm9yRWFjaChsaXN0ID0+IGxpc3QuZm9yRWFjaChlbCA9PiBlbC5jbGFzc0xpc3QuYWRkKCd3cHItaXNIaWRkZW4nKSkpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Ly8gVXBkYXRlIHRoZSBidXR0b24gVVJMIHdpdGggdGhlIGNvcnJlY3QgaXNfbW9udGhseSBwYXJhbWV0ZXIuXG5cdFx0XHRcdHVwZGF0ZUJ1dHRvblVybEJpbGxpbmdDeWNsZShpc1llYXJseSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cblx0XHQvLyBUcmFjayBSb2NrZXRDRE4gYWN0aXZhdGlvbiBmYWlsZWQgQ1RBIGNsaWNrXG5cdFx0Y29uc3QgYWN0aXZhdGlvbkNUQSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyN3cHItcm9ja2V0Y2RuLWFjdGl2YXRpb24tY3RhJyk7XG5cdFx0aWYgKGFjdGl2YXRpb25DVEEpIHtcblx0XHRcdGFjdGl2YXRpb25DVEEuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG5cdFx0XHRcdHRyYWNrUm9ja2V0Q0ROQWN0aXZhdGlvbkNUQSgpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXG5cdH0gKTtcblxuXHR3aW5kb3cub25tZXNzYWdlID0gKCBlICkgPT4ge1xuXHRcdGNvbnN0IGlmcmFtZVVSTCA9IHJvY2tldF9hamF4X2RhdGEub3JpZ2luX3VybDtcblxuXHRcdGlmICggZS5vcmlnaW4gIT09IGlmcmFtZVVSTCApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRzZXRDRE5GcmFtZUhlaWdodCggZS5kYXRhICk7XG5cdFx0Y2xvc2VNb2RhbCggZS5kYXRhICk7XG5cdFx0dG9rZW5IYW5kbGVyKCBlLmRhdGEsIGlmcmFtZVVSTCApO1xuXHRcdHByb2Nlc3NTdGF0dXMoIGUuZGF0YSApO1xuXHRcdGVuYWJsZUNETiggZS5kYXRhLCBpZnJhbWVVUkwgKTtcblx0XHRkaXNhYmxlQ0ROKCBlLmRhdGEsIGlmcmFtZVVSTCApO1xuXHRcdHZhbGlkYXRlVG9rZW5BbmRDTkFNRSggZS5kYXRhICk7XG5cdH07XG5cblx0ZnVuY3Rpb24gb3BlblJvY2tldENETk1vZGFsKCkge1xuXHRcdGNvbnN0IHJvY2tldGNkbklmcmFtZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb2NrZXRjZG4taWZyYW1lJyk7XG5cdFx0aWYgKCAhcm9ja2V0Y2RuSWZyYW1lIHx8ICFyb2NrZXRjZG5JZnJhbWUuZGF0YXNldCB8fCAhcm9ja2V0Y2RuSWZyYW1lLmRhdGFzZXQuc3JjIHx8IHJvY2tldGNkbklmcmFtZS5kYXRhc2V0LnNyYyA9PT0gcm9ja2V0Y2RuSWZyYW1lLnNyYyApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0cm9ja2V0Y2RuSWZyYW1lLnNyYyA9IHJvY2tldGNkbklmcmFtZS5kYXRhc2V0LnNyYztcblx0XHRNaWNyb01vZGFsLnNob3coICd3cHItcm9ja2V0Y2RuLW1vZGFsJyApO1xuXHR9XG5cblx0ZnVuY3Rpb24gY2hlY2tCdXR0b25VcmxBbmRPcGVuKCBpc0NUQSApIHtcblx0XHRsZXQgaWZyYW1lVmlzaXQgPSAhd2luZG93LnJvY2tldGNkbkJ1dHRvblVybDtcblx0XHQvLyBUcmFjayBDVEEgY2xpY2sgaWYgdGhpcyBpcyB0aGUgcHJpY2luZyBDVEEgYnV0dG9uLlxuXHRcdGlmICggaXNDVEEgKSB7XG5cdFx0XHR0cmFja1JvY2tldENETlVwc2VsbENUQUNsaWNrZWQoaWZyYW1lVmlzaXQpO1xuXHRcdH1cblxuXHRcdC8vIFdoaWNoIGJ1dHRvbiB3YXMgYWN0dWFsbHkgY2xpY2tlZCAtIHRoZSBkYXNoYm9hcmQtdGFiIENUQSBvciB0aGUgdXBzZWxsIGJhbm5lciBDVEEgLVxuXHRcdC8vIGNhbiBvbmx5IGJlIHJlc29sdmVkIGhlcmUuIFJldXNlZCBiZWxvdyB3aGV0aGVyIHRoZSBjbGljayBsZWFkcyB0byBhIHJlZGlyZWN0IG9yIHRoZVxuXHRcdC8vIGlmcmFtZSBmYWxsYmFjaywgc2luY2UgYm90aCBwYXRocyBjb252ZXJnZSBvbiB0aGUgc2FtZSBzaGFyZWQgYnV0dG9uL21vZGFsLlxuXHRcdGNvbnN0IHNvdXJjZSA9IGlzQ1RBID8gJ2Jhbm5lcl9jdGEnIDogJ2Rhc2hib2FyZF91cGdyYWRlJztcblxuXHRcdC8vIENoZWNrIGlmIGJ1dHRvbiBVUkwgd2FzIGluamVjdGVkIGJ5IFBIUFxuXHRcdGlmICggIWlmcmFtZVZpc2l0ICkge1xuXHRcdFx0d2luZG93LnJvY2tldGNkbkJ1dHRvblVybCA9IHNldFNvdXJjZVBhcmFtKCB3aW5kb3cucm9ja2V0Y2RuQnV0dG9uVXJsLCBzb3VyY2UgKTtcblxuXHRcdFx0Ly8gU21hbGwgZGVsYXkgdG8gZW5zdXJlIE1peHBhbmVsIGV2ZW50IGlzIHNlbnQgYmVmb3JlIG5hdmlnYXRpb25cblx0XHRcdHNldFRpbWVvdXQoIGZ1bmN0aW9uKCkge1xuXHRcdFx0XHR3aW5kb3cubG9jYXRpb24uaHJlZiA9IHdpbmRvdy5yb2NrZXRjZG5CdXR0b25Vcmw7XG5cdFx0XHR9LCAxMDAgKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gUmVtZW1iZXJlZCBzbyBlbmFibGVDRE4oKSBjYW4gcmVwb3J0IHdoaWNoIENUQSBsZWQgdG8gdGhpcyBpZnJhbWUgY2hlY2tvdXQuXG5cdFx0XHR3aW5kb3cucm9ja2V0Y2RuSWZyYW1lU291cmNlID0gc291cmNlO1xuXG5cdFx0XHQvLyBTaG93IGlmcmFtZSBtb2RhbCBhcyB1c3VhbFxuXHRcdFx0b3BlblJvY2tldENETk1vZGFsKCk7XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIFVwZGF0ZXMgdGhlIGJ1dHRvbiBVUkwgd2l0aCB0aGUgY29ycmVjdCBpc19tb250aGx5IHBhcmFtZXRlciBiYXNlZCBvbiBiaWxsaW5nIGN5Y2xlIHRvZ2dsZS5cblx0ICpcblx0ICogQHBhcmFtIHtib29sZWFufSBpc1llYXJseSAtIFRydWUgaWYgeWVhcmx5IGJpbGxpbmcgaXMgc2VsZWN0ZWQsIGZhbHNlIGZvciBtb250aGx5LlxuXHQgKi9cblx0ZnVuY3Rpb24gdXBkYXRlQnV0dG9uVXJsQmlsbGluZ0N5Y2xlKCBpc1llYXJseSApIHtcblx0XHRpZiAoICEgd2luZG93LnJvY2tldGNkbkJ1dHRvblVybCB8fCB3aW5kb3cucm9ja2V0Y2RuQnV0dG9uVXJsID09PSAnJyApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR3aW5kb3cucm9ja2V0Y2RuQnV0dG9uVXJsID0gc2V0SXNNb250aGx5UGFyYW0od2luZG93LnJvY2tldGNkbkJ1dHRvblVybCwgaXNZZWFybHkpO1xuXHR9XG5cblx0ZnVuY3Rpb24gbWF5YmVPcGVuTW9kYWwoKSB7XG5cdFx0bGV0IHBvc3REYXRhID0gJyc7XG5cblx0XHRwb3N0RGF0YSArPSAnYWN0aW9uPXJvY2tldGNkbl9wcm9jZXNzX3N0YXR1cyc7XG5cdFx0cG9zdERhdGEgKz0gJyZub25jZT0nICsgcm9ja2V0X2FqYXhfZGF0YS5ub25jZTtcblxuXHRcdGNvbnN0IHJlcXVlc3QgPSBzZW5kSFRUUFJlcXVlc3QoIHBvc3REYXRhICk7XG5cblx0XHRyZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9ICgpID0+IHtcblx0XHRcdGlmICggcmVxdWVzdC5yZWFkeVN0YXRlID09PSBYTUxIdHRwUmVxdWVzdC5ET05FICYmIDIwMCA9PT0gcmVxdWVzdC5zdGF0dXMgKSB7XG5cdFx0XHRcdGxldCByZXNwb25zZVR4dCA9IEpTT04ucGFyc2UocmVxdWVzdC5yZXNwb25zZVRleHQpO1xuXG5cdFx0XHRcdGlmICggdHJ1ZSA9PT0gcmVzcG9uc2VUeHQuc3VjY2VzcyApIHtcblx0XHRcdFx0XHRvcGVuUm9ja2V0Q0ROTW9kYWwoKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH07XG5cdH1cblxuXHRmdW5jdGlvbiBtYXliZU9wZW5Nb2RhbEZyb21VUkwoKSB7XG5cdFx0Y29uc3QgdXJsUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyggd2luZG93LmxvY2F0aW9uLnNlYXJjaCApO1xuXG5cdFx0aWYgKCB1cmxQYXJhbXMuaGFzKCAncm9ja2V0Y2RuX29wZW5faWZyYW1lJyApICYmICcxJyA9PT0gdXJsUGFyYW1zLmdldCggJ3JvY2tldGNkbl9vcGVuX2lmcmFtZScgKSApIHtcblx0XHRcdC8vIFNldCBoYXNoIHRvIHBhZ2VfY2RuIHRvIHNob3cgQ0ROIHRhYiBiZWhpbmQgbW9kYWxcblx0XHRcdHdpbmRvdy5sb2NhdGlvbi5oYXNoID0gJyNwYWdlX2Nkbic7XG5cblx0XHRcdG9wZW5Sb2NrZXRDRE5Nb2RhbCgpO1xuXG5cdFx0XHQvLyBDbGVhbiB1cCB0aGUgVVJMIHRvIHByZXZlbnQgcmUtdHJpZ2dlcmluZyBvbiByZWZyZXNoXG5cdFx0XHR1cmxQYXJhbXMuZGVsZXRlKCAncm9ja2V0Y2RuX29wZW5faWZyYW1lJyApO1xuXHRcdFx0Y29uc3Qgc2VhcmNoID0gdXJsUGFyYW1zLnRvU3RyaW5nKCk7XG5cdFx0XHRjb25zdCBuZXdVUkwgPSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgKyAoIHNlYXJjaCA/ICc/JyArIHNlYXJjaCA6ICcnICkgKyB3aW5kb3cubG9jYXRpb24uaGFzaDtcblx0XHRcdHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSgge30sICcnLCBuZXdVUkwgKTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBjbG9zZU1vZGFsKCBkYXRhICkge1xuXHRcdGlmICggISBkYXRhLmhhc093blByb3BlcnR5KCAnY2RuRnJhbWVDbG9zZScgKSApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRNaWNyb01vZGFsLmNsb3NlKCAnd3ByLXJvY2tldGNkbi1tb2RhbCcgKTtcblx0XHQvLyBFbnN1cmUgc2Nyb2xsIGlzIHJlc3RvcmVkXG5cdFx0ZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICcnO1xuXG5cdFx0bGV0IHBhZ2VzID0gWyAnaWZyYW1lLXBheW1lbnQtc3VjY2VzcycsICdpZnJhbWUtdW5zdWJzY3JpYmUtc3VjY2VzcycgXTtcblxuXHRcdGlmICggISBkYXRhLmhhc093blByb3BlcnR5KCAnY2RuX3BhZ2VfbWVzc2FnZScgKSApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRpZiAoIHBhZ2VzLmluZGV4T2YoIGRhdGEuY2RuX3BhZ2VfbWVzc2FnZSApID09PSAtMSApIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHR3aW5kb3cubG9jYXRpb24uaGFzaCA9ICcjcGFnZV9jZG4nO1xuXHRcdGRvY3VtZW50LmxvY2F0aW9uLnJlbG9hZCgpO1xuXHR9XG5cblx0ZnVuY3Rpb24gcHJvY2Vzc1N0YXR1cyggZGF0YSApIHtcblx0XHRpZiAoICEgZGF0YS5oYXNPd25Qcm9wZXJ0eSggJ3JvY2tldGNkbl9wcm9jZXNzJyApICkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGxldCBwb3N0RGF0YSA9ICcnO1xuXG5cdFx0cG9zdERhdGEgKz0gJ2FjdGlvbj1yb2NrZXRjZG5fcHJvY2Vzc19zZXQnO1xuXHRcdHBvc3REYXRhICs9ICcmc3RhdHVzPScgKyBkYXRhLnJvY2tldGNkbl9wcm9jZXNzO1xuXHRcdHBvc3REYXRhICs9ICcmbm9uY2U9JyArIHJvY2tldF9hamF4X2RhdGEubm9uY2U7XG5cblx0XHRzZW5kSFRUUFJlcXVlc3QoIHBvc3REYXRhICk7XG5cdH1cblxuXHRmdW5jdGlvbiBlbmFibGVDRE4oIGRhdGEsIGlmcmFtZVVSTCApIHtcblx0XHRsZXQgaWZyYW1lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJyNyb2NrZXRjZG4taWZyYW1lJyApLmNvbnRlbnRXaW5kb3c7XG5cblx0XHRpZiAoICEgZGF0YS5oYXNPd25Qcm9wZXJ0eSggJ3JvY2tldGNkbl91cmwnICkgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0bGV0IHBvc3REYXRhID0gJyc7XG5cblx0XHRwb3N0RGF0YSArPSAnYWN0aW9uPXJvY2tldGNkbl9lbmFibGUnO1xuXHRcdHBvc3REYXRhICs9ICcmY2RuX3VybD0nICsgZGF0YS5yb2NrZXRjZG5fdXJsO1xuXHRcdHBvc3REYXRhICs9ICcmbm9uY2U9JyArIHJvY2tldF9hamF4X2RhdGEubm9uY2U7XG5cdFx0Ly8gT25seSBzZXQgd2hlbiB0aGUgaWZyYW1lIHdhcyBvcGVuZWQgdmlhIGNoZWNrQnV0dG9uVXJsQW5kT3BlbigpIC0gYWJzZW50IHdoZW4gdGhlIG1vZGFsXG5cdFx0Ly8gd2FzIGF1dG8tcmVvcGVuZWQgKG1heWJlT3Blbk1vZGFsKCksIG1heWJlT3Blbk1vZGFsRnJvbVVSTCgpKSB3aXRoIG5vIGNsaWNrIHRvIGF0dHJpYnV0ZS5cblx0XHQvLyBDbGVhcmVkIGltbWVkaWF0ZWx5IGFmdGVyIHJlYWRpbmcgc28gYSBsYXRlciBjYWxsIHdpdGggbm8gZnJlc2ggY2xpY2sgZG9lc24ndCByZXVzZSBpdC5cblx0XHRpZiAoIHdpbmRvdy5yb2NrZXRjZG5JZnJhbWVTb3VyY2UgKSB7XG5cdFx0XHRwb3N0RGF0YSArPSAnJnNvdXJjZT0nICsgd2luZG93LnJvY2tldGNkbklmcmFtZVNvdXJjZTtcblx0XHRcdGRlbGV0ZSB3aW5kb3cucm9ja2V0Y2RuSWZyYW1lU291cmNlO1xuXHRcdH1cblxuXHRcdGNvbnN0IHJlcXVlc3QgPSBzZW5kSFRUUFJlcXVlc3QoIHBvc3REYXRhICk7XG5cblx0XHRyZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9ICgpID0+IHtcblx0XHRcdGlmICggcmVxdWVzdC5yZWFkeVN0YXRlID09PSBYTUxIdHRwUmVxdWVzdC5ET05FICYmIDIwMCA9PT0gcmVxdWVzdC5zdGF0dXMgKSB7XG5cdFx0XHRcdGxldCByZXNwb25zZVR4dCA9IEpTT04ucGFyc2UocmVxdWVzdC5yZXNwb25zZVRleHQpO1xuXHRcdFx0XHRpZnJhbWUucG9zdE1lc3NhZ2UoXG5cdFx0XHRcdFx0e1xuXHRcdFx0XHRcdFx0J3N1Y2Nlc3MnOiByZXNwb25zZVR4dC5zdWNjZXNzLFxuXHRcdFx0XHRcdFx0J2RhdGEnOiByZXNwb25zZVR4dC5kYXRhLFxuXHRcdFx0XHRcdFx0J3JvY2tldGNkbic6IHRydWVcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGlmcmFtZVVSTFxuXHRcdFx0XHQpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cblxuXHRmdW5jdGlvbiBzZXRTb3VyY2VQYXJhbSh1cmwsIHNvdXJjZSkge1xuXHRcdC8vIFRoZSByZWRpcmVjdC1iYWNrIGRlc3RpbmF0aW9uIGlzIG5lc3RlZCwgVVJMLWVuY29kZWQsIGluc2lkZSB0aGUgb3V0ZXIgVVJMJ3Ncblx0XHQvLyBkYXNoYm9hcmRfdXJsIHBhcmFtIChhbG9uZ3NpZGUgcm9ja2V0Y2RuX2NoZWNrb3V0KSAtIHNvIHRoYXQncyB3aGVyZSByb2NrZXRjZG5fc291cmNlXG5cdFx0Ly8gaGFzIHRvIGJlIGFkZGVkIHRvbywgZm9yIGhhbmRsZV9yb2NrZXRjZG5fY2hlY2tvdXRfcGFyYW1ldGVyKCkgdG8gcmVhZCBpdCBiYWNrLlxuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBvdXRlclVybCA9IG5ldyBVUkwoIHVybCApO1xuXHRcdFx0Y29uc3QgZGFzaGJvYXJkVXJsID0gb3V0ZXJVcmwuc2VhcmNoUGFyYW1zLmdldCggJ2Rhc2hib2FyZF91cmwnICk7XG5cblx0XHRcdGlmICggISBkYXNoYm9hcmRVcmwgKSB7XG5cdFx0XHRcdHJldHVybiB1cmw7XG5cdFx0XHR9XG5cblx0XHRcdGNvbnN0IGlubmVyVXJsID0gbmV3IFVSTCggZGFzaGJvYXJkVXJsICk7XG5cdFx0XHRpbm5lclVybC5zZWFyY2hQYXJhbXMuc2V0KCAncm9ja2V0Y2RuX3NvdXJjZScsIHNvdXJjZSApO1xuXHRcdFx0b3V0ZXJVcmwuc2VhcmNoUGFyYW1zLnNldCggJ2Rhc2hib2FyZF91cmwnLCBpbm5lclVybC50b1N0cmluZygpICk7XG5cblx0XHRcdHJldHVybiBvdXRlclVybC50b1N0cmluZygpO1xuXHRcdH0gY2F0Y2ggKCBlICkge1xuXHRcdFx0cmV0dXJuIHVybDtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBzZXRJc01vbnRobHlQYXJhbSh1cmwsIGlzWWVhcmx5KSB7XG5cdFx0Ly8gUmVtb3ZlIGFueSBleGlzdGluZyBpc19tb250aGx5IHBhcmFtXG5cdFx0bGV0IG5ld1VybCA9IHVybC5yZXBsYWNlKC8oWz8mXSlpc19tb250aGx5PVteJl0qL2csICcnKTtcblx0XHQvLyBBZGQgdGhlIG5ldyBwYXJhbVxuXHRcdGNvbnN0IHNlcCA9IG5ld1VybC5pbmNsdWRlcygnPycpID8gJyYnIDogJz8nO1xuXHRcdG5ld1VybCArPSBzZXAgKyAnaXNfbW9udGhseT0nICsgKGlzWWVhcmx5ID8gJzAnIDogJzEnKTtcblx0XHRyZXR1cm4gbmV3VXJsO1xuXHR9XG5cblx0ZnVuY3Rpb24gZGlzYWJsZUNETiggZGF0YSwgaWZyYW1lVVJMICkge1xuXHRcdGxldCBpZnJhbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnI3JvY2tldGNkbi1pZnJhbWUnICkuY29udGVudFdpbmRvdztcblxuXHRcdGlmICggISBkYXRhLmhhc093blByb3BlcnR5KCAncm9ja2V0Y2RuX2Rpc2FibGUnICkgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0bGV0IHBvc3REYXRhID0gJyc7XG5cblx0XHRwb3N0RGF0YSArPSAnYWN0aW9uPXJvY2tldGNkbl9kaXNhYmxlJztcblx0XHRwb3N0RGF0YSArPSAnJm5vbmNlPScgKyByb2NrZXRfYWpheF9kYXRhLm5vbmNlO1xuXG5cdFx0Y29uc3QgcmVxdWVzdCA9IHNlbmRIVFRQUmVxdWVzdCggcG9zdERhdGEgKTtcblxuXHRcdHJlcXVlc3Qub25yZWFkeXN0YXRlY2hhbmdlID0gKCkgPT4ge1xuXHRcdFx0aWYgKCByZXF1ZXN0LnJlYWR5U3RhdGUgPT09IFhNTEh0dHBSZXF1ZXN0LkRPTkUgJiYgMjAwID09PSByZXF1ZXN0LnN0YXR1cyApIHtcblx0XHRcdFx0bGV0IHJlc3BvbnNlVHh0ID0gSlNPTi5wYXJzZShyZXF1ZXN0LnJlc3BvbnNlVGV4dCk7XG5cdFx0XHRcdGlmcmFtZS5wb3N0TWVzc2FnZShcblx0XHRcdFx0XHR7XG5cdFx0XHRcdFx0XHQnc3VjY2Vzcyc6IHJlc3BvbnNlVHh0LnN1Y2Nlc3MsXG5cdFx0XHRcdFx0XHQnZGF0YSc6IHJlc3BvbnNlVHh0LmRhdGEsXG5cdFx0XHRcdFx0XHQncm9ja2V0Y2RuJzogdHJ1ZVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0aWZyYW1lVVJMXG5cdFx0XHRcdCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0fVxuXG5cdGZ1bmN0aW9uIHNlbmRIVFRQUmVxdWVzdCggcG9zdERhdGEgKSB7XG5cdFx0Y29uc3QgaHR0cFJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblxuXHRcdGh0dHBSZXF1ZXN0Lm9wZW4oICdQT1NUJywgYWpheHVybCApO1xuXHRcdGh0dHBSZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoICdDb250ZW50LVR5cGUnLCAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyApO1xuXHRcdGh0dHBSZXF1ZXN0LnNlbmQoIHBvc3REYXRhICk7XG5cblx0XHRyZXR1cm4gaHR0cFJlcXVlc3Q7XG5cdH1cblxuXHRmdW5jdGlvbiBzZXRDRE5GcmFtZUhlaWdodCggZGF0YSApIHtcblx0XHRpZiAoICEgZGF0YS5oYXNPd25Qcm9wZXJ0eSggJ2NkbkZyYW1lSGVpZ2h0JyApICkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAncm9ja2V0Y2RuLWlmcmFtZScgKS5zdHlsZS5oZWlnaHQgPSBgJHsgZGF0YS5jZG5GcmFtZUhlaWdodCB9cHhgO1xuXHR9XG5cblx0ZnVuY3Rpb24gdG9rZW5IYW5kbGVyKCBkYXRhLCBpZnJhbWVVUkwgKSB7XG5cdFx0bGV0IGlmcmFtZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoICcjcm9ja2V0Y2RuLWlmcmFtZScgKS5jb250ZW50V2luZG93O1xuXG5cdFx0aWYgKCAhIGRhdGEuaGFzT3duUHJvcGVydHkoICdyb2NrZXRjZG5fdG9rZW4nICkgKSB7XG5cdFx0XHRsZXQgZGF0YSA9IHtwcm9jZXNzOlwic3Vic2NyaWJlXCIsIG1lc3NhZ2U6XCJ0b2tlbl9ub3RfcmVjZWl2ZWRcIn07XG5cdFx0XHRpZnJhbWUucG9zdE1lc3NhZ2UoXG5cdFx0XHRcdHtcblx0XHRcdFx0XHQnc3VjY2Vzcyc6IGZhbHNlLFxuXHRcdFx0XHRcdCdkYXRhJzogZGF0YSxcblx0XHRcdFx0XHQncm9ja2V0Y2RuJzogdHJ1ZVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRpZnJhbWVVUkxcblx0XHRcdCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0bGV0IHBvc3REYXRhID0gJyc7XG5cblx0XHRwb3N0RGF0YSArPSAnYWN0aW9uPXNhdmVfcm9ja2V0Y2RuX3Rva2VuJztcblx0XHRwb3N0RGF0YSArPSAnJnZhbHVlPScgKyBkYXRhLnJvY2tldGNkbl90b2tlbjtcblx0XHRwb3N0RGF0YSArPSAnJm5vbmNlPScgKyByb2NrZXRfYWpheF9kYXRhLm5vbmNlO1xuXG5cdFx0Y29uc3QgcmVxdWVzdCA9IHNlbmRIVFRQUmVxdWVzdCggcG9zdERhdGEgKTtcblxuXHRcdHJlcXVlc3Qub25yZWFkeXN0YXRlY2hhbmdlID0gKCkgPT4ge1xuXHRcdFx0aWYgKCByZXF1ZXN0LnJlYWR5U3RhdGUgPT09IFhNTEh0dHBSZXF1ZXN0LkRPTkUgJiYgMjAwID09PSByZXF1ZXN0LnN0YXR1cyApIHtcblx0XHRcdFx0bGV0IHJlc3BvbnNlVHh0ID0gSlNPTi5wYXJzZShyZXF1ZXN0LnJlc3BvbnNlVGV4dCk7XG5cdFx0XHRcdGlmcmFtZS5wb3N0TWVzc2FnZShcblx0XHRcdFx0XHR7XG5cdFx0XHRcdFx0XHQnc3VjY2Vzcyc6IHJlc3BvbnNlVHh0LnN1Y2Nlc3MsXG5cdFx0XHRcdFx0XHQnZGF0YSc6IHJlc3BvbnNlVHh0LmRhdGEsXG5cdFx0XHRcdFx0XHQncm9ja2V0Y2RuJzogdHJ1ZVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0aWZyYW1lVVJMXG5cdFx0XHRcdCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0fVxuXG5cdGZ1bmN0aW9uIHZhbGlkYXRlVG9rZW5BbmRDTkFNRSggZGF0YSApIHtcblx0XHRpZiAoICEgZGF0YS5oYXNPd25Qcm9wZXJ0eSggJ3JvY2tldGNkbl92YWxpZGF0ZV90b2tlbicgKSB8fCAhIGRhdGEuaGFzT3duUHJvcGVydHkoICdyb2NrZXRjZG5fdmFsaWRhdGVfY25hbWUnICkgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0bGV0IHBvc3REYXRhID0gJyc7XG5cblx0XHRwb3N0RGF0YSArPSAnYWN0aW9uPXJvY2tldGNkbl92YWxpZGF0ZV90b2tlbl9jbmFtZSc7XG5cdFx0cG9zdERhdGEgKz0gJyZjZG5fdXJsPScgKyBkYXRhLnJvY2tldGNkbl92YWxpZGF0ZV9jbmFtZTtcblx0XHRwb3N0RGF0YSArPSAnJmNkbl90b2tlbj0nICsgZGF0YS5yb2NrZXRjZG5fdmFsaWRhdGVfdG9rZW47XG5cdFx0cG9zdERhdGEgKz0gJyZub25jZT0nICsgcm9ja2V0X2FqYXhfZGF0YS5ub25jZTtcblxuXHRcdGNvbnN0IHJlcXVlc3QgPSBzZW5kSFRUUFJlcXVlc3QoIHBvc3REYXRhICk7XG5cdH1cblxuXHQvKipcblx0ICogVHJhY2tzIFJvY2tldENETiBhY3RpdmF0aW9uIGZhaWxlZCBDVEEgY2xpY2sgd2l0aCBNaXhwYW5lbC5cblx0ICovXG5cdGZ1bmN0aW9uIHRyYWNrUm9ja2V0Q0ROQWN0aXZhdGlvbkNUQSgpIHtcblx0XHR0cmFja1JvY2tldENETlVwc2VsbE1peHBhbmVsRXZlbnQoICdSb2NrZXRDRE4gQWN0aXZhdGlvbiBGYWlsZWQgQ1RBIENsaWNrZWQnICk7XG5cdH1cblxuXHQvKipcblx0ICogVHJhY2tzIGEgUm9ja2V0Q0ROIHVwc2VsbCBldmVudCB3aXRoIE1peHBhbmVsLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gZXZlbnROYW1lICAgVGhlIE1peHBhbmVsIGV2ZW50IG5hbWUuXG5cdCAqIEBwYXJhbSB7T2JqZWN0fSBbZXh0cmFQcm9wc10gT3B0aW9uYWwgYWRkaXRpb25hbCBwcm9wZXJ0aWVzIHRvIG1lcmdlLlxuXHQgKi9cblx0ZnVuY3Rpb24gdHJhY2tSb2NrZXRDRE5VcHNlbGxNaXhwYW5lbEV2ZW50KCBldmVudE5hbWUsIGV4dHJhUHJvcHMgKSB7XG5cdFx0aWYgKCB0eXBlb2YgbWl4cGFuZWwgPT09ICd1bmRlZmluZWQnIHx8ICEgbWl4cGFuZWwudHJhY2sgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gQ2hlY2sgaWYgdXNlciBoYXMgb3B0ZWQgaW4uXG5cdFx0aWYgKCB0eXBlb2Ygcm9ja2V0X21peHBhbmVsX2RhdGEgPT09ICd1bmRlZmluZWQnIHx8ICEgcm9ja2V0X21peHBhbmVsX2RhdGEub3B0aW5fZW5hYmxlZCB8fCByb2NrZXRfbWl4cGFuZWxfZGF0YS5vcHRpbl9lbmFibGVkID09PSAnMCcgKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gSWRlbnRpZnkgdXNlciBpZiBhdmFpbGFibGUgLSBiZXN0LWVmZm9ydCBvbmx5LCBhYnNlbmNlIHNob3VsZG4ndCBibG9jayB0cmFja2luZy5cblx0XHRpZiAoIHJvY2tldF9taXhwYW5lbF9kYXRhLnVzZXJfaWQgJiYgdHlwZW9mIG1peHBhbmVsLmlkZW50aWZ5ID09PSAnZnVuY3Rpb24nICkge1xuXHRcdFx0bWl4cGFuZWwuaWRlbnRpZnkoIHJvY2tldF9taXhwYW5lbF9kYXRhLnVzZXJfaWQgKTtcblx0XHR9XG5cblx0XHR2YXIgY2RuRGF0YSA9IHR5cGVvZiByb2NrZXRfY2RuX21peHBhbmVsX2RhdGEgIT09ICd1bmRlZmluZWQnID8gcm9ja2V0X2Nkbl9taXhwYW5lbF9kYXRhIDoge307XG5cblx0XHR2YXIgcHJvcHMgPSB7XG5cdFx0XHRjb250ZXh0OiByb2NrZXRfbWl4cGFuZWxfZGF0YS5jb250ZXh0LFxuXHRcdFx0cGx1Z2luOiByb2NrZXRfbWl4cGFuZWxfZGF0YS5wbHVnaW4sXG5cdFx0XHRicmFuZDogcm9ja2V0X21peHBhbmVsX2RhdGEuYnJhbmQsXG5cdFx0XHRhcHBsaWNhdGlvbjogcm9ja2V0X21peHBhbmVsX2RhdGEuYXBwLFxuXHRcdFx0cGF0aDogcm9ja2V0X21peHBhbmVsX2RhdGEucGF0aCxcblx0XHRcdGNkbl9tb2RlOiBjZG5EYXRhLmNkbl9tb2RlLFxuXHRcdFx0Y2RuX3N0YXR1czogY2RuRGF0YS5jZG5fc3RhdHVzLFxuXHRcdFx0aW50ZXJhY3Rpb25fY2hhbm5lbDogJ1VJJ1xuXHRcdH07XG5cblx0XHQvLyBNZXJnZSBleHRyYSBwcm9wZXJ0aWVzIGlmIHByb3ZpZGVkIGFuZCB2YWxpZC5cblx0XHRpZiAoIGV4dHJhUHJvcHMgJiYgdHlwZW9mIGV4dHJhUHJvcHMgPT09ICdvYmplY3QnICkge1xuXHRcdFx0Zm9yICggdmFyIGtleSBpbiBleHRyYVByb3BzICkge1xuXHRcdFx0XHRpZiAoIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCggZXh0cmFQcm9wcywga2V5ICkgKSB7XG5cdFx0XHRcdFx0cHJvcHNbIGtleSBdID0gZXh0cmFQcm9wc1sga2V5IF07XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cblx0XHRtaXhwYW5lbC50cmFjayggZXZlbnROYW1lLCBwcm9wcyApO1xuXHR9XG5cblx0LyoqXG5cdCAqIFRyYWNrcyBSb2NrZXRDRE4gdXBzZWxsIGJhbm5lciB2aWV3IHdpdGggTWl4cGFuZWwuXG5cdCAqXG5cdCAqIEBwYXJhbSB7Ym9vbGVhbn0gW2lzX2NvbGxhcHNlZD1mYWxzZV0gV2hldGhlciB0aGUgc21hbGwgYmFubmVyIHZhcmlhbnQgaXMgZGlzcGxheWVkLCBTZW5kcyBgY29sbGFwc2VkYCB3aGVuIHRydWUsIG90aGVyd2lzZSBgb3BlbmVkYC5cblx0ICovXG5cdGZ1bmN0aW9uIHRyYWNrUm9ja2V0Q0ROVXBzZWxsQmFubmVyVmlld2VkKCBpc19jb2xsYXBzZWQgPSBmYWxzZSApIHtcblx0XHRpZiAoICEgaXNPbkNETlRhYigpICkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBoYXNoID0gd2luZG93LmxvY2F0aW9uLmhhc2g7XG5cdFx0Y29uc3QgYmFzZVBhdGggPSAoIHR5cGVvZiByb2NrZXRfbWl4cGFuZWxfZGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgcm9ja2V0X21peHBhbmVsX2RhdGEucGF0aCApID8gcm9ja2V0X21peHBhbmVsX2RhdGEucGF0aCA6ICcnO1xuXHRcdHRyYWNrUm9ja2V0Q0ROVXBzZWxsTWl4cGFuZWxFdmVudCggJ1JvY2tldENETiBVcHNlbGwgQmFubmVyIFZpZXdlZCcsIHtcblx0XHRcdHN0YXRlOiAgICAgaXNfY29sbGFwc2VkID8gJ2NvbGxhcHNlZCcgOiAnb3BlbmVkJyxcblx0XHRcdHBhZ2VfbmFtZTogaGFzaCxcblx0XHRcdHBhdGg6ICAgICAgYmFzZVBhdGggKyBoYXNoXG5cdFx0fSApO1xuXHR9XG5cblx0LyoqXG5cdCAqIFRyYWNrcyBSb2NrZXRDRE4gdXBzZWxsIGJhbm5lciBleHBhbmRlZCB3aXRoIE1peHBhbmVsLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gdHJpZ2dlciAnbWFudWFsJyBieSBkZWZhdWx0LlxuXHQgKi9cblx0ZnVuY3Rpb24gdHJhY2tSb2NrZXRDRE5VcHNlbGxCYW5uZXJFeHBhbmRlZCggdHJpZ2dlciApIHtcblx0XHR0cmFja1JvY2tldENETlVwc2VsbE1peHBhbmVsRXZlbnQoICdSb2NrZXRDRE4gVXBzZWxsIEJhbm5lciBFeHBhbmRlZCcsIHtcblx0XHRcdGxvY2F0aW9uOiB3aW5kb3cubG9jYXRpb24uaGFzaCxcblx0XHRcdHRyaWdnZXI6IHRyaWdnZXJcblx0XHR9ICk7XG5cdH1cblxuXHQvKipcblx0ICogVHJhY2tzIFJvY2tldENETiB1cHNlbGwgYmFubmVyIGNvbGxhcHNlZCB3aXRoIE1peHBhbmVsLlxuXHQgKlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gW3RyaWdnZXI9J21hbnVhbCddICdtYW51YWwnIHdoZW4gdXNlciBjbGlja3MgdG9nZ2xlLCAnYXV0b19saW1pdF9yZWxlYXNlZCcgd2hlbiBhIHBhZ2UgZGVsZXRpb24gZHJvcHMgY291bnQgYmVsb3cgbGltaXQuXG5cdCAqL1xuXHRmdW5jdGlvbiB0cmFja1JvY2tldENETlVwc2VsbEJhbm5lckNvbGxhcHNlZCggdHJpZ2dlciA9ICdtYW51YWwnICkge1xuXHRcdHRyYWNrUm9ja2V0Q0ROVXBzZWxsTWl4cGFuZWxFdmVudCggJ1JvY2tldENETiBVcHNlbGwgQmFubmVyIENvbGxhcHNlZCcsIHtcblx0XHRcdGxvY2F0aW9uOiB3aW5kb3cubG9jYXRpb24uaGFzaCxcblx0XHRcdHRyaWdnZXI6IHRyaWdnZXJcblx0XHR9ICk7XG5cdH1cblxuXHQvKipcblx0ICogVHJhY2tzIFJvY2tldENETiB1cHNlbGwgQ1RBIGNsaWNrIHdpdGggTWl4cGFuZWwuXG5cdCAqL1xuXHRmdW5jdGlvbiB0cmFja1JvY2tldENETlVwc2VsbENUQUNsaWNrZWQoIGlmcmFtZVZpc2l0ID0gZmFsc2UgKSB7XG5cdFx0Y29uc3QgdGFibGVMaXN0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy53cHItY2RuLWJ1aWx0LWluIC53cHItdGFibGUtbGlzdCcgKTtcblx0XHRjb25zdCBwYWdlc0NvdW50ID0gdGFibGVMaXN0ID8gdGFibGVMaXN0LnF1ZXJ5U2VsZWN0b3JBbGwoICdbZGF0YS1pZF0nICkubGVuZ3RoIDogMDtcblxuXHRcdHRyYWNrUm9ja2V0Q0ROVXBzZWxsTWl4cGFuZWxFdmVudCggJ1JvY2tldENETiBVcHNlbGwgQ1RBIENsaWNrZWQnLCB7XG5cdFx0XHRkZXN0aW5hdGlvbjogaWZyYW1lVmlzaXQgPyAnaWZyYW1lJyA6ICdleHByZXNzLWNoZWNrb3V0Jyxcblx0XHRcdHBhZ2VzX2NvdW50OiBwYWdlc0NvdW50XG5cdFx0fSApO1xuXHR9XG59ICkoIGRvY3VtZW50LCB3aW5kb3cgKTtcbiIsIi8qIVxyXG4gKiBWRVJTSU9OOiAxLjEyLjFcclxuICogREFURTogMjAxNC0wNi0yNlxyXG4gKiBVUERBVEVTIEFORCBET0NTIEFUOiBodHRwOi8vd3d3LmdyZWVuc29jay5jb21cclxuICpcclxuICogQGxpY2Vuc2UgQ29weXJpZ2h0IChjKSAyMDA4LTIwMTQsIEdyZWVuU29jay4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cclxuICogVGhpcyB3b3JrIGlzIHN1YmplY3QgdG8gdGhlIHRlcm1zIGF0IGh0dHA6Ly93d3cuZ3JlZW5zb2NrLmNvbS90ZXJtc19vZl91c2UuaHRtbCBvciBmb3JcclxuICogQ2x1YiBHcmVlblNvY2sgbWVtYmVycywgdGhlIHNvZnR3YXJlIGFncmVlbWVudCB0aGF0IHdhcyBpc3N1ZWQgd2l0aCB5b3VyIG1lbWJlcnNoaXAuXHJcbiAqIFxyXG4gKiBAYXV0aG9yOiBKYWNrIERveWxlLCBqYWNrQGdyZWVuc29jay5jb21cclxuICovXHJcbih3aW5kb3cuX2dzUXVldWV8fCh3aW5kb3cuX2dzUXVldWU9W10pKS5wdXNoKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7d2luZG93Ll9nc0RlZmluZShcIlRpbWVsaW5lTGl0ZVwiLFtcImNvcmUuQW5pbWF0aW9uXCIsXCJjb3JlLlNpbXBsZVRpbWVsaW5lXCIsXCJUd2VlbkxpdGVcIl0sZnVuY3Rpb24odCxlLGkpe3ZhciBzPWZ1bmN0aW9uKHQpe2UuY2FsbCh0aGlzLHQpLHRoaXMuX2xhYmVscz17fSx0aGlzLmF1dG9SZW1vdmVDaGlsZHJlbj10aGlzLnZhcnMuYXV0b1JlbW92ZUNoaWxkcmVuPT09ITAsdGhpcy5zbW9vdGhDaGlsZFRpbWluZz10aGlzLnZhcnMuc21vb3RoQ2hpbGRUaW1pbmc9PT0hMCx0aGlzLl9zb3J0Q2hpbGRyZW49ITAsdGhpcy5fb25VcGRhdGU9dGhpcy52YXJzLm9uVXBkYXRlO3ZhciBpLHMscj10aGlzLnZhcnM7Zm9yKHMgaW4gcilpPXJbc10sYShpKSYmLTEhPT1pLmpvaW4oXCJcIikuaW5kZXhPZihcIntzZWxmfVwiKSYmKHJbc109dGhpcy5fc3dhcFNlbGZJblBhcmFtcyhpKSk7YShyLnR3ZWVucykmJnRoaXMuYWRkKHIudHdlZW5zLDAsci5hbGlnbixyLnN0YWdnZXIpfSxyPTFlLTEwLG49aS5faW50ZXJuYWxzLmlzU2VsZWN0b3IsYT1pLl9pbnRlcm5hbHMuaXNBcnJheSxvPVtdLGg9d2luZG93Ll9nc0RlZmluZS5nbG9iYWxzLGw9ZnVuY3Rpb24odCl7dmFyIGUsaT17fTtmb3IoZSBpbiB0KWlbZV09dFtlXTtyZXR1cm4gaX0sXz1mdW5jdGlvbih0LGUsaSxzKXt0Ll90aW1lbGluZS5wYXVzZSh0Ll9zdGFydFRpbWUpLGUmJmUuYXBwbHkoc3x8dC5fdGltZWxpbmUsaXx8byl9LHU9by5zbGljZSxmPXMucHJvdG90eXBlPW5ldyBlO3JldHVybiBzLnZlcnNpb249XCIxLjEyLjFcIixmLmNvbnN0cnVjdG9yPXMsZi5raWxsKCkuX2djPSExLGYudG89ZnVuY3Rpb24odCxlLHMscil7dmFyIG49cy5yZXBlYXQmJmguVHdlZW5NYXh8fGk7cmV0dXJuIGU/dGhpcy5hZGQobmV3IG4odCxlLHMpLHIpOnRoaXMuc2V0KHQscyxyKX0sZi5mcm9tPWZ1bmN0aW9uKHQsZSxzLHIpe3JldHVybiB0aGlzLmFkZCgocy5yZXBlYXQmJmguVHdlZW5NYXh8fGkpLmZyb20odCxlLHMpLHIpfSxmLmZyb21Ubz1mdW5jdGlvbih0LGUscyxyLG4pe3ZhciBhPXIucmVwZWF0JiZoLlR3ZWVuTWF4fHxpO3JldHVybiBlP3RoaXMuYWRkKGEuZnJvbVRvKHQsZSxzLHIpLG4pOnRoaXMuc2V0KHQscixuKX0sZi5zdGFnZ2VyVG89ZnVuY3Rpb24odCxlLHIsYSxvLGgsXyxmKXt2YXIgcCxjPW5ldyBzKHtvbkNvbXBsZXRlOmgsb25Db21wbGV0ZVBhcmFtczpfLG9uQ29tcGxldGVTY29wZTpmLHNtb290aENoaWxkVGltaW5nOnRoaXMuc21vb3RoQ2hpbGRUaW1pbmd9KTtmb3IoXCJzdHJpbmdcIj09dHlwZW9mIHQmJih0PWkuc2VsZWN0b3IodCl8fHQpLG4odCkmJih0PXUuY2FsbCh0LDApKSxhPWF8fDAscD0wO3QubGVuZ3RoPnA7cCsrKXIuc3RhcnRBdCYmKHIuc3RhcnRBdD1sKHIuc3RhcnRBdCkpLGMudG8odFtwXSxlLGwocikscCphKTtyZXR1cm4gdGhpcy5hZGQoYyxvKX0sZi5zdGFnZ2VyRnJvbT1mdW5jdGlvbih0LGUsaSxzLHIsbixhLG8pe3JldHVybiBpLmltbWVkaWF0ZVJlbmRlcj0wIT1pLmltbWVkaWF0ZVJlbmRlcixpLnJ1bkJhY2t3YXJkcz0hMCx0aGlzLnN0YWdnZXJUbyh0LGUsaSxzLHIsbixhLG8pfSxmLnN0YWdnZXJGcm9tVG89ZnVuY3Rpb24odCxlLGkscyxyLG4sYSxvLGgpe3JldHVybiBzLnN0YXJ0QXQ9aSxzLmltbWVkaWF0ZVJlbmRlcj0wIT1zLmltbWVkaWF0ZVJlbmRlciYmMCE9aS5pbW1lZGlhdGVSZW5kZXIsdGhpcy5zdGFnZ2VyVG8odCxlLHMscixuLGEsbyxoKX0sZi5jYWxsPWZ1bmN0aW9uKHQsZSxzLHIpe3JldHVybiB0aGlzLmFkZChpLmRlbGF5ZWRDYWxsKDAsdCxlLHMpLHIpfSxmLnNldD1mdW5jdGlvbih0LGUscyl7cmV0dXJuIHM9dGhpcy5fcGFyc2VUaW1lT3JMYWJlbChzLDAsITApLG51bGw9PWUuaW1tZWRpYXRlUmVuZGVyJiYoZS5pbW1lZGlhdGVSZW5kZXI9cz09PXRoaXMuX3RpbWUmJiF0aGlzLl9wYXVzZWQpLHRoaXMuYWRkKG5ldyBpKHQsMCxlKSxzKX0scy5leHBvcnRSb290PWZ1bmN0aW9uKHQsZSl7dD10fHx7fSxudWxsPT10LnNtb290aENoaWxkVGltaW5nJiYodC5zbW9vdGhDaGlsZFRpbWluZz0hMCk7dmFyIHIsbixhPW5ldyBzKHQpLG89YS5fdGltZWxpbmU7Zm9yKG51bGw9PWUmJihlPSEwKSxvLl9yZW1vdmUoYSwhMCksYS5fc3RhcnRUaW1lPTAsYS5fcmF3UHJldlRpbWU9YS5fdGltZT1hLl90b3RhbFRpbWU9by5fdGltZSxyPW8uX2ZpcnN0O3I7KW49ci5fbmV4dCxlJiZyIGluc3RhbmNlb2YgaSYmci50YXJnZXQ9PT1yLnZhcnMub25Db21wbGV0ZXx8YS5hZGQocixyLl9zdGFydFRpbWUtci5fZGVsYXkpLHI9bjtyZXR1cm4gby5hZGQoYSwwKSxhfSxmLmFkZD1mdW5jdGlvbihyLG4sbyxoKXt2YXIgbCxfLHUsZixwLGM7aWYoXCJudW1iZXJcIiE9dHlwZW9mIG4mJihuPXRoaXMuX3BhcnNlVGltZU9yTGFiZWwobiwwLCEwLHIpKSwhKHIgaW5zdGFuY2VvZiB0KSl7aWYociBpbnN0YW5jZW9mIEFycmF5fHxyJiZyLnB1c2gmJmEocikpe2ZvcihvPW98fFwibm9ybWFsXCIsaD1ofHwwLGw9bixfPXIubGVuZ3RoLHU9MDtfPnU7dSsrKWEoZj1yW3VdKSYmKGY9bmV3IHMoe3R3ZWVuczpmfSkpLHRoaXMuYWRkKGYsbCksXCJzdHJpbmdcIiE9dHlwZW9mIGYmJlwiZnVuY3Rpb25cIiE9dHlwZW9mIGYmJihcInNlcXVlbmNlXCI9PT1vP2w9Zi5fc3RhcnRUaW1lK2YudG90YWxEdXJhdGlvbigpL2YuX3RpbWVTY2FsZTpcInN0YXJ0XCI9PT1vJiYoZi5fc3RhcnRUaW1lLT1mLmRlbGF5KCkpKSxsKz1oO3JldHVybiB0aGlzLl91bmNhY2hlKCEwKX1pZihcInN0cmluZ1wiPT10eXBlb2YgcilyZXR1cm4gdGhpcy5hZGRMYWJlbChyLG4pO2lmKFwiZnVuY3Rpb25cIiE9dHlwZW9mIHIpdGhyb3dcIkNhbm5vdCBhZGQgXCIrcitcIiBpbnRvIHRoZSB0aW1lbGluZTsgaXQgaXMgbm90IGEgdHdlZW4sIHRpbWVsaW5lLCBmdW5jdGlvbiwgb3Igc3RyaW5nLlwiO3I9aS5kZWxheWVkQ2FsbCgwLHIpfWlmKGUucHJvdG90eXBlLmFkZC5jYWxsKHRoaXMscixuKSwodGhpcy5fZ2N8fHRoaXMuX3RpbWU9PT10aGlzLl9kdXJhdGlvbikmJiF0aGlzLl9wYXVzZWQmJnRoaXMuX2R1cmF0aW9uPHRoaXMuZHVyYXRpb24oKSlmb3IocD10aGlzLGM9cC5yYXdUaW1lKCk+ci5fc3RhcnRUaW1lO3AuX3RpbWVsaW5lOyljJiZwLl90aW1lbGluZS5zbW9vdGhDaGlsZFRpbWluZz9wLnRvdGFsVGltZShwLl90b3RhbFRpbWUsITApOnAuX2djJiZwLl9lbmFibGVkKCEwLCExKSxwPXAuX3RpbWVsaW5lO3JldHVybiB0aGlzfSxmLnJlbW92ZT1mdW5jdGlvbihlKXtpZihlIGluc3RhbmNlb2YgdClyZXR1cm4gdGhpcy5fcmVtb3ZlKGUsITEpO2lmKGUgaW5zdGFuY2VvZiBBcnJheXx8ZSYmZS5wdXNoJiZhKGUpKXtmb3IodmFyIGk9ZS5sZW5ndGg7LS1pPi0xOyl0aGlzLnJlbW92ZShlW2ldKTtyZXR1cm4gdGhpc31yZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgZT90aGlzLnJlbW92ZUxhYmVsKGUpOnRoaXMua2lsbChudWxsLGUpfSxmLl9yZW1vdmU9ZnVuY3Rpb24odCxpKXtlLnByb3RvdHlwZS5fcmVtb3ZlLmNhbGwodGhpcyx0LGkpO3ZhciBzPXRoaXMuX2xhc3Q7cmV0dXJuIHM/dGhpcy5fdGltZT5zLl9zdGFydFRpbWUrcy5fdG90YWxEdXJhdGlvbi9zLl90aW1lU2NhbGUmJih0aGlzLl90aW1lPXRoaXMuZHVyYXRpb24oKSx0aGlzLl90b3RhbFRpbWU9dGhpcy5fdG90YWxEdXJhdGlvbik6dGhpcy5fdGltZT10aGlzLl90b3RhbFRpbWU9dGhpcy5fZHVyYXRpb249dGhpcy5fdG90YWxEdXJhdGlvbj0wLHRoaXN9LGYuYXBwZW5kPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHRoaXMuYWRkKHQsdGhpcy5fcGFyc2VUaW1lT3JMYWJlbChudWxsLGUsITAsdCkpfSxmLmluc2VydD1mLmluc2VydE11bHRpcGxlPWZ1bmN0aW9uKHQsZSxpLHMpe3JldHVybiB0aGlzLmFkZCh0LGV8fDAsaSxzKX0sZi5hcHBlbmRNdWx0aXBsZT1mdW5jdGlvbih0LGUsaSxzKXtyZXR1cm4gdGhpcy5hZGQodCx0aGlzLl9wYXJzZVRpbWVPckxhYmVsKG51bGwsZSwhMCx0KSxpLHMpfSxmLmFkZExhYmVsPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIHRoaXMuX2xhYmVsc1t0XT10aGlzLl9wYXJzZVRpbWVPckxhYmVsKGUpLHRoaXN9LGYuYWRkUGF1c2U9ZnVuY3Rpb24odCxlLGkscyl7cmV0dXJuIHRoaXMuY2FsbChfLFtcIntzZWxmfVwiLGUsaSxzXSx0aGlzLHQpfSxmLnJlbW92ZUxhYmVsPWZ1bmN0aW9uKHQpe3JldHVybiBkZWxldGUgdGhpcy5fbGFiZWxzW3RdLHRoaXN9LGYuZ2V0TGFiZWxUaW1lPWZ1bmN0aW9uKHQpe3JldHVybiBudWxsIT10aGlzLl9sYWJlbHNbdF0/dGhpcy5fbGFiZWxzW3RdOi0xfSxmLl9wYXJzZVRpbWVPckxhYmVsPWZ1bmN0aW9uKGUsaSxzLHIpe3ZhciBuO2lmKHIgaW5zdGFuY2VvZiB0JiZyLnRpbWVsaW5lPT09dGhpcyl0aGlzLnJlbW92ZShyKTtlbHNlIGlmKHImJihyIGluc3RhbmNlb2YgQXJyYXl8fHIucHVzaCYmYShyKSkpZm9yKG49ci5sZW5ndGg7LS1uPi0xOylyW25daW5zdGFuY2VvZiB0JiZyW25dLnRpbWVsaW5lPT09dGhpcyYmdGhpcy5yZW1vdmUocltuXSk7aWYoXCJzdHJpbmdcIj09dHlwZW9mIGkpcmV0dXJuIHRoaXMuX3BhcnNlVGltZU9yTGFiZWwoaSxzJiZcIm51bWJlclwiPT10eXBlb2YgZSYmbnVsbD09dGhpcy5fbGFiZWxzW2ldP2UtdGhpcy5kdXJhdGlvbigpOjAscyk7aWYoaT1pfHwwLFwic3RyaW5nXCIhPXR5cGVvZiBlfHwhaXNOYU4oZSkmJm51bGw9PXRoaXMuX2xhYmVsc1tlXSludWxsPT1lJiYoZT10aGlzLmR1cmF0aW9uKCkpO2Vsc2V7aWYobj1lLmluZGV4T2YoXCI9XCIpLC0xPT09bilyZXR1cm4gbnVsbD09dGhpcy5fbGFiZWxzW2VdP3M/dGhpcy5fbGFiZWxzW2VdPXRoaXMuZHVyYXRpb24oKStpOmk6dGhpcy5fbGFiZWxzW2VdK2k7aT1wYXJzZUludChlLmNoYXJBdChuLTEpK1wiMVwiLDEwKSpOdW1iZXIoZS5zdWJzdHIobisxKSksZT1uPjE/dGhpcy5fcGFyc2VUaW1lT3JMYWJlbChlLnN1YnN0cigwLG4tMSksMCxzKTp0aGlzLmR1cmF0aW9uKCl9cmV0dXJuIE51bWJlcihlKStpfSxmLnNlZWs9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy50b3RhbFRpbWUoXCJudW1iZXJcIj09dHlwZW9mIHQ/dDp0aGlzLl9wYXJzZVRpbWVPckxhYmVsKHQpLGUhPT0hMSl9LGYuc3RvcD1mdW5jdGlvbigpe3JldHVybiB0aGlzLnBhdXNlZCghMCl9LGYuZ290b0FuZFBsYXk9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5wbGF5KHQsZSl9LGYuZ290b0FuZFN0b3A9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5wYXVzZSh0LGUpfSxmLnJlbmRlcj1mdW5jdGlvbih0LGUsaSl7dGhpcy5fZ2MmJnRoaXMuX2VuYWJsZWQoITAsITEpO3ZhciBzLG4sYSxoLGwsXz10aGlzLl9kaXJ0eT90aGlzLnRvdGFsRHVyYXRpb24oKTp0aGlzLl90b3RhbER1cmF0aW9uLHU9dGhpcy5fdGltZSxmPXRoaXMuX3N0YXJ0VGltZSxwPXRoaXMuX3RpbWVTY2FsZSxjPXRoaXMuX3BhdXNlZDtpZih0Pj1fPyh0aGlzLl90b3RhbFRpbWU9dGhpcy5fdGltZT1fLHRoaXMuX3JldmVyc2VkfHx0aGlzLl9oYXNQYXVzZWRDaGlsZCgpfHwobj0hMCxoPVwib25Db21wbGV0ZVwiLDA9PT10aGlzLl9kdXJhdGlvbiYmKDA9PT10fHwwPnRoaXMuX3Jhd1ByZXZUaW1lfHx0aGlzLl9yYXdQcmV2VGltZT09PXIpJiZ0aGlzLl9yYXdQcmV2VGltZSE9PXQmJnRoaXMuX2ZpcnN0JiYobD0hMCx0aGlzLl9yYXdQcmV2VGltZT5yJiYoaD1cIm9uUmV2ZXJzZUNvbXBsZXRlXCIpKSksdGhpcy5fcmF3UHJldlRpbWU9dGhpcy5fZHVyYXRpb258fCFlfHx0fHx0aGlzLl9yYXdQcmV2VGltZT09PXQ/dDpyLHQ9XysxZS00KToxZS03PnQ/KHRoaXMuX3RvdGFsVGltZT10aGlzLl90aW1lPTAsKDAhPT11fHwwPT09dGhpcy5fZHVyYXRpb24mJnRoaXMuX3Jhd1ByZXZUaW1lIT09ciYmKHRoaXMuX3Jhd1ByZXZUaW1lPjB8fDA+dCYmdGhpcy5fcmF3UHJldlRpbWU+PTApKSYmKGg9XCJvblJldmVyc2VDb21wbGV0ZVwiLG49dGhpcy5fcmV2ZXJzZWQpLDA+dD8odGhpcy5fYWN0aXZlPSExLDA9PT10aGlzLl9kdXJhdGlvbiYmdGhpcy5fcmF3UHJldlRpbWU+PTAmJnRoaXMuX2ZpcnN0JiYobD0hMCksdGhpcy5fcmF3UHJldlRpbWU9dCk6KHRoaXMuX3Jhd1ByZXZUaW1lPXRoaXMuX2R1cmF0aW9ufHwhZXx8dHx8dGhpcy5fcmF3UHJldlRpbWU9PT10P3Q6cix0PTAsdGhpcy5faW5pdHRlZHx8KGw9ITApKSk6dGhpcy5fdG90YWxUaW1lPXRoaXMuX3RpbWU9dGhpcy5fcmF3UHJldlRpbWU9dCx0aGlzLl90aW1lIT09dSYmdGhpcy5fZmlyc3R8fGl8fGwpe2lmKHRoaXMuX2luaXR0ZWR8fCh0aGlzLl9pbml0dGVkPSEwKSx0aGlzLl9hY3RpdmV8fCF0aGlzLl9wYXVzZWQmJnRoaXMuX3RpbWUhPT11JiZ0PjAmJih0aGlzLl9hY3RpdmU9ITApLDA9PT11JiZ0aGlzLnZhcnMub25TdGFydCYmMCE9PXRoaXMuX3RpbWUmJihlfHx0aGlzLnZhcnMub25TdGFydC5hcHBseSh0aGlzLnZhcnMub25TdGFydFNjb3BlfHx0aGlzLHRoaXMudmFycy5vblN0YXJ0UGFyYW1zfHxvKSksdGhpcy5fdGltZT49dSlmb3Iocz10aGlzLl9maXJzdDtzJiYoYT1zLl9uZXh0LCF0aGlzLl9wYXVzZWR8fGMpOykocy5fYWN0aXZlfHxzLl9zdGFydFRpbWU8PXRoaXMuX3RpbWUmJiFzLl9wYXVzZWQmJiFzLl9nYykmJihzLl9yZXZlcnNlZD9zLnJlbmRlcigocy5fZGlydHk/cy50b3RhbER1cmF0aW9uKCk6cy5fdG90YWxEdXJhdGlvbiktKHQtcy5fc3RhcnRUaW1lKSpzLl90aW1lU2NhbGUsZSxpKTpzLnJlbmRlcigodC1zLl9zdGFydFRpbWUpKnMuX3RpbWVTY2FsZSxlLGkpKSxzPWE7ZWxzZSBmb3Iocz10aGlzLl9sYXN0O3MmJihhPXMuX3ByZXYsIXRoaXMuX3BhdXNlZHx8Yyk7KShzLl9hY3RpdmV8fHU+PXMuX3N0YXJ0VGltZSYmIXMuX3BhdXNlZCYmIXMuX2djKSYmKHMuX3JldmVyc2VkP3MucmVuZGVyKChzLl9kaXJ0eT9zLnRvdGFsRHVyYXRpb24oKTpzLl90b3RhbER1cmF0aW9uKS0odC1zLl9zdGFydFRpbWUpKnMuX3RpbWVTY2FsZSxlLGkpOnMucmVuZGVyKCh0LXMuX3N0YXJ0VGltZSkqcy5fdGltZVNjYWxlLGUsaSkpLHM9YTt0aGlzLl9vblVwZGF0ZSYmKGV8fHRoaXMuX29uVXBkYXRlLmFwcGx5KHRoaXMudmFycy5vblVwZGF0ZVNjb3BlfHx0aGlzLHRoaXMudmFycy5vblVwZGF0ZVBhcmFtc3x8bykpLGgmJih0aGlzLl9nY3x8KGY9PT10aGlzLl9zdGFydFRpbWV8fHAhPT10aGlzLl90aW1lU2NhbGUpJiYoMD09PXRoaXMuX3RpbWV8fF8+PXRoaXMudG90YWxEdXJhdGlvbigpKSYmKG4mJih0aGlzLl90aW1lbGluZS5hdXRvUmVtb3ZlQ2hpbGRyZW4mJnRoaXMuX2VuYWJsZWQoITEsITEpLHRoaXMuX2FjdGl2ZT0hMSksIWUmJnRoaXMudmFyc1toXSYmdGhpcy52YXJzW2hdLmFwcGx5KHRoaXMudmFyc1toK1wiU2NvcGVcIl18fHRoaXMsdGhpcy52YXJzW2grXCJQYXJhbXNcIl18fG8pKSl9fSxmLl9oYXNQYXVzZWRDaGlsZD1mdW5jdGlvbigpe2Zvcih2YXIgdD10aGlzLl9maXJzdDt0Oyl7aWYodC5fcGF1c2VkfHx0IGluc3RhbmNlb2YgcyYmdC5faGFzUGF1c2VkQ2hpbGQoKSlyZXR1cm4hMDt0PXQuX25leHR9cmV0dXJuITF9LGYuZ2V0Q2hpbGRyZW49ZnVuY3Rpb24odCxlLHMscil7cj1yfHwtOTk5OTk5OTk5OTtmb3IodmFyIG49W10sYT10aGlzLl9maXJzdCxvPTA7YTspcj5hLl9zdGFydFRpbWV8fChhIGluc3RhbmNlb2YgaT9lIT09ITEmJihuW28rK109YSk6KHMhPT0hMSYmKG5bbysrXT1hKSx0IT09ITEmJihuPW4uY29uY2F0KGEuZ2V0Q2hpbGRyZW4oITAsZSxzKSksbz1uLmxlbmd0aCkpKSxhPWEuX25leHQ7cmV0dXJuIG59LGYuZ2V0VHdlZW5zT2Y9ZnVuY3Rpb24odCxlKXt2YXIgcyxyLG49dGhpcy5fZ2MsYT1bXSxvPTA7Zm9yKG4mJnRoaXMuX2VuYWJsZWQoITAsITApLHM9aS5nZXRUd2VlbnNPZih0KSxyPXMubGVuZ3RoOy0tcj4tMTspKHNbcl0udGltZWxpbmU9PT10aGlzfHxlJiZ0aGlzLl9jb250YWlucyhzW3JdKSkmJihhW28rK109c1tyXSk7cmV0dXJuIG4mJnRoaXMuX2VuYWJsZWQoITEsITApLGF9LGYuX2NvbnRhaW5zPWZ1bmN0aW9uKHQpe2Zvcih2YXIgZT10LnRpbWVsaW5lO2U7KXtpZihlPT09dGhpcylyZXR1cm4hMDtlPWUudGltZWxpbmV9cmV0dXJuITF9LGYuc2hpZnRDaGlsZHJlbj1mdW5jdGlvbih0LGUsaSl7aT1pfHwwO2Zvcih2YXIgcyxyPXRoaXMuX2ZpcnN0LG49dGhpcy5fbGFiZWxzO3I7KXIuX3N0YXJ0VGltZT49aSYmKHIuX3N0YXJ0VGltZSs9dCkscj1yLl9uZXh0O2lmKGUpZm9yKHMgaW4gbiluW3NdPj1pJiYobltzXSs9dCk7cmV0dXJuIHRoaXMuX3VuY2FjaGUoITApfSxmLl9raWxsPWZ1bmN0aW9uKHQsZSl7aWYoIXQmJiFlKXJldHVybiB0aGlzLl9lbmFibGVkKCExLCExKTtmb3IodmFyIGk9ZT90aGlzLmdldFR3ZWVuc09mKGUpOnRoaXMuZ2V0Q2hpbGRyZW4oITAsITAsITEpLHM9aS5sZW5ndGgscj0hMTstLXM+LTE7KWlbc10uX2tpbGwodCxlKSYmKHI9ITApO3JldHVybiByfSxmLmNsZWFyPWZ1bmN0aW9uKHQpe3ZhciBlPXRoaXMuZ2V0Q2hpbGRyZW4oITEsITAsITApLGk9ZS5sZW5ndGg7Zm9yKHRoaXMuX3RpbWU9dGhpcy5fdG90YWxUaW1lPTA7LS1pPi0xOyllW2ldLl9lbmFibGVkKCExLCExKTtyZXR1cm4gdCE9PSExJiYodGhpcy5fbGFiZWxzPXt9KSx0aGlzLl91bmNhY2hlKCEwKX0sZi5pbnZhbGlkYXRlPWZ1bmN0aW9uKCl7Zm9yKHZhciB0PXRoaXMuX2ZpcnN0O3Q7KXQuaW52YWxpZGF0ZSgpLHQ9dC5fbmV4dDtyZXR1cm4gdGhpc30sZi5fZW5hYmxlZD1mdW5jdGlvbih0LGkpe2lmKHQ9PT10aGlzLl9nYylmb3IodmFyIHM9dGhpcy5fZmlyc3Q7czspcy5fZW5hYmxlZCh0LCEwKSxzPXMuX25leHQ7cmV0dXJuIGUucHJvdG90eXBlLl9lbmFibGVkLmNhbGwodGhpcyx0LGkpfSxmLmR1cmF0aW9uPWZ1bmN0aW9uKHQpe3JldHVybiBhcmd1bWVudHMubGVuZ3RoPygwIT09dGhpcy5kdXJhdGlvbigpJiYwIT09dCYmdGhpcy50aW1lU2NhbGUodGhpcy5fZHVyYXRpb24vdCksdGhpcyk6KHRoaXMuX2RpcnR5JiZ0aGlzLnRvdGFsRHVyYXRpb24oKSx0aGlzLl9kdXJhdGlvbil9LGYudG90YWxEdXJhdGlvbj1mdW5jdGlvbih0KXtpZighYXJndW1lbnRzLmxlbmd0aCl7aWYodGhpcy5fZGlydHkpe2Zvcih2YXIgZSxpLHM9MCxyPXRoaXMuX2xhc3Qsbj05OTk5OTk5OTk5OTk7cjspZT1yLl9wcmV2LHIuX2RpcnR5JiZyLnRvdGFsRHVyYXRpb24oKSxyLl9zdGFydFRpbWU+biYmdGhpcy5fc29ydENoaWxkcmVuJiYhci5fcGF1c2VkP3RoaXMuYWRkKHIsci5fc3RhcnRUaW1lLXIuX2RlbGF5KTpuPXIuX3N0YXJ0VGltZSwwPnIuX3N0YXJ0VGltZSYmIXIuX3BhdXNlZCYmKHMtPXIuX3N0YXJ0VGltZSx0aGlzLl90aW1lbGluZS5zbW9vdGhDaGlsZFRpbWluZyYmKHRoaXMuX3N0YXJ0VGltZSs9ci5fc3RhcnRUaW1lL3RoaXMuX3RpbWVTY2FsZSksdGhpcy5zaGlmdENoaWxkcmVuKC1yLl9zdGFydFRpbWUsITEsLTk5OTk5OTk5OTkpLG49MCksaT1yLl9zdGFydFRpbWUrci5fdG90YWxEdXJhdGlvbi9yLl90aW1lU2NhbGUsaT5zJiYocz1pKSxyPWU7dGhpcy5fZHVyYXRpb249dGhpcy5fdG90YWxEdXJhdGlvbj1zLHRoaXMuX2RpcnR5PSExfXJldHVybiB0aGlzLl90b3RhbER1cmF0aW9ufXJldHVybiAwIT09dGhpcy50b3RhbER1cmF0aW9uKCkmJjAhPT10JiZ0aGlzLnRpbWVTY2FsZSh0aGlzLl90b3RhbER1cmF0aW9uL3QpLHRoaXN9LGYudXNlc0ZyYW1lcz1mdW5jdGlvbigpe2Zvcih2YXIgZT10aGlzLl90aW1lbGluZTtlLl90aW1lbGluZTspZT1lLl90aW1lbGluZTtyZXR1cm4gZT09PXQuX3Jvb3RGcmFtZXNUaW1lbGluZX0sZi5yYXdUaW1lPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX3BhdXNlZD90aGlzLl90b3RhbFRpbWU6KHRoaXMuX3RpbWVsaW5lLnJhd1RpbWUoKS10aGlzLl9zdGFydFRpbWUpKnRoaXMuX3RpbWVTY2FsZX0sc30sITApfSksd2luZG93Ll9nc0RlZmluZSYmd2luZG93Ll9nc1F1ZXVlLnBvcCgpKCk7IiwiLyohXHJcbiAqIFZFUlNJT046IDEuMTIuMVxyXG4gKiBEQVRFOiAyMDE0LTA2LTI2XHJcbiAqIFVQREFURVMgQU5EIERPQ1MgQVQ6IGh0dHA6Ly93d3cuZ3JlZW5zb2NrLmNvbVxyXG4gKlxyXG4gKiBAbGljZW5zZSBDb3B5cmlnaHQgKGMpIDIwMDgtMjAxNCwgR3JlZW5Tb2NrLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG4gKiBUaGlzIHdvcmsgaXMgc3ViamVjdCB0byB0aGUgdGVybXMgYXQgaHR0cDovL3d3dy5ncmVlbnNvY2suY29tL3Rlcm1zX29mX3VzZS5odG1sIG9yIGZvclxyXG4gKiBDbHViIEdyZWVuU29jayBtZW1iZXJzLCB0aGUgc29mdHdhcmUgYWdyZWVtZW50IHRoYXQgd2FzIGlzc3VlZCB3aXRoIHlvdXIgbWVtYmVyc2hpcC5cclxuICogXHJcbiAqIEBhdXRob3I6IEphY2sgRG95bGUsIGphY2tAZ3JlZW5zb2NrLmNvbVxyXG4gKi9cclxuKGZ1bmN0aW9uKHQpe1widXNlIHN0cmljdFwiO3ZhciBlPXQuR3JlZW5Tb2NrR2xvYmFsc3x8dDtpZighZS5Ud2VlbkxpdGUpe3ZhciBpLHMsbixyLGEsbz1mdW5jdGlvbih0KXt2YXIgaSxzPXQuc3BsaXQoXCIuXCIpLG49ZTtmb3IoaT0wO3MubGVuZ3RoPmk7aSsrKW5bc1tpXV09bj1uW3NbaV1dfHx7fTtyZXR1cm4gbn0sbD1vKFwiY29tLmdyZWVuc29ja1wiKSxoPTFlLTEwLF89W10uc2xpY2UsdT1mdW5jdGlvbigpe30sbT1mdW5jdGlvbigpe3ZhciB0PU9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcsZT10LmNhbGwoW10pO3JldHVybiBmdW5jdGlvbihpKXtyZXR1cm4gbnVsbCE9aSYmKGkgaW5zdGFuY2VvZiBBcnJheXx8XCJvYmplY3RcIj09dHlwZW9mIGkmJiEhaS5wdXNoJiZ0LmNhbGwoaSk9PT1lKX19KCksZj17fSxwPWZ1bmN0aW9uKGkscyxuLHIpe3RoaXMuc2M9ZltpXT9mW2ldLnNjOltdLGZbaV09dGhpcyx0aGlzLmdzQ2xhc3M9bnVsbCx0aGlzLmZ1bmM9bjt2YXIgYT1bXTt0aGlzLmNoZWNrPWZ1bmN0aW9uKGwpe2Zvcih2YXIgaCxfLHUsbSxjPXMubGVuZ3RoLGQ9YzstLWM+LTE7KShoPWZbc1tjXV18fG5ldyBwKHNbY10sW10pKS5nc0NsYXNzPyhhW2NdPWguZ3NDbGFzcyxkLS0pOmwmJmguc2MucHVzaCh0aGlzKTtpZigwPT09ZCYmbilmb3IoXz0oXCJjb20uZ3JlZW5zb2NrLlwiK2kpLnNwbGl0KFwiLlwiKSx1PV8ucG9wKCksbT1vKF8uam9pbihcIi5cIikpW3VdPXRoaXMuZ3NDbGFzcz1uLmFwcGx5KG4sYSksciYmKGVbdV09bSxcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKCh0LkdyZWVuU29ja0FNRFBhdGg/dC5HcmVlblNvY2tBTURQYXRoK1wiL1wiOlwiXCIpK2kuc3BsaXQoXCIuXCIpLmpvaW4oXCIvXCIpLFtdLGZ1bmN0aW9uKCl7cmV0dXJuIG19KTpcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlJiZtb2R1bGUuZXhwb3J0cyYmKG1vZHVsZS5leHBvcnRzPW0pKSxjPTA7dGhpcy5zYy5sZW5ndGg+YztjKyspdGhpcy5zY1tjXS5jaGVjaygpfSx0aGlzLmNoZWNrKCEwKX0sYz10Ll9nc0RlZmluZT1mdW5jdGlvbih0LGUsaSxzKXtyZXR1cm4gbmV3IHAodCxlLGkscyl9LGQ9bC5fY2xhc3M9ZnVuY3Rpb24odCxlLGkpe3JldHVybiBlPWV8fGZ1bmN0aW9uKCl7fSxjKHQsW10sZnVuY3Rpb24oKXtyZXR1cm4gZX0saSksZX07Yy5nbG9iYWxzPWU7dmFyIHY9WzAsMCwxLDFdLGc9W10sVD1kKFwiZWFzaW5nLkVhc2VcIixmdW5jdGlvbih0LGUsaSxzKXt0aGlzLl9mdW5jPXQsdGhpcy5fdHlwZT1pfHwwLHRoaXMuX3Bvd2VyPXN8fDAsdGhpcy5fcGFyYW1zPWU/di5jb25jYXQoZSk6dn0sITApLHk9VC5tYXA9e30sdz1ULnJlZ2lzdGVyPWZ1bmN0aW9uKHQsZSxpLHMpe2Zvcih2YXIgbixyLGEsbyxoPWUuc3BsaXQoXCIsXCIpLF89aC5sZW5ndGgsdT0oaXx8XCJlYXNlSW4sZWFzZU91dCxlYXNlSW5PdXRcIikuc3BsaXQoXCIsXCIpOy0tXz4tMTspZm9yKHI9aFtfXSxuPXM/ZChcImVhc2luZy5cIityLG51bGwsITApOmwuZWFzaW5nW3JdfHx7fSxhPXUubGVuZ3RoOy0tYT4tMTspbz11W2FdLHlbcitcIi5cIitvXT15W28rcl09bltvXT10LmdldFJhdGlvP3Q6dFtvXXx8bmV3IHR9O2ZvcihuPVQucHJvdG90eXBlLG4uX2NhbGNFbmQ9ITEsbi5nZXRSYXRpbz1mdW5jdGlvbih0KXtpZih0aGlzLl9mdW5jKXJldHVybiB0aGlzLl9wYXJhbXNbMF09dCx0aGlzLl9mdW5jLmFwcGx5KG51bGwsdGhpcy5fcGFyYW1zKTt2YXIgZT10aGlzLl90eXBlLGk9dGhpcy5fcG93ZXIscz0xPT09ZT8xLXQ6Mj09PWU/dDouNT50PzIqdDoyKigxLXQpO3JldHVybiAxPT09aT9zKj1zOjI9PT1pP3MqPXMqczozPT09aT9zKj1zKnMqczo0PT09aSYmKHMqPXMqcypzKnMpLDE9PT1lPzEtczoyPT09ZT9zOi41PnQ/cy8yOjEtcy8yfSxpPVtcIkxpbmVhclwiLFwiUXVhZFwiLFwiQ3ViaWNcIixcIlF1YXJ0XCIsXCJRdWludCxTdHJvbmdcIl0scz1pLmxlbmd0aDstLXM+LTE7KW49aVtzXStcIixQb3dlclwiK3MsdyhuZXcgVChudWxsLG51bGwsMSxzKSxuLFwiZWFzZU91dFwiLCEwKSx3KG5ldyBUKG51bGwsbnVsbCwyLHMpLG4sXCJlYXNlSW5cIisoMD09PXM/XCIsZWFzZU5vbmVcIjpcIlwiKSksdyhuZXcgVChudWxsLG51bGwsMyxzKSxuLFwiZWFzZUluT3V0XCIpO3kubGluZWFyPWwuZWFzaW5nLkxpbmVhci5lYXNlSW4seS5zd2luZz1sLmVhc2luZy5RdWFkLmVhc2VJbk91dDt2YXIgUD1kKFwiZXZlbnRzLkV2ZW50RGlzcGF0Y2hlclwiLGZ1bmN0aW9uKHQpe3RoaXMuX2xpc3RlbmVycz17fSx0aGlzLl9ldmVudFRhcmdldD10fHx0aGlzfSk7bj1QLnByb3RvdHlwZSxuLmFkZEV2ZW50TGlzdGVuZXI9ZnVuY3Rpb24odCxlLGkscyxuKXtuPW58fDA7dmFyIG8sbCxoPXRoaXMuX2xpc3RlbmVyc1t0XSxfPTA7Zm9yKG51bGw9PWgmJih0aGlzLl9saXN0ZW5lcnNbdF09aD1bXSksbD1oLmxlbmd0aDstLWw+LTE7KW89aFtsXSxvLmM9PT1lJiZvLnM9PT1pP2guc3BsaWNlKGwsMSk6MD09PV8mJm4+by5wciYmKF89bCsxKTtoLnNwbGljZShfLDAse2M6ZSxzOmksdXA6cyxwcjpufSksdGhpcyE9PXJ8fGF8fHIud2FrZSgpfSxuLnJlbW92ZUV2ZW50TGlzdGVuZXI9ZnVuY3Rpb24odCxlKXt2YXIgaSxzPXRoaXMuX2xpc3RlbmVyc1t0XTtpZihzKWZvcihpPXMubGVuZ3RoOy0taT4tMTspaWYoc1tpXS5jPT09ZSlyZXR1cm4gcy5zcGxpY2UoaSwxKSx2b2lkIDB9LG4uZGlzcGF0Y2hFdmVudD1mdW5jdGlvbih0KXt2YXIgZSxpLHMsbj10aGlzLl9saXN0ZW5lcnNbdF07aWYobilmb3IoZT1uLmxlbmd0aCxpPXRoaXMuX2V2ZW50VGFyZ2V0Oy0tZT4tMTspcz1uW2VdLHMudXA/cy5jLmNhbGwocy5zfHxpLHt0eXBlOnQsdGFyZ2V0Oml9KTpzLmMuY2FsbChzLnN8fGkpfTt2YXIgaz10LnJlcXVlc3RBbmltYXRpb25GcmFtZSxiPXQuY2FuY2VsQW5pbWF0aW9uRnJhbWUsQT1EYXRlLm5vd3x8ZnVuY3Rpb24oKXtyZXR1cm4obmV3IERhdGUpLmdldFRpbWUoKX0sUz1BKCk7Zm9yKGk9W1wibXNcIixcIm1velwiLFwid2Via2l0XCIsXCJvXCJdLHM9aS5sZW5ndGg7LS1zPi0xJiYhazspaz10W2lbc10rXCJSZXF1ZXN0QW5pbWF0aW9uRnJhbWVcIl0sYj10W2lbc10rXCJDYW5jZWxBbmltYXRpb25GcmFtZVwiXXx8dFtpW3NdK1wiQ2FuY2VsUmVxdWVzdEFuaW1hdGlvbkZyYW1lXCJdO2QoXCJUaWNrZXJcIixmdW5jdGlvbih0LGUpe3ZhciBpLHMsbixvLGwsXz10aGlzLG09QSgpLGY9ZSE9PSExJiZrLHA9NTAwLGM9MzMsZD1mdW5jdGlvbih0KXt2YXIgZSxyLGE9QSgpLVM7YT5wJiYobSs9YS1jKSxTKz1hLF8udGltZT0oUy1tKS8xZTMsZT1fLnRpbWUtbCwoIWl8fGU+MHx8dD09PSEwKSYmKF8uZnJhbWUrKyxsKz1lKyhlPj1vPy4wMDQ6by1lKSxyPSEwKSx0IT09ITAmJihuPXMoZCkpLHImJl8uZGlzcGF0Y2hFdmVudChcInRpY2tcIil9O1AuY2FsbChfKSxfLnRpbWU9Xy5mcmFtZT0wLF8udGljaz1mdW5jdGlvbigpe2QoITApfSxfLmxhZ1Ntb290aGluZz1mdW5jdGlvbih0LGUpe3A9dHx8MS9oLGM9TWF0aC5taW4oZSxwLDApfSxfLnNsZWVwPWZ1bmN0aW9uKCl7bnVsbCE9biYmKGYmJmI/YihuKTpjbGVhclRpbWVvdXQobikscz11LG49bnVsbCxfPT09ciYmKGE9ITEpKX0sXy53YWtlPWZ1bmN0aW9uKCl7bnVsbCE9PW4/Xy5zbGVlcCgpOl8uZnJhbWU+MTAmJihTPUEoKS1wKzUpLHM9MD09PWk/dTpmJiZrP2s6ZnVuY3Rpb24odCl7cmV0dXJuIHNldFRpbWVvdXQodCwwfDFlMyoobC1fLnRpbWUpKzEpfSxfPT09ciYmKGE9ITApLGQoMil9LF8uZnBzPWZ1bmN0aW9uKHQpe3JldHVybiBhcmd1bWVudHMubGVuZ3RoPyhpPXQsbz0xLyhpfHw2MCksbD10aGlzLnRpbWUrbyxfLndha2UoKSx2b2lkIDApOml9LF8udXNlUkFGPWZ1bmN0aW9uKHQpe3JldHVybiBhcmd1bWVudHMubGVuZ3RoPyhfLnNsZWVwKCksZj10LF8uZnBzKGkpLHZvaWQgMCk6Zn0sXy5mcHModCksc2V0VGltZW91dChmdW5jdGlvbigpe2YmJighbnx8NT5fLmZyYW1lKSYmXy51c2VSQUYoITEpfSwxNTAwKX0pLG49bC5UaWNrZXIucHJvdG90eXBlPW5ldyBsLmV2ZW50cy5FdmVudERpc3BhdGNoZXIsbi5jb25zdHJ1Y3Rvcj1sLlRpY2tlcjt2YXIgeD1kKFwiY29yZS5BbmltYXRpb25cIixmdW5jdGlvbih0LGUpe2lmKHRoaXMudmFycz1lPWV8fHt9LHRoaXMuX2R1cmF0aW9uPXRoaXMuX3RvdGFsRHVyYXRpb249dHx8MCx0aGlzLl9kZWxheT1OdW1iZXIoZS5kZWxheSl8fDAsdGhpcy5fdGltZVNjYWxlPTEsdGhpcy5fYWN0aXZlPWUuaW1tZWRpYXRlUmVuZGVyPT09ITAsdGhpcy5kYXRhPWUuZGF0YSx0aGlzLl9yZXZlcnNlZD1lLnJldmVyc2VkPT09ITAsQil7YXx8ci53YWtlKCk7dmFyIGk9dGhpcy52YXJzLnVzZUZyYW1lcz9ROkI7aS5hZGQodGhpcyxpLl90aW1lKSx0aGlzLnZhcnMucGF1c2VkJiZ0aGlzLnBhdXNlZCghMCl9fSk7cj14LnRpY2tlcj1uZXcgbC5UaWNrZXIsbj14LnByb3RvdHlwZSxuLl9kaXJ0eT1uLl9nYz1uLl9pbml0dGVkPW4uX3BhdXNlZD0hMSxuLl90b3RhbFRpbWU9bi5fdGltZT0wLG4uX3Jhd1ByZXZUaW1lPS0xLG4uX25leHQ9bi5fbGFzdD1uLl9vblVwZGF0ZT1uLl90aW1lbGluZT1uLnRpbWVsaW5lPW51bGwsbi5fcGF1c2VkPSExO3ZhciBDPWZ1bmN0aW9uKCl7YSYmQSgpLVM+MmUzJiZyLndha2UoKSxzZXRUaW1lb3V0KEMsMmUzKX07QygpLG4ucGxheT1mdW5jdGlvbih0LGUpe3JldHVybiBudWxsIT10JiZ0aGlzLnNlZWsodCxlKSx0aGlzLnJldmVyc2VkKCExKS5wYXVzZWQoITEpfSxuLnBhdXNlPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIG51bGwhPXQmJnRoaXMuc2Vlayh0LGUpLHRoaXMucGF1c2VkKCEwKX0sbi5yZXN1bWU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gbnVsbCE9dCYmdGhpcy5zZWVrKHQsZSksdGhpcy5wYXVzZWQoITEpfSxuLnNlZWs9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy50b3RhbFRpbWUoTnVtYmVyKHQpLGUhPT0hMSl9LG4ucmVzdGFydD1mdW5jdGlvbih0LGUpe3JldHVybiB0aGlzLnJldmVyc2VkKCExKS5wYXVzZWQoITEpLnRvdGFsVGltZSh0Py10aGlzLl9kZWxheTowLGUhPT0hMSwhMCl9LG4ucmV2ZXJzZT1mdW5jdGlvbih0LGUpe3JldHVybiBudWxsIT10JiZ0aGlzLnNlZWsodHx8dGhpcy50b3RhbER1cmF0aW9uKCksZSksdGhpcy5yZXZlcnNlZCghMCkucGF1c2VkKCExKX0sbi5yZW5kZXI9ZnVuY3Rpb24oKXt9LG4uaW52YWxpZGF0ZT1mdW5jdGlvbigpe3JldHVybiB0aGlzfSxuLmlzQWN0aXZlPWZ1bmN0aW9uKCl7dmFyIHQsZT10aGlzLl90aW1lbGluZSxpPXRoaXMuX3N0YXJ0VGltZTtyZXR1cm4hZXx8IXRoaXMuX2djJiYhdGhpcy5fcGF1c2VkJiZlLmlzQWN0aXZlKCkmJih0PWUucmF3VGltZSgpKT49aSYmaSt0aGlzLnRvdGFsRHVyYXRpb24oKS90aGlzLl90aW1lU2NhbGU+dH0sbi5fZW5hYmxlZD1mdW5jdGlvbih0LGUpe3JldHVybiBhfHxyLndha2UoKSx0aGlzLl9nYz0hdCx0aGlzLl9hY3RpdmU9dGhpcy5pc0FjdGl2ZSgpLGUhPT0hMCYmKHQmJiF0aGlzLnRpbWVsaW5lP3RoaXMuX3RpbWVsaW5lLmFkZCh0aGlzLHRoaXMuX3N0YXJ0VGltZS10aGlzLl9kZWxheSk6IXQmJnRoaXMudGltZWxpbmUmJnRoaXMuX3RpbWVsaW5lLl9yZW1vdmUodGhpcywhMCkpLCExfSxuLl9raWxsPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX2VuYWJsZWQoITEsITEpfSxuLmtpbGw9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdGhpcy5fa2lsbCh0LGUpLHRoaXN9LG4uX3VuY2FjaGU9ZnVuY3Rpb24odCl7Zm9yKHZhciBlPXQ/dGhpczp0aGlzLnRpbWVsaW5lO2U7KWUuX2RpcnR5PSEwLGU9ZS50aW1lbGluZTtyZXR1cm4gdGhpc30sbi5fc3dhcFNlbGZJblBhcmFtcz1mdW5jdGlvbih0KXtmb3IodmFyIGU9dC5sZW5ndGgsaT10LmNvbmNhdCgpOy0tZT4tMTspXCJ7c2VsZn1cIj09PXRbZV0mJihpW2VdPXRoaXMpO3JldHVybiBpfSxuLmV2ZW50Q2FsbGJhY2s9ZnVuY3Rpb24odCxlLGkscyl7aWYoXCJvblwiPT09KHR8fFwiXCIpLnN1YnN0cigwLDIpKXt2YXIgbj10aGlzLnZhcnM7aWYoMT09PWFyZ3VtZW50cy5sZW5ndGgpcmV0dXJuIG5bdF07bnVsbD09ZT9kZWxldGUgblt0XTooblt0XT1lLG5bdCtcIlBhcmFtc1wiXT1tKGkpJiYtMSE9PWkuam9pbihcIlwiKS5pbmRleE9mKFwie3NlbGZ9XCIpP3RoaXMuX3N3YXBTZWxmSW5QYXJhbXMoaSk6aSxuW3QrXCJTY29wZVwiXT1zKSxcIm9uVXBkYXRlXCI9PT10JiYodGhpcy5fb25VcGRhdGU9ZSl9cmV0dXJuIHRoaXN9LG4uZGVsYXk9ZnVuY3Rpb24odCl7cmV0dXJuIGFyZ3VtZW50cy5sZW5ndGg/KHRoaXMuX3RpbWVsaW5lLnNtb290aENoaWxkVGltaW5nJiZ0aGlzLnN0YXJ0VGltZSh0aGlzLl9zdGFydFRpbWUrdC10aGlzLl9kZWxheSksdGhpcy5fZGVsYXk9dCx0aGlzKTp0aGlzLl9kZWxheX0sbi5kdXJhdGlvbj1mdW5jdGlvbih0KXtyZXR1cm4gYXJndW1lbnRzLmxlbmd0aD8odGhpcy5fZHVyYXRpb249dGhpcy5fdG90YWxEdXJhdGlvbj10LHRoaXMuX3VuY2FjaGUoITApLHRoaXMuX3RpbWVsaW5lLnNtb290aENoaWxkVGltaW5nJiZ0aGlzLl90aW1lPjAmJnRoaXMuX3RpbWU8dGhpcy5fZHVyYXRpb24mJjAhPT10JiZ0aGlzLnRvdGFsVGltZSh0aGlzLl90b3RhbFRpbWUqKHQvdGhpcy5fZHVyYXRpb24pLCEwKSx0aGlzKToodGhpcy5fZGlydHk9ITEsdGhpcy5fZHVyYXRpb24pfSxuLnRvdGFsRHVyYXRpb249ZnVuY3Rpb24odCl7cmV0dXJuIHRoaXMuX2RpcnR5PSExLGFyZ3VtZW50cy5sZW5ndGg/dGhpcy5kdXJhdGlvbih0KTp0aGlzLl90b3RhbER1cmF0aW9ufSxuLnRpbWU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gYXJndW1lbnRzLmxlbmd0aD8odGhpcy5fZGlydHkmJnRoaXMudG90YWxEdXJhdGlvbigpLHRoaXMudG90YWxUaW1lKHQ+dGhpcy5fZHVyYXRpb24/dGhpcy5fZHVyYXRpb246dCxlKSk6dGhpcy5fdGltZX0sbi50b3RhbFRpbWU9ZnVuY3Rpb24odCxlLGkpe2lmKGF8fHIud2FrZSgpLCFhcmd1bWVudHMubGVuZ3RoKXJldHVybiB0aGlzLl90b3RhbFRpbWU7aWYodGhpcy5fdGltZWxpbmUpe2lmKDA+dCYmIWkmJih0Kz10aGlzLnRvdGFsRHVyYXRpb24oKSksdGhpcy5fdGltZWxpbmUuc21vb3RoQ2hpbGRUaW1pbmcpe3RoaXMuX2RpcnR5JiZ0aGlzLnRvdGFsRHVyYXRpb24oKTt2YXIgcz10aGlzLl90b3RhbER1cmF0aW9uLG49dGhpcy5fdGltZWxpbmU7aWYodD5zJiYhaSYmKHQ9cyksdGhpcy5fc3RhcnRUaW1lPSh0aGlzLl9wYXVzZWQ/dGhpcy5fcGF1c2VUaW1lOm4uX3RpbWUpLSh0aGlzLl9yZXZlcnNlZD9zLXQ6dCkvdGhpcy5fdGltZVNjYWxlLG4uX2RpcnR5fHx0aGlzLl91bmNhY2hlKCExKSxuLl90aW1lbGluZSlmb3IoO24uX3RpbWVsaW5lOyluLl90aW1lbGluZS5fdGltZSE9PShuLl9zdGFydFRpbWUrbi5fdG90YWxUaW1lKS9uLl90aW1lU2NhbGUmJm4udG90YWxUaW1lKG4uX3RvdGFsVGltZSwhMCksbj1uLl90aW1lbGluZX10aGlzLl9nYyYmdGhpcy5fZW5hYmxlZCghMCwhMSksKHRoaXMuX3RvdGFsVGltZSE9PXR8fDA9PT10aGlzLl9kdXJhdGlvbikmJih0aGlzLnJlbmRlcih0LGUsITEpLHoubGVuZ3RoJiZxKCkpfXJldHVybiB0aGlzfSxuLnByb2dyZXNzPW4udG90YWxQcm9ncmVzcz1mdW5jdGlvbih0LGUpe3JldHVybiBhcmd1bWVudHMubGVuZ3RoP3RoaXMudG90YWxUaW1lKHRoaXMuZHVyYXRpb24oKSp0LGUpOnRoaXMuX3RpbWUvdGhpcy5kdXJhdGlvbigpfSxuLnN0YXJ0VGltZT1mdW5jdGlvbih0KXtyZXR1cm4gYXJndW1lbnRzLmxlbmd0aD8odCE9PXRoaXMuX3N0YXJ0VGltZSYmKHRoaXMuX3N0YXJ0VGltZT10LHRoaXMudGltZWxpbmUmJnRoaXMudGltZWxpbmUuX3NvcnRDaGlsZHJlbiYmdGhpcy50aW1lbGluZS5hZGQodGhpcyx0LXRoaXMuX2RlbGF5KSksdGhpcyk6dGhpcy5fc3RhcnRUaW1lfSxuLnRpbWVTY2FsZT1mdW5jdGlvbih0KXtpZighYXJndW1lbnRzLmxlbmd0aClyZXR1cm4gdGhpcy5fdGltZVNjYWxlO2lmKHQ9dHx8aCx0aGlzLl90aW1lbGluZSYmdGhpcy5fdGltZWxpbmUuc21vb3RoQ2hpbGRUaW1pbmcpe3ZhciBlPXRoaXMuX3BhdXNlVGltZSxpPWV8fDA9PT1lP2U6dGhpcy5fdGltZWxpbmUudG90YWxUaW1lKCk7dGhpcy5fc3RhcnRUaW1lPWktKGktdGhpcy5fc3RhcnRUaW1lKSp0aGlzLl90aW1lU2NhbGUvdH1yZXR1cm4gdGhpcy5fdGltZVNjYWxlPXQsdGhpcy5fdW5jYWNoZSghMSl9LG4ucmV2ZXJzZWQ9ZnVuY3Rpb24odCl7cmV0dXJuIGFyZ3VtZW50cy5sZW5ndGg/KHQhPXRoaXMuX3JldmVyc2VkJiYodGhpcy5fcmV2ZXJzZWQ9dCx0aGlzLnRvdGFsVGltZSh0aGlzLl90aW1lbGluZSYmIXRoaXMuX3RpbWVsaW5lLnNtb290aENoaWxkVGltaW5nP3RoaXMudG90YWxEdXJhdGlvbigpLXRoaXMuX3RvdGFsVGltZTp0aGlzLl90b3RhbFRpbWUsITApKSx0aGlzKTp0aGlzLl9yZXZlcnNlZH0sbi5wYXVzZWQ9ZnVuY3Rpb24odCl7aWYoIWFyZ3VtZW50cy5sZW5ndGgpcmV0dXJuIHRoaXMuX3BhdXNlZDtpZih0IT10aGlzLl9wYXVzZWQmJnRoaXMuX3RpbWVsaW5lKXthfHx0fHxyLndha2UoKTt2YXIgZT10aGlzLl90aW1lbGluZSxpPWUucmF3VGltZSgpLHM9aS10aGlzLl9wYXVzZVRpbWU7IXQmJmUuc21vb3RoQ2hpbGRUaW1pbmcmJih0aGlzLl9zdGFydFRpbWUrPXMsdGhpcy5fdW5jYWNoZSghMSkpLHRoaXMuX3BhdXNlVGltZT10P2k6bnVsbCx0aGlzLl9wYXVzZWQ9dCx0aGlzLl9hY3RpdmU9dGhpcy5pc0FjdGl2ZSgpLCF0JiYwIT09cyYmdGhpcy5faW5pdHRlZCYmdGhpcy5kdXJhdGlvbigpJiZ0aGlzLnJlbmRlcihlLnNtb290aENoaWxkVGltaW5nP3RoaXMuX3RvdGFsVGltZTooaS10aGlzLl9zdGFydFRpbWUpL3RoaXMuX3RpbWVTY2FsZSwhMCwhMCl9cmV0dXJuIHRoaXMuX2djJiYhdCYmdGhpcy5fZW5hYmxlZCghMCwhMSksdGhpc307dmFyIFI9ZChcImNvcmUuU2ltcGxlVGltZWxpbmVcIixmdW5jdGlvbih0KXt4LmNhbGwodGhpcywwLHQpLHRoaXMuYXV0b1JlbW92ZUNoaWxkcmVuPXRoaXMuc21vb3RoQ2hpbGRUaW1pbmc9ITB9KTtuPVIucHJvdG90eXBlPW5ldyB4LG4uY29uc3RydWN0b3I9UixuLmtpbGwoKS5fZ2M9ITEsbi5fZmlyc3Q9bi5fbGFzdD1udWxsLG4uX3NvcnRDaGlsZHJlbj0hMSxuLmFkZD1uLmluc2VydD1mdW5jdGlvbih0LGUpe3ZhciBpLHM7aWYodC5fc3RhcnRUaW1lPU51bWJlcihlfHwwKSt0Ll9kZWxheSx0Ll9wYXVzZWQmJnRoaXMhPT10Ll90aW1lbGluZSYmKHQuX3BhdXNlVGltZT10Ll9zdGFydFRpbWUrKHRoaXMucmF3VGltZSgpLXQuX3N0YXJ0VGltZSkvdC5fdGltZVNjYWxlKSx0LnRpbWVsaW5lJiZ0LnRpbWVsaW5lLl9yZW1vdmUodCwhMCksdC50aW1lbGluZT10Ll90aW1lbGluZT10aGlzLHQuX2djJiZ0Ll9lbmFibGVkKCEwLCEwKSxpPXRoaXMuX2xhc3QsdGhpcy5fc29ydENoaWxkcmVuKWZvcihzPXQuX3N0YXJ0VGltZTtpJiZpLl9zdGFydFRpbWU+czspaT1pLl9wcmV2O3JldHVybiBpPyh0Ll9uZXh0PWkuX25leHQsaS5fbmV4dD10KToodC5fbmV4dD10aGlzLl9maXJzdCx0aGlzLl9maXJzdD10KSx0Ll9uZXh0P3QuX25leHQuX3ByZXY9dDp0aGlzLl9sYXN0PXQsdC5fcHJldj1pLHRoaXMuX3RpbWVsaW5lJiZ0aGlzLl91bmNhY2hlKCEwKSx0aGlzfSxuLl9yZW1vdmU9ZnVuY3Rpb24odCxlKXtyZXR1cm4gdC50aW1lbGluZT09PXRoaXMmJihlfHx0Ll9lbmFibGVkKCExLCEwKSx0LnRpbWVsaW5lPW51bGwsdC5fcHJldj90Ll9wcmV2Ll9uZXh0PXQuX25leHQ6dGhpcy5fZmlyc3Q9PT10JiYodGhpcy5fZmlyc3Q9dC5fbmV4dCksdC5fbmV4dD90Ll9uZXh0Ll9wcmV2PXQuX3ByZXY6dGhpcy5fbGFzdD09PXQmJih0aGlzLl9sYXN0PXQuX3ByZXYpLHRoaXMuX3RpbWVsaW5lJiZ0aGlzLl91bmNhY2hlKCEwKSksdGhpc30sbi5yZW5kZXI9ZnVuY3Rpb24odCxlLGkpe3ZhciBzLG49dGhpcy5fZmlyc3Q7Zm9yKHRoaXMuX3RvdGFsVGltZT10aGlzLl90aW1lPXRoaXMuX3Jhd1ByZXZUaW1lPXQ7bjspcz1uLl9uZXh0LChuLl9hY3RpdmV8fHQ+PW4uX3N0YXJ0VGltZSYmIW4uX3BhdXNlZCkmJihuLl9yZXZlcnNlZD9uLnJlbmRlcigobi5fZGlydHk/bi50b3RhbER1cmF0aW9uKCk6bi5fdG90YWxEdXJhdGlvbiktKHQtbi5fc3RhcnRUaW1lKSpuLl90aW1lU2NhbGUsZSxpKTpuLnJlbmRlcigodC1uLl9zdGFydFRpbWUpKm4uX3RpbWVTY2FsZSxlLGkpKSxuPXN9LG4ucmF3VGltZT1mdW5jdGlvbigpe3JldHVybiBhfHxyLndha2UoKSx0aGlzLl90b3RhbFRpbWV9O3ZhciBEPWQoXCJUd2VlbkxpdGVcIixmdW5jdGlvbihlLGkscyl7aWYoeC5jYWxsKHRoaXMsaSxzKSx0aGlzLnJlbmRlcj1ELnByb3RvdHlwZS5yZW5kZXIsbnVsbD09ZSl0aHJvd1wiQ2Fubm90IHR3ZWVuIGEgbnVsbCB0YXJnZXQuXCI7dGhpcy50YXJnZXQ9ZT1cInN0cmluZ1wiIT10eXBlb2YgZT9lOkQuc2VsZWN0b3IoZSl8fGU7dmFyIG4scixhLG89ZS5qcXVlcnl8fGUubGVuZ3RoJiZlIT09dCYmZVswXSYmKGVbMF09PT10fHxlWzBdLm5vZGVUeXBlJiZlWzBdLnN0eWxlJiYhZS5ub2RlVHlwZSksbD10aGlzLnZhcnMub3ZlcndyaXRlO2lmKHRoaXMuX292ZXJ3cml0ZT1sPW51bGw9PWw/R1tELmRlZmF1bHRPdmVyd3JpdGVdOlwibnVtYmVyXCI9PXR5cGVvZiBsP2w+PjA6R1tsXSwob3x8ZSBpbnN0YW5jZW9mIEFycmF5fHxlLnB1c2gmJm0oZSkpJiZcIm51bWJlclwiIT10eXBlb2YgZVswXSlmb3IodGhpcy5fdGFyZ2V0cz1hPV8uY2FsbChlLDApLHRoaXMuX3Byb3BMb29rdXA9W10sdGhpcy5fc2libGluZ3M9W10sbj0wO2EubGVuZ3RoPm47bisrKXI9YVtuXSxyP1wic3RyaW5nXCIhPXR5cGVvZiByP3IubGVuZ3RoJiZyIT09dCYmclswXSYmKHJbMF09PT10fHxyWzBdLm5vZGVUeXBlJiZyWzBdLnN0eWxlJiYhci5ub2RlVHlwZSk/KGEuc3BsaWNlKG4tLSwxKSx0aGlzLl90YXJnZXRzPWE9YS5jb25jYXQoXy5jYWxsKHIsMCkpKToodGhpcy5fc2libGluZ3Nbbl09TShyLHRoaXMsITEpLDE9PT1sJiZ0aGlzLl9zaWJsaW5nc1tuXS5sZW5ndGg+MSYmJChyLHRoaXMsbnVsbCwxLHRoaXMuX3NpYmxpbmdzW25dKSk6KHI9YVtuLS1dPUQuc2VsZWN0b3IociksXCJzdHJpbmdcIj09dHlwZW9mIHImJmEuc3BsaWNlKG4rMSwxKSk6YS5zcGxpY2Uobi0tLDEpO2Vsc2UgdGhpcy5fcHJvcExvb2t1cD17fSx0aGlzLl9zaWJsaW5ncz1NKGUsdGhpcywhMSksMT09PWwmJnRoaXMuX3NpYmxpbmdzLmxlbmd0aD4xJiYkKGUsdGhpcyxudWxsLDEsdGhpcy5fc2libGluZ3MpOyh0aGlzLnZhcnMuaW1tZWRpYXRlUmVuZGVyfHwwPT09aSYmMD09PXRoaXMuX2RlbGF5JiZ0aGlzLnZhcnMuaW1tZWRpYXRlUmVuZGVyIT09ITEpJiYodGhpcy5fdGltZT0taCx0aGlzLnJlbmRlcigtdGhpcy5fZGVsYXkpKX0sITApLEk9ZnVuY3Rpb24oZSl7cmV0dXJuIGUubGVuZ3RoJiZlIT09dCYmZVswXSYmKGVbMF09PT10fHxlWzBdLm5vZGVUeXBlJiZlWzBdLnN0eWxlJiYhZS5ub2RlVHlwZSl9LEU9ZnVuY3Rpb24odCxlKXt2YXIgaSxzPXt9O2ZvcihpIGluIHQpaltpXXx8aSBpbiBlJiZcInRyYW5zZm9ybVwiIT09aSYmXCJ4XCIhPT1pJiZcInlcIiE9PWkmJlwid2lkdGhcIiE9PWkmJlwiaGVpZ2h0XCIhPT1pJiZcImNsYXNzTmFtZVwiIT09aSYmXCJib3JkZXJcIiE9PWl8fCEoIUxbaV18fExbaV0mJkxbaV0uX2F1dG9DU1MpfHwoc1tpXT10W2ldLGRlbGV0ZSB0W2ldKTt0LmNzcz1zfTtuPUQucHJvdG90eXBlPW5ldyB4LG4uY29uc3RydWN0b3I9RCxuLmtpbGwoKS5fZ2M9ITEsbi5yYXRpbz0wLG4uX2ZpcnN0UFQ9bi5fdGFyZ2V0cz1uLl9vdmVyd3JpdHRlblByb3BzPW4uX3N0YXJ0QXQ9bnVsbCxuLl9ub3RpZnlQbHVnaW5zT2ZFbmFibGVkPW4uX2xhenk9ITEsRC52ZXJzaW9uPVwiMS4xMi4xXCIsRC5kZWZhdWx0RWFzZT1uLl9lYXNlPW5ldyBUKG51bGwsbnVsbCwxLDEpLEQuZGVmYXVsdE92ZXJ3cml0ZT1cImF1dG9cIixELnRpY2tlcj1yLEQuYXV0b1NsZWVwPSEwLEQubGFnU21vb3RoaW5nPWZ1bmN0aW9uKHQsZSl7ci5sYWdTbW9vdGhpbmcodCxlKX0sRC5zZWxlY3Rvcj10LiR8fHQualF1ZXJ5fHxmdW5jdGlvbihlKXtyZXR1cm4gdC4kPyhELnNlbGVjdG9yPXQuJCx0LiQoZSkpOnQuZG9jdW1lbnQ/dC5kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIiNcIj09PWUuY2hhckF0KDApP2Uuc3Vic3RyKDEpOmUpOmV9O3ZhciB6PVtdLE89e30sTj1ELl9pbnRlcm5hbHM9e2lzQXJyYXk6bSxpc1NlbGVjdG9yOkksbGF6eVR3ZWVuczp6fSxMPUQuX3BsdWdpbnM9e30sVT1OLnR3ZWVuTG9va3VwPXt9LEY9MCxqPU4ucmVzZXJ2ZWRQcm9wcz17ZWFzZToxLGRlbGF5OjEsb3ZlcndyaXRlOjEsb25Db21wbGV0ZToxLG9uQ29tcGxldGVQYXJhbXM6MSxvbkNvbXBsZXRlU2NvcGU6MSx1c2VGcmFtZXM6MSxydW5CYWNrd2FyZHM6MSxzdGFydEF0OjEsb25VcGRhdGU6MSxvblVwZGF0ZVBhcmFtczoxLG9uVXBkYXRlU2NvcGU6MSxvblN0YXJ0OjEsb25TdGFydFBhcmFtczoxLG9uU3RhcnRTY29wZToxLG9uUmV2ZXJzZUNvbXBsZXRlOjEsb25SZXZlcnNlQ29tcGxldGVQYXJhbXM6MSxvblJldmVyc2VDb21wbGV0ZVNjb3BlOjEsb25SZXBlYXQ6MSxvblJlcGVhdFBhcmFtczoxLG9uUmVwZWF0U2NvcGU6MSxlYXNlUGFyYW1zOjEseW95bzoxLGltbWVkaWF0ZVJlbmRlcjoxLHJlcGVhdDoxLHJlcGVhdERlbGF5OjEsZGF0YToxLHBhdXNlZDoxLHJldmVyc2VkOjEsYXV0b0NTUzoxLGxhenk6MX0sRz17bm9uZTowLGFsbDoxLGF1dG86Mixjb25jdXJyZW50OjMsYWxsT25TdGFydDo0LHByZWV4aXN0aW5nOjUsXCJ0cnVlXCI6MSxcImZhbHNlXCI6MH0sUT14Ll9yb290RnJhbWVzVGltZWxpbmU9bmV3IFIsQj14Ll9yb290VGltZWxpbmU9bmV3IFIscT1mdW5jdGlvbigpe3ZhciB0PXoubGVuZ3RoO2ZvcihPPXt9Oy0tdD4tMTspaT16W3RdLGkmJmkuX2xhenkhPT0hMSYmKGkucmVuZGVyKGkuX2xhenksITEsITApLGkuX2xhenk9ITEpO3oubGVuZ3RoPTB9O0IuX3N0YXJ0VGltZT1yLnRpbWUsUS5fc3RhcnRUaW1lPXIuZnJhbWUsQi5fYWN0aXZlPVEuX2FjdGl2ZT0hMCxzZXRUaW1lb3V0KHEsMSkseC5fdXBkYXRlUm9vdD1ELnJlbmRlcj1mdW5jdGlvbigpe3ZhciB0LGUsaTtpZih6Lmxlbmd0aCYmcSgpLEIucmVuZGVyKChyLnRpbWUtQi5fc3RhcnRUaW1lKSpCLl90aW1lU2NhbGUsITEsITEpLFEucmVuZGVyKChyLmZyYW1lLVEuX3N0YXJ0VGltZSkqUS5fdGltZVNjYWxlLCExLCExKSx6Lmxlbmd0aCYmcSgpLCEoci5mcmFtZSUxMjApKXtmb3IoaSBpbiBVKXtmb3IoZT1VW2ldLnR3ZWVucyx0PWUubGVuZ3RoOy0tdD4tMTspZVt0XS5fZ2MmJmUuc3BsaWNlKHQsMSk7MD09PWUubGVuZ3RoJiZkZWxldGUgVVtpXX1pZihpPUIuX2ZpcnN0LCghaXx8aS5fcGF1c2VkKSYmRC5hdXRvU2xlZXAmJiFRLl9maXJzdCYmMT09PXIuX2xpc3RlbmVycy50aWNrLmxlbmd0aCl7Zm9yKDtpJiZpLl9wYXVzZWQ7KWk9aS5fbmV4dDtpfHxyLnNsZWVwKCl9fX0sci5hZGRFdmVudExpc3RlbmVyKFwidGlja1wiLHguX3VwZGF0ZVJvb3QpO3ZhciBNPWZ1bmN0aW9uKHQsZSxpKXt2YXIgcyxuLHI9dC5fZ3NUd2VlbklEO2lmKFVbcnx8KHQuX2dzVHdlZW5JRD1yPVwidFwiK0YrKyldfHwoVVtyXT17dGFyZ2V0OnQsdHdlZW5zOltdfSksZSYmKHM9VVtyXS50d2VlbnMsc1tuPXMubGVuZ3RoXT1lLGkpKWZvcig7LS1uPi0xOylzW25dPT09ZSYmcy5zcGxpY2UobiwxKTtyZXR1cm4gVVtyXS50d2VlbnN9LCQ9ZnVuY3Rpb24odCxlLGkscyxuKXt2YXIgcixhLG8sbDtpZigxPT09c3x8cz49NCl7Zm9yKGw9bi5sZW5ndGgscj0wO2w+cjtyKyspaWYoKG89bltyXSkhPT1lKW8uX2djfHxvLl9lbmFibGVkKCExLCExKSYmKGE9ITApO2Vsc2UgaWYoNT09PXMpYnJlYWs7cmV0dXJuIGF9dmFyIF8sdT1lLl9zdGFydFRpbWUraCxtPVtdLGY9MCxwPTA9PT1lLl9kdXJhdGlvbjtmb3Iocj1uLmxlbmd0aDstLXI+LTE7KShvPW5bcl0pPT09ZXx8by5fZ2N8fG8uX3BhdXNlZHx8KG8uX3RpbWVsaW5lIT09ZS5fdGltZWxpbmU/KF89X3x8SyhlLDAscCksMD09PUsobyxfLHApJiYobVtmKytdPW8pKTp1Pj1vLl9zdGFydFRpbWUmJm8uX3N0YXJ0VGltZStvLnRvdGFsRHVyYXRpb24oKS9vLl90aW1lU2NhbGU+dSYmKChwfHwhby5faW5pdHRlZCkmJjJlLTEwPj11LW8uX3N0YXJ0VGltZXx8KG1bZisrXT1vKSkpO2ZvcihyPWY7LS1yPi0xOylvPW1bcl0sMj09PXMmJm8uX2tpbGwoaSx0KSYmKGE9ITApLCgyIT09c3x8IW8uX2ZpcnN0UFQmJm8uX2luaXR0ZWQpJiZvLl9lbmFibGVkKCExLCExKSYmKGE9ITApO3JldHVybiBhfSxLPWZ1bmN0aW9uKHQsZSxpKXtmb3IodmFyIHM9dC5fdGltZWxpbmUsbj1zLl90aW1lU2NhbGUscj10Ll9zdGFydFRpbWU7cy5fdGltZWxpbmU7KXtpZihyKz1zLl9zdGFydFRpbWUsbio9cy5fdGltZVNjYWxlLHMuX3BhdXNlZClyZXR1cm4tMTAwO3M9cy5fdGltZWxpbmV9cmV0dXJuIHIvPW4scj5lP3ItZTppJiZyPT09ZXx8IXQuX2luaXR0ZWQmJjIqaD5yLWU/aDoocis9dC50b3RhbER1cmF0aW9uKCkvdC5fdGltZVNjYWxlL24pPmUraD8wOnItZS1ofTtuLl9pbml0PWZ1bmN0aW9uKCl7dmFyIHQsZSxpLHMsbixyPXRoaXMudmFycyxhPXRoaXMuX292ZXJ3cml0dGVuUHJvcHMsbz10aGlzLl9kdXJhdGlvbixsPSEhci5pbW1lZGlhdGVSZW5kZXIsaD1yLmVhc2U7aWYoci5zdGFydEF0KXt0aGlzLl9zdGFydEF0JiYodGhpcy5fc3RhcnRBdC5yZW5kZXIoLTEsITApLHRoaXMuX3N0YXJ0QXQua2lsbCgpKSxuPXt9O2ZvcihzIGluIHIuc3RhcnRBdCluW3NdPXIuc3RhcnRBdFtzXTtpZihuLm92ZXJ3cml0ZT0hMSxuLmltbWVkaWF0ZVJlbmRlcj0hMCxuLmxhenk9bCYmci5sYXp5IT09ITEsbi5zdGFydEF0PW4uZGVsYXk9bnVsbCx0aGlzLl9zdGFydEF0PUQudG8odGhpcy50YXJnZXQsMCxuKSxsKWlmKHRoaXMuX3RpbWU+MCl0aGlzLl9zdGFydEF0PW51bGw7ZWxzZSBpZigwIT09bylyZXR1cm59ZWxzZSBpZihyLnJ1bkJhY2t3YXJkcyYmMCE9PW8paWYodGhpcy5fc3RhcnRBdCl0aGlzLl9zdGFydEF0LnJlbmRlcigtMSwhMCksdGhpcy5fc3RhcnRBdC5raWxsKCksdGhpcy5fc3RhcnRBdD1udWxsO2Vsc2V7aT17fTtmb3IocyBpbiByKWpbc10mJlwiYXV0b0NTU1wiIT09c3x8KGlbc109cltzXSk7aWYoaS5vdmVyd3JpdGU9MCxpLmRhdGE9XCJpc0Zyb21TdGFydFwiLGkubGF6eT1sJiZyLmxhenkhPT0hMSxpLmltbWVkaWF0ZVJlbmRlcj1sLHRoaXMuX3N0YXJ0QXQ9RC50byh0aGlzLnRhcmdldCwwLGkpLGwpe2lmKDA9PT10aGlzLl90aW1lKXJldHVybn1lbHNlIHRoaXMuX3N0YXJ0QXQuX2luaXQoKSx0aGlzLl9zdGFydEF0Ll9lbmFibGVkKCExKX1pZih0aGlzLl9lYXNlPWg/aCBpbnN0YW5jZW9mIFQ/ci5lYXNlUGFyYW1zIGluc3RhbmNlb2YgQXJyYXk/aC5jb25maWcuYXBwbHkoaCxyLmVhc2VQYXJhbXMpOmg6XCJmdW5jdGlvblwiPT10eXBlb2YgaD9uZXcgVChoLHIuZWFzZVBhcmFtcyk6eVtoXXx8RC5kZWZhdWx0RWFzZTpELmRlZmF1bHRFYXNlLHRoaXMuX2Vhc2VUeXBlPXRoaXMuX2Vhc2UuX3R5cGUsdGhpcy5fZWFzZVBvd2VyPXRoaXMuX2Vhc2UuX3Bvd2VyLHRoaXMuX2ZpcnN0UFQ9bnVsbCx0aGlzLl90YXJnZXRzKWZvcih0PXRoaXMuX3RhcmdldHMubGVuZ3RoOy0tdD4tMTspdGhpcy5faW5pdFByb3BzKHRoaXMuX3RhcmdldHNbdF0sdGhpcy5fcHJvcExvb2t1cFt0XT17fSx0aGlzLl9zaWJsaW5nc1t0XSxhP2FbdF06bnVsbCkmJihlPSEwKTtlbHNlIGU9dGhpcy5faW5pdFByb3BzKHRoaXMudGFyZ2V0LHRoaXMuX3Byb3BMb29rdXAsdGhpcy5fc2libGluZ3MsYSk7aWYoZSYmRC5fb25QbHVnaW5FdmVudChcIl9vbkluaXRBbGxQcm9wc1wiLHRoaXMpLGEmJih0aGlzLl9maXJzdFBUfHxcImZ1bmN0aW9uXCIhPXR5cGVvZiB0aGlzLnRhcmdldCYmdGhpcy5fZW5hYmxlZCghMSwhMSkpLHIucnVuQmFja3dhcmRzKWZvcihpPXRoaXMuX2ZpcnN0UFQ7aTspaS5zKz1pLmMsaS5jPS1pLmMsaT1pLl9uZXh0O3RoaXMuX29uVXBkYXRlPXIub25VcGRhdGUsdGhpcy5faW5pdHRlZD0hMH0sbi5faW5pdFByb3BzPWZ1bmN0aW9uKGUsaSxzLG4pe3ZhciByLGEsbyxsLGgsXztpZihudWxsPT1lKXJldHVybiExO09bZS5fZ3NUd2VlbklEXSYmcSgpLHRoaXMudmFycy5jc3N8fGUuc3R5bGUmJmUhPT10JiZlLm5vZGVUeXBlJiZMLmNzcyYmdGhpcy52YXJzLmF1dG9DU1MhPT0hMSYmRSh0aGlzLnZhcnMsZSk7Zm9yKHIgaW4gdGhpcy52YXJzKXtpZihfPXRoaXMudmFyc1tyXSxqW3JdKV8mJihfIGluc3RhbmNlb2YgQXJyYXl8fF8ucHVzaCYmbShfKSkmJi0xIT09Xy5qb2luKFwiXCIpLmluZGV4T2YoXCJ7c2VsZn1cIikmJih0aGlzLnZhcnNbcl09Xz10aGlzLl9zd2FwU2VsZkluUGFyYW1zKF8sdGhpcykpO2Vsc2UgaWYoTFtyXSYmKGw9bmV3IExbcl0pLl9vbkluaXRUd2VlbihlLHRoaXMudmFyc1tyXSx0aGlzKSl7Zm9yKHRoaXMuX2ZpcnN0UFQ9aD17X25leHQ6dGhpcy5fZmlyc3RQVCx0OmwscDpcInNldFJhdGlvXCIsczowLGM6MSxmOiEwLG46cixwZzohMCxwcjpsLl9wcmlvcml0eX0sYT1sLl9vdmVyd3JpdGVQcm9wcy5sZW5ndGg7LS1hPi0xOylpW2wuX292ZXJ3cml0ZVByb3BzW2FdXT10aGlzLl9maXJzdFBUOyhsLl9wcmlvcml0eXx8bC5fb25Jbml0QWxsUHJvcHMpJiYobz0hMCksKGwuX29uRGlzYWJsZXx8bC5fb25FbmFibGUpJiYodGhpcy5fbm90aWZ5UGx1Z2luc09mRW5hYmxlZD0hMCl9ZWxzZSB0aGlzLl9maXJzdFBUPWlbcl09aD17X25leHQ6dGhpcy5fZmlyc3RQVCx0OmUscDpyLGY6XCJmdW5jdGlvblwiPT10eXBlb2YgZVtyXSxuOnIscGc6ITEscHI6MH0saC5zPWguZj9lW3IuaW5kZXhPZihcInNldFwiKXx8XCJmdW5jdGlvblwiIT10eXBlb2YgZVtcImdldFwiK3Iuc3Vic3RyKDMpXT9yOlwiZ2V0XCIrci5zdWJzdHIoMyldKCk6cGFyc2VGbG9hdChlW3JdKSxoLmM9XCJzdHJpbmdcIj09dHlwZW9mIF8mJlwiPVwiPT09Xy5jaGFyQXQoMSk/cGFyc2VJbnQoXy5jaGFyQXQoMCkrXCIxXCIsMTApKk51bWJlcihfLnN1YnN0cigyKSk6TnVtYmVyKF8pLWguc3x8MDtoJiZoLl9uZXh0JiYoaC5fbmV4dC5fcHJldj1oKX1yZXR1cm4gbiYmdGhpcy5fa2lsbChuLGUpP3RoaXMuX2luaXRQcm9wcyhlLGkscyxuKTp0aGlzLl9vdmVyd3JpdGU+MSYmdGhpcy5fZmlyc3RQVCYmcy5sZW5ndGg+MSYmJChlLHRoaXMsaSx0aGlzLl9vdmVyd3JpdGUscyk/KHRoaXMuX2tpbGwoaSxlKSx0aGlzLl9pbml0UHJvcHMoZSxpLHMsbikpOih0aGlzLl9maXJzdFBUJiYodGhpcy52YXJzLmxhenkhPT0hMSYmdGhpcy5fZHVyYXRpb258fHRoaXMudmFycy5sYXp5JiYhdGhpcy5fZHVyYXRpb24pJiYoT1tlLl9nc1R3ZWVuSURdPSEwKSxvKX0sbi5yZW5kZXI9ZnVuY3Rpb24odCxlLGkpe3ZhciBzLG4scixhLG89dGhpcy5fdGltZSxsPXRoaXMuX2R1cmF0aW9uLF89dGhpcy5fcmF3UHJldlRpbWU7aWYodD49bCl0aGlzLl90b3RhbFRpbWU9dGhpcy5fdGltZT1sLHRoaXMucmF0aW89dGhpcy5fZWFzZS5fY2FsY0VuZD90aGlzLl9lYXNlLmdldFJhdGlvKDEpOjEsdGhpcy5fcmV2ZXJzZWR8fChzPSEwLG49XCJvbkNvbXBsZXRlXCIpLDA9PT1sJiYodGhpcy5faW5pdHRlZHx8IXRoaXMudmFycy5sYXp5fHxpKSYmKHRoaXMuX3N0YXJ0VGltZT09PXRoaXMuX3RpbWVsaW5lLl9kdXJhdGlvbiYmKHQ9MCksKDA9PT10fHwwPl98fF89PT1oKSYmXyE9PXQmJihpPSEwLF8+aCYmKG49XCJvblJldmVyc2VDb21wbGV0ZVwiKSksdGhpcy5fcmF3UHJldlRpbWU9YT0hZXx8dHx8Xz09PXQ/dDpoKTtlbHNlIGlmKDFlLTc+dCl0aGlzLl90b3RhbFRpbWU9dGhpcy5fdGltZT0wLHRoaXMucmF0aW89dGhpcy5fZWFzZS5fY2FsY0VuZD90aGlzLl9lYXNlLmdldFJhdGlvKDApOjAsKDAhPT1vfHwwPT09bCYmXz4wJiZfIT09aCkmJihuPVwib25SZXZlcnNlQ29tcGxldGVcIixzPXRoaXMuX3JldmVyc2VkKSwwPnQ/KHRoaXMuX2FjdGl2ZT0hMSwwPT09bCYmKHRoaXMuX2luaXR0ZWR8fCF0aGlzLnZhcnMubGF6eXx8aSkmJihfPj0wJiYoaT0hMCksdGhpcy5fcmF3UHJldlRpbWU9YT0hZXx8dHx8Xz09PXQ/dDpoKSk6dGhpcy5faW5pdHRlZHx8KGk9ITApO2Vsc2UgaWYodGhpcy5fdG90YWxUaW1lPXRoaXMuX3RpbWU9dCx0aGlzLl9lYXNlVHlwZSl7dmFyIHU9dC9sLG09dGhpcy5fZWFzZVR5cGUsZj10aGlzLl9lYXNlUG93ZXI7KDE9PT1tfHwzPT09bSYmdT49LjUpJiYodT0xLXUpLDM9PT1tJiYodSo9MiksMT09PWY/dSo9dToyPT09Zj91Kj11KnU6Mz09PWY/dSo9dSp1KnU6ND09PWYmJih1Kj11KnUqdSp1KSx0aGlzLnJhdGlvPTE9PT1tPzEtdToyPT09bT91Oi41PnQvbD91LzI6MS11LzJ9ZWxzZSB0aGlzLnJhdGlvPXRoaXMuX2Vhc2UuZ2V0UmF0aW8odC9sKTtpZih0aGlzLl90aW1lIT09b3x8aSl7aWYoIXRoaXMuX2luaXR0ZWQpe2lmKHRoaXMuX2luaXQoKSwhdGhpcy5faW5pdHRlZHx8dGhpcy5fZ2MpcmV0dXJuO2lmKCFpJiZ0aGlzLl9maXJzdFBUJiYodGhpcy52YXJzLmxhenkhPT0hMSYmdGhpcy5fZHVyYXRpb258fHRoaXMudmFycy5sYXp5JiYhdGhpcy5fZHVyYXRpb24pKXJldHVybiB0aGlzLl90aW1lPXRoaXMuX3RvdGFsVGltZT1vLHRoaXMuX3Jhd1ByZXZUaW1lPV8sei5wdXNoKHRoaXMpLHRoaXMuX2xhenk9dCx2b2lkIDA7dGhpcy5fdGltZSYmIXM/dGhpcy5yYXRpbz10aGlzLl9lYXNlLmdldFJhdGlvKHRoaXMuX3RpbWUvbCk6cyYmdGhpcy5fZWFzZS5fY2FsY0VuZCYmKHRoaXMucmF0aW89dGhpcy5fZWFzZS5nZXRSYXRpbygwPT09dGhpcy5fdGltZT8wOjEpKX1mb3IodGhpcy5fbGF6eSE9PSExJiYodGhpcy5fbGF6eT0hMSksdGhpcy5fYWN0aXZlfHwhdGhpcy5fcGF1c2VkJiZ0aGlzLl90aW1lIT09byYmdD49MCYmKHRoaXMuX2FjdGl2ZT0hMCksMD09PW8mJih0aGlzLl9zdGFydEF0JiYodD49MD90aGlzLl9zdGFydEF0LnJlbmRlcih0LGUsaSk6bnx8KG49XCJfZHVtbXlHU1wiKSksdGhpcy52YXJzLm9uU3RhcnQmJigwIT09dGhpcy5fdGltZXx8MD09PWwpJiYoZXx8dGhpcy52YXJzLm9uU3RhcnQuYXBwbHkodGhpcy52YXJzLm9uU3RhcnRTY29wZXx8dGhpcyx0aGlzLnZhcnMub25TdGFydFBhcmFtc3x8ZykpKSxyPXRoaXMuX2ZpcnN0UFQ7cjspci5mP3IudFtyLnBdKHIuYyp0aGlzLnJhdGlvK3Iucyk6ci50W3IucF09ci5jKnRoaXMucmF0aW8rci5zLHI9ci5fbmV4dDt0aGlzLl9vblVwZGF0ZSYmKDA+dCYmdGhpcy5fc3RhcnRBdCYmdGhpcy5fc3RhcnRUaW1lJiZ0aGlzLl9zdGFydEF0LnJlbmRlcih0LGUsaSksZXx8KHRoaXMuX3RpbWUhPT1vfHxzKSYmdGhpcy5fb25VcGRhdGUuYXBwbHkodGhpcy52YXJzLm9uVXBkYXRlU2NvcGV8fHRoaXMsdGhpcy52YXJzLm9uVXBkYXRlUGFyYW1zfHxnKSksbiYmKHRoaXMuX2djfHwoMD50JiZ0aGlzLl9zdGFydEF0JiYhdGhpcy5fb25VcGRhdGUmJnRoaXMuX3N0YXJ0VGltZSYmdGhpcy5fc3RhcnRBdC5yZW5kZXIodCxlLGkpLHMmJih0aGlzLl90aW1lbGluZS5hdXRvUmVtb3ZlQ2hpbGRyZW4mJnRoaXMuX2VuYWJsZWQoITEsITEpLHRoaXMuX2FjdGl2ZT0hMSksIWUmJnRoaXMudmFyc1tuXSYmdGhpcy52YXJzW25dLmFwcGx5KHRoaXMudmFyc1tuK1wiU2NvcGVcIl18fHRoaXMsdGhpcy52YXJzW24rXCJQYXJhbXNcIl18fGcpLDA9PT1sJiZ0aGlzLl9yYXdQcmV2VGltZT09PWgmJmEhPT1oJiYodGhpcy5fcmF3UHJldlRpbWU9MCkpKX19LG4uX2tpbGw9ZnVuY3Rpb24odCxlKXtpZihcImFsbFwiPT09dCYmKHQ9bnVsbCksbnVsbD09dCYmKG51bGw9PWV8fGU9PT10aGlzLnRhcmdldCkpcmV0dXJuIHRoaXMuX2xhenk9ITEsdGhpcy5fZW5hYmxlZCghMSwhMSk7ZT1cInN0cmluZ1wiIT10eXBlb2YgZT9lfHx0aGlzLl90YXJnZXRzfHx0aGlzLnRhcmdldDpELnNlbGVjdG9yKGUpfHxlO3ZhciBpLHMsbixyLGEsbyxsLGg7aWYoKG0oZSl8fEkoZSkpJiZcIm51bWJlclwiIT10eXBlb2YgZVswXSlmb3IoaT1lLmxlbmd0aDstLWk+LTE7KXRoaXMuX2tpbGwodCxlW2ldKSYmKG89ITApO2Vsc2V7aWYodGhpcy5fdGFyZ2V0cyl7Zm9yKGk9dGhpcy5fdGFyZ2V0cy5sZW5ndGg7LS1pPi0xOylpZihlPT09dGhpcy5fdGFyZ2V0c1tpXSl7YT10aGlzLl9wcm9wTG9va3VwW2ldfHx7fSx0aGlzLl9vdmVyd3JpdHRlblByb3BzPXRoaXMuX292ZXJ3cml0dGVuUHJvcHN8fFtdLHM9dGhpcy5fb3ZlcndyaXR0ZW5Qcm9wc1tpXT10P3RoaXMuX292ZXJ3cml0dGVuUHJvcHNbaV18fHt9OlwiYWxsXCI7YnJlYWt9fWVsc2V7aWYoZSE9PXRoaXMudGFyZ2V0KXJldHVybiExO2E9dGhpcy5fcHJvcExvb2t1cCxzPXRoaXMuX292ZXJ3cml0dGVuUHJvcHM9dD90aGlzLl9vdmVyd3JpdHRlblByb3BzfHx7fTpcImFsbFwifWlmKGEpe2w9dHx8YSxoPXQhPT1zJiZcImFsbFwiIT09cyYmdCE9PWEmJihcIm9iamVjdFwiIT10eXBlb2YgdHx8IXQuX3RlbXBLaWxsKTtmb3IobiBpbiBsKShyPWFbbl0pJiYoci5wZyYmci50Ll9raWxsKGwpJiYobz0hMCksci5wZyYmMCE9PXIudC5fb3ZlcndyaXRlUHJvcHMubGVuZ3RofHwoci5fcHJldj9yLl9wcmV2Ll9uZXh0PXIuX25leHQ6cj09PXRoaXMuX2ZpcnN0UFQmJih0aGlzLl9maXJzdFBUPXIuX25leHQpLHIuX25leHQmJihyLl9uZXh0Ll9wcmV2PXIuX3ByZXYpLHIuX25leHQ9ci5fcHJldj1udWxsKSxkZWxldGUgYVtuXSksaCYmKHNbbl09MSk7IXRoaXMuX2ZpcnN0UFQmJnRoaXMuX2luaXR0ZWQmJnRoaXMuX2VuYWJsZWQoITEsITEpfX1yZXR1cm4gb30sbi5pbnZhbGlkYXRlPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX25vdGlmeVBsdWdpbnNPZkVuYWJsZWQmJkQuX29uUGx1Z2luRXZlbnQoXCJfb25EaXNhYmxlXCIsdGhpcyksdGhpcy5fZmlyc3RQVD1udWxsLHRoaXMuX292ZXJ3cml0dGVuUHJvcHM9bnVsbCx0aGlzLl9vblVwZGF0ZT1udWxsLHRoaXMuX3N0YXJ0QXQ9bnVsbCx0aGlzLl9pbml0dGVkPXRoaXMuX2FjdGl2ZT10aGlzLl9ub3RpZnlQbHVnaW5zT2ZFbmFibGVkPXRoaXMuX2xhenk9ITEsdGhpcy5fcHJvcExvb2t1cD10aGlzLl90YXJnZXRzP3t9OltdLHRoaXN9LG4uX2VuYWJsZWQ9ZnVuY3Rpb24odCxlKXtpZihhfHxyLndha2UoKSx0JiZ0aGlzLl9nYyl7dmFyIGkscz10aGlzLl90YXJnZXRzO2lmKHMpZm9yKGk9cy5sZW5ndGg7LS1pPi0xOyl0aGlzLl9zaWJsaW5nc1tpXT1NKHNbaV0sdGhpcywhMCk7ZWxzZSB0aGlzLl9zaWJsaW5ncz1NKHRoaXMudGFyZ2V0LHRoaXMsITApfXJldHVybiB4LnByb3RvdHlwZS5fZW5hYmxlZC5jYWxsKHRoaXMsdCxlKSx0aGlzLl9ub3RpZnlQbHVnaW5zT2ZFbmFibGVkJiZ0aGlzLl9maXJzdFBUP0QuX29uUGx1Z2luRXZlbnQodD9cIl9vbkVuYWJsZVwiOlwiX29uRGlzYWJsZVwiLHRoaXMpOiExfSxELnRvPWZ1bmN0aW9uKHQsZSxpKXtyZXR1cm4gbmV3IEQodCxlLGkpfSxELmZyb209ZnVuY3Rpb24odCxlLGkpe3JldHVybiBpLnJ1bkJhY2t3YXJkcz0hMCxpLmltbWVkaWF0ZVJlbmRlcj0wIT1pLmltbWVkaWF0ZVJlbmRlcixuZXcgRCh0LGUsaSl9LEQuZnJvbVRvPWZ1bmN0aW9uKHQsZSxpLHMpe3JldHVybiBzLnN0YXJ0QXQ9aSxzLmltbWVkaWF0ZVJlbmRlcj0wIT1zLmltbWVkaWF0ZVJlbmRlciYmMCE9aS5pbW1lZGlhdGVSZW5kZXIsbmV3IEQodCxlLHMpfSxELmRlbGF5ZWRDYWxsPWZ1bmN0aW9uKHQsZSxpLHMsbil7cmV0dXJuIG5ldyBEKGUsMCx7ZGVsYXk6dCxvbkNvbXBsZXRlOmUsb25Db21wbGV0ZVBhcmFtczppLG9uQ29tcGxldGVTY29wZTpzLG9uUmV2ZXJzZUNvbXBsZXRlOmUsb25SZXZlcnNlQ29tcGxldGVQYXJhbXM6aSxvblJldmVyc2VDb21wbGV0ZVNjb3BlOnMsaW1tZWRpYXRlUmVuZGVyOiExLHVzZUZyYW1lczpuLG92ZXJ3cml0ZTowfSl9LEQuc2V0PWZ1bmN0aW9uKHQsZSl7cmV0dXJuIG5ldyBEKHQsMCxlKX0sRC5nZXRUd2VlbnNPZj1mdW5jdGlvbih0LGUpe2lmKG51bGw9PXQpcmV0dXJuW107dD1cInN0cmluZ1wiIT10eXBlb2YgdD90OkQuc2VsZWN0b3IodCl8fHQ7dmFyIGkscyxuLHI7aWYoKG0odCl8fEkodCkpJiZcIm51bWJlclwiIT10eXBlb2YgdFswXSl7Zm9yKGk9dC5sZW5ndGgscz1bXTstLWk+LTE7KXM9cy5jb25jYXQoRC5nZXRUd2VlbnNPZih0W2ldLGUpKTtmb3IoaT1zLmxlbmd0aDstLWk+LTE7KWZvcihyPXNbaV0sbj1pOy0tbj4tMTspcj09PXNbbl0mJnMuc3BsaWNlKGksMSl9ZWxzZSBmb3Iocz1NKHQpLmNvbmNhdCgpLGk9cy5sZW5ndGg7LS1pPi0xOykoc1tpXS5fZ2N8fGUmJiFzW2ldLmlzQWN0aXZlKCkpJiZzLnNwbGljZShpLDEpO3JldHVybiBzfSxELmtpbGxUd2VlbnNPZj1ELmtpbGxEZWxheWVkQ2FsbHNUbz1mdW5jdGlvbih0LGUsaSl7XCJvYmplY3RcIj09dHlwZW9mIGUmJihpPWUsZT0hMSk7Zm9yKHZhciBzPUQuZ2V0VHdlZW5zT2YodCxlKSxuPXMubGVuZ3RoOy0tbj4tMTspc1tuXS5fa2lsbChpLHQpfTt2YXIgSD1kKFwicGx1Z2lucy5Ud2VlblBsdWdpblwiLGZ1bmN0aW9uKHQsZSl7dGhpcy5fb3ZlcndyaXRlUHJvcHM9KHR8fFwiXCIpLnNwbGl0KFwiLFwiKSx0aGlzLl9wcm9wTmFtZT10aGlzLl9vdmVyd3JpdGVQcm9wc1swXSx0aGlzLl9wcmlvcml0eT1lfHwwLHRoaXMuX3N1cGVyPUgucHJvdG90eXBlfSwhMCk7aWYobj1ILnByb3RvdHlwZSxILnZlcnNpb249XCIxLjEwLjFcIixILkFQST0yLG4uX2ZpcnN0UFQ9bnVsbCxuLl9hZGRUd2Vlbj1mdW5jdGlvbih0LGUsaSxzLG4scil7dmFyIGEsbztyZXR1cm4gbnVsbCE9cyYmKGE9XCJudW1iZXJcIj09dHlwZW9mIHN8fFwiPVwiIT09cy5jaGFyQXQoMSk/TnVtYmVyKHMpLWk6cGFyc2VJbnQocy5jaGFyQXQoMCkrXCIxXCIsMTApKk51bWJlcihzLnN1YnN0cigyKSkpPyh0aGlzLl9maXJzdFBUPW89e19uZXh0OnRoaXMuX2ZpcnN0UFQsdDp0LHA6ZSxzOmksYzphLGY6XCJmdW5jdGlvblwiPT10eXBlb2YgdFtlXSxuOm58fGUscjpyfSxvLl9uZXh0JiYoby5fbmV4dC5fcHJldj1vKSxvKTp2b2lkIDB9LG4uc2V0UmF0aW89ZnVuY3Rpb24odCl7Zm9yKHZhciBlLGk9dGhpcy5fZmlyc3RQVCxzPTFlLTY7aTspZT1pLmMqdCtpLnMsaS5yP2U9TWF0aC5yb3VuZChlKTpzPmUmJmU+LXMmJihlPTApLGkuZj9pLnRbaS5wXShlKTppLnRbaS5wXT1lLGk9aS5fbmV4dH0sbi5fa2lsbD1mdW5jdGlvbih0KXt2YXIgZSxpPXRoaXMuX292ZXJ3cml0ZVByb3BzLHM9dGhpcy5fZmlyc3RQVDtpZihudWxsIT10W3RoaXMuX3Byb3BOYW1lXSl0aGlzLl9vdmVyd3JpdGVQcm9wcz1bXTtlbHNlIGZvcihlPWkubGVuZ3RoOy0tZT4tMTspbnVsbCE9dFtpW2VdXSYmaS5zcGxpY2UoZSwxKTtmb3IoO3M7KW51bGwhPXRbcy5uXSYmKHMuX25leHQmJihzLl9uZXh0Ll9wcmV2PXMuX3ByZXYpLHMuX3ByZXY/KHMuX3ByZXYuX25leHQ9cy5fbmV4dCxzLl9wcmV2PW51bGwpOnRoaXMuX2ZpcnN0UFQ9PT1zJiYodGhpcy5fZmlyc3RQVD1zLl9uZXh0KSkscz1zLl9uZXh0O3JldHVybiExfSxuLl9yb3VuZFByb3BzPWZ1bmN0aW9uKHQsZSl7Zm9yKHZhciBpPXRoaXMuX2ZpcnN0UFQ7aTspKHRbdGhpcy5fcHJvcE5hbWVdfHxudWxsIT1pLm4mJnRbaS5uLnNwbGl0KHRoaXMuX3Byb3BOYW1lK1wiX1wiKS5qb2luKFwiXCIpXSkmJihpLnI9ZSksaT1pLl9uZXh0fSxELl9vblBsdWdpbkV2ZW50PWZ1bmN0aW9uKHQsZSl7dmFyIGkscyxuLHIsYSxvPWUuX2ZpcnN0UFQ7aWYoXCJfb25Jbml0QWxsUHJvcHNcIj09PXQpe2Zvcig7bzspe2ZvcihhPW8uX25leHQscz1uO3MmJnMucHI+by5wcjspcz1zLl9uZXh0OyhvLl9wcmV2PXM/cy5fcHJldjpyKT9vLl9wcmV2Ll9uZXh0PW86bj1vLChvLl9uZXh0PXMpP3MuX3ByZXY9bzpyPW8sbz1hfW89ZS5fZmlyc3RQVD1ufWZvcig7bzspby5wZyYmXCJmdW5jdGlvblwiPT10eXBlb2Ygby50W3RdJiZvLnRbdF0oKSYmKGk9ITApLG89by5fbmV4dDtyZXR1cm4gaX0sSC5hY3RpdmF0ZT1mdW5jdGlvbih0KXtmb3IodmFyIGU9dC5sZW5ndGg7LS1lPi0xOyl0W2VdLkFQST09PUguQVBJJiYoTFsobmV3IHRbZV0pLl9wcm9wTmFtZV09dFtlXSk7cmV0dXJuITB9LGMucGx1Z2luPWZ1bmN0aW9uKHQpe2lmKCEodCYmdC5wcm9wTmFtZSYmdC5pbml0JiZ0LkFQSSkpdGhyb3dcImlsbGVnYWwgcGx1Z2luIGRlZmluaXRpb24uXCI7dmFyIGUsaT10LnByb3BOYW1lLHM9dC5wcmlvcml0eXx8MCxuPXQub3ZlcndyaXRlUHJvcHMscj17aW5pdDpcIl9vbkluaXRUd2VlblwiLHNldDpcInNldFJhdGlvXCIsa2lsbDpcIl9raWxsXCIscm91bmQ6XCJfcm91bmRQcm9wc1wiLGluaXRBbGw6XCJfb25Jbml0QWxsUHJvcHNcIn0sYT1kKFwicGx1Z2lucy5cIitpLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpK2kuc3Vic3RyKDEpK1wiUGx1Z2luXCIsZnVuY3Rpb24oKXtILmNhbGwodGhpcyxpLHMpLHRoaXMuX292ZXJ3cml0ZVByb3BzPW58fFtdfSx0Lmdsb2JhbD09PSEwKSxvPWEucHJvdG90eXBlPW5ldyBIKGkpO28uY29uc3RydWN0b3I9YSxhLkFQST10LkFQSTtmb3IoZSBpbiByKVwiZnVuY3Rpb25cIj09dHlwZW9mIHRbZV0mJihvW3JbZV1dPXRbZV0pO3JldHVybiBhLnZlcnNpb249dC52ZXJzaW9uLEguYWN0aXZhdGUoW2FdKSxhfSxpPXQuX2dzUXVldWUpe2ZvcihzPTA7aS5sZW5ndGg+cztzKyspaVtzXSgpO2ZvcihuIGluIGYpZltuXS5mdW5jfHx0LmNvbnNvbGUubG9nKFwiR1NBUCBlbmNvdW50ZXJlZCBtaXNzaW5nIGRlcGVuZGVuY3k6IGNvbS5ncmVlbnNvY2suXCIrbil9YT0hMX19KSh3aW5kb3cpOyIsIi8qIVxyXG4gKiBWRVJTSU9OOiBiZXRhIDEuOS4zXHJcbiAqIERBVEU6IDIwMTMtMDQtMDJcclxuICogVVBEQVRFUyBBTkQgRE9DUyBBVDogaHR0cDovL3d3dy5ncmVlbnNvY2suY29tXHJcbiAqXHJcbiAqIEBsaWNlbnNlIENvcHlyaWdodCAoYykgMjAwOC0yMDE0LCBHcmVlblNvY2suIEFsbCByaWdodHMgcmVzZXJ2ZWQuXHJcbiAqIFRoaXMgd29yayBpcyBzdWJqZWN0IHRvIHRoZSB0ZXJtcyBhdCBodHRwOi8vd3d3LmdyZWVuc29jay5jb20vdGVybXNfb2ZfdXNlLmh0bWwgb3IgZm9yXHJcbiAqIENsdWIgR3JlZW5Tb2NrIG1lbWJlcnMsIHRoZSBzb2Z0d2FyZSBhZ3JlZW1lbnQgdGhhdCB3YXMgaXNzdWVkIHdpdGggeW91ciBtZW1iZXJzaGlwLlxyXG4gKiBcclxuICogQGF1dGhvcjogSmFjayBEb3lsZSwgamFja0BncmVlbnNvY2suY29tXHJcbiAqKi9cclxuKHdpbmRvdy5fZ3NRdWV1ZXx8KHdpbmRvdy5fZ3NRdWV1ZT1bXSkpLnB1c2goZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt3aW5kb3cuX2dzRGVmaW5lKFwiZWFzaW5nLkJhY2tcIixbXCJlYXNpbmcuRWFzZVwiXSxmdW5jdGlvbih0KXt2YXIgZSxpLHMscj13aW5kb3cuR3JlZW5Tb2NrR2xvYmFsc3x8d2luZG93LG49ci5jb20uZ3JlZW5zb2NrLGE9MipNYXRoLlBJLG89TWF0aC5QSS8yLGg9bi5fY2xhc3MsbD1mdW5jdGlvbihlLGkpe3ZhciBzPWgoXCJlYXNpbmcuXCIrZSxmdW5jdGlvbigpe30sITApLHI9cy5wcm90b3R5cGU9bmV3IHQ7cmV0dXJuIHIuY29uc3RydWN0b3I9cyxyLmdldFJhdGlvPWksc30sXz10LnJlZ2lzdGVyfHxmdW5jdGlvbigpe30sdT1mdW5jdGlvbih0LGUsaSxzKXt2YXIgcj1oKFwiZWFzaW5nLlwiK3Qse2Vhc2VPdXQ6bmV3IGUsZWFzZUluOm5ldyBpLGVhc2VJbk91dDpuZXcgc30sITApO3JldHVybiBfKHIsdCkscn0sYz1mdW5jdGlvbih0LGUsaSl7dGhpcy50PXQsdGhpcy52PWUsaSYmKHRoaXMubmV4dD1pLGkucHJldj10aGlzLHRoaXMuYz1pLnYtZSx0aGlzLmdhcD1pLnQtdCl9LGY9ZnVuY3Rpb24oZSxpKXt2YXIgcz1oKFwiZWFzaW5nLlwiK2UsZnVuY3Rpb24odCl7dGhpcy5fcDE9dHx8MD09PXQ/dDoxLjcwMTU4LHRoaXMuX3AyPTEuNTI1KnRoaXMuX3AxfSwhMCkscj1zLnByb3RvdHlwZT1uZXcgdDtyZXR1cm4gci5jb25zdHJ1Y3Rvcj1zLHIuZ2V0UmF0aW89aSxyLmNvbmZpZz1mdW5jdGlvbih0KXtyZXR1cm4gbmV3IHModCl9LHN9LHA9dShcIkJhY2tcIixmKFwiQmFja091dFwiLGZ1bmN0aW9uKHQpe3JldHVybih0LT0xKSp0KigodGhpcy5fcDErMSkqdCt0aGlzLl9wMSkrMX0pLGYoXCJCYWNrSW5cIixmdW5jdGlvbih0KXtyZXR1cm4gdCp0KigodGhpcy5fcDErMSkqdC10aGlzLl9wMSl9KSxmKFwiQmFja0luT3V0XCIsZnVuY3Rpb24odCl7cmV0dXJuIDE+KHQqPTIpPy41KnQqdCooKHRoaXMuX3AyKzEpKnQtdGhpcy5fcDIpOi41KigodC09MikqdCooKHRoaXMuX3AyKzEpKnQrdGhpcy5fcDIpKzIpfSkpLG09aChcImVhc2luZy5TbG93TW9cIixmdW5jdGlvbih0LGUsaSl7ZT1lfHwwPT09ZT9lOi43LG51bGw9PXQ/dD0uNzp0PjEmJih0PTEpLHRoaXMuX3A9MSE9PXQ/ZTowLHRoaXMuX3AxPSgxLXQpLzIsdGhpcy5fcDI9dCx0aGlzLl9wMz10aGlzLl9wMSt0aGlzLl9wMix0aGlzLl9jYWxjRW5kPWk9PT0hMH0sITApLGQ9bS5wcm90b3R5cGU9bmV3IHQ7cmV0dXJuIGQuY29uc3RydWN0b3I9bSxkLmdldFJhdGlvPWZ1bmN0aW9uKHQpe3ZhciBlPXQrKC41LXQpKnRoaXMuX3A7cmV0dXJuIHRoaXMuX3AxPnQ/dGhpcy5fY2FsY0VuZD8xLSh0PTEtdC90aGlzLl9wMSkqdDplLSh0PTEtdC90aGlzLl9wMSkqdCp0KnQqZTp0PnRoaXMuX3AzP3RoaXMuX2NhbGNFbmQ/MS0odD0odC10aGlzLl9wMykvdGhpcy5fcDEpKnQ6ZSsodC1lKSoodD0odC10aGlzLl9wMykvdGhpcy5fcDEpKnQqdCp0OnRoaXMuX2NhbGNFbmQ/MTplfSxtLmVhc2U9bmV3IG0oLjcsLjcpLGQuY29uZmlnPW0uY29uZmlnPWZ1bmN0aW9uKHQsZSxpKXtyZXR1cm4gbmV3IG0odCxlLGkpfSxlPWgoXCJlYXNpbmcuU3RlcHBlZEVhc2VcIixmdW5jdGlvbih0KXt0PXR8fDEsdGhpcy5fcDE9MS90LHRoaXMuX3AyPXQrMX0sITApLGQ9ZS5wcm90b3R5cGU9bmV3IHQsZC5jb25zdHJ1Y3Rvcj1lLGQuZ2V0UmF0aW89ZnVuY3Rpb24odCl7cmV0dXJuIDA+dD90PTA6dD49MSYmKHQ9Ljk5OTk5OTk5OSksKHRoaXMuX3AyKnQ+PjApKnRoaXMuX3AxfSxkLmNvbmZpZz1lLmNvbmZpZz1mdW5jdGlvbih0KXtyZXR1cm4gbmV3IGUodCl9LGk9aChcImVhc2luZy5Sb3VnaEVhc2VcIixmdW5jdGlvbihlKXtlPWV8fHt9O2Zvcih2YXIgaSxzLHIsbixhLG8saD1lLnRhcGVyfHxcIm5vbmVcIixsPVtdLF89MCx1PTB8KGUucG9pbnRzfHwyMCksZj11LHA9ZS5yYW5kb21pemUhPT0hMSxtPWUuY2xhbXA9PT0hMCxkPWUudGVtcGxhdGUgaW5zdGFuY2VvZiB0P2UudGVtcGxhdGU6bnVsbCxnPVwibnVtYmVyXCI9PXR5cGVvZiBlLnN0cmVuZ3RoPy40KmUuc3RyZW5ndGg6LjQ7LS1mPi0xOylpPXA/TWF0aC5yYW5kb20oKToxL3UqZixzPWQ/ZC5nZXRSYXRpbyhpKTppLFwibm9uZVwiPT09aD9yPWc6XCJvdXRcIj09PWg/KG49MS1pLHI9bipuKmcpOlwiaW5cIj09PWg/cj1pKmkqZzouNT5pPyhuPTIqaSxyPS41Km4qbipnKToobj0yKigxLWkpLHI9LjUqbipuKmcpLHA/cys9TWF0aC5yYW5kb20oKSpyLS41KnI6ZiUyP3MrPS41KnI6cy09LjUqcixtJiYocz4xP3M9MTowPnMmJihzPTApKSxsW18rK109e3g6aSx5OnN9O2ZvcihsLnNvcnQoZnVuY3Rpb24odCxlKXtyZXR1cm4gdC54LWUueH0pLG89bmV3IGMoMSwxLG51bGwpLGY9dTstLWY+LTE7KWE9bFtmXSxvPW5ldyBjKGEueCxhLnksbyk7dGhpcy5fcHJldj1uZXcgYygwLDAsMCE9PW8udD9vOm8ubmV4dCl9LCEwKSxkPWkucHJvdG90eXBlPW5ldyB0LGQuY29uc3RydWN0b3I9aSxkLmdldFJhdGlvPWZ1bmN0aW9uKHQpe3ZhciBlPXRoaXMuX3ByZXY7aWYodD5lLnQpe2Zvcig7ZS5uZXh0JiZ0Pj1lLnQ7KWU9ZS5uZXh0O2U9ZS5wcmV2fWVsc2UgZm9yKDtlLnByZXYmJmUudD49dDspZT1lLnByZXY7cmV0dXJuIHRoaXMuX3ByZXY9ZSxlLnYrKHQtZS50KS9lLmdhcCplLmN9LGQuY29uZmlnPWZ1bmN0aW9uKHQpe3JldHVybiBuZXcgaSh0KX0saS5lYXNlPW5ldyBpLHUoXCJCb3VuY2VcIixsKFwiQm91bmNlT3V0XCIsZnVuY3Rpb24odCl7cmV0dXJuIDEvMi43NT50PzcuNTYyNSp0KnQ6Mi8yLjc1PnQ/Ny41NjI1Kih0LT0xLjUvMi43NSkqdCsuNzU6Mi41LzIuNzU+dD83LjU2MjUqKHQtPTIuMjUvMi43NSkqdCsuOTM3NTo3LjU2MjUqKHQtPTIuNjI1LzIuNzUpKnQrLjk4NDM3NX0pLGwoXCJCb3VuY2VJblwiLGZ1bmN0aW9uKHQpe3JldHVybiAxLzIuNzU+KHQ9MS10KT8xLTcuNTYyNSp0KnQ6Mi8yLjc1PnQ/MS0oNy41NjI1Kih0LT0xLjUvMi43NSkqdCsuNzUpOjIuNS8yLjc1PnQ/MS0oNy41NjI1Kih0LT0yLjI1LzIuNzUpKnQrLjkzNzUpOjEtKDcuNTYyNSoodC09Mi42MjUvMi43NSkqdCsuOTg0Mzc1KX0pLGwoXCJCb3VuY2VJbk91dFwiLGZ1bmN0aW9uKHQpe3ZhciBlPS41PnQ7cmV0dXJuIHQ9ZT8xLTIqdDoyKnQtMSx0PTEvMi43NT50PzcuNTYyNSp0KnQ6Mi8yLjc1PnQ/Ny41NjI1Kih0LT0xLjUvMi43NSkqdCsuNzU6Mi41LzIuNzU+dD83LjU2MjUqKHQtPTIuMjUvMi43NSkqdCsuOTM3NTo3LjU2MjUqKHQtPTIuNjI1LzIuNzUpKnQrLjk4NDM3NSxlPy41KigxLXQpOi41KnQrLjV9KSksdShcIkNpcmNcIixsKFwiQ2lyY091dFwiLGZ1bmN0aW9uKHQpe3JldHVybiBNYXRoLnNxcnQoMS0odC09MSkqdCl9KSxsKFwiQ2lyY0luXCIsZnVuY3Rpb24odCl7cmV0dXJuLShNYXRoLnNxcnQoMS10KnQpLTEpfSksbChcIkNpcmNJbk91dFwiLGZ1bmN0aW9uKHQpe3JldHVybiAxPih0Kj0yKT8tLjUqKE1hdGguc3FydCgxLXQqdCktMSk6LjUqKE1hdGguc3FydCgxLSh0LT0yKSp0KSsxKX0pKSxzPWZ1bmN0aW9uKGUsaSxzKXt2YXIgcj1oKFwiZWFzaW5nLlwiK2UsZnVuY3Rpb24odCxlKXt0aGlzLl9wMT10fHwxLHRoaXMuX3AyPWV8fHMsdGhpcy5fcDM9dGhpcy5fcDIvYSooTWF0aC5hc2luKDEvdGhpcy5fcDEpfHwwKX0sITApLG49ci5wcm90b3R5cGU9bmV3IHQ7cmV0dXJuIG4uY29uc3RydWN0b3I9cixuLmdldFJhdGlvPWksbi5jb25maWc9ZnVuY3Rpb24odCxlKXtyZXR1cm4gbmV3IHIodCxlKX0scn0sdShcIkVsYXN0aWNcIixzKFwiRWxhc3RpY091dFwiLGZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLl9wMSpNYXRoLnBvdygyLC0xMCp0KSpNYXRoLnNpbigodC10aGlzLl9wMykqYS90aGlzLl9wMikrMX0sLjMpLHMoXCJFbGFzdGljSW5cIixmdW5jdGlvbih0KXtyZXR1cm4tKHRoaXMuX3AxKk1hdGgucG93KDIsMTAqKHQtPTEpKSpNYXRoLnNpbigodC10aGlzLl9wMykqYS90aGlzLl9wMikpfSwuMykscyhcIkVsYXN0aWNJbk91dFwiLGZ1bmN0aW9uKHQpe3JldHVybiAxPih0Kj0yKT8tLjUqdGhpcy5fcDEqTWF0aC5wb3coMiwxMCoodC09MSkpKk1hdGguc2luKCh0LXRoaXMuX3AzKSphL3RoaXMuX3AyKTouNSp0aGlzLl9wMSpNYXRoLnBvdygyLC0xMCoodC09MSkpKk1hdGguc2luKCh0LXRoaXMuX3AzKSphL3RoaXMuX3AyKSsxfSwuNDUpKSx1KFwiRXhwb1wiLGwoXCJFeHBvT3V0XCIsZnVuY3Rpb24odCl7cmV0dXJuIDEtTWF0aC5wb3coMiwtMTAqdCl9KSxsKFwiRXhwb0luXCIsZnVuY3Rpb24odCl7cmV0dXJuIE1hdGgucG93KDIsMTAqKHQtMSkpLS4wMDF9KSxsKFwiRXhwb0luT3V0XCIsZnVuY3Rpb24odCl7cmV0dXJuIDE+KHQqPTIpPy41Kk1hdGgucG93KDIsMTAqKHQtMSkpOi41KigyLU1hdGgucG93KDIsLTEwKih0LTEpKSl9KSksdShcIlNpbmVcIixsKFwiU2luZU91dFwiLGZ1bmN0aW9uKHQpe3JldHVybiBNYXRoLnNpbih0Km8pfSksbChcIlNpbmVJblwiLGZ1bmN0aW9uKHQpe3JldHVybi1NYXRoLmNvcyh0Km8pKzF9KSxsKFwiU2luZUluT3V0XCIsZnVuY3Rpb24odCl7cmV0dXJuLS41KihNYXRoLmNvcyhNYXRoLlBJKnQpLTEpfSkpLGgoXCJlYXNpbmcuRWFzZUxvb2t1cFwiLHtmaW5kOmZ1bmN0aW9uKGUpe3JldHVybiB0Lm1hcFtlXX19LCEwKSxfKHIuU2xvd01vLFwiU2xvd01vXCIsXCJlYXNlLFwiKSxfKGksXCJSb3VnaEVhc2VcIixcImVhc2UsXCIpLF8oZSxcIlN0ZXBwZWRFYXNlXCIsXCJlYXNlLFwiKSxwfSwhMCl9KSx3aW5kb3cuX2dzRGVmaW5lJiZ3aW5kb3cuX2dzUXVldWUucG9wKCkoKTsiLCIvKiFcclxuICogVkVSU0lPTjogMS4xMi4xXHJcbiAqIERBVEU6IDIwMTQtMDYtMjZcclxuICogVVBEQVRFUyBBTkQgRE9DUyBBVDogaHR0cDovL3d3dy5ncmVlbnNvY2suY29tXHJcbiAqXHJcbiAqIEBsaWNlbnNlIENvcHlyaWdodCAoYykgMjAwOC0yMDE0LCBHcmVlblNvY2suIEFsbCByaWdodHMgcmVzZXJ2ZWQuXHJcbiAqIFRoaXMgd29yayBpcyBzdWJqZWN0IHRvIHRoZSB0ZXJtcyBhdCBodHRwOi8vd3d3LmdyZWVuc29jay5jb20vdGVybXNfb2ZfdXNlLmh0bWwgb3IgZm9yXHJcbiAqIENsdWIgR3JlZW5Tb2NrIG1lbWJlcnMsIHRoZSBzb2Z0d2FyZSBhZ3JlZW1lbnQgdGhhdCB3YXMgaXNzdWVkIHdpdGggeW91ciBtZW1iZXJzaGlwLlxyXG4gKiBcclxuICogQGF1dGhvcjogSmFjayBEb3lsZSwgamFja0BncmVlbnNvY2suY29tXHJcbiAqL1xyXG4od2luZG93Ll9nc1F1ZXVlfHwod2luZG93Ll9nc1F1ZXVlPVtdKSkucHVzaChmdW5jdGlvbigpe1widXNlIHN0cmljdFwiO3dpbmRvdy5fZ3NEZWZpbmUoXCJwbHVnaW5zLkNTU1BsdWdpblwiLFtcInBsdWdpbnMuVHdlZW5QbHVnaW5cIixcIlR3ZWVuTGl0ZVwiXSxmdW5jdGlvbih0LGUpe3ZhciBpLHIscyxuLGE9ZnVuY3Rpb24oKXt0LmNhbGwodGhpcyxcImNzc1wiKSx0aGlzLl9vdmVyd3JpdGVQcm9wcy5sZW5ndGg9MCx0aGlzLnNldFJhdGlvPWEucHJvdG90eXBlLnNldFJhdGlvfSxvPXt9LGw9YS5wcm90b3R5cGU9bmV3IHQoXCJjc3NcIik7bC5jb25zdHJ1Y3Rvcj1hLGEudmVyc2lvbj1cIjEuMTIuMVwiLGEuQVBJPTIsYS5kZWZhdWx0VHJhbnNmb3JtUGVyc3BlY3RpdmU9MCxhLmRlZmF1bHRTa2V3VHlwZT1cImNvbXBlbnNhdGVkXCIsbD1cInB4XCIsYS5zdWZmaXhNYXA9e3RvcDpsLHJpZ2h0OmwsYm90dG9tOmwsbGVmdDpsLHdpZHRoOmwsaGVpZ2h0OmwsZm9udFNpemU6bCxwYWRkaW5nOmwsbWFyZ2luOmwscGVyc3BlY3RpdmU6bCxsaW5lSGVpZ2h0OlwiXCJ9O3ZhciBoLHUsZixfLHAsYyxkPS8oPzpcXGR8XFwtXFxkfFxcLlxcZHxcXC1cXC5cXGQpKy9nLG09Lyg/OlxcZHxcXC1cXGR8XFwuXFxkfFxcLVxcLlxcZHxcXCs9XFxkfFxcLT1cXGR8XFwrPS5cXGR8XFwtPVxcLlxcZCkrL2csZz0vKD86XFwrPXxcXC09fFxcLXxcXGIpW1xcZFxcLVxcLl0rW2EtekEtWjAtOV0qKD86JXxcXGIpL2dpLHY9L1teXFxkXFwtXFwuXS9nLHk9Lyg/OlxcZHxcXC18XFwrfD18I3xcXC4pKi9nLFQ9L29wYWNpdHkgKj0gKihbXildKikvaSx3PS9vcGFjaXR5OihbXjtdKikvaSx4PS9hbHBoYVxcKG9wYWNpdHkgKj0uKz9cXCkvaSxiPS9eKHJnYnxoc2wpLyxQPS8oW0EtWl0pL2csUz0vLShbYS16XSkvZ2ksQz0vKF4oPzp1cmxcXChcXFwifHVybFxcKCkpfCg/OihcXFwiXFwpKSR8XFwpJCkvZ2ksUj1mdW5jdGlvbih0LGUpe3JldHVybiBlLnRvVXBwZXJDYXNlKCl9LGs9Lyg/OkxlZnR8UmlnaHR8V2lkdGgpL2ksQT0vKE0xMXxNMTJ8TTIxfE0yMik9W1xcZFxcLVxcLmVdKy9naSxPPS9wcm9naWRcXDpEWEltYWdlVHJhbnNmb3JtXFwuTWljcm9zb2Z0XFwuTWF0cml4XFwoLis/XFwpL2ksRD0vLCg/PVteXFwpXSooPzpcXCh8JCkpL2dpLE09TWF0aC5QSS8xODAsTD0xODAvTWF0aC5QSSxOPXt9LFg9ZG9jdW1lbnQsej1YLmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksST1YLmNyZWF0ZUVsZW1lbnQoXCJpbWdcIiksRT1hLl9pbnRlcm5hbHM9e19zcGVjaWFsUHJvcHM6b30sRj1uYXZpZ2F0b3IudXNlckFnZW50LFk9ZnVuY3Rpb24oKXt2YXIgdCxlPUYuaW5kZXhPZihcIkFuZHJvaWRcIiksaT1YLmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7cmV0dXJuIGY9LTEhPT1GLmluZGV4T2YoXCJTYWZhcmlcIikmJi0xPT09Ri5pbmRleE9mKFwiQ2hyb21lXCIpJiYoLTE9PT1lfHxOdW1iZXIoRi5zdWJzdHIoZSs4LDEpKT4zKSxwPWYmJjY+TnVtYmVyKEYuc3Vic3RyKEYuaW5kZXhPZihcIlZlcnNpb24vXCIpKzgsMSkpLF89LTEhPT1GLmluZGV4T2YoXCJGaXJlZm94XCIpLC9NU0lFIChbMC05XXsxLH1bXFwuMC05XXswLH0pLy5leGVjKEYpJiYoYz1wYXJzZUZsb2F0KFJlZ0V4cC4kMSkpLGkuaW5uZXJIVE1MPVwiPGEgc3R5bGU9J3RvcDoxcHg7b3BhY2l0eTouNTU7Jz5hPC9hPlwiLHQ9aS5nZXRFbGVtZW50c0J5VGFnTmFtZShcImFcIilbMF0sdD8vXjAuNTUvLnRlc3QodC5zdHlsZS5vcGFjaXR5KTohMX0oKSxCPWZ1bmN0aW9uKHQpe3JldHVybiBULnRlc3QoXCJzdHJpbmdcIj09dHlwZW9mIHQ/dDoodC5jdXJyZW50U3R5bGU/dC5jdXJyZW50U3R5bGUuZmlsdGVyOnQuc3R5bGUuZmlsdGVyKXx8XCJcIik/cGFyc2VGbG9hdChSZWdFeHAuJDEpLzEwMDoxfSxVPWZ1bmN0aW9uKHQpe3dpbmRvdy5jb25zb2xlJiZjb25zb2xlLmxvZyh0KX0sVz1cIlwiLGo9XCJcIixWPWZ1bmN0aW9uKHQsZSl7ZT1lfHx6O3ZhciBpLHIscz1lLnN0eWxlO2lmKHZvaWQgMCE9PXNbdF0pcmV0dXJuIHQ7Zm9yKHQ9dC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSt0LnN1YnN0cigxKSxpPVtcIk9cIixcIk1velwiLFwibXNcIixcIk1zXCIsXCJXZWJraXRcIl0scj01Oy0tcj4tMSYmdm9pZCAwPT09c1tpW3JdK3RdOyk7cmV0dXJuIHI+PTA/KGo9Mz09PXI/XCJtc1wiOmlbcl0sVz1cIi1cIitqLnRvTG93ZXJDYXNlKCkrXCItXCIsait0KTpudWxsfSxIPVguZGVmYXVsdFZpZXc/WC5kZWZhdWx0Vmlldy5nZXRDb21wdXRlZFN0eWxlOmZ1bmN0aW9uKCl7fSxxPWEuZ2V0U3R5bGU9ZnVuY3Rpb24odCxlLGkscixzKXt2YXIgbjtyZXR1cm4gWXx8XCJvcGFjaXR5XCIhPT1lPyghciYmdC5zdHlsZVtlXT9uPXQuc3R5bGVbZV06KGk9aXx8SCh0KSk/bj1pW2VdfHxpLmdldFByb3BlcnR5VmFsdWUoZSl8fGkuZ2V0UHJvcGVydHlWYWx1ZShlLnJlcGxhY2UoUCxcIi0kMVwiKS50b0xvd2VyQ2FzZSgpKTp0LmN1cnJlbnRTdHlsZSYmKG49dC5jdXJyZW50U3R5bGVbZV0pLG51bGw9PXN8fG4mJlwibm9uZVwiIT09biYmXCJhdXRvXCIhPT1uJiZcImF1dG8gYXV0b1wiIT09bj9uOnMpOkIodCl9LFE9RS5jb252ZXJ0VG9QaXhlbHM9ZnVuY3Rpb24odCxpLHIscyxuKXtpZihcInB4XCI9PT1zfHwhcylyZXR1cm4gcjtpZihcImF1dG9cIj09PXN8fCFyKXJldHVybiAwO3ZhciBvLGwsaCx1PWsudGVzdChpKSxmPXQsXz16LnN0eWxlLHA9MD5yO2lmKHAmJihyPS1yKSxcIiVcIj09PXMmJi0xIT09aS5pbmRleE9mKFwiYm9yZGVyXCIpKW89ci8xMDAqKHU/dC5jbGllbnRXaWR0aDp0LmNsaWVudEhlaWdodCk7ZWxzZXtpZihfLmNzc1RleHQ9XCJib3JkZXI6MCBzb2xpZCByZWQ7cG9zaXRpb246XCIrcSh0LFwicG9zaXRpb25cIikrXCI7bGluZS1oZWlnaHQ6MDtcIixcIiVcIiE9PXMmJmYuYXBwZW5kQ2hpbGQpX1t1P1wiYm9yZGVyTGVmdFdpZHRoXCI6XCJib3JkZXJUb3BXaWR0aFwiXT1yK3M7ZWxzZXtpZihmPXQucGFyZW50Tm9kZXx8WC5ib2R5LGw9Zi5fZ3NDYWNoZSxoPWUudGlja2VyLmZyYW1lLGwmJnUmJmwudGltZT09PWgpcmV0dXJuIGwud2lkdGgqci8xMDA7X1t1P1wid2lkdGhcIjpcImhlaWdodFwiXT1yK3N9Zi5hcHBlbmRDaGlsZCh6KSxvPXBhcnNlRmxvYXQoelt1P1wib2Zmc2V0V2lkdGhcIjpcIm9mZnNldEhlaWdodFwiXSksZi5yZW1vdmVDaGlsZCh6KSx1JiZcIiVcIj09PXMmJmEuY2FjaGVXaWR0aHMhPT0hMSYmKGw9Zi5fZ3NDYWNoZT1mLl9nc0NhY2hlfHx7fSxsLnRpbWU9aCxsLndpZHRoPTEwMCooby9yKSksMCE9PW98fG58fChvPVEodCxpLHIscywhMCkpfXJldHVybiBwPy1vOm99LFo9RS5jYWxjdWxhdGVPZmZzZXQ9ZnVuY3Rpb24odCxlLGkpe2lmKFwiYWJzb2x1dGVcIiE9PXEodCxcInBvc2l0aW9uXCIsaSkpcmV0dXJuIDA7dmFyIHI9XCJsZWZ0XCI9PT1lP1wiTGVmdFwiOlwiVG9wXCIscz1xKHQsXCJtYXJnaW5cIityLGkpO3JldHVybiB0W1wib2Zmc2V0XCIrcl0tKFEodCxlLHBhcnNlRmxvYXQocykscy5yZXBsYWNlKHksXCJcIikpfHwwKX0sJD1mdW5jdGlvbih0LGUpe3ZhciBpLHIscz17fTtpZihlPWV8fEgodCxudWxsKSlpZihpPWUubGVuZ3RoKWZvcig7LS1pPi0xOylzW2VbaV0ucmVwbGFjZShTLFIpXT1lLmdldFByb3BlcnR5VmFsdWUoZVtpXSk7ZWxzZSBmb3IoaSBpbiBlKXNbaV09ZVtpXTtlbHNlIGlmKGU9dC5jdXJyZW50U3R5bGV8fHQuc3R5bGUpZm9yKGkgaW4gZSlcInN0cmluZ1wiPT10eXBlb2YgaSYmdm9pZCAwPT09c1tpXSYmKHNbaS5yZXBsYWNlKFMsUildPWVbaV0pO3JldHVybiBZfHwocy5vcGFjaXR5PUIodCkpLHI9UGUodCxlLCExKSxzLnJvdGF0aW9uPXIucm90YXRpb24scy5za2V3WD1yLnNrZXdYLHMuc2NhbGVYPXIuc2NhbGVYLHMuc2NhbGVZPXIuc2NhbGVZLHMueD1yLngscy55PXIueSx4ZSYmKHMuej1yLnoscy5yb3RhdGlvblg9ci5yb3RhdGlvblgscy5yb3RhdGlvblk9ci5yb3RhdGlvblkscy5zY2FsZVo9ci5zY2FsZVopLHMuZmlsdGVycyYmZGVsZXRlIHMuZmlsdGVycyxzfSxHPWZ1bmN0aW9uKHQsZSxpLHIscyl7dmFyIG4sYSxvLGw9e30saD10LnN0eWxlO2ZvcihhIGluIGkpXCJjc3NUZXh0XCIhPT1hJiZcImxlbmd0aFwiIT09YSYmaXNOYU4oYSkmJihlW2FdIT09KG49aVthXSl8fHMmJnNbYV0pJiYtMT09PWEuaW5kZXhPZihcIk9yaWdpblwiKSYmKFwibnVtYmVyXCI9PXR5cGVvZiBufHxcInN0cmluZ1wiPT10eXBlb2YgbikmJihsW2FdPVwiYXV0b1wiIT09bnx8XCJsZWZ0XCIhPT1hJiZcInRvcFwiIT09YT9cIlwiIT09biYmXCJhdXRvXCIhPT1uJiZcIm5vbmVcIiE9PW58fFwic3RyaW5nXCIhPXR5cGVvZiBlW2FdfHxcIlwiPT09ZVthXS5yZXBsYWNlKHYsXCJcIik/bjowOloodCxhKSx2b2lkIDAhPT1oW2FdJiYobz1uZXcgZmUoaCxhLGhbYV0sbykpKTtpZihyKWZvcihhIGluIHIpXCJjbGFzc05hbWVcIiE9PWEmJihsW2FdPXJbYV0pO3JldHVybntkaWZzOmwsZmlyc3RNUFQ6b319LEs9e3dpZHRoOltcIkxlZnRcIixcIlJpZ2h0XCJdLGhlaWdodDpbXCJUb3BcIixcIkJvdHRvbVwiXX0sSj1bXCJtYXJnaW5MZWZ0XCIsXCJtYXJnaW5SaWdodFwiLFwibWFyZ2luVG9wXCIsXCJtYXJnaW5Cb3R0b21cIl0sdGU9ZnVuY3Rpb24odCxlLGkpe3ZhciByPXBhcnNlRmxvYXQoXCJ3aWR0aFwiPT09ZT90Lm9mZnNldFdpZHRoOnQub2Zmc2V0SGVpZ2h0KSxzPUtbZV0sbj1zLmxlbmd0aDtmb3IoaT1pfHxIKHQsbnVsbCk7LS1uPi0xOylyLT1wYXJzZUZsb2F0KHEodCxcInBhZGRpbmdcIitzW25dLGksITApKXx8MCxyLT1wYXJzZUZsb2F0KHEodCxcImJvcmRlclwiK3Nbbl0rXCJXaWR0aFwiLGksITApKXx8MDtyZXR1cm4gcn0sZWU9ZnVuY3Rpb24odCxlKXsobnVsbD09dHx8XCJcIj09PXR8fFwiYXV0b1wiPT09dHx8XCJhdXRvIGF1dG9cIj09PXQpJiYodD1cIjAgMFwiKTt2YXIgaT10LnNwbGl0KFwiIFwiKSxyPS0xIT09dC5pbmRleE9mKFwibGVmdFwiKT9cIjAlXCI6LTEhPT10LmluZGV4T2YoXCJyaWdodFwiKT9cIjEwMCVcIjppWzBdLHM9LTEhPT10LmluZGV4T2YoXCJ0b3BcIik/XCIwJVwiOi0xIT09dC5pbmRleE9mKFwiYm90dG9tXCIpP1wiMTAwJVwiOmlbMV07cmV0dXJuIG51bGw9PXM/cz1cIjBcIjpcImNlbnRlclwiPT09cyYmKHM9XCI1MCVcIiksKFwiY2VudGVyXCI9PT1yfHxpc05hTihwYXJzZUZsb2F0KHIpKSYmLTE9PT0ocitcIlwiKS5pbmRleE9mKFwiPVwiKSkmJihyPVwiNTAlXCIpLGUmJihlLm94cD0tMSE9PXIuaW5kZXhPZihcIiVcIiksZS5veXA9LTEhPT1zLmluZGV4T2YoXCIlXCIpLGUub3hyPVwiPVwiPT09ci5jaGFyQXQoMSksZS5veXI9XCI9XCI9PT1zLmNoYXJBdCgxKSxlLm94PXBhcnNlRmxvYXQoci5yZXBsYWNlKHYsXCJcIikpLGUub3k9cGFyc2VGbG9hdChzLnJlcGxhY2UodixcIlwiKSkpLHIrXCIgXCIrcysoaS5sZW5ndGg+Mj9cIiBcIitpWzJdOlwiXCIpfSxpZT1mdW5jdGlvbih0LGUpe3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiB0JiZcIj1cIj09PXQuY2hhckF0KDEpP3BhcnNlSW50KHQuY2hhckF0KDApK1wiMVwiLDEwKSpwYXJzZUZsb2F0KHQuc3Vic3RyKDIpKTpwYXJzZUZsb2F0KHQpLXBhcnNlRmxvYXQoZSl9LHJlPWZ1bmN0aW9uKHQsZSl7cmV0dXJuIG51bGw9PXQ/ZTpcInN0cmluZ1wiPT10eXBlb2YgdCYmXCI9XCI9PT10LmNoYXJBdCgxKT9wYXJzZUludCh0LmNoYXJBdCgwKStcIjFcIiwxMCkqTnVtYmVyKHQuc3Vic3RyKDIpKStlOnBhcnNlRmxvYXQodCl9LHNlPWZ1bmN0aW9uKHQsZSxpLHIpe3ZhciBzLG4sYSxvLGw9MWUtNjtyZXR1cm4gbnVsbD09dD9vPWU6XCJudW1iZXJcIj09dHlwZW9mIHQ/bz10OihzPTM2MCxuPXQuc3BsaXQoXCJfXCIpLGE9TnVtYmVyKG5bMF0ucmVwbGFjZSh2LFwiXCIpKSooLTE9PT10LmluZGV4T2YoXCJyYWRcIik/MTpMKS0oXCI9XCI9PT10LmNoYXJBdCgxKT8wOmUpLG4ubGVuZ3RoJiYociYmKHJbaV09ZSthKSwtMSE9PXQuaW5kZXhPZihcInNob3J0XCIpJiYoYSU9cyxhIT09YSUocy8yKSYmKGE9MD5hP2ErczphLXMpKSwtMSE9PXQuaW5kZXhPZihcIl9jd1wiKSYmMD5hP2E9KGErOTk5OTk5OTk5OSpzKSVzLSgwfGEvcykqczotMSE9PXQuaW5kZXhPZihcImNjd1wiKSYmYT4wJiYoYT0oYS05OTk5OTk5OTk5KnMpJXMtKDB8YS9zKSpzKSksbz1lK2EpLGw+byYmbz4tbCYmKG89MCksb30sbmU9e2FxdWE6WzAsMjU1LDI1NV0sbGltZTpbMCwyNTUsMF0sc2lsdmVyOlsxOTIsMTkyLDE5Ml0sYmxhY2s6WzAsMCwwXSxtYXJvb246WzEyOCwwLDBdLHRlYWw6WzAsMTI4LDEyOF0sYmx1ZTpbMCwwLDI1NV0sbmF2eTpbMCwwLDEyOF0sd2hpdGU6WzI1NSwyNTUsMjU1XSxmdWNoc2lhOlsyNTUsMCwyNTVdLG9saXZlOlsxMjgsMTI4LDBdLHllbGxvdzpbMjU1LDI1NSwwXSxvcmFuZ2U6WzI1NSwxNjUsMF0sZ3JheTpbMTI4LDEyOCwxMjhdLHB1cnBsZTpbMTI4LDAsMTI4XSxncmVlbjpbMCwxMjgsMF0scmVkOlsyNTUsMCwwXSxwaW5rOlsyNTUsMTkyLDIwM10sY3lhbjpbMCwyNTUsMjU1XSx0cmFuc3BhcmVudDpbMjU1LDI1NSwyNTUsMF19LGFlPWZ1bmN0aW9uKHQsZSxpKXtyZXR1cm4gdD0wPnQ/dCsxOnQ+MT90LTE6dCwwfDI1NSooMT42KnQ/ZSs2KihpLWUpKnQ6LjU+dD9pOjI+Myp0P2UrNiooaS1lKSooMi8zLXQpOmUpKy41fSxvZT1mdW5jdGlvbih0KXt2YXIgZSxpLHIscyxuLGE7cmV0dXJuIHQmJlwiXCIhPT10P1wibnVtYmVyXCI9PXR5cGVvZiB0P1t0Pj4xNiwyNTUmdD4+OCwyNTUmdF06KFwiLFwiPT09dC5jaGFyQXQodC5sZW5ndGgtMSkmJih0PXQuc3Vic3RyKDAsdC5sZW5ndGgtMSkpLG5lW3RdP25lW3RdOlwiI1wiPT09dC5jaGFyQXQoMCk/KDQ9PT10Lmxlbmd0aCYmKGU9dC5jaGFyQXQoMSksaT10LmNoYXJBdCgyKSxyPXQuY2hhckF0KDMpLHQ9XCIjXCIrZStlK2kraStyK3IpLHQ9cGFyc2VJbnQodC5zdWJzdHIoMSksMTYpLFt0Pj4xNiwyNTUmdD4+OCwyNTUmdF0pOlwiaHNsXCI9PT10LnN1YnN0cigwLDMpPyh0PXQubWF0Y2goZCkscz1OdW1iZXIodFswXSklMzYwLzM2MCxuPU51bWJlcih0WzFdKS8xMDAsYT1OdW1iZXIodFsyXSkvMTAwLGk9LjU+PWE/YSoobisxKTphK24tYSpuLGU9MiphLWksdC5sZW5ndGg+MyYmKHRbM109TnVtYmVyKHRbM10pKSx0WzBdPWFlKHMrMS8zLGUsaSksdFsxXT1hZShzLGUsaSksdFsyXT1hZShzLTEvMyxlLGkpLHQpOih0PXQubWF0Y2goZCl8fG5lLnRyYW5zcGFyZW50LHRbMF09TnVtYmVyKHRbMF0pLHRbMV09TnVtYmVyKHRbMV0pLHRbMl09TnVtYmVyKHRbMl0pLHQubGVuZ3RoPjMmJih0WzNdPU51bWJlcih0WzNdKSksdCkpOm5lLmJsYWNrfSxsZT1cIig/OlxcXFxiKD86KD86cmdifHJnYmF8aHNsfGhzbGEpXFxcXCguKz9cXFxcKSl8XFxcXEIjLis/XFxcXGJcIjtmb3IobCBpbiBuZSlsZSs9XCJ8XCIrbCtcIlxcXFxiXCI7bGU9UmVnRXhwKGxlK1wiKVwiLFwiZ2lcIik7dmFyIGhlPWZ1bmN0aW9uKHQsZSxpLHIpe2lmKG51bGw9PXQpcmV0dXJuIGZ1bmN0aW9uKHQpe3JldHVybiB0fTt2YXIgcyxuPWU/KHQubWF0Y2gobGUpfHxbXCJcIl0pWzBdOlwiXCIsYT10LnNwbGl0KG4pLmpvaW4oXCJcIikubWF0Y2goZyl8fFtdLG89dC5zdWJzdHIoMCx0LmluZGV4T2YoYVswXSkpLGw9XCIpXCI9PT10LmNoYXJBdCh0Lmxlbmd0aC0xKT9cIilcIjpcIlwiLGg9LTEhPT10LmluZGV4T2YoXCIgXCIpP1wiIFwiOlwiLFwiLHU9YS5sZW5ndGgsZj11PjA/YVswXS5yZXBsYWNlKGQsXCJcIik6XCJcIjtyZXR1cm4gdT9zPWU/ZnVuY3Rpb24odCl7dmFyIGUsXyxwLGM7aWYoXCJudW1iZXJcIj09dHlwZW9mIHQpdCs9ZjtlbHNlIGlmKHImJkQudGVzdCh0KSl7Zm9yKGM9dC5yZXBsYWNlKEQsXCJ8XCIpLnNwbGl0KFwifFwiKSxwPTA7Yy5sZW5ndGg+cDtwKyspY1twXT1zKGNbcF0pO3JldHVybiBjLmpvaW4oXCIsXCIpfWlmKGU9KHQubWF0Y2gobGUpfHxbbl0pWzBdLF89dC5zcGxpdChlKS5qb2luKFwiXCIpLm1hdGNoKGcpfHxbXSxwPV8ubGVuZ3RoLHU+cC0tKWZvcig7dT4rK3A7KV9bcF09aT9fWzB8KHAtMSkvMl06YVtwXTtyZXR1cm4gbytfLmpvaW4oaCkraCtlK2wrKC0xIT09dC5pbmRleE9mKFwiaW5zZXRcIik/XCIgaW5zZXRcIjpcIlwiKX06ZnVuY3Rpb24odCl7dmFyIGUsbixfO2lmKFwibnVtYmVyXCI9PXR5cGVvZiB0KXQrPWY7ZWxzZSBpZihyJiZELnRlc3QodCkpe2ZvcihuPXQucmVwbGFjZShELFwifFwiKS5zcGxpdChcInxcIiksXz0wO24ubGVuZ3RoPl87XysrKW5bX109cyhuW19dKTtyZXR1cm4gbi5qb2luKFwiLFwiKX1pZihlPXQubWF0Y2goZyl8fFtdLF89ZS5sZW5ndGgsdT5fLS0pZm9yKDt1PisrXzspZVtfXT1pP2VbMHwoXy0xKS8yXTphW19dO3JldHVybiBvK2Uuam9pbihoKStsfTpmdW5jdGlvbih0KXtyZXR1cm4gdH19LHVlPWZ1bmN0aW9uKHQpe3JldHVybiB0PXQuc3BsaXQoXCIsXCIpLGZ1bmN0aW9uKGUsaSxyLHMsbixhLG8pe3ZhciBsLGg9KGkrXCJcIikuc3BsaXQoXCIgXCIpO2ZvcihvPXt9LGw9MDs0Pmw7bCsrKW9bdFtsXV09aFtsXT1oW2xdfHxoWyhsLTEpLzI+PjBdO3JldHVybiBzLnBhcnNlKGUsbyxuLGEpfX0sZmU9KEUuX3NldFBsdWdpblJhdGlvPWZ1bmN0aW9uKHQpe3RoaXMucGx1Z2luLnNldFJhdGlvKHQpO2Zvcih2YXIgZSxpLHIscyxuPXRoaXMuZGF0YSxhPW4ucHJveHksbz1uLmZpcnN0TVBULGw9MWUtNjtvOyllPWFbby52XSxvLnI/ZT1NYXRoLnJvdW5kKGUpOmw+ZSYmZT4tbCYmKGU9MCksby50W28ucF09ZSxvPW8uX25leHQ7aWYobi5hdXRvUm90YXRlJiYobi5hdXRvUm90YXRlLnJvdGF0aW9uPWEucm90YXRpb24pLDE9PT10KWZvcihvPW4uZmlyc3RNUFQ7bzspe2lmKGk9by50LGkudHlwZSl7aWYoMT09PWkudHlwZSl7Zm9yKHM9aS54czAraS5zK2kueHMxLHI9MTtpLmw+cjtyKyspcys9aVtcInhuXCIrcl0raVtcInhzXCIrKHIrMSldO2kuZT1zfX1lbHNlIGkuZT1pLnMraS54czA7bz1vLl9uZXh0fX0sZnVuY3Rpb24odCxlLGkscixzKXt0aGlzLnQ9dCx0aGlzLnA9ZSx0aGlzLnY9aSx0aGlzLnI9cyxyJiYoci5fcHJldj10aGlzLHRoaXMuX25leHQ9cil9KSxfZT0oRS5fcGFyc2VUb1Byb3h5PWZ1bmN0aW9uKHQsZSxpLHIscyxuKXt2YXIgYSxvLGwsaCx1LGY9cixfPXt9LHA9e30sYz1pLl90cmFuc2Zvcm0sZD1OO2ZvcihpLl90cmFuc2Zvcm09bnVsbCxOPWUscj11PWkucGFyc2UodCxlLHIscyksTj1kLG4mJihpLl90cmFuc2Zvcm09YyxmJiYoZi5fcHJldj1udWxsLGYuX3ByZXYmJihmLl9wcmV2Ll9uZXh0PW51bGwpKSk7ciYmciE9PWY7KXtpZigxPj1yLnR5cGUmJihvPXIucCxwW29dPXIucytyLmMsX1tvXT1yLnMsbnx8KGg9bmV3IGZlKHIsXCJzXCIsbyxoLHIuciksci5jPTApLDE9PT1yLnR5cGUpKWZvcihhPXIubDstLWE+MDspbD1cInhuXCIrYSxvPXIucCtcIl9cIitsLHBbb109ci5kYXRhW2xdLF9bb109cltsXSxufHwoaD1uZXcgZmUocixsLG8saCxyLnJ4cFtsXSkpO3I9ci5fbmV4dH1yZXR1cm57cHJveHk6XyxlbmQ6cCxmaXJzdE1QVDpoLHB0OnV9fSxFLkNTU1Byb3BUd2Vlbj1mdW5jdGlvbih0LGUscixzLGEsbyxsLGgsdSxmLF8pe3RoaXMudD10LHRoaXMucD1lLHRoaXMucz1yLHRoaXMuYz1zLHRoaXMubj1sfHxlLHQgaW5zdGFuY2VvZiBfZXx8bi5wdXNoKHRoaXMubiksdGhpcy5yPWgsdGhpcy50eXBlPW98fDAsdSYmKHRoaXMucHI9dSxpPSEwKSx0aGlzLmI9dm9pZCAwPT09Zj9yOmYsdGhpcy5lPXZvaWQgMD09PV8/citzOl8sYSYmKHRoaXMuX25leHQ9YSxhLl9wcmV2PXRoaXMpfSkscGU9YS5wYXJzZUNvbXBsZXg9ZnVuY3Rpb24odCxlLGkscixzLG4sYSxvLGwsdSl7aT1pfHxufHxcIlwiLGE9bmV3IF9lKHQsZSwwLDAsYSx1PzI6MSxudWxsLCExLG8saSxyKSxyKz1cIlwiO3ZhciBmLF8scCxjLGcsdix5LFQsdyx4LFAsUyxDPWkuc3BsaXQoXCIsIFwiKS5qb2luKFwiLFwiKS5zcGxpdChcIiBcIiksUj1yLnNwbGl0KFwiLCBcIikuam9pbihcIixcIikuc3BsaXQoXCIgXCIpLGs9Qy5sZW5ndGgsQT1oIT09ITE7Zm9yKCgtMSE9PXIuaW5kZXhPZihcIixcIil8fC0xIT09aS5pbmRleE9mKFwiLFwiKSkmJihDPUMuam9pbihcIiBcIikucmVwbGFjZShELFwiLCBcIikuc3BsaXQoXCIgXCIpLFI9Ui5qb2luKFwiIFwiKS5yZXBsYWNlKEQsXCIsIFwiKS5zcGxpdChcIiBcIiksaz1DLmxlbmd0aCksayE9PVIubGVuZ3RoJiYoQz0obnx8XCJcIikuc3BsaXQoXCIgXCIpLGs9Qy5sZW5ndGgpLGEucGx1Z2luPWwsYS5zZXRSYXRpbz11LGY9MDtrPmY7ZisrKWlmKGM9Q1tmXSxnPVJbZl0sVD1wYXJzZUZsb2F0KGMpLFR8fDA9PT1UKWEuYXBwZW5kWHRyYShcIlwiLFQsaWUoZyxUKSxnLnJlcGxhY2UobSxcIlwiKSxBJiYtMSE9PWcuaW5kZXhPZihcInB4XCIpLCEwKTtlbHNlIGlmKHMmJihcIiNcIj09PWMuY2hhckF0KDApfHxuZVtjXXx8Yi50ZXN0KGMpKSlTPVwiLFwiPT09Zy5jaGFyQXQoZy5sZW5ndGgtMSk/XCIpLFwiOlwiKVwiLGM9b2UoYyksZz1vZShnKSx3PWMubGVuZ3RoK2cubGVuZ3RoPjYsdyYmIVkmJjA9PT1nWzNdPyhhW1wieHNcIithLmxdKz1hLmw/XCIgdHJhbnNwYXJlbnRcIjpcInRyYW5zcGFyZW50XCIsYS5lPWEuZS5zcGxpdChSW2ZdKS5qb2luKFwidHJhbnNwYXJlbnRcIikpOihZfHwodz0hMSksYS5hcHBlbmRYdHJhKHc/XCJyZ2JhKFwiOlwicmdiKFwiLGNbMF0sZ1swXS1jWzBdLFwiLFwiLCEwLCEwKS5hcHBlbmRYdHJhKFwiXCIsY1sxXSxnWzFdLWNbMV0sXCIsXCIsITApLmFwcGVuZFh0cmEoXCJcIixjWzJdLGdbMl0tY1syXSx3P1wiLFwiOlMsITApLHcmJihjPTQ+Yy5sZW5ndGg/MTpjWzNdLGEuYXBwZW5kWHRyYShcIlwiLGMsKDQ+Zy5sZW5ndGg/MTpnWzNdKS1jLFMsITEpKSk7ZWxzZSBpZih2PWMubWF0Y2goZCkpe2lmKHk9Zy5tYXRjaChtKSwheXx8eS5sZW5ndGghPT12Lmxlbmd0aClyZXR1cm4gYTtmb3IocD0wLF89MDt2Lmxlbmd0aD5fO18rKylQPXZbX10seD1jLmluZGV4T2YoUCxwKSxhLmFwcGVuZFh0cmEoYy5zdWJzdHIocCx4LXApLE51bWJlcihQKSxpZSh5W19dLFApLFwiXCIsQSYmXCJweFwiPT09Yy5zdWJzdHIoeCtQLmxlbmd0aCwyKSwwPT09XykscD14K1AubGVuZ3RoO2FbXCJ4c1wiK2EubF0rPWMuc3Vic3RyKHApfWVsc2UgYVtcInhzXCIrYS5sXSs9YS5sP1wiIFwiK2M6YztpZigtMSE9PXIuaW5kZXhPZihcIj1cIikmJmEuZGF0YSl7Zm9yKFM9YS54czArYS5kYXRhLnMsZj0xO2EubD5mO2YrKylTKz1hW1wieHNcIitmXSthLmRhdGFbXCJ4blwiK2ZdO2EuZT1TK2FbXCJ4c1wiK2ZdfXJldHVybiBhLmx8fChhLnR5cGU9LTEsYS54czA9YS5lKSxhLnhmaXJzdHx8YX0sY2U9OTtmb3IobD1fZS5wcm90b3R5cGUsbC5sPWwucHI9MDstLWNlPjA7KWxbXCJ4blwiK2NlXT0wLGxbXCJ4c1wiK2NlXT1cIlwiO2wueHMwPVwiXCIsbC5fbmV4dD1sLl9wcmV2PWwueGZpcnN0PWwuZGF0YT1sLnBsdWdpbj1sLnNldFJhdGlvPWwucnhwPW51bGwsbC5hcHBlbmRYdHJhPWZ1bmN0aW9uKHQsZSxpLHIscyxuKXt2YXIgYT10aGlzLG89YS5sO3JldHVybiBhW1wieHNcIitvXSs9biYmbz9cIiBcIit0OnR8fFwiXCIsaXx8MD09PW98fGEucGx1Z2luPyhhLmwrKyxhLnR5cGU9YS5zZXRSYXRpbz8yOjEsYVtcInhzXCIrYS5sXT1yfHxcIlwiLG8+MD8oYS5kYXRhW1wieG5cIitvXT1lK2ksYS5yeHBbXCJ4blwiK29dPXMsYVtcInhuXCIrb109ZSxhLnBsdWdpbnx8KGEueGZpcnN0PW5ldyBfZShhLFwieG5cIitvLGUsaSxhLnhmaXJzdHx8YSwwLGEubixzLGEucHIpLGEueGZpcnN0LnhzMD0wKSxhKTooYS5kYXRhPXtzOmUraX0sYS5yeHA9e30sYS5zPWUsYS5jPWksYS5yPXMsYSkpOihhW1wieHNcIitvXSs9ZSsocnx8XCJcIiksYSl9O3ZhciBkZT1mdW5jdGlvbih0LGUpe2U9ZXx8e30sdGhpcy5wPWUucHJlZml4P1YodCl8fHQ6dCxvW3RdPW9bdGhpcy5wXT10aGlzLHRoaXMuZm9ybWF0PWUuZm9ybWF0dGVyfHxoZShlLmRlZmF1bHRWYWx1ZSxlLmNvbG9yLGUuY29sbGFwc2libGUsZS5tdWx0aSksZS5wYXJzZXImJih0aGlzLnBhcnNlPWUucGFyc2VyKSx0aGlzLmNscnM9ZS5jb2xvcix0aGlzLm11bHRpPWUubXVsdGksdGhpcy5rZXl3b3JkPWUua2V5d29yZCx0aGlzLmRmbHQ9ZS5kZWZhdWx0VmFsdWUsdGhpcy5wcj1lLnByaW9yaXR5fHwwfSxtZT1FLl9yZWdpc3RlckNvbXBsZXhTcGVjaWFsUHJvcD1mdW5jdGlvbih0LGUsaSl7XCJvYmplY3RcIiE9dHlwZW9mIGUmJihlPXtwYXJzZXI6aX0pO3ZhciByLHMsbj10LnNwbGl0KFwiLFwiKSxhPWUuZGVmYXVsdFZhbHVlO2ZvcihpPWl8fFthXSxyPTA7bi5sZW5ndGg+cjtyKyspZS5wcmVmaXg9MD09PXImJmUucHJlZml4LGUuZGVmYXVsdFZhbHVlPWlbcl18fGEscz1uZXcgZGUobltyXSxlKX0sZ2U9ZnVuY3Rpb24odCl7aWYoIW9bdF0pe3ZhciBlPXQuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkrdC5zdWJzdHIoMSkrXCJQbHVnaW5cIjttZSh0LHtwYXJzZXI6ZnVuY3Rpb24odCxpLHIscyxuLGEsbCl7dmFyIGg9KHdpbmRvdy5HcmVlblNvY2tHbG9iYWxzfHx3aW5kb3cpLmNvbS5ncmVlbnNvY2sucGx1Z2luc1tlXTtyZXR1cm4gaD8oaC5fY3NzUmVnaXN0ZXIoKSxvW3JdLnBhcnNlKHQsaSxyLHMsbixhLGwpKTooVShcIkVycm9yOiBcIitlK1wiIGpzIGZpbGUgbm90IGxvYWRlZC5cIiksbil9fSl9fTtsPWRlLnByb3RvdHlwZSxsLnBhcnNlQ29tcGxleD1mdW5jdGlvbih0LGUsaSxyLHMsbil7dmFyIGEsbyxsLGgsdSxmLF89dGhpcy5rZXl3b3JkO2lmKHRoaXMubXVsdGkmJihELnRlc3QoaSl8fEQudGVzdChlKT8obz1lLnJlcGxhY2UoRCxcInxcIikuc3BsaXQoXCJ8XCIpLGw9aS5yZXBsYWNlKEQsXCJ8XCIpLnNwbGl0KFwifFwiKSk6XyYmKG89W2VdLGw9W2ldKSksbCl7Zm9yKGg9bC5sZW5ndGg+by5sZW5ndGg/bC5sZW5ndGg6by5sZW5ndGgsYT0wO2g+YTthKyspZT1vW2FdPW9bYV18fHRoaXMuZGZsdCxpPWxbYV09bFthXXx8dGhpcy5kZmx0LF8mJih1PWUuaW5kZXhPZihfKSxmPWkuaW5kZXhPZihfKSx1IT09ZiYmKGk9LTE9PT1mP2w6byxpW2FdKz1cIiBcIitfKSk7ZT1vLmpvaW4oXCIsIFwiKSxpPWwuam9pbihcIiwgXCIpfXJldHVybiBwZSh0LHRoaXMucCxlLGksdGhpcy5jbHJzLHRoaXMuZGZsdCxyLHRoaXMucHIscyxuKX0sbC5wYXJzZT1mdW5jdGlvbih0LGUsaSxyLG4sYSl7cmV0dXJuIHRoaXMucGFyc2VDb21wbGV4KHQuc3R5bGUsdGhpcy5mb3JtYXQocSh0LHRoaXMucCxzLCExLHRoaXMuZGZsdCkpLHRoaXMuZm9ybWF0KGUpLG4sYSl9LGEucmVnaXN0ZXJTcGVjaWFsUHJvcD1mdW5jdGlvbih0LGUsaSl7bWUodCx7cGFyc2VyOmZ1bmN0aW9uKHQscixzLG4sYSxvKXt2YXIgbD1uZXcgX2UodCxzLDAsMCxhLDIscywhMSxpKTtyZXR1cm4gbC5wbHVnaW49byxsLnNldFJhdGlvPWUodCxyLG4uX3R3ZWVuLHMpLGx9LHByaW9yaXR5Oml9KX07dmFyIHZlPVwic2NhbGVYLHNjYWxlWSxzY2FsZVoseCx5LHosc2tld1gsc2tld1kscm90YXRpb24scm90YXRpb25YLHJvdGF0aW9uWSxwZXJzcGVjdGl2ZVwiLnNwbGl0KFwiLFwiKSx5ZT1WKFwidHJhbnNmb3JtXCIpLFRlPVcrXCJ0cmFuc2Zvcm1cIix3ZT1WKFwidHJhbnNmb3JtT3JpZ2luXCIpLHhlPW51bGwhPT1WKFwicGVyc3BlY3RpdmVcIiksYmU9RS5UcmFuc2Zvcm09ZnVuY3Rpb24oKXt0aGlzLnNrZXdZPTB9LFBlPUUuZ2V0VHJhbnNmb3JtPWZ1bmN0aW9uKHQsZSxpLHIpe2lmKHQuX2dzVHJhbnNmb3JtJiZpJiYhcilyZXR1cm4gdC5fZ3NUcmFuc2Zvcm07dmFyIHMsbixvLGwsaCx1LGYsXyxwLGMsZCxtLGcsdj1pP3QuX2dzVHJhbnNmb3JtfHxuZXcgYmU6bmV3IGJlLHk9MD52LnNjYWxlWCxUPTJlLTUsdz0xZTUseD0xNzkuOTksYj14Kk0sUD14ZT9wYXJzZUZsb2F0KHEodCx3ZSxlLCExLFwiMCAwIDBcIikuc3BsaXQoXCIgXCIpWzJdKXx8di56T3JpZ2lufHwwOjA7Zm9yKHllP3M9cSh0LFRlLGUsITApOnQuY3VycmVudFN0eWxlJiYocz10LmN1cnJlbnRTdHlsZS5maWx0ZXIubWF0Y2goQSkscz1zJiY0PT09cy5sZW5ndGg/W3NbMF0uc3Vic3RyKDQpLE51bWJlcihzWzJdLnN1YnN0cig0KSksTnVtYmVyKHNbMV0uc3Vic3RyKDQpKSxzWzNdLnN1YnN0cig0KSx2Lnh8fDAsdi55fHwwXS5qb2luKFwiLFwiKTpcIlwiKSxuPShzfHxcIlwiKS5tYXRjaCgvKD86XFwtfFxcYilbXFxkXFwtXFwuZV0rXFxiL2dpKXx8W10sbz1uLmxlbmd0aDstLW8+LTE7KWw9TnVtYmVyKG5bb10pLG5bb109KGg9bC0obHw9MCkpPygwfGgqdysoMD5oPy0uNTouNSkpL3crbDpsO2lmKDE2PT09bi5sZW5ndGgpe3ZhciBTPW5bOF0sQz1uWzldLFI9blsxMF0saz1uWzEyXSxPPW5bMTNdLEQ9blsxNF07aWYodi56T3JpZ2luJiYoRD0tdi56T3JpZ2luLGs9UypELW5bMTJdLE89QypELW5bMTNdLEQ9UipEK3Yuek9yaWdpbi1uWzE0XSksIWl8fHJ8fG51bGw9PXYucm90YXRpb25YKXt2YXIgTixYLHosSSxFLEYsWSxCPW5bMF0sVT1uWzFdLFc9blsyXSxqPW5bM10sVj1uWzRdLEg9bls1XSxRPW5bNl0sWj1uWzddLCQ9blsxMV0sRz1NYXRoLmF0YW4yKFEsUiksSz0tYj5HfHxHPmI7di5yb3RhdGlvblg9RypMLEcmJihJPU1hdGguY29zKC1HKSxFPU1hdGguc2luKC1HKSxOPVYqSStTKkUsWD1IKkkrQypFLHo9USpJK1IqRSxTPVYqLUUrUypJLEM9SCotRStDKkksUj1RKi1FK1IqSSwkPVoqLUUrJCpJLFY9TixIPVgsUT16KSxHPU1hdGguYXRhbjIoUyxCKSx2LnJvdGF0aW9uWT1HKkwsRyYmKEY9LWI+R3x8Rz5iLEk9TWF0aC5jb3MoLUcpLEU9TWF0aC5zaW4oLUcpLE49QipJLVMqRSxYPVUqSS1DKkUsej1XKkktUipFLEM9VSpFK0MqSSxSPVcqRStSKkksJD1qKkUrJCpJLEI9TixVPVgsVz16KSxHPU1hdGguYXRhbjIoVSxIKSx2LnJvdGF0aW9uPUcqTCxHJiYoWT0tYj5HfHxHPmIsST1NYXRoLmNvcygtRyksRT1NYXRoLnNpbigtRyksQj1CKkkrVipFLFg9VSpJK0gqRSxIPVUqLUUrSCpJLFE9VyotRStRKkksVT1YKSxZJiZLP3Yucm90YXRpb249di5yb3RhdGlvblg9MDpZJiZGP3Yucm90YXRpb249di5yb3RhdGlvblk9MDpGJiZLJiYodi5yb3RhdGlvblk9di5yb3RhdGlvblg9MCksdi5zY2FsZVg9KDB8TWF0aC5zcXJ0KEIqQitVKlUpKncrLjUpL3csdi5zY2FsZVk9KDB8TWF0aC5zcXJ0KEgqSCtDKkMpKncrLjUpL3csdi5zY2FsZVo9KDB8TWF0aC5zcXJ0KFEqUStSKlIpKncrLjUpL3csdi5za2V3WD0wLHYucGVyc3BlY3RpdmU9JD8xLygwPiQ/LSQ6JCk6MCx2Lng9ayx2Lnk9Tyx2Lno9RH19ZWxzZSBpZighKHhlJiYhciYmbi5sZW5ndGgmJnYueD09PW5bNF0mJnYueT09PW5bNV0mJih2LnJvdGF0aW9uWHx8di5yb3RhdGlvblkpfHx2b2lkIDAhPT12LngmJlwibm9uZVwiPT09cSh0LFwiZGlzcGxheVwiLGUpKSl7dmFyIEo9bi5sZW5ndGg+PTYsdGU9Sj9uWzBdOjEsZWU9blsxXXx8MCxpZT1uWzJdfHwwLHJlPUo/blszXToxO3YueD1uWzRdfHwwLHYueT1uWzVdfHwwLHU9TWF0aC5zcXJ0KHRlKnRlK2VlKmVlKSxmPU1hdGguc3FydChyZSpyZStpZSppZSksXz10ZXx8ZWU/TWF0aC5hdGFuMihlZSx0ZSkqTDp2LnJvdGF0aW9ufHwwLHA9aWV8fHJlP01hdGguYXRhbjIoaWUscmUpKkwrXzp2LnNrZXdYfHwwLGM9dS1NYXRoLmFicyh2LnNjYWxlWHx8MCksZD1mLU1hdGguYWJzKHYuc2NhbGVZfHwwKSxNYXRoLmFicyhwKT45MCYmMjcwPk1hdGguYWJzKHApJiYoeT8odSo9LTEscCs9MD49Xz8xODA6LTE4MCxfKz0wPj1fPzE4MDotMTgwKTooZio9LTEscCs9MD49cD8xODA6LTE4MCkpLG09KF8tdi5yb3RhdGlvbiklMTgwLGc9KHAtdi5za2V3WCklMTgwLCh2b2lkIDA9PT12LnNrZXdYfHxjPlR8fC1UPmN8fGQ+VHx8LVQ+ZHx8bT4teCYmeD5tJiZmYWxzZXxtKnd8fGc+LXgmJng+ZyYmZmFsc2V8Zyp3KSYmKHYuc2NhbGVYPXUsdi5zY2FsZVk9Zix2LnJvdGF0aW9uPV8sdi5za2V3WD1wKSx4ZSYmKHYucm90YXRpb25YPXYucm90YXRpb25ZPXYuej0wLHYucGVyc3BlY3RpdmU9cGFyc2VGbG9hdChhLmRlZmF1bHRUcmFuc2Zvcm1QZXJzcGVjdGl2ZSl8fDAsdi5zY2FsZVo9MSl9di56T3JpZ2luPVA7Zm9yKG8gaW4gdilUPnZbb10mJnZbb10+LVQmJih2W29dPTApO3JldHVybiBpJiYodC5fZ3NUcmFuc2Zvcm09diksdn0sU2U9ZnVuY3Rpb24odCl7dmFyIGUsaSxyPXRoaXMuZGF0YSxzPS1yLnJvdGF0aW9uKk0sbj1zK3Iuc2tld1gqTSxhPTFlNSxvPSgwfE1hdGguY29zKHMpKnIuc2NhbGVYKmEpL2EsbD0oMHxNYXRoLnNpbihzKSpyLnNjYWxlWCphKS9hLGg9KDB8TWF0aC5zaW4obikqLXIuc2NhbGVZKmEpL2EsdT0oMHxNYXRoLmNvcyhuKSpyLnNjYWxlWSphKS9hLGY9dGhpcy50LnN0eWxlLF89dGhpcy50LmN1cnJlbnRTdHlsZTtpZihfKXtpPWwsbD0taCxoPS1pLGU9Xy5maWx0ZXIsZi5maWx0ZXI9XCJcIjt2YXIgcCxkLG09dGhpcy50Lm9mZnNldFdpZHRoLGc9dGhpcy50Lm9mZnNldEhlaWdodCx2PVwiYWJzb2x1dGVcIiE9PV8ucG9zaXRpb24sdz1cInByb2dpZDpEWEltYWdlVHJhbnNmb3JtLk1pY3Jvc29mdC5NYXRyaXgoTTExPVwiK28rXCIsIE0xMj1cIitsK1wiLCBNMjE9XCIraCtcIiwgTTIyPVwiK3UseD1yLngsYj1yLnk7aWYobnVsbCE9ci5veCYmKHA9KHIub3hwPy4wMSptKnIub3g6ci5veCktbS8yLGQ9KHIub3lwPy4wMSpnKnIub3k6ci5veSktZy8yLHgrPXAtKHAqbytkKmwpLGIrPWQtKHAqaCtkKnUpKSx2PyhwPW0vMixkPWcvMix3Kz1cIiwgRHg9XCIrKHAtKHAqbytkKmwpK3gpK1wiLCBEeT1cIisoZC0ocCpoK2QqdSkrYikrXCIpXCIpOncrPVwiLCBzaXppbmdNZXRob2Q9J2F1dG8gZXhwYW5kJylcIixmLmZpbHRlcj0tMSE9PWUuaW5kZXhPZihcIkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0Lk1hdHJpeChcIik/ZS5yZXBsYWNlKE8sdyk6dytcIiBcIitlLCgwPT09dHx8MT09PXQpJiYxPT09byYmMD09PWwmJjA9PT1oJiYxPT09dSYmKHYmJi0xPT09dy5pbmRleE9mKFwiRHg9MCwgRHk9MFwiKXx8VC50ZXN0KGUpJiYxMDAhPT1wYXJzZUZsb2F0KFJlZ0V4cC4kMSl8fC0xPT09ZS5pbmRleE9mKFwiZ3JhZGllbnQoXCImJmUuaW5kZXhPZihcIkFscGhhXCIpKSYmZi5yZW1vdmVBdHRyaWJ1dGUoXCJmaWx0ZXJcIikpLCF2KXt2YXIgUCxTLEMsUj04PmM/MTotMTtmb3IocD1yLmllT2Zmc2V0WHx8MCxkPXIuaWVPZmZzZXRZfHwwLHIuaWVPZmZzZXRYPU1hdGgucm91bmQoKG0tKCgwPm8/LW86bykqbSsoMD5sPy1sOmwpKmcpKS8yK3gpLHIuaWVPZmZzZXRZPU1hdGgucm91bmQoKGctKCgwPnU/LXU6dSkqZysoMD5oPy1oOmgpKm0pKS8yK2IpLGNlPTA7ND5jZTtjZSsrKVM9SltjZV0sUD1fW1NdLGk9LTEhPT1QLmluZGV4T2YoXCJweFwiKT9wYXJzZUZsb2F0KFApOlEodGhpcy50LFMscGFyc2VGbG9hdChQKSxQLnJlcGxhY2UoeSxcIlwiKSl8fDAsQz1pIT09cltTXT8yPmNlPy1yLmllT2Zmc2V0WDotci5pZU9mZnNldFk6Mj5jZT9wLXIuaWVPZmZzZXRYOmQtci5pZU9mZnNldFksZltTXT0ocltTXT1NYXRoLnJvdW5kKGktQyooMD09PWNlfHwyPT09Y2U/MTpSKSkpK1wicHhcIn19fSxDZT1FLnNldDNEVHJhbnNmb3JtUmF0aW89ZnVuY3Rpb24odCl7dmFyIGUsaSxyLHMsbixhLG8sbCxoLHUsZixwLGMsZCxtLGcsdix5LFQsdyx4LGIsUCxTPXRoaXMuZGF0YSxDPXRoaXMudC5zdHlsZSxSPVMucm90YXRpb24qTSxrPVMuc2NhbGVYLEE9Uy5zY2FsZVksTz1TLnNjYWxlWixEPVMucGVyc3BlY3RpdmU7aWYoISgxIT09dCYmMCE9PXR8fFwiYXV0b1wiIT09Uy5mb3JjZTNEfHxTLnJvdGF0aW9uWXx8Uy5yb3RhdGlvblh8fDEhPT1PfHxEfHxTLnopKXJldHVybiBSZS5jYWxsKHRoaXMsdCksdm9pZCAwO2lmKF8pe3ZhciBMPTFlLTQ7TD5rJiZrPi1MJiYoaz1PPTJlLTUpLEw+QSYmQT4tTCYmKEE9Tz0yZS01KSwhRHx8Uy56fHxTLnJvdGF0aW9uWHx8Uy5yb3RhdGlvbll8fChEPTApfWlmKFJ8fFMuc2tld1gpeT1NYXRoLmNvcyhSKSxUPU1hdGguc2luKFIpLGU9eSxuPVQsUy5za2V3WCYmKFItPVMuc2tld1gqTSx5PU1hdGguY29zKFIpLFQ9TWF0aC5zaW4oUiksXCJzaW1wbGVcIj09PVMuc2tld1R5cGUmJih3PU1hdGgudGFuKFMuc2tld1gqTSksdz1NYXRoLnNxcnQoMSt3KncpLHkqPXcsVCo9dykpLGk9LVQsYT15O2Vsc2V7aWYoIShTLnJvdGF0aW9uWXx8Uy5yb3RhdGlvblh8fDEhPT1PfHxEKSlyZXR1cm4gQ1t5ZV09XCJ0cmFuc2xhdGUzZChcIitTLngrXCJweCxcIitTLnkrXCJweCxcIitTLnorXCJweClcIisoMSE9PWt8fDEhPT1BP1wiIHNjYWxlKFwiK2srXCIsXCIrQStcIilcIjpcIlwiKSx2b2lkIDA7ZT1hPTEsaT1uPTB9Zj0xLHI9cz1vPWw9aD11PXA9Yz1kPTAsbT1EPy0xL0Q6MCxnPVMuek9yaWdpbix2PTFlNSxSPVMucm90YXRpb25ZKk0sUiYmKHk9TWF0aC5jb3MoUiksVD1NYXRoLnNpbihSKSxoPWYqLVQsYz1tKi1ULHI9ZSpULG89bipULGYqPXksbSo9eSxlKj15LG4qPXkpLFI9Uy5yb3RhdGlvblgqTSxSJiYoeT1NYXRoLmNvcyhSKSxUPU1hdGguc2luKFIpLHc9aSp5K3IqVCx4PWEqeStvKlQsYj11KnkrZipULFA9ZCp5K20qVCxyPWkqLVQrcip5LG89YSotVCtvKnksZj11Ki1UK2YqeSxtPWQqLVQrbSp5LGk9dyxhPXgsdT1iLGQ9UCksMSE9PU8mJihyKj1PLG8qPU8sZio9TyxtKj1PKSwxIT09QSYmKGkqPUEsYSo9QSx1Kj1BLGQqPUEpLDEhPT1rJiYoZSo9ayxuKj1rLGgqPWssYyo9ayksZyYmKHAtPWcscz1yKnAsbD1vKnAscD1mKnArZykscz0odz0ocys9Uy54KS0oc3w9MCkpPygwfHcqdisoMD53Py0uNTouNSkpL3YrczpzLGw9KHc9KGwrPVMueSktKGx8PTApKT8oMHx3KnYrKDA+dz8tLjU6LjUpKS92K2w6bCxwPSh3PShwKz1TLnopLShwfD0wKSk/KDB8dyp2KygwPnc/LS41Oi41KSkvditwOnAsQ1t5ZV09XCJtYXRyaXgzZChcIitbKDB8ZSp2KS92LCgwfG4qdikvdiwoMHxoKnYpL3YsKDB8Yyp2KS92LCgwfGkqdikvdiwoMHxhKnYpL3YsKDB8dSp2KS92LCgwfGQqdikvdiwoMHxyKnYpL3YsKDB8byp2KS92LCgwfGYqdikvdiwoMHxtKnYpL3YscyxsLHAsRD8xKy1wL0Q6MV0uam9pbihcIixcIikrXCIpXCJ9LFJlPUUuc2V0MkRUcmFuc2Zvcm1SYXRpbz1mdW5jdGlvbih0KXt2YXIgZSxpLHIscyxuLGE9dGhpcy5kYXRhLG89dGhpcy50LGw9by5zdHlsZTtyZXR1cm4gYS5yb3RhdGlvblh8fGEucm90YXRpb25ZfHxhLnp8fGEuZm9yY2UzRD09PSEwfHxcImF1dG9cIj09PWEuZm9yY2UzRCYmMSE9PXQmJjAhPT10Pyh0aGlzLnNldFJhdGlvPUNlLENlLmNhbGwodGhpcyx0KSx2b2lkIDApOihhLnJvdGF0aW9ufHxhLnNrZXdYPyhlPWEucm90YXRpb24qTSxpPWUtYS5za2V3WCpNLHI9MWU1LHM9YS5zY2FsZVgqcixuPWEuc2NhbGVZKnIsbFt5ZV09XCJtYXRyaXgoXCIrKDB8TWF0aC5jb3MoZSkqcykvcitcIixcIisoMHxNYXRoLnNpbihlKSpzKS9yK1wiLFwiKygwfE1hdGguc2luKGkpKi1uKS9yK1wiLFwiKygwfE1hdGguY29zKGkpKm4pL3IrXCIsXCIrYS54K1wiLFwiK2EueStcIilcIik6bFt5ZV09XCJtYXRyaXgoXCIrYS5zY2FsZVgrXCIsMCwwLFwiK2Euc2NhbGVZK1wiLFwiK2EueCtcIixcIithLnkrXCIpXCIsdm9pZCAwKX07bWUoXCJ0cmFuc2Zvcm0sc2NhbGUsc2NhbGVYLHNjYWxlWSxzY2FsZVoseCx5LHoscm90YXRpb24scm90YXRpb25YLHJvdGF0aW9uWSxyb3RhdGlvblosc2tld1gsc2tld1ksc2hvcnRSb3RhdGlvbixzaG9ydFJvdGF0aW9uWCxzaG9ydFJvdGF0aW9uWSxzaG9ydFJvdGF0aW9uWix0cmFuc2Zvcm1PcmlnaW4sdHJhbnNmb3JtUGVyc3BlY3RpdmUsZGlyZWN0aW9uYWxSb3RhdGlvbixwYXJzZVRyYW5zZm9ybSxmb3JjZTNELHNrZXdUeXBlXCIse3BhcnNlcjpmdW5jdGlvbih0LGUsaSxyLG4sbyxsKXtpZihyLl90cmFuc2Zvcm0pcmV0dXJuIG47dmFyIGgsdSxmLF8scCxjLGQsbT1yLl90cmFuc2Zvcm09UGUodCxzLCEwLGwucGFyc2VUcmFuc2Zvcm0pLGc9dC5zdHlsZSx2PTFlLTYseT12ZS5sZW5ndGgsVD1sLHc9e307aWYoXCJzdHJpbmdcIj09dHlwZW9mIFQudHJhbnNmb3JtJiZ5ZSlmPXouc3R5bGUsZlt5ZV09VC50cmFuc2Zvcm0sZi5kaXNwbGF5PVwiYmxvY2tcIixmLnBvc2l0aW9uPVwiYWJzb2x1dGVcIixYLmJvZHkuYXBwZW5kQ2hpbGQoeiksaD1QZSh6LG51bGwsITEpLFguYm9keS5yZW1vdmVDaGlsZCh6KTtlbHNlIGlmKFwib2JqZWN0XCI9PXR5cGVvZiBUKXtpZihoPXtzY2FsZVg6cmUobnVsbCE9VC5zY2FsZVg/VC5zY2FsZVg6VC5zY2FsZSxtLnNjYWxlWCksc2NhbGVZOnJlKG51bGwhPVQuc2NhbGVZP1Quc2NhbGVZOlQuc2NhbGUsbS5zY2FsZVkpLHNjYWxlWjpyZShULnNjYWxlWixtLnNjYWxlWikseDpyZShULngsbS54KSx5OnJlKFQueSxtLnkpLHo6cmUoVC56LG0ueikscGVyc3BlY3RpdmU6cmUoVC50cmFuc2Zvcm1QZXJzcGVjdGl2ZSxtLnBlcnNwZWN0aXZlKX0sZD1ULmRpcmVjdGlvbmFsUm90YXRpb24sbnVsbCE9ZClpZihcIm9iamVjdFwiPT10eXBlb2YgZClmb3IoZiBpbiBkKVRbZl09ZFtmXTtlbHNlIFQucm90YXRpb249ZDtoLnJvdGF0aW9uPXNlKFwicm90YXRpb25cImluIFQ/VC5yb3RhdGlvbjpcInNob3J0Um90YXRpb25cImluIFQ/VC5zaG9ydFJvdGF0aW9uK1wiX3Nob3J0XCI6XCJyb3RhdGlvblpcImluIFQ/VC5yb3RhdGlvblo6bS5yb3RhdGlvbixtLnJvdGF0aW9uLFwicm90YXRpb25cIix3KSx4ZSYmKGgucm90YXRpb25YPXNlKFwicm90YXRpb25YXCJpbiBUP1Qucm90YXRpb25YOlwic2hvcnRSb3RhdGlvblhcImluIFQ/VC5zaG9ydFJvdGF0aW9uWCtcIl9zaG9ydFwiOm0ucm90YXRpb25YfHwwLG0ucm90YXRpb25YLFwicm90YXRpb25YXCIsdyksaC5yb3RhdGlvblk9c2UoXCJyb3RhdGlvbllcImluIFQ/VC5yb3RhdGlvblk6XCJzaG9ydFJvdGF0aW9uWVwiaW4gVD9ULnNob3J0Um90YXRpb25ZK1wiX3Nob3J0XCI6bS5yb3RhdGlvbll8fDAsbS5yb3RhdGlvblksXCJyb3RhdGlvbllcIix3KSksaC5za2V3WD1udWxsPT1ULnNrZXdYP20uc2tld1g6c2UoVC5za2V3WCxtLnNrZXdYKSxoLnNrZXdZPW51bGw9PVQuc2tld1k/bS5za2V3WTpzZShULnNrZXdZLG0uc2tld1kpLCh1PWguc2tld1ktbS5za2V3WSkmJihoLnNrZXdYKz11LGgucm90YXRpb24rPXUpfWZvcih4ZSYmbnVsbCE9VC5mb3JjZTNEJiYobS5mb3JjZTNEPVQuZm9yY2UzRCxjPSEwKSxtLnNrZXdUeXBlPVQuc2tld1R5cGV8fG0uc2tld1R5cGV8fGEuZGVmYXVsdFNrZXdUeXBlLHA9bS5mb3JjZTNEfHxtLnp8fG0ucm90YXRpb25YfHxtLnJvdGF0aW9uWXx8aC56fHxoLnJvdGF0aW9uWHx8aC5yb3RhdGlvbll8fGgucGVyc3BlY3RpdmUscHx8bnVsbD09VC5zY2FsZXx8KGguc2NhbGVaPTEpOy0teT4tMTspaT12ZVt5XSxfPWhbaV0tbVtpXSwoXz52fHwtdj5ffHxudWxsIT1OW2ldKSYmKGM9ITAsbj1uZXcgX2UobSxpLG1baV0sXyxuKSxpIGluIHcmJihuLmU9d1tpXSksbi54czA9MCxuLnBsdWdpbj1vLHIuX292ZXJ3cml0ZVByb3BzLnB1c2gobi5uKSk7cmV0dXJuIF89VC50cmFuc2Zvcm1PcmlnaW4sKF98fHhlJiZwJiZtLnpPcmlnaW4pJiYoeWU/KGM9ITAsaT13ZSxfPShffHxxKHQsaSxzLCExLFwiNTAlIDUwJVwiKSkrXCJcIixuPW5ldyBfZShnLGksMCwwLG4sLTEsXCJ0cmFuc2Zvcm1PcmlnaW5cIiksbi5iPWdbaV0sbi5wbHVnaW49byx4ZT8oZj1tLnpPcmlnaW4sXz1fLnNwbGl0KFwiIFwiKSxtLnpPcmlnaW49KF8ubGVuZ3RoPjImJigwPT09Znx8XCIwcHhcIiE9PV9bMl0pP3BhcnNlRmxvYXQoX1syXSk6Zil8fDAsbi54czA9bi5lPV9bMF0rXCIgXCIrKF9bMV18fFwiNTAlXCIpK1wiIDBweFwiLG49bmV3IF9lKG0sXCJ6T3JpZ2luXCIsMCwwLG4sLTEsbi5uKSxuLmI9ZixuLnhzMD1uLmU9bS56T3JpZ2luKTpuLnhzMD1uLmU9Xyk6ZWUoXytcIlwiLG0pKSxjJiYoci5fdHJhbnNmb3JtVHlwZT1wfHwzPT09dGhpcy5fdHJhbnNmb3JtVHlwZT8zOjIpLG59LHByZWZpeDohMH0pLG1lKFwiYm94U2hhZG93XCIse2RlZmF1bHRWYWx1ZTpcIjBweCAwcHggMHB4IDBweCAjOTk5XCIscHJlZml4OiEwLGNvbG9yOiEwLG11bHRpOiEwLGtleXdvcmQ6XCJpbnNldFwifSksbWUoXCJib3JkZXJSYWRpdXNcIix7ZGVmYXVsdFZhbHVlOlwiMHB4XCIscGFyc2VyOmZ1bmN0aW9uKHQsZSxpLG4sYSl7ZT10aGlzLmZvcm1hdChlKTt2YXIgbyxsLGgsdSxmLF8scCxjLGQsbSxnLHYseSxULHcseCxiPVtcImJvcmRlclRvcExlZnRSYWRpdXNcIixcImJvcmRlclRvcFJpZ2h0UmFkaXVzXCIsXCJib3JkZXJCb3R0b21SaWdodFJhZGl1c1wiLFwiYm9yZGVyQm90dG9tTGVmdFJhZGl1c1wiXSxQPXQuc3R5bGU7Zm9yKGQ9cGFyc2VGbG9hdCh0Lm9mZnNldFdpZHRoKSxtPXBhcnNlRmxvYXQodC5vZmZzZXRIZWlnaHQpLG89ZS5zcGxpdChcIiBcIiksbD0wO2IubGVuZ3RoPmw7bCsrKXRoaXMucC5pbmRleE9mKFwiYm9yZGVyXCIpJiYoYltsXT1WKGJbbF0pKSxmPXU9cSh0LGJbbF0scywhMSxcIjBweFwiKSwtMSE9PWYuaW5kZXhPZihcIiBcIikmJih1PWYuc3BsaXQoXCIgXCIpLGY9dVswXSx1PXVbMV0pLF89aD1vW2xdLHA9cGFyc2VGbG9hdChmKSx2PWYuc3Vic3RyKChwK1wiXCIpLmxlbmd0aCkseT1cIj1cIj09PV8uY2hhckF0KDEpLHk/KGM9cGFyc2VJbnQoXy5jaGFyQXQoMCkrXCIxXCIsMTApLF89Xy5zdWJzdHIoMiksYyo9cGFyc2VGbG9hdChfKSxnPV8uc3Vic3RyKChjK1wiXCIpLmxlbmd0aC0oMD5jPzE6MCkpfHxcIlwiKTooYz1wYXJzZUZsb2F0KF8pLGc9Xy5zdWJzdHIoKGMrXCJcIikubGVuZ3RoKSksXCJcIj09PWcmJihnPXJbaV18fHYpLGchPT12JiYoVD1RKHQsXCJib3JkZXJMZWZ0XCIscCx2KSx3PVEodCxcImJvcmRlclRvcFwiLHAsdiksXCIlXCI9PT1nPyhmPTEwMCooVC9kKStcIiVcIix1PTEwMCoody9tKStcIiVcIik6XCJlbVwiPT09Zz8oeD1RKHQsXCJib3JkZXJMZWZ0XCIsMSxcImVtXCIpLGY9VC94K1wiZW1cIix1PXcveCtcImVtXCIpOihmPVQrXCJweFwiLHU9dytcInB4XCIpLHkmJihfPXBhcnNlRmxvYXQoZikrYytnLGg9cGFyc2VGbG9hdCh1KStjK2cpKSxhPXBlKFAsYltsXSxmK1wiIFwiK3UsXytcIiBcIitoLCExLFwiMHB4XCIsYSk7cmV0dXJuIGF9LHByZWZpeDohMCxmb3JtYXR0ZXI6aGUoXCIwcHggMHB4IDBweCAwcHhcIiwhMSwhMCl9KSxtZShcImJhY2tncm91bmRQb3NpdGlvblwiLHtkZWZhdWx0VmFsdWU6XCIwIDBcIixwYXJzZXI6ZnVuY3Rpb24odCxlLGkscixuLGEpe3ZhciBvLGwsaCx1LGYsXyxwPVwiYmFja2dyb3VuZC1wb3NpdGlvblwiLGQ9c3x8SCh0LG51bGwpLG09dGhpcy5mb3JtYXQoKGQ/Yz9kLmdldFByb3BlcnR5VmFsdWUocCtcIi14XCIpK1wiIFwiK2QuZ2V0UHJvcGVydHlWYWx1ZShwK1wiLXlcIik6ZC5nZXRQcm9wZXJ0eVZhbHVlKHApOnQuY3VycmVudFN0eWxlLmJhY2tncm91bmRQb3NpdGlvblgrXCIgXCIrdC5jdXJyZW50U3R5bGUuYmFja2dyb3VuZFBvc2l0aW9uWSl8fFwiMCAwXCIpLGc9dGhpcy5mb3JtYXQoZSk7aWYoLTEhPT1tLmluZGV4T2YoXCIlXCIpIT0oLTEhPT1nLmluZGV4T2YoXCIlXCIpKSYmKF89cSh0LFwiYmFja2dyb3VuZEltYWdlXCIpLnJlcGxhY2UoQyxcIlwiKSxfJiZcIm5vbmVcIiE9PV8pKXtmb3Iobz1tLnNwbGl0KFwiIFwiKSxsPWcuc3BsaXQoXCIgXCIpLEkuc2V0QXR0cmlidXRlKFwic3JjXCIsXyksaD0yOy0taD4tMTspbT1vW2hdLHU9LTEhPT1tLmluZGV4T2YoXCIlXCIpLHUhPT0oLTEhPT1sW2hdLmluZGV4T2YoXCIlXCIpKSYmKGY9MD09PWg/dC5vZmZzZXRXaWR0aC1JLndpZHRoOnQub2Zmc2V0SGVpZ2h0LUkuaGVpZ2h0LG9baF09dT9wYXJzZUZsb2F0KG0pLzEwMCpmK1wicHhcIjoxMDAqKHBhcnNlRmxvYXQobSkvZikrXCIlXCIpO209by5qb2luKFwiIFwiKX1yZXR1cm4gdGhpcy5wYXJzZUNvbXBsZXgodC5zdHlsZSxtLGcsbixhKX0sZm9ybWF0dGVyOmVlfSksbWUoXCJiYWNrZ3JvdW5kU2l6ZVwiLHtkZWZhdWx0VmFsdWU6XCIwIDBcIixmb3JtYXR0ZXI6ZWV9KSxtZShcInBlcnNwZWN0aXZlXCIse2RlZmF1bHRWYWx1ZTpcIjBweFwiLHByZWZpeDohMH0pLG1lKFwicGVyc3BlY3RpdmVPcmlnaW5cIix7ZGVmYXVsdFZhbHVlOlwiNTAlIDUwJVwiLHByZWZpeDohMH0pLG1lKFwidHJhbnNmb3JtU3R5bGVcIix7cHJlZml4OiEwfSksbWUoXCJiYWNrZmFjZVZpc2liaWxpdHlcIix7cHJlZml4OiEwfSksbWUoXCJ1c2VyU2VsZWN0XCIse3ByZWZpeDohMH0pLG1lKFwibWFyZ2luXCIse3BhcnNlcjp1ZShcIm1hcmdpblRvcCxtYXJnaW5SaWdodCxtYXJnaW5Cb3R0b20sbWFyZ2luTGVmdFwiKX0pLG1lKFwicGFkZGluZ1wiLHtwYXJzZXI6dWUoXCJwYWRkaW5nVG9wLHBhZGRpbmdSaWdodCxwYWRkaW5nQm90dG9tLHBhZGRpbmdMZWZ0XCIpfSksbWUoXCJjbGlwXCIse2RlZmF1bHRWYWx1ZTpcInJlY3QoMHB4LDBweCwwcHgsMHB4KVwiLHBhcnNlcjpmdW5jdGlvbih0LGUsaSxyLG4sYSl7dmFyIG8sbCxoO3JldHVybiA5PmM/KGw9dC5jdXJyZW50U3R5bGUsaD04PmM/XCIgXCI6XCIsXCIsbz1cInJlY3QoXCIrbC5jbGlwVG9wK2grbC5jbGlwUmlnaHQraCtsLmNsaXBCb3R0b20raCtsLmNsaXBMZWZ0K1wiKVwiLGU9dGhpcy5mb3JtYXQoZSkuc3BsaXQoXCIsXCIpLmpvaW4oaCkpOihvPXRoaXMuZm9ybWF0KHEodCx0aGlzLnAscywhMSx0aGlzLmRmbHQpKSxlPXRoaXMuZm9ybWF0KGUpKSx0aGlzLnBhcnNlQ29tcGxleCh0LnN0eWxlLG8sZSxuLGEpfX0pLG1lKFwidGV4dFNoYWRvd1wiLHtkZWZhdWx0VmFsdWU6XCIwcHggMHB4IDBweCAjOTk5XCIsY29sb3I6ITAsbXVsdGk6ITB9KSxtZShcImF1dG9Sb3VuZCxzdHJpY3RVbml0c1wiLHtwYXJzZXI6ZnVuY3Rpb24odCxlLGkscixzKXtyZXR1cm4gc319KSxtZShcImJvcmRlclwiLHtkZWZhdWx0VmFsdWU6XCIwcHggc29saWQgIzAwMFwiLHBhcnNlcjpmdW5jdGlvbih0LGUsaSxyLG4sYSl7cmV0dXJuIHRoaXMucGFyc2VDb21wbGV4KHQuc3R5bGUsdGhpcy5mb3JtYXQocSh0LFwiYm9yZGVyVG9wV2lkdGhcIixzLCExLFwiMHB4XCIpK1wiIFwiK3EodCxcImJvcmRlclRvcFN0eWxlXCIscywhMSxcInNvbGlkXCIpK1wiIFwiK3EodCxcImJvcmRlclRvcENvbG9yXCIscywhMSxcIiMwMDBcIikpLHRoaXMuZm9ybWF0KGUpLG4sYSl9LGNvbG9yOiEwLGZvcm1hdHRlcjpmdW5jdGlvbih0KXt2YXIgZT10LnNwbGl0KFwiIFwiKTtyZXR1cm4gZVswXStcIiBcIisoZVsxXXx8XCJzb2xpZFwiKStcIiBcIisodC5tYXRjaChsZSl8fFtcIiMwMDBcIl0pWzBdfX0pLG1lKFwiYm9yZGVyV2lkdGhcIix7cGFyc2VyOnVlKFwiYm9yZGVyVG9wV2lkdGgsYm9yZGVyUmlnaHRXaWR0aCxib3JkZXJCb3R0b21XaWR0aCxib3JkZXJMZWZ0V2lkdGhcIil9KSxtZShcImZsb2F0LGNzc0Zsb2F0LHN0eWxlRmxvYXRcIix7cGFyc2VyOmZ1bmN0aW9uKHQsZSxpLHIscyl7dmFyIG49dC5zdHlsZSxhPVwiY3NzRmxvYXRcImluIG4/XCJjc3NGbG9hdFwiOlwic3R5bGVGbG9hdFwiO3JldHVybiBuZXcgX2UobixhLDAsMCxzLC0xLGksITEsMCxuW2FdLGUpfX0pO3ZhciBrZT1mdW5jdGlvbih0KXt2YXIgZSxpPXRoaXMudCxyPWkuZmlsdGVyfHxxKHRoaXMuZGF0YSxcImZpbHRlclwiKSxzPTB8dGhpcy5zK3RoaXMuYyp0OzEwMD09PXMmJigtMT09PXIuaW5kZXhPZihcImF0cml4KFwiKSYmLTE9PT1yLmluZGV4T2YoXCJyYWRpZW50KFwiKSYmLTE9PT1yLmluZGV4T2YoXCJvYWRlcihcIik/KGkucmVtb3ZlQXR0cmlidXRlKFwiZmlsdGVyXCIpLGU9IXEodGhpcy5kYXRhLFwiZmlsdGVyXCIpKTooaS5maWx0ZXI9ci5yZXBsYWNlKHgsXCJcIiksZT0hMCkpLGV8fCh0aGlzLnhuMSYmKGkuZmlsdGVyPXI9cnx8XCJhbHBoYShvcGFjaXR5PVwiK3MrXCIpXCIpLC0xPT09ci5pbmRleE9mKFwicGFjaXR5XCIpPzA9PT1zJiZ0aGlzLnhuMXx8KGkuZmlsdGVyPXIrXCIgYWxwaGEob3BhY2l0eT1cIitzK1wiKVwiKTppLmZpbHRlcj1yLnJlcGxhY2UoVCxcIm9wYWNpdHk9XCIrcykpfTttZShcIm9wYWNpdHksYWxwaGEsYXV0b0FscGhhXCIse2RlZmF1bHRWYWx1ZTpcIjFcIixwYXJzZXI6ZnVuY3Rpb24odCxlLGkscixuLGEpe3ZhciBvPXBhcnNlRmxvYXQocSh0LFwib3BhY2l0eVwiLHMsITEsXCIxXCIpKSxsPXQuc3R5bGUsaD1cImF1dG9BbHBoYVwiPT09aTtyZXR1cm5cInN0cmluZ1wiPT10eXBlb2YgZSYmXCI9XCI9PT1lLmNoYXJBdCgxKSYmKGU9KFwiLVwiPT09ZS5jaGFyQXQoMCk/LTE6MSkqcGFyc2VGbG9hdChlLnN1YnN0cigyKSkrbyksaCYmMT09PW8mJlwiaGlkZGVuXCI9PT1xKHQsXCJ2aXNpYmlsaXR5XCIscykmJjAhPT1lJiYobz0wKSxZP249bmV3IF9lKGwsXCJvcGFjaXR5XCIsbyxlLW8sbik6KG49bmV3IF9lKGwsXCJvcGFjaXR5XCIsMTAwKm8sMTAwKihlLW8pLG4pLG4ueG4xPWg/MTowLGwuem9vbT0xLG4udHlwZT0yLG4uYj1cImFscGhhKG9wYWNpdHk9XCIrbi5zK1wiKVwiLG4uZT1cImFscGhhKG9wYWNpdHk9XCIrKG4ucytuLmMpK1wiKVwiLG4uZGF0YT10LG4ucGx1Z2luPWEsbi5zZXRSYXRpbz1rZSksaCYmKG49bmV3IF9lKGwsXCJ2aXNpYmlsaXR5XCIsMCwwLG4sLTEsbnVsbCwhMSwwLDAhPT1vP1wiaW5oZXJpdFwiOlwiaGlkZGVuXCIsMD09PWU/XCJoaWRkZW5cIjpcImluaGVyaXRcIiksbi54czA9XCJpbmhlcml0XCIsci5fb3ZlcndyaXRlUHJvcHMucHVzaChuLm4pLHIuX292ZXJ3cml0ZVByb3BzLnB1c2goaSkpLG59fSk7dmFyIEFlPWZ1bmN0aW9uKHQsZSl7ZSYmKHQucmVtb3ZlUHJvcGVydHk/KFwibXNcIj09PWUuc3Vic3RyKDAsMikmJihlPVwiTVwiK2Uuc3Vic3RyKDEpKSx0LnJlbW92ZVByb3BlcnR5KGUucmVwbGFjZShQLFwiLSQxXCIpLnRvTG93ZXJDYXNlKCkpKTp0LnJlbW92ZUF0dHJpYnV0ZShlKSl9LE9lPWZ1bmN0aW9uKHQpe2lmKHRoaXMudC5fZ3NDbGFzc1BUPXRoaXMsMT09PXR8fDA9PT10KXt0aGlzLnQuc2V0QXR0cmlidXRlKFwiY2xhc3NcIiwwPT09dD90aGlzLmI6dGhpcy5lKTtmb3IodmFyIGU9dGhpcy5kYXRhLGk9dGhpcy50LnN0eWxlO2U7KWUudj9pW2UucF09ZS52OkFlKGksZS5wKSxlPWUuX25leHQ7MT09PXQmJnRoaXMudC5fZ3NDbGFzc1BUPT09dGhpcyYmKHRoaXMudC5fZ3NDbGFzc1BUPW51bGwpfWVsc2UgdGhpcy50LmdldEF0dHJpYnV0ZShcImNsYXNzXCIpIT09dGhpcy5lJiZ0aGlzLnQuc2V0QXR0cmlidXRlKFwiY2xhc3NcIix0aGlzLmUpfTttZShcImNsYXNzTmFtZVwiLHtwYXJzZXI6ZnVuY3Rpb24odCxlLHIsbixhLG8sbCl7dmFyIGgsdSxmLF8scCxjPXQuZ2V0QXR0cmlidXRlKFwiY2xhc3NcIil8fFwiXCIsZD10LnN0eWxlLmNzc1RleHQ7aWYoYT1uLl9jbGFzc05hbWVQVD1uZXcgX2UodCxyLDAsMCxhLDIpLGEuc2V0UmF0aW89T2UsYS5wcj0tMTEsaT0hMCxhLmI9Yyx1PSQodCxzKSxmPXQuX2dzQ2xhc3NQVCl7Zm9yKF89e30scD1mLmRhdGE7cDspX1twLnBdPTEscD1wLl9uZXh0O2Yuc2V0UmF0aW8oMSl9cmV0dXJuIHQuX2dzQ2xhc3NQVD1hLGEuZT1cIj1cIiE9PWUuY2hhckF0KDEpP2U6Yy5yZXBsYWNlKFJlZ0V4cChcIlxcXFxzKlxcXFxiXCIrZS5zdWJzdHIoMikrXCJcXFxcYlwiKSxcIlwiKSsoXCIrXCI9PT1lLmNoYXJBdCgwKT9cIiBcIitlLnN1YnN0cigyKTpcIlwiKSxuLl90d2Vlbi5fZHVyYXRpb24mJih0LnNldEF0dHJpYnV0ZShcImNsYXNzXCIsYS5lKSxoPUcodCx1LCQodCksbCxfKSx0LnNldEF0dHJpYnV0ZShcImNsYXNzXCIsYyksYS5kYXRhPWguZmlyc3RNUFQsdC5zdHlsZS5jc3NUZXh0PWQsYT1hLnhmaXJzdD1uLnBhcnNlKHQsaC5kaWZzLGEsbykpLGF9fSk7dmFyIERlPWZ1bmN0aW9uKHQpe2lmKCgxPT09dHx8MD09PXQpJiZ0aGlzLmRhdGEuX3RvdGFsVGltZT09PXRoaXMuZGF0YS5fdG90YWxEdXJhdGlvbiYmXCJpc0Zyb21TdGFydFwiIT09dGhpcy5kYXRhLmRhdGEpe3ZhciBlLGkscixzLG49dGhpcy50LnN0eWxlLGE9by50cmFuc2Zvcm0ucGFyc2U7aWYoXCJhbGxcIj09PXRoaXMuZSluLmNzc1RleHQ9XCJcIixzPSEwO2Vsc2UgZm9yKGU9dGhpcy5lLnNwbGl0KFwiLFwiKSxyPWUubGVuZ3RoOy0tcj4tMTspaT1lW3JdLG9baV0mJihvW2ldLnBhcnNlPT09YT9zPSEwOmk9XCJ0cmFuc2Zvcm1PcmlnaW5cIj09PWk/d2U6b1tpXS5wKSxBZShuLGkpO3MmJihBZShuLHllKSx0aGlzLnQuX2dzVHJhbnNmb3JtJiZkZWxldGUgdGhpcy50Ll9nc1RyYW5zZm9ybSl9fTtmb3IobWUoXCJjbGVhclByb3BzXCIse3BhcnNlcjpmdW5jdGlvbih0LGUscixzLG4pe3JldHVybiBuPW5ldyBfZSh0LHIsMCwwLG4sMiksbi5zZXRSYXRpbz1EZSxuLmU9ZSxuLnByPS0xMCxuLmRhdGE9cy5fdHdlZW4saT0hMCxufX0pLGw9XCJiZXppZXIsdGhyb3dQcm9wcyxwaHlzaWNzUHJvcHMscGh5c2ljczJEXCIuc3BsaXQoXCIsXCIpLGNlPWwubGVuZ3RoO2NlLS07KWdlKGxbY2VdKTtsPWEucHJvdG90eXBlLGwuX2ZpcnN0UFQ9bnVsbCxsLl9vbkluaXRUd2Vlbj1mdW5jdGlvbih0LGUsbyl7aWYoIXQubm9kZVR5cGUpcmV0dXJuITE7dGhpcy5fdGFyZ2V0PXQsdGhpcy5fdHdlZW49byx0aGlzLl92YXJzPWUsaD1lLmF1dG9Sb3VuZCxpPSExLHI9ZS5zdWZmaXhNYXB8fGEuc3VmZml4TWFwLHM9SCh0LFwiXCIpLG49dGhpcy5fb3ZlcndyaXRlUHJvcHM7dmFyIGwsXyxjLGQsbSxnLHYseSxULHg9dC5zdHlsZTtpZih1JiZcIlwiPT09eC56SW5kZXgmJihsPXEodCxcInpJbmRleFwiLHMpLChcImF1dG9cIj09PWx8fFwiXCI9PT1sKSYmdGhpcy5fYWRkTGF6eVNldCh4LFwiekluZGV4XCIsMCkpLFwic3RyaW5nXCI9PXR5cGVvZiBlJiYoZD14LmNzc1RleHQsbD0kKHQscykseC5jc3NUZXh0PWQrXCI7XCIrZSxsPUcodCxsLCQodCkpLmRpZnMsIVkmJncudGVzdChlKSYmKGwub3BhY2l0eT1wYXJzZUZsb2F0KFJlZ0V4cC4kMSkpLGU9bCx4LmNzc1RleHQ9ZCksdGhpcy5fZmlyc3RQVD1fPXRoaXMucGFyc2UodCxlLG51bGwpLHRoaXMuX3RyYW5zZm9ybVR5cGUpe2ZvcihUPTM9PT10aGlzLl90cmFuc2Zvcm1UeXBlLHllP2YmJih1PSEwLFwiXCI9PT14LnpJbmRleCYmKHY9cSh0LFwiekluZGV4XCIscyksKFwiYXV0b1wiPT09dnx8XCJcIj09PXYpJiZ0aGlzLl9hZGRMYXp5U2V0KHgsXCJ6SW5kZXhcIiwwKSkscCYmdGhpcy5fYWRkTGF6eVNldCh4LFwiV2Via2l0QmFja2ZhY2VWaXNpYmlsaXR5XCIsdGhpcy5fdmFycy5XZWJraXRCYWNrZmFjZVZpc2liaWxpdHl8fChUP1widmlzaWJsZVwiOlwiaGlkZGVuXCIpKSk6eC56b29tPTEsYz1fO2MmJmMuX25leHQ7KWM9Yy5fbmV4dDt5PW5ldyBfZSh0LFwidHJhbnNmb3JtXCIsMCwwLG51bGwsMiksdGhpcy5fbGlua0NTU1AoeSxudWxsLGMpLHkuc2V0UmF0aW89VCYmeGU/Q2U6eWU/UmU6U2UseS5kYXRhPXRoaXMuX3RyYW5zZm9ybXx8UGUodCxzLCEwKSxuLnBvcCgpfWlmKGkpe2Zvcig7Xzspe2ZvcihnPV8uX25leHQsYz1kO2MmJmMucHI+Xy5wcjspYz1jLl9uZXh0OyhfLl9wcmV2PWM/Yy5fcHJldjptKT9fLl9wcmV2Ll9uZXh0PV86ZD1fLChfLl9uZXh0PWMpP2MuX3ByZXY9XzptPV8sXz1nfXRoaXMuX2ZpcnN0UFQ9ZH1yZXR1cm4hMH0sbC5wYXJzZT1mdW5jdGlvbih0LGUsaSxuKXt2YXIgYSxsLHUsZixfLHAsYyxkLG0sZyx2PXQuc3R5bGU7Zm9yKGEgaW4gZSlwPWVbYV0sbD1vW2FdLGw/aT1sLnBhcnNlKHQscCxhLHRoaXMsaSxuLGUpOihfPXEodCxhLHMpK1wiXCIsbT1cInN0cmluZ1wiPT10eXBlb2YgcCxcImNvbG9yXCI9PT1hfHxcImZpbGxcIj09PWF8fFwic3Ryb2tlXCI9PT1hfHwtMSE9PWEuaW5kZXhPZihcIkNvbG9yXCIpfHxtJiZiLnRlc3QocCk/KG18fChwPW9lKHApLHA9KHAubGVuZ3RoPjM/XCJyZ2JhKFwiOlwicmdiKFwiKStwLmpvaW4oXCIsXCIpK1wiKVwiKSxpPXBlKHYsYSxfLHAsITAsXCJ0cmFuc3BhcmVudFwiLGksMCxuKSk6IW18fC0xPT09cC5pbmRleE9mKFwiIFwiKSYmLTE9PT1wLmluZGV4T2YoXCIsXCIpPyh1PXBhcnNlRmxvYXQoXyksYz11fHwwPT09dT9fLnN1YnN0cigodStcIlwiKS5sZW5ndGgpOlwiXCIsKFwiXCI9PT1ffHxcImF1dG9cIj09PV8pJiYoXCJ3aWR0aFwiPT09YXx8XCJoZWlnaHRcIj09PWE/KHU9dGUodCxhLHMpLGM9XCJweFwiKTpcImxlZnRcIj09PWF8fFwidG9wXCI9PT1hPyh1PVoodCxhLHMpLGM9XCJweFwiKToodT1cIm9wYWNpdHlcIiE9PWE/MDoxLGM9XCJcIikpLGc9bSYmXCI9XCI9PT1wLmNoYXJBdCgxKSxnPyhmPXBhcnNlSW50KHAuY2hhckF0KDApK1wiMVwiLDEwKSxwPXAuc3Vic3RyKDIpLGYqPXBhcnNlRmxvYXQocCksZD1wLnJlcGxhY2UoeSxcIlwiKSk6KGY9cGFyc2VGbG9hdChwKSxkPW0/cC5zdWJzdHIoKGYrXCJcIikubGVuZ3RoKXx8XCJcIjpcIlwiKSxcIlwiPT09ZCYmKGQ9YSBpbiByP3JbYV06YykscD1mfHwwPT09Zj8oZz9mK3U6ZikrZDplW2FdLGMhPT1kJiZcIlwiIT09ZCYmKGZ8fDA9PT1mKSYmdSYmKHU9USh0LGEsdSxjKSxcIiVcIj09PWQ/KHUvPVEodCxhLDEwMCxcIiVcIikvMTAwLGUuc3RyaWN0VW5pdHMhPT0hMCYmKF89dStcIiVcIikpOlwiZW1cIj09PWQ/dS89USh0LGEsMSxcImVtXCIpOlwicHhcIiE9PWQmJihmPVEodCxhLGYsZCksZD1cInB4XCIpLGcmJihmfHwwPT09ZikmJihwPWYrdStkKSksZyYmKGYrPXUpLCF1JiYwIT09dXx8IWYmJjAhPT1mP3ZvaWQgMCE9PXZbYV0mJihwfHxcIk5hTlwiIT1wK1wiXCImJm51bGwhPXApPyhpPW5ldyBfZSh2LGEsZnx8dXx8MCwwLGksLTEsYSwhMSwwLF8scCksaS54czA9XCJub25lXCIhPT1wfHxcImRpc3BsYXlcIiE9PWEmJi0xPT09YS5pbmRleE9mKFwiU3R5bGVcIik/cDpfKTpVKFwiaW52YWxpZCBcIithK1wiIHR3ZWVuIHZhbHVlOiBcIitlW2FdKTooaT1uZXcgX2UodixhLHUsZi11LGksMCxhLGghPT0hMSYmKFwicHhcIj09PWR8fFwiekluZGV4XCI9PT1hKSwwLF8scCksaS54czA9ZCkpOmk9cGUodixhLF8scCwhMCxudWxsLGksMCxuKSksbiYmaSYmIWkucGx1Z2luJiYoaS5wbHVnaW49bik7cmV0dXJuIGl9LGwuc2V0UmF0aW89ZnVuY3Rpb24odCl7dmFyIGUsaSxyLHM9dGhpcy5fZmlyc3RQVCxuPTFlLTY7aWYoMSE9PXR8fHRoaXMuX3R3ZWVuLl90aW1lIT09dGhpcy5fdHdlZW4uX2R1cmF0aW9uJiYwIT09dGhpcy5fdHdlZW4uX3RpbWUpaWYodHx8dGhpcy5fdHdlZW4uX3RpbWUhPT10aGlzLl90d2Vlbi5fZHVyYXRpb24mJjAhPT10aGlzLl90d2Vlbi5fdGltZXx8dGhpcy5fdHdlZW4uX3Jhd1ByZXZUaW1lPT09LTFlLTYpZm9yKDtzOyl7aWYoZT1zLmMqdCtzLnMscy5yP2U9TWF0aC5yb3VuZChlKTpuPmUmJmU+LW4mJihlPTApLHMudHlwZSlpZigxPT09cy50eXBlKWlmKHI9cy5sLDI9PT1yKXMudFtzLnBdPXMueHMwK2Urcy54czErcy54bjErcy54czI7ZWxzZSBpZigzPT09cilzLnRbcy5wXT1zLnhzMCtlK3MueHMxK3MueG4xK3MueHMyK3MueG4yK3MueHMzO2Vsc2UgaWYoND09PXIpcy50W3MucF09cy54czArZStzLnhzMStzLnhuMStzLnhzMitzLnhuMitzLnhzMytzLnhuMytzLnhzNDtlbHNlIGlmKDU9PT1yKXMudFtzLnBdPXMueHMwK2Urcy54czErcy54bjErcy54czIrcy54bjIrcy54czMrcy54bjMrcy54czQrcy54bjQrcy54czU7ZWxzZXtmb3IoaT1zLnhzMCtlK3MueHMxLHI9MTtzLmw+cjtyKyspaSs9c1tcInhuXCIrcl0rc1tcInhzXCIrKHIrMSldO3MudFtzLnBdPWl9ZWxzZS0xPT09cy50eXBlP3MudFtzLnBdPXMueHMwOnMuc2V0UmF0aW8mJnMuc2V0UmF0aW8odCk7ZWxzZSBzLnRbcy5wXT1lK3MueHMwO3M9cy5fbmV4dH1lbHNlIGZvcig7czspMiE9PXMudHlwZT9zLnRbcy5wXT1zLmI6cy5zZXRSYXRpbyh0KSxzPXMuX25leHQ7ZWxzZSBmb3IoO3M7KTIhPT1zLnR5cGU/cy50W3MucF09cy5lOnMuc2V0UmF0aW8odCkscz1zLl9uZXh0fSxsLl9lbmFibGVUcmFuc2Zvcm1zPWZ1bmN0aW9uKHQpe3RoaXMuX3RyYW5zZm9ybVR5cGU9dHx8Mz09PXRoaXMuX3RyYW5zZm9ybVR5cGU/MzoyLHRoaXMuX3RyYW5zZm9ybT10aGlzLl90cmFuc2Zvcm18fFBlKHRoaXMuX3RhcmdldCxzLCEwKX07dmFyIE1lPWZ1bmN0aW9uKCl7dGhpcy50W3RoaXMucF09dGhpcy5lLHRoaXMuZGF0YS5fbGlua0NTU1AodGhpcyx0aGlzLl9uZXh0LG51bGwsITApfTtsLl9hZGRMYXp5U2V0PWZ1bmN0aW9uKHQsZSxpKXt2YXIgcj10aGlzLl9maXJzdFBUPW5ldyBfZSh0LGUsMCwwLHRoaXMuX2ZpcnN0UFQsMik7ci5lPWksci5zZXRSYXRpbz1NZSxyLmRhdGE9dGhpc30sbC5fbGlua0NTU1A9ZnVuY3Rpb24odCxlLGkscil7cmV0dXJuIHQmJihlJiYoZS5fcHJldj10KSx0Ll9uZXh0JiYodC5fbmV4dC5fcHJldj10Ll9wcmV2KSx0Ll9wcmV2P3QuX3ByZXYuX25leHQ9dC5fbmV4dDp0aGlzLl9maXJzdFBUPT09dCYmKHRoaXMuX2ZpcnN0UFQ9dC5fbmV4dCxyPSEwKSxpP2kuX25leHQ9dDpyfHxudWxsIT09dGhpcy5fZmlyc3RQVHx8KHRoaXMuX2ZpcnN0UFQ9dCksdC5fbmV4dD1lLHQuX3ByZXY9aSksdH0sbC5fa2lsbD1mdW5jdGlvbihlKXt2YXIgaSxyLHMsbj1lO2lmKGUuYXV0b0FscGhhfHxlLmFscGhhKXtuPXt9O2ZvcihyIGluIGUpbltyXT1lW3JdO24ub3BhY2l0eT0xLG4uYXV0b0FscGhhJiYobi52aXNpYmlsaXR5PTEpfXJldHVybiBlLmNsYXNzTmFtZSYmKGk9dGhpcy5fY2xhc3NOYW1lUFQpJiYocz1pLnhmaXJzdCxzJiZzLl9wcmV2P3RoaXMuX2xpbmtDU1NQKHMuX3ByZXYsaS5fbmV4dCxzLl9wcmV2Ll9wcmV2KTpzPT09dGhpcy5fZmlyc3RQVCYmKHRoaXMuX2ZpcnN0UFQ9aS5fbmV4dCksaS5fbmV4dCYmdGhpcy5fbGlua0NTU1AoaS5fbmV4dCxpLl9uZXh0Ll9uZXh0LHMuX3ByZXYpLHRoaXMuX2NsYXNzTmFtZVBUPW51bGwpLHQucHJvdG90eXBlLl9raWxsLmNhbGwodGhpcyxuKX07dmFyIExlPWZ1bmN0aW9uKHQsZSxpKXt2YXIgcixzLG4sYTtpZih0LnNsaWNlKWZvcihzPXQubGVuZ3RoOy0tcz4tMTspTGUodFtzXSxlLGkpO2Vsc2UgZm9yKHI9dC5jaGlsZE5vZGVzLHM9ci5sZW5ndGg7LS1zPi0xOyluPXJbc10sYT1uLnR5cGUsbi5zdHlsZSYmKGUucHVzaCgkKG4pKSxpJiZpLnB1c2gobikpLDEhPT1hJiY5IT09YSYmMTEhPT1hfHwhbi5jaGlsZE5vZGVzLmxlbmd0aHx8TGUobixlLGkpfTtyZXR1cm4gYS5jYXNjYWRlVG89ZnVuY3Rpb24odCxpLHIpe3ZhciBzLG4sYSxvPWUudG8odCxpLHIpLGw9W29dLGg9W10sdT1bXSxmPVtdLF89ZS5faW50ZXJuYWxzLnJlc2VydmVkUHJvcHM7Zm9yKHQ9by5fdGFyZ2V0c3x8by50YXJnZXQsTGUodCxoLGYpLG8ucmVuZGVyKGksITApLExlKHQsdSksby5yZW5kZXIoMCwhMCksby5fZW5hYmxlZCghMCkscz1mLmxlbmd0aDstLXM+LTE7KWlmKG49RyhmW3NdLGhbc10sdVtzXSksbi5maXJzdE1QVCl7bj1uLmRpZnM7XHJcbmZvcihhIGluIHIpX1thXSYmKG5bYV09clthXSk7bC5wdXNoKGUudG8oZltzXSxpLG4pKX1yZXR1cm4gbH0sdC5hY3RpdmF0ZShbYV0pLGF9LCEwKX0pLHdpbmRvdy5fZ3NEZWZpbmUmJndpbmRvdy5fZ3NRdWV1ZS5wb3AoKSgpOyIsIi8qIVxyXG4gKiBWRVJTSU9OOiAxLjcuM1xyXG4gKiBEQVRFOiAyMDE0LTAxLTE0XHJcbiAqIFVQREFURVMgQU5EIERPQ1MgQVQ6IGh0dHA6Ly93d3cuZ3JlZW5zb2NrLmNvbVxyXG4gKlxyXG4gKiBAbGljZW5zZSBDb3B5cmlnaHQgKGMpIDIwMDgtMjAxNCwgR3JlZW5Tb2NrLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG4gKiBUaGlzIHdvcmsgaXMgc3ViamVjdCB0byB0aGUgdGVybXMgYXQgaHR0cDovL3d3dy5ncmVlbnNvY2suY29tL3Rlcm1zX29mX3VzZS5odG1sIG9yIGZvclxyXG4gKiBDbHViIEdyZWVuU29jayBtZW1iZXJzLCB0aGUgc29mdHdhcmUgYWdyZWVtZW50IHRoYXQgd2FzIGlzc3VlZCB3aXRoIHlvdXIgbWVtYmVyc2hpcC5cclxuICogXHJcbiAqIEBhdXRob3I6IEphY2sgRG95bGUsIGphY2tAZ3JlZW5zb2NrLmNvbVxyXG4gKiovXHJcbih3aW5kb3cuX2dzUXVldWV8fCh3aW5kb3cuX2dzUXVldWU9W10pKS5wdXNoKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LGU9d2luZG93LGk9ZnVuY3Rpb24oaSxzKXt2YXIgcj1cInhcIj09PXM/XCJXaWR0aFwiOlwiSGVpZ2h0XCIsbj1cInNjcm9sbFwiK3IsYT1cImNsaWVudFwiK3Isbz1kb2N1bWVudC5ib2R5O3JldHVybiBpPT09ZXx8aT09PXR8fGk9PT1vP01hdGgubWF4KHRbbl0sb1tuXSktKGVbXCJpbm5lclwiK3JdfHxNYXRoLm1heCh0W2FdLG9bYV0pKTppW25dLWlbXCJvZmZzZXRcIityXX0scz13aW5kb3cuX2dzRGVmaW5lLnBsdWdpbih7cHJvcE5hbWU6XCJzY3JvbGxUb1wiLEFQSToyLHZlcnNpb246XCIxLjcuM1wiLGluaXQ6ZnVuY3Rpb24odCxzLHIpe3JldHVybiB0aGlzLl93ZHc9dD09PWUsdGhpcy5fdGFyZ2V0PXQsdGhpcy5fdHdlZW49cixcIm9iamVjdFwiIT10eXBlb2YgcyYmKHM9e3k6c30pLHRoaXMuX2F1dG9LaWxsPXMuYXV0b0tpbGwhPT0hMSx0aGlzLng9dGhpcy54UHJldj10aGlzLmdldFgoKSx0aGlzLnk9dGhpcy55UHJldj10aGlzLmdldFkoKSxudWxsIT1zLng/KHRoaXMuX2FkZFR3ZWVuKHRoaXMsXCJ4XCIsdGhpcy54LFwibWF4XCI9PT1zLng/aSh0LFwieFwiKTpzLngsXCJzY3JvbGxUb194XCIsITApLHRoaXMuX292ZXJ3cml0ZVByb3BzLnB1c2goXCJzY3JvbGxUb194XCIpKTp0aGlzLnNraXBYPSEwLG51bGwhPXMueT8odGhpcy5fYWRkVHdlZW4odGhpcyxcInlcIix0aGlzLnksXCJtYXhcIj09PXMueT9pKHQsXCJ5XCIpOnMueSxcInNjcm9sbFRvX3lcIiwhMCksdGhpcy5fb3ZlcndyaXRlUHJvcHMucHVzaChcInNjcm9sbFRvX3lcIikpOnRoaXMuc2tpcFk9ITAsITB9LHNldDpmdW5jdGlvbih0KXt0aGlzLl9zdXBlci5zZXRSYXRpby5jYWxsKHRoaXMsdCk7dmFyIHM9dGhpcy5fd2R3fHwhdGhpcy5za2lwWD90aGlzLmdldFgoKTp0aGlzLnhQcmV2LHI9dGhpcy5fd2R3fHwhdGhpcy5za2lwWT90aGlzLmdldFkoKTp0aGlzLnlQcmV2LG49ci10aGlzLnlQcmV2LGE9cy10aGlzLnhQcmV2O3RoaXMuX2F1dG9LaWxsJiYoIXRoaXMuc2tpcFgmJihhPjd8fC03PmEpJiZpKHRoaXMuX3RhcmdldCxcInhcIik+cyYmKHRoaXMuc2tpcFg9ITApLCF0aGlzLnNraXBZJiYobj43fHwtNz5uKSYmaSh0aGlzLl90YXJnZXQsXCJ5XCIpPnImJih0aGlzLnNraXBZPSEwKSx0aGlzLnNraXBYJiZ0aGlzLnNraXBZJiZ0aGlzLl90d2Vlbi5raWxsKCkpLHRoaXMuX3dkdz9lLnNjcm9sbFRvKHRoaXMuc2tpcFg/czp0aGlzLngsdGhpcy5za2lwWT9yOnRoaXMueSk6KHRoaXMuc2tpcFl8fCh0aGlzLl90YXJnZXQuc2Nyb2xsVG9wPXRoaXMueSksdGhpcy5za2lwWHx8KHRoaXMuX3RhcmdldC5zY3JvbGxMZWZ0PXRoaXMueCkpLHRoaXMueFByZXY9dGhpcy54LHRoaXMueVByZXY9dGhpcy55fX0pLHI9cy5wcm90b3R5cGU7cy5tYXg9aSxyLmdldFg9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5fd2R3P251bGwhPWUucGFnZVhPZmZzZXQ/ZS5wYWdlWE9mZnNldDpudWxsIT10LnNjcm9sbExlZnQ/dC5zY3JvbGxMZWZ0OmRvY3VtZW50LmJvZHkuc2Nyb2xsTGVmdDp0aGlzLl90YXJnZXQuc2Nyb2xsTGVmdH0sci5nZXRZPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX3dkdz9udWxsIT1lLnBhZ2VZT2Zmc2V0P2UucGFnZVlPZmZzZXQ6bnVsbCE9dC5zY3JvbGxUb3A/dC5zY3JvbGxUb3A6ZG9jdW1lbnQuYm9keS5zY3JvbGxUb3A6dGhpcy5fdGFyZ2V0LnNjcm9sbFRvcH0sci5fa2lsbD1mdW5jdGlvbih0KXtyZXR1cm4gdC5zY3JvbGxUb194JiYodGhpcy5za2lwWD0hMCksdC5zY3JvbGxUb195JiYodGhpcy5za2lwWT0hMCksdGhpcy5fc3VwZXIuX2tpbGwuY2FsbCh0aGlzLHQpfX0pLHdpbmRvdy5fZ3NEZWZpbmUmJndpbmRvdy5fZ3NRdWV1ZS5wb3AoKSgpOyJdfQ==
