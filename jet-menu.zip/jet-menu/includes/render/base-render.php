<?php
namespace Jet_Menu\Render;

abstract class Base_Render {

	/**
	 * [$settings description]
	 * @var null
	 */
	private $settings = null;

	/**
	 * [__construct description]
	 * @param array $settings [description]
	 */
	public function __construct( $settings = array() ) {
		$this->settings = $this->get_parsed_settings( $settings );

		$this->init();
	}

	/**
	 * [init description]
	 * @return [type] [description]
	 */
	public function init() {}

	/**
	 * Returns parsed settings
	 *
	 * @param  array $settings
	 * @return array
	 */
	public function get_parsed_settings( $settings = array() ) {

		$defaults = $this->default_settings();

		return wp_parse_args( $settings, $defaults );

	}

	/**
	 * Returns plugin default settings
	 *
	 * @return array
	 */
	public function default_settings() {
		return array();
	}

	/**
	 * [get_settings description]
	 * @param  [type] $setting [description]
	 * @return [type]          [description]
	 */
	public function get_settings( $setting = null ) {

		if ( $setting ) {
			return isset( $this->settings[ $setting ] ) ? $this->settings[ $setting ] : false;
		} else {
			return $this->settings;
		}
	}

	/**
	 * Returns required settings
	 *
	 * @return array
	 */
	public function get_required_settings() {
		$required = array();
		$settings = $this->get_settings();
		$default  = $this->default_settings();

		foreach ( $default as $key => $value ) {

			if ( isset( $settings[ $key ] ) ) {
				$required[ $key ] = $settings[ $key ];
			}
		}

		return $required;
	}

	/**
	 * [get description]
	 * @param  [type]  $setting [description]
	 * @param  boolean $default [description]
	 * @return [type]           [description]
	 */
	public function get( $setting = null, $default = false ) {

		if ( isset( $this->settings[ $setting ] ) ) {
			return $this->settings[ $setting ];
		} else {
			$defaults = $this->default_settings();

			return isset( $defaults[ $setting ] ) ? $defaults[ $setting ] : $default;
		}
	}

	/**
	 * [get_content description]
	 * @return [type] [description]
	 */
	public function get_content() {
		ob_start();

		$this->render();

		return ob_get_clean();
	}

	/**
	 * @return false
	 */
	public function get_render_data() {
		return false;
	}

	/**
	 * [get_name description]
	 * @return [type] [description]
	 */
	abstract public function get_name();

	/**
	 * Render content
	 *
	 * @return [type] [description]
	 */
	abstract public function render();

	/**
	 * Is editor context
	 *
	 * @return boolean
	 */
	public function is_editor() {
		// Safe: 'context' is only used to detect editor mode, no sensitive processing.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return isset( $_REQUEST['context'] ) && $_REQUEST['context'] === 'edit' ? true : false;
	}

	/**
	 * @param $handler
	 *
	 * @return \_WP_Dependency|false
	 */
	public function get_registered_style_obj_by_handler( $handler ) {

		if ( isset( wp_styles()->registered[ $handler ] ) ) {
			$src = wp_styles()->registered[ $handler ]->src;

			if ( ! preg_match( '|^(https?:)?//|', $src ) && ! ( wp_styles()->content_url && 0 === strpos( $src, wp_styles()->content_url ) ) ) {
				wp_styles()->registered[ $handler ]->src = wp_styles()->base_url . $src;
			}

			return wp_styles()->registered[ $handler ];
		}

		return false;
	}

	/**
	 * [get_script_uri_by_handler description]
	 * @param  [type] $handler [description]
	 * @return [type]          [description]
	 */
	public function get_registered_script_obj_by_handler( $handler ) {

		if ( isset( wp_scripts()->registered[ $handler ] ) ) {
			$src = wp_scripts()->registered[ $handler ]->src;

			if ( ! preg_match( '|^(https?:)?//|', $src ) && ! ( wp_scripts()->content_url && 0 === strpos( $src, wp_scripts()->content_url ) ) ) {
				wp_scripts()->registered[ $handler ]->src = wp_scripts()->base_url . $src;
			}

			return wp_scripts()->registered[ $handler ];
		}

		return false;
	}

	/**
	 * Update script dependencies stored in post meta.
	 *
	 * @param int   $template_id  Template post ID.
	 * @param array $scripts_data Script dependencies data.
	 *
	 * @return int|bool
	 */
	public static function update_script_dependencies_cache( $template_id, $scripts_data ) {

		$scripts_data = self::prepare_script_dependencies_for_cache( $scripts_data );

		if ( metadata_exists( 'post', $template_id, '_is_script_deps' ) ) {
			return update_post_meta( $template_id, '_is_script_deps', $scripts_data );
		}

		$result = add_post_meta( $template_id, '_is_script_deps', $scripts_data, true );

		if ( ! $result ) {
			return update_post_meta( $template_id, '_is_script_deps', $scripts_data );
		}

		return $result;
	}

	/**
	 * Check if cached script dependencies can be safely printed.
	 *
	 * @param array $scripts_data Script dependencies data.
	 *
	 * @return bool
	 */
	public static function is_script_dependencies_cache_valid( $scripts_data ) {

		if ( empty( $scripts_data['depends'] ) || ! is_array( $scripts_data['depends'] ) ) {
			return true;
		}

		foreach ( $scripts_data['depends'] as $script_data ) {
			if ( empty( $script_data['obj'] ) || ! $script_data['obj'] instanceof \_WP_Dependency ) {
				continue;
			}

			if ( ! empty( $script_data['obj']->extra['data'] ) && self::has_malformed_localized_script_data( $script_data['obj']->extra['data'] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Prepare script dependencies for storing in post meta.
	 *
	 * Meta API unslashes values before saving. Script dependency objects may
	 * contain already escaped inline data generated by wp_localize_script(),
	 * so deep-slash cloned objects before storage.
	 *
	 * @param array $scripts_data Script dependencies data.
	 *
	 * @return array
	 */
	private static function prepare_script_dependencies_for_cache( $scripts_data ) {

		if ( empty( $scripts_data['depends'] ) || ! is_array( $scripts_data['depends'] ) ) {
			return $scripts_data;
		}

		foreach ( $scripts_data['depends'] as $key => $script_data ) {
			if ( isset( $script_data['handle'] ) ) {
				$scripts_data['depends'][ $key ]['handle'] = wp_slash( $script_data['handle'] );
			}

			if ( isset( $script_data['src'] ) ) {
				$scripts_data['depends'][ $key ]['src'] = wp_slash( $script_data['src'] );
			}

			if ( ! empty( $script_data['obj'] ) && $script_data['obj'] instanceof \_WP_Dependency ) {
				$scripts_data['depends'][ $key ]['obj'] = map_deep( clone $script_data['obj'], 'wp_slash' );
			}
		}

		return $scripts_data;
	}

	/**
	 * Check for localized script data damaged by unslashing nested JSON strings.
	 *
	 * @param string $data Localized script data.
	 *
	 * @return bool
	 */
	private static function has_malformed_localized_script_data( $data ) {

		if ( ! is_string( $data ) ) {
			return false;
		}

		return (bool) preg_match( '/:\s*"\s*[\[{]\s*"/', $data );
	}
}
