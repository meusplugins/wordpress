<?php
namespace com\sakuraplugins\appetit\rest_api\models;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'OrderTypes.php');
require_once(plugin_dir_path(__FILE__) . 'OrderPaymentStatus.php');
require_once(plugin_dir_path(__FILE__) . 'OrderStatus.php');
require_once(plugin_dir_path(__FILE__) . '../../../services/ProductSevice.php');
require_once(plugin_dir_path(__FILE__) . '../../../services/ChoiceGroupsService.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/PriceUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/Sanitizer.php');
require_once(plugin_dir_path(__FILE__) . '../../../cpt/OrderCpt.php');

use com\sakuraplugins\appetit\services\ProductSevice;
use com\sakuraplugins\appetit\services\ChoiceGroupsService;
use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\Sanitizer;
use com\sakuraplugins\appetit\utils\PriceUtil;
use com\sakuraplugins\appetit\cpt\OrderCpt;
use com\sakuraplugins\appetit\services\LocalesService;

class Order {

    private $ID;
    private $_orderRawData;
    private $_cartProducts;
    private $_orderType;
    private $_orderProducts = [];
    private $_delivery_info = [];
    private $_pickup_date;
    private $_safe_match_code;
    private $_safe_match_bkg;
    private $_payment_method;
    private $_public_id;
    private $_delivery_cost = 0;
    private $_orderTotal = 0;
    private $_tipping_cost = 0;
    private $_payment_status;
    private $_user_accepted_terms;

    private $_products_total = 0;
    private $errors = [];
    public $_orderAll;

    private $restaurant_timezone;

    function __construct() {
        $this->restaurant_timezone = OptionUtil::getInstance()->getOption('restaurant_timezone', 'Europe/Amsterdam');
    }

    function setId($id) {
        $this->ID = $id;
    }

    function getId() {
        return $this->ID;
    }

    function setRawData($val) {
        $this->_orderRawData = $val;
        return $this;
    }

    function extractRawData() {
        $this->_orderType = Sanitizer::sanitizeInput($this->_orderRawData['_order_type'] ?? '');
        if (!in_array($this->_orderType, OrderTypes::getAll())) {
            array_push($this->errors, esc_html__('Invalid order type', 'instafood'));
            return;
        }

        $this->_user_accepted_terms = Sanitizer::sanitizeInput($this->_orderRawData['_user_accepted_terms'] ?? false);

        $this->_cartProducts = $this->_orderRawData['_cartProducts'] ?? [];
        if (sizeof($this->_cartProducts) === 0) {
            array_push($this->errors, esc_html__('Cart is empty, can not place order', 'instafood'));
            return;
        }
        $this->_extractProducts();
        $this->_extractDeliveryInfo();
        $this->_handleDeliveryDate();
        $this->_generateSafeMatchCode();
        $this->_generatePublicId();
        $this->_payment_method = sanitize_text_field($this->_orderRawData['payment_type'] ?? '');
        $this->_setupDeliveryCost();
        $this->_handleTip();
        $this->_handlePaymentStatus();
    }

    private function _handlePaymentStatus() {
        if ($this->_payment_method === 'stripe') {
            $this->_payment_status = OrderPaymentStatus::PENDING_TRANSACTION;
        } else if ($this->_payment_method === 'cash_on_delivery') {
            $this->_payment_status = OrderPaymentStatus::PENDING_ON_DELIVERY;
        }
    }

    private function _handleTip() {
        $tipping_percentage = OptionUtil::getInstance()->getOption("tipping_percentage", '');
        $isDeliveryOrDineIn = $this->_orderType === OrderTypes::DELIVERY || $this->_orderType === OrderTypes::DINEIN;
        if ($isDeliveryOrDineIn && $tipping_percentage !== '') {
            $this->_tipping_cost = ($this->_products_total * floatval($tipping_percentage)) / 100;
            $this->_orderTotal += $this->_tipping_cost;
        }
    }

    private function _setupDeliveryCost() {
        $isDelivery = $this->_orderType === OrderTypes::DELIVERY;
        $delivery_cost = OptionUtil::getInstance()->getOption("order_delivery_cost", '');
        if ($isDelivery && $delivery_cost !== '') {
            $this->_delivery_cost = floatval($delivery_cost);
            $this->_orderTotal += $this->_delivery_cost;
        }
    }

    private function _extractProducts() {
        foreach ($this->_cartProducts as $cartProduct) {
            $productId = Sanitizer::sanitizeInput($cartProduct['product_id'] ?? '');
            $quantity = Sanitizer::sanitizeInput($cartProduct['_quantity'] ?? 1);
            $additional_notes = Sanitizer::sanitizeInput($cartProduct['additional_notes'] ?? '');
            $product_total = 0;

            $product = ProductSevice::getProduct($productId);
            if ($product === false) {
                continue;
            }
            $meta = ProductSevice::getProductMeta($productId);
            $item_name_1 = Sanitizer::sanitizeInput($meta['item_name_1'] ?? '');
            $item_name_2 = Sanitizer::sanitizeInput($meta['item_name_2'] ?? '');
            $item_description_1 = Sanitizer::sanitizeInput($meta['item_description_1'] ?? '');
            $item_description_2 = Sanitizer::sanitizeInput($meta['item_description_2'] ?? '');
            
            // extract choices
            $product_choices = [];
            $_groups = wp_unslash($cartProduct['_groups'] ?? []);

            foreach ($_groups as $group) {
                $groupChoices = wp_unslash($group['groupChoices'] ?? []);
                if (sizeof($groupChoices) > 0) {
                    foreach ($groupChoices as $choiceId) {
                        # code...
                        $choice = ChoiceGroupsService::getInstance()->getChoice($choiceId);
                        if ($choice) {
                            $price = floatval($choice->term_meta['choice_price'] ?? '');
                            array_push($product_choices, [
                                'term_id' => $choiceId,
                                'primary_lang_choice_name' => $choice->term_meta['primary_lang_choice_name'] ?? '',
                                'secondary_lang_choice_name' => $choice->term_meta['secondary_lang_choice_name'] ?? '',
                                'choice_price' => $price,
                            ]);
                            if (is_numeric($price)) {
                                $product_total += $price * $quantity;
                            }
                        }
                    }
                }
            }

            // extract variant 
            $product_variations = wp_unslash($meta['product_variations'] ?? []);
            $variant_id = $cartProduct['variant_id'] ?? '';
            $selectedVariant = [];
            for ($i=0; $i < sizeof($product_variations); $i++) { 
                if ($variant_id === $product_variations[$i]['ID'] ?? '') {
                    $variantPrice = Sanitizer::sanitizeInput(floatval($product_variations[$i]['price']));
                    $selectedVariant = array_merge(
                        $product_variations[$i],
                        ['price' => floatval($variantPrice)]
                    );
                    if (sizeof($product_variations) === 1) {
                        $selectedVariant['variation_name_1'] = $item_name_1;
                        $selectedVariant['variation_name_2'] = $item_name_2;
                    }
                    if (is_numeric($variantPrice)) {
                        $product_total += $variantPrice * $quantity;
                    }
                    break;
                }
            }

            $this->_orderTotal += $product_total;
            $this->_products_total += $product_total;

            array_push($this->_orderProducts, [
                'productId' => $productId,
                'item_name_1' => $item_name_1,
                'item_name_2' => $item_name_2,
                'item_description_1' => $item_description_1,
                'item_description_2' => $item_description_2,
                'quantity' => $quantity,
                'additional_notes' => $additional_notes,
                'product_total' => $product_total,
                'selectedVariant' => $selectedVariant,
                'product_choices' => $product_choices,
                'hasVariants' => sizeof($product_variations) > 1,
            ]);
        }
    }

    private function _extractDeliveryInfo() {
        switch ($this->_orderType) {
            case OrderTypes::DELIVERY:
                $this->_delivery_info = [
                    '_customerPhone' => Sanitizer::sanitizeInput($this->_orderRawData['_delivery_info']['_customerPhone'] ?? ''),
                    '_customerCity' => Sanitizer::sanitizeInput($this->_orderRawData['_delivery_info']['_customerCity'] ?? ''),
                    '_customerAddress' => Sanitizer::sanitizeInput($this->_orderRawData['_delivery_info']['_customerAddress'] ?? ''),
                    '_customer_notes' => Sanitizer::sanitizeInput($this->_orderRawData['_delivery_info']['_customer_notes'] ?? '')
                ];
            break;
            case OrderTypes::PICKUP:
                $pickup_day = Sanitizer::sanitizeInput($this->_orderRawData['_pickup_date']['day'] ?? '');
                $pickup_time = Sanitizer::sanitizeInput($this->_orderRawData['_pickup_date']['time'] ?? '');

                $_pickupCustomerPhone = Sanitizer::sanitizeInput($this->_orderRawData['_pickupCustomerPhone'] ?? '');
                $_customerFirstName = Sanitizer::sanitizeInput($this->_orderRawData['_customerFirstName'] ?? '');
                
                $this->_delivery_info = [
                    '_pickup_day' => $pickup_day,
                    '_pickup_time' => $pickup_time,
                    '_pickupCustomerPhone' => $_pickupCustomerPhone,
                    '_customerFirstName' => $_customerFirstName,
                ];
                $format = 'm/d/Y h:i A'; // WP format
                $dateStart = \DateTime::createFromFormat($format, "$pickup_day $pickup_time", new \DateTimeZone($this->restaurant_timezone));
                $this->_pickup_date = $dateStart->format('Y-m-d H:i:s');
            break;
            case OrderTypes::DINEIN:
                $this->_delivery_info = [
                    '_table' => sanitize_text_field($this->_orderRawData['_table'] ?? ''),
                ];
            break;
        }
    }

    private function _handleDeliveryDate() {
        if ($this->_orderType === OrderTypes::PICKUP) {
            $pickup_day = Sanitizer::sanitizeInput($this->_orderRawData['_pickup_date']['day'] ?? '');
            $pickup_time = Sanitizer::sanitizeInput($this->_orderRawData['_pickup_date']['time'] ?? '');
            $format = 'm/d/Y h:i A'; // WP format
            $dateStart = \DateTime::createFromFormat($format, "$pickup_day $pickup_time", new \DateTimeZone($this->restaurant_timezone));
            $this->_pickup_date = $dateStart->format('Y-m-d H:i:s');
        }
    }

    private function _generateSafeMatchCode() {
        $this->_safe_match_code = chr(rand(65,90)) . chr(rand(65,90)) . rand(0, 9) . rand(0, 9) . rand(0, 9);
        $this->_safe_match_bkg = apply_filters('appetit_request_random_safematch_color', []);
    }

    private function _generatePublicId() {
        $this->_public_id = wp_generate_uuid4();
    }

    public function insertOrderToDb() {
        if (INSTAFOOD_PREVIEW_MODE === true) {
            return;
        }
        OrderCpt::getPostType();
        $post_id = wp_insert_post([
            'post_type' => OrderCpt::getPostType(),
            'post_status' => 'private',
        ]);
        $d = new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));
        $orderDateTZ = $d->format('Y-m-d h:ia');

        $this->ID = $post_id;
        if (is_numeric($post_id)) {
            $this->ID = $post_id;
            wp_update_post([
                'ID' => $post_id,
                'post_title' => esc_html__("Order ", 'instafood') . '#' . $post_id,
            ]);
            update_post_meta($post_id, '_orderRawData', $this->_orderRawData);
            update_post_meta($post_id, '_orderProducts', $this->_orderProducts);
            update_post_meta($post_id, '_orderType', $this->_orderType);
            update_post_meta($post_id, '_delivery_info', $this->_delivery_info);
            update_post_meta($post_id, '_pickup_date', $this->_pickup_date);
            update_post_meta($post_id, '_safe_match_code', $this->_safe_match_code);
            update_post_meta($post_id, '_safe_match_bkg', $this->_safe_match_bkg);
            update_post_meta($post_id, '_safe_match_code_lowercase', strtolower($this->_safe_match_code));
            update_post_meta($post_id, '_payment_method', $this->_payment_method);
            update_post_meta($post_id, '_payment_status', $this->_payment_status);
            update_post_meta($post_id, '_public_id', $this->_public_id);
            update_post_meta($post_id, '_delivery_cost', $this->_delivery_cost);
            update_post_meta($post_id, '_tipping_cost', $this->_tipping_cost);
            update_post_meta($post_id, '_orderTotal', $this->_orderTotal);
            update_post_meta($post_id, '_orderStatus', OrderStatus::NEW_ORDER);
            update_post_meta($post_id, '_orderDate', $orderDateTZ);
            update_post_meta($post_id, '_user_accepted_terms', $this->_user_accepted_terms);

            update_post_meta($post_id, '_orderAll', [
                '_orderProducts' => $this->_orderProducts,
                '_orderType' => $this->_orderType,
                '_delivery_info' => $this->_delivery_info,
                '_pickup_date' => $this->_pickup_date,
                '_safe_match_code' => $this->_safe_match_code,
                '_safe_match_bkg' => $this->_safe_match_bkg,
                '_safe_match_code_lowercase' => strtolower($this->_safe_match_code),
                '_payment_method' => $this->_payment_method,
                '_payment_status' => $this->_payment_status,
                '_public_id' => $this->_public_id,
                '_delivery_cost' => $this->_delivery_cost,
                '_tipping_cost' => $this->_tipping_cost,
                '_orderTotal' => $this->_orderTotal,

                '_delivery_cost_formatted' => number_format((float)$this->_delivery_cost, 2, '.', ''),
                '_tipping_cost_formatted' => number_format((float)$this->_tipping_cost, 2, '.', ''),
                '_orderTotal_formatted' => number_format((float)$this->_orderTotal, 2, '.', ''),

                '_orderStatus' => OrderStatus::NEW_ORDER,
                '_orderDate' => $orderDateTZ,
                '_user_accepted_terms' => $this->_user_accepted_terms,
            ]);

            do_action('instafood_new_order', $this->ID);
        }
    }

    public function getPaymentMethod() {
        return esc_html($this->_payment_method);
    }

    public function getOrderSummary(): array {
        $resposne = [
            'ID' => esc_html($this->ID),
            '_orderType' => esc_html($this->_orderType),
            '_payment_status' => esc_html($this->_payment_status),
            '_payment_method' => esc_html($this->getPaymentMethod())
        ];
        if ($this->_orderType === OrderTypes::PICKUP) {
            $resposne['_pickup_date'] = [
                'day' => esc_html($this->_orderRawData['_pickup_date']['day'] ?? ''),
                'time' => esc_html($this->_orderRawData['_pickup_date']['time'] ?? ''),
            ];
            $resposne['_safe_match_code'] = $this->_safe_match_code;
            $resposne['_safe_match_bkg'] = $this->_safe_match_bkg;
        }
        return $resposne;
    }

    function findOne(int $ID) {
        $postData = get_post($ID);
        if ($postData) {
            $this->ID = intval($ID);
            $_orderAll = get_post_meta($ID, '_orderAll', true);
            $this->_orderAll = $_orderAll;
            if (is_array($_orderAll)) {
                foreach ($_orderAll as $key => $value) {
                    $this->{$key} = $value;
                }
            }
        }
        return $postData;
    }

    function findOneByPublicId($_public_id) {
        $posts = get_posts(array(
            'numberposts'   => -1,
            'post_type'     => OrderCpt::getPostType(),
            'post_status' => 'private',
            'meta_key'      => '_public_id',
            'meta_value'    => $_public_id,
        ));
        if (isset($posts[0])) {
            $this->ID = $posts[0]->ID;
        }
        return $this->ID;
    }

    function getProperty($propKey, $default = null) {
        return $this->{$propKey} ?? $default;
    }

    function getStripeLineItems() {
        $locales = LocalesService::getInstance()->getLocales();

        $_orderProducts = $this->getProperty('_orderProducts', []);
        $currency_code = OptionUtil::getInstance()->getOption('restaurant_currency_code', 'USD');
        if (sizeof($_orderProducts) === 0) {
            return [];
        }
        $line_items = [];
        foreach ($_orderProducts as $orderProduct) {
            
            $p_price = $orderProduct['selectedVariant']['price'] ?? 1;

            $product_data = [
                'name' => $orderProduct['item_name_1'] ?? esc_html__("Missing name", 'instafood') . $orderProduct['selectedVariant']['variation_name_1'] ?? esc_html__("Missing name", 'instafood'),
            ];
            $product_choices = $orderProduct['product_choices'] ?? [];
            if (sizeof($product_choices) > 0) {
                $product_data['description'] = '';
                for ($i = 0; $i < sizeof($product_choices); $i++) { 
                    $productChoice = $product_choices[$i];
                    $separator = $i < sizeof($product_choices) - 1 ? ', ' : ' ';
                    $primary_lang_choice_name = $productChoice['primary_lang_choice_name'] ?? 'missing choice name';
                    $product_data['description'] .= $primary_lang_choice_name . $separator;
                    $p_price += $productChoice['choice_price'] ?? 0;
                }
            }

            
            $line_item = [
                'quantity' => $orderProduct['quantity'] ?? 1,
                'price_data' => [
                    'unit_amount_decimal' => number_format((float)$p_price, 2, '.', '') * 100,
                    'currency' => $currency_code,
                    'product_data' => $product_data
                ]
            ];
            array_push($line_items, $line_item);
        }
        
        $_tipping_cost = $this->getProperty('_tipping_cost', 0);
        if ($_tipping_cost && $_tipping_cost !== 0) {
            $tippingLabel = $locales['tip_percentage_summary_label']['primary_lang_'] ?? 'Tip';
            $tipping_percentage = OptionUtil::getInstance()->getOption("tipping_percentage", '');
            $tippingLabel = str_replace("&lt;%= tipPercent %&gt;", $tipping_percentage, $tippingLabel);

            $line_item = [
                'quantity' => 1,
                'price_data' => [
                    'unit_amount_decimal' => number_format((float)$_tipping_cost, 2, '.', '') * 100,
                    'currency' => $currency_code,
                    'product_data' => [
                        'name' => $tippingLabel
                    ]
                ]
            ];
            array_push($line_items, $line_item);
        }

        
        $_delivery_cost = $this->getProperty('_delivery_cost', 0);
        if ($_delivery_cost && $_delivery_cost !== 0) {
            $delivery_fee_label = $locales['delivery_fee_label']['primary_lang_'] ?? 'Delivery';
            $line_item = [
                'quantity' => 1,
                'price_data' => [
                    'unit_amount_decimal' => number_format((float)$_delivery_cost, 2, '.', '') * 100,
                    'currency' => $currency_code,
                    'product_data' => [
                        'name' => $delivery_fee_label,
                    ]
                ]
            ];
            array_push($line_items, $line_item);
        }
        return $line_items;
    }

    function getLineItemsData() {
        $locales = LocalesService::getInstance()->getLocales();

        $_orderProducts = $this->getProperty('_orderProducts', []);
        $total = 0;


        if (sizeof($_orderProducts) === 0) {
            return [];
        }
        $line_items = [];
        foreach ($_orderProducts as $orderProduct) {

            $p_price =  esc_html($orderProduct['selectedVariant']['price'] ?? 1);

            $p_ID =  esc_html($orderProduct['productId'] ?? 0);
            $p_name = $orderProduct['item_name_1'] ?? esc_html__("Missing name", 'instafood');
            $p_name = esc_html($p_name);
            $p_description =  esc_html($orderProduct['item_description_1'] ?? '');
            $p_quantity = esc_html($orderProduct['quantity'] ?? 1);
            $p_additional_notes = esc_html($orderProduct['additional_notes'] ?? '');
            

            $p_variant = [
                'name' => esc_html($orderProduct['selectedVariant']['variation_name_1'] ?? ''),
                'ID' => esc_html($orderProduct['selectedVariant']['ID'] ?? ''),
            ];

            $p_choices = [];

            $product_choices = $orderProduct['product_choices'] ?? [];
            if (sizeof($product_choices) > 0) {
                for ($i = 0; $i < sizeof($product_choices); $i++) {

                    $choice_id = $product_choices[$i]['term_id'] ?? '';
                    $choice_name = $product_choices[$i]['primary_lang_choice_name'] ?? '';
                    $choice_price = $product_choices[$i]['choice_price'] ?? 0;
                    $p_price += $choice_price;
                    $choice_price = number_format((float)$choice_price, 2, '.', '');

                    array_push($p_choices, [
                        'name' => esc_html($choice_name),
                        'price' => esc_html($choice_price),
                        'choice_id' => esc_html($choice_id),
                    ]);
                }
            }

            $p_price = ($p_price * $p_quantity);
            $total += $p_price;
            $p_price = number_format((float)$p_price, 2, '.', '');

            $line_item = [
                'ID' => $p_ID,
                'type' => 'prduct',
                'quantity' => $p_quantity,
                'price' => $p_price,
                'name' => $p_name,
                'description' => $p_description,
                'variant' => $p_variant,
                'choices' => $p_choices,
                'hasVariants' => $orderProduct['hasVariants'] ?? false,
                'additional_notes' => $p_additional_notes
            ];

            array_push($line_items, $line_item);
        }
        
        $_tipping_cost = $this->getProperty('_tipping_cost', 0);
        if ($_tipping_cost && $_tipping_cost !== 0) {
            $tippingLabel = esc_html($locales['tip_percentage_summary_label']['primary_lang_'] ?? 'Tip');
            $tipping_percentage = OptionUtil::getInstance()->getOption("tipping_percentage", '');
            $tippingLabel = str_replace("&lt;%= tipPercent %&gt;", $tipping_percentage, $tippingLabel);

            $total += (float)$_tipping_cost;

            $line_item = [
                'type' => 'tipping',
                'quantity' => 1,
                'price' => number_format((float)$_tipping_cost, 2, '.', ''),
                'name' => $tippingLabel,
            ];
            array_push($line_items, $line_item);
        }
        $_delivery_cost = $this->getProperty('_delivery_cost', 0);
        if ($_delivery_cost && $_delivery_cost !== 0) {
            $delivery_fee_label = $locales['delivery_fee_label']['primary_lang_'] ?? esc_html__('Delivery', 'instafood');
            
            $total += (float)$_delivery_cost;

            $line_item = [
                'type' => 'delivery_cost',
                'quantity' => 1,
                'price' => number_format((float)$_delivery_cost, 2, '.', ''),
                'name' => esc_html($delivery_fee_label),
            ];
            array_push($line_items, $line_item);
        }
        return [
            'line_items' => $line_items,
            'total' => number_format((float)$total, 2, '.', ''),
            'currencySymbol' => PriceUtil::getInstance()->getCurrencySymbol(),
            'currencyPosition' => PriceUtil::getInstance()->getCurrencyPosition(),
        ];
    }

    function setStatusPaymentStatus($status) {
        if (!$this->ID) {
            return;
        }
        update_post_meta($this->ID, '_payment_status', Sanitizer::sanitizeInput($status));
        $_orderAll = get_post_meta($this->ID, '_orderAll', true);
        if (is_array($_orderAll)) {
            $_orderAll['_payment_status'] = Sanitizer::sanitizeInput($status);
            update_post_meta($this->ID, '_orderAll', $_orderAll);
        }
    }

    function setStripeReceiptUrl($url) {
        if (!$this->ID) {
            return;
        }
        update_post_meta($this->ID, 'stripe_receipt_url', Sanitizer::sanitizeInput($url));
        $_orderAll = get_post_meta($this->ID, '_orderAll', true);
        if (is_array($_orderAll)) {
            $_orderAll['stripe_receipt_url'] = Sanitizer::sanitizeInput($url);
            update_post_meta($this->ID, '_orderAll', $_orderAll);
        }
    }

    function setOrderStatus($status) {
        if (!$this->ID) {
            return;
        }
        $allowedStatueses = OrderStatus::getAll();
        if (!in_array($status, $allowedStatueses)) {
            return;
        }

        update_post_meta($this->ID, '_orderStatus', Sanitizer::sanitizeInput($status));
        $_orderAll = get_post_meta($this->ID, '_orderAll', true);
        if (is_array($_orderAll)) {
            $_orderAll['_orderStatus'] = Sanitizer::sanitizeInput($status);
            update_post_meta($this->ID, '_orderAll', $_orderAll);
        }

        do_action('instafood_order_status_changed', $this->ID, $status);

        if ($status === OrderStatus::DELIVERED) {
            $this->setStatusPaymentStatus(OrderPaymentStatus::PAID);
        }
        if ($status === OrderStatus::REJECTED) {
            $this->setStatusPaymentStatus(OrderPaymentStatus::PENDING_TRANSACTION);
        }
    }

    function getAllProperties() {
        if (!$this->ID) {
            return;
        }
        $_orderAll = get_post_meta($this->ID, '_orderAll', true);
        $_orderAll = Sanitizer::escapeHtmlFromArray($_orderAll);
        if (is_array($_orderAll)) {
            foreach ($_orderAll as $key => $value) {
                if ($key === '_delivery_info') {
                    $_orderAll[$key] = Sanitizer::escapeHtmlFromArray($value);
                }
            }
            return array_merge($_orderAll, ['ID' => $this->ID]);
        }
        return $_orderAll;
    }
    

    function populate() {
        if (!$this->ID) {
            return;
        }
        $_orderAll = get_post_meta($this->ID, '_orderAll', true);
        if (is_array($_orderAll)) {
            foreach ($_orderAll as $key => $value) {
                $this->{$key} = $value;
            }
        }
    }

    function delete($force_delete = true) {
        if (!$this->ID) {
            return;
        }
        return wp_delete_post($this->ID, $force_delete);
    }

    function hasErrors() {
        return sizeof($this->errors) > 0;
    }

    function getErrors() {
        return $this->errors;
    }

    static function createFromRawData($orderRawData) {
        $order = new Order();
        $order->setRawData($orderRawData)->extractRawData();
        return $order;
    }
}
?>