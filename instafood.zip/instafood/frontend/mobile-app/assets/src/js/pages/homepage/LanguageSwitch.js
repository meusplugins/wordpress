import DataUtils from '../../utils/DataUtils';
import LanguageUtils, { Languages } from '../../utils/LanguageUtils';
import StorageUtil from '../../utils/StorageUtil';

let instance;
const instanceKey = '@(&E_@';

class LanguageSwitch {

    _langSwitchUI;
    _isOpen = false;

    renderTo(componentUI) {
        const _this = this;

        const currentLang = LanguageUtils.getInstance().getLang();
        const currentLangLabel = currentLang === Languages.PRIMARY ? LanguageUtils.getInstance().getLabel('primary_lang_ccode') : LanguageUtils.getInstance().getLabel('secondary_lang_ccode');
        const template = `
            <a href="#" class="lang_switch primary_color">
                <span class="ln_switch icon-chevron-down mr_5"></span><span>${currentLangLabel}</span>
                <div class="lang_switch_ui">
                    <div class="inside">
                        <div class="primary-lang in-section-link border${currentLang === Languages.PRIMARY ? ' selected' : ''}" data-link="section-nav-3">
                            ${LanguageUtils.getInstance().getLabel('primary_lang_ccode')}
                        </div>
                        <div class="secondary-lang in-section-link${currentLang === Languages.SECONDARY ? ' selected' : ''}" data-link="section-nav-5">
                            ${LanguageUtils.getInstance().getLabel('secondary_lang_ccode')}
                        </div>
                    </div>
                </div>
            </a>
        `;
        this._langSwitchUI = jQuery(template);
        this._langSwitchUI.appendTo(componentUI);

        this._langSwitchUI.click(function(event) {
            event.preventDefault();
            if (_this._isOpen) {
                return;
            }
            _this._isOpen = true;
            jQuery(this).find('.lang_switch_ui').css('opacity', 0);
            jQuery(this).find('.lang_switch_ui').show();
            jQuery(this).find('.lang_switch_ui').animate({
                opacity: 1
            }, 300, 'easeInOutQuint');
        })

        this._langSwitchUI.hover(function() {}, function(event) {
            event.preventDefault();
            jQuery(this).find('.lang_switch_ui').hide();
            _this._isOpen = false;
        })

        this._langSwitchUI.find('.primary-lang').click(function(event){
            event.preventDefault();
            StorageUtil.setLanguage(Languages.PRIMARY);
            _this._closeSelect();
        })
        this._langSwitchUI.find('.secondary-lang').click(function(event){
            event.preventDefault();
            StorageUtil.setLanguage(Languages.SECONDARY);
            _this._closeSelect();
        })
    }

    _closeSelect() {
        this._langSwitchUI.find('.lang_switch_ui').animate({
            opacity: 0
        }, 300, 'easeInOutQuint', () => {
            window.location.reload();
        });
    }

    static getInstance() {
        if (!instance) {
            instance = new LanguageSwitch(instanceKey);
        }
        return instance;
    }
}
export default LanguageSwitch;