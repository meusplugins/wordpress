<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . '../../utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');
require_once(plugin_dir_path(__FILE__) . '../guards/Guards.php');

use \com\sakuraplugins\appetit\utils\TimeUtils;
use \com\sakuraplugins\appetit\rest_api\guards\Guards;

class GetPickupDatesController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/pickup-dates', array(
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'getPickupDates'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));

        register_rest_route('instafood', '/shop-open', array(
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'getIsShopOpen'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * retrieve pickup dates
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function getPickupDates(\WP_REST_Request $request) {
        $pickup_dates = TimeUtils::getInstance()->getAllowedPickupDays();
        return ResponseHelper::respond(['pickup_dates' => $pickup_dates]);
    }

    /**
     * verify shop is open now
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function getIsShopOpen(\WP_REST_Request $request) {
        $openResult = TimeUtils::getInstance()->isOpenNow(true);
        return ResponseHelper::respond(['isOpen' => $openResult['isOpen'] ?? false, 'extra' => $openResult]);
    }
    
}
?>