<?php
/**
 * Team Hover Grid integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Team_Hover_Grid extends \WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'team_members';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'name',
			'role',
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'name':
				return __( 'Team Hover Grid: Name', 'happy-addons-pro' );
			case 'role':
				return __( 'Team Hover Grid: Role', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'name':
			case 'role':
				return 'LINE';
			default:
				return '';
		}
	}
}
