<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;


class GeocodeService {

    private $gMapAPIKey;

    function __construct($gMapAPIKey) {
        $this->gMapAPIKey = $gMapAPIKey;
    }

    public function geocode(string $address) {
        $apiKey = $this->gMapAPIKey;

        // url encode the address
        $address = urlencode($address);
        
        // google map geocode api url
        $url = "https://maps.googleapis.com/maps/api/geocode/json?address={$address}&key=$apiKey";
    
        // get the json response
        $resp_json = file_get_contents($url);
        
        // decode the json
        $resp = json_decode($resp_json, true);
        
        // response status will be 'OK', if able to geocode given address 
        if ($resp['status']=='OK') {
            // get the important data
            $lat = isset($resp['results'][0]['geometry']['location']['lat']) ? $resp['results'][0]['geometry']['location']['lat'] : "";
            $lng = isset($resp['results'][0]['geometry']['location']['lng']) ? $resp['results'][0]['geometry']['location']['lng'] : "";
            
            // verify if data is complete
            if ($lat && $lng) {
                // put the data in the array
                $data_arr = array();
                array_push($data_arr, $lat, $lng);
                return $data_arr;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}
?>