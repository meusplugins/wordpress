<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Logged_In extends Base_Condition {

	public function get_key() {
		return 'logged_in';
	}

	public function check( $rule, $context ) {

		$value    = $this->get_rule_value( $rule, 'value', true );
		$expected = (bool) $value;
		$actual   = is_user_logged_in();

		return ( $actual === $expected );
	}
}
