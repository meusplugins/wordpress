import EventBus, { Event, Events } from '../../events/EventBus';
import LanguageUtils from '../../utils/LanguageUtils';
import Order from '../../order/Order';
import DataUtils from '../../utils/DataUtils';

class TermsAgreement {
    _onChnage;
    _selected;
    _parentUI;
    _ui;

    constructor(parentUI, onChnage, selected = false) {
        this._parentUI = parentUI;
        this._onChnage = onChnage;
        this._selected = selected;
        this._selected = Order.getInstance().getUserAcceptedTerms();
    }

    render() {
        const terms_link = DataUtils.getInstance().getOption('terms_link');

        let terms_and_conditions_link_label = LanguageUtils.getInstance().getLabel('terms_and_conditions_link_label');
        let terms_and_conditions = LanguageUtils.getInstance().getLabel('terms_and_conditions_text');
        terms_and_conditions = LanguageUtils.getInstance().decodeHtml(terms_and_conditions);
        const terms_and_conditions_template = _.template(terms_and_conditions);
        const terms_compiled = terms_and_conditions_template({ termsLinkLabel: `<a href="${ terms_link }" class="terms_btn">${terms_and_conditions_link_label}</a>` });

        const template = `
<div class="user_privacy">
    <div class="product_widget apt_no_padding no_background pt_10 pb_10">
        <div class="widget_radio_entry ${ this._selected ? 'selected' : '' }">
            <div class="square_symbol primary_color_border">
                <div class="square_fill primary_color show terms_check_ui"><span class="icon-check"></span></div>
            </div>
            <div class="variant_info">${ terms_compiled }</div>
        </div>
    </div>
</div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._parentUI);
        const _this = this;
        this._ui.click(function(event) {
            event.preventDefault();
            _this._switch();
            return false;
        })
        this._ui.find('.terms_btn').click(function(event) {
            window.open(jQuery(this).attr('href'), '_blank');
            return false;
        });
    }

    _switch() {
        this._selected = this._selected ? false : true;
        this._updateOnChange();
    }

    setSelected(val) {
        this._selected = val;
        this._updateOnChange();
    }

    _updateOnChange() {
        if (this._selected) {
            if (!this._ui.find('.widget_radio_entry').hasClass('selected')) {
                this._ui.find('.widget_radio_entry').addClass('selected')
                this._ui.find('.widget_radio_entry .terms_check_ui').css('display', 'flex');
            }
        } else {
            if (this._ui.find('.widget_radio_entry').hasClass('selected')) {
                this._ui.find('.widget_radio_entry').removeClass('selected');
                this._ui.find('.widget_radio_entry .terms_check_ui').css('display', 'none');
            }
        }
        Order.getInstance().setUserAcceptedTerms(this._selected);
        this._onChnage(this._selected);
    }
}
export default TermsAgreement;