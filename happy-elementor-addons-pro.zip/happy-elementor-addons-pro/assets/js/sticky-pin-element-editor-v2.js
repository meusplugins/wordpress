"use strict";

function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
(function () {
  "use strict";

  // Wait for Elementor V2 editor to be ready
  function initStickyPinV2() {
    if (typeof window.elementorV2 === "undefined" || typeof window.elementorV2.editor === "undefined" || typeof window.elementorV2.editor.injectIntoTop === "undefined") {
      setTimeout(initStickyPinV2, 100);
      return;
    }
    var React = window.React;
    var eV2 = window.elementorV2;
    var UI = eV2.ui;
    var Icons = eV2.icons;
    var Adapters = eV2.editorV1Adapters;
    var config = window.haSplEditorV2Config || {};
    var SECTION_ID = config.sectionId || "_ha_spl_section";
    function getElementTitle(id) {
      try {
        var _window$elementor, _window$elementor$get, _model$get;
        var container = (_window$elementor = window.elementor) === null || _window$elementor === void 0 || (_window$elementor$get = _window$elementor.getContainer) === null || _window$elementor$get === void 0 ? void 0 : _window$elementor$get.call(_window$elementor, id);
        if (!container) return id;
        var model = container.model;
        var widgetType = model.get("widgetType");
        var elType = model.get("elType");
        var title = (_model$get = model.get("settings")) === null || _model$get === void 0 ? void 0 : _model$get.get("_title");
        if (title) return title;
        if (widgetType) {
          var _window$elementor2;
          var widgetCache = (_window$elementor2 = window.elementor) === null || _window$elementor2 === void 0 || (_window$elementor2 = _window$elementor2.widgetsCache) === null || _window$elementor2 === void 0 ? void 0 : _window$elementor2[widgetType];
          return (widgetCache === null || widgetCache === void 0 ? void 0 : widgetCache.title) || widgetType;
        }
        return elType ? elType.charAt(0).toUpperCase() + elType.slice(1) : id;
      } catch (e) {
        return id;
      }
    }
    function scanDocumentForPinned() {
      try {
        var _window$elementor3, _window$elementor3$ge;
        var _traverse = function traverse(model) {
          if (!model) return;
          var settings = model.get("settings");
          if (settings && settings.get("ha_spl_switcher") === "yes") {
            var id = model.get("id");
            var elType = model.get("elType");
            var widgetType = model.get("widgetType");
            var item = {
              id: id,
              type: elType,
              widgetType: widgetType,
              title: getElementTitle(id)
            };
            switch (elType) {
              case "column":
                result.columns.push(item);
                break;
              case "section":
                result.sections.push(item);
                break;
              case "container":
                result.containers.push(item);
                break;
              default:
                result.widgets.push(item);
                break;
            }
          }
          var children = model.get("elements");
          if (children && children.models) {
            children.models.forEach(_traverse);
          }
        };
        var rootContainer = (_window$elementor3 = window.elementor) === null || _window$elementor3 === void 0 || (_window$elementor3$ge = _window$elementor3.getPreviewContainer) === null || _window$elementor3$ge === void 0 ? void 0 : _window$elementor3$ge.call(_window$elementor3);
        if (!rootContainer || !rootContainer.model) {
          return {
            columns: [],
            sections: [],
            widgets: [],
            containers: []
          };
        }
        var result = {
          columns: [],
          sections: [],
          widgets: [],
          containers: []
        };
        _traverse(rootContainer.model);
        return result;
      } catch (e) {
        // eslint-disable-next-line no-console
        console.warn("[HA Sticky Pin V2] Scan error:", e);
        return {
          columns: [],
          sections: [],
          widgets: [],
          containers: []
        };
      }
    }
    function openStickyPinSettings(elementId) {
      try {
        var _window$elementor4, _window$elementor4$ge;
        var container = (_window$elementor4 = window.elementor) === null || _window$elementor4 === void 0 || (_window$elementor4$ge = _window$elementor4.getContainer) === null || _window$elementor4$ge === void 0 ? void 0 : _window$elementor4$ge.call(_window$elementor4, elementId);
        if (!container) return;
        var model = container.model;
        var view = container.view;
        var $e = window.$e;

        // 1. Select the element in the canvas
        if ($e) {
          $e.run("document/elements/select", {
            container: container
          });
        }

        // 2. Open the element editing panel, then switch tab & expand section
        setTimeout(function () {
          try {
            if ($e) {
              // Open the editor panel for this element
              $e.run("panel/editor/open", {
                model: model,
                view: view
              });
            }

            // 3. After panel renders, switch to Advanced tab & expand section
            setTimeout(function () {
              try {
                var _window$elementor5, _window$elementor5$ge, _panel$getCurrentPage, _editor$getControlMod;
                var panel = (_window$elementor5 = window.elementor) === null || _window$elementor5 === void 0 || (_window$elementor5$ge = _window$elementor5.getPanelView) === null || _window$elementor5$ge === void 0 ? void 0 : _window$elementor5$ge.call(_window$elementor5);
                if (!panel) return;
                var editor = (_panel$getCurrentPage = panel.getCurrentPageView) === null || _panel$getCurrentPage === void 0 ? void 0 : _panel$getCurrentPage.call(panel);
                if (!editor) return;

                // Find which tab the section belongs to
                var sectionModel = (_editor$getControlMod = editor.getControlModel) === null || _editor$getControlMod === void 0 ? void 0 : _editor$getControlMod.call(editor, SECTION_ID);
                if (sectionModel) {
                  var targetTab = sectionModel.get("tab");
                  editor.activateTab(targetTab);
                } else {
                  editor.activateTab("advanced");
                }
                editor.activateSection(SECTION_ID);
                editor._renderChildren();

                // Scroll the section into view in the panel
                setTimeout(function () {
                  var _editor$$el, _editor$$el$find;
                  var sectionEl = (_editor$$el = editor.$el) === null || _editor$$el === void 0 || (_editor$$el$find = _editor$$el.find) === null || _editor$$el$find === void 0 ? void 0 : _editor$$el$find.call(_editor$$el, '.elementor-control-section[data-setting="' + SECTION_ID + '"]');
                  if (sectionEl && sectionEl.length) {
                    sectionEl[0].scrollIntoView({
                      behavior: "smooth",
                      block: "start"
                    });
                  }
                }, 50);
              } catch (err) {
                console.warn("[HA Sticky Pin V2] Tab/section error:", err);
              }
            }, 150);
          } catch (err) {
            console.warn("[HA Sticky Pin V2] Panel open error:", err);
          }
        }, 100);
      } catch (e) {
        console.warn("[HA Sticky Pin V2] Navigation error:", e);
      }
    }
    function StickyPinNavigatorDropdown(_ref) {
      var _config$i18n, _config$i18n2, _config$i18n3, _config$i18n4, _config$i18n5, _config$i18n6;
      var pinned = _ref.pinned,
        anchorEl = _ref.anchorEl,
        onClose = _ref.onClose;
      var total = pinned.columns.length + pinned.sections.length + pinned.widgets.length + pinned.containers.length;
      function renderGroup(title, items) {
        if (!items.length) return null;
        return React.createElement(React.Fragment, {
          key: title
        }, React.createElement(UI.Divider, null), React.createElement(UI.Box, {
          sx: {
            px: 2,
            py: 0.5
          }
        }, React.createElement(UI.Typography, {
          variant: "caption",
          color: "text.secondary",
          fontWeight: 600
        }, title + " (" + items.length + ")")), items.map(function (item) {
          return React.createElement(UI.MenuItem, {
            key: item.id,
            onClick: function onClick() {
              onClose();
              openStickyPinSettings(item.id);
            },
            dense: true,
            sx: {
              minWidth: 220
            }
          }, React.createElement(UI.Stack, {
            direction: "row",
            alignItems: "center",
            gap: 1
          }, React.createElement(Icons.PinIcon, {
            fontSize: "small",
            color: "primary"
          }), React.createElement(UI.Typography, {
            variant: "body2",
            noWrap: true,
            sx: {
              maxWidth: 200
            }
          }, item.title)));
        }));
      }
      return React.createElement(UI.Menu, {
        open: Boolean(anchorEl),
        anchorEl: anchorEl,
        onClose: onClose,
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "right"
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "right"
        },
        PaperProps: {
          sx: {
            maxHeight: 420,
            minWidth: 260
          }
        }
      }, React.createElement(UI.Box, {
        sx: {
          px: 2,
          py: 1
        }
      }, React.createElement(UI.Typography, {
        variant: "subtitle2"
      }, ((_config$i18n = config.i18n) === null || _config$i18n === void 0 ? void 0 : _config$i18n.pinnedElements) || "Pinned Elements"), total > 0 ? React.createElement(UI.Typography, {
        variant: "caption",
        color: "text.secondary"
      }, total + " total") : React.createElement(UI.Typography, {
        variant: "caption",
        color: "text.secondary"
      }, ((_config$i18n2 = config.i18n) === null || _config$i18n2 === void 0 ? void 0 : _config$i18n2.noPinned) || "No pinned elements")), renderGroup(((_config$i18n3 = config.i18n) === null || _config$i18n3 === void 0 ? void 0 : _config$i18n3.sections) || "Sections", pinned.sections), renderGroup(((_config$i18n4 = config.i18n) === null || _config$i18n4 === void 0 ? void 0 : _config$i18n4.columns) || "Columns", pinned.columns), renderGroup(((_config$i18n5 = config.i18n) === null || _config$i18n5 === void 0 ? void 0 : _config$i18n5.widgets) || "Widgets", pinned.widgets), renderGroup(((_config$i18n6 = config.i18n) === null || _config$i18n6 === void 0 ? void 0 : _config$i18n6.containers) || "Containers", pinned.containers));
    }
    function StickyPinNavigator() {
      var _config$i18n7, _config$i18n8;
      var _React$useState = React.useState(scanDocumentForPinned),
        _React$useState2 = _slicedToArray(_React$useState, 2),
        pinned = _React$useState2[0],
        setPinned = _React$useState2[1];
      var _React$useState3 = React.useState(null),
        _React$useState4 = _slicedToArray(_React$useState3, 2),
        anchorEl = _React$useState4[0],
        setAnchorEl = _React$useState4[1];
      React.useEffect(function () {
        function refresh() {
          setPinned(scanDocumentForPinned());
        }

        // Listen to settings changes
        var unsubscribe = Adapters.__privateUseListenTo([Adapters.commandEndEvent("document/elements/set-settings"), Adapters.commandEndEvent("document/elements/create"), Adapters.commandEndEvent("document/elements/delete"), Adapters.v1ReadyEvent()], refresh);

        // Also listen to DOM render events from preview iframe
        window.addEventListener("elementor/preview/loaded", refresh);
        return function () {
          unsubscribe();
          window.removeEventListener("elementor/preview/loaded", refresh);
        };
      }, []);
      var total = pinned.columns.length + pinned.sections.length + pinned.widgets.length + pinned.containers.length;
      return React.createElement(React.Fragment, null, React.createElement(UI.Tooltip, {
        title: ((_config$i18n7 = config.i18n) === null || _config$i18n7 === void 0 ? void 0 : _config$i18n7.pinnedElements) || "Pinned Elements",
        arrow: true
      }, React.createElement(UI.IconButton, {
        size: "small",
        onClick: function onClick(event) {
          setAnchorEl(anchorEl ? null : event.currentTarget);
        },
        color: anchorEl ? "primary" : "inherit",
        "aria-label": ((_config$i18n8 = config.i18n) === null || _config$i18n8 === void 0 ? void 0 : _config$i18n8.pinnedElements) || "Pinned Elements"
      }, React.createElement(Icons.PinIcon, {
        fontSize: "small"
      }), total > 0 ? React.createElement(UI.Badge, {
        badgeContent: total,
        color: "primary",
        sx: {
          "& .MuiBadge-badge": {
            fontSize: 10,
            height: 16,
            minWidth: 16
          }
        }
      }) : null)), React.createElement(StickyPinNavigatorDropdown, {
        pinned: pinned,
        anchorEl: anchorEl,
        onClose: function onClose() {
          setAnchorEl(null);
        }
      }));
    }

    // Inject into V2 editor top bar
    eV2.editor.injectIntoTop({
      id: "ha-sticky-pin-navigator",
      component: StickyPinNavigator
    });

    // eslint-disable-next-line no-console
    console.log("[HA Sticky Pin V2] Navigator injected.");
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initStickyPinV2);
  } else {
    initStickyPinV2();
  }
})();