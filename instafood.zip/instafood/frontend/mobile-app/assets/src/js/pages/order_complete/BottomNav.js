import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Events, Event } from '../../events/EventBus';

class BottomNav {
    _parrentUI;
    _ui;
    _onOrderConfChanged;
    _onOrderPaymentChanged;

    _isPlacingOrder = false;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_nav_bottom');
    }
    
    render() {
        const _this = this;
        const template = `
            <div class="cart_nav_bottom">
                <a href="#" class="apt_button primary bottom_close_btn">
                ${ LanguageUtils.getInstance().getLabel('order_complete_bottom_nav') }
                </a>
            </div>
        `;
        jQuery(template).appendTo(this._ui);
        this._ui.find('.bottom_close_btn').click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.CLOSE_ORDER_COMPLETE_SCREEN_REQUEST);
        })
    }
}
export default BottomNav;