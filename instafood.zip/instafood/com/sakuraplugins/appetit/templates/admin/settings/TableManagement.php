<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class TableManagement {
    public function render(): void {
        ?>

        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('QR codes colours', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->_renderQrgeneralColors() ?>
            </div>
        </div>

        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Main QR code', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->_renderGeneralQr() ?>
            </div>
        </div>

        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Tables & QR codes', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->_renderTablesQr() ?>
            </div>
        </div>
        <?php
    }

    private function _renderQrgeneralColors() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Set up the dark and light colours for all QR codes.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Light color', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('colorLight', '#FFFFFF'))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[colorLight]"
                            class="form-control" placeholder="#FFFFFF">
                        <div class="option-entry-info"><?= esc_html__('Ex: #FFFFFF', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Dark color', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('colorDark', '#051e47'))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[colorDark]"
                            class="form-control" placeholder="#051e47">
                        <div class="option-entry-info"><?= esc_html__('Ex: #051e47', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderGeneralQr() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <div class="general_qr_ui">
                            <div id="general_qr"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("The general QR code is being used for delivery and pickup only. It does not hold the table information. As an example, the general QR code can be placed on flyers sent with a previous order.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderTablesQr() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("In order to offer a better user experience, each table has its own QR code, this way the table is being identified automatically when the QR code it's being scanned.As for the restaurant staff to easily identify which QR code to assign to which table, all QR codes images will contain the table number.", 'instafood') ?>
                    </div>
                </div>
            </div>
            <div class="row mb_20">
                <div class="col-md-12">
                    <button type="button" class="btn btn-dark add_table_btn"><?php esc_html_e('Add new table', 'instafood'); ?></button>
                </div>
            </div>

            <div class="qr_tables_ui">
                <?php
                    $qr_tables_no = OptionUtil::getInstance()->getOption('qr_tables_no', []);
                    $qr_tables_desc = OptionUtil::getInstance()->getOption('qr_tables_desc', []);
                    for ($i = 0; $i < sizeof($qr_tables_no); $i++) { 
                        $tableNo = $qr_tables_no[$i] ?? '';
                        $tableDesc = $qr_tables_desc[$i] ?? '';
                        $this->_renderTable($tableNo, $tableDesc);
                    }
                ?>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderTable($tableNo, $tableDesc) {
        ?>
        <div class="row qr_table_entry">
            <div class="apt_hr mt_20 mb_20"></div>
            <div class="col-md-6">
                <div class="apt-option-entry mb_10">
                    <div id="<?= esc_attr(uniqid('_qr_')) ?>" class="qr_canvas_ui"></div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="apt-option-entry mb_10">
                    <label class="option-entry-label"><?= esc_html__('Table no', 'instafood'); ?></label>
                    <input type="number"
                        value="<?= esc_attr($tableNo) ?>" 
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[qr_tables_no][]"
                        class="form-control table_no_input">
                    <div class="option-entry-info"><?= esc_html__('Ex: 1', 'instafood'); ?></div>
                </div>
                <div class="apt-option-entry mb_10">
                    <label class="option-entry-label"><?= esc_html__('Table description/area', 'instafood'); ?></label>
                    <input type="text"
                        value="<?= esc_attr($tableDesc) ?>" 
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[qr_tables_desc][]"
                        class="form-control">
                    <div class="option-entry-info"><?= esc_html__('Ex: Outside', 'instafood'); ?></div>
                </div>
            </div>
        </div>
        <?php
    }
}