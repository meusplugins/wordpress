<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../cpt/ChoiceGroupsCpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/PriceUtil.php');

use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt;
use com\sakuraplugins\appetit\utils\PriceUtil;


class ChoiceGroupsService {

    private static $instance = null;
    private $groups = [];
    private $choices = [];

    public function getGroups() {
        if (isset($this->groups) && is_array($this->groups) && sizeof($this->groups) > 0) {
            return $this->groups;
        }
        $all_groups_args = [
            'posts_per_page' => -1,
            'post_type'      => ChoiceGroupsCpt::getPostType(),
            'post_status'    => 'publish',
        ];
        $all_groups_query = new \WP_Query($all_groups_args);
        if ($all_groups_query->have_posts()) {
            while ($all_groups_query->have_posts()) {
                $all_groups_query->the_post();
                global $post;

                
                $post_meta = get_post_meta($post->ID, ChoiceGroupsCpt::getMetaKey(), true);
                if (!is_array($post_meta)) {
                    $post_meta = [];
                }
                array_push($this->groups, [
                    'ID' => get_the_ID(),
                    'title' => get_the_title(),
                    'post_meta' => $post_meta
                ]);
            }
        }
        wp_reset_postdata();
        wp_reset_query();
        return $this->groups;
    }

    public function getAllChoices() {
        if (isset($this->choices) && is_array($this->choices) && sizeof($this->choices) > 0) {
            return $this->choices;
        }
        $allChoices = get_terms(['taxonomy' => ChoiceGroupsCpt::CHOICE_SLUG, 'hide_empty' => FALSE, 'parent' => 0]);

        if (is_array($allChoices) && sizeof($allChoices) > 0) {
            foreach ($allChoices as $choice) {
                $term_meta = get_term_meta($choice->term_id, ChoiceGroupsCpt::CHOICE_META_KEY, true);
                if (isset($term_meta) && is_array($term_meta)) {
                    if (isset($term_meta['choice_price'])) {
                        $term_meta['price_display'] = PriceUtil::getInstance()->getPriceDisplay($term_meta['choice_price']);
                    } else {
                        $term_meta['price_display'] = PriceUtil::getInstance()->getPriceDisplay(0);
                    }
                    $result = array_merge((array) $choice, $term_meta);
                    array_push($this->choices, $result);
                }
            }
        }
        return $this->choices;
    }

    function getChoice($choiceId) {
        $choice = get_term($choiceId, ChoiceGroupsCpt::CHOICE_SLUG);
        $choice->term_meta = get_term_meta($choice->term_id, ChoiceGroupsCpt::CHOICE_META_KEY, true);
        return $choice ? $choice : false;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new ChoiceGroupsService();
        }
        return self::$instance;
    }
}
?>