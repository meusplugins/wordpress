<?php
namespace com\sakuraplugins\appetit\rest_api\guards;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'IGuard.php');
require_once(plugin_dir_path(__FILE__) . 'BaseGuard.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/OptionUtil.php');

use com\sakuraplugins\appetit\utils\OptionUtil;

class RecaptchaGuard extends BaseGuard implements IGuard {

    public static function validateRequest(\WP_REST_Request $request) {

        if (!OptionUtil::getInstance()->hasReCaptcha()) {
            return true;
        }
        $token = $request->get_param('recaptcha_token');
        $recaptcha_secret_key = trim(OptionUtil::getInstance()->getOption('recaptcha_secret_key', ''));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('secret' => trim($recaptcha_secret_key), 'response' => $token)));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        $arrResponse = json_decode($response, true);

        if( $arrResponse["success"] == '1' && $arrResponse["action"] == 'submit' && $arrResponse["score"] >= 0.5 ) {
            // valid submission
            return true;
        }
        
        return new \WP_REST_Response([
            'status' => 'FAIL',
            'data' => [],
            'errors' => [esc_html__('Google reCaptcha error', 'instafood')],
        ], 200);
    }
}
?>