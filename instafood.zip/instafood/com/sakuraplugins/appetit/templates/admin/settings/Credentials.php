<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class Credentials {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Google Maps & Geocoding', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderGoogleMapsCredentials() ?>
            </div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Stripe', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderStripeCredentials() ?>
            </div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Google reCaptcha', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderReCaptchaCredentials() ?>
            </div>
        </div>
        <?php
    }

    private function renderGoogleMapsCredentials() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Google API Key', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('gmap_api_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[gmap_api_key]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Both Geocoding API and Maps JavaScript API must be enabled within the Google cloud console. The API Key will be used to get the restaurant geo-coordinates within the Admin General settings and for delivery, this way the max delivery distance can be determined when a user places an order (delivery). This API Key is optional, if left empty the max delivery radius won't be required.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderStripeCredentials() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Stripe publishable key', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('stripe_public_api_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[stripe_public_api_key]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Stripe secret key', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('stripe_secret_api_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[stripe_secret_api_key]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Stripe webhook endpoint secret', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('stripe_endpoint_secret', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[stripe_endpoint_secret]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Stripe webhook endpoint URL', 'instafood'); ?></label>
                        <div><?= esc_url_raw(rest_url() . 'instafood/stripe-webhook') ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("The Stripe API will be used to process payments.", 'instafood') ?>
                    </div>
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("A webhook enables Stripe to push real-time notifications to the application, as an example, an order is marked as paid based on events received from Stripe. Find out more within the documentation.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderReCaptchaCredentials() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Google reCaptcha site key', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('recaptcha_site_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[recaptcha_site_key]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Google reCaptcha secret key', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('recaptcha_secret_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[recaptcha_secret_key]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("reCAPTCHA uses an advanced risk analysis engine and adaptive challenges to keep malicious software from engaging in abusive activities on your website. Meanwhile, legitimate users will be able to login, make purchases, view pages, or create accounts and fake users will be blocked. ReCaptcha credentials are optional.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }
}