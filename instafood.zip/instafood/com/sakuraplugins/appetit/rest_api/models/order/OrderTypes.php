<?php
namespace com\sakuraplugins\appetit\rest_api\models;
if (!defined('ABSPATH')) exit;

abstract class OrderTypes {
    const DELIVERY = 'DELIVERY';
    const PICKUP = 'PICKUP';
    const DINEIN = 'DINEIN';

    static function getAll() {
        return [self::DELIVERY, self::PICKUP, self::DINEIN];
    }

    static function getMappedToLabels() {
        return [
            self::DELIVERY => esc_html__('Delivery', 'instafood'),
            self::PICKUP => esc_html__('Pickup', 'instafood'),
            self::DINEIN => esc_html__('Dine-in', 'instafood'),
        ];
    }
}
?>