<?php
/*
 * Page Name: Settings
 */

use HerdEffectsPro\Admin\CreateFields;

defined( 'ABSPATH' ) || exit;

$page_opt = include( 'options/4.settings.php' );
$field    = new CreateFields( $options, $page_opt );
$id       = $options['id'] ?? '';

?>


    <div class="wpie-fieldset">
        <div class="wpie-legend"><?php esc_html_e( 'Link', 'wow-herd-effects-pro' ); ?></div>
        <div class="wpie-fields">
			<?php $field->create( 'herd_link' ); ?>
			<?php $field->create( 'link_target' ); ?>
			<?php $field->create( 'click_link' ); ?>
        </div>
    </div>

    <div class="wpie-fieldset">
        <div class="wpie-legend"><?php esc_html_e( 'Show', 'wow-herd-effects-pro' ); ?></div>
        <div class="wpie-fields">
			<?php $field->create( 'sec_step' ); ?>
			<?php $field->create( 'speed' ); ?>
			<?php $field->create( 'speed_min' ); ?>
			<?php $field->create( 'speed_max' ); ?>
        </div>
        <div class="wpie-fields">
	        <?php $field->create( 'auto_close' ); ?>
	        <?php $field->create( 'number' ); ?>
        </div>
    </div>

    <div class="wpie-fieldset">
        <div class="wpie-legend"><?php esc_html_e( 'Animation', 'wow-herd-effects-pro' ); ?></div>
        <div class="wpie-fields">
			<?php $field->create( 'window_animate' ); ?>
			<?php $field->create( 'window_animate_out' ); ?>
        </div>
    </div>

<?php
