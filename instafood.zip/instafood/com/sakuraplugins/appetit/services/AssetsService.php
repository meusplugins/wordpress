<?php
namespace com\sakuraplugins\appetit\services;
require_once(plugin_dir_path(__FILE__) . '../cpt/MenuItemCpt.php');
require_once(plugin_dir_path(__FILE__) . '../cpt/ChoiceGroupsCpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class AssetsService {
    static function loadAdminMainCss() {
        wp_enqueue_style('appetit-admin-css-main', INSTAFOOD_QR_BASE_URL . '/assets/admin/css/main.css');
    }

    static function loadBootstrapCss() {
        wp_enqueue_style('bootstrap.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/bootstrap/css/bootstrap.min.css');
    }

    static function loadSelect2All() {
        wp_enqueue_script('select2.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/select2/select2.min.js', ['jquery'], 'v1', true);
        wp_enqueue_style('select2.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/select2/select2.min.css');
    }

    static function loadToastr() {
        wp_enqueue_script('toastr.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/toastr/toastr.min.js', ['jquery'], 'v1', true);
        wp_enqueue_style('toastr.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/toastr/toastr.min.css');
    }

    static function loadBootstrapJS() {
        wp_enqueue_script('bootstrap.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/bootstrap/js/bootstrap.min.js', ['jquery'], 'v1', true);
    }

    static function loadBootstrapAll() {
        self::loadBootstrapCss();
        self::loadBootstrapJS();
    }

    static function loadLodash() {
        wp_enqueue_script('lodash', INSTAFOOD_QR_BASE_URL . '/assets/vendor/lodash/lodash.js', ['jquery'], 'v1', true);
    }

    static function loadIconFonts() {
        wp_enqueue_style('appetit-icon-font', INSTAFOOD_QR_BASE_URL . '/assets/vendor/icon-font/style.css');
    }

    static function loadMenuItemAssets() {
        self::loadBootstrapAll();
        self::loadLodash();
        self::loadSelect2All();
        self::loadToastr();
        self::loadIconFonts();

        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-selectable');


        wp_enqueue_script('media-upload-utils', INSTAFOOD_QR_BASE_URL . '/assets/admin/js/media-upload-utils.js', ['jquery'], 'v1', true);
        
        
        wp_register_script('menu-item', INSTAFOOD_QR_BASE_URL . '/assets/admin/js/menu-item.js', ['jquery'], 'v1', true);
        wp_localize_script('menu-item', 'APPETIT_ITEM', [
            'locales' => [
                'price' => esc_html__('Price', 'instafood'),
                'v_name' => esc_html__('Variation name', 'instafood'),
                'v_name_1' => esc_html__('Variation name (secondary language)', 'instafood'),
                'delete' => esc_html__('Delete', 'instafood'),
                'variation_name_example' => esc_html__('Example: Small, Medium, Large', 'instafood'),
                'group_exists' => esc_html__('Group already added!', 'instafood'),
                'group_successfully_added' => esc_html__('Group successfully added', 'instafood'),
            ],
            'post_meta_key' => \com\sakuraplugins\appetit\cpt\MenuItemCpt::getMetaKey(),
        ]);
        wp_enqueue_script('menu-item');
    }

    static function loadChoiceGroupAssets() {
        self::loadBootstrapAll();
        self::loadLodash();
        self::loadSelect2All();
        self::loadToastr();

        wp_register_script('choice-group', INSTAFOOD_QR_BASE_URL . '/assets/admin/js/choice-group.js', ['jquery'], 'v1', true);
        wp_localize_script('choice-group', 'APPETIT_CHOICE_GROUP', [
            'locales' => [
                'delete' => esc_html__('Delete', 'instafood'),
                'choice_exists' => esc_html__('Choice already added!', 'instafood'),
                'choice_successfully_added' => esc_html__('Choice successfully added', 'instafood'),
                'select' => esc_html__('Select', 'instafood'),
                'group_min_max_error' => esc_html__('The minimum number of choices can not be less than the maximum number of choices.', 'instafood'),
            ],
            'post_meta_key' => \com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt::getMetaKey(),
        ]);
        wp_enqueue_script('choice-group');
    }

    static function loadAdminSettingsAssets() {
        self::loadBootstrapAll();
        self::loadLodash();
        self::loadSelect2All();
        self::loadToastr();
        self::loadIconFonts();

        wp_enqueue_media();

        wp_enqueue_script('media-upload-utils', INSTAFOOD_QR_BASE_URL . '/assets/admin/js/media-upload-utils.js', ['jquery'], 'v1', true);
        wp_enqueue_script('easy.qrcode.min', INSTAFOOD_QR_BASE_URL . '/assets/vendor/easy.qrcode/easy.qrcode.min.js', ['appetit-settings'], 'v1', true);


        $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
        $mobileAppPageUrl = get_permalink($mobileAppPageId);

        $orders_css = '/com/sakuraplugins/appetit/templates/admin/orders_management/orders_assets/dist/css/index.css';
        wp_enqueue_style('orders_management_css', INSTAFOOD_QR_BASE_URL . $orders_css);

        wp_register_script('appetit-settings', INSTAFOOD_QR_BASE_URL . '/assets/admin/js/appetit-settings.js', ['jquery'], 'v1', true);
        wp_localize_script('appetit-settings', 'APPETIT_SETTINGS', [
            'locales' => [
                'start' => esc_html__('Shift start', 'instafood'),
                'stop' => esc_html__('Shift stop', 'instafood'),
                'am' => esc_html__('AM', 'instafood'),
                'pm' => esc_html__('PM', 'instafood'),
                'restaurant_empty_address' => esc_html__("In order to geo-code, address must not be empty.", 'instafood'),
                'restaurant_geocode_error' => esc_html__("Geocode was not successful for the following reason:", 'instafood'),
                'restaurant_geocode_success' => esc_html__("Goe-code updated", 'instafood'),
                'qr_code_download' => esc_html__("Download", 'instafood'),
                'qr_delete_table' => esc_html__("Delete table", 'instafood'),
                'table_no' => esc_html__('Table no', 'instafood'),
                'table_no_ex' => esc_html__('Ex: 1', 'instafood'),
                'table_description' => esc_html__('Table description/area', 'instafood'),
                'table_description_ex' => esc_html__('Ex: Outside', 'instafood'),
                'table_delete_warn' => esc_html__('Are you sure you want to delete the table?', 'instafood'),
            ],
            'options' => [
                'colorLight' => OptionUtil::getInstance()->getOption('colorLight', '#FFFFFF'),
                'colorDark' => OptionUtil::getInstance()->getOption('colorDark', '#FFFFFF'),
                'mobileAppPageUrl' => $mobileAppPageUrl ? $mobileAppPageUrl : '/',
                'options_group_slug' => Config::getOptionsGroupSlug()
            ]
        ]);
        wp_enqueue_script('appetit-settings');
        $gmapAPIKey = trim(OptionUtil::getInstance()->getOption('gmap_api_key', ''));
        if ($gmapAPIKey !== '') {
            self::enqueueRemoteScript('google-maps', '://maps.googleapis.com/maps/api/js?key=' . $gmapAPIKey . '&libraries=&callback=initAdminGmap', ['appetit-settings']);
        }
    }

    static function loadAdminOrdersManagementAssets() {
        wp_enqueue_script('jquery');
        
        self::loadBootstrapAll();
        self::loadAdminMainCss();
        self::loadLodash();
        self::loadToastr();
        self::loadIconFonts();

        $orders_css = '/com/sakuraplugins/appetit/templates/admin/orders_management/orders_assets/dist/css/index.css';
        wp_enqueue_style('orders_management_css', INSTAFOOD_QR_BASE_URL . $orders_css);

        $html2pdf = '/com/sakuraplugins/appetit/templates/admin/orders_management/orders_assets/dist/vendor/html2pdf.bundle.min.js';
        wp_register_script('html2pdf', INSTAFOOD_QR_BASE_URL . $html2pdf, ['jquery'], 'v1', true);
        wp_enqueue_script('html2pdf');

        $orders_js = '/com/sakuraplugins/appetit/templates/admin/orders_management/orders_assets/dist/js/index.js';
        wp_register_script('orders_management_js', INSTAFOOD_QR_BASE_URL . $orders_js, ['jquery'], 'v1', true);
        wp_enqueue_script('orders_management_js');
    }

    static function enqueueRemoteScript($key, $url, $dependsOf = []) {
        $protocol = is_ssl() ? 'https' : 'http';
        wp_enqueue_script($key, $protocol . $url, $dependsOf, '3', true);
    }

    static function enqueueRemoteStyle($key, $url) {
        $protocol = is_ssl() ? 'https' : 'http';
        wp_enqueue_style($key, $protocol . $url);
    }
}
?>