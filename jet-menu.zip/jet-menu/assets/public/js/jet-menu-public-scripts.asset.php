<?php return array('dependencies' => array(), 'version' => 'b8e3da6a91f8af5f9bc5');
