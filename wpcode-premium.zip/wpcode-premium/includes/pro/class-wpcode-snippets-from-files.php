<?php
/**
 * The Manage Snippets from Files mode.
 *
 * With WPCODE_SNIPPETS_FROM_FILES defined as true, the files in the snippets directory are the source of
 * truth for PHP, HTML, Universal, CSS, JS and SCSS snippets and the database is a read-only mirror. This
 * class owns the mode: it decides before any snippet executes whether this request imports and which snippets
 * must not run before the import, refuses every write to a managed snippet that does not come from the
 * importer or the exporter at the same gates the remote-only mode uses, keeps the admin informative (read-only
 * editor, file names in the list, sync errors) and offers a Sync now action.
 *
 * @package WPCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_Snippets_From_Files.
 */
class WPCode_Snippets_From_Files {

	const SYNC_ACTION = 'sync_snippet_files';
	const SYNC_NONCE  = 'wpcode_sync_snippet_files';

	/**
	 * Mirrors whose file changed in this request: they must not run before the import re-reads them.
	 *
	 * @var int[]
	 */
	protected static $skip_ids = array();

	/**
	 * The message of a write this request refused, shown on the page that re-renders after it.
	 *
	 * @var string
	 */
	protected static $last_refusal = '';

	/**
	 * Whether the mode is on.
	 *
	 * @return bool
	 */
	public static function enabled() {
		return WPCode_Snippets_File_Sync::mode_enabled();
	}

	/**
	 * Whether the current write comes from a trusted writer rather than a user or another process.
	 *
	 * @return bool
	 */
	public static function is_trusted_context() {
		return WPCode_Snippets_File_Sync::is_trusted_context();
	}

	/**
	 * The relative file name of a managed snippet, or an empty string.
	 *
	 * @param int $snippet_id The snippet id.
	 *
	 * @return string
	 */
	public static function file_for( $snippet_id ) {
		$snippet_id = absint( $snippet_id );

		return $snippet_id ? (string) get_post_meta( $snippet_id, WPCode_Snippets_File_Sync::META_FILE, true ) : '';
	}

	/**
	 * Whether a snippet is managed from a file.
	 *
	 * @param WPCode_Snippet|int $snippet The snippet or its id.
	 *
	 * @return bool
	 */
	public static function is_managed( $snippet ) {
		$id = $snippet instanceof WPCode_Snippet ? (int) $snippet->get_id() : absint( $snippet );

		return $id > 0 && '' !== self::file_for( $id );
	}

	/**
	 * Whether a managed snippet's file has been removed, which makes the mirror deletable locally.
	 *
	 * @param int $snippet_id The snippet id.
	 *
	 * @return bool
	 */
	public static function is_file_missing( $snippet_id ) {
		return (bool) get_post_meta( absint( $snippet_id ), WPCode_Snippets_File_Sync::META_MISSING, true );
	}

	/**
	 * Whether an existing snippet is of a file-managed type but has no file yet: untrashed by a user, or its
	 * export failed. The next sync writes its file; until then it is read-only too.
	 *
	 * @param WPCode_Snippet $snippet The snippet.
	 *
	 * @return bool
	 */
	public static function awaits_export( $snippet ) {
		if ( ! self::enabled() || ! $snippet instanceof WPCode_Snippet || ! $snippet->get_id() || self::is_managed( $snippet ) ) {
			return false;
		}
		$stored = wpcode_get_snippet( $snippet->get_id() );

		return WPCode_Snippet_File::is_file_type( $stored->get_code_type() );
	}

	/**
	 * The refusal message for an existing managed snippet.
	 *
	 * @return string
	 */
	public static function mode_message() {
		return __( 'This snippet is managed from a file on the server. Edit the file and it will sync on the next request.', 'wpcode-premium' );
	}

	/**
	 * The refusal message for a new snippet of a file-managed type.
	 *
	 * @return string
	 */
	public static function new_snippet_message() {
		return sprintf(
			/* translators: %s: the snippets directory. */
			__( 'PHP, HTML, Universal, CSS, JS and SCSS snippets on this site are added as files in %s. Create the file there and it will sync on the next request.', 'wpcode-premium' ),
			self::display_dir()
		);
	}

	/**
	 * The refusal message for an existing file-type snippet that has no file yet.
	 *
	 * @return string
	 */
	public static function awaiting_export_message() {
		if ( ! WPCode_Snippets_File_Sync::file_writes_allowed() ) {
			return sprintf(
				/* translators: %s: the snippets directory. */
				__( 'This snippet is of a type managed from files on this site but has no file yet. Run "wp wpcode snippets export" to write it to %s, then edit it there.', 'wpcode-premium' ),
				self::display_dir()
			);
		}

		return sprintf(
			/* translators: %s: the snippets directory. */
			__( 'This snippet is of a type managed from files on this site but has no file yet. The next sync writes it to %s; edit it there.', 'wpcode-premium' ),
			self::display_dir()
		);
	}

	/**
	 * The snippets directory shown to users: relative to the WordPress root or the content directory's parent,
	 * or the constant's name when it lives elsewhere, so an absolute server path is never printed.
	 *
	 * @return string
	 */
	public static function display_dir() {
		$dir = WPCode_Snippets_File_Handler::get_snippets_dir();
		foreach ( array( ABSPATH, dirname( WP_CONTENT_DIR ) ) as $root ) {
			$root = trailingslashit( wp_normalize_path( $root ) );
			if ( 0 === strpos( $dir, $root ) ) {
				return substr( $dir, strlen( $root ) );
			}
		}

		return 'WPCODE_SNIPPETS_DIR/';
	}

	/**
	 * A managed snippet's file, shown relative like display_dir(), or an empty string.
	 *
	 * @param WPCode_Snippet|int $snippet The snippet or its id.
	 *
	 * @return string
	 */
	public static function display_file( $snippet ) {
		$file = self::file_for( $snippet instanceof WPCode_Snippet ? (int) $snippet->get_id() : absint( $snippet ) );

		return '' === $file ? '' : self::display_dir() . $file;
	}

	/**
	 * One sentence summarizing a sync report, shared by every surface that shows the last sync.
	 *
	 * @param array $report The report.
	 *
	 * @return string
	 */
	public static function report_summary( $report ) {
		$count = function ( $key ) use ( $report ) {
			return isset( $report[ $key ] ) && is_array( $report[ $key ] ) ? count( $report[ $key ] ) : 0;
		};

		return sprintf(
			/* translators: 1: imported files count, 2: exported files count, 3: removed files count, 4: errors count. */
			__( '%1$d imported, %2$d exported, %3$d removed, %4$d with errors.', 'wpcode-premium' ),
			$count( 'imported' ),
			$count( 'exported' ),
			$count( 'removed' ),
			$count( 'errors' ) + $count( 'export_errors' ) + ( empty( $report['export_error'] ) ? 0 : 1 )
		);
	}

	/**
	 * The nonce'd Sync now URL.
	 *
	 * @return string
	 */
	public static function sync_now_url() {
		$url = add_query_arg(
			array(
				'page'          => 'wpcode-settings',
				'view'          => 'general',
				'wpcode_action' => self::SYNC_ACTION,
			),
			admin_url( 'admin.php' )
		);

		return wp_nonce_url( $url, self::SYNC_NONCE );
	}

	/**
	 * Why a library deploy onto a local snippet is refused in the mode, or an empty string to allow it. The
	 * local target decides first; for a new snippet the payload must name a type that is not file-managed.
	 *
	 * @param array $cloud_snippet The snippet data from the library.
	 * @param int   $local_id      The local snippet the deploy would update, 0 for a new one.
	 *
	 * @return string
	 */
	public static function library_deploy_refusal( $cloud_snippet, $local_id ) {
		if ( ! self::enabled() ) {
			return '';
		}
		if ( self::is_managed( (int) $local_id ) ) {
			return __( 'This snippet is managed from a file on this site. Deploying from the library is not available for it.', 'wpcode-premium' );
		}
		if ( empty( $cloud_snippet['code_type'] ) || WPCode_Snippet_File::is_file_type( $cloud_snippet['code_type'] ) ) {
			return __( 'Snippets of this type are managed from files on this site. Deploying from the library is not available for them.', 'wpcode-premium' );
		}

		return '';
	}

	/**
	 * Why saving a local snippet to the library, or removing it from there, is refused in the mode: both write
	 * the cloud id back to the mirror, which a managed snippet does not accept. Empty string to allow.
	 *
	 * @param int $snippet_id The local snippet.
	 *
	 * @return string
	 */
	public static function cloud_refusal( $snippet_id ) {
		if ( ! self::enabled() || ! self::is_managed( (int) $snippet_id ) ) {
			return '';
		}

		return __( 'This snippet is managed from a file on this site. Library actions are not available for it.', 'wpcode-premium' );
	}

	/**
	 * Whether this request is the Sync now action: an admin page request for the settings page carrying the
	 * action. The nonce and capability are checked by the handler; this test only decides what runs before it,
	 * at a point where neither can be checked without resolving the user. A request that fails them dies
	 * before rendering anything, so skipping its snippets has no visible effect.
	 *
	 * @return bool
	 */
	protected static function is_sync_now_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- verified in maybe_handle_sync_now().
		if ( ! is_admin() || wp_doing_ajax() || ! isset( $_GET['page'], $_GET['wpcode_action'] ) ) {
			return false;
		}

		return 'wpcode-settings' === sanitize_key( wp_unslash( $_GET['page'] ) ) && self::SYNC_ACTION === sanitize_key( wp_unslash( $_GET['wpcode_action'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Constructor: hooks only when the mode is on.
	 */
	public function __construct() {
		if ( ! self::enabled() ) {
			return;
		}

		// Every write path: save(), raw post writes, trash, untrash and delete.
		add_filter( 'wpcode_pre_save_snippet', array( $this, 'block_local_save' ), 5, 2 );
		add_filter( 'wp_insert_post_empty_content', array( $this, 'block_local_post_writes' ), 5, 2 );
		add_filter( 'pre_trash_post', array( $this, 'block_local_delete' ), 5, 2 );
		add_filter( 'pre_untrash_post', array( $this, 'block_local_delete' ), 5, 2 );
		add_filter( 'pre_delete_post', array( $this, 'block_local_delete' ), 5, 2 );
		add_action( 'untrashed_post', array( $this, 'export_after_untrash' ) );

		// Components load at -1: the decision whether this request syncs must be taken before them.
		add_action( 'plugins_loaded', array( $this, 'schedule_sync' ), - 2 );
		add_filter( 'wpcode_skip_snippet_execution', array( $this, 'skip_pending_snippets' ), 10, 2 );
		add_action( 'wpcode_snippet_error_tracked', array( $this, 'remember_error_hash' ), 10, 2 );

		// Admin.
		add_action( 'wpcode_admin_notices', array( $this, 'render_notices' ) );
		add_filter( 'wpcode_code_snippets_table_column_value', array( $this, 'table_column' ), 10, 3 );
		add_filter( 'wpcode_snippet_manager_is_read_only', array( $this, 'editor_read_only' ), 10, 2 );
		add_filter( 'wpcode_snippet_manager_read_only_message', array( $this, 'editor_message' ), 10, 2 );
		add_filter( 'wpcode_code_type_options', array( $this, 'editor_code_types' ), PHP_INT_MAX );
		add_filter( 'wpcode_code_types_for_display', array( $this, 'editor_code_types' ), PHP_INT_MAX );
		add_filter( 'wpcode_show_testing_mode_toggle', '__return_false' );
		add_filter( 'wpcode_snippets_bulk_action_refusal', array( $this, 'bulk_refusal' ), 10, 3 );
		add_action( 'admin_init', array( $this, 'maybe_handle_sync_now' ) );
	}

	/**
	 * Refuse WPCode_Snippet::save() outside the importer and exporter for managed snippets, for existing
	 * file-type snippets that await their file, and for new snippets of a file-managed type.
	 *
	 * @param int|false      $pre_save The short-circuit value.
	 * @param WPCode_Snippet $snippet  The snippet being saved.
	 *
	 * @return int|false
	 */
	public function block_local_save( $pre_save, $snippet ) {
		if ( false !== $pre_save || self::is_trusted_context() ) {
			return $pre_save;
		}
		if ( self::is_managed( $snippet ) ) {
			$message = self::mode_message();
		} elseif ( self::awaits_export( $snippet ) ) {
			$message = self::awaiting_export_message();
		} elseif ( WPCode_Snippet_File::is_file_type( $snippet->get_code_type() ) ) {
			$message = self::new_snippet_message();
		} else {
			return $pre_save;
		}

		self::$last_refusal = $message;
		wpcode()->error->add_error(
			array(
				'message' => $message,
				'type'    => 'permissions',
			)
		);
		// Callers read $active to learn whether the status changed: report the stored status, so nothing did.
		$snippet->active = $snippet->get_id() > 0 && 'publish' === get_post_status( $snippet->get_id() );

		return 0;
	}

	/**
	 * Abort raw wp_insert_post()/wp_update_post() writes to a managed snippet, unless its file is gone: the
	 * list trashes through wp_update_post(), and an orphan may be trashed or deleted locally.
	 *
	 * @param bool  $maybe_empty Whether WordPress should treat the post as empty and abort.
	 * @param array $postarr     The post data.
	 *
	 * @return bool
	 */
	public function block_local_post_writes( $maybe_empty, $postarr ) {
		if ( $maybe_empty || empty( $postarr['post_type'] ) || wpcode_get_post_type() !== $postarr['post_type'] ) {
			return $maybe_empty;
		}
		if ( empty( $postarr['ID'] ) || self::is_trusted_context() || ! self::is_managed( (int) $postarr['ID'] ) ) {
			return $maybe_empty;
		}
		if ( self::is_file_missing( (int) $postarr['ID'] ) ) {
			return $maybe_empty;
		}

		return true;
	}

	/**
	 * Abort trash, untrash and delete of a managed snippet, unless its file is gone.
	 *
	 * @param null|mixed $delete The short-circuit value.
	 * @param WP_Post    $post   The post.
	 *
	 * @return null|false
	 */
	public function block_local_delete( $delete, $post ) {
		if ( null !== $delete || ! $post instanceof WP_Post || wpcode_get_post_type() !== $post->post_type ) {
			return $delete;
		}
		if ( self::is_trusted_context() || ! self::is_managed( $post->ID ) || self::is_file_missing( $post->ID ) ) {
			return $delete;
		}

		return false;
	}

	/**
	 * An untrashed file-type snippet without a file gets one on the next sync; ask for that sync now.
	 *
	 * @param int $post_id The untrashed post.
	 *
	 * @return void
	 */
	public function export_after_untrash( $post_id ) {
		if ( wpcode_get_post_type() !== get_post_type( $post_id ) || self::is_managed( (int) $post_id ) ) {
			return;
		}
		if ( WPCode_Snippet_File::is_file_type( wpcode_get_snippet( (int) $post_id )->get_code_type() ) ) {
			WPCode_Snippets_File_Sync::request_export();
		}
	}

	/**
	 * Decide, before WPCode's components load, whether this request imports. Only the request that holds the
	 * lock imports, at init, after core has resolved the current user (writing posts earlier would pre-empt
	 * other plugins' determine_current_user filters). In that request the snippets whose files changed do not
	 * run before the import: the import's activation check runs the changed code once, and running the old
	 * file as well would redeclare its functions. Every other snippet runs as usual, and once the import has
	 * run the hold is lifted for the types whose code never executes in an activation check. When there are
	 * files but no manifest to tell which changed, nothing auto-inserts. The Sync now request and
	 * "wp wpcode snippets ..." import through their own handlers after snippets have already executed, so they
	 * turn auto insert off altogether.
	 *
	 * @return void
	 */
	public function schedule_sync() {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			if ( self::is_snippets_command() ) {
				add_filter( 'wpcode_do_auto_insert', '__return_false' );
			}

			return;
		}

		if ( self::is_sync_now_request() ) {
			add_filter( 'wpcode_do_auto_insert', '__return_false' );

			return;
		}

		$pending = WPCode_Snippets_File_Sync::pending();
		if ( null === $pending || ! WPCode_Snippets_File_Sync::claim_lock() ) {
			return;
		}

		if ( $pending['all'] ) {
			add_filter( 'wpcode_do_auto_insert', '__return_false' );
		} elseif ( ! empty( $pending['ids'] ) ) {
			self::$skip_ids = $pending['ids'];
			// Last, so nothing added to a location later in the chain puts a held snippet back.
			add_filter( 'wpcode_get_snippets_for_location', array( $this, 'remove_pending_snippets' ), PHP_INT_MAX );
		}
		add_action( 'init', array( 'WPCode_Snippets_File_Sync', 'maybe_sync' ), 20 );
		add_action( 'init', array( $this, 'release_held_snippets' ), 21 );
	}

	/**
	 * Whether the current WP-CLI process runs "wp wpcode snippets ...": the first two positional arguments,
	 * after any global flags and alias.
	 *
	 * @return bool
	 */
	protected static function is_snippets_command() {
		$positional = array();
		foreach ( array_slice( isset( $GLOBALS['argv'] ) ? (array) $GLOBALS['argv'] : array(), 1 ) as $arg ) {
			if ( 0 !== strpos( (string) $arg, '-' ) && 0 !== strpos( (string) $arg, '@' ) ) {
				$positional[] = $arg;
			}
		}

		return array( 'wpcode', 'snippets' ) === array_slice( $positional, 0, 2 );
	}

	/**
	 * After the import, only the snippets whose code the activation check ran stay held; the others (HTML,
	 * CSS, JS, SCSS) render their freshly imported code for the rest of the request.
	 *
	 * @return void
	 */
	public function release_held_snippets() {
		self::$skip_ids = array();
	}

	/**
	 * Ids that must not run in this request: mirrors whose file changed (until the import re-reads them) and
	 * snippets the import's activation check already ran.
	 *
	 * @return int[]
	 */
	protected static function held_ids() {
		return array_merge( self::$skip_ids, WPCode_Snippets_File_Sync::executed_ids() );
	}

	/**
	 * Drop held snippets from an auto-insert location before they run.
	 *
	 * @param WPCode_Snippet[] $snippets The snippets for the location.
	 *
	 * @return WPCode_Snippet[]
	 */
	public function remove_pending_snippets( $snippets ) {
		$held = self::held_ids();
		if ( empty( $held ) || ! is_array( $snippets ) ) {
			return $snippets;
		}

		return array_values(
			array_filter(
				$snippets,
				function ( $snippet ) use ( $held ) {
					return ! ( $snippet instanceof WPCode_Snippet ) || ! in_array( (int) $snippet->get_id(), $held, true );
				}
			)
		);
	}

	/**
	 * Skip executing a held snippet (shortcodes, blocks and any other direct execution).
	 *
	 * @param bool           $skip    The current value.
	 * @param WPCode_Snippet $snippet The snippet about to execute.
	 *
	 * @return bool
	 */
	public function skip_pending_snippets( $skip, $snippet ) {
		return $skip || in_array( (int) $snippet->get_id(), self::held_ids(), true );
	}

	/**
	 * Remember the file hash when a managed snippet records an error, so a sync does not re-activate a
	 * snippet WPCode deactivated until the file changes.
	 *
	 * @param array          $error   The error details.
	 * @param WPCode_Snippet $snippet The snippet.
	 *
	 * @return void
	 */
	public function remember_error_hash( $error, $snippet ) {
		if ( ! $snippet instanceof WPCode_Snippet || ! self::is_managed( $snippet ) ) {
			return;
		}
		$dir  = WPCode_Snippets_File_Handler::get_snippets_dir();
		$file = self::file_for( $snippet->get_id() );
		if ( file_exists( $dir . $file ) ) {
			update_post_meta( $snippet->get_id(), WPCode_Snippets_File_Sync::META_ERROR_HASH, WPCode_Snippets_File_Sync::hash_file( $dir, $file ) );
		}
	}

	/**
	 * Explain the mode on the list and editor, show a write this request refused, report sync warnings and
	 * errors on every WPCode page, confirm a Sync now.
	 *
	 * @return void
	 */
	public function render_notices() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display-only reads.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( 0 !== strpos( $page, 'wpcode' ) ) {
			return;
		}
		$synced = isset( $_GET['wpcode_synced'] ) ? sanitize_key( wp_unslash( $_GET['wpcode_synced'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( in_array( $page, array( 'wpcode', 'wpcode-snippet-manager' ), true ) ) {
			echo '<div class="notice notice-info"><p>';
			printf(
				/* translators: %s: the snippets directory. */
				esc_html__( 'PHP, HTML, Universal, CSS, JS and SCSS snippets on this site are managed from files in %s and are read-only here: add or edit the files and they sync on the next request. Text and Blocks snippets are edited here as usual.', 'wpcode-premium' ),
				'<code>' . esc_html( self::display_dir() ) . '</code>'
			);
			echo '</p></div>';
		} elseif ( 'wpcode-tools' === $page ) {
			echo '<div class="notice notice-info"><p>' . esc_html__( 'Snippets are managed from files on this site: imported PHP, HTML, Universal, CSS, JS and SCSS snippets are skipped. Add them as files instead.', 'wpcode-premium' ) . '</p></div>';
		}

		if ( '' !== self::$last_refusal ) {
			echo '<div class="notice notice-error"><p>' . esc_html( self::$last_refusal ) . '</p></div>';
		}

		$report = WPCode_Snippets_File_Sync::report();
		$errors = ! empty( $report['errors'] ) && is_array( $report['errors'] ) ? $report['errors'] : array();
		$export = ! empty( $report['export_errors'] ) && is_array( $report['export_errors'] ) ? $report['export_errors'] : array();

		if ( 'skipped' === $synced ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Another sync was already running. Try again in a minute.', 'wpcode-premium' ) . '</p></div>';
		} elseif ( 'done' === $synced ) {
			echo '<div class="notice notice-success is-dismissible"><p>';
			printf(
				/* translators: %s: the sync summary, e.g. "2 imported, 0 exported, 1 removed, 0 with errors." */
				esc_html__( 'Snippet files synced: %s', 'wpcode-premium' ),
				esc_html( self::report_summary( $report ) )
			);
			echo '</p></div>';
		}

		if ( ! empty( $report['export_error'] ) ) {
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Snippet files could not be exported:', 'wpcode-premium' ) . '</strong> ' . esc_html( $report['export_error'] ) . '</p></div>';
		}
		$this->render_file_list( __( 'Some snippets could not be written to files:', 'wpcode-premium' ), $export, 'notice-warning' );
		$this->render_file_list( __( 'Some snippet files could not be imported:', 'wpcode-premium' ), $errors, 'notice-warning' );
		$this->render_file_list( __( 'Notes from the last snippet file sync:', 'wpcode-premium' ), ! empty( $report['warnings'] ) && is_array( $report['warnings'] ) ? $report['warnings'] : array(), 'notice-info' );
	}

	/**
	 * One notice with a list of file names and messages.
	 *
	 * @param string $heading The heading.
	 * @param array  $items   File name to message.
	 * @param string $class   The notice class.
	 *
	 * @return void
	 */
	protected function render_file_list( $heading, $items, $class ) {
		if ( empty( $items ) ) {
			return;
		}
		echo '<div class="notice ' . esc_attr( $class ) . '"><p><strong>' . esc_html( $heading ) . '</strong></p><ul>';
		foreach ( $items as $file => $message ) {
			echo '<li><code>' . esc_html( $file ) . '</code>: ' . esc_html( $message ) . '</li>';
		}
		echo '</ul></div>';
	}

	/**
	 * Show the file name and the removed-file state in the snippets list's status column.
	 *
	 * @param string         $value       The column markup.
	 * @param WPCode_Snippet $snippet     The row's snippet.
	 * @param string         $column_name The column.
	 *
	 * @return string
	 */
	public function table_column( $value, $snippet, $column_name ) {
		if ( 'status' !== $column_name || ! self::is_managed( $snippet ) ) {
			return $value;
		}
		$value .= '<div class="wpcode-snippet-file"><code>' . esc_html( self::file_for( $snippet->get_id() ) ) . '</code>';
		if ( self::is_file_missing( $snippet->get_id() ) ) {
			$value .= ' <span class="wpcode-snippet-file-missing">' . esc_html__( 'File removed', 'wpcode-premium' ) . '</span>';
		}

		return $value . '</div>';
	}

	/**
	 * The editor is read-only for managed snippets and for file-type snippets that await their file.
	 *
	 * @param bool                $read_only The current value.
	 * @param WPCode_Snippet|null $snippet   The snippet being edited.
	 *
	 * @return bool
	 */
	public function editor_read_only( $read_only, $snippet ) {
		return $read_only || ( $snippet instanceof WPCode_Snippet && ( self::is_managed( $snippet ) || self::awaits_export( $snippet ) ) );
	}

	/**
	 * Name the file in the editor's read-only message.
	 *
	 * @param string              $message The default message.
	 * @param WPCode_Snippet|null $snippet The snippet being edited.
	 *
	 * @return string
	 */
	public function editor_message( $message, $snippet ) {
		if ( ! $snippet instanceof WPCode_Snippet ) {
			return $message;
		}
		if ( self::is_managed( $snippet ) ) {
			return sprintf(
				/* translators: %s: the file path. */
				__( 'This snippet is managed from %s. Edit the file and it will sync on the next request.', 'wpcode-premium' ),
				'<code>' . esc_html( self::display_file( $snippet ) ) . '</code>'
			);
		}
		if ( self::awaits_export( $snippet ) ) {
			return self::awaiting_export_message();
		}

		return $message;
	}

	/**
	 * The editor offers only the types that are edited here: file-managed types are dropped from the Code Type
	 * select and from the picker tiles for a new snippet and for a snippet of another type, so nobody composes
	 * code the save would refuse. A managed snippet keeps the full list, so its own type still renders in the
	 * read-only editor. Both filtered arrays are keyed by type.
	 *
	 * @param array $options Code type to label, or to label and description.
	 *
	 * @return array
	 */
	public function editor_code_types( $options ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- display-only reads.
		if ( ! is_admin() || ! isset( $_GET['page'] ) || 'wpcode-snippet-manager' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return $options;
		}
		$snippet_id = isset( $_GET['snippet_id'] ) ? absint( $_GET['snippet_id'] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( $snippet_id && ( self::is_managed( $snippet_id ) || WPCode_Snippet_File::is_file_type( wpcode_get_snippet( $snippet_id )->get_code_type() ) ) ) {
			return $options;
		}

		return array_diff_key( $options, array_flip( array_merge( WPCode_Snippet_File::PHP_TYPES, WPCode_Snippet_File::ASSET_TYPES ) ) );
	}

	/**
	 * Refuse a bulk action that touches a managed snippet, except trash, untrash or delete of one whose file is gone.
	 *
	 * @param string $refusal The current refusal message, empty to allow.
	 * @param int[]  $ids     The selected snippet ids.
	 * @param string $action  The bulk action.
	 *
	 * @return string
	 */
	public function bulk_refusal( $refusal, $ids, $action ) {
		if ( '' !== $refusal ) {
			return $refusal;
		}
		foreach ( (array) $ids as $id ) {
			if ( ! self::is_managed( (int) $id ) ) {
				continue;
			}
			if ( in_array( $action, array( 'delete', 'trash', 'untrash' ), true ) && self::is_file_missing( (int) $id ) ) {
				continue;
			}

			return __( 'Some of the selected snippets are managed from files on the server and cannot be changed here.', 'wpcode-premium' );
		}

		return $refusal;
	}

	/**
	 * Sync now: a nonce'd GET behind manage_options that runs a sync at once, retrying a failed export, and
	 * returns to the settings page with the outcome. Auto insert was turned off for this request in
	 * schedule_sync(), so the activation checks of changed files are the only run of their code.
	 *
	 * @return void
	 */
	public function maybe_handle_sync_now() {
		if ( ! self::is_sync_now_request() ) {
			return;
		}
		check_admin_referer( self::SYNC_NONCE );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to sync snippet files.', 'wpcode-premium' ), '', array( 'response' => 403 ) );
		}

		$report = WPCode_Snippets_File_Sync::sync_now();
		$state  = ! empty( $report['skipped'] ) ? 'skipped' : 'done';

		wp_safe_redirect( add_query_arg( 'wpcode_synced', $state, remove_query_arg( array( 'wpcode_action', '_wpnonce' ) ) ) );
		exit;
	}
}

new WPCode_Snippets_From_Files();
