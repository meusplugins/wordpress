"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
!function () {
  "use strict";

  var React = window.React;
  jQuery(function ($) {
    var initialized = false;
    var log = function log() {
      var _console;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      (_console = console).log.apply(_console, ["[HA Advanced Tabs]:"].concat(args));
    };
    var initEditor = function initEditor() {
      var _ref, _$e, _$e$get, _$e2, _$e2$get, _elementor;
      if (initialized) {
        log("Already initialized");
        return true;
      }
      log("Init attempt...");
      if (typeof elementor === "undefined" || typeof $e === "undefined") {
        log("Elementor or $e not ready");
        return false;
      }
      log("Elementor detected");
      var nestedModule = ((_ref = ((_$e = $e) === null || _$e === void 0 || (_$e = _$e.components) === null || _$e === void 0 || (_$e$get = _$e.get) === null || _$e$get === void 0 ? void 0 : _$e$get.call(_$e, "nested-elements/nested-repeater")) || ((_$e2 = $e) === null || _$e2 === void 0 || (_$e2 = _$e2.components) === null || _$e2 === void 0 || (_$e2$get = _$e2.get) === null || _$e2$get === void 0 ? void 0 : _$e2$get.call(_$e2, "nested-elements"))) === null || _ref === void 0 ? void 0 : _ref.exports) || null;
      if (!nestedModule) {
        log("nestedModule not ready");
        return false;
      }
      log("nestedModule loaded");
      var NestedViewBase = nestedModule.NestedViewBase || nestedModule.NestedView;
      var NestedModelBase = nestedModule.NestedRepeaterModel || nestedModule.NestedModelBase;
      if (!NestedViewBase || !NestedModelBase) {
        log("View or Model base missing");
        return false;
      }
      log("View & Model ready");
      var NestedElementBase = (_elementor = elementor) === null || _elementor === void 0 || (_elementor = _elementor.modules) === null || _elementor === void 0 || (_elementor = _elementor.elements) === null || _elementor === void 0 || (_elementor = _elementor.types) === null || _elementor === void 0 ? void 0 : _elementor.NestedElementBase;
      if (typeof NestedElementBase !== "function" || !NestedElementBase.prototype) {
        log("NestedElementBase NOT ready", NestedElementBase);
        return false;
      }
      log("NestedElementBase ready");

      // ─────────────────────────────
      // VIEW
      // ─────────────────────────────
      var HappyAdvancedTabsView = /*#__PURE__*/function (_NestedViewBase) {
        function HappyAdvancedTabsView() {
          _classCallCheck(this, HappyAdvancedTabsView);
          return _callSuper(this, HappyAdvancedTabsView, arguments);
        }
        _inherits(HappyAdvancedTabsView, _NestedViewBase);
        return _createClass(HappyAdvancedTabsView, [{
          key: "getTemplate",
          value: function getTemplate() {
            var _this = this;
            return function (data) {
              var settings = data.settings || {};
              var tabs = settings.tabs || [];
              var elementUid = _this.getIDInt ? _this.getIDInt().toString() : "0";
              var elementId = _this.getID();
              var navPosition = (settings === null || settings === void 0 ? void 0 : settings.nav_position) || 'top';
              var navAlignX = (settings === null || settings === void 0 ? void 0 : settings.nav_align_x) || 'x-left';
              var navAlignY = (settings === null || settings === void 0 ? void 0 : settings.nav_align_y) || 'y-top';
              var navIconPosition = (settings === null || settings === void 0 ? void 0 : settings.nav_icon_position) || 'left';
              var classes = ["ha-tabs", "ha-tabs-".concat(elementUid), "ha-tabs-".concat(elementId), "ha-tabs--nav-".concat(navPosition || 'top'), ['top', 'bottom'].includes(navPosition) ? "ha-tabs--nav-".concat(navAlignX) : '', ['left', 'right'].includes(navPosition) ? "ha-tabs--nav-".concat(navAlignY) : '', "ha-tabs--icon-".concat(navIconPosition || 'left')].filter(Boolean).join(' ');
              log("Rendering template", _this.getID());
              var tabsHtml = '';
              var panelsHtml = '';
              var panelsHtml1 = '';
              var containerIndex = 0;
              tabs.forEach(function (item, index) {
                var _item$icon;
                console.log("Processing tab item", item, index);
                var tabCount = index + 1;
                var title = (item === null || item === void 0 ? void 0 : item.title) || "Tab #".concat(tabCount);
                var iconValue = item === null || item === void 0 || (_item$icon = item.icon) === null || _item$icon === void 0 ? void 0 : _item$icon.value;
                var source = (item === null || item === void 0 ? void 0 : item.source) || 'editor';
                var repeaterClass = item !== null && item !== void 0 && item._id ? " elementor-repeater-item-".concat(item._id) : '';
                var tabTitleId = "ha-tab-title-".concat(tabCount);
                var tabContentId = "ha-tab-content-".concat(tabCount);
                var activeClass = tabCount === 1 ? ' ha-tab--active' : '';
                var displayStyle = tabCount === 1 ? ' style=""' : ' style="display: none;"';
                var tabIsContainer = source === "container";
                var iconHtml = '';
                if (iconValue) {
                  if (typeof iconValue === 'string') {
                    iconHtml = "<span class=\"ha-tab__title-icon\"><i class=\"".concat(iconValue, "\"></i></span>");
                  } else if (iconValue.value) {
                    iconHtml = "<span class=\"ha-tab__title-icon\"><i class=\"".concat(iconValue.value, "\"></i></span>");
                  }
                }
                tabsHtml += "\n                                <div id=\"".concat(tabTitleId, "\"\n                                    class=\"ha-tab__title ha-tab__title--desktop").concat(repeaterClass).concat(activeClass, "\"\n                                    aria-selected=\"").concat(tabCount === 1 ? 'true' : 'false', "\"\n                                    data-tab=\"").concat(tabCount, "\"\n                                    role=\"tab\"\n                                    tabindex=\"").concat(tabCount === 1 ? '0' : '-1', "\"\n                                    aria-controls=\"").concat(tabContentId, "\">\n                                    ").concat(iconHtml, "\n                                    <span class=\"ha-tab__title-text\">").concat(title, "</span>\n                                </div>\n                            ");
                if (tabIsContainer) {
                  containerIndex += 1;
                  panelsHtml += "\n                                    <div id=\"".concat(tabContentId, "\"\n                                        class=\"ha-tab__content con ha-tabs-content ha-clearfix").concat(repeaterClass).concat(activeClass, "\"\n                                        data-tab=\"").concat(tabCount, "\"\n                                        data-tab-index=\"").concat(tabCount, "\"\n                                        data-child-index=\"").concat(containerIndex, "\"\n                                        role=\"tabpanel\"\n                                        aria-labelledby=\"").concat(tabTitleId, "\"\n                                        ").concat(displayStyle, ">\n                                    </div>\n                                ");
                  return;
                }
                console.log("Non-container tab, source:", source);
                if (source === 'editor') {
                  panelsHtml += "\n                                    <div id=\"".concat(tabContentId, "\"\n                                        class=\"ha-tab__content editor-part ha-clearfix").concat(repeaterClass).concat(activeClass, "\"\n                                        data-tab=\"").concat(tabCount, "\"\n                                        role=\"tabpanel\"\n                                        aria-labelledby=\"").concat(tabTitleId, "\"\n                                        ").concat(displayStyle, ">\n                                        ").concat((item === null || item === void 0 ? void 0 : item.editor) || '', "\n                                    </div>\n                                ");
                } else if (source === 'template') {
                  var templateId = (item === null || item === void 0 ? void 0 : item.template) || '';
                  panelsHtml += "\n                                    <div id=\"".concat(tabContentId, "\"\n                                        class=\"ha-tab__content template-part ha-clearfix").concat(repeaterClass).concat(activeClass, "\"\n                                        data-tab=\"").concat(tabCount, "\"\n                                        data-template-id=\"").concat(templateId, "\"\n                                        data-loaded=\"false\"\n                                        role=\"tabpanel\"\n                                        aria-labelledby=\"").concat(tabTitleId, "\"\n                                        ").concat(displayStyle, ">\n                                        <div class=\"ha-template-loader\"></div>\n                                    </div>\n                                ");
                } else {
                  panelsHtml += "\n                                    <div id=\"".concat(tabContentId, "\"\n                                        class=\"ha-tab__content elseitem-part  ha-clearfix").concat(repeaterClass).concat(activeClass, "\"\n                                        data-tab=\"").concat(tabCount, "\"\n                                        role=\"tabpanel\"\n                                        aria-labelledby=\"").concat(tabTitleId, "\"\n                                        ").concat(displayStyle, "></div>\n                                ");
                }
              });
              return "\n                            <div class=\"".concat(classes, "\">\n                                <div class=\"ha-tabs__nav\" role=\"tablist\">\n                                    ").concat(tabsHtml, "\n                                </div>\n                                <div class=\"ha-tabs__content\">\n                                    ").concat(panelsHtml, "\n                                </div>\n                            </div>\n                        ");
            };
          }
        }, {
          key: "filter",
          value: function filter(model, index) {
            var dataIndex = index + 1;
            if (typeof (model === null || model === void 0 ? void 0 : model.set) === "function") {
              model.set({
                dataIndex: dataIndex,
                _index: dataIndex
              });
            } else if (model !== null && model !== void 0 && model.attributes) {
              model.attributes.dataIndex = dataIndex;
              model.attributes._index = dataIndex;
            }
            return true;
          }
          // onAddChild(child) {
          //     const childIndex = child.model?.get?.('_childIndex') ?? child.model?.attributes?._childIndex;
          //     if (childIndex != null) {
          //         const panel = this.$el.find(`[data-child-index="${childIndex}"]`)[0];
          //         if (panel) {
          //             panel.appendChild(child.el);
          //         }
          //     }
          //     log("Child added", child, "childIndex:", childIndex);
          // }
        }]);
      }(NestedViewBase); // ─────────────────────────────
      // ELEMENT
      // ─────────────────────────────
      var HappyAdvancedTabsElement = /*#__PURE__*/function (_NestedElementBase) {
        function HappyAdvancedTabsElement() {
          _classCallCheck(this, HappyAdvancedTabsElement);
          return _callSuper(this, HappyAdvancedTabsElement, arguments);
        }
        _inherits(HappyAdvancedTabsElement, _NestedElementBase);
        return _createClass(HappyAdvancedTabsElement, [{
          key: "getType",
          value: function getType() {
            return "ha-advanced-tabs";
          }
        }, {
          key: "getView",
          value: function getView() {
            return HappyAdvancedTabsView;
          }
        }, {
          key: "getModel",
          value: function getModel() {
            return NestedModelBase;
          }
        }, {
          key: "getInitialConfig",
          value: function getInitialConfig() {
            log("Initial config loaded");
            return _objectSpread(_objectSpread({}, _superPropGet(HappyAdvancedTabsElement, "getInitialConfig", this, 3)([])), {}, {
              defaults: {
                repeater_title_setting: "title"
              }
            });
          }
        }]);
      }(NestedElementBase);
      elementor.elementsManager.registerElementType(new HappyAdvancedTabsElement());
      initialized = true;
      log("SUCCESS: Widget Registered");
      return true;
    };

    // ─────────────────────────────
    // INIT SYSTEM
    // ─────────────────────────────
    var startInit = function startInit() {
      log("Starting init loop...");
      var interval = setInterval(function () {
        if (initEditor()) {
          clearInterval(interval);
          log("Init loop stopped");
        }
      }, 150);
    };

    // Editor
    if (window.elementor && elementor.on) {
      log("Hooking into preview:loaded");
      elementor.on('preview:loaded', startInit);
    }

    // Frontend fallback
    jQuery(window).on('elementor/frontend/init', function () {
      log("Frontend init triggered");
      startInit();
    });
  });
}();