<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_404 extends Base_Condition {

	public function get_key() {
		return 'is_404';
	}

	public function check( $rule, $context ) {
		return is_404();
	}
}

