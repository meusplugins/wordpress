"use strict";

(function ($, w) {
  'use strict';

  $(w).on('elementor/frontend/init', function () {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      return;
    }
    gsap.registerPlugin(ScrollTrigger);
    var HappyHorizontalScroll = elementorModules.frontend.handlers.Base.extend({
      onInit: function onInit() {
        elementorModules.frontend.handlers.Base.prototype.onInit.apply(this, arguments);
        this._initDone = false;
        this.run();
      },
      onElementChange: function onElementChange(changedKey) {
        if (typeof changedKey === 'string' && (changedKey === 'ha_hs_switcher' || changedKey === 'ha_hs_direction' || changedKey === 'ha_snap_scroll_switcher' || changedKey === 'ha_hs_enable_editor_preview' || changedKey === 'ha_hs_enable_auto_width')) {
          this.killAnimation();
          this.run();
        }
      },
      onDestroy: function onDestroy() {
        this.killAnimation();
        elementorModules.frontend.handlers.Base.prototype.onDestroy.apply(this, arguments);
      },
      run: function run() {
        if (window.innerWidth < 1025) {
          return;
        }
        var settings = this.getElementSettings();
        if (settings.ha_hs_switcher !== 'yes') return;
        if (this.isEdit && settings.ha_hs_enable_editor_preview !== 'yes') {
          return;
        }
        var $wrapper = this.$element;
        var $children = $wrapper.children();
        if ($children.length < 2) return;
        var snap_switcher = settings.ha_snap_scroll_switcher || 'no';
        var snapPoints = 0;

        // Build track
        var $inner = $('<div class="ha-hs-inner"></div>');
        $children.each(function () {
          $(this).addClass('ha-hs-item').appendTo($inner);
        });
        $wrapper.empty().append($inner);
        var totalPanels = $children.length;

        // In editor mode, DOM may not be fully laid out yet — delay measurement
        if (this.isEdit) {
          var self = this;
          setTimeout(function () {
            self._createAnimation($wrapper, $inner, totalPanels, settings, snap_switcher);
          }, 100);
          return;
        }
        this._createAnimation($wrapper, $inner, totalPanels, settings, snap_switcher);
      },
      _createAnimation: function _createAnimation($wrapper, $inner, totalPanels, settings, snap_switcher) {
        var containerWidth = $wrapper.outerWidth();
        if (!containerWidth || containerWidth < 1) return;
        var totalWidth;
        var isAutoWidth = $wrapper.hasClass('ha-hs-auto-width-enabled');
        if (isAutoWidth) {
          totalWidth = $inner[0].scrollWidth;
        } else {
          totalWidth = containerWidth * totalPanels;
        }
        if (!isAutoWidth) {
          $inner.width(totalWidth);
        }
        var direction = settings.ha_hs_direction || 'left';
        var isRight = direction === 'right';
        var maxTranslate = totalWidth - containerWidth;
        var fromX = isRight ? -maxTranslate : 0;
        var toX = isRight ? 0 : -maxTranslate;
        var snapPoints = 0;
        if (snap_switcher === 'yes') {
          snapPoints = 1 / (totalPanels - 1);
        }
        gsap.set($inner[0], {
          x: fromX
        });
        var stConfig;
        if (this.isEdit) {
          // Editor: scroll-driven without pin
          // pin does not work inside Elementor's editor iframe
          stConfig = {
            trigger: $wrapper[0],
            start: 'top center',
            end: 'bottom center',
            scrub: 1,
            invalidateOnRefresh: true,
            snap: snapPoints
          };
        } else {
          // Frontend: scroll-driven with pin
          stConfig = {
            trigger: $wrapper[0],
            pin: true,
            scrub: 1,
            duration: 1,
            markers: false,
            anticipatePin: 0,
            invalidateOnRefresh: true,
            snap: snapPoints,
            end: function end() {
              return "+=" + totalWidth;
            }
          };
        }
        this.scrollTween = gsap.to($inner[0], {
          x: toX,
          ease: 'none',
          scrollTrigger: stConfig
        });
        if (this.isEdit) {
          setTimeout(function () {
            ScrollTrigger.refresh();
          }, 200);
        }
      },
      killAnimation: function killAnimation() {
        if (this.scrollTween) {
          if (this.scrollTween.scrollTrigger) {
            this.scrollTween.scrollTrigger.kill();
          }
          this.scrollTween.kill();
          this.scrollTween = null;
        }
        if (window.ScrollTrigger) {
          var $el = this.$element;
          ScrollTrigger.getAll().forEach(function (st) {
            if (st.vars.trigger === $el[0]) {
              st.kill();
            }
          });
        }
        this._initDone = false;
      }
    });
    elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
      elementorFrontend.elementsHandler.addHandler(HappyHorizontalScroll, {
        $element: $scope
      });
    });
  });
})(jQuery, window);