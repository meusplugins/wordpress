import Utils from '../utils/Utils';
import ProductUtils from '../utils/ProductUtils';
import DataUtils from '../utils/DataUtils';

export class CartGroup {

    _group = null;
    selectedChoices = [];

    constructor(group, selectedChoices = null) {
        this._group = group;
        if (!_.isNil(selectedChoices) && _.isArray(selectedChoices)) {
            this.selectedChoices = selectedChoices;
        }
    }

    pushChoice(choiceId) {
        if (_.isArray(this.selectedChoices) && !_.includes(this.selectedChoices, choiceId)) {
            this.selectedChoices.push(choiceId);
        }
    }

    removeChoice(choiceId) {
        let choice = null;
        if (_.isArray(this.selectedChoices) && _.includes(this.selectedChoices, choiceId)) {
            for (let i = 0; i < this.selectedChoices.length; i++) {
                choice = this.selectedChoices[i];
                if (choice === choiceId) {
                    this.selectedChoices.splice(i, 1);
                    break;
                }
            }
        }
        return choice;
    }

    getSelectedChoices() {
        return this.selectedChoices;
    }

    getGroupId() {
        return parseInt(_.get(this._group, 'ID', ''), 10);
    }

    minIsValid(min_choices_num) {
        if (isNaN(min_choices_num)) {
            return true;
        }
        if (_.isNumber(min_choices_num) && min_choices_num === 0) {
            return true;
        }
        if (_.isNumber(min_choices_num) && this.selectedChoices.length >= min_choices_num) {
            return true;
        }
        return false;
    }

    maxIsValid(max_choices_num) {
        if (isNaN(max_choices_num)) {
            return true;
        }
        if (_.isNumber(max_choices_num) && max_choices_num === 0) {
            return true;
        }
        if (_.isNumber(max_choices_num) && this.selectedChoices.length <= max_choices_num) {
            return true;
        }
        return false;
    }

    isValid() {
        const min_choices_num = parseInt(_.get(this._group, 'post_meta.min_choices_num', ''), 10);
        const max_choices_num = parseInt(_.get(this._group, 'post_meta.max_choices_num', ''), 10);

        const _minIsValid = this.minIsValid(min_choices_num);
        const _maxIsValid = this.maxIsValid(max_choices_num);
        return _minIsValid === true && _maxIsValid === true;
    }

    getGroupChoicesWithData() {
        if (!Array.isArray(this.selectedChoices)) {
            return [];
        }
        return DataUtils.getInstance().getChoicesFromData(this.selectedChoices);
    }
}
class CartProduct {
    
    id;
    _product;
    _selectedVariantId = null;
    _cartGroups = [];
    _quantity = 1;
    _productCategoryId = '';
    _additionalNotes = '';

    constructor(product) {
        this._product = product;
        this.id = Utils.uuidv4();
    }

    setVariant(variantId) {
        this._selectedVariantId = variantId;
    }

    getVariant() {
        return this._selectedVariantId;
    }

    getSelectedVariantData() {
        const findVariant = (element) => _.get(element, 'ID', '') === this._selectedVariantId;
        const variants = _.get(this._product, 'meta.product_variations', []);
        const variantIndex = variants.findIndex(findVariant);
        return _.get(variants, `[${variantIndex}]`, {});
    }

    hasManyVariants() {
        const variants = _.get(this._product, 'meta.product_variations', []);
        return variants.length > 1;
    }

    getGroupsWithChoicesData() {
        const result = [];
        this._cartGroups.forEach(cartGroup => {
            const choicesWithData =  cartGroup.getGroupChoicesWithData();
            if (Array.isArray(choicesWithData) && choicesWithData.length > 0) {
                result.push({
                    group: cartGroup._group,
                    choices: choicesWithData,
                    product: this._product
                });
            }

        });
        return result;
    }

    addGroup(group) {
        if (!this._groupExists(_.get(group, 'ID', ''))) {
            let newGroup = new CartGroup(group);
            this._cartGroups.push(newGroup);
        }
    }

    getGroupSelectedChoices(groupRaw) {
        let selectedChoices = [];
        if (this._groupExists(_.get(groupRaw, 'ID', ''))) {
            const group = this.getGroup(_.get(groupRaw, 'ID', ''));
            if (!_.isNil(group)) {
                
                selectedChoices = group.getSelectedChoices();
            }
        }
        return selectedChoices;
    }

    setChoice(choiceId, groupId) {
        if (this._groupExists(groupId)) {
            let cartGroupIndex = this.getGroupIndex(groupId);
            if (!_.isNil(cartGroupIndex)) {
                this._cartGroups[cartGroupIndex].pushChoice(choiceId);
            }
        }
    }

    removeChoice(choiceId, groupId) {
        if (this._groupExists(groupId)) {
            let cartGroupIndex = this.getGroupIndex(groupId);
            if (!_.isNil(cartGroupIndex)) {
                this._cartGroups[cartGroupIndex].removeChoice(choiceId);
            }
        }
    }

    _groupExists(groupId) {
        let exists = false;
        for (let i = 0; i < this._cartGroups.length; i++) {
            const editedGroup = this._cartGroups[i];
            if (editedGroup.getGroupId() === parseInt(groupId, 10)) {
                exists = true;
                break;
            }
        }
        return exists;
    }

    getGroup(groupId) {
        let group = null;
        for (let i = 0; i < this._cartGroups.length; i++) {
            const editedGroup = this._cartGroups[i];
            if (editedGroup.getGroupId() === parseInt(groupId, 10)) {
                group = editedGroup;
                break;
            }
        }
        return group;
    }

    getGroupIndex(groupId) {
        let index = null;
        for (let i = 0; i < this._cartGroups.length; i++) {
            const editedGroup = this._cartGroups[i];
            if (editedGroup.getGroupId() === parseInt(groupId, 10)) {
                index = i;
                break;
            }
        }
        return index;
    }

    setQuantity(val) {
        this._quantity = parseInt(val, 10);
    }

    getQuantity() {
        return this._quantity;
    }

    setProductCategoryId(categoryId) {
        this._productCategoryId = categoryId;
    }

    getProductCategoryId() {
        return this._productCategoryId;
    }

    getProductAndGroupWithQuantity() {
        return {
            product: this._product,
            quantity: this.getQuantity(),
            porductId: this._product.ID,
            productCategoryId: this._productCategoryId,
        }
    }

    getProduct() {
        return this._product;
    }

    getTotal() {
        const q = this.getQuantity();
        const productVariant = this.getSelectedVariantData();
        const variantPrice = _.get(productVariant, 'price_float_val', 0);

        let cartProductTotal = variantPrice;

        const cartGroupsWithChoices = this.getGroupsWithChoicesData();
        if (Array.isArray(cartGroupsWithChoices) && cartGroupsWithChoices.length > 0) {
            cartGroupsWithChoices.forEach(cartGroupData => {
                const { choices } = cartGroupData;
                if (Array.isArray(choices)) {
                    choices.forEach(choice => {
                        cartProductTotal += _.get(choice, 'price_float_val', 0);
                    });
                }
            });
        }
        return q * cartProductTotal;
    }

    setAdditionalNotes(notes) {
        this._additionalNotes = notes;
    }
    
    getAdditionalNotes() {
        return this._additionalNotes;
    }

    validate() {
        let isValid = true;
        if (ProductUtils.productHasVariants(this._product) && _.isNil(this._selectedVariantId)) {
            return false;
        } else {
            if (_.isNil(this._selectedVariantId)) {
                return false;
            }
        }
        if (ProductUtils.productHasChoiceGroups(this._product) && _.isArray(this._cartGroups)) {
            for (let i = 0; i < this._cartGroups.length; i++) {
                const cartGroup = this._cartGroups[i];
                if (!cartGroup.isValid()) {
                    return false;
                    break;
                }
            }
        }
        return isValid;
    }

}
export default CartProduct;
