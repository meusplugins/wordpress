<?php

defined( 'ABSPATH' ) || exit;

return [
	'amount_min' => [
		'type'  => 'number',
		'title' => __( 'Amount min', 'wow-herd-effects-pro' ),
		'val'   => '1',
		'atts'  => [
			'min'  => 0,
			'step' => 1,
		],
	],

	'amount_max' => [
		'type'  => 'number',
		'title' => __( 'Amount max', 'wow-herd-effects-pro' ),
		'val'   => '59',
		'atts'  => [
			'min'  => 0,
			'step' => 1,
		],
	],

	'herd_name' => [
		'type'  => 'textarea',
		'atts' => [
			'placeholder' => __( 'Enter the values separated by comma.', 'wow-herd-effects-pro' ),
		],
	],

	'herd_city' => [
		'type'  => 'textarea',
		'atts' => [
			'placeholder' => __( 'Enter the values separated by comma.', 'wow-herd-effects-pro' ),
		],
	],

	'herd_product' => [
		'type'  => 'textarea',
		'atts' => [
			'placeholder' => __( 'Enter the values separated by comma.', 'wow-herd-effects-pro' ),
		],
	],

	'variable4' => [
		'type'  => 'textarea',
		'atts' => [
			'placeholder' => __( 'Enter the values separated by comma.', 'wow-herd-effects-pro' ),
		],
	],

	'variable5' => [
		'type'  => 'textarea',
		'atts' => [
			'placeholder' => __( 'Enter the values separated by comma.', 'wow-herd-effects-pro' ),
		],
	],

];