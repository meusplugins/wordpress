"use strict";

function AppetitMediaUpload(isMultiple, callback, windowTitle = 'Select image', libraryType = ['image'], addBtnLabel = 'Add image') {
    let send_attachment_bkp = wp.media.editor.send.attachment;
    let frame = wp.media({
        title: windowTitle,
        multiple: isMultiple || false,
        library: { type: libraryType },
        button : { text : addBtnLabel }
    });
    frame.on('close',function() {
        let selection = frame.state().get('selection');
        if (selection) {
            let attachements = [];
            selection.each(function(attachment) {
                attachements.push(attachment);
            });
            wp.media.editor.send.attachment = send_attachment_bkp;
            callback(attachements);
        }
    });
    frame.open();
}
