<?php
/**
 * WP-CLI commands for file-managed snippets: "wp wpcode snippets sync" and "wp wpcode snippets export".
 *
 * Run them as their own wp process and as the web server user: the mode turns auto insert off for that
 * process so the imported code runs once, in the activation check, and the files written stay writable by
 * the web server afterwards.
 *
 * @package WPCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manage snippets stored as files.
 */
class WPCode_CLI_Snippets {

	/**
	 * Import changed snippet files into the database mirror.
	 *
	 * Prints one line per exported, imported, removed or failed file; failures go to STDERR. Waits up to a
	 * minute for a sync another request is running. Exits with code 1 when any file failed, so a deploy hook
	 * can stop on a bad file, and with code 2 when another sync still holds the lock.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report what would change without writing anything.
	 *
	 * [--force]
	 * : Re-import every file, not only the changed ones.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wpcode snippets sync
	 *     wp wpcode snippets sync --dry-run
	 *
	 * @param array $args       Positional arguments (unused).
	 * @param array $assoc_args Named arguments.
	 *
	 * @return void
	 */
	public function sync( $args, $assoc_args ) {
		$this->require_mode();
		$this->require_own_process();
		$this->warn_if_root();

		$force   = ! empty( $assoc_args['force'] );
		$dry_run = ! empty( $assoc_args['dry-run'] );

		$report = $this->run_when_unlocked(
			function () use ( $force, $dry_run ) {
				// Each attempt clears the export back-off, even one set while this command waited on the lock.
				return WPCode_Snippets_File_Sync::sync_now( $force, $dry_run );
			}
		);

		foreach ( $report['exported'] as $file ) {
			WP_CLI::log( sprintf( '%-13s %s', $report['dry_run'] ? 'would export' : 'exported', $file ) );
		}
		$verb = $report['dry_run'] ? 'would import' : 'imported';
		foreach ( $report['imported'] as $file ) {
			WP_CLI::log( sprintf( '%-13s %s', $verb, $file ) );
		}
		foreach ( $report['removed'] as $file ) {
			WP_CLI::log( sprintf( '%-13s %s', $report['dry_run'] ? 'would remove' : 'removed', $file ) );
		}
		foreach ( $report['warnings'] as $file => $message ) {
			WP_CLI::warning( $file . ': ' . $message );
		}
		if ( '' !== $report['export_error'] ) {
			if ( $dry_run ) {
				// A dry run attempts no export; the earlier failure is information, not this run's result.
				WP_CLI::warning( 'export pending: ' . $report['export_error'] . ' A real run retries it.' );
			} else {
				WP_CLI::error( 'export: ' . $report['export_error'], false );
			}
		}
		foreach ( $report['errors'] as $file => $message ) {
			WP_CLI::error( sprintf( '%s: %s', $file, $message ), false );
		}
		foreach ( $report['export_errors'] as $file => $message ) {
			WP_CLI::error( sprintf( 'export %s: %s', $file, $message ), false );
		}
		WP_CLI::log( sprintf( '%d unchanged', (int) $report['unchanged'] ) );

		if ( ! $dry_run && preg_grep( '/\.php$/i', $report['imported'] ) ) {
			WP_CLI::log( 'PHP files changed: if the web server runs opcache with validate_timestamps off, reload PHP-FPM so it compiles the new files.' );
		}

		$failed = count( $report['errors'] ) + count( $report['export_errors'] ) + ( ! $dry_run && '' !== $report['export_error'] ? 1 : 0 );
		if ( $failed ) {
			WP_CLI::error( sprintf( '%d file(s) failed.', $failed ) );
		}

		WP_CLI::success( $report['dry_run'] ? 'Dry run complete.' : 'Sync complete.' );
	}

	/**
	 * Write every file-capable snippet from the database to the snippets directory.
	 *
	 * Snippets that already have a file are left alone. Legacy md5-named PHP files are removed. Exits with
	 * code 1 when a snippet could not be written, and with code 2 when another sync holds the lock.
	 *
	 * ## EXAMPLES
	 *
	 *     wp wpcode snippets export
	 *
	 * @return void
	 */
	public function export() {
		$this->require_mode();
		$this->warn_if_root();

		$report = $this->run_when_unlocked(
			function () {
				return ( new WPCode_Snippets_File_Sync() )->export();
			}
		);
		if ( is_wp_error( $report ) ) {
			WP_CLI::error( $report->get_error_message() );
		}
		foreach ( $report['exported'] as $file ) {
			WP_CLI::log( sprintf( '%-13s %s', 'exported', $file ) );
		}
		foreach ( $report['errors'] as $file => $message ) {
			WP_CLI::error( sprintf( '%s: %s', $file, $message ), false );
		}
		if ( $report['errors'] ) {
			WP_CLI::error( sprintf( '%d snippet(s) could not be written.', count( $report['errors'] ) ) );
		}
		WP_CLI::success( sprintf( '%d file(s) exported, %d legacy file(s) removed.', count( $report['exported'] ), (int) $report['removed_legacy'] ) );
	}

	/**
	 * Run a sync or export, waiting for a lock another request holds: a deploy hook that runs right after a
	 * pull races the visitor-triggered import of the same files. Gives up after the lock's lifetime with exit
	 * code 2, distinct from a failed file.
	 *
	 * @param callable $run Returns the report (with 'skipped' when the lock is held) or a WP_Error.
	 *
	 * @return array|WP_Error
	 */
	private function run_when_unlocked( $run ) {
		$deadline = time() + WPCode_Snippets_File_Sync::LOCK_TTL;
		$waiting  = false;
		while ( true ) {
			$result = $run();
			$held   = ! is_wp_error( $result ) && ! empty( $result['skipped'] );
			if ( ! $held ) {
				return $result;
			}
			if ( time() >= $deadline ) {
				WP_CLI::error( sprintf( 'Another sync is still running after %d seconds. Try again.', WPCode_Snippets_File_Sync::LOCK_TTL ), false );
				WP_CLI::halt( 2 );
			}
			if ( ! $waiting ) {
				WP_CLI::log( 'Another sync is running, waiting for it to finish.' );
				$waiting = true;
			}
			sleep( 2 );
		}
	}

	/**
	 * Stop unless the mode is on.
	 *
	 * @return void
	 */
	private function require_mode() {
		if ( ! WPCode_Snippets_From_Files::enabled() ) {
			WP_CLI::error( 'Define WPCODE_SNIPPETS_FROM_FILES as true in wp-config.php to manage snippets from files.' );
		}
	}

	/**
	 * Stop unless auto insert is off for this process, which the mode arranges when "wp wpcode snippets" is
	 * the command being run. Dispatched from another command, snippets already executed at bootstrap and the
	 * import's activation check would run the same code again.
	 *
	 * @return void
	 */
	private function require_own_process() {
		if ( apply_filters( 'wpcode_do_auto_insert', true ) ) {
			WP_CLI::error( 'Run "wp wpcode snippets sync" as its own wp process: snippets must not auto insert while the import runs.' );
		}
	}

	/**
	 * Files written by root are not writable by the web server later.
	 *
	 * @return void
	 */
	private function warn_if_root() {
		if ( function_exists( 'posix_geteuid' ) && 0 === posix_geteuid() ) {
			WP_CLI::warning( 'Running as root: files written now may not be writable by the web server user. Run the command as that user.' );
		}
	}
}
