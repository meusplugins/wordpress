<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../cpt/MenuItemCpt.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt;

class CategoriesService {
    private static $instance = null;
    private $categories = [];

    public function getCategories() {
        if (isset($this->categories) && is_array($this->categories) && sizeof($this->categories) > 0) {
            return $this->categories;
        }
        
        $this->categories = get_terms(['taxonomy' => MenuItemCpt::MENU_CAT_SLUG, 'hide_empty' => TRUE, 'parent' => 0]);

        if (!is_array($this->categories)) {
            $this->categories = [];
        }
        $this->parseCategories();
        return $this->categories;
    }

    private function parseCategories() {
        if (is_array($this->categories) && sizeof($this->categories) > 0) {
            for ($i=0; $i < sizeof($this->categories); $i++) { 
                $term = $this->categories[$i];
                $this->categories[$i]->meta = get_term_meta($term->term_id, MenuItemCpt::MENU_CAT_META_KEY, true);
            }
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new CategoriesService();
        }
        return self::$instance;
    }
}
?>