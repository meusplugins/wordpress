<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../utils/Sanitizer.php');


use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\Sanitizer;

class RedirectUtils {
    public static function process(): void {
        // $vars[] = 'ift'; // instafood table 
        // $vars[] = 'ifp_redirect'; // instafood payment redirect (success | fail)
        // $vars[] = 'if_oid'; // instafood order id (public id)
        // $vars[] = 'ifp'; // instafood payment ( possible values [stripe] )
        // $vars[] = 'opid'; // order public id
        $if_oid = Sanitizer::sanitizeInput($_GET['if_oid'] ?? false);
        $ifp = Sanitizer::sanitizeInput($_GET['ifp'] ?? false);


        if ($if_oid && $ifp === 'stripe') {
            self::handleStripePayments();
        }
    }

    static function handleStripePayments() {
        $ift = Sanitizer::sanitizeInput($_GET['ift'] ?? false);
        $if_oid = Sanitizer::sanitizeInput($_GET['if_oid'] ?? false);
        
        $order = new \com\sakuraplugins\appetit\rest_api\models\Order();
        $order->findOne($if_oid);
        $_payment_status = $order->getProperty('_payment_status');
        if ($_payment_status === \com\sakuraplugins\appetit\rest_api\models\OrderPaymentStatus::PAID) {
            return;
        }
        $_payment_method = $order->getProperty('_payment_method');            
        if ($_payment_method === 'stripe') {
            $stripeService = new \com\sakuraplugins\appetit\services\StripeService();
            if (!$stripeService->hasCredentials) {
                return;
            }
    
            $line_items = $order->getStripeLineItems();
            if (sizeof($line_items) === 0) {
                return;
            }
            
            try {
                $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
                $mobileAppPageUrl = get_permalink($mobileAppPageId);
                $success_url = $mobileAppPageUrl;
                $fail_url = $mobileAppPageUrl;

                $qVarsDataSuccess = ['ifp_redirect' => 'success'];
                $qVarsDataFail = ['ifp_redirect' => 'fail'];

                if ($ift) {
                    $qVarsDataSuccess['ift'] = $ift;
                    $qVarsDataFail['ift'] = $ift;
                }
                if ($if_oid) {
                    $qVarsDataSuccess['if_oid'] = $if_oid;
                }

                $properties = $order->getAllProperties();
                $_public_id = $properties['_public_id'] ?? '';
                if ($_public_id !== '') {
                    $qVarsDataFail['opid'] = $_public_id;
                }

                $success_url = add_query_arg($qVarsDataSuccess, $success_url);
                $fail_url = add_query_arg($qVarsDataFail, $fail_url);

                $stripeService->createSession($line_items, $success_url, $fail_url, $if_oid);
            } catch (\Exception $e) {
                echo 'Caught exception: ',  $e->getMessage(), "\n";
            }
        }
    }

    static function processPaymentComplete() {
        $ifp_redirect = Sanitizer::sanitizeInput($_GET['ifp_redirect'] ?? false);

        
        $if_oid = Sanitizer::sanitizeInput($_GET['if_oid'] ?? false);

        if ($if_oid && $ifp_redirect === 'success') {
            self::handleAfterPaymentSuccess($if_oid);
        }

        if ($ifp_redirect === 'fail') {
            self::handleAfterPaymentFailed($if_oid);
        }
    }

    static function handleAfterPaymentSuccess($orderId) {
        $order = new \com\sakuraplugins\appetit\rest_api\models\Order();
        $order->findOne($orderId);
        $orderSummary = $order->getOrderSummary();
        
        $ift = Sanitizer::sanitizeInput($_GET['ift'] ?? false);

        $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
        $mobileAppPageUrl = get_permalink($mobileAppPageId);

        
        if ($ift) {
            $mobileAppPageUrl = add_query_arg('ift', $ift, $mobileAppPageUrl);
        }

        echo '<script> localStorage.setItem(`APPETIT_TEMP_ORDER`, `'. json_encode($orderSummary) .'`); window.location.href = `'. $mobileAppPageUrl .'`; </script>';
    }

    static function handleAfterPaymentFailed($orderId) {
        
        $ift = Sanitizer::sanitizeInput($_GET['ift'] ?? false);
        $opid = Sanitizer::sanitizeInput($_GET['opid'] ?? '');

        if ($opid !== '') {
            $order = new \com\sakuraplugins\appetit\rest_api\models\Order();
            $ID = $order->findOneByPublicId($opid);
            if ($ID) {
                $order->setStatusPaymentStatus(\com\sakuraplugins\appetit\rest_api\models\OrderPaymentStatus::PAYMENT_CANCELED);
            }
        }

        $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
        $mobileAppPageUrl = get_permalink($mobileAppPageId);
        
        if ($ift) {
            $mobileAppPageUrl = add_query_arg('ift', $ift, $mobileAppPageUrl);
        }
        echo '<script> localStorage.setItem(`APPETIT_TEMP_ORDER`, `'. 'fail' .'`); window.location.href = `'. esc_url($mobileAppPageUrl) .'`; </script>';
    }

    static function strip_param_from_url($url, $param) {
        $base_url = strtok($url, '?');
        $parsed_url = parse_url($url);
        $query = $parsed_url['query'];
        parse_str( $query, $parameters );
        unset( $parameters[$param] );
        $new_query = http_build_query($parameters);
        return $base_url.'?'.$new_query;
    }
}
?>