
class QuantityComponent {
    _onChange;
    _min = 1;
    _current = 1;
    _parent_ui;
    _ui = null;

    constructor(current = 1, min = 1, onChange = null) {
        this._min = min;
        this._current = current;
        this._onChange = onChange;
    }

    render(parent_ui) {
        this._parent_ui = parent_ui;
        const _this = this;
        const template = `            
            <div class="cart_add_remove_controls">
                <a href="#" class="round_nav_fill primary minus inactive"><span class="icon-minus"></span></a>
                <div class="cart_add_info"></div>
                <a href="#" class="round_nav_fill primary plus"><span class="icon-plus"></span></a>
            </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._parent_ui);

        this._ui.find('.minus').click(function(event) {
            event.preventDefault();
            if (_this._current === _this._min) {
                return;
            }
            _this._current -= 1;
            _this._handleCurrent();
            if (_.isFunction(_this._onChange)) {
                _this._onChange(_this._current);
            }
        })

        this._ui.find('.plus').click(function(event) {
            event.preventDefault();
            _this._current += 1;
            _this._handleCurrent();
            if (_.isFunction(_this._onChange)) {
                _this._onChange(_this._current);
            }
        })

        this._handleCurrent();
    }

    _handleCurrent() {
        if (this._current === this._min) {
            if (!this._ui.find('.minus').hasClass('inactive')) {
                this._ui.find('.minus').addClass('inactive');
            }
        } else {
            this._ui.find('.minus').removeClass('inactive');
        }
        this._ui.find('.cart_add_info').html(this._current);
    }

    _getQuantity() {
        return this._current;
    }
}
export default QuantityComponent;