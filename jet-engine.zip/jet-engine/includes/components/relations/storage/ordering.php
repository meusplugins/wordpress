<?php
namespace Jet_Engine\Relations\Storage;

/**
 * Database manager class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Validate and persist ordering changes for stored relation rows.
 */
class Ordering {

	/**
	 * A reference to an instance of this class.
	 *
	 * @since  1.0.0
	 * @access private
	 * @var    object
	 */
	private static $instance = null;

	/**
	 * Returns ordering mode.
	 * Mode can be adjusted (or totally disabled) for client project requirements
	 *
	 * @return mixed
	 */
	public function get_mode() {
		/**
		 * Allowed modes:
		 * - string 'date' - default. On reorder items dates will be updated to match a new order. Getting related data will be updated to be sorted by date.
		 * - string 'id' - On reorder old items will be removed, new one will be created with a new order.
		 * - bool false - disable an ability to reorder items.
		 */
		return apply_filters( 'jet-engine/relations/ordering-mode', 'date' );
	}

	/**
	 * Reorder stored relation rows in the configured mode.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param array                          $items    Ordered rows containing storage IDs.
	 * @param array                          $scope    Optional field/value scope for an authorized object.
	 * @return true|\WP_Error True on success or a disabled mode; an error on failure.
	 */
	public function reorder_relation_items( $relation, $items, $scope = array() ) {
		switch ( $this->get_mode() ) {
			case 'id':
				return $this->process_id_reorder( $relation, $items, $scope );
			case 'date':
				return $this->process_date_reorder( $relation, $items, $scope );
		}

		return true;
	}

	/**
	 * Validate a positive storage/object ID without coercing expressions or overflowing.
	 *
	 * @param mixed $value Candidate integer or decimal integer string.
	 * @return int|false Normalized ID, or false for invalid input.
	 */
	protected function normalize_id( $value ) {
		if ( ! is_int( $value ) && ! is_string( $value ) ) {
			return false;
		}

		$value = (string) $value;
		if ( ! preg_match( '/^[0-9]+$/D', $value ) ) {
			return false;
		}

		$value = ltrim( $value, '0' );
		$id    = (int) $value;
		return $id > 0 && (string) $id === $value ? $id : false;
	}

	/**
	 * Resolve submitted IDs to fresh, authoritative rows before any mutation.
	 *
	 * Presentation filters and cached lists must not authorize database writes.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param mixed                          $items    Ordered rows containing storage IDs.
	 * @param array                          $scope    Optional authorized object field/value.
	 * @return array|\WP_Error Stored rows in submitted order, or a validation/database error.
	 */
	protected function get_reorder_rows( $relation, $items, $scope ) {
		$error = new \WP_Error( 'invalid_relation_order', __( 'Invalid related items order. Please reload and try again.', 'jet-engine' ) );
		if ( ! is_array( $items ) || ! is_array( $scope ) ) {
			return $error;
		}

		if ( $scope && ( ! isset( $scope['field'], $scope['value'] )
			|| ! in_array( $scope['field'], array( 'parent_object_id', 'child_object_id' ), true )
			|| false === $this->normalize_id( $scope['value'] ) ) ) {
			return $error;
		}

		$ids = array();
		foreach ( $items as $item ) {
			$id = is_array( $item ) && isset( $item['_ID'] ) ? $this->normalize_id( $item['_ID'] ) : false;
			if ( false === $id || isset( $ids[ $id ] ) ) {
				return $error;
			}
			$ids[ $id ] = $id;
		}

		if ( ! $ids ) {
			return array();
		}

		$db    = $relation->db::wpdb();
		$table = $relation->db->table();
		$where = $this->get_reorder_where( $relation, array_values( $ids ), $scope );
		$rows  = $db->get_results( "SELECT * FROM {$table} WHERE {$where}", ARRAY_A );
		if ( ! is_array( $rows ) || $db->last_error ) {
			return $this->database_error();
		}

		$stored = array();
		foreach ( $rows as $row ) {
			$stored[ (int) $row['_ID'] ] = $row;
		}

		$ordered = array();
		foreach ( $ids as $id ) {
			if ( ! isset( $stored[ $id ] ) ) {
				return $error;
			}
			$ordered[] = $stored[ $id ];
		}
		return $ordered;
	}

	/**
	 * Build a prepared predicate using validated IDs and a server-selected scope column.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param int[]                          $ids      Validated storage IDs.
	 * @param array                          $scope    Validated authorized object field/value.
	 * @return string Prepared SQL predicate.
	 */
	protected function get_reorder_where( $relation, $ids, $scope ) {
		$sql  = 'rel_id = %s AND _ID IN (' . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ')';
		$args = array_merge( array( $relation->get_id() ), $ids );
		if ( $scope ) {
			$sql   .= ' AND ' . $scope['field'] . ' = %d';
			$args[] = $scope['value'];
		}
		return $relation->db::wpdb()->prepare( $sql, $args );
	}

	/**
	 * Recreate validated rows in reverse order, preserving stored relationship fields.
	 *
	 * This legacy two-statement operation is not atomic: an insert failure can leave
	 * deleted links absent. Never insert after a failed or incomplete deletion.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param array                          $items    Ordered rows containing storage IDs.
	 * @param array                          $scope    Optional authorized object field/value.
	 * @return true|\WP_Error Operation result.
	 */
	public function process_id_reorder( $relation, $items = array(), $scope = array() ) {
		$rows = $this->get_reorder_rows( $relation, $items, $scope );
		if ( is_wp_error( $rows ) || ! $rows ) {
			return is_wp_error( $rows ) ? $rows : true;
		}

		$db    = $relation->db::wpdb();
		$table = $relation->db->table();
		$where = $this->get_reorder_where( $relation, array_column( $rows, '_ID' ), $scope );
		$values = array();
		foreach ( array_reverse( $rows ) as $row ) {
			// Keep nullable fields and string relation IDs exactly as stored.
			$parts = array();
			foreach ( array( 'rel_id' => '%s', 'parent_rel' => '%d', 'parent_object_id' => '%d', 'child_object_id' => '%d' ) as $field => $format ) {
				$parts[] = null === $row[ $field ] ? 'NULL' : $db->prepare( $format, $row[ $field ] );
			}
			$values[] = '(' . implode( ', ', $parts ) . ')';
		}

		$deleted = $db->query( "DELETE FROM {$table} WHERE {$where}" );
		if ( false === $deleted || count( $rows ) !== $deleted ) {
			$this->invalidate_caches( $relation, $rows );
			return $this->database_error();
		}

		$inserted = $db->query( "INSERT INTO {$table} (rel_id, parent_rel, parent_object_id, child_object_id) VALUES " . implode( ', ', $values ) );
		$this->invalidate_caches( $relation, $rows );
		return false !== $inserted && count( $rows ) === $inserted ? true : $this->database_error();
	}

	/**
	 * Update ordering timestamps without changing storage IDs or relationship fields.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param array                          $items    Ordered rows containing storage IDs.
	 * @param array                          $scope    Optional authorized object field/value.
	 * @return true|\WP_Error Operation result; zero changed rows is successful.
	 */
	public function process_date_reorder( $relation, $items = array(), $scope = array() ) {
		$rows = $this->get_reorder_rows( $relation, $items, $scope );
		if ( is_wp_error( $rows ) || ! $rows ) {
			return is_wp_error( $rows ) ? $rows : true;
		}

		$db        = $relation->db::wpdb();
		$base_date = wp_date( 'Y-m-d' );
		$case      = array();
		foreach ( array_reverse( $rows ) as $index => $row ) {
			$case[] = $db->prepare( 'WHEN _ID = %d THEN %s', $row['_ID'], $base_date . ' ' . gmdate( 'H:i:s', $index + 1 ) );
		}

		$table = $relation->db->table();
		$where = $this->get_reorder_where( $relation, array_column( $rows, '_ID' ), $scope );
		$result = $db->query( "UPDATE {$table} SET created = CASE " . implode( ' ', $case ) . " ELSE created END WHERE {$where}" );
		$this->invalidate_caches( $relation, $rows );
		return false === $result ? $this->database_error() : true;
	}

	/**
	 * Clear affected pair/object caches and the relation's in-memory DB caches.
	 *
	 * @param \Jet_Engine\Relations\Relation $relation Relation instance.
	 * @param array                          $rows     Authoritative affected rows.
	 * @return void
	 */
	protected function invalidate_caches( $relation, $rows ) {
		$pairs = array();
		foreach ( $rows as $row ) {
			$key = $row['parent_object_id'] . ':' . $row['child_object_id'];
			if ( ! isset( $pairs[ $key ] ) ) {
				$relation->flush_cache( $row['parent_object_id'], $row['child_object_id'] );
				$pairs[ $key ] = true;
			}
		}
		$relation->reset_db_cache();
	}

	/**
	 * Return a database failure without exposing SQL or database diagnostics.
	 *
	 * @return \WP_Error Generic reorder failure.
	 */
	protected function database_error() {
		return new \WP_Error( 'relation_order_failed', __( 'Could not save related items order. Please reload and try again.', 'jet-engine' ) );
	}

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return static
	 */
	public static function instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

}
