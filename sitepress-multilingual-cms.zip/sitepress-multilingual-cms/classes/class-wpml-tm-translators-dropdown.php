<?php

class WPML_TM_Translators_Dropdown {

	private $blog_translators;

	public function __construct( $blog_translators ) {
		$this->blog_translators = $blog_translators;
	}

	public function render( $args = array() ) {
		$dropdown = '';


		$from         = false;
		$to           = false;
		$id           = 'translator_id';
		$name         = 'translator_id';
		$selected     = 0;
		$echo         = true;
		$add_label    = false;
		$services     = array( 'local' );
		$disabled     = false;
		$default_name = false;
		$local_only   = false;

		extract( $args, EXTR_OVERWRITE );

		$translators = array();

		$id .= $from ? '_' . $from . ( $to ? '_' . $to : '' ) : '';

		try {

			$translation_service      = TranslationProxy::get_current_service();
			$translation_service_id   = TranslationProxy::get_current_service_id();
			$translation_service_name = TranslationProxy::get_current_service_name();
			$is_service_authenticated = TranslationProxy::is_service_authenticated();

			if ( isset( $translation_service->id ) && ! TranslationProxy::translator_selection_available() && $is_service_authenticated ) {
				$translators[] = (object) array(
					'ID'           => TranslationProxy_Service::get_wpml_translator_id( $translation_service->id ),
					/* translators: First option in the dropdown that picks a translator: whoever is free first takes the job. */
					'display_name' => __( 'First available', 'sitepress' ),
					'service'      => $translation_service_name,
				);
			} elseif ( in_array( $translation_service_id, $services ) && $is_service_authenticated ) {
				$lang_status = TranslationProxy_Translator::get_language_pairs();
				if ( empty( $lang_status ) ) {
					$lang_status = array();
				}
				foreach ( (array) $lang_status as $language_pair ) {
					if ( $from && $from != $language_pair['from'] ) {
						continue;
					}
					if ( $to && $to != $language_pair['to'] ) {
						continue;
					}

					if ( ! empty( $language_pair['translators'] ) ) {
						if ( 1 < count( $language_pair['translators'] ) ) {
							$translators[] = (object) array(
								'ID'           => TranslationProxy_Service::get_wpml_translator_id( $translation_service->id ),
								/* translators: First option in the dropdown that picks a translator: whoever is free first takes the job. */
								'display_name' => __( 'First available', 'sitepress' ),
								'service'      => $translation_service_name,
							);
						}
						foreach ( $language_pair['translators'] as $tr ) {
							if ( ! isset( $_icl_translators[ $tr['id'] ] ) ) {
								$translators[] = $_icl_translators[ $tr['id'] ] = (object) array(
									'ID'           => TranslationProxy_Service::get_wpml_translator_id( $translation_service->id, $tr['id'] ),
									'display_name' => $tr['nickname'],
									'service'      => $translation_service_name,
								);
							}
						}
					}
				}
			}

			if ( in_array( 'local', $services ) ) {
				$translators[] = (object) array(
					'ID'           => 0,
					/* translators: First option in the dropdown that picks a translator: whoever is free first takes the job. */
					'display_name' => __( 'First available', 'sitepress' ),
				);
				$translators   = array_merge(
					$translators,
					$this->blog_translators->get_blog_translators(
						array(
							'from' => $from,
							'to'   => $to,
						)
					)
				);
			}
			$translators = apply_filters( 'wpml_tm_translators_list', $translators );

			$dropdown .= '<select id="' . esc_attr( $id ) . '" class="js-wpml-translator-dropdown" data-lang-to="' . esc_attr( (string) $to ) . '"
								  name="' . esc_attr( $name ) . '" ' . ( $disabled ? 'disabled="disabled"' : '' ) . '>';

			if ( $default_name ) {
				$dropdown_selected = selected( $selected, false, false );
				$dropdown         .= '<option value="" ' . $dropdown_selected . '>';
				$dropdown         .= esc_html( $default_name );
				$dropdown         .= '</option>';
			}

			foreach ( $translators as $t ) {
				if ( $local_only && isset( $t->service ) ) {
					continue;
				}
				$current_translator = $t->ID;

				$dropdown_selected = selected( $selected, $current_translator, false );
				$dropdown         .= '<option value="' . $current_translator . '" ' . $dropdown_selected . '>';
				$dropdown         .= isset( $t->service ) ? $t->service : esc_html( $t->display_name );
				$dropdown         .= '</option>';
			}
			$dropdown .= '</select>';
		} catch ( WPMLTranslationProxyApiException $ex ) {
			$dropdown .= esc_html__( 'Translation Proxy error', 'sitepress' ) . ': ' . $ex->getMessage();
		} catch ( Exception $ex ) {
			/* translators: Word in front of the details of something that went wrong; a colon and the details follow it. */
			$dropdown .= esc_html__( 'Error', 'sitepress' ) . ': ' . $ex->getMessage();
		}

		if ( $add_label ) {
			/* translators: Label in front of the dropdown that picks whose translation jobs are listed; the names follow the colon. */
			$dropdown = '<label for="' . esc_attr( $id ) . '">' . esc_html__( 'Translation jobs for:', 'sitepress' ) . '</label>&nbsp;' . $dropdown;
		}

		if ( $echo ) {
			echo $dropdown;
		}

		return $dropdown;
	}
}
