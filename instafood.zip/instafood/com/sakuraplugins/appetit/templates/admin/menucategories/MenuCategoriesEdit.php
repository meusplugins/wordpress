<?php
namespace com\sakuraplugins\appetit\templates\admin\menucategories;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../../../cpt/MenuItemCpt.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt;

class MenuCategoriesEdit {

    function onNewCategory($taxonomy) {
        ?>
            <div class="form-group">
                <label for="category_name_1"><?= esc_html__('Category name (Primary language)*', 'instafood') ?></label>
                <input type="text" value="" required
                    class="form-control" id="category_name_1" required name="<?= esc_attr(MenuItemCpt::MENU_CAT_META_KEY . '[primary_lang_category_name]') ?>">
            </div>
            <div class="form-group">
                <label for="category_name_2"><?= esc_html__('Category name (Optional - secondary language)', 'instafood') ?></label>
                <input type="text" value=""
                    class="form-control" id="category_name_2" required name="<?= esc_attr(MenuItemCpt::MENU_CAT_META_KEY . '[secondary_lang_category_name]') ?>">
            </div>
        <?php
    }

    function onEditCategory($term) {
        $post_meta = get_term_meta($term->term_id, MenuItemCpt::MENU_CAT_META_KEY, true);
        ?>
            <tr>
                <th>
                    <?= esc_html__('Category name (Primary language)*', 'instafood') ?>
                </th>
                <td>
                    <input type="text" required value="<?= isset($post_meta['primary_lang_category_name']) ? esc_attr($post_meta['primary_lang_category_name']) : '' ?>"
                    class="form-control" id="category_name_2" name="<?= esc_attr(MenuItemCpt::MENU_CAT_META_KEY . '[primary_lang_category_name]') ?>">
                </td>
            </tr>
            <tr>
                <th>
                    <?= esc_html__('Category name (Optional - secondary language)', 'instafood') ?>
                </th>
                <td>
                    <input type="text" value="<?= isset($post_meta['secondary_lang_category_name']) ? esc_attr($post_meta['secondary_lang_category_name']) : '' ?>"
                    class="form-control" id="category_name_2" name="<?= esc_attr(MenuItemCpt::MENU_CAT_META_KEY . '[secondary_lang_category_name]') ?>">
                </td>
            </tr>
        <?php
    }
}
?>