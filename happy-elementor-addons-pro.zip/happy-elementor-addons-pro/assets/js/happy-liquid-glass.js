"use strict";

(function ($, w) {
  "use strict";

  var $window = $(w);
  var HappyLiquidGlass = {
    numericPresets: Array.from({
      length: 25
    }, function (_, i) {
      return "ha-lg-preset" + (i + 1);
    }),
    namedPresets: ["ha-lg-container-glass", "ha-lg-goo", "ha-lg-diamond-glass", "ha-lg-lens-glass", "ha-lg-gooey", "ha-lg-macos-glass", "ha-lg-melted-glass", "ha-lg-crystal-glass", "ha-lg-water-ripple", "ha-lg-holographic-glass", "ha-lg-bubble-glass", "ha-lg-frozen-window", "ha-lg-jelly-surface", "ha-lg-wavy-water", "ha-lg-ice-crystal", "ha-lg-vapor-lens", "ha-lg-distorted-prism", "ha-lg-mercury-liquid", "ha-lg-visionos-glass", "ha-lg-custom"],
    presetParams: {
      1: {
        frequency: "0.02 0.02",
        scale: 80,
        name: "Soft Ripple"
      },
      2: {
        frequency: "0.004 0.004",
        scale: 125,
        name: "Deep Glass"
      },
      3: {
        frequency: "0.007 0.007",
        scale: 110,
        name: "Crystal Flow"
      },
      4: {
        frequency: "0.015 0.015",
        scale: 180,
        name: "Heavy Distortion"
      },
      5: {
        frequency: "0.01 0.01",
        scale: 95,
        name: "Liquid Mist"
      },
      6: {
        frequency: "0.003 0.008",
        scale: 140,
        name: "Vertical Wave"
      },
      7: {
        frequency: "0.008 0.003",
        scale: 130,
        name: "Horizontal Flow"
      },
      8: {
        frequency: "0.006 0.006",
        scale: 100,
        name: "Balanced Blur"
      },
      9: {
        frequency: "0.012 0.02",
        scale: 120,
        name: "Glass Storm"
      },
      10: {
        frequency: "0.005 0.015",
        scale: 160,
        name: "Molten Glass"
      },
      11: {
        frequency: "0.001 0.001",
        scale: 220,
        name: "Magnifier Lens"
      },
      12: {
        frequency: "0.025 0.025",
        scale: 45,
        name: "Micro Frost"
      },
      13: {
        frequency: "0.002 0.012",
        scale: 180,
        name: "Rain Streak"
      },
      14: {
        frequency: "0.012 0.002",
        scale: 180,
        name: "Wind Flow"
      },
      15: {
        frequency: "0.03 0.03",
        scale: 25,
        name: "Fine Crystal"
      },
      16: {
        frequency: "0.002 0.002",
        scale: 280,
        name: "Bubble Lens"
      },
      17: {
        frequency: "0.009 0.018",
        scale: 150,
        name: "Aqua Warp"
      },
      18: {
        frequency: "0.018 0.009",
        scale: 150,
        name: "Ocean Current"
      },
      19: {
        frequency: "0.04 0.01",
        scale: 70,
        name: "Prism Cut"
      },
      20: {
        frequency: "0.01 0.04",
        scale: 70,
        name: "Glass Fiber"
      },
      21: {
        frequency: "0.002 0.006",
        scale: 240,
        name: "Jelly Blob"
      },
      22: {
        frequency: "0.006 0.002",
        scale: 240,
        name: "Viscous Gel"
      },
      23: {
        frequency: "0.05 0.05",
        scale: 12,
        name: "Diamond Dust"
      },
      24: {
        frequency: "0.0015 0.0015",
        scale: 320,
        name: "Ultra Lens"
      },
      25: {
        frequency: "0.015 0.008",
        scale: 135,
        name: "Frozen Glass"
      }
    },
    customFilterMarkup: {
      "container-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.008 0.008" numOctaves="2" seed="92" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="0.02" result="blur"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="blur" scale="77" xChannelSelector="R" yChannelSelector="G"></feDisplacementMap>',
      "goo": '<feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur"></feGaussianBlur>' + '<feColorMatrix in="blur" type="matrix" result="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 16 -10"></feColorMatrix>' + '<feComposite in="matrix" operator="atop"></feComposite>',
      "diamond-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="1" seed="20" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="10"></feDisplacementMap>' + '<feSpecularLighting surfaceScale="3" specularConstant="1" specularExponent="20">' + '<fePointLight x="50" y="50" z="100"></fePointLight>' + '</feSpecularLighting>',
      "lens-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.005" numOctaves="1" seed="1" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="60"></feDisplacementMap>',
      "gooey": '<feGaussianBlur in="SourceGraphic" stdDeviation="8" result="blur"></feGaussianBlur>' + '<feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -10"></feColorMatrix>' + '<feBlend in="SourceGraphic"></feBlend>',
      "macos-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.004" numOctaves="2" seed="10" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="0.6" result="blur"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="blur" scale="12"></feDisplacementMap>' + '<feGaussianBlur stdDeviation="0.3"></feGaussianBlur>',
      "melted-glass": '<feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur"></feGaussianBlur>' + '<feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 25 -12"></feColorMatrix>',
      "crystal-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="4" seed="8" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="15"></feDisplacementMap>' + '<feGaussianBlur stdDeviation="0.4"></feGaussianBlur>',
      "water-ripple": '<feTurbulence type="turbulence" baseFrequency="0.015" numOctaves="3" seed="3" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="25"></feDisplacementMap>',
      "holographic-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.012" numOctaves="3" seed="11" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="30"></feDisplacementMap>' + '<feColorMatrix type="saturate" values="1.8"></feColorMatrix>',
      "bubble-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.002" numOctaves="1" seed="15" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="4" result="blur"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="blur" scale="250"></feDisplacementMap>',
      "frozen-window": '<feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="5" seed="21" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="1"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="12"></feDisplacementMap>',
      "jelly-surface": '<feTurbulence type="fractalNoise" baseFrequency="0.003" numOctaves="2" seed="4" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="5" result="goo"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="goo" scale="180"></feDisplacementMap>',
      "wavy-water": '<feTurbulence type="turbulence" baseFrequency="0.008" numOctaves="4" seed="18" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="50"></feDisplacementMap>',
      "ice-crystal": '<feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="6" seed="9" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="18"></feDisplacementMap>' + '<feGaussianBlur stdDeviation="0.2"></feGaussianBlur>',
      "vapor-lens": '<feTurbulence type="fractalNoise" baseFrequency="0.004" numOctaves="3" seed="25" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="2" result="mist"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="mist" scale="140"></feDisplacementMap>',
      "distorted-prism": '<feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="2" seed="13" result="noise"></feTurbulence>' + '<feDisplacementMap in="SourceGraphic" in2="noise" scale="40"></feDisplacementMap>' + '<feColorMatrix type="saturate" values="2"></feColorMatrix>',
      "mercury-liquid": '<feTurbulence type="fractalNoise" baseFrequency="0.002" numOctaves="1" seed="40" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="8" result="smooth"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="smooth" scale="300"></feDisplacementMap>',
      "visionos-glass": '<feTurbulence type="fractalNoise" baseFrequency="0.0035 0.0035" numOctaves="2" seed="42" result="noise"></feTurbulence>' + '<feGaussianBlur in="noise" stdDeviation="1.5" result="blur"></feGaussianBlur>' + '<feDisplacementMap in="SourceGraphic" in2="blur" scale="60" xChannelSelector="R" yChannelSelector="G"></feDisplacementMap>' + '<feGaussianBlur stdDeviation="0.2"></feGaussianBlur>'
    },
    allPresetClasses: function allPresetClasses() {
      return this.numericPresets.concat(this.namedPresets);
    },
    init: function init() {
      elementorFrontend.hooks.addAction("frontend/element_ready/global", this.onElementReady.bind(this));
    },
    onElementReady: function onElementReady($scope) {
      var matchedPresets = this.getLiquidGlassPresets($scope);
      if (!matchedPresets.length) {
        return;
      }
      for (var i = 0; i < matchedPresets.length; i++) {
        var presetKey = matchedPresets[i];
        if (presetKey === 'ha-lg-custom') {
          this.renderCustomFilter($scope);
        } else {
          $scope.css('backdrop-filter', '');
          $scope.css('-webkit-backdrop-filter', '');
          this.renderSVGFilter(presetKey);
        }
      }
    },
    renderCustomFilter: function renderCustomFilter($scope) {
      var el = $scope[0];
      var style = window.getComputedStyle(el);
      var freqX = this.trimCSSVar(style.getPropertyValue('--ha-lg-frequency-x')) || '0.006';
      var freqY = this.trimCSSVar(style.getPropertyValue('--ha-lg-frequency-y')) || '0.006';
      var scale = this.trimCSSVar(style.getPropertyValue('--ha-lg-scale')) || '80';
      var octaves = this.trimCSSVar(style.getPropertyValue('--ha-lg-octaves')) || '2';
      var seed = this.trimCSSVar(style.getPropertyValue('--ha-lg-seed')) || '92';
      var xChannel = this.trimCSSVar(style.getPropertyValue('--ha-lg-x-channel')) || 'R';
      var yChannel = this.trimCSSVar(style.getPropertyValue('--ha-lg-y-channel')) || 'G';
      var elementId = $scope.data('id') || $scope.attr('id');
      if (!elementId) {
        elementId = $scope.attr('data-ha-lg-uid');
        if (!elementId) {
          elementId = 'el-' + Math.random().toString(36).substr(2, 9);
          $scope.attr('data-ha-lg-uid', elementId);
        }
      }
      var filterId = 'ha-glass-distortion-custom-' + elementId;
      var svgClass = 'ha-lg-svg-custom-' + elementId;
      $('.' + svgClass).remove();
      var filterInner = '<feTurbulence type="fractalNoise" baseFrequency="' + freqX + ' ' + freqY + '" numOctaves="' + octaves + '" seed="' + seed + '" result="noise" />' + '<feGaussianBlur in="noise" stdDeviation="2" result="blurred" />' + '<feDisplacementMap in="SourceGraphic" in2="blurred" scale="' + scale + '" xChannelSelector="' + xChannel + '" yChannelSelector="' + yChannel + '" />';
      var svgMarkup = '<svg class="' + svgClass + '" xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;overflow:hidden">' + '<defs>' + '<filter id="' + filterId + '" x="0%" y="0%" width="100%" height="100%">' + filterInner + '</filter>' + '</defs>' + '</svg>';
      $("body").append(svgMarkup);
      $scope.css('backdrop-filter', 'blur(var(--ha-lg-blur, 8px)) url(#' + filterId + ')');
      $scope.css('-webkit-backdrop-filter', 'blur(var(--ha-lg-blur, 8px)) url(#' + filterId + ')');
    },
    trimCSSVar: function trimCSSVar(val) {
      return val ? val.trim() : '';
    },
    getLiquidGlassPresets: function getLiquidGlassPresets($scope) {
      var found = [];
      var allClasses = this.allPresetClasses();
      for (var i = 0; i < allClasses.length; i++) {
        var cls = allClasses[i];
        if ($scope.hasClass(cls)) {
          found.push(cls);
          continue;
        }
        var $children = $scope.find("." + cls);
        if ($children.length) {
          found.push(cls);
        }
      }
      var unique = [];
      for (var j = 0; j < found.length; j++) {
        if (unique.indexOf(found[j]) === -1) {
          unique.push(found[j]);
        }
      }
      return unique;
    },
    renderSVGFilter: function renderSVGFilter(presetKey) {
      var filterId = this.getFilterId(presetKey);
      if (!filterId) {
        return;
      }
      var svgClass = "ha-lg-svg-" + presetKey.replace(/ha-lg-/, "");
      if ($("." + svgClass).length) {
        return;
      }
      var filterInner = this.getFilterInnerMarkup(presetKey);
      if (!filterInner) {
        return;
      }
      var svgMarkup = '<svg class="' + svgClass + '" xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;overflow:hidden">' + '<defs>' + '<filter id="' + filterId + '" x="0%" y="0%" width="100%" height="100%">' + filterInner + '</filter>' + '</defs>' + '</svg>';
      $("body").append(svgMarkup);
    },
    getFilterId: function getFilterId(presetKey) {
      var numericMatch = presetKey.match(/preset(\d+)/);
      if (numericMatch) {
        return "ha-glass-distortion-" + numericMatch[1];
      }
      var namedMatch = presetKey.match(/^ha-lg-(.+)$/);
      if (namedMatch) {
        return "ha-glass-distortion-" + namedMatch[1];
      }
      return null;
    },
    getFilterInnerMarkup: function getFilterInnerMarkup(presetKey) {
      var numericMatch = presetKey.match(/preset(\d+)/);
      if (numericMatch) {
        var num = parseInt(numericMatch[1], 10);
        var params = this.presetParams[num];
        if (!params) {
          return null;
        }
        return '<feTurbulence type="fractalNoise" baseFrequency="' + params.frequency + '" numOctaves="2" seed="92" result="noise" />' + '<feGaussianBlur in="noise" stdDeviation="2" result="blurred" />' + '<feDisplacementMap in="SourceGraphic" in2="blurred" scale="' + params.scale + '" xChannelSelector="R" yChannelSelector="G" />';
      }
      var namedMatch = presetKey.match(/^ha-lg-(.+)$/);
      if (namedMatch && this.customFilterMarkup[namedMatch[1]]) {
        return this.customFilterMarkup[namedMatch[1]];
      }
      return null;
    }
  };
  $window.on("elementor/frontend/init", function () {
    HappyLiquidGlass.init();
  });
})(jQuery, window);