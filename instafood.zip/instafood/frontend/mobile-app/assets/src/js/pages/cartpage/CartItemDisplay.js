import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Events } from '../../events/EventBus';
import Cart from '../../cart/Cart';

class CartItemDisplay {
    _cartItemData = null;
    _parentUI = null;
    _ui;
    _quantity;

    constructor(cartItemData, parentUI) {
        this._cartItemData = cartItemData;
        this._parentUI = parentUI;
        this._quantity = _.get(this._cartItemData, 'quantity', 1);
    }

    render() {
        const _this = this;
        const t = DataUtils.getInstance().getOption('price_display_template');
        const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));
        const total = _.get(this._cartItemData, 'cartItemTotal', 0);
        const formattedPrice = DataUtils.getInstance().getFormmatedPriceDisplay(total);
        const priceTotal = priceTemplate({ price: formattedPrice });
        const choicesInfo = _.get(this._cartItemData, 'choicesInfo', '');

        const cartProductTemplate = `
            <div class="screen_content_entry underline">
                <div class="cart-product-entry">
                    <div class="cpe-product-info-ui">
                        <div class="cpe-product-info">
                            <div class="title"><span class="icon-edit mr_5"></span> ${ _.get(this._cartItemData, 'productTitle', '') }</div>
                            ${ choicesInfo !== '' ? `<div class="summary text_grey">${ choicesInfo }</div>` : '' }
                        </div>
                        <div class="cpe-product-price">${ priceTotal }</div>
                    </div>
                    <div class="cpe-quantity">
                        <div class="quantity-info">${ this._quantity }</div>
                        <div class="quantity-controls">
                            <a href="#" class="square_nav q_min">
                                <span class="icon-minus"></span>
                            </a>
                            <div class="separator"></div>
                            <a href="#" class="square_nav q_plus">
                                <span class="icon-plus"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        `;
        this._ui = jQuery(cartProductTemplate);
        this._ui.appendTo(this._parentUI);

        this._ui.find('.cpe-product-info').click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_AND_OPEN_EDIT_PRODUCT, {
                productId: _this._cartItemData.cartProduct.getProduct().ID,
                categoryId: _this._cartItemData.cartProduct.getProductCategoryId(),
                existingCartProduct: _this._cartItemData.cartProduct
            });
        })

        this._ui.find('.q_min').click(function(event) {
            event.preventDefault();
            _this._quantity -= 1;
            _this._handleQuantityChange();
        })
        this._ui.find('.q_plus').click(function(event) {
            event.preventDefault();
            _this._quantity += 1;
            _this._handleQuantityChange();
        })
    }

    _handleQuantityChange() {
        this._ui.find('.quantity-info').html(this._quantity);
        const cartProduct = _.get(this._cartItemData, 'cartProduct', {});
        if (this._quantity === 0) {
            this._ui.remove();
            Cart.getInstance().remove(cartProduct);
        } else {
            cartProduct.setQuantity(this._quantity);
            Cart.getInstance().update(cartProduct);

            const t = DataUtils.getInstance().getOption('price_display_template');
            const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));
            const total = cartProduct.getTotal();
            const formattedPrice = DataUtils.getInstance().getFormmatedPriceDisplay(total);
            const priceTotal = priceTemplate({ price: formattedPrice });
            this._ui.find('.cpe-product-price').html(priceTotal);
        }
    }


}
export default CartItemDisplay;