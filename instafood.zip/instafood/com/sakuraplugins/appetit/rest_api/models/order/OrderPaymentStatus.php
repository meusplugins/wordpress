<?php
namespace com\sakuraplugins\appetit\rest_api\models;
if (!defined('ABSPATH')) exit;

abstract class OrderPaymentStatus {
    const PENDING_TRANSACTION = 'PENDING_TRANSACTION';
    const PAYMENT_INTENT_SUCCEDED = 'PAYMENT_INTENT_SUCCEDED';
    const PENDING_ON_DELIVERY = 'PENDING_ON_DELIVERY';
    const PAYMENT_FAILED = 'PAYMENT_FAILED';
    const PAYMENT_CANCELED = 'PAYMENT_CANCELED';
    const PAID = 'PAID';

    static function getMappedToLabels() {
        return [
            self::PENDING_TRANSACTION => esc_html__('Pending transaction', 'instafood'),
            self::PAYMENT_INTENT_SUCCEDED => esc_html__('Payment intend succeeded', 'instafood'),
            self::PENDING_ON_DELIVERY => esc_html__('Pending on delivery', 'instafood'),
            self::PAYMENT_FAILED => esc_html__('Failed', 'instafood'),
            self::PAYMENT_CANCELED => esc_html__('Cancelled', 'instafood'),
            self::PAID => esc_html__('Paid', 'instafood'),
        ];
    }
}
?>