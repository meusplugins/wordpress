<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class OrderOptions {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Order general options', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->renderOrderGeneralOptions() ?></div>
        </div>
        <?php
    }

    private function renderOrderGeneralOptions() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <?php
                    $delivery_enabled = OptionUtil::getInstance()->getOption("delivery_enabled", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="delivery_enabled_id"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[delivery_enabled]" 
                        <?= $delivery_enabled === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="delivery_enabled_id"><?= esc_html__('Enable local delivery', 'instafood'); ?></label>
                        <div class="option-entry-info"><?= esc_html__("Allow customers to place an online order. Note! Google Maps API Key must be set also, within the checkout process the max delivery radius will be checked against the user's address.", 'instafood'); ?></div>
                    </div>
                    <label class="option-entry-label" style="font-size: 15px; margin-bottom: 15px;"><?= esc_html__('Payment options for delivery', 'instafood'); ?></label>
                    <?php
                    $delivery_payment_cash_on_delivery = OptionUtil::getInstance()->getOption("delivery_payment_cash_on_delivery", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="delivery_payment_cash_on_delivery"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[delivery_payment_cash_on_delivery]" 
                        <?= $delivery_payment_cash_on_delivery === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="delivery_payment_cash_on_delivery"><?= esc_html__('Cash on delivery', 'instafood'); ?></label>
                    </div>
                    <?php
                    $delivery_payment_stripe = OptionUtil::getInstance()->getOption("delivery_payment_stripe", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="delivery_payment_stripe"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[delivery_payment_stripe]" 
                        <?= $delivery_payment_stripe === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="delivery_payment_stripe"><?= esc_html__('Card (Stripe)', 'instafood'); ?></label>
                    </div>
                </div>
                <div class="col-md-6">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Min order value', 'instafood'); ?></label>
                        <input type="number" min="0"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_delivery_min_order_value', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_delivery_min_order_value]"
                            class="form-control">

                            <div class="option-entry-info"><?= esc_html__("Min order value will not apply for local (dine-in) orders.", 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Max delivery radius (distance in Miles)', 'instafood'); ?></label>
                        <input type="number" min="0"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_max_delivery_radius', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_max_delivery_radius]"
                            class="form-control">
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Delivery cost', 'instafood'); ?></label>
                        <input type="number" min="0"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('order_delivery_cost', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[order_delivery_cost]"
                            class="form-control">
                            
                        <div class="option-entry-info"><?= esc_html__("Leave empty if delivery is free", 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Tipping percentage', 'instafood'); ?></label>
                        <input type="number" min="0"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('tipping_percentage', '15')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[tipping_percentage]"
                            class="form-control">
                            
                        <div class="option-entry-info"><?= esc_html__("Leave empty if there is no tipping. This option applies for delivery and dine-in.", 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">

                        <?php
                        $disabled_add_to_cart = OptionUtil::getInstance()->getOption("disabled_add_to_cart", '');
                        ?>
                        <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                            <input type="checkbox" class="custom-control-input day_abailable_cb"  
                            id="disabled_add_to_cart_id"
                            value="ON"
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[disabled_add_to_cart]" 
                            <?= $disabled_add_to_cart === 'ON' ? "checked" : "" ?>
                            >
                            <label class="custom-control-label" for="disabled_add_to_cart_id"><?= esc_html__('Disable add to cart', 'instafood'); ?></label>
                            <div class="option-entry-info"><?= esc_html__("By disabling Add to cart, customers won't be able to add products to the cart and go to checkout.", 'instafood'); ?></div>
                        </div>

                    </div>
                </div>
                <div class="col-md-6"></div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
                
                <div class="col-md-6">
                    <?php
                    $local_order_enabled = OptionUtil::getInstance()->getOption("local_order_enabled", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="local_order_enabled_id"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[local_order_enabled]" 
                        <?= $local_order_enabled === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="local_order_enabled_id"><?= esc_html__('Enable local (dine in) order', 'instafood'); ?></label>
                        <div class="option-entry-info"><?= esc_html__("Allow customers to place an online order from within the restaurant. Note! QR codes need to be created and placed on their respective tables also.", 'instafood'); ?></div>
                    </div>

                    <?php
                    $local_order_print_bill_table_no = OptionUtil::getInstance()->getOption("local_order_print_bill_table_no", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="local_order_print_bill_table_no_id"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[local_order_print_bill_table_no]" 
                        <?= $local_order_print_bill_table_no === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="local_order_print_bill_table_no_id"><?= esc_html__('Dine-in - Print bill: Include table no', 'instafood'); ?></label>
                        <div class="option-entry-info"><?= esc_html__("Include the table number when printing the bill. Note! This does not apply to thermal printers. For thermal printers, this can be achieved with custom code from the child plugin.", 'instafood'); ?></div>
                    </div>

                    <label class="option-entry-label" style="font-size: 15px; margin-bottom: 15px;"><?= esc_html__('Payment options for dine in', 'instafood'); ?></label>
                    <?php
                    $dine_in_payment_cash_on_delivery = OptionUtil::getInstance()->getOption("dine_in_payment_cash_on_delivery", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="dine_in_payment_cash_on_delivery"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[dine_in_payment_cash_on_delivery]" 
                        <?= $dine_in_payment_cash_on_delivery === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="dine_in_payment_cash_on_delivery"><?= esc_html__('Cash on delivery', 'instafood'); ?></label>
                    </div>
                    <?php
                    $dine_in_payment_stripe = OptionUtil::getInstance()->getOption("dine_in_payment_stripe", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="dine_in_payment_stripe"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[dine_in_payment_stripe]" 
                        <?= $dine_in_payment_stripe === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="dine_in_payment_stripe"><?= esc_html__('Card (Stripe)', 'instafood'); ?></label>
                    </div>
                </div>
                <div class="col-md-6"></div>

                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>


                <div class="col-md-6">
                    <?php
                    $pickup_order_enabled = OptionUtil::getInstance()->getOption("pickup_order_enabled", '');
                    ?>
                    <div class="alert alert-danger pickup_error_info" role="alert">
                        <?= esc_html__('In order to enable pick up, the restaurant must set business hours for at least one weekday. Business hours can be added from General settings > Restaurant business hours.', 'instafood'); ?>
                    </div>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="pickup_order_enabled_id"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[pickup_order_enabled]" 
                        <?= $pickup_order_enabled === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="pickup_order_enabled_id"><?= esc_html__('Enable pickup order', 'instafood'); ?></label>
                        <div class="option-entry-info"><?= esc_html__('Allow customers to place an online order for pick up at the local store.', 'instafood'); ?></div>
                    </div>
                    <label class="option-entry-label" style="font-size: 15px; margin-bottom: 15px;"><?= esc_html__('Payment options for pickup', 'instafood'); ?></label>
                    <?php
                    $pickup_payment_cash_on_delivery = OptionUtil::getInstance()->getOption("pickup_payment_cash_on_delivery", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="pickup_payment_cash_on_delivery"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[pickup_payment_cash_on_delivery]" 
                        <?= $pickup_payment_cash_on_delivery === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="pickup_payment_cash_on_delivery"><?= esc_html__('Cash on delivery', 'instafood'); ?></label>
                    </div>
                    <?php
                    $pickup_payment_stripe = OptionUtil::getInstance()->getOption("pickup_payment_stripe", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="pickup_payment_stripe"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[pickup_payment_stripe]" 
                        <?= $pickup_payment_stripe === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="pickup_payment_stripe"><?= esc_html__('Card (Stripe)', 'instafood'); ?></label>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Pickup start date (days no)', 'instafood'); ?></label>
                        <input type="number" min="1"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('order_pickup_start_date', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[order_pickup_start_date]"
                            class="form-control">
                        <div class="alert alert-primary mt_15" role="alert" style="font-size: 14px;">
                            <?= esc_html__("Pickup start date in days. Leave empty if orders can be placed right away. If the field value is 2, the user can choose the pickup day two days from the current date. For example, this feature is useful if a shop would sell birthday cakes that need a longer preparation time.", 'instafood'); ?>
                        </div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Pickup end date (days no)', 'instafood'); ?></label>
                        <input type="number" min="1"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('order_pickup_end_date', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[order_pickup_end_date]"
                            class="form-control">
                        <div class="alert alert-primary mt_15" role="alert" style="font-size: 14px;">
                            <?= esc_html__("Pickup availability in days. The value represents the maximum number of days a user can choose to pick up the order. Leave empty if orders can only be picked up only within the same day.", 'instafood'); ?>
                        </div>
                    </div>

                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <h6><?php esc_html_e('OrderSafeMatch is enabled for pickup', 'instafood'); ?></h6>
                            <p><?php esc_html_e('Customers are presented with an order specific colour and code image.', 'instafood'); ?></p>

                            <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                                <?= esc_html__("OrderSafeMatch technology uses a unique combination of colour and pickup number to easily verify orders and to ensure accuracy and simplicity. OrderSafeMatch also speeds up the curbside and in-store order pickup process.", 'instafood'); ?>
                            </div>
                            <img style="max-width: 150px;" src="<?= esc_url(INSTAFOOD_QR_BASE_URL . '/assets/admin/img/curb-side-info.jpg') ?>" alt="">
                        </div>
                        <div class="col-md-6"></div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }
}