<?php
/** @noinspection PhpMultipleClassDeclarationsInspection */
/** @noinspection TransitiveDependenciesUsageInspection */

/**
 * Provides the controller for the WebAuthn API.
 *
 * @package REALLY_SIMPLE_SSL
 *
 * @noinspection
 */

namespace RSSSL\Pro\Security\WordPress\Two_Fa\Controllers;

require_once rsssl_path . 'pro/lib/webauthn/bootstrap.php';

use Exception;
use JsonException;
use RSSSL\Pro\Security\WordPress\Passkey\Rsssl_Public_Credential_Resource;
use RSSSL\Pro\Security\WordPress\Passkey\Rsssl_User_Entity_Creator;
use RSSSL\Pro\Security\WordPress\Two_Fa\Providers\Rsssl_Two_Factor_Passkey;
use RSSSL\Security\WordPress\Two_Fa\Controllers\Rsssl_Abstract_Controller;
use RSSSL\Security\WordPress\Two_Fa\Models\Rsssl_Request_Parameters;
use RSSProVendor\Base64Url\Base64Url;
use RSSProVendor\Nyholm\Psr7\Factory\Psr17Factory;
use RSSProVendor\Psr\Http\Message\ServerRequestInterface;
use RSSProVendor\Webauthn\PublicKeyCredentialCreationOptions;
use RSSProVendor\Webauthn\PublicKeyCredentialDescriptor;
use RSSProVendor\Webauthn\PublicKeyCredentialOptions;
use RSSProVendor\Webauthn\PublicKeyCredentialRequestOptions;
use RSSProVendor\Webauthn\PublicKeyCredentialRpEntity;
use RSSProVendor\Webauthn\Server;
use RuntimeException;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_User;

final class Rsssl_WebAuthn_Controller extends Rsssl_Abstract_Controller
{

    private Server $server;
    private Rsssl_Public_Credential_Resource $credentialRepository;

    /**
     * Constructor for the class.
     *
     * Initializes the class by creating an instance of PublicKeyCredentialRpEntity,
     * initializing the credentialRepository property, and creating an instance of Server class.
     *
     * @return void
     */
    public function __construct($namespace, $version, $featureVersion)
    {
        parent::__construct($namespace, $version, $featureVersion);
        add_action('rest_api_init', array($this, 'register_api_routes'));
        $rpEntity = new PublicKeyCredentialRpEntity(
            get_bloginfo('name'),
            parse_url(home_url(), PHP_URL_HOST)
        );

        $this->credentialRepository = new Rsssl_Public_Credential_Resource();
        $this->server = new Server($rpEntity, $this->credentialRepository);
        $this->server->setMetadataStatementRepository(new Rsssl_User_Entity_Creator());
    }

    /**
     * Retrieves the server request.
     *
     * This method creates a server request object using the Psr17Factory and returns it.
     *
     * @return ServerRequestInterface The server request object.
     */
    public function create_server_request(): ServerRequestInterface
    {
        return (new Psr17Factory())->createServerRequest('POST', home_url($_SERVER['REQUEST_URI']));
    }

    /**
     * Starts the registration process for a user.
     *
     * @param WP_REST_Request $request The REST request object containing the necessary information.
     *
     * @return WP_REST_Response Returns a WP_REST_Response object with the registration options,
     *                           or an error response if the user is not authenticated or not found.
     */
    public function start_registration(WP_REST_Request $request): WP_REST_Response
    {
        $parameters = new Rsssl_Request_Parameters($request);
        try {
            $user = $this->check_login_and_get_user($parameters->user_id, $parameters->login_nonce);
        } catch (Exception $e) {
            return new WP_REST_Response(['message' => $e->getMessage()], 403);
        }

        // Pre-auth nonce is not enough to add a passkey after 2FA exists.
        // Logged-in owners already passed 2FA and may manage their profile.
        if ($this->has_configured_provider($user) && ! $this->is_logged_in_owner($user)) {
            return new WP_REST_Response(
                [
                    'error' => __('Two-Factor Authentication must be completed before it can be changed.', 'really-simple-ssl'),
                ],
                403
            );
        }

        $userEntity = $this->credentialRepository->create_public_key_credential_user_entity($user, $user->ID);
        $creationOptions = $this->server->generatePublicKeyCredentialCreationOptions($userEntity);

        update_user_meta($parameters->user_id, 'webauthn_creation_options', $creationOptions->jsonSerialize());

        return new WP_REST_Response($creationOptions->jsonSerialize(), 200);
    }

    /**
     * Completes the registration process for a user.
     *
     * @param WP_REST_Request $request The REST request object.
     *
     * @return WP_REST_Response Returns a REST response object.
     *
     * @throws Exception If there was an error during the registration process.
     */
    public function complete_registration(WP_REST_Request $request): WP_REST_Response
    {
        $parameters = new Rsssl_Request_Parameters($request);
        try {
            $user = $this->check_login_and_get_user($parameters->user_id, $parameters->login_nonce);
        } catch (Exception $e) {
            return new WP_REST_Response(['message' => $e->getMessage()], 403);
        }

        // Pre-auth nonce is not enough to finish passkey setup after 2FA exists.
        // Logged-in owners already passed 2FA and may manage their profile.
        if ($this->has_configured_provider($user) && ! $this->is_logged_in_owner($user)) {
            return new WP_REST_Response(
                [
                    'error' => __('Two-Factor Authentication must be completed before it can be changed.', 'really-simple-ssl'),
                ],
                403
            );
        }

        if (is_wp_error($user)) {
            /** @var WP_Error $user */
            return new WP_REST_Response(['message' => $user->get_error_message()], $user->get_error_data()['status']);
        }

        $data = $this->decode_json_request( $request );

        if ( $data === null || ! $this->has_required_attestation_fields( $data ) ) {
            return new WP_REST_Response(['message' => __('Invalid attestation response data', 'really-simple-ssl')], 400);
        }


        $credential = $this->credentialRepository->userHasCredential($data['credential']['id']);

        if ($credential !== null) {
            return new WP_REST_Response(['message' => __('User already registered', 'really-simple-ssl')], 200);
        }

        try {
            $creationOptions = $this->get_public_key_credential_options_from_user($user->ID, 'creation');
            $serverRequest = $this->create_server_request();

            $attestationResponse = $this->server->loadAndCheckAttestationResponse(
                json_encode($data['credential'], JSON_THROW_ON_ERROR),
                $creationOptions,
                $serverRequest
            );
            $this->credentialRepository->saveCredentialSource(
                $attestationResponse,
                $user->ID,
                $parameters->auth_device_id
            );

            delete_user_meta($parameters->user_id, 'webauthn_creation_options');
        } catch (Exception $e) {
            return $this->handle_passkey_exception($e, 'registration');
        }
		 Rsssl_Two_Factor_Passkey::set_user_status($user->ID, 'active');
		 self::set_active_provider($user->ID, 'passkey');

		// User has been successfully registered, so we update the user meta so no further registration is needed.
	    update_user_meta($user->ID, 'rsssl_passkey_configured', 'configured');

        $redirect_url = $this->authenticate_user_and_get_redirect($user->ID, $parameters->redirect_to ?? admin_url());
        return new WP_REST_Response([
            'message' => __('Registration successful', 'really-simple-ssl'),
            'status' => 'success',
            'userHandle' => Base64Url::encode($attestationResponse->getUserHandle()),
            'redirect_to' => $redirect_url,
        ], 200);
    }

    /**
     * Returns WebAuthn assertion options for the passkey login ceremony.
     */
    public function challenge_assertion(WP_REST_Request $request): WP_REST_Response
    {
        $user_id = $this->extract_user_id_from_request($request);
        $user = $user_id ? $this->get_user_by_identifier($user_id) : false;

        $parameters = new Rsssl_Request_Parameters($request);
        $user_handle = !empty($parameters->user_login) ? $parameters->user_login : ($parameters->user_handle ?? '');

        $options = $this->generate_request_options(($user ?: null), $user_handle);
        return new WP_REST_Response($options->jsonSerialize(), 200);
    }

    /**
     * Verifies the assertion response for a given REST API request.
     *
     * @param WP_REST_Request $request The REST API request.
     */
    public function verify_assertion(WP_REST_Request $request): WP_REST_Response
    {
        $data = $this->decode_json_request( $request );

        // Validate the assertion response data
        if ( $data === null || ! $this->has_required_assertion_fields( $data ) ) {
            return new WP_REST_Response(['message' => __('Invalid assertion response data', 'really-simple-ssl')], 400);
        }

        // Extract user ID from the request
        $user_id = $this->extract_user_id_from_assertion($data);

        if (!$user_id) {
            return new WP_REST_Response(['message' => __('Invalid assertion response', 'really-simple-ssl')], 400);
        }

        $user = $this->get_user_by_identifier($user_id);

        if (!$user) {
            return new WP_REST_Response(['message' => __('Invalid assertion response', 'really-simple-ssl')], 400);
        }

        try {
            // Retrieve the stored request options
            $requestOptions = $this->get_public_key_credential_options_from_user($user->ID, 'request');

            // Get the server request
            $serverRequest = $this->create_server_request();

            // Find the user's credential by credential ID
            $userEntity = $this->credentialRepository->findOneByCredentialId($data['credential']['id']);

            // Load and check the assertion response
            $assertionResponse = $this->server->loadAndCheckAssertionResponse(
                json_encode($data['credential'], JSON_THROW_ON_ERROR),
                $requestOptions,
                $userEntity,
                $serverRequest
            );

            // Verify that the user handle matches
            if ($assertionResponse->getUserHandle() !== Base64Url::decode($data['credential']['response']['userHandle'] ?? '')) {
                throw new RuntimeException('User handle does not match');
            }

            $parameters = new Rsssl_Request_Parameters($request);

            // Update the last used timestamp
            $this->credentialRepository->update(
                $assertionResponse->getPublicKeyCredentialId(),
                ['updated_at' => current_time('mysql')]
            );

            // Validate user login and prepare redirect URL
            $redirect_url = $parameters->redirect_to ?? admin_url();
            $redirect_url = $this->authenticate_user_and_get_redirect($user->ID, $redirect_url);

            return new WP_REST_Response([
                'message' => __('Assertion verified successfully', 'really-simple-ssl'),
                'status' => 'success',
                'redirect_to' => $redirect_url,
            ], 200);

        } catch (Exception $e) {
            return $this->handle_passkey_exception($e);
        }
    }

    /**
     * Fetches the user passkey data.
     *
     * @param $request
     *
     * @return void
     */
    public static function get_user_passkey_data($request): void
    {
        $user_id = (new Rsssl_Request_Parameters($request))->user_id;
        if (!$user_id) {
            wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 403);
        }
        $resource = Rsssl_Public_Credential_Resource::get_instance();
        if (!$resource) {
            wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 404);
        }
        $data = $resource->findAllForUserId($user_id);

        wp_send_json_success(['rows' => $data]);
    }

	/**
	 * Deletes a user's credential.
	 *
	 * For non-administrators, the user_id + login_nonce combination is validated
	 * by credentials_permission_check() and this method enforces that the credential
	 * being deleted belongs to the target user. Administrators who are logged in
	 * can delete credentials for any user, as long as a valid user_id and
	 * matching credential entry_id are provided.
	 *
	 * @param $request
	 *
	 * @return void
	 */
	public static function delete_credential($request): void
	{
		$parameters = new Rsssl_Request_Parameters($request);
		$entry_id = (int) $parameters->entry_id;
		$user_id = (int) $parameters->user_id;

		if (!$entry_id) {
			wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 400);
		}

		if (!$user_id) {
			wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 403);
		}

		$resource = Rsssl_Public_Credential_Resource::get_instance();

		if (!$resource) {
			wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 404);
		}

		// Fetch all credentials for the target user
		$credentials = $resource->findAllForUserId($user_id);

		if (!is_array($credentials) || count($credentials) === 0) {
			wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 404);
		}

		// Ensure that the credential being deleted belongs to the target user
		$owned_credential_ids = array_map(static function ($credential) {
			return (int) $credential->id;
		}, $credentials);

		if (!in_array($entry_id, $owned_credential_ids, true)) {
			wp_send_json_error(['message' => __('An error occurred while processing the request.', 'really-simple-ssl')], 403);
		}

		// If there is only one credential, we should not allow the user to delete it
		if (count($credentials) === 1) {
			wp_send_json_error(['message' => __('You cannot delete your last credential', 'really-simple-ssl')], 400);
		}

		if ($resource->delete($entry_id)) {
			wp_send_json_success(['message' => __('Credential deleted successfully', 'really-simple-ssl')]);
		}
		wp_send_json_error(['message' => __('Failed to delete credential', 'really-simple-ssl')], 400);
	}

    public function get_user_by_username(string $username)
    {
        return get_user_by('login', $username) ?? false;
    }

    /**
     * @throws Exception
     */
    public function register_api_routes(): void
    {
        $routes = [
            [
                'route' => 'webauthn_register_callback',
                'callback' => array($this, 'start_registration'),
                'permission_callback' => array($this, 'permission_check'),
                'args' => $this->build_args(array(
                    'user_id',
                    'login_nonce',
                    'provider'
                ), array('redirect_to'))
            ],
            [
                'route' => 'webauthn_complete_registration',
                'callback' => array($this, 'complete_registration'),
                'permission_callback' => array($this, 'permission_check'),
                'args' => $this->build_args(array('user_id', 'login_nonce'), array('redirect_to'))
            ],
            [
                'route' => 'webauthn_verify_assertion',
                'callback' => array($this, 'verify_assertion'),
                'permission_callback' => array($this, 'assertion_permission_check'),
                'args' => []
            ],
            [
                'route' => 'webauthn_challenge_assertion',
                'callback' => array($this, 'challenge_assertion'),
                'permission_callback' => array($this, 'challenge_permission_check'),
                'args' => []
            ],
            [
                'route' => 'webauthn_get_all_credentials',
                'callback' => array($this, 'get_user_passkey_data'),
                'permission_callback' => array($this, 'credentials_permission_check'),
                'args' => $this->build_args(array('user_id'), array('login_nonce'))
            ],
            [
	            'route' => 'webauthn_delete_credential',
	            'callback' => array($this, 'delete_credential'),
	            'permission_callback' => array($this, 'credentials_permission_check'),
	            'args' => $this->build_args(array('user_id', 'entry_id'), array('login_nonce'))
            ]
        ];
        foreach ($routes as $route) {
            $this->route(
                $this->namespace,
                self::METHOD,
                $route['route'],
                $route['callback'],
                $route['permission_callback'],
                $route['args']
            );
        }
    }

    /**
     * Validates that the challenge assertion request is structurally valid and
     * that passkey login is enabled.
     */
    public function challenge_permission_check(WP_REST_Request $request): bool
    {
        if (!rsssl_get_option('enable_passkey_login', false)) {
            return false;
        }

        $parameters = new Rsssl_Request_Parameters($request);
        return !empty($parameters->user_login) || !empty($parameters->user_handle);
    }

    /**
     * Validates that the verify-assertion request is structurally valid and
     * that passkey login is enabled.
     */
    public function assertion_permission_check(WP_REST_Request $request): bool
    {
        if (!rsssl_get_option('enable_passkey_login', false)) {
            return false;
        }

        $data = $this->decode_json_request( $request );

        return $data !== null && $this->has_required_assertion_fields( $data );
    }

    private function get_user_by_identifier($identifier, $type = 'id')
    {
        switch ($type) {
            case 'id':
                return get_user_by('id', $identifier);
            case 'username':
                if ( ! is_string( $identifier ) ) {
                    return false;
                }

                return get_user_by('login', $identifier);
            case 'user_handle':
                $user_id = $this->decode_user_handle( $identifier );
                if ( $user_id === false ) {
                    return false;
                }

                return get_user_by('id', $user_id);
            case 'unique_browser_id':
                $users = get_users([
                    'meta_key' => 'webauthn_unique_browser_id',
                    'meta_value' => $identifier,
                    'number' => 1,
                    'fields' => 'ID',
                ]);

                return !empty($users) ? get_user_by('id', $users[0]) : false;
            default:
                return false;
        }
    }

    /**
     * Extracts the user ID from the request.
     *
     *
     * @return false|int
     */
    private function extract_user_id_from_request(WP_REST_Request $request)
    {
        $parameters = new Rsssl_Request_Parameters($request);
        $user_login = $parameters->user_login;
        $user_handle = $parameters->user_handle;

        if (!empty($user_login)) {
            $user = $this->get_user_by_identifier($user_login, 'username');

            return $user->ID ?? false;
        }

        if (!empty($user_handle)) {
            $user = $this->get_user_by_identifier($user_handle, 'user_handle');

            return $user->ID ?? false;
        }

        return false;
    }

    /**
     * Retrieves the public key credential options from the user meta.
     *
     *
     * @return PublicKeyCredentialRequestOptions|PublicKeyCredentialCreationOptions
     * @throws Exception
     */
    private function get_public_key_credential_options_from_user(int $user_id, string $type): PublicKeyCredentialOptions
    {
        $meta_key = $type === 'creation' ? 'webauthn_creation_options' : 'webauthn_request_options';
        $options = get_user_meta($user_id, $meta_key, true);

        if (!$options) {
            throw new RuntimeException("No $type options found for user");
        }

        return $type === 'creation'
            ? PublicKeyCredentialCreationOptions::createFromArray($options)
            : PublicKeyCredentialRequestOptions::createFromArray($options);
    }

    /**
     * Handles exceptions from passkey (WebAuthn) operations.
     *
     * Logs the actual error message for debugging when WP_DEBUG is enabled.
     * Returns a user-friendly message based on the error type and context.
     *
     * @param Exception $e The exception to handle.
     * @param string $context The operation context: 'registration' or 'login'.
     *
     * @return WP_REST_Response
     */
    private function handle_passkey_exception(Exception $e, string $context = 'login'): WP_REST_Response
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Really Simple Security Passkey Error: ' . $e->getMessage() . ' | File: ' . $e->getFile() . ':' . $e->getLine());
        }

        return new WP_REST_Response([
            'message' => $this->get_passkey_error_message($e->getMessage(), $context),
        ], 400);
    }

    /**
     * Returns a user-friendly error message for passkey operations.
     *
     * For errors we recognize and understand, we show a helpful message.
     * For security-related or unknown errors, we show a generic message.
     *
     * @param string $exception_message The original exception message.
     * @param string $context           The operation context: 'registration' or 'login'.
     *
     * @return string
     */
    private function get_passkey_error_message(string $exception_message, string $context): string
    {
        if ($exception_message === 'Invalid challenge.') {
            return __('Your session may have expired. Please refresh the page and try again.', 'really-simple-ssl');
        }

        if ($context === 'registration') {
            return __('Passkey registration failed. Please try again.', 'really-simple-ssl');
        }

        if ($context === 'login' && in_array($exception_message, ['The credential ID is invalid.', 'The credential ID is not allowed.'], true)) {
            return __('Your passkey is not registered on this site. Please log in with another method to register your passkey.', 'really-simple-ssl');
        }

        return __('Passkey authentication failed. Please try again.', 'really-simple-ssl');
    }

    /**
     * Builds WebAuthn request options for the passkey login ceremony. This
     * method returns a fallback, indistinguishable, credential response if
     * the provided user is not found.
     *
     * @internal NL14RSP1-883
     */
    private function generate_request_options(?WP_User $user, string $user_handle): PublicKeyCredentialRequestOptions
    {
        $allowedCredentials = [];
        $credentialID = hash_hmac('sha256', strtolower($user_handle), wp_salt(), true);

        // Fallback credentials
        if (strlen($user_handle) % 2 === 0) {
            $allowedCredentials = [
                $this->generate_public_key_for_credential_id($credentialID)
            ];
        }

        if ($user instanceof WP_User) {
            $userEntity = $this->credentialRepository->create_public_key_credential_user_entity($user, $user->ID);
            $allowedCredentials = array_map(
                fn($credential) => $this->generate_public_key_for_credential_id($credential->getPublicKeyCredentialId()),
                $this->credentialRepository->findAllForUserEntity($userEntity)
            );
        }

        $options = $this->server->generatePublicKeyCredentialRequestOptions(null, $allowedCredentials);

        if ($user instanceof WP_User) {
            update_user_meta($user->ID, 'webauthn_request_options', $options->jsonSerialize());
        }

        return $options;
    }

    /**
     * Generate a public key credential descriptor for a given credential ID.
     */
    private function generate_public_key_for_credential_id(string $id) : PublicKeyCredentialDescriptor
    {
        return new PublicKeyCredentialDescriptor(
            PublicKeyCredentialDescriptor::CREDENTIAL_TYPE_PUBLIC_KEY,
            $id
        );
    }

    /**
     * Extracts the user ID from the assertion data.
     *
     * @param array $data The assertion data.
     *
     * @return int|false Returns the user ID if found, false otherwise.
     */
    private function extract_user_id_from_assertion(array $data)
    {
        $user_handle = $data['credential']['response']['userHandle'] ?? null;
        $username    = $data['username'] ?? null;

        if ( is_string( $user_handle ) && $user_handle !== '' ) {
            return $this->decode_user_handle( $user_handle );
        }

        if ( is_string( $username ) && $username !== '' ) {
            $user = $this->get_user_by_identifier( $username, 'username' );

            return $user->ID ?? false;
        }

        return false;
    }

    /**
     * Decode a WebAuthn user handle and ensure it contains a valid user ID.
     *
     * @param mixed $user_handle Encoded WebAuthn user handle.
     *
     * @return int|false
     */
    private function decode_user_handle( $user_handle ) {
        if ( ! is_string( $user_handle ) || $user_handle === '' ) {
            return false;
        }

        try {
            $user_id = Base64Url::decode( $user_handle );
        } catch ( Exception $e ) {
            return false;
        }

        if ( ! ctype_digit( $user_id ) || (int) $user_id < 1 ) {
            return false;
        }

        return (int) $user_id;
    }

    /**
     * Decode a JSON REST request body into an associative array.
     *
     * @param WP_REST_Request $request REST request.
     *
     * @return array|null
     */
    private function decode_json_request( WP_REST_Request $request ): ?array {
        try {
            $data = json_decode( $request->get_body(), true, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            return null;
        }

        return is_array( $data ) ? $data : null;
    }

    /**
     * Validate the fields used during passkey registration.
     *
     * @param array $data Decoded request body.
     *
     * @return bool
     */
    private function has_required_attestation_fields( array $data ): bool {
        $credential = $data['credential'] ?? null;
        if ( ! is_array( $credential ) || ! is_string( $credential['id'] ?? null ) ) {
            return false;
        }

        $response = $credential['response'] ?? null;

        return is_array( $response )
            && is_string( $response['attestationObject'] ?? null )
            && is_string( $response['clientDataJSON'] ?? null );
    }

    /**
     * Validate the fields used during passkey authentication.
     *
     * @param array $data Decoded request body.
     *
     * @return bool
     */
    private function has_required_assertion_fields( array $data ): bool {
        $credential = $data['credential'] ?? null;
        if ( ! is_array( $credential ) || ! is_string( $credential['id'] ?? null ) ) {
            return false;
        }

        $response = $credential['response'] ?? null;
        if (
            ! is_array( $response )
            || ! is_string( $response['authenticatorData'] ?? null )
            || ! is_string( $response['clientDataJSON'] ?? null )
            || ! is_string( $response['signature'] ?? null )
        ) {
            return false;
        }

        $user_handle = $response['userHandle'] ?? null;
        if ( $user_handle !== null && ! is_string( $user_handle ) ) {
            return false;
        }

        $username = $data['username'] ?? null;

        return ( is_string( $user_handle ) && $user_handle !== '' )
            || ( is_string( $username ) && $username !== '' );
    }

    /**
     * Authenticates the user by setting auth cookies and current user.
     *
     * @param int $user_id The user ID.
     *
     * @return void
     * @noinspection UnusedFunctionResultInspection
     */
    private function authenticate_user(int $user_id): void
    {
        wp_set_auth_cookie($user_id, true);
        $user = wp_set_current_user($user_id);
        do_action('rsssl_two_factor_user_authenticated', $user->user_login, $user);
    }

    /**
     * Authenticates passkey users through the same password-expiry checkpoint.
     * Passkey authentication completes through REST instead of the regular login
     * flow, so expired-password enforcement needs to run before redirecting.
     */
    private function authenticate_user_and_get_redirect(int $user_id, string $redirect_to): string
    {
        $this->authenticate_user($user_id);

        $redirect_to = $redirect_to ?: admin_url();
        if (function_exists('\RSSSL\Pro\Security\WordPress\rsssl_maybe_get_expired_password_redirect')) {
            $redirect_to = \RSSSL\Pro\Security\WordPress\rsssl_maybe_get_expired_password_redirect($redirect_to, $user_id);
        }
        return wp_validate_redirect($redirect_to, admin_url());
    }


	/**
	 * Allow admins, logged-in owners, or pre-auth users without configured 2FA.
	 *
	 * Logged-in administrators can manage credentials for any user. Logged-in
	 * users can manage their own credentials. During pre-authentication,
	 * login_nonce access is only valid before a provider is configured.
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return bool
	 */
	public function credentials_permission_check(WP_REST_Request $request): bool
	{
		if (is_user_logged_in() && current_user_can('manage_options')) {
			return true;
		}

		$parameters = new Rsssl_Request_Parameters($request);

		try {
			$user = $this->check_login_and_get_user(
				$parameters->user_id,
				$parameters->login_nonce
			);
		} catch (Exception $e) {
			return false;
		}

		if (! $user instanceof WP_User) {
			return false;
		}

		// Owner still needs the per-request login nonce. Auth cookie alone is not enough.
		if ($this->is_logged_in_owner($user)) {
			return true;
		}

		// Pre-auth credential management is only allowed before a provider is configured.
		return ! $this->has_configured_provider($user);
	}

	/**
	 * Check if the current authenticated user owns the requested account.
	 *
	 * This marks profile management, not the pre-auth login challenge.
	 *
	 * @param WP_User $user The requested user.
	 *
	 * @return bool
	 */
	private function is_logged_in_owner(WP_User $user): bool
	{
		return is_user_logged_in() && get_current_user_id() === (int) $user->ID;
	}
}
