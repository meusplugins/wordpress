<?php return array('dependencies' => array(), 'version' => '426f8f1979c06ebc5d4a');
