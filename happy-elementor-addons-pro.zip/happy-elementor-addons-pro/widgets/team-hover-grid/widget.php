<?php

/**
 * Team Hover Grid widget class
 *
 * @package Happy_Addons_Pro
 */

namespace Happy_Addons_Pro\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;
use Elementor\Utils;

defined('ABSPATH') || die();

class Team_Hover_Grid extends Base {

	public static function register_editor_styles() {
		$handle = 'ha-team-hover-grid-editor-panel-styles';
		wp_register_style($handle, false);
		wp_enqueue_style($handle);
		wp_add_inline_style($handle, '
			.elementor-control-member_align_self .elementor-choices label i {
				transform: rotate(360deg);
			}
		');
	}

	public function get_title() {
		return __('Team Hover Grid', 'happy-addons-pro');
	}

	public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/team-hover-grid/';
    }

	public function get_icon() {
		return 'hm hm-User-Circle';
	}

	public function get_keywords() {
		return ['team', 'member', 'hover', 'grid', 'profile', 'staff', 'crew'];
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	public function get_script_depends() {
		return ['ha-swiper'];
	}

	public function get_style_depends() {
		return ['ha-swiper'];
	}

	protected function register_content_controls() {
		$this->_section_team_members();
		$this->_section_layout();
		$this->_section_animation();
	}

	protected function register_style_controls() {
		$this->_section_style_profile();
		$this->_section_style_details();
		$this->_section_style_slider();
	}

	protected function _section_team_members() {
		$this->start_controls_section(
			'section_team_members',
			[
				'label' => __('Team Members', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label'   => __('Photo', 'happy-addons-pro'),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name',
			[
				'label'       => __('Name', 'happy-addons-pro'),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Member Name', 'happy-addons-pro'),
				'placeholder' => __('Type Member Name', 'happy-addons-pro'),
			]
		);

		$repeater->add_control(
			'role',
			[
				'label'       => __('Role', 'happy-addons-pro'),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __('Member Role', 'happy-addons-pro'),
				'placeholder' => __('Type Member Role', 'happy-addons-pro'),
			]
		);

		$repeater->add_control(
			'member_width',
			[
				'label'      => __('Width', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 300,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 197,
				],
			]
		);

		$repeater->add_control(
			'member_height',
			[
				'label'      => __('Height', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 300,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 197,
				],
			]
		);

		$repeater->add_responsive_control(
			'member_margin',
			[
				'label'      => __('Margin', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
			]
		);

		$repeater->add_control(
			'member_align_self',
			[
				'label'   => __('Align Self', 'happy-addons-pro'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __('Start', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => __('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-align-center-v',
					],
					'flex-end' => [
						'title' => __('End', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => __('Stretch', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'default' => '',
				'toggle'  => true,
			]
		);

		$repeater->add_control(
			'member_transform_origin',
			[
				'label'   => __('Transform Origin', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => [
					'auto'          => __('Auto (Based on Position)', 'happy-addons-pro'),
					'top left'      => __('Top Left', 'happy-addons-pro'),
					'top center'    => __('Top Center', 'happy-addons-pro'),
					'top right'     => __('Top Right', 'happy-addons-pro'),
					'center left'   => __('Center Left', 'happy-addons-pro'),
					'center'        => __('Center', 'happy-addons-pro'),
					'center right'  => __('Center Right', 'happy-addons-pro'),
					'bottom left'   => __('Bottom Left', 'happy-addons-pro'),
					'bottom center' => __('Bottom Center', 'happy-addons-pro'),
					'bottom right'  => __('Bottom Right', 'happy-addons-pro'),
				],
			]
		);

		$this->add_control(
			'team_members',
			[
				'show_label'  => false,
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
				'default'     => [
					[
						'name'         => __('Jaylon Culhane', 'happy-addons-pro'),
						'role'         => __('Founder & COO', 'happy-addons-pro'),
						'member_width'  => ['size' => 197],
						'member_height' => ['size' => 197],
						"member_align_self" => "flex-start",
					],
					[
						'name'         => __('Brandon Bergson', 'happy-addons-pro'),
						'role'         => __('Co Founder & CEO', 'happy-addons-pro'),
						'member_width'  => ['size' => 109],
						'member_height' => ['size' => 109],
						"member_align_self" => "flex-end",
					],
					[
						'name'         => __('Ahmad George', 'happy-addons-pro'),
						'role'         => __('Designer', 'happy-addons-pro'),
						'member_width'  => ['size' => 142],
						'member_height' => ['size' => 142],
						"member_align_self" => "center",
					],
					[
						'name'         => __('Jakob Franci', 'happy-addons-pro'),
						'role'         => __('Developer', 'happy-addons-pro'),
						'member_width'  => ['size' => 109],
						'member_height' => ['size' => 109],
						"member_align_self" => "center",
					],
					[
						'name'         => __('Ken Cresta', 'happy-addons-pro'),
						'role'         => __('Founder & COO', 'happy-addons-pro'),
						'member_width'  => ['size' => 197],
						'member_height' => ['size' => 197],
						"member_align_self" => "flex-end",
					],
					[
						'name'         => __('Angel Arcand', 'happy-addons-pro'),
						'role'         => __('UI UX Designer', 'happy-addons-pro'),
						'member_width'  => ['size' => 197],
						'member_height' => ['size' => 197],
						"member_align_self" => "flex-start",
					],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function _section_layout() {
		$this->start_controls_section(
			'section_layout',
			[
				'label' => __('Layout', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'members_per_row',
			[
				'label'       => __('Members Per Row', 'happy-addons-pro'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 12,
				'step'        => 1,
				'default'     => 6,
				'render_type' => 'template',
			]
		);

		$this->add_control(
			'members_height',
			[
				'label'      => __('Height', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'vh', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 800,
						'step' => 1,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 283,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-members .team-member-row' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'vertical_gap',
			[
				'label'      => __('Vertical Gap', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 400,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 15,
				],
				'mobile_default' => [
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-members' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
				'description' => __('Applies between member rows', 'happy-addons-pro'),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'     => __('Alignment', 'happy-addons-pro'),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-members .team-member-row' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'members_gap',
			[
				'label'      => __('Gap', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 80,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 15,
				],
				'condition' => [
					'align!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-members .team-member-row' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'_mobile_slider_title',
			[
				'label'     => __('Mobile Slider', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'mobile_layout',
			[
				'label'       => __('Mobile Layout', 'happy-addons-pro'),
				'type'        => Controls_Manager::CHOOSE,
				'toggle'      => false,
				'default'     => 'slider',
				'options'     => [
					'list' => [
						'title' => __('List', 'happy-addons-pro'),
						'icon'  => 'hm hm-icon-box',
					],
					'slider' => [
						'title' => __('Slider', 'happy-addons-pro'),
						'icon'  => 'hm hm-slider-doc',
					],
				],
				'description' => __('Choose how members are displayed on mobile devices', 'happy-addons-pro'),
				'render_type' => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_dots',
			[
				'label'        => __('Show Dots', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'happy-addons-pro'),
				'label_off'    => __('Hide', 'happy-addons-pro'),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'mobile_layout' => 'slider',
				],
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_arrows',
			[
				'label'        => __('Show Arrows', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'happy-addons-pro'),
				'label_off'    => __('Hide', 'happy-addons-pro'),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'mobile_layout' => 'slider',
				],
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_counter',
			[
				'label'        => __('Show Counter', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'happy-addons-pro'),
				'label_off'    => __('Hide', 'happy-addons-pro'),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __('Shows the current slide number, e.g. 1/5', 'happy-addons-pro'),
				'condition'    => [
					'mobile_layout' => 'slider',
				],
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_slides_per_view',
			[
				'label'       => __('Slides To Show', 'happy-addons-pro'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 2,
				'step'        => 0.5,
				'default'     => 1,
				'description' => __('Number of slides shown at once. Use a decimal (e.g. 1.5) to peek the next slide', 'happy-addons-pro'),
				'condition'   => [
					'mobile_layout' => 'slider',
				],
				'render_type' => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_autoplay',
			[
				'label'        => __('Autoplay', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('On', 'happy-addons-pro'),
				'label_off'    => __('Off', 'happy-addons-pro'),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => [
					'mobile_layout' => 'slider',
				],
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'mobile_slider_delay',
			[
				'label'       => __('Autoplay Delay (ms)', 'happy-addons-pro'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 500,
				'max'         => 20000,
				'step'        => 100,
				'default'     => 5000,
				'condition'   => [
					'mobile_layout'          => 'slider',
					'mobile_slider_autoplay' => 'yes',
				],
				'render_type' => 'template',
			]
		);

		$this->end_controls_section();
	}

	protected function _section_animation() {
		$this->start_controls_section(
			'section_animation',
			[
				'label' => __('Hover Animation', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'transition_switcher',
			[
				'label'        => __('Transition', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __('On', 'happy-addons-pro'),
				'label_off'    => __('Off', 'happy-addons-pro'),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
				'_active_width_title',
				[
					'label' => __( 'Active', 'happy-addons-pro' ),
					'type'  => Controls_Manager::HEADING,
					'condition' => [
						'transition_switcher' => 'yes',
					],
				]
			);

		$this->add_control(
			'active_width',
			[
				'label'      => __('Active Width', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 197,
				],
				'description' => __('Width of the hovered team member', 'happy-addons-pro'),
				'condition' => [
					'transition_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'active_height',
			[
				'label'      => __('Active Height', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 197,
				],
				'description' => __('Height of the hovered team member', 'happy-addons-pro'),
				'condition' => [
					'transition_switcher' => 'yes',
				],
			]
		);
		$this->add_control(
				'_inactive_width_title',
				[
					'label' => __( 'Inactive', 'happy-addons-pro' ),
					'type'  => Controls_Manager::HEADING,
					'condition' => [
						'transition_switcher' => 'yes',
					],
				]
			);

		$this->add_control(
			'inactive_width',
			[
				'label'      => __('Inactive Width', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 109,
				],
				'description' => __('Width of non-hovered team members', 'happy-addons-pro'),
				'condition' => [
					'transition_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'inactive_height',
			[
				'label'      => __('Inactive Height', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 109,
				],
				'description' => __('Height of non-hovered team members', 'happy-addons-pro'),
				'condition' => [
					'transition_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'blur_value',
			[
				'label'      => __('Blur', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 10,
						'step' => 0.5,
					],
				],
				'default'    => [
					'size' => 4,
				],
				'description' => __('Blur applied to non-hovered members', 'happy-addons-pro'),
				
			]
		);

		$this->add_control(
			'info_scale',
			[
				'label'      => __('Info Scale', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'default'    => [
					'size' => 1,
				],
				'description' => __('Scale of the info overlay when hovered (0 = hidden, 1 = full size)', 'happy-addons-pro'),
				
			]
		);

		$this->add_control(
			'transition_duration',
			[
				'label'   => __('Transition Duration (s)', 'happy-addons-pro'),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 5,
				'step'    => 0.01,
				'default' => 0.5,
				
			]
		);

		$this->add_control(
			'transition_timing',
			[
				'label'   => __('Transition Timing', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'cubic-bezier(0.34, 1.56, 0.64, .85)',
				'options' => [
					'cubic-bezier(0.34, 1.56, 0.64, .85)' => __('Cubic Bezier (Default)', 'happy-addons-pro'),
					'ease'       => __('Ease', 'happy-addons-pro'),
					'linear'     => __('Linear', 'happy-addons-pro'),
					'ease-in'    => __('Ease In', 'happy-addons-pro'),
					'ease-out'   => __('Ease Out', 'happy-addons-pro'),
					'ease-in-out' => __('Ease In Out', 'happy-addons-pro'),
				],
				
			]
		);

		$this->add_control(
			'transition_delay',
			[
				'label' => __('Transition Delay (s)', 'happy-addons-pro'),
				'type' => Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 2,
				'step' => 0.01,
				'default' => 0,
				
			]
		);

		$this->end_controls_section();
	}

	protected function _section_style_profile() {
		$this->start_controls_section(
			'section_style_profile',
			[
				'label' => __('Image Box', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'profile_bg_color',
			[
				'label'     => __('Background Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-profile' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'profile_border',
				'selector' => '{{WRAPPER}} .ha-team-hover-grid-profile',
			]
		);

		$this->add_control(
			'profile_border_radius',
			[
				'label'      => __('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .ha-team-hover-grid-profile' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'profile_box_shadow',
				'selector' => '{{WRAPPER}} .ha-team-hover-grid-profile',
			]
		);

		$this->end_controls_section();
	}

	protected function _section_style_details() {
		$this->start_controls_section(
			'section_style_details',
			[
				'label' => __('Info Box', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		


		$this->add_control(
			'details_width',
			[
				'label'      => __('Width', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 180,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-info' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'_info_position_title',
			[
				'label'     => __('Position', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'info_position',
			[
				'label'       => __('Position', 'happy-addons-pro'),
				'type'        => Controls_Manager::CHOOSE,
				'toggle'      => false,
				'default'     => 'bottom',
				'options'     => [
					'left' => [
						'title' => __('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => __('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-right',
					],
					'top' => [
						'title' => __('Top', 'happy-addons-pro'),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => __('Bottom', 'happy-addons-pro'),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'description' => __('Position of the info box relative to the image', 'happy-addons-pro'),
				'render_type' => 'template',
			]
		);

		$this->add_responsive_control(
			'info_offset_left',
			[
				'label'      => __('Offset', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-wrap' => '--ha-info-offset: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'info_position' => 'left',
				],
			]
		);

		$this->add_responsive_control(
			'info_offset_right',
			[
				'label'      => __('Offset', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-wrap' => '--ha-info-offset: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'info_position' => 'right',
				],
			]
		);

		$this->add_responsive_control(
			'info_offset_top',
			[
				'label'      => __('Offset', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-wrap' => '--ha-info-offset: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'info_position' => 'top',
				],
			]
		);

		$this->add_responsive_control(
			'info_offset_bottom',
			[
				'label'      => __('Offset', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-wrap' => '--ha-info-offset: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'info_position' => 'bottom',
				],
			]
		);

		$this->add_control(
			'details_bg_color',
			[
				'label'     => __('Background Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-info' => 'background-color: {{VALUE}};',
				],
			]
		);

		
		$this->add_control(
			'details_align',
			[
				'label'     => __('Alignment', 'happy-addons-pro'),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left' => [
						'title' => __('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-info' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'details_padding',
			[
				'label'      => __('Padding', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .ha-team-hover-grid-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'details_border',
				'selector' => '{{WRAPPER}} .ha-team-hover-grid-info',
			]
		);

		$this->add_control(
			'details_border_radius',
			[
				'label'      => __('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .ha-team-hover-grid-info' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'_name_style_title',
			[
				'label'     => __('Name', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .ha-team-hover-grid-name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => __('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-name' => 'color: {{VALUE}};',
				],
			]
		);

		

		$this->add_control(
			'_role_style_title',
			[
				'label'     => __('Role', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'role_typography',
				'selector' => '{{WRAPPER}} .ha-team-hover-grid-role',
			]
		);

		$this->add_control(
			'role_color',
			[
				'label'     => __('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ha-team-hover-grid-role' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function _section_style_slider() {
		$this->start_controls_section(
			'section_style_slider',
			[
				'label'     => __('Mobile Slider', 'happy-addons-pro'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'mobile_layout' => 'slider',
				],
			]
		);

		$this->add_control(
			'_slider_dots_style_title',
			[
				'label' => __('Dots', 'happy-addons-pro'),
				'type'  => Controls_Manager::HEADING,
				'condition' => [
					'mobile_slider_dots' => 'yes',
				],
			]
		);

		$this->add_control(
			'slider_dots_color',
			[
				'label'     => __('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'mobile_slider_dots' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-thg-swiper .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'slider_dots_active_color',
			[
				'label'     => __('Active Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'mobile_slider_dots' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-thg-swiper .swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'_slider_arrows_style_title',
			[
				'label'     => __('Arrows', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'mobile_slider_arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'slider_arrow_color',
			[
				'label'     => __('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'mobile_slider_arrows' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-thg-swiper .ha-thg-arrow' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'slider_arrow_bg_color',
			[
				'label'     => __('Background Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'mobile_slider_arrows' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-thg-swiper .ha-thg-arrow' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'_slider_counter_style_title',
			[
				'label'     => __('Counter', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'mobile_slider_counter' => 'yes',
				],
			]
		);

		$this->add_control(
			'slider_counter_color',
			[
				'label'     => __('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'mobile_slider_counter' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-thg-swiper .ha-thg-counter' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		if (! is_array($settings['team_members'])) {
			return;
		}

		$transition_enabled = isset($settings['transition_switcher']) && $settings['transition_switcher'] === 'yes';

		$info_position = ! empty($settings['info_position']) ? $settings['info_position'] : 'bottom';

		$members_per_row = min(12, ! empty($settings['members_per_row']) ? absint($settings['members_per_row']) : 6);

		$animation_data = wp_json_encode([
			'transitionEnabled' => $transition_enabled,
			'infoPosition'  => $info_position,
			'activeWidth'   => isset($settings['active_width']['size']) ? $settings['active_width']['size'] : 197,
			'activeHeight'  => isset($settings['active_height']['size']) ? $settings['active_height']['size'] : 197,
			'inactiveWidth'  => isset($settings['inactive_width']['size']) ? $settings['inactive_width']['size'] : 109,
			'inactiveHeight' => isset($settings['inactive_height']['size']) ? $settings['inactive_height']['size'] : 109,
			'blur'          => isset($settings['blur_value']['size']) ? $settings['blur_value']['size'] : 4,
			'scale'         => isset($settings['info_scale']['size']) ? $settings['info_scale']['size'] : 1,
			'duration'      => isset($settings['transition_duration']) ? $settings['transition_duration']: 0.5,
			'timing'        => isset($settings['transition_timing']) ? $settings['transition_timing'] : 'cubic-bezier(0.23, 1, 0.32, 1)',
			'delay'         => isset($settings['transition_delay']) ? $settings['transition_delay'] : 0,
			'membersPerRow' => $members_per_row,
			'mobileLayout'  => ! empty($settings['mobile_layout']) ? $settings['mobile_layout'] : 'slider',
			'sliderDots'    => ! isset($settings['mobile_slider_dots']) || $settings['mobile_slider_dots'] === 'yes',
			'sliderArrows'  => ! isset($settings['mobile_slider_arrows']) || $settings['mobile_slider_arrows'] === 'yes',
			'sliderCounter' => isset($settings['mobile_slider_counter']) && $settings['mobile_slider_counter'] === 'yes',
			'sliderSlidesPerView' => ! empty($settings['mobile_slider_slides_per_view']) ? floatval($settings['mobile_slider_slides_per_view']) : 1,
			'sliderAutoplay'      => isset($settings['mobile_slider_autoplay']) && $settings['mobile_slider_autoplay'] === 'yes',
			'sliderDelay'         => ! empty($settings['mobile_slider_delay']) ? absint($settings['mobile_slider_delay']) : 5000,
		]);

		$is_round = (isset($settings['image_shape']) && $settings['image_shape'] === 'round');
?>
		<div class="ha-team-hover-grid-wrap ha-info-pos-<?php echo esc_attr($info_position); ?>" data-settings='<?php echo esc_attr($animation_data); ?>'>
			<div class="ha-team-hover-grid-members">
				<?php foreach ($settings['team_members'] as $index => $member) :
					if ($index % $members_per_row === 0) : ?>
						<div class="team-member-row">
						<?php endif;
					$member_w = isset($member['member_width']['size']) ? $member['member_width']['size'] : 197;
					$member_h = isset($member['member_height']['size']) ? $member['member_height']['size'] : 197;
				$align_self = ! empty($member['member_align_self']) ? $member['member_align_self'] : '';
				$member_margin = ! empty($member['member_margin']) ? $member['member_margin'] : '';
				$transform_origin = ! empty($member['member_transform_origin']) ? $member['member_transform_origin'] : 'auto';

					$image_url = '';
					if (! empty($member['image']['id'])) {
						$image_url = wp_get_attachment_image_url($member['image']['id'], 'full');
					}
					if (! $image_url && ! empty($member['image']['url'])) {
						$image_url = $member['image']['url'];
					}

					$profile_style = 'width: ' . esc_attr($member_w) . 'px; height: ' . esc_attr($member_h) . 'px;';
					if ($align_self) {
						$profile_style .= ' align-self: ' . esc_attr($align_self) . ';';
					}
					if ($member_margin) {
						$unit = $member_margin['unit'] ?? 'px';

						$top    = $member_margin['top'] ?: 0;
						$right  = $member_margin['right'] ?: 0;
						$bottom = $member_margin['bottom'] ?: 0;
						$left   = $member_margin['left'] ?: 0;

						$profile_style .= sprintf(
							'margin: %s%s %s%s %s%s %s%s;',
							esc_attr($top),
							esc_attr($unit),
							esc_attr($right),
							esc_attr($unit),
							esc_attr($bottom),
							esc_attr($unit),
							esc_attr($left),
							esc_attr($unit)
						);
					}
						?>
					<div class="ha-team-hover-grid-profile" data-member-id="<?php echo $index; ?>"
						style="<?php echo esc_attr($profile_style); ?>"
						data-default-width="<?php echo esc_attr($member_w); ?>"
						data-default-height="<?php echo esc_attr($member_h); ?>"
						data-transform-origin="<?php echo esc_attr($transform_origin); ?>">
							<?php if ($image_url) : ?>
								<img class="ha-team-hover-grid-img"
									src="<?php echo esc_url($image_url); ?>"
									alt="<?php echo esc_attr($member['name']); ?>">
							<?php endif; ?>

							<?php if (! empty($member['name']) ||  (! empty($member['role'])) ) : ?>
								<div class="ha-team-hover-grid-info" style="transform: scale3d(0, 0, 1);">
									<?php if (! empty($member['name'])) : ?>
										<div class="ha-team-hover-grid-name"><?php echo esc_html($member['name']); ?></div>
									<?php endif; ?>
									<?php if (! empty($member['role'])) : ?>
										<div class="ha-team-hover-grid-role"><?php echo esc_html($member['role']); ?></div>
									<?php endif; ?>
								</div>
							<?php endif; ?>

						</div>
						<?php if ($index % $members_per_row === ($members_per_row - 1) || $index === count($settings['team_members']) - 1) : ?>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		</div>
<?php
	}
}

add_action('elementor/editor/after_enqueue_styles', [Team_Hover_Grid::class, 'register_editor_styles']);
