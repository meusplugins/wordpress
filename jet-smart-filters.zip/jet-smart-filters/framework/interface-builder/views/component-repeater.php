<?php
/**
 * Repeater template.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
?>
<div class="cx-ui-kit cx-component cx-repeater <?php echo esc_attr( $args['class'] ); ?>" data-compotent-id="#<?php echo esc_attr( $args['id'] ); ?>">
	<?php if ( ! empty( $args['title'] ) ) { ?>
		<div class="h2-style cx-ui-kit__title cx-component__title" role="banner" ><?php echo wp_kses_post( $args['title'] ); ?></div>
	<?php } ?>
	<?php if ( ! empty( $args['description'] ) ) { ?>
		<div class="cx-ui-kit__description cx-component__description" role="note" ><?php echo wp_kses_post( $args['description'] ); ?></div>
	<?php } ?>
	<?php if ( ! empty( $args['children'] ) ) { ?>
		<div class="cx-ui-kit__content cx-component__content" role="group" >
			<?php echo $args['children']; ?>
		</div>
	<?php } ?>
</div>
