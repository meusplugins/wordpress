<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class CustomCode {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Primary color', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderPrimaryColor() ?>
            </div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Custom CSS', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderCustomCSS() ?>
            </div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Custom JavaScript', 'instafood') ?>
            </div>
            <div class="apt-section-content">
                <?php $this->renderCustomJavascript() ?>
            </div>
        </div>
        <?php
    }

    private function renderPrimaryColor() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Override primary colour', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('custom_primary_color', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[custom_primary_color]"
                            class="form-control" placeholder="#30b3ab">
                        <div class="option-entry-info"><?= esc_html__('Optional. Ex: #30b3ab', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Modify the primary colour used across the mobile web app.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderCustomCSS() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <div class="option-entry-label"><?= esc_html__('Add CSS code below', 'instafood'); ?></div>
                        <textarea name="<?= esc_attr(Config::getOptionsGroupSlug());?>[custom_css]" style="width: 100%;" rows="10"><?= OptionUtil::getInstance()->getOption('custom_css', '') ?></textarea>
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Modify the look & feel of the mobile web app.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderCustomJavascript() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <div class="option-entry-label"><?= esc_html__('Add JS code below', 'instafood'); ?></div>
                        <textarea name="<?= esc_attr(Config::getOptionsGroupSlug());?>[custom_js]" style="width: 100%;" rows="10"><?= OptionUtil::getInstance()->getOption('custom_js', '') ?></textarea>
                        <div class="option-entry-info"><?= esc_html__('Optional.', 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Add additional functionality to the mobile web app", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }
}