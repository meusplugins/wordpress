<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Controls_Manager;
use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Object_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;
use Happy_Addons_Pro\Extensions\Display_Conditions;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * One Display Condition: the condition, its operator and the value to compare.
 * The value is a text whose format depends on the condition (see
 * Display_Condition::condition_controls()).
 */
class Display_Condition_Item_Prop_Type extends Object_Prop_Type {

	public static function get_key(): string {
		return 'ha-display-condition';
	}

	protected function define_shape(): array {
		return [
			'key'      => String_Prop_Type::make()->enum( Display_Condition::keys() )->default( 'login_status' ),
			'operator' => String_Prop_Type::make()->enum( [ 'is', 'not' ] )->default( 'is' ),
			'value'    => String_Prop_Type::make(),
		];
	}
}

/**
 * The Conditions list. The key is what the editor builds for a repeatable
 * control whose items are "ha-display-condition" (<item key>-array).
 */
class Display_Condition_Items_Prop_Type extends Array_Prop_Type {

	public static function get_key(): string {
		return 'ha-display-condition-array';
	}

	protected function define_item_type(): Prop_Type {
		return Display_Condition_Item_Prop_Type::make();
	}
}

/**
 * Display Condition for the Atomic containers (e-flexbox, e-div-block, e-grid)
 * and the Atomic elements that render a single root (heading, paragraph,
 * image, button, SVG).
 *
 * Same settings and behaviour as the Classic Display Condition extension: it
 * shows or hides the element when all / any of the conditions are met. The
 * conditions themselves are the Classic ones (extensions/conditions), the
 * Atomic settings are only translated into the Classic ones for them.
 */
class Display_Condition extends Atomic_Feature_Base {

	/** Classic condition keys, in the Classic order. */
	const CONDITIONS = [
		'login_status',
		'role',
		'operating_system',
		'browser',
		'date_range',
		'date',
		'time',
		'day',
		'country',
		'initial_load',
		'language',
	];

	/** @var array<string,object> */
	private static $condition_objects = [];

	/** @return string[] */
	public static function keys() {
		return self::CONDITIONS;
	}

	protected function prefix() {
		return 'ha_dc_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid', 'e-heading', 'e-paragraph', 'e-image', 'e-button', 'e-svg' ];
	}

	protected function feature_key() {
		return 'display-condition';
	}

	protected function section_label() {
		return __( 'Happy Features', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		if ( ! isset( $schema['classes'], $schema['link'] ) ) {
			return false;
		}

		// A container, or one of the single root elements listed in target_types().
		return isset( $schema['tag'] ) || isset( $schema['image'] ) || isset( $schema['svg'] );
	}

	public function init() {
		parent::init();

		// Atomic elements filter by their own type ("e-flexbox", "e-heading"...).
		foreach ( $this->target_types() as $type ) {
			add_filter( "elementor/frontend/{$type}/should_render", [ $this, 'should_render' ], 10, 2 );
		}

		add_filter( 'elementor/element/is_dynamic_content', [ $this, 'is_dynamic_content' ], 10, 3 );
	}

	/**
	 * Nothing runs in the browser, so there is no frontend config to register.
	 */
	public function before_render( $element ) {}

	protected function fields() {
		$on = [ 'switcher' => true ];

		return [
			'switcher'  => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Display Condition', 'happy-addons-pro' ),
			],
			'to'        => [
				'type'    => 'enum',
				'default' => 'show',
				'label'   => __( 'To', 'happy-addons-pro' ),
				'options' => [
					'show' => __( 'Show Element', 'happy-addons-pro' ),
					'hide' => __( 'Hide Element', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'relation'  => [
				'type'    => 'enum',
				'default' => 'and',
				'label'   => __( 'When', 'happy-addons-pro' ),
				'options' => [
					'and' => __( 'All Conditions Met', 'happy-addons-pro' ),
					'or'  => __( 'Any Condition Met', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'time_zone' => [
				'type'        => 'enum',
				'default'     => 'server',
				'label'       => __( 'Timezone', 'happy-addons-pro' ),
				'description' => __( 'You can change Server Timezone from Settings > General.', 'happy-addons-pro' ),
				'options'     => [
					'server' => __( 'Server Timezone', 'happy-addons-pro' ),
					'local'  => __( 'Local Timezone', 'happy-addons-pro' ),
				],
				'show'        => $on,
			],
		];
	}

	protected function extra_props() {
		$type = Display_Condition_Items_Prop_Type::make()->default( [] );

		$type->set_dependencies(
			Dependency_Manager::make( Dependency_Manager::RELATION_AND )
				->where( [
					'operator' => 'eq',
					'path'     => [ $this->prefix() . 'switcher' ],
					'value'    => true,
					'effect'   => 'hide',
				] )
				->get()
		);

		return [ $this->prefix() . 'conditions' => $type ];
	}

	protected function extra_controls() {
		return [
			'time_zone' => Repeatable_Control::bind_to( $this->prefix() . 'conditions' )
				->set_repeaterLabel( __( 'Conditions', 'happy-addons-pro' ) )
				->set_child_control_type( 'ha-display-condition' )
				->set_child_control_props( [
					'conditions' => self::condition_controls(),
					'operators'  => [
						[ 'value' => 'is', 'label' => __( 'Is', 'happy-addons-pro' ) ],
						[ 'value' => 'not', 'label' => __( 'Is not', 'happy-addons-pro' ) ],
					],
				] )
				->set_initialValues( (object) [
					'key'      => [ '$$type' => 'string', 'value' => 'login_status' ],
					'operator' => [ '$$type' => 'string', 'value' => 'is' ],
					'value'    => [ '$$type' => 'string', 'value' => 'login' ],
				] )
				->set_patternLabel( '${value.key.value}' )
				->set_placeholder( __( 'Condition', 'happy-addons-pro' ) )
				->set_prop_key( 'ha-display-condition-array' )
				->set_is_sortable( true )
				->hide_toggle(),
		];
	}

	/**
	 * A Classic condition object.
	 *
	 * @return \Happy_Addons_Pro\Extensions\Conditions\Condition|null
	 */
	private static function condition( $key ) {
		if ( ! in_array( $key, self::CONDITIONS, true ) ) {
			return null;
		}

		if ( ! isset( self::$condition_objects[ $key ] ) ) {
			$class = 'Happy_Addons_Pro\\Extensions\\Conditions\\' . str_replace( ' ', '_', ucwords( str_replace( '_', ' ', $key ) ) );

			self::$condition_objects[ $key ] = class_exists( $class ) ? new $class() : null;
		}

		return self::$condition_objects[ $key ];
	}

	/**
	 * What the editor needs to build the value field of every condition, taken
	 * from the Classic condition controls: field kind (select, multi, date,
	 * date_range, time), options and default value.
	 *
	 * @return array[]
	 */
	private static function condition_controls() {
		$list = [];

		foreach ( self::CONDITIONS as $key ) {
			$condition = self::condition( $key );

			if ( ! $condition ) {
				continue;
			}

			$control = $condition->get_repeater_control( [] );
			$picker  = $control['picker_options'] ?? [];
			$type    = 'select';

			if ( Controls_Manager::SELECT2 === $control['type'] ) {
				$type = 'multi';
			} elseif ( Controls_Manager::DATE_TIME === $control['type'] ) {
				if ( ! empty( $picker['noCalendar'] ) ) {
					$type = 'time';
				} else {
					$type = 'range' === ( $picker['mode'] ?? '' ) ? 'date_range' : 'date';
				}
			}

			$options = [];

			foreach ( $control['options'] ?? [] as $value => $label ) {
				$options[] = [ 'value' => (string) $value, 'label' => (string) $label ];
			}

			$default = $control['default'] ?? '';
			$default = is_array( $default ) ? implode( ',', $default ) : (string) $default;

			if ( '' === $default && $options ) {
				$default = $options[0]['value'];
			}

			$list[] = [
				'key'         => $key,
				'title'       => $condition->get_title(),
				'type'        => $type,
				'default'     => $default,
				'options'     => $options,
				'description' => isset( $control['description'] ) ? trim( wp_strip_all_tags( $control['description'] ) ) : '',
			];
		}

		return $list;
	}

	/**
	 * A prop value as stored: { $$type, value } wrappers removed.
	 */
	private static function unwrap( $value ) {
		while ( is_array( $value ) && array_key_exists( '$$type', $value ) ) {
			$value = $value['value'] ?? null;
		}

		return $value;
	}

	/**
	 * Display Condition settings of an Atomic element in the Classic format
	 * ("_ha_condition_*"), or null when the feature is off for it.
	 */
	private function classic_settings( $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) ) {
			return null;
		}

		if ( ! in_array( $element::get_element_type(), $this->target_types(), true ) ) {
			return null;
		}

		$settings = $element->get_atomic_settings();

		if ( empty( $settings[ $this->prefix() . 'switcher' ] ) ) {
			return null;
		}

		$fields = $this->fields();
		$pick   = function ( $key ) use ( $settings, $fields ) {
			$value = $settings[ $this->prefix() . $key ] ?? '';

			return array_key_exists( (string) $value, $fields[ $key ]['options'] ) ? (string) $value : (string) $fields[ $key ]['default'];
		};

		$controls = [];

		foreach ( self::condition_controls() as $control ) {
			$controls[ $control['key'] ] = $control;
		}

		// The items are read as stored: they are not resolved by Elementor's renderer.
		$items = $element->get_settings( $this->prefix() . 'conditions' );
		$list  = [];

		foreach ( self::unwrap( $items ) ?: [] as $index => $item ) {
			$item = self::unwrap( $item );

			if ( ! is_array( $item ) ) {
				continue;
			}

			$key = (string) self::unwrap( $item['key'] ?? '' );
			$key = isset( $controls[ $key ] ) ? $key : 'login_status';

			$operator = (string) self::unwrap( $item['operator'] ?? '' );
			$operator = in_array( $operator, [ 'is', 'not' ], true ) ? $operator : 'is';

			$value = self::unwrap( $item['value'] ?? '' );
			$value = is_scalar( $value ) && '' !== (string) $value ? (string) $value : $controls[ $key ]['default'];

			if ( 'multi' === $controls[ $key ]['type'] ) {
				$value = array_values( array_filter( array_map( 'trim', explode( ',', $value ) ) ) );
			}

			$list[] = [
				'_ha_condition_key'      => $key,
				'_ha_condition_operator' => $operator,
				'_ha_condition_' . $key  => $value,
				'_id'                    => $element->get_id() . '-' . $index,
			];
		}

		return [
			'_ha_condition_enable'   => 'yes',
			'_ha_condition_to'       => $pick( 'to' ),
			'_ha_condition_relation' => $pick( 'relation' ),
			'_ha_time_zone'          => $pick( 'time_zone' ),
			'_ha_condition_list'     => $list,
		];
	}

	/**
	 * Same logic as Display_Conditions::content_render() in Classic.
	 */
	public function should_render( $should_render, $element ) {
		$settings = $this->classic_settings( $element );

		if ( null === $settings ) {
			return $should_render;
		}

		if ( 'false' === Display_Conditions::$cookies ) {
			Display_Conditions::$cookies = 'true';

			// The Classic script reads it to store the visitor's timezone in a cookie.
			wp_localize_script(
				'happy-addons-pro',
				'haDisplayCondition',
				[ 'status' => Display_Conditions::$cookies ]
			);
		}

		// No condition to check: the element stays as it is.
		if ( ! $settings['_ha_condition_list'] ) {
			return $should_render;
		}

		$results = [];

		foreach ( $settings['_ha_condition_list'] as $item ) {
			$key       = $item['_ha_condition_key'];
			$condition = self::condition( $key );

			if ( ! $condition ) {
				continue;
			}

			$results[] = (bool) $condition->compare_value( $settings, $item['_ha_condition_operator'], $item[ '_ha_condition_' . $key ] );
		}

		if ( ! $results ) {
			return $should_render;
		}

		$passed = 'or' === $settings['_ha_condition_relation'] ? in_array( true, $results, true ) : ! in_array( false, $results, true );

		return 'show' === $settings['_ha_condition_to'] ? $passed : ! $passed;
	}

	/**
	 * Elements with a condition depend on the visitor, so Elementor must not cache them.
	 */
	public function is_dynamic_content( $is_dynamic_content, $element_raw_data, $element_instance ) {
		$settings = is_array( $element_raw_data ) ? ( $element_raw_data['settings'] ?? [] ) : [];

		if ( ! empty( self::unwrap( $settings[ $this->prefix() . 'switcher' ] ?? null ) ) ) {
			return true;
		}

		return $is_dynamic_content;
	}
}
