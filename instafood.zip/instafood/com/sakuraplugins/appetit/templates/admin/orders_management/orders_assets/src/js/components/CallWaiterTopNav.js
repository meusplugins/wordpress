import EventBus, { Events, Event } from '../events/EventBus';

let instance;
const instanceKey = '2738__KSJK';

class CallWaiterTopNav {

    _ui;
    _onLiveWaiterCallsCount;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._ui = jQuery('.nav_link_waiter_calls');

        this._onLiveWaiterCallsCount = new Event(Events.LIVE_WAITER_CALLS_COUNT, ({ count }) => {
            this._handleChange(count);
        });
        EventBus.getInstance().registerEvent(this._onLiveWaiterCallsCount);

        const _this = this;
        this._ui.click(function(event) {
            _this._handleChange(0);
        })
    }
    
    _handleChange(count) {
        if (count !== 0) {
            this._ui.find('.order_info').html(count);
            this._ui.find('.order_info').css('display', 'flex');
            return;
        }
        this._ui.find('.order_info').hide();
    }

    static getInstance() {
        if (!instance) {
            instance = new CallWaiterTopNav(instanceKey);
        }
        return instance;
    }
}
export default CallWaiterTopNav;