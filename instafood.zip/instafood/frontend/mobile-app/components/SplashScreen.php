<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

use com\sakuraplugins\appetit\utils\OptionUtil;

require_once(plugin_dir_path(__FILE__) . '../pages/IAppetitPage.php');

class SplashScreen implements IAppetitPage {

    public function render(): void {
        $restaurant_logo_image_id = OptionUtil::getInstance()->getOption('restaurant_logo_image_id');
        $restaurant_logo_image_url = '';
        if ($restaurant_logo_image_id) {
            $restaurant_logo_image_data = wp_get_attachment_image_src($restaurant_logo_image_id, 'appetit-aquare-medium-large');
            $restaurant_logo_image_url = $restaurant_logo_image_data[0] ?? '';
        }

        $restaurant_logo_image_url = $restaurant_logo_image_url === '' ? INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/img/appetit_logo_small.png' : $restaurant_logo_image_url;
        
        ?>
        <div class="apt-splashscreen">
            <div class="apt-logo-ui" data-logourl="<?= esc_url($restaurant_logo_image_url) ?>"></div>
        </div>
        <?php
    }
}

?>