"use strict";

(function ($, w) {
  'use strict';

  $(w).on('elementor/frontend/init', function () {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      return;
    }
    gsap.registerPlugin(ScrollTrigger);

    // Coalesced refresh timing. Must outlast the longest native content
    // toggle animation (Elementor nested accordion exposes no completion
    // event) so ScrollTrigger measures the settled height, not a moving one.
    var SETTLE_DELAY = 550;
    function itemHasCustomWidth(el) {
      var inlineStyle = el.getAttribute('style') || '';
      if (/(^|;)\s*width\s*:/i.test(inlineStyle)) {
        return true;
      }
      var width = window.getComputedStyle(el).getPropertyValue('--width').trim();
      return !!width && '100%' !== width;
    }
    var HappyHorizontalScroll = elementorModules.frontend.handlers.Base.extend({
      onInit: function onInit() {
        elementorModules.frontend.handlers.Base.prototype.onInit.apply(this, arguments);
        this._initDone = false;
        this._layoutBound = false;
        this._refreshTimer = null;
        this._refreshFrame = null;
        this._resizeObserver = null;
        this._geom = null;
        this._bindLayoutChangeListeners();
        this.run();
      },
      onElementChange: function onElementChange(changedKey) {
        if (typeof changedKey === 'string' && (changedKey === 'ha_hs_switcher' || changedKey === 'ha_hs_direction' || changedKey === 'ha_snap_scroll_switcher' || changedKey === 'ha_hs_enable_auto_width')) {
          this.killAnimation();
          this._restoreVerticalLayout();
          this.run();
        }
      },
      onDestroy: function onDestroy() {
        this._unbindLayoutChangeListeners();
        this.killAnimation();
        this._restoreVerticalLayout();
        elementorModules.frontend.handlers.Base.prototype.onDestroy.apply(this, arguments);
      },
      // ─── Layout change coordination ──────────────────────────────
      //
      // Every layout signal (tabs/accordion/toggle, nested widgets, the
      // Hover Accordion transition, resize, fonts/images) is funnelled
      // into ONE trailing refresh per instance. Refreshing during an
      // animated height change records an intermediate pin-spacer height
      // and produces overlap, jumps and long vertical whitespace.

      _bindLayoutChangeListeners: function _bindLayoutChangeListeners() {
        if (this._layoutBound) {
          return;
        }
        var self = this;
        this._onLayoutSignal = function () {
          self._scheduleRefresh();
        };
        this._onViewportChange = this._debounce(function () {
          self._reconcileResponsiveState();
        }, 120);
        this._desktopMediaQuery = w.matchMedia('(min-width: 1025px)');
        $(w).on('elementor-pro/motion-fx/recalc', this._onLayoutSignal);
        $(w).on('elementor/nested-tabs/activate', this._onLayoutSignal);
        $(w).on('ha:nested:change', this._onLayoutSignal);
        $(w).on('ha:hover-list:change', this._onLayoutSignal);
        $(w).on('load', this._onLayoutSignal);
        $(document).on('ha_TabHandlerBase_changed', this._onLayoutSignal);
        $(w).on('resize', this._onViewportChange);
        $(w).on('orientationchange', this._onViewportChange);
        this._desktopMediaQuery.addEventListener('change', this._onViewportChange);
        this._observeGeometry();
        this._layoutBound = true;
      },
      _unbindLayoutChangeListeners: function _unbindLayoutChangeListeners() {
        if (!this._layoutBound) {
          return;
        }
        $(w).off('elementor-pro/motion-fx/recalc', this._onLayoutSignal);
        $(w).off('elementor/nested-tabs/activate', this._onLayoutSignal);
        $(w).off('ha:nested:change', this._onLayoutSignal);
        $(w).off('ha:hover-list:change', this._onLayoutSignal);
        $(w).off('load', this._onLayoutSignal);
        $(document).off('ha_TabHandlerBase_changed', this._onLayoutSignal);
        $(w).off('resize', this._onViewportChange);
        $(w).off('orientationchange', this._onViewportChange);
        if (this._desktopMediaQuery) {
          this._desktopMediaQuery.removeEventListener('change', this._onViewportChange);
          this._desktopMediaQuery = null;
        }
        this._disconnectObserver();
        this._cancelScheduledRefresh();
        this._layoutBound = false;
      },
      /**
       * Width-only observer on the wrapper.
       *
       * Height is deliberately ignored: the wrapper is the element GSAP
       * pins, so its measured height can flip between content height and
       * the viewport while it is pinned. Reacting to that would schedule
       * refreshes on every pin/unpin and cause the very jumps we are
       * fixing. Content-height changes are instead driven by the
       * tab/accordion/nested/hover-list events.
       */
      _observeGeometry: function _observeGeometry() {
        if (typeof w.ResizeObserver === 'undefined') {
          return;
        }
        var self = this;
        this._resizeObserver = new w.ResizeObserver(function (entries) {
          var changed = false;
          entries.forEach(function (entry) {
            var width = Math.round(entry.contentRect.width);
            if (entry.target._haObservedWidth !== width) {
              entry.target._haObservedWidth = width;
              changed = true;
            }
          });
          if (changed) {
            self._scheduleRefresh();
          }
        });
        this._resizeObserver.observe(this.$element[0]);
      },
      _disconnectObserver: function _disconnectObserver() {
        if (this._resizeObserver) {
          this._resizeObserver.disconnect();
          this._resizeObserver = null;
        }
      },
      _scheduleRefresh: function _scheduleRefresh() {
        var self = this;
        if (this._refreshTimer) {
          clearTimeout(this._refreshTimer);
        }
        this._refreshTimer = setTimeout(function () {
          self._refreshTimer = null;
          if (self._refreshFrame) {
            cancelAnimationFrame(self._refreshFrame);
          }
          self._refreshFrame = w.requestAnimationFrame(function () {
            self._refreshFrame = null;
            self._refreshLayout();
          });
        }, SETTLE_DELAY);
      },
      _cancelScheduledRefresh: function _cancelScheduledRefresh() {
        if (this._refreshTimer) {
          clearTimeout(this._refreshTimer);
          this._refreshTimer = null;
        }
        if (this._refreshFrame) {
          cancelAnimationFrame(this._refreshFrame);
          this._refreshFrame = null;
        }
      },
      _refreshLayout: function _refreshLayout() {
        if (typeof ScrollTrigger === 'undefined' || !this.scrollTween) {
          return;
        }

        // Only refresh when this section is actually active.
        if (!this.$element.is(':visible') || !this.$element[0].isConnected) {
          return;
        }

        // Re-measure the track before GSAP reads it.
        this._geom = null;
        this._applyGeometry();
        ScrollTrigger.refresh();
      },
      _reconcileResponsiveState: function _reconcileResponsiveState() {
        if (!this._desktopMediaQuery.matches) {
          this.killAnimation();
          this._restoreVerticalLayout();
          return;
        }
        if (!this.scrollTween) {
          this.run();
          return;
        }
        this._scheduleRefresh();
      },
      _debounce: function _debounce(fn, wait) {
        var timer;
        return function () {
          var ctx = this;
          var args = arguments;
          clearTimeout(timer);
          timer = setTimeout(function () {
            fn.apply(ctx, args);
          }, wait);
        };
      },
      // ─── Geometry (always measured live) ─────────────────────────

      /**
       * Element that directly holds the panels. A Boxed Elementor
       * container wraps its children in `.e-con-inner`, so the track must
       * be built inside that wrapper (and its boxed width overridden in
       * CSS) for the panels to be reached and the container to be full
       * width.
       */
      _getHost: function _getHost() {
        var $boxed = this.$element.children('.e-con-inner');
        return $boxed.length ? $boxed.first() : this.$element;
      },
      _getTrack: function _getTrack() {
        return this._getHost().children('.ha-hs-inner');
      },
      _measure: function _measure() {
        var $wrapper = this.$element;
        var $inner = this._getTrack();
        if (!$inner.length) {
          return null;
        }
        var panels = $inner.children('.ha-hs-item').length;
        if (!panels) {
          return null;
        }
        var containerWidth = $wrapper.outerWidth();
        if (!containerWidth || containerWidth < 1) {
          return null;
        }
        var isAutoWidth = $wrapper.hasClass('ha-hs-auto-width-enabled');
        var hasCustomWidth = !isAutoWidth && $inner.children('.ha-hs-item-custom-width').length > 0;
        var autoMode = isAutoWidth || hasCustomWidth;
        var totalWidth = autoMode ? $inner[0].scrollWidth : containerWidth * panels;
        var maxTranslate = Math.max(0, totalWidth - containerWidth);
        return {
          panels: panels,
          containerWidth: containerWidth,
          totalWidth: totalWidth,
          maxTranslate: maxTranslate,
          autoMode: autoMode
        };
      },
      _applyGeometry: function _applyGeometry() {
        var geom = this._measure();
        if (!geom) {
          return null;
        }
        this._geom = geom;
        var $inner = this._getTrack();
        if (!geom.autoMode) {
          $inner.width(geom.totalWidth);
        }
        return geom;
      },
      _getGeometry: function _getGeometry() {
        if (this._geom) {
          return this._geom;
        }
        return this._applyGeometry() || {
          panels: 0,
          containerWidth: 0,
          totalWidth: 0,
          maxTranslate: 0,
          autoMode: false
        };
      },
      _isRight: function _isRight() {
        return (this.getElementSettings().ha_hs_direction || 'left') === 'right';
      },
      _fromX: function _fromX() {
        var geom = this._getGeometry();
        return this._isRight() ? -geom.maxTranslate : 0;
      },
      _toX: function _toX() {
        var geom = this._getGeometry();
        return this._isRight() ? 0 : -geom.maxTranslate;
      },
      _scrollDistance: function _scrollDistance() {
        var geom = this._getGeometry();
        // No horizontal overflow → no pin distance, so no phantom
        // vertical whitespace is reserved.
        return geom.maxTranslate > 0 ? geom.totalWidth : 0;
      },
      run: function run() {
        if (window.innerWidth < 1025) {
          return;
        }
        var settings = this.getElementSettings();
        if (settings.ha_hs_switcher !== 'yes') return;
        if (this.isEdit) {
          return;
        }

        // Idempotent: never build a second track.
        if (this._getTrack().length) {
          this._restoreVerticalLayout();
        }
        var $wrapper = this.$element;
        var host = this._getHost();
        var $children = host.children();
        if ($children.length < 2) return;
        var snap_switcher = settings.ha_snap_scroll_switcher || 'no';

        // Build track
        var $inner = $('<div class="ha-hs-inner"></div>');
        $children.each(function () {
          var $child = $(this);
          $child.addClass('ha-hs-item');
          if (itemHasCustomWidth(this)) {
            $child.addClass('ha-hs-item-custom-width');
          }
          $child.appendTo($inner);
        });
        host.append($inner);
        this._createAnimation($wrapper, $inner, settings, snap_switcher);

        // Re-observe (run can be called after a mobile restore).
        this._disconnectObserver();
        this._observeGeometry();

        // One settled refresh after init catches late font/image layout
        // that emits no layout event. Coalesces with any other signal.
        this._scheduleRefresh();
      },
      _restoreVerticalLayout: function _restoreVerticalLayout() {
        this._disconnectObserver();
        var $inner = this._getTrack();
        if (!$inner.length) {
          return;
        }
        var $host = $inner.parent();
        gsap.set($inner[0], {
          clearProps: 'transform,width'
        });
        $inner.children().each(function () {
          $(this).removeClass('ha-hs-item ha-hs-item-custom-width');
        }).appendTo($host);
        $inner.remove();
      },
      _createAnimation: function _createAnimation($wrapper, $inner, settings, snap_switcher) {
        this._geom = null;
        var geom = this._applyGeometry();
        if (!geom) return;
        var self = this;
        gsap.set($inner[0], {
          x: self._fromX()
        });
        var snapPoints = 0;
        if (snap_switcher === 'yes' && geom.panels > 1) {
          snapPoints = 1 / (geom.panels - 1);
        }
        var baseConfig = {
          trigger: $wrapper[0],
          invalidateOnRefresh: true,
          snap: snapPoints,
          // Re-measure the track and reserve the correct pin distance
          // BEFORE ScrollTrigger reads end()/start on every refresh,
          // so stale initialization values can never be reused.
          onRefreshInit: function onRefreshInit() {
            self._geom = null;
            self._applyGeometry();
          },
          end: function end() {
            return '+=' + self._scrollDistance();
          }
        };
        var stConfig;
        if (this.isEdit) {
          // Editor: scroll-driven without pin
          // pin does not work inside Elementor's editor iframe
          stConfig = $.extend({}, baseConfig, {
            start: 'top center',
            end: 'bottom center',
            scrub: 1
          });
        } else {
          // Frontend: scroll-driven with pin
          stConfig = $.extend({}, baseConfig, {
            start: 'top top',
            pin: true,
            scrub: 1,
            duration: 1,
            markers: false,
            anticipatePin: 1
          });
        }
        this.scrollTween = gsap.fromTo($inner[0], {
          x: function x() {
            return self._fromX();
          }
        }, {
          x: function x() {
            return self._toX();
          },
          ease: 'none',
          scrollTrigger: stConfig
        });
        if (this.isEdit) {
          setTimeout(function () {
            ScrollTrigger.refresh();
          }, 200);
        }
      },
      killAnimation: function killAnimation() {
        if (this.scrollTween) {
          if (this.scrollTween.scrollTrigger) {
            this.scrollTween.scrollTrigger.kill();
          }
          this.scrollTween.kill();
          this.scrollTween = null;
        }
        if (window.ScrollTrigger) {
          var $el = this.$element;
          ScrollTrigger.getAll().forEach(function (st) {
            if (st.vars.trigger === $el[0]) {
              st.kill();
            }
          });
        }
        this._geom = null;
        this._initDone = false;
      }
    });
    elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
      elementorFrontend.elementsHandler.addHandler(HappyHorizontalScroll, {
        $element: $scope
      });
    });
  });
})(jQuery, window);