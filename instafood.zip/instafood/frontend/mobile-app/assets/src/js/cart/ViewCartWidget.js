
import LanguageUtils from '../utils/LanguageUtils';
import EventBus, { Events, Event } from '../events/EventBus';
import Cart from './Cart';
import DataUtils from '../utils/DataUtils';

class ViewCartWidget {

    _parent_ui = null;
    _ui = null;
    _cartViewBtn = null;
    _onCartChangeEvent = null;

    render(parent_ui) {
        const _this = this;
        this._parent_ui = parent_ui;
        const template = `
        <div class="screen_bottom_controls hide"></div>
        `;

        const btnLabel = LanguageUtils.getInstance().getLabel('view_cart_label');
        this._cartViewBtn = jQuery(`
        <a href="#" class="apt_button primary view_cart_btn">
        <span class="quantity_info info_number white"></span>
        <span class="view_label">${btnLabel}</span>
        <span class="price_info"></span>
        </a>`);

        this._ui = jQuery(template);
        this._ui.appendTo(this._parent_ui);
        this._cartViewBtn.appendTo(this._ui);


        this._cartViewBtn.click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.OPEN_CART_SCREEN_REQUEST);
        });

        this._onCartChangeEvent = new Event(Events.CART_CHANGED, ({ cartProduct }) => {
            this._handleCartChange();
        });
        EventBus.getInstance().registerEvent(this._onCartChangeEvent);
    }

    show() {
        this._ui.css('opacity', 1);
        if (this._ui.hasClass('hide')) {
            this._ui.removeClass('hide')
        }
    }

    hide() {
        this._ui.css('opacity', 0);
        if (!this._ui.hasClass('hide')) {
            this._ui.addClass('hide')
        }
    }

    _handleCartChange() {
        if (Cart.getInstance().cartHasItems()) {
            const t = DataUtils.getInstance().getOption('price_display_template');
            const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));
            this.show();
            this._ui.find('.quantity_info').html(Cart.getInstance().getCartQuantity());
            const total = Cart.getInstance().getCartTotal();
            const formattedPrice = DataUtils.getInstance().getFormmatedPriceDisplay(total);
            this._ui.find('.price_info').html(priceTemplate({ price: formattedPrice }));
        } else {
            this.hide();
        }
    }

    remove() {
        this._ui.remove();
    }
}
export default ViewCartWidget;