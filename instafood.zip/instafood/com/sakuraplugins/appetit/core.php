<?php
namespace com\sakuraplugins\appetit;

if (!defined('ABSPATH')) exit;
require_once(plugin_dir_path(__FILE__) . 'cpt/MenuItemCpt.php');
require_once(plugin_dir_path(__FILE__) . 'cpt/OrderCpt.php');
require_once(plugin_dir_path(__FILE__) . 'cpt/ChoiceGroupsCpt.php');
require_once(plugin_dir_path(__FILE__) . 'utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . 'utils/TermsUtils.php');
require_once(plugin_dir_path(__FILE__) . 'utils/RedirectUtils.php');
require_once(plugin_dir_path(__FILE__) . 'utils/PriceUtil.php');
require_once(plugin_dir_path(__FILE__) . 'utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . 'utils/UserManagement.php');
require_once(plugin_dir_path(__FILE__) . 'services/AssetsService.php');
require_once(plugin_dir_path(__FILE__) . 'services/ProductSevice.php');
require_once(plugin_dir_path(__FILE__) . 'services/PrintNodeService.php');
require_once(plugin_dir_path(__FILE__) . 'services/ChoiceGroupsService.php');
require_once(plugin_dir_path(__FILE__) . 'services/CategoriesService.php');
require_once(plugin_dir_path(__FILE__) . 'services/StripeService.php');
require_once(plugin_dir_path(__FILE__) . 'services/LocalesService.php');
require_once(plugin_dir_path(__FILE__) . 'services/AjaxService.php');
require_once(plugin_dir_path(__FILE__) . 'services/OptionsService.php');
require_once(plugin_dir_path(__FILE__) . 'rest_api/models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . 'rest_api/models/order/OrderPaymentStatus.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/settings/Settings.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/orders_management/OrdersManagement.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/menu_item/ItemMtbx.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/order/OrderMtbx.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/menu_choice_group/ChoiceGroupMtbx.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/choices/ChoiceEdit.php');
require_once(plugin_dir_path(__FILE__) . 'templates/admin/menucategories/MenuCategoriesEdit.php');
require_once(plugin_dir_path(__FILE__) . 'config.php');
require_once(plugin_dir_path(__FILE__) . 'rest_api/routes/RoutesManager.php');
require_once(plugin_dir_path(__FILE__) . 'shortcodes/ShortcodeManager.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt;
use com\sakuraplugins\appetit\cpt\OrderCpt;
use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt;
use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\TermsUtils;
use com\sakuraplugins\appetit\utils\UserManagement;
use com\sakuraplugins\appetit\services\AssetsService;
use com\sakuraplugins\appetit\templates\admin\settings\Settings;
use com\sakuraplugins\appetit\templates\admin\orders_management\OrdersManagement;
use com\sakuraplugins\appetit\templates\admin\menu_item\ItemMtbx;
use com\sakuraplugins\appetit\templates\admin\order\OrderMtbx;
use com\sakuraplugins\appetit\templates\admin\menu_item\ChoiceGroupMtbx;
use com\sakuraplugins\appetit\templates\admin\choices\ChoiceEdit;
use com\sakuraplugins\appetit\templates\admin\menucategories\MenuCategoriesEdit;
use com\sakuraplugins\appetit\rest_api\routes\RoutesManager;
use com\sakuraplugins\appetit\shortcodes\ShortcodeManager;



class AppetitCore {
    public function run(): void {
        // entry point
        $this->registerActions();
    }

    public function initializeHandler(): void {
        UserManagement::mapCapabilitiesToRoles();
        $this->registerCustomPostType();
        self::addImageSizes();
        $sm = new ShortcodeManager();
        $sm->registerShortcodes();
    }

    // set up image sizes for topics
    public static function addImageSizes() {
        add_theme_support('post-thumbnails');
        add_image_size('appetit-cover-large', 1000);
        add_image_size('appetit-cover-medium', 700);
        add_image_size('appetit-aquare-large', 512, 512, true);
        add_image_size('appetit-aquare-medium', 250, 250, true);
        add_image_size('appetit-aquare-medium-large', 350, 350, true);
        add_image_size('appetit-aquare-small', 180, 180, true);
    }

    public function registerSettingsGroups() {
        register_setting(Config::getOptionsGroupSlug(), Config::getOptionsGroupSlug());
    }

    public function adminMenuHandler() {
        $settings = new Settings();
        add_menu_page(esc_html__('InstaFood Settings', 'instafood'), esc_html__('InstaFood Settings', 'instafood'), UserManagement::IF_SETTINGS_CAP, Config::getSettingsPageSlug(), [$settings, 'render'], NULL, 83);
        $ordersManagementPage = new OrdersManagement();
        add_menu_page(esc_html__('InstaFood Orders', 'instafood'), esc_html__('InstaFood Orders', 'instafood'), UserManagement::ORDERS_PAGE_CAP, Config::getOrdersPageSlug(), [$ordersManagementPage, 'render'], NULL, 84);
    }
    
    public function registerCustomPostType(): void {
        $appetitItemCPT = new MenuItemCpt();
        $menuCatReWrite = OptionUtil::getInstance()->getOption(MenuItemCpt::REWRITE_KEY, MenuItemCpt::DEFAULT_REWRITE_SLUG);

        $args = $appetitItemCPT->getSettings($menuCatReWrite, 81);
        $appetitItemCPT->create(MenuItemCpt::getPostType(), array_merge($args, [
            'show_in_rest' => false,
            'show_ui' => true,
            'show_in_menu' => true,
        ]));
        MenuItemCpt::registerTaxonomies();

        $instaFoodOrder = new OrderCpt();
        $orderArgs = $instaFoodOrder->getSettings(OrderCpt::DEFAULT_REWRITE_SLUG, 81);
        $appetitItemCPT->create(OrderCpt::getPostType(), array_merge($orderArgs, [
            'show_in_rest' => false,
            'show_ui' => false,
            'show_in_menu' => false,
        ]));


        $appetitChoiceGroupsCPT = new ChoiceGroupsCpt();
        $choiceGroupReWrite = OptionUtil::getInstance()->getOption(ChoiceGroupsCpt::REWRITE_KEY, ChoiceGroupsCpt::DEFAULT_REWRITE_SLUG);

        $args = $appetitChoiceGroupsCPT->getSettings($choiceGroupReWrite, 82);
        $appetitChoiceGroupsCPT->create(ChoiceGroupsCpt::getPostType(), array_merge($args, [
            'show_in_rest' => false,
            'show_ui' => true,
            'show_in_menu' => true,
        ]));
        ChoiceGroupsCpt::registerTaxonomies();
    }

    public function appetitAdminBarCustom(): void {
        if (!function_exists('get_current_screen')) {
            return;
        }
        $current_screen = get_current_screen();
        $isSettingsPage = $current_screen->id === 'toplevel_page_' . Config::getSettingsPageSlug();
        $showBanner = $current_screen->post_type === MenuItemCpt::getPostType() || $current_screen->post_type === ChoiceGroupsCpt::getPostType() || $isSettingsPage;

        if ($showBanner) {
            require_once plugin_dir_path( __FILE__ ) . 'templates/admin/AdminBanner.php';
            \com\sakuraplugins\appetit\templates\admin\AdminBanner::render();
        }
    }

    public function loadAdminScripts($hook): void {
        $current_screen = get_current_screen();
        $isSettingsPage = $current_screen->id === 'toplevel_page_' . Config::getSettingsPageSlug();
        $isOrdersManagementPage = $current_screen->id === 'toplevel_page_' . Config::getOrdersPageSlug();
        $isMenuItemPage = $current_screen->post_type === MenuItemCpt::getPostType();
        $isChoiceGrouppage = $current_screen->post_type === ChoiceGroupsCpt::getPostType();
        $isMenuItemEditPage = $current_screen->id === MenuItemCpt::getPostType() && $current_screen->post_type === MenuItemCpt::getPostType();        

        $isChoiceGroupEditpage = $current_screen->id === ChoiceGroupsCpt::getPostType() && 
        $current_screen->post_type === ChoiceGroupsCpt::getPostType() && $current_screen->base === 'post';

        $isAdminChoiceEdit = $current_screen->id === 'edit-' . ChoiceGroupsCpt::CHOICE_SLUG;
        $isAdminMenuCategoryEdit = $current_screen->id === 'edit-' . MenuItemCpt::MENU_CAT_SLUG;
        

        $isAppetitPage = $isSettingsPage || $isMenuItemPage || $isChoiceGrouppage || $isMenuItemEditPage || $isChoiceGroupEditpage || $isAdminChoiceEdit;

        if ($isAppetitPage) {
            wp_enqueue_script('jquery');
        }
        
        if ($isAdminChoiceEdit || $isAdminMenuCategoryEdit) {
            AssetsService::loadBootstrapAll();
        }

        if ($isSettingsPage) {
            AssetsService::loadAdminSettingsAssets();
        }

        if ($isOrdersManagementPage) {
            AssetsService::loadAdminOrdersManagementAssets();
        }

        if ($isMenuItemEditPage) {
            AssetsService::loadMenuItemAssets();
        }

        if ($isChoiceGroupEditpage) {
            AssetsService::loadChoiceGroupAssets();
        }

        if ($isAppetitPage) {
            AssetsService::loadAdminMainCss();
        }
    }

    public function addMetaBoxes() {
        $itemMtbx = new ItemMtbx();
        add_meta_box(
            'appetit_item_details_mtbx',
            esc_html__('Item details', 'instafood'),
            [$itemMtbx, 'renderDetails'],
            MenuItemCpt::getPostType(),
            'advanced',
            'high'
        );

        $orderMtbx = new OrderMtbx();
        add_meta_box(
            'appetit_order_details_mtbx',
            esc_html__('Order details', 'instafood'),
            [$orderMtbx, 'render'],
            OrderCpt::getPostType(),
            'advanced',
            'high'
        );

        add_meta_box(
            'appetit_item_photo_mtbx',
            esc_html__('Dish photo', 'instafood'),
            [$itemMtbx, 'renderPhoto'],
            MenuItemCpt::getPostType(),
            'advanced',
            'high'
        );

        add_meta_box(
            'appetit_item_prices_mtbx',
            esc_html__('Prices and sizes', 'instafood'),
            [$itemMtbx, 'renderPrices'],
            MenuItemCpt::getPostType(),
            'advanced',
            'high'
        );

        add_meta_box(
            'appetit_item_choices_mtbx',
            esc_html__('Choice Groups', 'instafood'),
            [$itemMtbx, 'renderGroupChoices'],
            MenuItemCpt::getPostType(),
            'advanced',
            'high'
        );

        add_meta_box(
            'appetit_item_exclude_opts_mtbx',
            esc_html__('Product exclude options', 'instafood'),
            [$itemMtbx, 'renderExcludeOptions'],
            MenuItemCpt::getPostType(),
            'advanced',
            'high'
        );

        $choiceGroupMtbx = new ChoiceGroupMtbx();
        add_meta_box(
            'appetit_choice_group_details_mtbx',
            esc_html__('Choice group details', 'instafood'),
            [$choiceGroupMtbx, 'renderGroupDetails'],
            ChoiceGroupsCpt::getPostType(),
            'advanced',
            'high'
        );
        add_meta_box(
            'appetit_choice_group_choices_mtbx',
            esc_html__('Choices', 'instafood'),
            [$choiceGroupMtbx, 'renderGroupChoices'],
            ChoiceGroupsCpt::getPostType(),
            'advanced',
            'high'
        );
    }

    public function appetit_on_page_template($original_template) {
        global $post;
        $isPage = isset($post) && isset($post->post_type) && $post->post_type === 'page';

        $frontend_is_homepage_enabled = OptionUtil::getInstance()->getOption("frontend_is_homepage_enabled", '');

        if ($frontend_is_homepage_enabled === 'ON' && is_home()) {
            $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
            if ($mobileAppPageId !== '') {
                $appetit_mobile_app_response = apply_filters('appetit_mobile_app_request', $original_template);
                if (isset($appetit_mobile_app_response)) {
                    return $appetit_mobile_app_response;
                }
            }
        }

        if ($isPage && $post->post_type === 'page') {
            $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
            if ($mobileAppPageId !== '' && (int) $mobileAppPageId === $post->ID) {
                $appetit_mobile_app_response = apply_filters('appetit_mobile_app_request', $original_template);
                if (isset($appetit_mobile_app_response)) {
                    $original_template = $appetit_mobile_app_response;
                }
            }

            $invoicePageId = OptionUtil::getInstance()->getOption('invoice_page_id', '');
            if ($invoicePageId !== '' && (int) $invoicePageId === $post->ID) {
                $original_template = plugin_dir_path(__FILE__) . 'services/PDFService.php';
            }
        }
        return $original_template;
    }

    public function on_appetit_mobile_app_request($original_template) {
        return dirname( __FILE__ ) . '../../../../frontend/mobile-app/index.php';
    }

    public function saveCustomPosts(int $post_id) {
        // check autosave
        if(wp_is_post_autosave($post_id)) {
            return 'autosave';
        }

        //check post revision
        if(wp_is_post_revision($post_id)) {
            return 'revision';
        }

        // check permissions for saving
        if (isset($_POST['post_type']) && MenuItemCpt::getPostType() === $_POST['post_type']) {
            if (!current_user_can('edit_post', $post_id)) {
                return esc_html__('You do not have permission to edit this page', 'instafood');
            } elseif (!current_user_can('edit_post', $post_id)) {
                return esc_html__('You do not have permission to edit this post', 'instafood');
            }

            if (isset($_POST[MenuItemCpt::getMetaKey()])) {
                $termUtils = new TermsUtils();
                if (isset($_POST[MenuItemCpt::getMetaKey()]['item_category'])) {
                    $itemCategories = $_POST[MenuItemCpt::getMetaKey()]['item_category'];
                    if (is_array($itemCategories) && sizeof($itemCategories) > 0) {
                        $termUtils->set_post_terms($post_id, $itemCategories, MenuItemCpt::MENU_CAT_SLUG);
                    }
                } else {
                    $termUtils->removeAllPostTerms($post_id, MenuItemCpt::MENU_CAT_SLUG);
                }
                update_post_meta($post_id, MenuItemCpt::getMetaKey(), $_POST[MenuItemCpt::getMetaKey()]);
            }
        }

        // check permissions for saving

        if (isset($_POST['post_type']) && ChoiceGroupsCpt::getPostType() === $_POST['post_type']) {
            if (!current_user_can('edit_post', $post_id)) {
                return esc_html__('You do not have permission to edit this page', 'instafood');
            } elseif (!current_user_can('edit_post', $post_id)) {
                return esc_html__('You do not have permission to edit this post', 'instafood');
            }

            if (isset($_POST[ChoiceGroupsCpt::getMetaKey()])) {
                update_post_meta($post_id, ChoiceGroupsCpt::getMetaKey(), $_POST[ChoiceGroupsCpt::getMetaKey()]);
            }
        }
    }

    public function saveChoiceMeta($term_id): void {
        $isChoice = isset($_POST['taxonomy']) && $_POST['taxonomy'] === ChoiceGroupsCpt::CHOICE_SLUG;
        if (isset($_POST[ChoiceGroupsCpt::CHOICE_META_KEY]) && $isChoice) {
            update_term_meta(
                $term_id,
                ChoiceGroupsCpt::CHOICE_META_KEY,
                $_POST[ChoiceGroupsCpt::CHOICE_META_KEY]
            );
        }
    }

    public function saveMenuCatMeta($term_id): void {
        $isMenuCat = isset($_POST['taxonomy']) && $_POST['taxonomy'] === MenuItemCpt::MENU_CAT_SLUG;
        if (isset($_POST[MenuItemCpt::MENU_CAT_META_KEY]) && $isMenuCat) {
            update_term_meta(
                $term_id,
                MenuItemCpt::MENU_CAT_META_KEY,
                $_POST[MenuItemCpt::MENU_CAT_META_KEY]
            );
        }
    }

    public function appetit_request_random_safematch_color(array $bkgColors) {
        // can be extended from another plugin
        $colors = ['#F25A38', '#038C8C', '#3c3c3c'];
        return $colors[rand(0, 2)];
    }
    
    public function register_query_vars($vars) {
        $vars[] = 'ift'; // instafood table 
        $vars[] = 'ifp_redirect'; // instafood payment redirect (success | fail)
        $vars[] = 'if_oid'; // instafood order id 
        $vars[] = 'ifp'; // instafood payment ( possible values [stripe] )
        $vars[] = 'opid'; // order public id
        return $vars;
    }

    public function settings_page_cap($capability) {
        return UserManagement::IF_SETTINGS_CAP;
    }

    public function ift_editable_roles($roles) {
        
        $user = wp_get_current_user();
        $isRestaurantAdmin = in_array(UserManagement::IF_RESTAURANT_ADMIN, $user->roles);
        if ($isRestaurantAdmin) {
            $tmp = array_keys($roles);
            foreach($tmp as $r) {
                $isRestaurantStaff = $r === UserManagement::IF_RESTAURANT_STAFF;
                $isRestaurantAdministrator = $r === UserManagement::IF_RESTAURANT_ADMIN;
                if($isRestaurantStaff || $isRestaurantAdministrator) continue;
                unset($roles[$r]);
            }
        }
        return $roles;
    }

    function filter_users_by_job_role_section($u_query) {

        $current_user = wp_get_current_user();

        $isRestAdmin = in_array(UserManagement::IF_RESTAURANT_ADMIN, $current_user->roles);
        if ($isRestAdmin) { 
            global $wpdb;
            $u_query->query_where = str_replace(
                'WHERE 1=1', 
                "WHERE 1=1 AND {$wpdb->users}.ID IN (
                  SELECT {$wpdb->usermeta}.user_id FROM $wpdb->usermeta 
                  WHERE {$wpdb->usermeta}.meta_key = '{$wpdb->prefix}capabilities'
                  AND {$wpdb->usermeta}.meta_value LIKE '%IF_RESTAURANT_STAFF%' OR {$wpdb->usermeta}.meta_value LIKE '%IF_RESTAURANT_ADMIN%')", 
                $u_query->query_where
            );
        }
    }
    

    private function registerActions(): void {
        $routesManager = new RoutesManager();
        add_action('init', [$this, 'initializeHandler']);
        add_action('admin_init', [$this, 'registerSettingsGroups']);
        add_action('admin_menu', [$this, 'adminMenuHandler']);
        add_action('wp_before_admin_bar_render', [$this, 'appetitAdminBarCustom']);
        add_action('admin_enqueue_scripts', [$this, 'loadAdminScripts']);
        add_action('add_meta_boxes', [$this, 'addMetaBoxes']);
        add_action('save_post', [$this, 'saveCustomPosts']);
        $choiceEdit = new ChoiceEdit();
        add_action(ChoiceGroupsCpt::CHOICE_SLUG . '_add_form_fields', [$choiceEdit, 'onNewChoice']);
        add_action(ChoiceGroupsCpt::CHOICE_SLUG . '_edit_form_fields', [$choiceEdit, 'onEditChoice']);        
        add_action('created_' . ChoiceGroupsCpt::CHOICE_SLUG, [$this, 'saveChoiceMeta']);
        add_action('edited_' . ChoiceGroupsCpt::CHOICE_SLUG, [$this, 'saveChoiceMeta']);
        $menuCatEdit = new MenuCategoriesEdit();
        add_action(MenuItemCpt::MENU_CAT_SLUG . '_add_form_fields', [$menuCatEdit, 'onNewCategory']);
        add_action(MenuItemCpt::MENU_CAT_SLUG . '_edit_form_fields', [$menuCatEdit, 'onEditCategory']);
        add_action('created_' . MenuItemCpt::MENU_CAT_SLUG, [$this, 'saveMenuCatMeta']);
        add_action('edited_' . MenuItemCpt::MENU_CAT_SLUG, [$this, 'saveMenuCatMeta']);
        add_filter('template_include', [$this, 'appetit_on_page_template']);
        add_filter('appetit_mobile_app_request', [$this, 'on_appetit_mobile_app_request'], 10);
        add_filter('appetit_request_random_safematch_color', [$this, 'appetit_request_random_safematch_color'], 10);
        add_filter('query_vars', [$this, 'register_query_vars']);
        add_action('rest_api_init', [$routesManager, 'registerRoutes']);
        add_filter('option_page_capability_' . Config::getOptionsGroupSlug(), [$this, 'settings_page_cap']);
        add_action('wp_ajax_fetch_orders', ['\com\sakuraplugins\appetit\services\AjaxService', 'fetchOrders']);
        add_action('wp_ajax_order_status', ['\com\sakuraplugins\appetit\services\AjaxService', 'changeOrderStatus']);
        add_action('wp_ajax_fetch_order_single', ['\com\sakuraplugins\appetit\services\AjaxService', 'fetchOrderSingle']);
        add_action('wp_ajax_fetch_waiter_calls', ['\com\sakuraplugins\appetit\services\AjaxService', 'fetchWaiterCalls']);
        add_action('wp_ajax_delete_waiter_call', ['\com\sakuraplugins\appetit\services\AjaxService', 'deleteWaiterCall']);
        add_action('wp_ajax_get_printnode_printers', ['\com\sakuraplugins\appetit\services\AjaxService', 'getPrintNodePrinters']);
        add_action('wp_ajax_remote_print_order_single', ['\com\sakuraplugins\appetit\services\AjaxService', 'printRemote']);
        add_filter('editable_roles', [$this, 'ift_editable_roles']);
        add_filter('pre_user_query', [$this, 'filter_users_by_job_role_section']);
    }
}
?>