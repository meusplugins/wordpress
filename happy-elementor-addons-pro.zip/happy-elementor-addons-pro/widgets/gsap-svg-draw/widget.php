<?php
    /**
 * GSAP SVG Draw Widget.
 * @since 1.0.0
 * @package Happy_Addons_Pro
 */

    namespace Happy_Addons_Pro\Widget;

    use Elementor\Controls_Manager;

    defined( 'ABSPATH' ) || die();

    class Gsap_Svg_Draw extends Base {

    public function get_title() {
        return __( 'GSAP SVG Draw', 'happy-addons-pro' );
    }

    public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/svg-draw/';
    }

    public function get_icon() {
        return 'hm hm-timeline-spiral';
    }

    public function get_keywords() {
        return ['gsap', 'svg', 'draw', 'animation', 'scroll-triggered', 'svg-draw', 'GSAP', 'Gsap-Svg'];
    }

    protected function register_content_controls() {
        $this->__svg_draw_content_controls();
        $this->__svg_draw_settings_controls();
        $this->__svg_draw_linkable_controls();
    }

    protected function __svg_draw_content_controls() {

        $this->start_controls_section(
            '_section_svg_draw_content',
            [
                'label' => __( 'Content', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control(
            'ha_gsd_svg_type',
            [
                'label'       => __( 'SVG Type', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'svg_code',
                'options'     => [
                    'svg_code'  => __( 'SVG Code', 'happy-addons-pro' ),
                    'svg_image' => __( 'SVG Image', 'happy-addons-pro' )
                ],
                'render_type' => 'template'
            ]
        );

        $this->add_control(
            'ha_gsd_svg_image',
            [
                'label'       => __( 'Choose SVG Image', 'happy-addons-pro' ),
                'type'        => Controls_Manager::MEDIA,
                'media_types' => ['svg'],
                'condition'   => [
                    'ha_gsd_svg_type' => 'svg_image'
                ],
                'description' => 'You can use these sites to Convert SVG image to code: <a href="https://nikitahl.github.io/svg-2-code/" target="_blank">SVG 2 CODE</a> '
            ]
        );

        $this->add_control(
            'ha_gsd_svg_code',
            [
                'label'             => __( 'SVG Code', 'happy-addons-pro' ),
                'type'              => Controls_Manager::TEXTAREA,
                'condition'         => [
                    'ha_gsd_svg_type' => 'svg_code'
                ],
                'sanitize_callback' => 'wp_kses_post',
                'description'       => 'You can use these sites to Convert SVG image to code: <a href="https://nikitahl.github.io/svg-2-code/" target="_blank">SVG 2 CODE</a> ',
                'default'           => '<svg xmlns:xlink="http://www.w3.org/1999/xlink"  id="svg-stage" xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 103 103" fill="none" stroke-width="2.2" opacity="0" style="opacity: 1;">
    <defs>
      <linearGradient id="grad-1" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
        <stop offset="0.2" stop-color="rgb(255, 135, 9)"></stop>
        <stop offset="0.8" stop-color="rgb(247, 189, 248)"></stop>
      </linearGradient>
    </defs>
    <path stroke="url(#grad-1)" d="M50.5 50.5h50v50s-19.2 1.3-37.2-16.7S56 35.4 35.5 15.5C18.5-1 .5.5.5.5v50h50s25.6-.6 38-18 12-32 12-32h-50v100H.5S.2 80.7 11.8 68.2 40 49.7 50.5 50.5Z" style="stroke-dashoffset: -8.96809; stroke-dasharray: 703.881px, 9.07809px;"></path>
  </svg>'
            ]
        );

        $this->end_controls_section();
    }

    protected function __svg_draw_settings_controls() {

        $this->start_controls_section(
            '_section_gsd_physics_settings',
            [
                'label' => __( 'Animation Settings', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control(
			'ha_gsd_panel_notice',
			[
				'type' => Controls_Manager::NOTICE,
				'notice_type' => 'info',
				'dismissible' => true,
				'heading' => __( 'Configuration', 'happy-addons-pro' ),
				'content' => __( 'For any configuration related help please <a href="https://happyaddons.com/happy-support/" target="_blank">contact support</a>', 'happy-addons-pro' ),
			]
		);

        $this->add_control(
            'ha_gsd_trigger_mode',
            [
                'label'              => __( 'Animation Mode', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'scroll',
                'options'            => [
                    'onPageLoad'     => __( 'On Page Load', 'happy-addons-pro' ),
                    'scroll'         => __( 'On Appearing', 'happy-addons-pro' ),
                    'playwithscroll' => __( 'On Scroll', 'happy-addons-pro' )
                ],
                'description'        => __( 'Select how and when the SVG drawing animation should trigger.', 'happy-addons-pro' ),
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_trigger_start',
            [
                'label'              => __( 'Start Trigger', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'description'        => __( 'The point on the trigger element where the animation should start.', 'happy-addons-pro' ),
                'default'            => 'top-center',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_gsd_trigger_mode' => ['scroll', 'playwithscroll']
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_trigger_start_custom_value',
            [
                'label'              => __( 'Start Offset', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'description'        => __( 'The offset value for the trigger start point.', 'happy-addons-pro' ),
                'size_units'         => ['px', '%'],
                'default'            => [
                    'size' => 50,
                    'unit' => '%'
                ],
                'range'              => [
                    'px' => [
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1
                    ],
                    '%'  => [
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1
                    ]
                ],
                'condition'          => [
                    'ha_gsd_trigger_mode'  => ['scroll', 'playwithscroll'],
                    'ha_gsd_trigger_start' => 'custom'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_trigger_end',
            [
                'label'              => __( 'End Trigger', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'description'        => __( 'The point on the trigger element where the animation should end.', 'happy-addons-pro' ),
                'default'            => 'bottom-center',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_gsd_trigger_mode' => 'playwithscroll'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_trigger_end_custom_value',
            [
                'label'              => __( 'End Offset', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'description'        => __( 'The offset value for the trigger end point.', 'happy-addons-pro' ),
                'size_units'         => ['px', '%'],
                'default'            => [
                    'size' => 0,
                    'unit' => '%'
                ],
                'range'              => [
                    'px' => [
                        'min'  => -2000,
                        'max'  => 2000,
                        'step' => 1
                    ],
                    '%'  => [
                        'min'  => -100,
                        'max'  => 100,
                        'step' => 1
                    ]
                ],
                'condition'          => [
                    'ha_gsd_trigger_mode' => 'playwithscroll',
                    'ha_gsd_trigger_end'  => 'custom'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_animation_method',
            [
                'label'       => __( 'Method', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SELECT,
                'options'     => [
                    'fromTo' => __( 'From - To', 'happy-addons-pro' ),
                    'from'   => __( 'From', 'happy-addons-pro' ),
                    'to'     => __( 'To', 'happy-addons-pro' )
                ],
                'default'     => 'from',
                'label_block' => true
            ]
        );

        $this->add_control(
            'ha_gsd_animation_from',
            [
                'label'       => __( 'From', 'happy-addons-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => '0%',
                'label_block' => true,
                'condition'   => [
                    'ha_gsd_animation_method' => ['from', 'fromTo']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_animation_to',
            [
                'label'       => __( 'To Value (End)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => '100%',
                'label_block' => true,
                'condition'   => [
                    'ha_gsd_animation_method' => ['to', 'fromTo']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_duration',
            [
                'label'   => __( 'Duration (s)', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 2
                ],
                'range'   => [
                    'px' => [
                        'min'  => 0.1,
                        'max'  => 90,
                        'step' => 0.1
                    ]
                ],
                'condition' => [
                    'ha_gsd_trigger_mode' => ['onPageLoad', 'scroll']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_delay',
            [
                'label'   => __( 'Delay (s)', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.5
                ],
                'range'   => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 90,
                        'step' => 0.1
                    ]
                ],
                'condition' => [
                    'ha_gsd_trigger_mode' => ['onPageLoad', 'scroll']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_enable_yoyo',
            [
                'label'       => __( 'Yoyo', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SWITCHER,
                'default'     => 'no',
                'render_type' => 'template',
                'description' => __( 'Reverse the animation after completing a loop.', 'happy-addons-pro' ),
                'condition' => [
                    'ha_gsd_trigger_mode' => ['onPageLoad', 'scroll']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_repeat',
            [
                'label'       => __( 'Repeat', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'description' => __( 'Number of times the animation should repeat. Use -1 for infinite loop.', 'happy-addons-pro' ),
                'default'     => [
                    'size' => -1
                ],
                'range'       => [
                    'px' => [
                        'min'  => -1,
                        'max'  => 1000,
                        'step' => 1
                    ]
                ],
                'condition'   => [
                    'ha_gsd_enable_yoyo' => 'yes',
                    'ha_gsd_trigger_mode' => ['onPageLoad', 'scroll']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_repeat_delay',
            [
                'label'     => __( 'Repeat Delay (s)', 'happy-addons-pro' ),
                'type'      => Controls_Manager::SLIDER,
                'default'   => [
                    'size' => 0.5
                ],
                'range'     => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 5,
                        'step' => 0.1
                    ]
                ],
                'condition' => [
                    'ha_gsd_enable_yoyo' => 'yes',
                    'ha_gsd_trigger_mode' => ['onPageLoad', 'scroll']
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_easing',
            [
                'label'   => __( 'Easing', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'none'          => __( 'None', 'happy-addons-pro' ),
                    'power1.inOut'  => __( 'Power1 InOut', 'happy-addons-pro' ),
                    'power2.inOut'  => __( 'Power2 InOut', 'happy-addons-pro' ),
                    'power3.inOut'  => __( 'Power3 InOut', 'happy-addons-pro' ),
                    'power4.inOut'  => __( 'Power4 InOut', 'happy-addons-pro' ),
                    'power1.in'     => __( 'Power1 In', 'happy-addons-pro' ),
                    'power2.in'     => __( 'Power2 In', 'happy-addons-pro' ),
                    'power3.in'     => __( 'Power3 In', 'happy-addons-pro' ),
                    'power4.in'     => __( 'Power4 In', 'happy-addons-pro' ),
                    'power1.out'    => __( 'Power1 Out', 'happy-addons-pro' ),
                    'power2.out'    => __( 'Power2 Out', 'happy-addons-pro' ),
                    'power3.out'    => __( 'Power3 Out', 'happy-addons-pro' ),
                    'power4.out'    => __( 'Power4 Out', 'happy-addons-pro' ),
                    'sine.inOut'    => __( 'Sine In Out', 'happy-addons-pro' ),
                    'back.in'       => __( 'Back In', 'happy-addons-pro' ),
                    'back.out'      => __( 'Back Out', 'happy-addons-pro' ),
                    'back.inOut'    => __( 'Back InOut', 'happy-addons-pro' ),
                    'elastic.in'    => __( 'Elastic In', 'happy-addons-pro' ),
                    'elastic.out'   => __( 'Elastic Out', 'happy-addons-pro' ),
                    'elastic.inOut' => __( 'Elastic InOut', 'happy-addons-pro' ),
                    'bounce.in'     => __( 'Bounce In', 'happy-addons-pro' ),
                    'bounce.out'    => __( 'Bounce Out', 'happy-addons-pro' ),
                    'bounce.inOut'  => __( 'Bounce InOut', 'happy-addons-pro' )
                ],
                'default' => 'sine.inOut'
            ]
        );

        $this->end_controls_section();
    }

    protected function __svg_draw_linkable_controls() {

        $this->start_controls_section(
            '_section_svg_draw_linkable',
            [
                'label' => __( 'SVG Link', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control(
            'ha_gsd_svg_linkable',
            [
                'label'              => __( 'Enable', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'default'            => 'no',
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_control(
            'ha_gsd_website_link',
            [
                'label'              => __( 'Link', 'happy-addons-pro' ),
                'type'               => Controls_Manager::URL,
                'options'            => ['url', 'is_external', 'nofollow'],
                'placeholder'        => __( 'https://example.com', 'happy-addons-pro' ),
                'default'            => [
                    'url'         => '',
                    'is_external' => true,
                    'nofollow'    => true
                ],
                'dynamic'            => [
                    'active' => true
                ],
                'condition'          => [
                    'ha_gsd_svg_linkable' => 'yes'
                ],
                'label_block'        => true,
                'frontend_available' => true
            ]
        );

        $this->end_controls_section();
    }

    protected function register_style_controls() {
        $this->__svg_draw_style_controls();
    }

    protected function __svg_draw_style_controls() {

        $this->start_controls_section(
            '_section_svg_draw_style',
            [
                'label' => __( 'Style', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'ha_gsd_stroke_color_type',
            [
                'label'              => __( 'Stroke Type', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'gradient',
                'options'            => [
                    'classic'  => __( 'Classic', 'happy-addons-pro' ),
                    'gradient' => __( 'Gradient', 'happy-addons-pro' )
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_stroke_color',
            [
                'label'              => __( 'Stroke First Color', 'happy-addons-pro' ),
                'type'               => Controls_Manager::COLOR,
                // 'default'            => '#000000',
                'default'            => '#F09CFD',
                'frontend_available' => true,
                'render_type'        => 'template',
                'selectors'          => [
                    '{{WRAPPER}} svg path'     => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg circle'   => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg rect'     => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg line'     => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg polyline' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg polygon'  => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg ellipse'  => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} svg textPath' => 'stroke: {{VALUE}}'
                ]
            ]
        );

        $this->add_control(
            'ha_gsd_stroke_color_b',
            [
                'label'              => __( 'Stroke Second Color', 'happy-addons-pro' ),
                'type'               => Controls_Manager::COLOR,
                // 'default'            => '#e2498a',
                'default'            => '#FA6197',
                'condition'          => [
                    'ha_gsd_stroke_color_type' => 'gradient'
                ],
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_stroke_gradient_type',
            [
                'label'              => __( 'Gradient Type', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'linear',
                'options'            => [
                    'linear' => __( 'Linear', 'happy-addons-pro' ),
                    'radial' => __( 'Radial', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_gsd_stroke_color_type' => 'gradient'
                ],
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_gsd_stroke_gradient_angle',
            [
                'label'              => __( 'Gradient Angle', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'size_units'         => ['deg'],
                'default'            => [
                    'unit' => 'deg',
                    'size' => 90
                ],
                'range'              => [
                    'deg' => [
                        'min'  => 0,
                        'max'  => 360,
                        'step' => 1
                    ]
                ],
                'condition'          => [
                    'ha_gsd_stroke_color_type'    => 'gradient',
                    'ha_gsd_stroke_gradient_type' => 'linear'
                ],
                'frontend_available' => true
            ]
        );

        $this->add_responsive_control(
            'ha_gsd_svg_stroke_width',
            [
                'label'      => __( 'Stroke Width', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ],
                    'em' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 0.1
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} svg path'     => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg circle'   => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg rect'     => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg line'     => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg polyline' => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg polygon'  => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg ellipse'  => 'stroke-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} svg textPath' => 'stroke-width: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_gsd_svg_width',
            [
                'label'      => __( 'Width', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 5
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} svg' => 'width: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_gsd_svg_height',
            [
                'label'      => __( 'Height', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 5
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} svg' => 'height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $svg_code = null;
        if ( $settings['ha_gsd_svg_type'] === 'svg_code' ) {
            $svg_code = $settings['ha_gsd_svg_code'];
        } elseif ( !empty( $settings['ha_gsd_svg_image']['url'] ) ) {
            $attachment_id = $settings['ha_gsd_svg_image']['id'];

            if ( $attachment_id ) {
                $file_path = get_attached_file( $attachment_id );
                if ( $file_path && file_exists( $file_path ) ) {
                    $svg_code = file_get_contents( $file_path );
                }
            }
        }

        $trigger_mode       = isset( $settings['ha_gsd_trigger_mode'] ) ? sanitize_text_field( $settings['ha_gsd_trigger_mode'] ) : 'onPageLoad';
        $trigger_start      = isset( $settings['ha_gsd_trigger_start'] ) ? sanitize_text_field( $settings['ha_gsd_trigger_start'] ) : 'top-center';
        $trigger_end        = isset( $settings['ha_gsd_trigger_end'] ) ? sanitize_text_field( $settings['ha_gsd_trigger_end'] ) : 'custom';
        $method             = sanitize_text_field( $settings['ha_gsd_animation_method'] );
        $from               = sanitize_text_field( $settings['ha_gsd_animation_from'] );
        $to                 = sanitize_text_field( $settings['ha_gsd_animation_to'] );
        $duration           = isset( $settings['ha_gsd_duration']['size'] ) ? $settings['ha_gsd_duration']['size'] : 2;
        $delay              = isset( $settings['ha_gsd_delay']['size'] ) ? $settings['ha_gsd_delay']['size'] : 0.5;
        $repeat             = isset( $settings['ha_gsd_repeat']['size'] ) ? $settings['ha_gsd_repeat']['size'] : 0;
        $repeat_delay       = isset( $settings['ha_gsd_repeat_delay']['size'] ) ? $settings['ha_gsd_repeat_delay']['size'] : 0;
        $ease               = sanitize_text_field( $settings['ha_gsd_easing'] );
        $timeline_yoyo      = sanitize_text_field( $settings['ha_gsd_enable_yoyo'] );

        $trigger_start_custom_value = isset( $settings['ha_gsd_trigger_start_custom_value']['size'] ) ? $settings['ha_gsd_trigger_start_custom_value']['size'] : 50;
        $trigger_start_custom_unit  = isset( $settings['ha_gsd_trigger_start_custom_value']['unit'] ) ? $settings['ha_gsd_trigger_start_custom_value']['unit'] : '%';
        $trigger_end_custom_value   = isset( $settings['ha_gsd_trigger_end_custom_value']['size'] ) ? $settings['ha_gsd_trigger_end_custom_value']['size'] : 0;
        $trigger_end_custom_unit    = isset( $settings['ha_gsd_trigger_end_custom_value']['unit'] ) ? $settings['ha_gsd_trigger_end_custom_value']['unit'] : '%';

        $stroke_color_type    = isset( $settings['ha_gsd_stroke_color_type'] ) ? $settings['ha_gsd_stroke_color_type'] : 'classic';
        $stroke_gradient_defs = '';
        $gradient_id          = 'ha-gsd-gradient-' . $this->get_id();

        if ( $stroke_color_type === 'gradient' && $svg_code ) {
            $stroke_color_a = isset( $settings['ha_gsd_stroke_color'] ) ? $settings['ha_gsd_stroke_color'] : '#000000';
            $stroke_color_b = isset( $settings['ha_gsd_stroke_color_b'] ) ? $settings['ha_gsd_stroke_color_b'] : '#e2498a';
            $gradient_type  = isset( $settings['ha_gsd_stroke_gradient_type'] ) ? $settings['ha_gsd_stroke_gradient_type'] : 'linear';
            $gradient_angle = isset( $settings['ha_gsd_stroke_gradient_angle']['size'] ) ? $settings['ha_gsd_stroke_gradient_angle']['size'] : 90;

            if ( $gradient_type === 'linear' ) {
                $gradient_angle_rad = ( $gradient_angle - 90 ) * M_PI / 180;
                $x1                 = round( 50 - 50 * cos( $gradient_angle_rad ), 2 );
                $y1                 = round( 50 - 50 * sin( $gradient_angle_rad ), 2 );
                $x2                 = round( 50 + 50 * cos( $gradient_angle_rad ), 2 );
                $y2                 = round( 50 + 50 * sin( $gradient_angle_rad ), 2 );

                $stroke_gradient_defs = sprintf(
                    '<defs><linearGradient id="%s" x1="%s%%" y1="%s%%" x2="%s%%" y2="%s%%"><stop offset="0%%" stop-color="%s"/><stop offset="100%%" stop-color="%s"/></linearGradient></defs>',
                    esc_attr( $gradient_id ),
                    $x1, $y1, $x2, $y2,
                    esc_attr( $stroke_color_a ),
                    esc_attr( $stroke_color_b )
                );
            } else {
                $stroke_gradient_defs = sprintf(
                    '<defs><radialGradient id="%s" cx="50%%" cy="50%%" r="50%%"><stop offset="0%%" stop-color="%s"/><stop offset="100%%" stop-color="%s"/></radialGradient></defs>',
                    esc_attr( $gradient_id ),
                    esc_attr( $stroke_color_a ),
                    esc_attr( $stroke_color_b )
                );
            }

            $svg_code = preg_replace(
                '/(<svg[^>]*>)/i',
                '$1' . $stroke_gradient_defs,
                $svg_code,
                1
            );
        }

        $this->add_render_attribute(
            'container',
            [
                'class'                              => 'ha-gsap-svg-draw-content',
                'data-trigger-mode'                  => esc_attr( $trigger_mode ),
                'data-method'                        => esc_attr( $method ),
                'data-from'                          => esc_attr( $from ),
                'data-to'                            => esc_attr( $to ),
                'data-duration'                      => esc_attr( $duration ),
                'data-delay'                         => esc_attr( $delay ),
                'data-repeat'                        => esc_attr( $repeat ),
                'data-repeatDelay'                   => esc_attr( $repeat_delay ),
                'data-ease'                          => esc_attr( $ease ),
                'data-yoyo'                          => esc_attr( $timeline_yoyo ),
                'data-triggerstart'                  => esc_attr( $trigger_start ),
                'data-triggerstartcustomvalue'       => esc_attr( $trigger_start_custom_value ),
                'data-triggerstartcustomunit'        => esc_attr( $trigger_start_custom_unit ),
                'data-triggerend'                    => esc_attr( $trigger_end ),
                'data-triggerendcustomvalue'         => esc_attr( $trigger_end_custom_value ),
                'data-triggerendcustomunit'          => esc_attr( $trigger_end_custom_unit ),
                'data-stroke-gradient-id'            => $stroke_color_type === 'gradient' ? esc_attr( $gradient_id ) : ''
            ]
        );

        if ( $stroke_color_type === 'gradient' ) {
            $this->add_render_attribute(
                'wrapper',
                [
                    'class'                => 'ha-gsap-svg-draw-wrapper ha-gsap-svg-draw-gradient',
                    'data-gradient-stroke' => esc_attr( $gradient_id )
                ]
            );
        } else {
            $this->add_render_attribute(
                'wrapper',
                [
                    'class' => 'ha-gsap-svg-draw-wrapper'
                ]
            );
        }

        ?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( $svg_code ): ?>
				<div <?php $this->print_render_attribute_string( 'container' ); ?>>
					<?php echo $svg_code; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
            }
        }