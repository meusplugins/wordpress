import DataUtils from '../utils/DataUtils';
import EventBus, { Event, Events } from '../events/EventBus';
import Cart from '../cart/Cart';

let instance;
const instanceKey = '_order';

export const ORDER_TYPES = {
    DELIVERY: 'DELIVERY',
    PICKUP: 'PICKUP',
    DINEIN: 'DINEIN'
};

class Order {

    _cartItems = [];
    _isDelivery = false;
    _isPickup = false;
    _isDineIn = false;
    _deliveryFee = 0;
    _tipfee = 0;
    _customerPhone = '';
    _customerCity = '';
    _customerAddress = '';
    _customer_notes = '';
    _canDeliverToAddress = false;
    _existingPickupData = {};
    _paymentType = '';
    _pickupCustomerPhone;
    _customerFirstName;
    _isShopOpen = false;
    _user_accepted_terms = true;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._cartItems = [];
    }

    setIsDelivery() {
        if (!DataUtils.getInstance().canDeliver()) {
            return;
        }
        this.setPaymentType('')
        this._isDelivery = true;
        this._isPickup = false;
        this._isDineIn = false;
        this._handleTip();
        this._handleDeliveryFee();
        this._updateGrandTotal();
        this.setPaymentType('');
        EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
    }

    isDelivery() {
        return this._isDelivery;
    }

    setIsPickup() {
        if (!DataUtils.getInstance().canPickUp()) {
            return;
        }
        this._isPickup = true;
        this._isDelivery = false;
        this._isDineIn = false;
        this._updateGrandTotal();
        this.setPaymentType('');
        EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
    }

    isPickup() {
        return this._isPickup;
    }

    isDineIn() {
        return this._isDineIn;
    }

    setIsDineIn() {
        if (!DataUtils.getInstance().canDineIn()) {
            return;
        }
        this._isDineIn = true;
        this._isPickup = false;
        this._isDelivery = false;
        this._handleTip();
        this._updateGrandTotal();
        this.setPaymentType('');
        EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
    }

    setDeliveryInfo(deliveryInfo) {
        this._customerPhone = _.get(deliveryInfo, '_customerPhone', '');
        this._customerCity = _.get(deliveryInfo, '_customerCity', '');
        this._customerAddress = _.get(deliveryInfo, '_customerAddress', '');
        this._customer_notes = _.get(deliveryInfo, '_customer_notes', '');
    }

    getDeliveryInfo() {
        return {
            _customerPhone: this._customerPhone,
            _customerCity: this._customerCity,
            _customerAddress: this._customerAddress,
            _customer_notes: this._customer_notes,
        }
    }

    setIsShopOpen(val) {
        this._isShopOpen = val;
        EventBus.getInstance().triggerEvent(Events.SHOP_IS_OPEN_EVENT);
    }

    getIsShopOpen() {
        return this._isShopOpen;
    }

    setUserAcceptedTerms(val) {
        this._user_accepted_terms = val;
        EventBus.getInstance().triggerEvent(Events.USER_TERMS_CHANGED);
    }

    getUserAcceptedTerms() {
        return this._user_accepted_terms;
    }    

    setCanDeliverToAddress(val, dispatchEvent) {
        this._canDeliverToAddress = val;
        if (dispatchEvent) {
            EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
        }
    }

    setPickupInfo(pickupInfo, dispatchEvent = false) {
        this._pickupCustomerPhone = _.get(pickupInfo, '_pickupCustomerPhone', '');
        this._customerFirstName = _.get(pickupInfo, '_customerFirstName', '');
        if (dispatchEvent) {
            EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
        }
    }

    getPickupInfo() {
        return {
            _pickupCustomerPhone: this._pickupCustomerPhone,
            _customerFirstName: this._customerFirstName,
        }
    }

    getCanDeliverToAddress(val) {
        return this._canDeliverToAddress;
    }

    getTipPercent() {
        return this._tipPercentage;
    }

    getTipValue() {
        return this._tipValue;
    }

    getDeliveryValue() {
        return this._deliveryFee;
    }

    getGrandTotal() {
        return this._grandTotal;
    }

    _handleTip() {
        const tipPercentage = parseInt(DataUtils.getInstance().getOption('tipping_percentage'), 10);
        if (!isNaN(tipPercentage)) {
            this._tipPercentage = tipPercentage;
            this._tipValue = (this._grandTotal * this._tipPercentage) / 100;
            this._updateGrandTotal();
        }
    }

    _handleDeliveryFee() {
        if (DataUtils.getInstance().canDeliver()) {
            const order_delivery_cost = parseFloat(DataUtils.getInstance().getOption('order_delivery_cost'));
            if (!isNaN(order_delivery_cost)) {
                this._deliveryFee = order_delivery_cost;
                this._updateGrandTotal();
            }
        }
    }

    getShippingOptions() {
        return { isPickup: this._isPickup, isDineIn: this._isDineIn, isDelivery: this._isDelivery };
    }

    setExistingPickupData(existingPickupData, dispatchEvent = false) {
        this._existingPickupData = existingPickupData;
        if (dispatchEvent) {
            EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
        }
    }
    
    getExistingPickupData() {
        return this._existingPickupData;
    }

    _updateGrandTotal() {
        if (this.isDelivery()) {
            this._grandTotal = Cart.getInstance().getCartTotal() + this._tipValue + this._deliveryFee;
        }
        if (this.isDineIn()) {
            this._grandTotal = Cart.getInstance().getCartTotal() + this._tipValue;
        }
        if (this.isPickup()) {
            this._grandTotal = Cart.getInstance().getCartTotal();
        }
    }

    setPaymentType(val, dispatchEvent = false) {
        this._paymentType = val;
        if (dispatchEvent) {
            EventBus.getInstance().triggerEvent(Events.ORDER_CONFIG_CHANGED);
        }
    }

    getPaymentType() {
        return this._paymentType;
    }

    getAvailablePaymentMethods() {
        if (this.isDelivery()) {
            return DataUtils.getInstance().getOption('delivery_payment_pethods');
        }
        if (this.isDineIn()) {
            return DataUtils.getInstance().getOption('dinein_payment_pethods');
        }
        if (this.isPickup()) {
            return DataUtils.getInstance().getOption('pickup_payment_pethods');
        }
        return [];
    }

    hasOrderTypes() {
        return DataUtils.getInstance().canDineIn() || DataUtils.getInstance().canDeliver() || DataUtils.getInstance().canPickUp();
    }

    canPlaceOrder() {
        let can = false;
        if (this._cartItems.length === 0) {
            return false;
        }
        if (this.isDelivery()) {
            const canDeliverToAddress = this.getCanDeliverToAddress();
            const isPaymentType = this.getPaymentType() !== '';
            if (canDeliverToAddress && isPaymentType && this.getIsShopOpen() && this._user_accepted_terms) {
                return true;
            }
        }
        if (this.isPickup()) {
            const isPaymentType = this.getPaymentType() !== '';
            const existingPickupData = Order.getInstance().getExistingPickupData();
            const isPickupData = existingPickupData.day && existingPickupData.time;
            const isContactInfo = this._pickupCustomerPhone;// && this._customerFirstName;
            if (!this._customerFirstName) {
                this._customerFirstName = '';
            }
        
            if (isPickupData && isContactInfo && isPaymentType && this._user_accepted_terms) {
                return true;
            }
        }
        if (this.isDineIn() && this._user_accepted_terms) {
            return this.getPaymentType() !== '' && this.getIsShopOpen();
        }
        return can;
    }

    _getOrderType() {
        let type = '';
        if (this.isDelivery()) {
            type = ORDER_TYPES.DELIVERY;
        }
        if (this.isPickup()) {
            type = ORDER_TYPES.PICKUP;
        }
        if (this.isDineIn()) {
            type = ORDER_TYPES.DINEIN;
        }
        return type;
    }

    prepareData() {
        let orderPayload = {
            _cartProducts: [],
            _cart_total: Cart.getInstance().getCartTotal()
        };
        this._cartItems.forEach(cartProduct => {
            const additional_notes = cartProduct.getAdditionalNotes();
            const variant_id = _.get(cartProduct.getSelectedVariantData(), 'ID', '');
            const product_id = _.get(cartProduct.getProduct(), 'ID');
            const _quantity = cartProduct.getQuantity();
            const cartGroupsWithChoices = cartProduct.getGroupsWithChoicesData();

            const groups = [];
            cartGroupsWithChoices.forEach(cartGroup => {
                const groupChoicesRaw = _.get(cartGroup, 'choices', []);
                const groupChoices = groupChoicesRaw.map(choiceData => {
                    return _.get(choiceData, 'term_id');
                })
                const groupId = _.get(cartGroup, 'group.ID');
                groups.push({
                    ID: groupId,
                    groupChoices
                })
            });
            orderPayload._cartProducts.push({
                variant_id,
                product_id,
                additional_notes,
                _quantity,
                _groups: groups,
            });
        });

        const _order_type = this._getOrderType();
        orderPayload._order_type = _order_type;
        if (_order_type === ORDER_TYPES.DELIVERY) {
            orderPayload._delivery_info = this.getDeliveryInfo();
        }
        if (_order_type === ORDER_TYPES.PICKUP) {
            orderPayload._pickup_date = this.getExistingPickupData();
            orderPayload._pickupCustomerPhone = this._pickupCustomerPhone;
            orderPayload._customerFirstName = this._customerFirstName;
        }
        if (_order_type === ORDER_TYPES.DINEIN) {
            orderPayload._table = DataUtils.getInstance().getCurrentTable();
        }
        orderPayload.payment_type = this.getPaymentType();
        orderPayload._user_accepted_terms = this._user_accepted_terms;
        return orderPayload;
    }


    reset() {
        this._cartItems = Cart.getInstance().getAll();
        this._isDelivery = false;
        this._isPickup = false;
        this._isDineIn = false;
        this._deliveryFee = 0;
        this._tipfee = 0;
        this._tipPercentage = 0;
        this._tipValue = 0;
        this._grandTotal = Cart.getInstance().getCartTotal();
        this._existingPickupData = {};
        this._paymentType = '';
        this._pickupCustomerPhone = null;
        this._customerFirstName = null;
        this._isShopOpen = false;
        this._user_accepted_terms = true;

        this._customerPhone = '';
        this._customerCity = '';
        this._customerAddress = '';
        this._customer_notes = '';
        this._canDeliverToAddress = false;
        
        const canDineIn = DataUtils.getInstance().canDineIn();
        if (canDineIn) {
            this.setIsDineIn();
        }

        const canDeliver = DataUtils.getInstance().canDeliver();
        const canPickUp = DataUtils.getInstance().canPickUp();
        if (canDeliver && !canPickUp) {
            this.setIsDelivery();
        }
        if (!canDeliver && canPickUp) {
            this.setIsPickup();
        }
        if (canDeliver && canPickUp) {
            this.setIsDelivery();
            // this.setIsPickup();
        }
    }

    static getInstance() {
        if (!instance) {
            instance = new Order(instanceKey);
        }
        return instance;
    }
}
export default Order;