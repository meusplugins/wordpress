<?php
namespace com\sakuraplugins\appetit\cpt;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . 'ICpt.php');


abstract class GenericPostType implements ICpt { 
    
    // create custom post
	public function create($slug, $args) {
        register_post_type($slug, $args);
    }
    

    public static function createTaxonomie($args, $postType, $taxSlug) {    
        register_taxonomy($taxSlug, array( $postType ), $args );
    }
}

?>