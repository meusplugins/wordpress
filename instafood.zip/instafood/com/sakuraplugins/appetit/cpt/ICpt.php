<?php
namespace com\sakuraplugins\appetit\cpt;
if ( ! defined( 'ABSPATH' ) ) exit;

// interface - forces method implementation
interface ICpt {
    public static function getMetaKey();
    public static function getPostType();
    public static function CPTSupports();
}
?>