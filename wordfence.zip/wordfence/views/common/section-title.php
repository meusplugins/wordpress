<?php
if (!defined('WORDFENCE_VERSION')) { exit; }
/**
 * Expects $title (or $titleHTML) to be defined. If $helpLink and $helpLabel (or $helpLabelHTML) are defined, the help link will be shown.
 * 
 * @var $title string The page title.
 * @var $titleHTML string The page title as raw HTML
 * @var $settingsLink string|null The URL for the settings link.
 * @var $settingsHelpLabel string|null The settings link's tooltip. Expected if $settingsLink is set.
 * @var $helpLink string The URL for the help link.
 * @var $helpLabel string The help link's text.
 * @var $helpLabelHTML string The help link's text as raw HTML.
 * @var $subtitle string The page subtitle.
 * @var $subtitleHTML string The page subtitle as raw HTML
 */

if (isset($title) && !isset($titleHTML)) {
	$titleHTML = esc_html($title);
}

if (isset($helpLabel) && !isset($helpLabelHTML)) {
	$helpLabelHTML = esc_html($helpLabel);
}

if (isset($subtitle) && !isset($subtitleHTML)) {
	$subtitleHTML = esc_html($subtitle);
}
?>
<div class="wf-section-title<?php echo (isset($subtitleHTML) && $subtitleHTML) ? ' wf-section-title-with-subtitle' : ''; ?>">
<?php if (isset($showIcon) && $showIcon): ?>
	<div class="wordfence-lock-icon wordfence-icon32 wf-hidden-xs"></div>
<?php endif; ?>
	<h2 class="wf-center-xs wf-flex-horizontal"<?php echo (isset($headerID) ? ' id="' . $headerID . '"' : ''); ?>>
		<?php echo $titleHTML; ?>

		<?php if (isset($settingsLink) && $settingsLink): ?>
		&nbsp;<a href="<?php echo esc_url($settingsLink) ?>" class="wf-section-title-settings-link" title="<?php echo esc_attr($settingsHelpLabel) ?>">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100.11 100.11" class="wf-options-icon"><title><?php esc_html__('Settings', 'wordfence'); ?></title><path d="M99.59,41.42a2.06,2.06,0,0,0-1.37-.82L86.3,38.78a39.34,39.34,0,0,0-2.67-6.39q1.17-1.63,3.52-4.6t3.32-4.33A2.52,2.52,0,0,0,91,22a2.1,2.1,0,0,0-.46-1.43Q88.18,17.2,79.78,9.45a2.52,2.52,0,0,0-1.63-.65,2.12,2.12,0,0,0-1.57.59l-9.25,7a40.09,40.09,0,0,0-5.87-2.41L59.64,2a1.92,1.92,0,0,0-.75-1.4A2.46,2.46,0,0,0,57.29,0H42.82a2.19,2.19,0,0,0-2.34,1.82,106,106,0,0,0-1.89,12.12,37.62,37.62,0,0,0-5.93,2.48l-9-7A2.78,2.78,0,0,0,22,8.8q-1.44,0-6.16,4.66a64.88,64.88,0,0,0-6.42,7A2.75,2.75,0,0,0,8.8,22a2.44,2.44,0,0,0,.65,1.56q4.37,5.28,7,9a32.38,32.38,0,0,0-2.54,6L1.76,40.34a2,2,0,0,0-1.24.85A2.5,2.5,0,0,0,0,42.69V57.16a2.44,2.44,0,0,0,.52,1.53,2,2,0,0,0,1.37.82l11.93,1.76a31.91,31.91,0,0,0,2.67,6.45Q15.31,69.35,13,72.31T9.65,76.65a2.54,2.54,0,0,0-.07,3q2.54,3.52,10.75,11a2.25,2.25,0,0,0,1.63.71,2.35,2.35,0,0,0,1.63-.59l9.19-7a40.54,40.54,0,0,0,5.87,2.41l1.82,12a1.92,1.92,0,0,0,.75,1.4,2.45,2.45,0,0,0,1.6.55H57.29a2.2,2.2,0,0,0,2.35-1.82,107.41,107.41,0,0,0,1.89-12.12,37.19,37.19,0,0,0,5.93-2.48l9,7a3.18,3.18,0,0,0,1.69.59q1.43,0,6.13-4.62a65.86,65.86,0,0,0,6.45-7,2.16,2.16,0,0,0,.59-1.5,2.51,2.51,0,0,0-.65-1.63q-4.69-5.74-7-9a41.57,41.57,0,0,0,2.54-5.93l12.06-1.82a2,2,0,0,0,1.3-.85,2.52,2.52,0,0,0,.52-1.5V43a2.46,2.46,0,0,0-.52-1.53ZM61.85,61.86a16.08,16.08,0,0,1-11.8,4.89A16.69,16.69,0,0,1,33.37,50.06,16.69,16.69,0,0,1,50.06,33.37,16.69,16.69,0,0,1,66.74,50.06a16.08,16.08,0,0,1-4.89,11.8Zm0,0"/></svg>
		</a>
		<?php endif; ?>
	</h2>
<?php if (isset($helpLink) && isset($helpLabelHTML)): ?>
	<span class="wf-hidden-xs"><a href="<?php echo esc_attr($helpLink); ?>" target="_blank" rel="noopener noreferrer" class="wf-help-link"><?php echo $helpLabelHTML; ?><span class="screen-reader-text"> (<?php esc_html_e('opens in new tab', 'wordfence') ?>)</span></a> <i class="wf-fa wf-fa-external-link" aria-hidden="true"></i></span>
<?php endif; ?>
</div>
<?php if (isset($subtitleHTML) && $subtitleHTML): ?>
<div class="wf-section-subtitle">
<h5 class="wf-no-top wf-no-bottom"><?php echo $subtitleHTML; ?></h5>
</div>
<?php endif; ?>
