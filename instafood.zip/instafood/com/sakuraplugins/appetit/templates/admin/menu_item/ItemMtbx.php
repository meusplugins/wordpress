<?php
namespace com\sakuraplugins\appetit\templates\admin\menu_item;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../../../cpt/MenuItemCpt.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt as MenuItemCpt;
use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt as ChoiceGroupsCpt;


class ItemMtbx {

    private $post_meta = [];
    private $post_meta_key = '';

    function __construct() {
        global $post;
        $this->post_meta_key = MenuItemCpt::getMetaKey();
        $this->post_meta = get_post_meta($post->ID, $this->post_meta_key, true);
        if (!is_array($this->post_meta)) {
            $this->post_meta = [];
        }
    }

    function renderDetails(): void {
        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="item_name_1"><?= esc_html__('Item name', 'instafood') ?>*</label>
                        <input type="text" value="<?= isset($this->post_meta['item_name_1']) ? esc_attr($this->post_meta['item_name_1']) : ''  ?>"
                         class="form-control" id="item_name_1" aria-describedby="item_name_1_help" required name="<?= esc_attr($this->post_meta_key . '[item_name_1]') ?>">
                        <small id="item_name_1_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="item_name_2"><?= esc_html__('Item name (Optional - secondary language)', 'instafood') ?></label>
                        <input type="text" value="<?= isset($this->post_meta['item_name_2']) ? esc_attr($this->post_meta['item_name_2']) : ''  ?>" class="form-control" id="item_name_2" 
                        aria-describedby="item_name_2_help" name="<?= esc_attr($this->post_meta_key . '[item_name_2]') ?>">
                        <small id="item_name_2_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="item_description_1"><?= esc_html__('Item description - (Optional)', 'instafood') ?></label>
                        <input type="text" value="<?= isset($this->post_meta['item_description_1']) ? esc_attr($this->post_meta['item_description_1']) : ''  ?>"
                         class="form-control" id="item_description_1" aria-describedby="item_description_1_help" name="<?= esc_attr($this->post_meta_key . '[item_description_1]') ?>">
                        <small id="item_description_1_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="item_description_2"><?= esc_html__('Item description (Optional - secondary language)', 'instafood') ?></label>
                        <input type="text" value="<?= isset($this->post_meta['item_description_2']) ? esc_attr($this->post_meta['item_description_2']) : ''  ?>" 
                        class="form-control" id="item_description_2" aria-describedby="item_description_2_help" name="<?= esc_attr($this->post_meta_key . '[item_description_2]') ?>">
                        <small id="item_description_2_help" class="form-text text-muted"><?= esc_html__('Example: Cheese Pizza, Apple Juice', 'instafood') ?></small>
                    </div>
                </div>
            </div>
            <?php
            $allCategories = get_terms(['taxonomy' => MenuItemCpt::MENU_CAT_SLUG, 'hide_empty' => FALSE, 'parent' => 0]);
            $selectedCategories = isset($this->post_meta['item_category']) ? $this->post_meta['item_category'] : [];
            ?>
            <div class="row mb-4">
                <div class="col-md-6">
                    <label for="exampleFormControlSelect1"><?= esc_html__('Item category (Example: Breakfast)', 'instafood') ?></label>
                    <select class="form-control" name="<?= esc_attr($this->post_meta_key . '[item_category][]') ?>" id="item_category" multiple>
                        <option value=""><?php esc_html_e('-- Select category', 'instafood') ?></option>
                        <?php if (is_array($allCategories)): ?>
                            
                            <?php foreach ($allCategories as $category): ?>
                                <?php 
                                    $isSelected = false;
                                    for ($i = 0; $i < sizeof($selectedCategories); $i++) { 
                                        $isSelected = (int) $selectedCategories[$i] === $category->term_id;
                                        if ($isSelected) {
                                            break;
                                        }
                                    }
                                    if ($isSelected) {
                                        ?><option value="<?= esc_attr($category->term_id); ?>" selected><?= esc_html($category->name); ?></option><?php
                                    } else {
                                        ?><option value="<?= esc_attr($category->term_id); ?>"><?= esc_html($category->name); ?></option><?php
                                    }
                                ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <?php if (is_array($allCategories) && sizeof($allCategories) === 0): ?>
                        <div class="alert alert-warning" role="alert">
                        <?= esc_html__('There are no menu categories added. To add a category, use the left main menu > Menu categories.', 'instafood') ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-primary" role="alert">
                            <?= esc_html__('You can select multiple categories by holding down the control (ctrl or cmd) button.', 'instafood') ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    function renderPhoto(): void {
        $square_photo = isset($this->post_meta['square_photo']) ? esc_attr($this->post_meta['square_photo']) : '';
        $landscape_photo = isset($this->post_meta['landscape_photo']) ? esc_attr($this->post_meta['landscape_photo']) : '';
        

        $square_photo_url = '';
        if ($square_photo !== '') {
            $square_photo_url_data = wp_get_attachment_image_src($square_photo, 'medium');
            if (is_array($square_photo_url_data) && isset($square_photo_url_data[0])) {
                $square_photo_url = $square_photo_url_data[0];
            }
        }

        $landscape_photo_url = '';
        if ($landscape_photo !== '') {
            $landscape_photo_url_data = wp_get_attachment_image_src($landscape_photo, 'medium');
            if (is_array($landscape_photo_url_data) && isset($landscape_photo_url_data[0])) {
                $landscape_photo_url = $landscape_photo_url_data[0];
            }
        }
        ?>
        <div class="container-fluid">
            <div class="row mt-4">
                <div class="col md-12">
                    <div class="alert alert-primary" role="alert">
                        <?= esc_html__("Upload high quality photos to showcase your item. Dishes should be centred. It's best if images do not contain watermarks, logos and collages.", 'instafood') ?>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col md-6">
                    <div class="alert alert-primary" role="alert">
                        <?= esc_html__('Recommended dimension 512px x 512px', 'instafood') ?>
                    </div>
                    <p><strong><?= esc_html__('Square photo', 'instafood') ?></strong></p>
                    <div class="upload_img_ui">
                        <div class="item-image-uploaded mb-3">
                            <?php if ($square_photo_url !== ''): ?>
                                <img src="<?= esc_url($square_photo_url) ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <input class="photo_id" name="<?= esc_attr($this->post_meta_key . '[square_photo]') ?>" value="<?= esc_attr($square_photo) ?>" type="hidden">
                        <div class="d-flex flex-row">
                            <button type="button" class="btn btn-secondary upload_btn mr-4"><?= esc_html__('Upload image', 'instafood') ?></button>
                            <a href="#" class="remove_btn <?= $square_photo_url === '' ? 'd-none' : '' ?>"><?= esc_html__('Remove image', 'instafood') ?></a>
                        </div>
                    </div>
                </div>
                <div class="col md-6">
                    <div class="alert alert-primary" role="alert">
                        <?= esc_html__('Recommended dimension 1000px x 500px', 'instafood') ?>
                    </div>
                    <p><strong><?= esc_html__('Landscape photo', 'instafood') ?></strong></p>
                    <div class="upload_img_ui">
                        <div class="item-image-uploaded mb-3">
                            <?php if ($landscape_photo_url !== ''): ?>
                                <img src="<?= esc_url($landscape_photo_url) ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <input class="photo_id" name="<?= $this->post_meta_key ?>[landscape_photo]" value="<?= esc_attr($landscape_photo) ?>" type="hidden">
                        <div class="d-flex flex-row">
                            <button type="button" class="btn btn-secondary upload_btn mr-4"><?= esc_html__('Upload image', 'instafood') ?></button>
                            <a href="#" class="remove_btn <?= $landscape_photo_url === '' ? 'd-none' : '' ?>"><?= esc_html__('Remove image', 'instafood') ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    function renderPrices(): void {
        $product_variations = isset($this->post_meta['product_variations']) && is_array($this->post_meta['product_variations']) ? $this->post_meta['product_variations'] : [];

        ?>
        <div class="container-fluid mt-4 mb-3">
            <div class="row">
                <div class="col-md-9">
                    <div class="alert alert-primary" role="alert">
                        <?= esc_html__('Add a variation if this item comes in more than one style or price.', 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-secondary add_variation_btn w-100"><?= esc_html__('Add variation', 'instafood') ?></button>
                </div>
            </div>
        </div>
        <div class="container-fluid variation_container">
            <?php if (sizeof($product_variations) === 0): ?>
                <?php
                    $this->itemVariationHelper([], 0, true, false);
                ?>
            <?php elseif (sizeof($product_variations) === 1): ?>
                <?php
                    $this->itemVariationHelper($product_variations[0], 0, true, false);
                ?>
            <?php else: ?>
                <?php for ($i=0; $i < sizeof($product_variations); $i++): ?>
                    <?php $this->itemVariationHelper($product_variations[$i], $i, false, $i === 0 ? false : true); ?>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    private function itemVariationHelper($product_variation, $count, $isSingle = true, $showDelete = true) {
        $price = isset($product_variation['price']) ? $product_variation['price'] : 0;
        $vn_1 = isset($product_variation['variation_name_1']) ? $product_variation['variation_name_1'] : '';
        $vn_2 = isset($product_variation['variation_name_2']) ? $product_variation['variation_name_2'] : '';
        $v_id = isset($product_variation['ID']) ? $product_variation['ID'] : uniqid('_id_');
        ?>
            <div class="row mb-3 variation_item">
                <div class="col-md-2">
                    <div class="form-group variation_price_ui">
                        <label><?= esc_html__('Price', 'instafood') ?>*</label>
                        <input type="number" min="0" step=".01" value="<?= esc_attr($price) ?>" required
                        class="form-control" name="<?= esc_attr($this->post_meta_key) ?>[product_variations][<?= esc_attr($count) ?>][price]">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group variation_name_ui <?= $isSingle ? 'd-none' : '' ?>">
                        <label><?= esc_html__('Variation name', 'instafood') ?></label>
                        <input type="text" value="<?= esc_attr($vn_1) ?>"
                        class="form-control" name="<?= esc_attr($this->post_meta_key) ?>[product_variations][<?= esc_attr($count) ?>][variation_name_1]">
                        <small class="form-text text-muted"><?= esc_html__('Example: Small, Medium, Large', 'instafood') ?></small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group variation_name_2_ui <?= $isSingle ? 'd-none' : '' ?>">
                        <label><?= esc_html__('Variation name (secondary language)', 'instafood') ?></label>
                        <input type="text" value="<?= esc_attr($vn_2) ?>"
                        class="form-control" name="<?= esc_attr($this->post_meta_key) ?>[product_variations][<?= esc_attr($count) ?>][variation_name_2]">
                        <small class="form-text text-muted"><?= esc_html__('Example: Small, Medium, Large', 'instafood') ?></small>
                        <input type="hidden" value="<?= esc_attr($v_id) ?>" name="<?= esc_attr($this->post_meta_key) ?>[product_variations][<?= esc_attr($count) ?>][ID]">
                    </div>
                </div>
                <div class="col-md-2">
                    <?php if ($showDelete): ?>
                    <a class="delete_variation_btn" href="#"><?= esc_html__('Delete', 'instafood') ?></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php
    }

    function renderGroupChoices(): void {
        $all_groups_args = [
            'posts_per_page' => -1,
            'post_type'      => ChoiceGroupsCpt::getPostType(),
            'post_status'    => 'publish',
        ];
        $all_groups_query = new \WP_Query($all_groups_args);
        $all_choices_groups = [];
        if ($all_groups_query->have_posts()) {
            while ($all_groups_query->have_posts()) {
                $all_groups_query->the_post();
                global $post;
                array_push($all_choices_groups, [
                    'ID' => get_the_ID(),
                    'title' => get_the_title(),
                    'edit_link' => get_edit_post_link()
                ]);
            }
        }
        wp_reset_postdata();

        $existingGroupsIds = isset($this->post_meta['choice_groups']) && is_array($this->post_meta['choice_groups']) ? $this->post_meta['choice_groups'] : [];
        $existingGroups = [];
        if (sizeof($existingGroupsIds) > 0) {
            $existing_groups_query = new \WP_Query([
                'posts_per_page' => -1,
                'post_type'      => ChoiceGroupsCpt::getPostType(),
                'post__in' => $existingGroupsIds,
                'orderby' => 'post__in' 
            ]);
            if ($existing_groups_query->have_posts()) {
                while ($existing_groups_query->have_posts()) {
                    $existing_groups_query->the_post();
                    global $post;
                    array_push($existingGroups, [
                        'ID' => get_the_ID(),
                        'title' => get_the_title(),
                        'edit_link' => get_edit_post_link()
                    ]);
                }
            }
            wp_reset_postdata();
        }

        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-12" style="color: #696969;">
                    <?= esc_html__('Add choice groups for your customers to choose from.', 'instafood') ?>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="col-md-8">
                    <?php if (is_array($all_choices_groups) && sizeof($all_choices_groups) > 0): ?>
                        <select class="form-select d-block w-100 select_choice_group">
                            <option value=""><?= esc_html__('Select choice group ...', 'instafood'); ?></option>
                            <?php foreach ($all_choices_groups as $group): ?>
                                <option data-group-id="<?= esc_attr($group['ID']) ?>" 
                                data-group-name="<?= esc_attr($group['title']) ?>" data-edit-link="<?= esc_attr($group['edit_link']) ?>" 
                                value="<?= esc_attr($group['ID']); ?>"><?= esc_html__($group['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <button type="button" class="btn btn-secondary add_choice_group_btn w-100" disabled><?= esc_html__('Add choice group', 'instafood') ?></button>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="col-md-12">
                    <ul id="sortable-groups" data-metakey="<?= esc_attr($this->post_meta_key) ?>">
                        <?php if (sizeof($existingGroups) > 0): ?>
                            <?php foreach ($existingGroups as $groupEntry): ?>
                            <li class="ui-state-default" data-id="<?= esc_attr($groupEntry['ID']) ?>">
                                <div class="choice-group-dragable">
                                    <span class="icon-drag_indicator"></span>
                                    <div class="group-title apt-display-flex apt-flex-center"><span class="mr-2 apt-display-block"><?= esc_html__($groupEntry['title']) ?></span><a class="apt-no-decoration apt-display-block" href="<?= esc_url($groupEntry['edit_link']) ?>" target="_blank"><span class="icon-external-link"></span></a>
                                        <input type="hidden" name="<?= esc_attr($this->post_meta_key) ?>[choice_groups][]" value="<?= esc_attr($groupEntry['ID']) ?>" />
                                    </div>
                                    <div><a class="delete_group" href="#"><span class="icon-trash-2"></span></a></div>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php
    }

    function renderExcludeOptions(): void {
        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-12" style="color: #696969;">
                    <?= esc_html__('Exclude product from dine-in or pickup and delivery.', 'instafood') ?>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="custom-control custom-switch" style="margin-top: 0px;">
                    <input type="checkbox" class="custom-control-input day_abailable_cb"  
                    id="item_dinein_disabled"
                    value="ON"
                    name="<?= esc_attr($this->post_meta_key . '[item_dinein_disabled]') ?>" 
                    <?= $this->post_meta['item_dinein_disabled'] ?? '' === 'ON' ? "checked" : "" ?>>
                    <label class="custom-control-label" for="item_dinein_disabled"><?= esc_html__('Hide product from dine-in.', 'instafood'); ?></label>
                </div>
            </div>
            <div class="row mt-4 mb-4">
                <div class="custom-control custom-switch" style="margin-top: 0px;">
                    <input type="checkbox" class="custom-control-input day_abailable_cb"  
                    id="item_pickup_delivery_disabled"
                    value="ON"
                    name="<?= esc_attr($this->post_meta_key . '[item_pickup_delivery_disabled]') ?>" 
                    <?= $this->post_meta['item_pickup_delivery_disabled'] ?? '' === 'ON' ? "checked" : "" ?>>
                    <label class="custom-control-label" for="item_pickup_delivery_disabled"><?= esc_html__('Hide product from pickup and delivery.', 'instafood'); ?></label>
                </div>
            </div>
        </div>
        <?php
    }
}
?>