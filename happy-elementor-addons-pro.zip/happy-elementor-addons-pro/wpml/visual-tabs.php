<?php
/**
 * Visual Tabs integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Visual_Tabs extends \WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'items';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'service_title',
			'prefix_text',
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'service_title':
				return __( 'Visual Tabs: Title', 'happy-addons-pro' );
			case 'prefix_text':
				return __( 'Visual Tabs: Prefix / Suffix Text', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'service_title':
			case 'prefix_text':
				return 'LINE';
			default:
				return '';
		}
	}
}
