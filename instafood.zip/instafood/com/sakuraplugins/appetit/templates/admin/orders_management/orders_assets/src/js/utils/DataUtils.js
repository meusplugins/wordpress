import EventBus, { Events, Event } from '../events/EventBus';

let instance;
const instanceKey = '23847238_KSJK';

class DataUtils {

    _data;
    _options = {};
    _labels = {};

    _initial_live_orders = [];
    _new_live_orders = [];

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._data = {};
    }

    setupData(jsonData) {
        if (!lodash.isNil(jsonData)) {
            try {
                this._data = JSON.parse(jsonData);
                this._options = this._data?.options;
                this._labels = this._data?.labels;
            } catch (error) {
                console.log(error);
            }
        }
    }

    getOption(optionKey, dafault = '') {
        return lodash.get(this._options, optionKey, dafault);
    }

    getLabel(key, dafault = '') {
        return lodash.get(this._labels, key, dafault);
    }

    getOrderTypeLabel(type) {
        const types = this.getOption('order_types_mapped', {});
        return types[type];
    }

    setInitialLiveOrders(val) {
        if (!Array.isArray(val)) {
            return;
        }
        this._initial_live_orders = val;
        this._liveOrdersCountEvent();
    }

    getInitialLiveOrders() {
        return this._initial_live_orders;
    }

    getInitialLiveOrdersIds() {
        return this._initial_live_orders.map(order => {
            return order?.ID;
        })
    }

    getExistingOrdersIds() {
        const existing_orders_ids = this._initial_live_orders.map(order => {
            return order?.ID;
        })
        const new_orders_ids = this._new_live_orders.map(order => {
            return order?.ID;
        });
        return [...existing_orders_ids, ...new_orders_ids];
    }

    setNewLiveOrders(orders) {
        this._new_live_orders = [...this._new_live_orders, ...orders];
        if (orders.length !== 0) {
            try {
                document.getElementById('alert1').play();
            } catch (err) { console.log(err) };   
        }
        this._liveOrdersCountEvent();
    }

    getNewLiveOrders() {
        return this._new_live_orders;
    }

    getLiveOrdersCount() {
        return this._initial_live_orders.length + this._new_live_orders.length;
    }

    _liveOrdersCountEvent() {
        EventBus.getInstance().triggerEvent(Events.LIVE_ORDERS_COUNT, { count: this.getLiveOrdersCount() });
    }

    removeLiveOrder(orderId) {
        for (let i = 0; i < this._initial_live_orders.length; i++) {
            let order = this._initial_live_orders[i];
            if (parseInt(order?.ID) === parseInt(orderId)) {
                this._initial_live_orders.splice(i, 1);
                break;
            }
        }
        for (let i = 0; i < this._new_live_orders.length; i++) {
            let order = this._new_live_orders[i];
            if (parseInt(order?.ID) === parseInt(orderId)) {
                this._new_live_orders.splice(i, 1);
                break;
            }
        }
        this._liveOrdersCountEvent();
    }

    decodeHtml(val) {
        return jQuery("<div />").html(val).text();
    }

    getOrderTypeClass(_orderType) {
        let cls = 'dinein';
        switch (_orderType) {
            case 'DELIVERY':
                cls = 'delivery';
                break;
            case 'PICKUP':
                cls = 'pickup';
                break;
            case 'DINEIN':
                cls = 'dinein';
                break;
        }
        return cls;
    }
    
    static getInstance() {
        if (!instance) {
            instance = new DataUtils(instanceKey);
        }
        return instance;
    }
}
export default DataUtils;