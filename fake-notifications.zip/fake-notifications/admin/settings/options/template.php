<?php

defined( 'ABSPATH' ) || exit;

$template = [
	'text' => [
		'type'  => 'text',
		'title' => __( 'Title', 'wow-herd-effects-pro' ),
		'val'   => '',
		'atts' => [
			'placeholder' => __( 'Placeholder', 'wow-herd-effects-pro' ),
		],
	],

	'number' => [
		'type'  => 'number',
		'title' => __( 'Title', 'wow-herd-effects-pro' ),
		'val'   => '',
		'atts' => [
			'min'  => 0,
			'max'  => 100,
			'step' => 1,
		],
	],

	'select' => [
		'type' => 'select',
		'title' => __('Title', 'wow-herd-effects-pro'),
		'val' => '1',
		'atts' => [
			'1' => __( '1', 'wow-herd-effects-pro' ),
			'2' => __( '2', 'wow-herd-effects-pro' ),
			'3' => __( '3', 'wow-herd-effects-pro' ),
		],
	],

	'color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	'checkbox' => [
		'type'  => 'checkbox',
		'title' => __( 'Title', 'wow-herd-effects-pro' ),
		'label' => __( 'Enable', 'wow-herd-effects-pro' ),
	],

	'title' => [
		'label'  => __( 'Title', 'wow-herd-effects-pro' ),
		'name'   => '',
		'toggle' => true,
		'val'    => 1
	],

	'addon' => [
		'type' => 'select',
		'name' => '',
		'val'  => '',
		'atts' => [
			'1' => __( '1', 'wow-herd-effects-pro' ),
			'2' => __( '2', 'wow-herd-effects-pro' ),
			'3' => __( '3', 'wow-herd-effects-pro' ),
		],
	],

];