<?php
/**
 * Image Masking for the Elementor V4 (Atomic) image widgets.
 *
 * The V4 counterpart of extensions/image-masking.php: the same shapes and the
 * same position / size / repeat settings, for the Atomic Image (e-image).
 *
 * Pure CSS (mask-image). The CSS is printed per element on the frontend; the
 * editor preview builds the same rules in happy-atomic-image-masking.js
 * (keep them in sync).
 *
 * @package Happy_Addons_Pro
 */
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Types\Image_Control;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

class Image_Masking extends Atomic_Feature_Base {

	const SHAPE_COUNT = 39;

	/** @var array<string,bool> */
	private static $printed = [];

	protected function prefix() {
		return 'ha_imask_';
	}

	protected function target_type() {
		return 'e-image';
	}

	protected function feature_key() {
		return 'image-masking';
	}

	protected function section_label() {
		return __( 'Image Masking', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['image'], $schema['link'] ) && ! isset( $schema['title'], $schema['tag'], $schema['text'], $schema['paragraph'] );
	}

	private static function shape_base_url() {
		return HAPPY_ADDONS_PRO_ASSETS . 'imgs/masking-shape/';
	}

	protected function fields() {
		$shapes = [];

		for ( $i = 1; $i <= self::SHAPE_COUNT; $i++ ) {
			/* translators: %d: shape number */
			$shapes[ 'shape' . $i ] = sprintf( __( 'Shape %d', 'happy-addons-pro' ), $i );
		}

		$on = [ 'switcher' => true ];

		return [
			'switcher'    => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Enable Image Masking', 'happy-addons-pro' ),
			],
			'shape_type'  => [
				'type'    => 'enum',
				'default' => 'default',
				'label'   => __( 'Masking Shape', 'happy-addons-pro' ),
				'options' => [
					'default' => __( 'Default Shapes', 'happy-addons-pro' ),
					'custom'  => __( 'Custom Shape', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'shape'       => [
				'type'    => 'enum',
				'default' => 'shape1',
				'label'   => __( 'Default Shape', 'happy-addons-pro' ),
				'options' => $shapes,
				'show'    => $on + [ 'shape_type' => 'default' ],
			],
			'position'    => [
				'type'    => 'enum',
				'default' => 'center center',
				'label'   => __( 'Position', 'happy-addons-pro' ),
				'options' => self::positions(),
				'show'    => $on,
			],
			'size'        => [
				'type'    => 'enum',
				'default' => 'contain',
				'label'   => __( 'Size', 'happy-addons-pro' ),
				'options' => [
					'auto'    => __( 'Auto', 'happy-addons-pro' ),
					'cover'   => __( 'Cover', 'happy-addons-pro' ),
					'contain' => __( 'Contain', 'happy-addons-pro' ),
					'initial' => __( 'Custom', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'custom_size' => [
				'type'    => 'number',
				'default' => 100,
				'min'     => 0,
				'max'     => 1000,
				'step'    => 1,
				'label'   => __( 'Custom Size', 'happy-addons-pro' ),
				'show'    => $on + [ 'size' => 'initial' ],
			],
			'custom_unit' => [
				'type'    => 'enum',
				'default' => '%',
				'label'   => __( 'Custom Size Unit', 'happy-addons-pro' ),
				'options' => [
					'%'  => '%',
					'px' => 'px',
					'em' => 'em',
					'vw' => 'vw',
				],
				'show'    => $on + [ 'size' => 'initial' ],
			],
			'repeat'      => [
				'type'    => 'enum',
				'default' => 'no-repeat',
				'label'   => __( 'Repeat', 'happy-addons-pro' ),
				'options' => self::repeats(),
				'show'    => $on,
			],
		];
	}

	/** Mask value for every position key (the keys double as the CSS value). */
	private static function positions() {
		return [
			'center center' => __( 'Center Center', 'happy-addons-pro' ),
			'center left'   => __( 'Center Left', 'happy-addons-pro' ),
			'center right'  => __( 'Center Right', 'happy-addons-pro' ),
			'top center'    => __( 'Top Center', 'happy-addons-pro' ),
			'top left'      => __( 'Top Left', 'happy-addons-pro' ),
			'top right'     => __( 'Top Right', 'happy-addons-pro' ),
			'bottom center' => __( 'Bottom Center', 'happy-addons-pro' ),
			'bottom left'   => __( 'Bottom Left', 'happy-addons-pro' ),
			'bottom right'  => __( 'Bottom Right', 'happy-addons-pro' ),
		];
	}

	private static function repeats() {
		return [
			'repeat'          => __( 'Repeat', 'happy-addons-pro' ),
			'repeat-x'        => __( 'Repeat-x', 'happy-addons-pro' ),
			'repeat-y'        => __( 'Repeat-y', 'happy-addons-pro' ),
			'space'           => __( 'Space', 'happy-addons-pro' ),
			'round'           => __( 'Round', 'happy-addons-pro' ),
			'no-repeat'       => __( 'No-repeat', 'happy-addons-pro' ),
			'repeat space'    => __( 'Repeat Space', 'happy-addons-pro' ),
			'round space'     => __( 'Round Space', 'happy-addons-pro' ),
			'no-repeat round' => __( 'No-repeat Round', 'happy-addons-pro' ),
		];
	}

	/** The uploaded mask image of the "Custom Shape" choice. */
	protected function extra_props() {
		return [
			$this->prefix() . 'custom' => Image_Prop_Type::make()
				->set_dependencies( $this->dependencies( [ 'switcher' => true, 'shape_type' => 'custom' ] ) ),
		];
	}

	protected function extra_controls() {
		return [
			'shape_type' => Image_Control::bind_to( $this->prefix() . 'custom' )
				->set_label( __( 'Custom Shape', 'happy-addons-pro' ) ),
		];
	}

	/** The preview builds the shape URL from the shape key. */
	public function defaults() {
		return parent::defaults() + [ 'shape_base' => self::shape_base_url() ];
	}

	/**
	 * Prints the element's rule; nothing while the mask is off.
	 */
	public function before_render( $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) || ! $this->targets_element( $element ) ) {
			return;
		}

		$id = preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $element->get_id() );

		if ( '' === $id || isset( self::$printed[ $id ] ) ) {
			return;
		}

		$settings = $element->get_atomic_settings();

		if ( empty( $settings[ $this->prefix() . 'switcher' ] ) ) {
			return;
		}

		$config = $this->sanitize_config( $settings );
		$custom = $settings[ $this->prefix() . 'custom' ]['src'] ?? '';
		$url    = 'custom' === $config['shape_type'] ? (string) $custom : self::shape_base_url() . $config['shape'] . '.svg';
		$css    = self::build_css( self::selector( $id ), $config, $url );

		if ( '' === $css ) {
			return;
		}

		self::$printed[ $id ] = true;

		echo '<style id="ha-imask-' . esc_attr( $id ) . '">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- values are whitelisted/clamped in sanitize_config() and the URL is escaped in build_css().
	}

	/**
	 * Atomic widgets sit in a `display: contents` wrapper (data-atomic), so the
	 * mask goes on the images inside it (keep in sync with the preview script).
	 */
	private static function selector( $id ) {
		$s = '[data-id="' . $id . '"]';

		return $s . ' img,img' . $s;
	}

	/** Safe inside url("..."). */
	private static function css_url( $url ) {
		$url = esc_url_raw( trim( (string) $url ) );

		return str_replace(
			[ '"', '\\', '(', ')', "\n", "\r", ' ' ],
			[ '%22', '%5C', '%28', '%29', '', '', '%20' ],
			$url
		);
	}

	/**
	 * @param string $s      Selector of the images.
	 * @param array  $config Sanitized config (prefix stripped).
	 * @param string $url    Mask image URL.
	 */
	public static function build_css( $s, array $config, $url ) {
		$url = self::css_url( $url );

		if ( '' === $url ) {
			return '';
		}

		$size = 'initial' === $config['size']
			? $config['custom_size'] . $config['custom_unit']
			: $config['size'];

		$rules = [
			'mask-image'    => 'url("' . $url . '")',
			'mask-position' => $config['position'],
			'mask-size'     => $size,
			'mask-repeat'   => $config['repeat'],
		];

		$css = '';

		foreach ( $rules as $property => $value ) {
			$css .= '-webkit-' . $property . ':' . $value . ';' . $property . ':' . $value . ';';
		}

		return $s . '{' . $css . '}';
	}
}
