<?php
namespace com\sakuraplugins\appetit\templates\admin\orders_management;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../rest_api/models/order/OrderPaymentStatus.php');
require_once(plugin_dir_path(__FILE__) . '../../../rest_api/models/order/OrderStatus.php');
require_once(plugin_dir_path(__FILE__) . '../../../rest_api/models/order/OrderTypes.php');
require_once(plugin_dir_path(__FILE__) . '../../../rest_api/models/order/OrderPaymentMethods.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/PriceUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/UserManagement.php');
require_once(plugin_dir_path(__FILE__) . '../../../services/PrintNodeService.php');


use com\sakuraplugins\appetit\rest_api\models\OrderPaymentStatus;
use com\sakuraplugins\appetit\rest_api\models\OrderStatus;
use com\sakuraplugins\appetit\rest_api\models\OrderTypes;
use com\sakuraplugins\appetit\rest_api\models\OrderPaymentMethods;
use com\sakuraplugins\appetit\utils\PriceUtil;
use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\UserManagement;
use com\sakuraplugins\appetit\services\PrintNodeService;

class OrdersManagement {
    function render(): void {
        ?>
            <textarea id="appetit_data" style="display: none;"><?=  json_encode($this->_get_data()) ?></textarea>
            <div class="container-fluid mt_20">
                <div class="row">
                    <div class="col-md-12">
                        <?php $this->renderNavs() ?>
                        <?php $this->renderContent() ?>
                    </div>
                </div>
            </div>
            <?php $this->_manageAlerts(); ?>
        <?php
    }

    private function renderNavs() {
        ?>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link top_nav_link nav_link_live_orders active" id="live_orders-tab" data-toggle="tab" href="#live_orders" 
                    role="tab" aria-controls="live_orders" aria-selected="true">
                    <?= esc_html__('Live orders', 'instafood'); ?>
                    <span class="order_info"></span>
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link top_nav_link nav_link_orders" id="orders-tab" data-toggle="tab" href="#orders" role="tab" 
                    aria-controls="orders" aria-selected="false">
                    <?= esc_html__('Orders', 'instafood'); ?>
                    <span class="order_info"></span>
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link top_nav_link nav_link_waiter_calls" id="waiter_calls-tab" data-toggle="tab" href="#waiter_calls" role="tab" 
                    aria-controls="orders" aria-selected="false">
                    <?= esc_html__('Waiter calls', 'instafood'); ?>
                    <span class="order_info"></span>
                </a>
            </li>
        </ul>
        <?php
    }

    private function renderContent() {
        ?>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="live_orders" role="tabpanel" aria-labelledby="live_orders-tab">
                <div class="orders_loading mt_20"><?= esc_html__("Loading...", 'instafood'); ?></div>
                <div class="orders_container_ui orders_tab_content">
                    <div class="live_orders_ui">
                        <?php $this->_tableHelper() ?>
                    </div>
                </div>
                <div class="not_found"><?= esc_html__("No new orders found", 'instafood'); ?></div>
            </div>
            
            <div class="tab-pane fade" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                <?php $this->_renderFilters(); ?>
                
                <div class="orders_loading mt_20"><?= esc_html__("Loading...", 'instafood'); ?></div>
                <div class="orders_container_ui orders_tab_content">
                    <div class="orders_ui">
                        <?php $this->_tableHelper() ?>
                    </div>
                </div>
                <div class="order_pagination"></div>
                <div class="not_found"><?= esc_html__("No orders found", 'instafood'); ?></div>
            </div>

            <div class="tab-pane fade" id="waiter_calls" role="tabpanel" aria-labelledby="orders-tab">
                <div class="orders_loading mt_20"><?= esc_html__("Loading...", 'instafood'); ?></div>
                <div class="orders_container_ui orders_tab_content">
                    <div class="orders_ui">
                        <?php $this->_tableHelperWaiter() ?>
                    </div>
                </div>
                <div class="order_pagination"></div>
                <div class="not_found"><?= esc_html__("No waiter requests at this moment.", 'instafood'); ?></div>
            </div>

        </div>
        <?php
    }

    private function _tableHelper() {
        ?>
        <table class="table appetit_table">
            <thead>
                <tr>
                    <th scope="col o_id"><?= esc_html__('#ID', 'instafood'); ?></th>
                    <th class="o_type" scope="col o_type"><?= esc_html__('Type', 'instafood'); ?></th>
                    <th class="o_status" scope="col o_status"><?= esc_html__('Status', 'instafood'); ?></th>
                    <th class="o_date" scope="col o_date"><?= esc_html__('Date', 'instafood'); ?></th>
                    <th class="o_price" scope="col o_price"><?= esc_html__('Total', 'instafood'); ?></th>
                    <th class="o_actions" scope="col o_actions"><?= esc_html__('Actions', 'instafood'); ?></th>
                    <th class="o_edit" scope="col o_edit"><?= esc_html__('View', 'instafood'); ?></th>
                </tr>
            </thead>
            <tbody class="appetit_table_body">
            </tbody>
        </table>
        <?php
    }

    private function _tableHelperWaiter() {
        ?>
        <table class="table appetit_table_waiter">
            <thead>
                <tr>
                    <th scope="col o_table"><?= esc_html__('Table No', 'instafood'); ?></th>
                    <th scope="col o_date"><?= esc_html__('Time', 'instafood'); ?></th>
                    <th scope="col o_actions"><?= esc_html__('Actions', 'instafood'); ?></th>
                </tr>
            </thead>
            <tbody class="appetit_table_body">
            </tbody>
        </table>
        <?php
    }

    private function _get_data() {
        $invoicePageId = OptionUtil::getInstance()->getOption('invoice_page_id', '');
        $invoicePageUrl = get_permalink($invoicePageId);

        $printersResult = PrintNodeService::getInstance()->getAvailablePrinters(false);
        $hasPrinters = !isset($printersResult['error']) && is_array($printersResult) && sizeof($printersResult) > 0;

        return [
            'options' => [
                'rest_url' => esc_url_raw(rest_url() . 'instafood'),
                'order_types' => OrderTypes::getAll(),
                'order_types_mapped' => OrderTypes::getMappedToLabels(),
                'order_statuses' => OrderStatus::getAll(),
                'order_statuses_mapped' => OrderStatus::getMappedToLabels(),
                'order_statuses_colors' => OrderStatus::getMappedToColors(),
                'payment_statuses_mapped' => OrderPaymentStatus::getMappedToLabels(),
                'order_payment_methods_mapped' => OrderPaymentMethods::getMappedToLabels(),
                'price_display_template' => PriceUtil::getInstance()->getDisplayWithCurrency('<%= price %>'),
                'invoicePageUrl' => $invoicePageUrl ? $invoicePageUrl : '',
                'current_user_role' => UserManagement::getCurrentUserRole(),
                'printnode_api_key' => trim(OptionUtil::getInstance()->getOption('printnode_api_key', '')),
                'available_printers' => $printersResult
            ],
            'labels' => [
                'accept' => esc_html__('Accept', 'instafood'),
                'prepared' => esc_html__('Prepared', 'instafood'),
                'delivered' => esc_html__('Delivered', 'instafood'),
                'reject' => esc_html__('Reject', 'instafood'),
                'closed' => esc_html__('Closed', 'instafood'),
                'delete' => esc_html__('Permanently delete', 'instafood'),
                'order_rejected' => esc_html__('N/A', 'instafood'),
                'order_closed' => esc_html__('N/A', 'instafood'),
                'search_by_order_id' => esc_html__('search by order Id:', 'instafood'),
                'search_by_safematch_code' => esc_html__('search by safematch code:', 'instafood'),
                'order_single_title' => esc_html__('Order', 'instafood'),
                'order_single_items' => esc_html__('Items', 'instafood'),
                'order_single_details' => esc_html__('Details', 'instafood'),
                'order_single_actions' => esc_html__('Actions', 'instafood'),
                'order_single_choices' => esc_html__('Choices', 'instafood'),
                'order_single_customer_notes' => esc_html__('Customer notes', 'instafood'),
                'print_bill_btn' => esc_html__('Print bill', 'instafood'),
                'order_single_total' => esc_html__('Total', 'instafood'),
                'order_type_single' => esc_html__('Order type', 'instafood'),
                'close_waiter_call' => esc_html__('Close', 'instafood'),
                'order_status_single' => esc_html__('Order status', 'instafood'),
                'order_payment_method_single' => esc_html__('Payment method', 'instafood'),
                'order_payment_status_single' => esc_html__('Payment status', 'instafood'),
                'stripe_receipt' => esc_html__('Stripe receipt', 'instafood'),
                'order_date_single' => esc_html__('Date', 'instafood'),
                'order_customerAddress_single' => esc_html__('Delivery address', 'instafood'),
                'order_customerCity_single' => esc_html__('Delivery city', 'instafood'),
                'order_customerPhone_single' => esc_html__('Customer phone', 'instafood'),
                'order_customer_notes_single' => esc_html__('Delivery instructions ', 'instafood'),
                'order_customer_first_name' => esc_html__('Customer first name', 'instafood'),
                'order_pickup_day' => esc_html__('Pickup date', 'instafood'),
                'order_pickup_time' => esc_html__('Pickup date', 'instafood'),
                'order_safe_match_label' => esc_html__('Order Safe Match', 'instafood'),
                'order_table_label' => esc_html__('Table no', 'instafood'),
                'order_change_status_label' => esc_html__('Change order status', 'instafood'),
                'order_table_does_not_exist' => esc_html__('Payment cancelled by the user!', 'instafood'),
                'order_cpayment_cancelled_by_user' => esc_html__('Warning, the current table does not exist in the system.', 'instafood'),
                'order_delete_order' => esc_html__('Delete order', 'instafood'),
                'order_change_status_info' => esc_html__('changed status to', 'instafood'),
                'close_order_single' => esc_html__('Close', 'instafood'),
                'remote_printers_label' => esc_html__('Remote printers', 'instafood'),
                'select_remote_printer' => esc_html__('Select printer', 'instafood'),
                'print_remote' => esc_html__('Print remote', 'instafood'),
                'remote_printer_success' => esc_html__('Order sent to remote printer', 'instafood'),
            ]
        ];
    }

    private function _renderFilters() {
        ?>
        <div class="row mt_20 apt_filters">
            <div class="col-md-3 mb_10">
                <div class="filter_label mb_5"><?= esc_html__('Filter by order type', 'instafood') ?></div>
                <?php
                $types = OrderTypes::getMappedToLabels();
                ?>
                <select class="filter_by_order_type w-100">
                    <option value="false"><?= esc_html__('All', 'instafood') ?></option>
                    <?php foreach ($types as $key => $value): ?>
                        <option value="<?= esc_attr($key) ?>"><?= esc_html__($value) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 mb_10">
                <div class="filter_label mb_5"><?= esc_html__('Filter by status', 'instafood') ?></div>
                <?php
                $statuses = OrderStatus::getMappedToLabels();
                ?>
                <select class="filter_by_status w-100">
                    <option value="false"><?= esc_html__('All', 'instafood') ?></option>
                    <?php foreach ($statuses as $key => $value): ?>
                        <?php if ($key !== OrderStatus::NEW_ORDER): ?>
                        <option value="<?= esc_attr($key) ?>"><?= esc_html__($value) ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 mb_10">
                <div class="filter_label mb_5"><?= esc_html__('Search by order ID', 'instafood') ?></div>
                <div class="search_ui search_id_ui">
                    <input class="searchbox w-100 mr_5" placeholder="<?= esc_html__('order Id', 'instafood') ?>" type="number">
                    <button type="button" class="btn btn-light"><?= esc_html__('Search', 'instafood') ?></button>
                </div>
            </div>
            <div class="col-md-3 mb_10">
                <div class="filter_label mb_5"><?= esc_html__('Search by SafeMatch code', 'instafood') ?></div>
                <div class="search_ui search_safe_match_ui">
                    <input class="searchbox w-100 mr_5" placeholder="<?= esc_html__('safematch code', 'instafood') ?>" type="text">
                    <button type="button" class="btn btn-light"><?= esc_html__('Search', 'instafood') ?></button>
                </div>
            </div>
            <div class="col-md-12 mb_10 apt_filters_dynamic">
            </div>
        </div>
        <?php
    }

    private function _manageAlerts() {
        ?>
            <audio id="alert1">
                <source src="<?= esc_url(INSTAFOOD_QR_BASE_URL . '/assets/admin/sounds/alert1.ogg') ?>" type="audio/ogg">
                <source src="<?= esc_url(INSTAFOOD_QR_BASE_URL . '/assets/admin/sounds/alert1.mp3') ?>" type="audio/mpeg">
            </audio>
            <audio id="alert2">
                <source src="<?= esc_url(INSTAFOOD_QR_BASE_URL . '/assets/admin/sounds/alert2.ogg') ?>" type="audio/ogg">
                <source src="<?= esc_url(INSTAFOOD_QR_BASE_URL . '/assets/admin/sounds/alert2.mp3') ?>" type="audio/mpeg">
            </audio>   
        <?php
    }
}