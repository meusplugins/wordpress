<?php

class WPML_Page_Builders_Media_Shortcodes_Update_Factory extends WPML_Page_Builders_Media_Update_Factory {

	private $page_builder_config_import;

	private $element_factory;

	public function __construct( WPML_PB_Config_Import_Shortcode $page_builder_config_import ) {
		$this->page_builder_config_import = $page_builder_config_import;
	}

	public function create( $find_usage_instead_of_translate = false ) {
		$media_translate  = $this->get_media_translate( $find_usage_instead_of_translate );
		$media_shortcodes = new WPML_Page_Builders_Media_Shortcodes(
			$media_translate,
			$this->get_media_settings(),
			new \WPML\PB\Media\CssImages( $media_translate )
		);

		return new WPML_Page_Builders_Media_Shortcodes_Update(
			$this->get_element_factory(),
			$media_shortcodes,
			$find_usage_instead_of_translate
				? null
				: new WPML_Page_Builders_Media_Usage( $this->get_media_translate( $find_usage_instead_of_translate ), new WPML_Media_Usage_Factory() )
		);
	}

	public function get_media_settings() {
		$media_settings = $this->page_builder_config_import->get_media_settings();

		return defined( 'WPB_VC_VERSION' )
			? \WPML\Compatibility\WPBakery\DesignOptionsImages::addMediaSettings( $media_settings )
			: $media_settings;
	}

	private function get_element_factory() {
		global $sitepress;

		if ( ! $this->element_factory ) {
			$this->element_factory = new WPML_Translation_Element_Factory( $sitepress );
		}

		return $this->element_factory;
	}
}
