<?php
defined( 'ABSPATH' ) or die();

if ( ! function_exists( 'rsssl_get_passkey_login_enable_block_reason' ) ) {
	/**
	 * Return the blocker message when passkey login cannot be enabled.
	 *
	 * @param bool $rest_api_check Whether to perform a live REST API check when no result is cached.
	 */
	function rsssl_get_passkey_login_enable_block_reason( bool $rest_api_check = true ): string {
		if ( ! rsssl_get_option( 'ssl_enabled' ) || ! rsssl_get_option( 'site_has_ssl' ) ) {
			return __( "Passkeys require HTTPS to function. Please enable SSL on your site first.", "really-simple-ssl" );
		}

		if ( ! function_exists( 'rsssl_rest_api_accessible_for_logged_out_users' ) || ! rsssl_rest_api_accessible_for_logged_out_users( $rest_api_check ) ) {
			return __( "Passkey login requires the REST API to be accessible for logged-out users. Please ensure the REST API is not blocked.", "really-simple-ssl" );
		}

		return '';
	}
}
