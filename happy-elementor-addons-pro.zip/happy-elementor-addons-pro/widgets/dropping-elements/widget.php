<?php
    /**
 * Dropping Elements Widget.
 * @package Happy_Addons_Pro
 */
    namespace Happy_Addons_Pro\Widget;

    use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;

    defined( 'ABSPATH' ) || die();

    class Dropping_Elements extends Base {

    public function get_title() {
        return __( 'Dropping Elements', 'happy-addons-pro' );
    }

    public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/dropping-elements/';
    }

    public function get_icon() {
        return 'hm hm-weather-windy-rain';
    }

    public function get_keywords() {
        return ['dropping-elements', 'bouncing', 'bouncing ball', 'drop', 'elements', 'animation', 'falling', 'drop-animation', 'element-animation'];
    }

    protected function register_content_controls() {
        $this->__dropping_elements_content_controls();
        $this->__dropping_elements_settings_controls();
    }

    protected function __dropping_elements_content_controls() {

        $this->start_controls_section(
            '_section_dropping_elements',
            [
                'label' => __( 'Dropping Elements', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'label',
            [
                'label'       => __( 'Label', 'happy-addons-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Element',
                'label_block' => true,
                'dynamic'     => ['active' => true]
            ]
        );

        $repeater->add_responsive_control(
            'element_width',
            [
                'label'      => __( 'Width', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 30, 'max' => 300],
                    '%'  => ['min' => 1, 'max' => 50]
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 100
                ],
                'selectors'  => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $repeater->add_responsive_control(
            'element_height',
            [
                'label'      => __( 'Height', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 30, 'max' => 300],
                    '%'  => ['min' => 1, 'max' => 50]
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 100
                ],
                'selectors'  => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $repeater->add_responsive_control(
            'pos_x',
            [
                'label'      => __( 'Horizontal Position (X)', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 2000],
                    '%'  => ['min' => 0, 'max' => 100]
                ],
                'default'    => [
                    'unit' => '%'
                ],
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $repeater->add_responsive_control(
            'pos_y',
            [
                'label'      => __( 'Vertical Position (Y)', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 2000],
                    '%'  => ['min' => 0, 'max' => 100]
                ],
                'default'    => [
                    'unit' => '%'
                ],
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $repeater->add_responsive_control(
            'rotation',
            [
                'label'   => __( 'Rotation', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SLIDER,
                'range'   => [
                    'px' => ['min' => -360, 'max' => 360, 'step' => 1]
                ],
                'default' => [
                    'size' => 0
                ],
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $repeater->add_responsive_control(
            'element_padding',
            [
                'label'      => __( 'Padding', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $repeater->add_control(
            'element_bg_color',
            [
                'label'   => __( 'Background Color', 'happy-addons-pro' ),
                'type'    => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-dropping-element {{CURRENT_ITEM}}' => 'background-color: {{VALUE}}'
                ],
                'render_type' => 'template',
            ]
        );

        $repeater->add_control(
            'follow_bg_color',
            [
                'label'   => __( 'Follow Background Color', 'happy-addons-pro' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#6478ff'
            ]
        );

        $default_sizes = [
            90, 120, 100, 140, 110, 95, 200,
            115, 105, 180, 200, 85, 100, 110
        ];

        $default_bg_colors = [
            '#7D4BC0', '#3C862A', '#404CD6', '#21A98E',
            '#F6B22B', '#FF6C45', '#E84393', '#00B894',
            '#6C5CE7', '#FD79A8', '#0984E3', '#FFEAA7',
            '#7D4BC0', '#3C862A', '#404CD6', '#21A98E',
            '#F6B22B', '#FF6C45', '#E84393', '#00B894'
        ];

        $default_elements = [];

        for ( $i = 0; $i < 11; $i++ ) {
            $default_elements[] = [
                'label'                 => 'Element ' . ( $i + 1 ),
                'element_width'         => [
                    'unit' => 'px',
                    'size' => $default_sizes[$i]
                ],
                'element_height'        => [
                    'unit' => 'px',
                    'size' => $default_sizes[$i]
                ],
                'rotation'              => [
                    'size' => 0
                ],
                'element_bg_background' => 'classic',
                'element_bg_color'      => $default_bg_colors[$i],
                'follow_bg_color'       => '#6478ff',
                'style_transfer'        => true,
                'frontend_available'    => true
            ];
        }

        $this->add_control(
            'elements',
            [
                'show_label'  => false,
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ label }}}',
                'default'     => $default_elements
            ]
        );

        $this->add_control(
            'rpt_magic',
            [
                'label'        => __( 'none', 'happy-addons-pro' ),
                'type'         => Controls_Manager::HIDDEN,
                'default'      => 'retaeper',
                'prefix_class' => 'cigam-'
            ]
        );

        $this->end_controls_section();
    }

    protected function __dropping_elements_settings_controls() {

        // Animation Mode
        $this->start_controls_section(
            '_section_animation_mode',
            [
                'label' => __( 'Animation Mode', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control(
            'trigger_mode',
            [
                'label'   => __( 'Trigger Mode', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'scroll',
                'options' => [
                    'scroll' => __( 'On Scrolling', 'happy-addons-pro' ),
                    'appearing' => __( 'On Appearing', 'happy-addons-pro' ),
                    'load'   => __( 'On Page Load', 'happy-addons-pro' )
                ]
            ]
        );

        $this->add_control(
            'trigger_position',
            [
                'label'       => __( 'Trigger Position', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SELECT,
                'default'     => 'top-top',
                'options'     => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'description' => __(
                    'First value is the element position, second is the viewport position.',
                    'happy-addons-pro'
                ),
                'condition'   => [
                    'trigger_mode' => ['scroll', 'appearing'],
                ]
            ]
        );

        $this->add_control(
            'custom_offset',
            [
                'label'       => __( 'Custom Offset (px)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => 0,
                'min'         => -1000,
                'max'         => 2500,
                'step'        => 1,
                'condition'   => [
                    'trigger_mode'     => 'scroll',
                    'trigger_position' => 'custom'
                ],
                'description' => __( 'Offset from the trigger position to start the animation. Positive = start earlier, Negative = start later.', 'happy-addons-pro' )
            ]
        );

        $this->end_controls_section();

        // Physics Settings
        $this->start_controls_section(
            '_section_physics',
            [
                'label' => __( 'Physics Settings', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_responsive_control(
            'bounce_delay',
            [
                'label'       => __( 'Bounce Delay (s)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0.01, 'max' => 100, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.1
                ],
                'description' => __( 'Time gap between each element starting to drop. Lower = all drop together, higher = one-by-one cascade.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'drop_duration',
            [
                'label'       => __( 'Drop Duration (s)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 10, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 1.2
                ],
                'description' => __( 'How long the drop element takes. Lower = faster drop, higher = slower drop.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'drop_duration_variance',
            [
                'label'       => __( 'Duration Variance', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 10, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.9
                ],
                'description' => __( 'Adds randomness to the drop duration. Higher = more random (some elements drop faster, some slower).', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'scale_bounce',
            [
                'label'       => __( 'Scale Bounce', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 5, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.88
                ],
                'description' => __( 'How much the element bounces/scales when it hits the ground. Lower = less bounce, higher = more bounce.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'scale_bounce_variance',
            [
                'label'       => __( 'Scale Variance', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 10, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.25
                ],
                'description' => __( 'Adds randomness to the bounce effect. Higher = more random (some elements bounce more, some less).', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->end_controls_section();

        // Mouse Follow
        $this->start_controls_section(
            '_section_mouse_follow',
            [
                'label' => __( 'Mouse Follow', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_responsive_control(
            'enable_mouse_follow',
            [
                'label'        => __( 'Enable Mouse Follow', 'happy-addons-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'happy-addons-pro' ),
                'label_off'    => __( 'No', 'happy-addons-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'follow_strength',
            [
                'label'       => __( 'Follow Strength', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.001]
                ],
                'default'     => [
                    'size' => 0.01
                ],
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Controls how closely elements follow the cursor. Lower = more lag, higher = less lag.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'follow_strength_variance',
            [
                'label'       => __( 'Strength Variance', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.001]
                ],
                'default'     => [
                    'size' => 0.01
                ],
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Adds variation to follow strength. Higher = more randomness.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'follow_damping',
            [
                'label'       => __( 'Follow Damping', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.35
                ],
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Controls how closely elements follow the cursor. Lower = more lag, higher = less lag.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'follow_damping_variance',
            [
                'label'       => __( 'Damping Variance', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 2, 'step' => 0.01]
                ],
                'default'     => [
                    'size' => 0.05
                ],
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Adds variation to damping. Higher = more randomness.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'nearest_count',
            [
                'label'       => __( 'Nearest Count', 'happy-addons-pro' ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => 1,
                'min'         => 1,
                'max'         => 10,
                'step'        => 1,
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Number of nearest elements affected by mouse follow.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'follow_max_distance',
            [
                'label'       => __( 'Max Distance (px)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 1, 'max' => 1000, 'step' => 1]
                ],
                'default'     => [
                    'size' => 300
                ],
                'condition'   => [
                    'enable_mouse_follow' => 'yes'
                ],
                'description' => __( 'Maximum distance within which elements respond to the cursor.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->end_controls_section();

        // Overlap Prevention
        $this->start_controls_section(
            '_section_overlap_prevention',
            [
                'label' => __( 'Overlap Prevention', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_responsive_control(
            'prevent_overlap',
            [
                'label'        => __( 'Prevent Overlap', 'happy-addons-pro' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'happy-addons-pro' ),
                'label_off'    => __( 'No', 'happy-addons-pro' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'description'  => __( 'Prevents elements from overlapping each other when they drop.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->add_responsive_control(
            'overlap_padding',
            [
                'label'       => __( 'Overlap Padding (px)', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'range'       => [
                    'px' => ['min' => 0, 'max' => 150, 'step' => 1]
                ],
                'default'     => [
                    'size' => 8
                ],
                'condition'   => [
                    'prevent_overlap' => 'yes'
                ],
                'description' => __( 'Minimum distance to maintain between elements when preventing overlap.', 'happy-addons-pro' ),
                'frontend_available' => true,
                'render_type'        => 'template'
            ]
        );

        $this->end_controls_section();
    }

    protected function register_style_controls() {
        $this->__dropping_elements_style_controls();
    }

    protected function __dropping_elements_style_controls() {

        $this->start_controls_section(
            '_section_element_style_defaults',
            [
                'label' => __( 'Element Style Defaults', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'           => 'element_typography',
                'selector'       => '{{WRAPPER}} .ha-dropping-element',
                'fields_options' => [
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 12
                        ]
                    ]
                ]
            ]
        );

        $this->add_control(
            'element_typography_color',
            [
                'label'     => __( 'Label Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-dropping-element' => 'color: {{VALUE}}'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'           => 'element_border',
                'selector'       => '{{WRAPPER}} .ha-dropping-element',
                'style_transfer' => true,
                'fields_options' => [
                    'border' => [
                        'default' => 'none'
                    ]
                ]
            ]
        );

        $this->add_responsive_control(
            'default_border_radius',
            [
                'label'      => __( 'Border Radius', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default'    => [
                    'top'      => 100,
                    'right'    => 100,
                    'bottom'   => 100,
                    'left'     => 100,
                    'unit'     => 'px',
                    'isLinked' => true
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-dropping-element' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_control(
            'default_bg_color',
            [
                'label'   => __( 'Default Background Color', 'happy-addons-pro' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#13131317'
            ]
        );

        $this->add_control(
            'default_bg_opacity',
            [
                'label'   => __( 'Background Opacity', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SLIDER,
                'range'   => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01]
                ],
                'default' => [
                    'size' => 1
                ]
            ]
        );

        $this->add_control(
            'default_follow_bg_color',
            [
                'label' => __( 'Mouse Follow BG Color', 'happy-addons-pro' ),
                'type'  => Controls_Manager::COLOR,
                'default' => '#6478ff'
            ]
        );

        $this->add_control(
            'default_follow_bg_opacity',
            [
                'label' => __( 'Follow BG Opacity', 'happy-addons-pro' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01]
                ],
                'default' => [
                    'size' => 0.25
                ]
            ]
        );

        $this->add_control(
            'default_glow_color',
            [
                'label' => __( 'Glow Color', 'happy-addons-pro' ),
                'type'  => Controls_Manager::COLOR,
                'default' => '#FF48F7'
            ]
        );

        $this->add_control(
            'default_glow_opacity',
            [
                'label' => __( 'Glow Opacity', 'happy-addons-pro' ),
                'type'  => Controls_Manager::SLIDER,
                'range' => [
                    'px' => ['min' => 0, 'max' => 1, 'step' => 0.01]
                ],
                'default' => [
                    'size' => 0.02
                ]
            ]
        );

        $this->add_control(
            'default_element_padding',
            [
                'label'      => __( 'Element Padding', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-dropping-element' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'           => 'container_background',
                'label'          => __( 'Background', 'happy-addons-pro' ),
                'types'          => ['classic', 'gradient'],
                'selector'       => '{{WRAPPER}} .ha-dropping-elements-container',
                'style_transfer' => true
            ]
        );

        $this->add_responsive_control(
            'container_min_height',
            [
                'label'      => __( 'Container Min Height', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range'      => [
                    'px' => ['min' => 100, 'max' => 3000],
                    'vh' => ['min' => 10, 'max' => 100]
                ],
                'default'    => [
                    'unit' => 'vh',
                    'size' => 100
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-dropping-elements-container' => 'min-height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'container_width',
            [
                'label'      => __( 'Container Width', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => ['min' => 0, 'max' => 3000],
                    '%'  => ['min' => 0, 'max' => 100]
                ],
                'default'    => [
                    'unit' => '%',
                    'size' => 100
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-dropping-elements-container' => 'width: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $elements_data = [];

        $extract_responsive_slider = function ( $element, $key, $default_unit = '%' ) {
            $result = [];
            $devices = [ '' => '', 'Tablet' => '_tablet', 'Mobile' => '_mobile' ];
            foreach ( $devices as $label => $sfx ) {
                $k = $key . $sfx;
                $size = null;
                $unit = $default_unit;
                if ( isset( $element[ $k ] ) && is_array( $element[ $k ] ) ) {
                    $size = isset( $element[ $k ]['size'] ) && $element[ $k ]['size'] !== '' ? floatval( $element[ $k ]['size'] ) : null;
                    $unit = ! empty( $element[ $k ]['unit'] ) ? $element[ $k ]['unit'] : $default_unit;
                }
                $result[ $label ] = [ 'size' => $size, 'unit' => $unit ];
            }
            return $result;
        };

        if ( !empty( $settings['elements'] ) && is_array( $settings['elements'] ) ) {
            foreach ( $settings['elements'] as $element ) {
                $width_unit  = !empty( $element['element_width']['unit'] ) ? $element['element_width']['unit'] : 'px';
                $width_value = !empty( $element['element_width']['size'] ) ? floatval( $element['element_width']['size'] ) : 100;

                $height_unit  = !empty( $element['element_height']['unit'] ) ? $element['element_height']['unit'] : 'px';
                $height_value = !empty( $element['element_height']['size'] ) ? floatval( $element['element_height']['size'] ) : 100;

                $item_bg_color = ! empty( $element['element_bg_color'] ) ? sanitize_hex_color( $element['element_bg_color'] ) : '';
                if ( ! $item_bg_color && ! empty( $element['element_bg_color'] ) ) {
                    $item_bg_color = sanitize_hex_color( substr( $element['element_bg_color'], 0, 7 ) );
                }

                $pos_x   = $extract_responsive_slider( $element, 'pos_x', '%' );
                $pos_y   = $extract_responsive_slider( $element, 'pos_y', '%' );
                $rotation = $extract_responsive_slider( $element, 'rotation', 'px' );

                $elements_data[] = [
                    'label'          => sanitize_text_field( $element['label'] ),
                    'width'          => $width_value,
                    'widthUnit'      => sanitize_text_field( $width_unit ),
                    'height'         => $height_value,
                    'heightUnit'     => sanitize_text_field( $height_unit ),
                    'posX'           => $pos_x['']['size'],
                    'posXUnit'       => sanitize_text_field( $pos_x['']['unit'] ),
                    'posXTablet'     => $pos_x['Tablet']['size'],
                    'posXUnitTablet' => sanitize_text_field( $pos_x['Tablet']['unit'] ),
                    'posXMobile'     => $pos_x['Mobile']['size'],
                    'posXUnitMobile' => sanitize_text_field( $pos_x['Mobile']['unit'] ),
                    'posY'           => $pos_y['']['size'],
                    'posYUnit'       => sanitize_text_field( $pos_y['']['unit'] ),
                    'posYTablet'     => $pos_y['Tablet']['size'],
                    'posYUnitTablet' => sanitize_text_field( $pos_y['Tablet']['unit'] ),
                    'posYMobile'     => $pos_y['Mobile']['size'],
                    'posYUnitMobile' => sanitize_text_field( $pos_y['Mobile']['unit'] ),
                    'rotation'       => $rotation['']['size'],
                    'rotationTablet' => $rotation['Tablet']['size'],
                    'rotationMobile' => $rotation['Mobile']['size'],
                    'bgColor'        => $item_bg_color,
                    'followBgColor'  => !empty( $element['follow_bg_color'] ) ? sanitize_hex_color( $element['follow_bg_color'] ) : ''
                ];
            }
        }

        $default_bg_color = sanitize_hex_color( $settings['default_bg_color'] );
        if ( !$default_bg_color ) {
            $default_bg_color = sanitize_hex_color( substr( $settings['default_bg_color'], 0, 7 ) );
        }

        $bounce_delay_s        = $extract_responsive_slider( $settings, 'bounce_delay', 'px' );
        $drop_duration_s       = $extract_responsive_slider( $settings, 'drop_duration', 'px' );
        $drop_duration_var_s   = $extract_responsive_slider( $settings, 'drop_duration_variance', 'px' );
        $scale_bounce_s        = $extract_responsive_slider( $settings, 'scale_bounce', 'px' );
        $scale_bounce_var_s    = $extract_responsive_slider( $settings, 'scale_bounce_variance', 'px' );

        $extract_responsive_value = function ( $settings, $key ) {
            return [
                ''       => isset( $settings[ $key ] ) ? $settings[ $key ] : null,
                'Tablet' => isset( $settings[ $key . '_tablet' ] ) ? $settings[ $key . '_tablet' ] : null,
                'Mobile' => isset( $settings[ $key . '_mobile' ] ) ? $settings[ $key . '_mobile' ] : null,
            ];
        };

        $enable_mouse_follow_v = $extract_responsive_value( $settings, 'enable_mouse_follow' );
        $follow_strength_s     = $extract_responsive_slider( $settings, 'follow_strength', 'px' );
        $follow_strength_var_s = $extract_responsive_slider( $settings, 'follow_strength_variance', 'px' );
        $follow_damping_s      = $extract_responsive_slider( $settings, 'follow_damping', 'px' );
        $follow_damping_var_s  = $extract_responsive_slider( $settings, 'follow_damping_variance', 'px' );
        $nearest_count_v       = $extract_responsive_value( $settings, 'nearest_count' );
        $follow_max_dist_s     = $extract_responsive_slider( $settings, 'follow_max_distance', 'px' );
        $prevent_overlap_v     = $extract_responsive_value( $settings, 'prevent_overlap' );
        $overlap_padding_s     = $extract_responsive_slider( $settings, 'overlap_padding', 'px' );

        $drop_settings = [
            'triggerMode'            => sanitize_text_field( $settings['trigger_mode'] ),
            'triggerPosition'        => sanitize_text_field( $settings['trigger_position'] ),
            'customOffset'           => intval( $settings['custom_offset'] ),
            'bounceDelay'            => $bounce_delay_s['']['size'] ?? 0.1,
            'bounceDelayTablet'      => $bounce_delay_s['Tablet']['size'],
            'bounceDelayMobile'      => $bounce_delay_s['Mobile']['size'],
            'dropDuration'           => $drop_duration_s['']['size'] ?? 1.2,
            'dropDurationTablet'     => $drop_duration_s['Tablet']['size'],
            'dropDurationMobile'     => $drop_duration_s['Mobile']['size'],
            'dropDurationVar'        => $drop_duration_var_s['']['size'] ?? 0.9,
            'dropDurationVarTablet'  => $drop_duration_var_s['Tablet']['size'],
            'dropDurationVarMobile'  => $drop_duration_var_s['Mobile']['size'],
            'scaleBounce'            => $scale_bounce_s['']['size'] ?? 0.88,
            'scaleBounceTablet'      => $scale_bounce_s['Tablet']['size'],
            'scaleBounceMobile'      => $scale_bounce_s['Mobile']['size'],
            'scaleBounceVar'         => $scale_bounce_var_s['']['size'] ?? 0.25,
            'scaleBounceVarTablet'   => $scale_bounce_var_s['Tablet']['size'],
            'scaleBounceVarMobile'   => $scale_bounce_var_s['Mobile']['size'],
            'enableMouseFollow'      => $enable_mouse_follow_v[''] === 'yes',
            'enableMouseFollowTablet'=> $enable_mouse_follow_v['Tablet'] !== null ? ( $enable_mouse_follow_v['Tablet'] === 'yes' ) : null,
            'enableMouseFollowMobile'=> $enable_mouse_follow_v['Mobile'] !== null ? ( $enable_mouse_follow_v['Mobile'] === 'yes' ) : null,
            'followStrength'         => $follow_strength_s['']['size'] ?? 0.01,
            'followStrengthTablet'   => $follow_strength_s['Tablet']['size'],
            'followStrengthMobile'   => $follow_strength_s['Mobile']['size'],
            'followStrengthVar'      => $follow_strength_var_s['']['size'] ?? 0.01,
            'followStrengthVarTablet'=> $follow_strength_var_s['Tablet']['size'],
            'followStrengthVarMobile'=> $follow_strength_var_s['Mobile']['size'],
            'followDamping'          => $follow_damping_s['']['size'] ?? 0.35,
            'followDampingTablet'    => $follow_damping_s['Tablet']['size'],
            'followDampingMobile'    => $follow_damping_s['Mobile']['size'],
            'followDampingVar'       => $follow_damping_var_s['']['size'] ?? 0.05,
            'followDampingVarTablet' => $follow_damping_var_s['Tablet']['size'],
            'followDampingVarMobile' => $follow_damping_var_s['Mobile']['size'],
            'nearestCount'           => $nearest_count_v[''] !== null ? absint( $nearest_count_v[''] ) : 1,
            'nearestCountTablet'     => $nearest_count_v['Tablet'] !== null ? absint( $nearest_count_v['Tablet'] ) : null,
            'nearestCountMobile'     => $nearest_count_v['Mobile'] !== null ? absint( $nearest_count_v['Mobile'] ) : null,
            'followMaxDist'          => $follow_max_dist_s['']['size'] ?? 300,
            'followMaxDistTablet'    => $follow_max_dist_s['Tablet']['size'],
            'followMaxDistMobile'    => $follow_max_dist_s['Mobile']['size'],
            'preventOverlap'         => $prevent_overlap_v[''] === 'yes',
            'preventOverlapTablet'   => $prevent_overlap_v['Tablet'] !== null ? ( $prevent_overlap_v['Tablet'] === 'yes' ) : null,
            'preventOverlapMobile'   => $prevent_overlap_v['Mobile'] !== null ? ( $prevent_overlap_v['Mobile'] === 'yes' ) : null,
            'overlapPadding'         => $overlap_padding_s['']['size'] ?? 8,
            'overlapPaddingTablet'   => $overlap_padding_s['Tablet']['size'],
            'overlapPaddingMobile'   => $overlap_padding_s['Mobile']['size'],
            'defaultBgColor'         => $default_bg_color,
            'defaultBgOpacity'       => floatval( $settings['default_bg_opacity']['size'] ),
            'defaultFollowBg'        => sanitize_hex_color( $settings['default_follow_bg_color'] ),
            'defaultFollowBgOpacity' => floatval( $settings['default_follow_bg_opacity']['size'] ),
            'defaultGlowColor'       => sanitize_hex_color( $settings['default_glow_color'] ),
            'defaultGlowOpacity'     => floatval( $settings['default_glow_opacity']['size'] ),
            'elements'               => $elements_data
        ];

        $this->add_render_attribute( 'wrapper', [
            'class'              => 'ha-dropping-elements-wrapper',
            'data-drop-settings' => wp_json_encode( $drop_settings )
        ] );

        ?>
        <div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
            <div class="ha-dropping-elements-container">
                <?php foreach ( $settings['elements'] as $index => $element ):
                                $repeater_id = !empty( $element['_id'] ) ? $element['_id'] : $index;
                        ?>
                    <div class="ha-dropping-element elementor-repeater-item-<?php echo esc_attr( $repeater_id ); ?>"
                         data-index="<?php echo esc_attr( $index ); ?>">
                        <?php echo esc_html( $element['label'] ); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
            }

        }
