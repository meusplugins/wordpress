import EventBus, { Events, Event } from '../events/EventBus';

let instance;
const instanceKey = '2738_KSJK';

class LiveOrdersTopNav {

    _ui;
    _onLiveOrdersCount;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._ui = jQuery('.nav_link_live_orders');

        this._onLiveOrdersCount = new Event(Events.LIVE_ORDERS_COUNT, ({ count }) => {
            this._handleChange(count);
        });
        EventBus.getInstance().registerEvent(this._onLiveOrdersCount);
    }
    
    _handleChange(count) {
        if (count !== 0) {
            this._ui.find('.order_info').html(count);
            this._ui.find('.order_info').css('display', 'flex');
            return;
        }
        this._ui.find('.order_info').hide();
    }

    static getInstance() {
        if (!instance) {
            instance = new LiveOrdersTopNav(instanceKey);
        }
        return instance;
    }
}
export default LiveOrdersTopNav;