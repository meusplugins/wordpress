import QuantityComponent from './QuantityComponent';
import LanguageUtils from '../utils/LanguageUtils';
import DataUtils from '../utils/DataUtils';

export class CartAddMode {
    static UPDATE = 'UPDATE';
    static ADD = 'ADD';
}
class CartAddNav {

    _quantity = 1;
    _parent_ui = null;
    _ui = null;
    _mode;
    _updatedQuantity = 1;
    _canUpdate = true;
    _addUpdateBtn = null;

    constructor(onSelect, mode = CartAddMode.ADD, quantity = 1) {
        this._onSelect = onSelect;
        this._mode = mode;
        this._quantity = quantity;
        this._updatedQuantity = quantity;
    }

    render(parent_ui) {
        const disabled_add_to_cart = DataUtils.getInstance().getOption('disabled_add_to_cart');
        const _this = this;
        this._parent_ui = parent_ui;
        const template = `
        <div class="screen_bottom_controls" style="${ disabled_add_to_cart === 'ON' ? `display: none;` : '' }">
            <div class="udapte_controls mr_20">
            </div>
        </div>
        `;

        const btnLabel = this._mode === CartAddMode.ADD ? LanguageUtils.getInstance().getLabel('product_add_to_cart') : LanguageUtils.getInstance().getLabel('product_udapte_cart');
        this._addUpdateBtn = jQuery(`<a href="#" class="apt_button primary add_to_cart_btn">${btnLabel}</a>`);

        this._ui = jQuery(template);
        this._ui.appendTo(this._parent_ui);
        this._addUpdateBtn.appendTo(this._ui);

        const quantityComponent = new QuantityComponent(this._quantity, this._mode === CartAddMode.UPDATE ? 0 : 1, quantity => {
            _this._updatedQuantity = quantity;
        });
        quantityComponent.render(this._ui.find('.udapte_controls'));

        this._addUpdateBtn.click(function(event) {
            event.preventDefault();
            if (_this._canUpdate && _.isFunction(_this._onSelect)) {
                _this._onSelect(_this._updatedQuantity);
            }
        })
    }

    setCanUpdate(val) {
        const disabled_add_to_cart = DataUtils.getInstance().getOption('disabled_add_to_cart');
        if (disabled_add_to_cart === 'ON') {
            this._ui.hide();
            return;
        }
        this._canUpdate = val;
        if (!this._canUpdate) {
            this._ui.hide();
            if (!this._addUpdateBtn.hasClass('inactive')) {
                this._addUpdateBtn.addClass('inactive');
            }
        } else {
            this._ui.show();
            if (this._addUpdateBtn.hasClass('inactive')) {
                this._addUpdateBtn.removeClass('inactive');
            }
        }
    }

    show() {
        const disabled_add_to_cart = DataUtils.getInstance().getOption('disabled_add_to_cart');
        if (disabled_add_to_cart === 'ON') {
            return;
        }

        this._ui.css('opacity', 1);
    }

    hide() {
        this._ui.css('opacity', 0);
    }

    remove() {
        this._ui.remove();
    }
}
export default CartAddNav;