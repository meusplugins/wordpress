<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');
require_once(plugin_dir_path(__FILE__) . '../guards/Guards.php');
require_once(plugin_dir_path(__FILE__) . '../models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . '../../services/StripeService.php');

use \com\sakuraplugins\appetit\rest_api\guards\Guards;
use \com\sakuraplugins\appetit\rest_api\models\Order;
use com\sakuraplugins\appetit\services\StripeService;

class StripeWebhookController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/stripe-webhook', array(
            array(
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'handleRequest'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * handle Stripe
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function handleRequest(\WP_REST_Request $request) {

        $stripeService = new StripeService();
        $stripeService->handleIncommingWebhook();
        if ($stripeService->hasErrors()) {
            return new \WP_REST_Response(null, 400); 
        }

        if ($stripeService->getOrderPaymentStatus()) {
            $orderId = $stripeService->getCurrentOrderId();
            $order = new Order();
            $order->findOne($orderId);
            $order->setStatusPaymentStatus($stripeService->getOrderPaymentStatus());
            $order->setStripeReceiptUrl($stripeService->get_receipt_url());
        }
        
        return ResponseHelper::respond([]);
    }
    
}
?>