<?php
/**
 * Supplies the Elementor V4 (Atomic) implementations of the Pro features.
 *
 * The free plugin lists the Atomic features and loads the ones that arrive
 * through the "happyaddons_atomic_features" filter.
 *
 * @package Happy_Addons_Pro
 */
namespace Happy_Addons_Pro\Classes;

defined( 'ABSPATH' ) || die();

class Atomic_Features {

	public static function init() {
		add_filter( 'happyaddons_atomic_features', [ __CLASS__, 'add_features' ] );
		add_action( 'init', [ __CLASS__, 'register_assets' ], 20 );
	}

	public static function add_features( $features ) {
		$features = is_array( $features ) ? $features : [];

		// Runs before include_on_init() loads the extension helpers.
		include_once HAPPY_ADDONS_PRO_DIR_PATH . 'inc/functions-extensions.php';

		if ( hapro_is_image_masking_enabled() ) {
			$features['image-masking'] = [
				'title'          => __( 'Image Masking', 'happy-addons-pro' ),
				'icon'           => 'hm hm-image-masking',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => false,
				'is_extension'   => true,
				'path'          => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/image-masking.php',
				'fqcn'           => '\Happy_Addons_Pro\Extensions\Atomic\Image_Masking',
				'script'         => 'happy-atomic-image-masking',
				'editor_preview' => true,
				'prehide'        => false,
			];
		}

		return $features;
	}

	/**
	 * Editor preview script; the frontend mask is pure CSS from PHP.
	 */
	public static function register_assets() {
		$suffix = function_exists( 'ha_is_script_debug_enabled' ) && ha_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'happy-atomic-image-masking',
			HAPPY_ADDONS_PRO_ASSETS . 'js/happy-atomic-image-masking' . $suffix . 'js',
			[ 'happy-elementor-addons-atomic' ],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}
}
