<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;


class TermsUtils {
    public function set_post_terms(int $postId, array $terms_ids, string $taxonomy): void {
        if (isset($terms_ids) && is_array($terms_ids) && sizeof($terms_ids) > 0) {
            $terms_to_push = [];
            foreach ($terms_ids as $term_id) {
                $term = get_term((int) $term_id, $taxonomy);
                if ($term && !is_wp_error($term)) {
                    if (isset($term->slug)) {
                        array_push($terms_to_push, $term->slug);
                    }
                }
            }
            if (sizeof($terms_to_push) > 0) {
                wp_set_post_terms($postId, $terms_to_push, $taxonomy, false);
            }
        }
    }

    public function removeAllPostTerms(int $postId, string $taxonomy): void {
        $existingPostTerms = get_the_terms($postId, $taxonomy);
        if (isset($existingPostTerms) && is_array($existingPostTerms)) {
            wp_remove_object_terms($postId, $existingPostTerms, $taxonomy);
        }
    }

    
}
?>