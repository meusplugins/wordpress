<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');

use com\sakuraplugins\appetit\utils\OptionUtil;

class PrintJobResult {
    public $resultRaw;
    public $status_code;
    public $parsedResult;

    function __construct($result, $status_code, $parsedResult) {
        $this->resultRaw = $result;
        $this->status_code = $status_code;
        $this->parsedResult = $parsedResult;
    }
}

class PrintNodeService {
    private static $instance = null;
    protected $ch;
    protected $apiRoot = 'https://api.printnode.com';
    protected $apiKey = '';
    protected $printers = [];
    const PRINT_NODE_PRINTERS_META_KEY = 'PRINT_NODE_PRINTERS_META_KEY';

    function __construct() {
        $this->apiKey = trim(OptionUtil::getInstance()->getOption('printnode_api_key', ''));
    }

    public function getApiKey(): string {
        return $this->apiKey;
    }

    public function getAvailablePrinters(bool $useNetwork = false) {
        if (!$this->canUsePrintNode()) {
            return [];
        }
        if (!$useNetwork) {
            $this->printers = get_option(self::PRINT_NODE_PRINTERS_META_KEY, []);
            return $this->printers;
        }
        $this->initCh();
        curl_setopt($this->ch, CURLOPT_URL, $this->apiRoot . '/printers');
        $result = curl_exec($this->ch);
        $status_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
        $parsedResult = $this->parseCurlResponse($result, $this->ch);
        curl_close($this->ch);
        if ($status_code !== 200) {
            update_option(self::PRINT_NODE_PRINTERS_META_KEY, [], false);
            return $this->buildError($parsedResult);
        }
        if ($parsedResult['body'] && is_array($parsedResult['body'])) {
            update_option(self::PRINT_NODE_PRINTERS_META_KEY, $parsedResult['body'], false);
            $this->printers = $parsedResult['body'] ?? [];
        }
        return $this->printers;
    }

    public function printOrder(array $body): PrintJobResult {
        if (!$this->canUsePrintNode()) {
            return [];
        }

        $this->initCh();
        curl_setopt($this->ch, CURLOPT_POST, true);
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, json_encode($body));
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($this->ch, CURLOPT_VERBOSE, 1);
        curl_setopt($this->ch, CURLOPT_URL, $this->apiRoot . '/printjobs');

        $result = curl_exec($this->ch);
        $status_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
        $parsedResult = $this->parseCurlResponse($result, $this->ch);
        curl_close($this->ch);

        return new PrintJobResult($result, $status_code, $parsedResult);
    }

    public function canUsePrintNode(): bool {
        return $this->canUseCurl() && $this->hasPrintNodeApiKey();
    }

    private function canUseCurl(): bool {
        return function_exists('curl_init') && function_exists('curl_exec');
    }

    public function hasPrintNodeApiKey(): bool {
        return $this->apiKey !== '';
    }

    protected function initCh() {
        $this->ch = curl_init();
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_HEADER, true);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($this->ch, CURLOPT_USERPWD, $this->apiKey . ":");
        return $this->ch;
    }

    protected function parseCurlResponse($result, $ch) {
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header_text = substr($result, 0, $header_size);
        $body = substr($result, $header_size);
        $json = json_decode($body, TRUE);

        return array(
            'body' => $json,
            'headers' => $header_text,
            'error' => false
        );
    }

    protected function buildError($parsedResult) {
        return [
            'error' => [
                'code' => $parsedResult['body']['code'] ?? '400',
                'message' => $parsedResult['body']['message'] ?? 'Unexpected PrintNode Error',
            ]
        ];
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new PrintNodeService();
        }
        return self::$instance;
    } 
}
?>