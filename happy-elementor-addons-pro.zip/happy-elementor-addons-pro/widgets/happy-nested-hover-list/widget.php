<?php

/**
 * Hover Accordion widget class
 *
 * @package Happy_Addons_Pro
 */

namespace Happy_Addons_Pro\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Modules\NestedElements\Base\Widget_Nested_Base;
use Elementor\Modules\NestedElements\Controls\Control_Nested_Repeater;
use Elementor\Repeater;
use Elementor\Utils;

if (! defined('ABSPATH')) {
	exit;
}

if (! class_exists('Elementor\Modules\NestedElements\Base\Widget_Nested_Base')) {
	return;
}

class Happy_Nested_Hover_List extends Widget_Nested_Base {

	private $hover_item_settings = [];

	public function get_name(): string {
		return 'ha-happy-nested-hover-list';
	}

	public function get_title(): string {
		return esc_html__('Hover Accordion', 'happy-addons-pro');
	}

	public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/hover-accordion/';
    }

	public function get_icon(): string {
		return 'hm hm-list';
	}

	public function get_keywords(): array {
		return ['nested', 'hover', 'list', 'services', 'creative', 'accordion', 'happy'];
	}

	public function get_categories(): array {
		return ['happy_addons_pro_category'];
	}

	public function get_style_depends(): array {
		return ['happy-nested-hover-list'];
	}

	protected function get_default_children_title() {
		return esc_html__('Item #%d', 'happy-addons-pro');
	}

	protected function get_default_repeater_title_setting_key(): string {
		return 'item_title';
	}

	protected function get_default_children_elements(): array {
		return [
			$this->item_content_container(1),
			$this->item_content_container(2),
			$this->item_content_container(3),
			$this->item_content_container(4),
		];
	}

	protected function item_content_container(int $index) {
		return [
			'elType'   => 'container',
			'settings' => [
				'_title'        => sprintf(
					/* translators: %d: Item index. */
					esc_html__('Item #%d', 'happy-addons-pro'),
					$index
				),
				'content_width' => 'full',
			],
		];
	}

	protected function get_default_children_placeholder_selector(): string {
		return '.ha-n-hover-list';
	}

	protected function get_default_children_container_placeholder_selector(): string {
		return '.ha-n-hover-list-item';
	}

	protected function get_html_wrapper_class(): string {
		return 'elementor-widget-ha-n-hover-list';
	}

	protected function get_initial_config(): array {
		return array_merge(parent::get_initial_config(), [
			'support_improved_repeaters' => true,
			'target_container'           => ['.ha-n-hover-list'],
			'node'                       => 'div',
			'is_interlaced'              => true,
		]);
	}

	protected function register_controls(): void {
		$this->register_items_controls();
		$this->register_title_animation_controls();
		$this->register_interactions_controls();
		$this->register_hover_list_style_controls();
		$this->register_title_style_controls();
		$this->register_icon_style_controls();
	}

	protected function register_items_controls(): void {

		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__('Items', 'happy-addons-pro'),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			[
				'label'       => esc_html__('Title', 'happy-addons-pro'),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__('Item Title', 'happy-addons-pro'),
				'placeholder' => esc_html__('Item Title', 'happy-addons-pro'),
				'label_block' => true,
				'dynamic'     => ['active' => true],
			]
		);

		$repeater->add_control(
			'element_css_id',
			[
				'label'          => esc_html__('CSS ID', 'happy-addons-pro'),
				'type'           => Controls_Manager::TEXT,
				'default'        => '',
				'dynamic'        => ['active' => true],
				'title'          => esc_html__('Add your custom id WITHOUT the Pound key. e.g: my-id', 'happy-addons-pro'),
				'style_transfer' => false,
				'classes'        => 'elementor-control-direction-ltr',
			]
		);

		$this->add_control(
			'items',
			[
				'label'              => esc_html__('Hover List Items', 'happy-addons-pro'),
				'type'               => Control_Nested_Repeater::CONTROL_TYPE,
				'fields'             => $repeater->get_controls(),
				'default'            => [
					['item_title' => esc_html__('Item #1', 'happy-addons-pro')],
					['item_title' => esc_html__('Item #2', 'happy-addons-pro')],
					['item_title' => esc_html__('Item #3', 'happy-addons-pro')],
					['item_title' => esc_html__('Item #4', 'happy-addons-pro')],
				],
				'frontend_available' => true,
				'title_field'        => '{{{ item_title }}}',
				'button_text'        => esc_html__('Add Item', 'happy-addons-pro'),
			]
		);

		$this->add_control(
			'show_icon',
			[
				'label'        => esc_html__('Icon', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'    => esc_html__('No', 'happy-addons-pro'),
				'default'      => 'yes',
				'separator'    => 'before',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'item_icon',
			[
				'label'       => esc_html__('Expand', 'happy-addons-pro'),
				'type'        => Controls_Manager::ICONS,
				'skin'        => 'inline',
				'label_block' => false,
				'default' => [
					'value' => 'fas fa-plus',
					'library' => 'fa-solid',
				],
				'condition'   => [
					'show_icon' => 'yes',
				],
			]
		);

		$this->add_control(
			'item_icon_hover',
			[
				'label'       => esc_html__('Collapse', 'happy-addons-pro'),
				'type'        => Controls_Manager::ICONS,
				'skin'        => 'inline',
				'label_block' => false,
				'default' => [
					'value' => 'fas fa-minus',
					'library' => 'fa-solid',
				],
				'condition'   => [
					'show_icon'           => 'yes',
					'item_icon[value]!'   => '',
				],
			]
		);

		$this->add_responsive_control(
			'icon_position',
			[
				'label'     => esc_html__('Icon Position', 'happy-addons-pro'),
				'type'      => Controls_Manager::CHOOSE,
				'prefix_class' => 'ha-n-hover-list-icon-position-',
				'options'   => [
					'left' => [
						'title' => esc_html__('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-left',
					],
					'right'   => [
						'title' => esc_html__('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'              => 'left',
				'frontend_available'   => true,
				'condition'            => [
					'show_icon' => 'yes',
				],
				'selectors_dictionary' => [
					'left'  => '--ha-n-hover-list-icon-order: -1;',
					'right' => '--ha-n-hover-list-icon-order: 1;',
				],
				'selectors' => [
					'{{WRAPPER}}' => '{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'item_title_tag',
			[
				'label'   => esc_html__('Title HTML Tag', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p'   => 'p',
				],
				'default' => 'div',
			]
		);

		$this->end_controls_section();
	}

	protected function register_title_animation_controls(): void {

		$this->start_controls_section(
			'section_title_animation',
			[
				'label' => esc_html__('Title Animation', 'happy-addons-pro'),
			]
		);

		$this->add_control(
			'title_zoom_heading',
			[
				'label' => esc_html__('Active Item Title', 'happy-addons-pro'),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_zoom',
			[
				'label'        => esc_html__('Zoom', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'    => esc_html__('No', 'happy-addons-pro'),
				'default'      => '',
				'render_type'  => 'ui',
			]
		);

		$this->add_control(
			'title_zoom_scale',
			[
				'label'      => esc_html__('Zoom Scale', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['x'],
				'range'      => [
					'x' => ['min' => 1, 'max' => 2, 'step' => 0.05],
				],
				'default'    => [
					'unit' => 'x',
					'size' => 1.2,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-title-zoom-scale: {{SIZE}};',
				],
				'condition'  => [
					'title_zoom' => 'yes',
				],
				'render_type' => 'ui',
			]
		);

		$this->add_control(
			'title_zoom_duration',
			[
				'label'      => esc_html__('Zoom Duration (ms)', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['ms'],
				'range'      => [
					'ms' => ['min' => 100, 'max' => 3000, 'step' => 50],
				],
				'default'    => [
					'unit' => 'ms',
					'size' => 300,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-title-zoom-duration: {{SIZE}}ms;',
				],
				'condition'  => [
					'title_zoom' => 'yes',
				],
				'render_type' => 'ui',
			]
		);

		$this->add_control(
			'title_zoom_easing',
			[
				'label'   => esc_html__('Zoom Easing', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'ease',
				'options' => [
					'ease'                                   => esc_html__('Ease', 'happy-addons-pro'),
					'ease-in'                                => esc_html__('Ease In', 'happy-addons-pro'),
					'ease-out'                               => esc_html__('Ease Out', 'happy-addons-pro'),
					'ease-in-out'                            => esc_html__('Ease In Out', 'happy-addons-pro'),
					'linear'                                 => esc_html__('Linear', 'happy-addons-pro'),
					'cubic-bezier(0.68, -0.55, 0.265, 1.55)' => esc_html__('Bounce', 'happy-addons-pro'),
					'cubic-bezier(0.5, 1.75, 0.4, 0.75)'     => esc_html__('Elastic', 'happy-addons-pro'),
				],
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-title-zoom-easing: {{VALUE}};',
				],
				'condition' => [
					'title_zoom' => 'yes',
				],
				'render_type' => 'ui',
			]
		);

		$this->add_control(
			'icon_zoom',
			[
				'label'       => esc_html__('Icon Zoom', 'happy-addons-pro'),
				'type'        => Controls_Manager::SWITCHER,
				'label_on'    => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'   => esc_html__('No', 'happy-addons-pro'),
				'default'     => '',
				'description' => esc_html__('Zooms the icon using the title zoom settings above.', 'happy-addons-pro'),
				'render_type' => 'ui',
				'condition'   => [
					'show_icon' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_interactions_controls(): void {

		$this->start_controls_section(
			'section_interactions',
			[
				'label' => esc_html__('Interactions', 'happy-addons-pro'),
			]
		);

		$this->add_control(
			'default_active',
			[
				'label'   => esc_html__('Default Active Item', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'   => esc_html__('None', 'happy-addons-pro'),
					'first'  => esc_html__('First', 'happy-addons-pro'),
					'custom' => esc_html__('Custom', 'happy-addons-pro'),
				],
				'default'            => 'first',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'default_active_custom',
			[
				'label'              => esc_html__('Active Item Number', 'happy-addons-pro'),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 1,
				'step'               => 1,
				'default'            => 1,
				'frontend_available' => true,
				'condition'          => [
					'default_active' => 'custom',
				],
			]
		);

		$this->add_control(
			'animation_duration',
			[
				'label'   => esc_html__('Animation Duration (ms)', 'happy-addons-pro'),
				'type'    => Controls_Manager::SLIDER,
				'range'   => [
					'px' => [
						'min' => 100,
						'max' => 1500,
						'step' => 50,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 500,
				],
				'frontend_available' => true,
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-animation-duration: {{SIZE}}ms',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_hover_list_style_controls(): void {

		$this->start_controls_section(
			'section_hover_list_style',
			[
				'label' => esc_html__('Hover List', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'hover_list_item_space_between',
			[
				'label'      => esc_html__('Space between Items', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', 'rem', 'custom'],
				'range'      => [
					'px'  => ['max' => 200],
					'em'  => ['max' => 20],
					'rem' => ['max' => 20],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-item-space-between: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'hover_list_item_distance_from_content',
			[
				'label'      => esc_html__('Distance from content', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', 'rem', 'custom'],
				'range'      => [
					'px'  => ['max' => 200],
					'em'  => ['max' => 20],
					'rem' => ['max' => 20],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-item-distance-from-content: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'hover_list_divider_color',
			[
				'label'     => esc_html__('Divider Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#2121211f',
				'condition' => [
					'hover_list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ha-n-hover-list-item' => '--ha-n-hover-list-divider-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'hover_list_divider_width',
			[
				'label'      => esc_html__('Divider Width', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => ['max' => 10],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 1,
				],
				'condition'  => [
					'hover_list_divider' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}} .ha-n-hover-list-item' => '--ha-n-hover-list-divider-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->start_controls_tabs('hover_list_border_and_background');

		$this->start_controls_tab('hover_list_normal', [
			'label' => esc_html__('Normal', 'happy-addons-pro'),
		]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'hover_list_background_normal',
				'types'    => ['classic', 'gradient'],
				'exclude'  => ['image'],
				'selector' => '{{WRAPPER}} .ha-n-hover-list-item .ha-n-hover-list-title',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'hover_list_border_normal',
				'selector' => '{{WRAPPER}} .ha-n-hover-list-item .ha-n-hover-list-title',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab('hover_list_hover', [
			'label' => esc_html__('Hover', 'happy-addons-pro'),
		]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'hover_list_background_hover',
				'types'    => ['classic', 'gradient'],
				'exclude'  => ['image'],
				'selector' => '{{WRAPPER}} .ha-n-hover-list-item:hover .ha-n-hover-list-title, {{WRAPPER}} .ha-n-hover-list-item.e-active .ha-n-hover-list-title',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'hover_list_border_hover',
				'selector' => '{{WRAPPER}} .ha-n-hover-list-item:hover .ha-n-hover-list-title, {{WRAPPER}} .ha-n-hover-list-item.e-active .ha-n-hover-list-title',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'hover_list_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'hover_list_padding',
			[
				'label'      => esc_html__('Padding', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'selectors'  => [
					'{{WRAPPER}} .ha-n-hover-list-item .ha-n-hover-list-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function register_title_style_controls(): void {

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__('Title', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ha-n-hover-list-item-title-text',
				'fields_options' => [
					'font_size' => [
						'selectors' => [
							'{{WRAPPER}}' => '--ha-n-hover-list-title-font-size: {{SIZE}}{{UNIT}}',
						],
					],
				],
			]
		);

		$this->start_controls_tabs('title_style');

		$this->start_controls_tab('title_normal', [
			'label' => esc_html__('Normal', 'happy-addons-pro'),
		]);

		$this->add_control(
			'title_text_color',
			[
				'label'     => esc_html__('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-title-normal-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab('title_hover', [
			'label' => esc_html__('Hover', 'happy-addons-pro'),
		]);

		$this->add_control(
			'title_text_color_hover',
			[
				'label'     => esc_html__('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-title-hover-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	protected function register_icon_style_controls(): void {

		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__('Icon', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'show_icon' => 'yes',
				],
			]
		);

		

		$this->add_responsive_control(
			'icon_size',
			[
				'label'      => esc_html__('Size', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => ['max' => 100],
				],
				'size_units' => ['px', 'em', 'rem', 'custom'],
				'condition'  => [
					'show_icon' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'      => esc_html__('Spacing', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', 'rem', 'custom'],
				'range'      => [
					'px' => ['max' => 400],
				],
				'condition'  => [
					'show_icon' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-gap: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'icon_bg_color',
			[
				'label'     => esc_html__('Icon Background', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'condition' => [
					'show_icon' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-bg: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_bg_color_hover',
			[
				'label'     => esc_html__('Icon Background Hover', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'show_icon' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-bg-hover: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_bg_size',
			[
				'label'      => esc_html__('Icon Background Size', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', 'rem', 'custom'],
				'range'      => [
					'px' => ['max' => 100],
				],
				'condition'  => [
					'show_icon' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-bg-size: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_responsive_control(
			'icon_bg_radius',
			[
				'label'      => esc_html__('Icon Background Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => ['max' => 100],
					'%'  => ['max' => 50],
				],
				'condition'  => [
					'show_icon' => 'yes',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-bg-radius: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->start_controls_tabs('icon_style', [
			'condition' => [
				'show_icon' => 'yes',
			],
		]);

		$this->start_controls_tab('icon_normal', [
			'label' => esc_html__('Normal', 'happy-addons-pro'),
		]);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-normal-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab('icon_hover', [
			'label' => esc_html__('Hover', 'happy-addons-pro'),
		]);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__('Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--ha-n-hover-list-icon-hover-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function register_content_style_controls(): void {

	}

	protected function render(): void {
		$settings      = $this->get_settings_for_display();
		$items         = $settings['items'] ?? [];
		$widget_number = $this->get_id_int();

		$default_active = $settings['default_active'] ?? 'first';
		$custom_active  = max(1, absint($settings['default_active_custom'] ?? 1));
		$title_html_tag = Utils::validate_html_tag($settings['item_title_tag'] ?? 'div');

		$show_icon       = 'yes' === ($settings['show_icon'] ?? 'yes');
		$item_icon       = $settings['item_icon'] ?? [];
		$item_icon_hover = $settings['item_icon_hover'] ?? [];
		$has_icon        = $show_icon && ! empty($item_icon['value']);
		$has_hover_icon  = $has_icon && ! empty($item_icon_hover['value']);

		$this->add_render_attribute('hover-list-wrapper', [
			'class'                => ['ha-n-hover-list', 'yes' === ($settings['title_zoom'] ?? '') ? 'ha-n-hover-list-title-zoom' : '', 'yes' === ($settings['icon_zoom'] ?? '') ? 'ha-n-hover-list-icon-zoom' : ''],
			'data-widget-number'   => $widget_number,
			'data-default-active'  => $default_active,
			'data-active-index'    => $custom_active,
		]);

		$items_html = '';

		foreach ($items as $index => $item) {
			$hover_count    = $index + 1;
			$item_setting_key = $this->get_repeater_setting_key('item_title', 'items', $index);
			$item_id        = empty($item['element_css_id']) ? 'ha-n-hover-list-item-' . $widget_number . $hover_count : $item['element_css_id'];
			$item_title     = $item['item_title'] ?? '';
			$is_active      = ('first' === $default_active && 0 === $index) || ('custom' === $default_active && $custom_active === $hover_count);
			$aria_expanded  = $is_active ? 'true' : 'false';

			$item_settings = [
				'index'         => $index,
				'hover_count'   => $hover_count,
				'item_id'       => $item_id,
				'widget_number' => $widget_number,
				'item'          => $item,
				'settings'      => $settings,
			];

			$this->hover_item_settings[] = $item_settings;

			$this->add_render_attribute($item_setting_key, [
				'id'                   => $item_id,
				'class'                => ['ha-n-hover-list-item', $is_active ? 'e-active' : ''],
				'data-hover-index'     => $hover_count,
			]);

			$title_setting_key = $item_setting_key . '-title';
			$this->add_render_attribute($title_setting_key, [
				'id'                   => $item_id . '-title',
				'class'                => ['ha-n-hover-list-title', $is_active ? 'e-active' : ''],
				'role'                 => 'button',
				'tabindex'             => 0 === $index ? '0' : '-1',
				'aria-expanded'        => $aria_expanded,
				'aria-controls'        => $item_id . '-content',
				'data-hover-index'     => $hover_count,
			]);

			ob_start();
			?>
			<div <?php $this->print_render_attribute_string($item_setting_key); ?>>
				<div <?php $this->print_render_attribute_string($title_setting_key); ?>>
					<span class="ha-n-hover-list-title-header">
						<<?php echo esc_attr($title_html_tag); ?> class="ha-n-hover-list-item-title-text">
							<?php echo esc_html($item_title); ?>
						</<?php echo esc_attr($title_html_tag); ?>>
					</span>
					<?php if ($has_icon) : ?>
						<span class="ha-n-hover-list-icon">
							<span class="ha-n-hover-list-icon-normal">
								<?php Icons_Manager::render_icon($item_icon, ['aria-hidden' => 'true']); ?>
							</span>
							<span class="ha-n-hover-list-icon-hover">
								<?php Icons_Manager::render_icon($has_hover_icon ? $item_icon_hover : $item_icon, ['aria-hidden' => 'true']); ?>
							</span>
						</span>
					<?php endif; ?>
				</div>
				<div id="<?php echo esc_attr($item_id); ?>-content" class="ha-n-hover-list-content">
					<?php
					$item_settings_data = $this->hover_item_settings[$index];
					$this->print_child($item_settings_data['index'], $item_settings_data);
					?>
				</div>
				<?php if ($index < count($items) - 1) : ?>
					<div class="ha-n-hover-list-item-divider"></div>
				<?php endif; ?>
			</div>
			<?php
			$items_html .= ob_get_clean();
		}
		?>
		<div <?php $this->print_render_attribute_string('hover-list-wrapper'); ?>>
			<?php echo $items_html; ?>
		</div>
		<?php
	}

	public function print_child($index, $item_settings = []) {

		$children = $this->get_children();

		if (! isset($children[$index])) {
			return;
		}

		$child = $children[$index];
		$child_id = $child->get_id();

		$add_attribute_to_container = function ($should_render, $container) use ($child_id, $item_settings) {
			if ($container->get_id() === $child_id) {
				$this->add_attributes_to_container($container, $item_settings);
			}

			return $should_render;
		};

		add_filter('elementor/frontend/container/should_render', $add_attribute_to_container, 10, 3);

		$child->print_element();

		remove_filter('elementor/frontend/container/should_render', $add_attribute_to_container);
	}

	protected function add_attributes_to_container($container, $item_settings) {
		$container->add_render_attribute('_wrapper', [
			'role'              => 'region',
			'aria-labelledby'   => $item_settings['item_id'] . '-title',
			'data-hover-index'  => $item_settings['hover_count'] ?? 1,
		]);
	}

	protected function content_template(): void {
		?>
		<#
			const elementUid = view.getIDInt().toString();
			const titleHTMLTag = elementor.helpers.validateHTMLTag(settings.item_title_tag || 'div');
			const defaultActive = settings.default_active || 'first';
			const customActive = parseInt(settings.default_active_custom || 1, 10);
			const showIcon = settings.show_icon === 'yes';
			const widgetIcon = showIcon && settings.item_icon ? elementor.helpers.renderIcon(view, settings.item_icon, { 'aria-hidden': true }, 'i', 'object') : null;
			const widgetHoverIcon = showIcon && settings.item_icon_hover && settings.item_icon_hover.value
				? elementor.helpers.renderIcon(view, settings.item_icon_hover, { 'aria-hidden': true }, 'i', 'object')
				: widgetIcon;
			const hasIcon = widgetIcon && widgetIcon.value;
			const titleZoom = settings.title_zoom === 'yes';
			const iconZoom = showIcon && settings.icon_zoom === 'yes';

			view.addRenderAttribute('hover-list-wrapper', {
				'class': ['ha-n-hover-list', titleZoom ? 'ha-n-hover-list-title-zoom' : '', iconZoom ? 'ha-n-hover-list-icon-zoom' : ''],
				'data-widget-number': elementUid,
				'data-default-active': defaultActive,
				'data-active-index': customActive
			});
		#>
		<div {{{ view.getRenderAttributeString('hover-list-wrapper') }}}>
			<# if (settings['items']) { #>
				<# _.each(settings['items'], function(item, index) { #>
					<#
						const hoverCount = index + 1;
						const itemUid = elementUid + hoverCount;
						const itemId = item.element_css_id || 'ha-n-hover-list-item-' + itemUid;
						const isActive = ('first' === defaultActive && 0 === index) || ('custom' === defaultActive && customActive === hoverCount);
						const ariaExpanded = isActive ? 'true' : 'false';

						const itemAttributes = {
							'id': itemId,
							'class': ['ha-n-hover-list-item', isActive ? 'e-active' : ''],
							'data-hover-index': hoverCount
						};

						view.addRenderAttribute('item-' + itemUid, itemAttributes);

						view.addRenderAttribute('title-' + itemUid, {
							'id': itemId + '-title',
							'class': ['ha-n-hover-list-title', isActive ? 'e-active' : ''],
							'role': 'button',
							'tabindex': 0 === index ? '0' : '-1',
							'aria-expanded': ariaExpanded,
							'aria-controls': itemId + '-content',
							'data-hover-index': hoverCount
						});
					#>
					<div {{{ view.getRenderAttributeString('item-' + itemUid) }}}>
						<div {{{ view.getRenderAttributeString('title-' + itemUid) }}}>
							<span class="ha-n-hover-list-title-header">
								<{{{ titleHTMLTag }}} class="ha-n-hover-list-item-title-text">
									{{{ item.item_title }}}
								</{{{ titleHTMLTag }}}>
							</span>
							<# if (hasIcon) { #>
								<span class="ha-n-hover-list-icon">
									<span class="ha-n-hover-list-icon-normal">{{{ widgetIcon.value }}}</span>
									<span class="ha-n-hover-list-icon-hover">{{{ widgetHoverIcon.value }}}</span>
								</span>
							<# } #>
						</div>
						<div id="{{{ itemId }}}-content" class="ha-n-hover-list-content"></div>
						<# if (index < settings['items'].length - 1) { #>
							<div class="ha-n-hover-list-item-divider"></div>
						<# } #>
					</div>
				<# }); #>
			<# } #>
		</div>
		<?php
	}

	
	protected function content_template_single_repeater_item(): void {
	?>
	<#
		const tabIndex = view.collection.length;
		const elementUid = view.getIDInt().toString();
		const tabCount = tabIndex + 1;

		const itemUid = elementUid + tabCount;
		const itemId = data.element_css_id || 'ha-n-hover-list-item-' + itemUid;

		const settings = view.getContainer().settings;

		const showIcon = (settings.get('show_icon') ?? 'yes') === 'yes';
		const itemIcon = settings.get('item_icon');
		const itemIconHover = settings.get('item_icon_hover');

		const defaultIcon = {
			value: 'fas fa-plus',
			library: 'fa-solid'
		};

		const defaultHoverIcon = {
			value: 'fas fa-minus',
			library: 'fa-solid'
		};

		const finalIcon = itemIcon || defaultIcon;
		const finalHoverIcon = itemIconHover || defaultHoverIcon;

		const renderIconSafe = (icon) => {
			if (!icon) return '';

			const rendered = elementor.helpers.renderIcon(
				view,
				icon,
				{ 'aria-hidden': true },
				'i',
				'object'
			);

			return typeof rendered === 'string'
				? rendered
				: (rendered?.value || '');
		};

		const widgetIcon = showIcon ? renderIconSafe(finalIcon) : '';
		const widgetHoverIcon = showIcon ? renderIconSafe(finalHoverIcon) : widgetIcon;

		const hasIcon = !!widgetIcon;

		const wrapperKey = 'item-wrapper-' + tabCount;
		const titleKey = 'item-title-' + tabCount;

		view.addRenderAttribute(wrapperKey, {
			'id': itemId,
			'class': 'ha-n-hover-list-item',
			'data-hover-index': tabCount
		});

		view.addRenderAttribute(titleKey, {
			'id': itemId + '-title',
			'class': 'ha-n-hover-list-title',
			'role': 'button',
			'tabindex': -1,
			'aria-expanded': 'false',
			'aria-controls': itemId + '-content',
			'data-hover-index': tabCount
		});
	#>

	<div {{{ view.getRenderAttributeString(wrapperKey) }}}>
		<div {{{ view.getRenderAttributeString(titleKey) }}}>

			<span class="ha-n-hover-list-title-header">
				<div class="ha-n-hover-list-item-title-text">
					{{{ data.item_title }}}
				</div>
			</span>

			<# if (hasIcon) { #>
				<span class="ha-n-hover-list-icon">
					<span class="ha-n-hover-list-icon-normal">
						{{{ widgetIcon }}}
					</span>

					<span class="ha-n-hover-list-icon-hover">
						{{{ widgetHoverIcon }}}
					</span>
				</span>
			<# } #>

		</div>

		<div class="ha-n-hover-list-content"></div>
		<div class="ha-n-hover-list-item-divider"></div>
	</div>

	<?php
}
}
