import DataUtils from '../../utils/DataUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import ProductInfo from './ProductInfo';
import ProductUtils from '../../utils/ProductUtils';
import WidgetVariantChoose from './WidgetVariantChoose';
import CartProduct from '../../cart/CartProduct';
import CartAddNav, { CartAddMode } from '../../cart/CartAddNav';
import WidgetGroupChoose, { WidgetGroupPayload } from './WidgetGroupChoose';
import Cart from '../../cart/Cart';
import ExistingProductInCartInfo from './ExistingProductInCartInfo';
import LanguageUtils from '../../utils/LanguageUtils';


const animationTopVar = 100;

let instance;
const instanceKey = '_*&3874*(239';

class ProductPage {

    _onOpenRequestEvent;
    _onCloseProductPageEvent;

    static SCREEN_ID = 'apt_product_screen';
    _screen_ui;
    _isOpen = false;
    _product = null;
    _categoryId = null;
    _isNavSticky = false;

    _apt_product_nav;
    _apt_product_nav_sticky;
    _product_content_ui;

    _productInfo;
    _widgetVariantChoose;
    _cartProduct = null;

    _cartAddNav = null;
    _isExistingCartProduct = false;
    _existingProductInCartInfo = null;
    _existingCartProductData = null;

    _pageData = {};

    init() {
        const _this = this;
        this._screen_ui = jQuery(`#${ProductPage.SCREEN_ID}`);
        this._onOpenRequestEvent = new Event(Events.OPEN_PRODUCT_SCREEN_REQUEST, data => this._onOpenPageRequest(data));
        EventBus.getInstance().registerEvent(this._onOpenRequestEvent);

        this._onCloseProductPageEvent = new Event(Events.PRODUCT_SCREEN_CLOSE, data => this._pageClose(data));
        EventBus.getInstance().registerEvent(this._onCloseProductPageEvent);

        this._apt_product_nav = this._screen_ui.find('.apt-product-nav');
        this._apt_product_nav_sticky = this._screen_ui.find('.apt-product-nav-sticky');
        this._product_content_ui = this._screen_ui.find('.product_content_ui');

        this._uiEvents();
        this._productInfo = new ProductInfo(this._apt_product_nav);
    }

    _uiEvents() {
        const _this = this;
        this._screen_ui.find('.header_close_btn').click(function(event) {
            event.preventDefault();
            if (!_this._isOpen) {
                return;
            }
            _this._pageClose();
        })
        this._screen_ui.find('.header_float_close_btn').click(function(event) {
            event.preventDefault();
            if (!_this._isOpen) {
                return;
            }
            _this._apt_product_nav_sticky.removeClass('show');
            _this._pageClose();
        })

        this._screen_ui[0].onscroll = scrollEvent => {
            this._handleMainNavStiky(scrollEvent);
        };
    }

    _handleMainNavStiky(scrollEvent) {
        const offsetTop = this._apt_product_nav.offset().top;
        if (!this._isNavSticky && offsetTop <= 100) {
            if (!this._apt_product_nav_sticky.hasClass('show')) {
                this._apt_product_nav_sticky.addClass('show');
            }
            if (offsetTop >= 0) {
                this._apt_product_nav_sticky.css('opacity', (100 - offsetTop) * .01);
            } else {
                this._apt_product_nav_sticky.css('opacity', 1);
            }
        } else {
            if (this._apt_product_nav_sticky.hasClass('show')) {
                this._apt_product_nav_sticky.removeClass('show');
            }
        }
    }

    _onOpenPageRequest(data) {
        if (this._isOpen) {
            return;
        }
        this._pageData = data;
        this.gcc();

        this._isOpen = true;
        this._product = DataUtils.getInstance().getProduct(_.get(data, 'productId'));

        this._existingCartProductData = Cart.getInstance().cartHasProduct(this._product.ID);
        this._categoryId = _.get(data, 'categoryId')
        
        this._onBeforePageAnimation(data);

        this._handleHeader();
        this._renderContent();

        EventBus.getInstance().triggerEvent(Events.PRODUCT_SCREEN_OPEN_START, data );
        this._screen_ui.css('top', jQuery(window).height() + animationTopVar);
        this._screen_ui.removeClass('aptdisplay_none');
        this._screen_ui.animate({
            top: 0
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterAnimation();
        });
        this._screen_ui.scrollTop(0);
    }

    _onBeforePageAnimation(data) {
        const existingCartProduct = _.get(data, 'existingCartProduct', null);

        if (!_.isNil(existingCartProduct) && existingCartProduct instanceof CartProduct) {
            this._isExistingCartProduct = true;
            this._cartProduct = existingCartProduct;
            this._cartAddNav = new CartAddNav(quantity => {
                if (quantity === 0) {
                    Cart.getInstance().remove(this._cartProduct);
                    this._pageClose(false);
                    return;
                }
                this._cartProduct.setQuantity(quantity);
                Cart.getInstance().update(this._cartProduct);
                this._pageClose(true);
            }, CartAddMode.UPDATE, this._cartProduct.getQuantity())
        } else {
            this._cartProduct = new CartProduct(this._product);
            this._cartProduct.setProductCategoryId(this._categoryId);
            this._cartAddNav = new CartAddNav(quantity => {
                this._cartProduct.setQuantity(quantity);
                Cart.getInstance().add(this._cartProduct);
                this._pageClose();
            }, CartAddMode.ADD, 1);
        }
        this._cartAddNav.render(this._product_content_ui);
        this._cartAddNav.hide();

        const hasVariants = ProductUtils.productHasVariants(this._product);
        const hasChoiceGroups = ProductUtils.productHasChoiceGroups(this._product);
        if (!hasVariants && !hasChoiceGroups) {
            if (this._product_content_ui.hasClass('b_padding')) {
                this._product_content_ui.removeClass('b_padding');
            }
        } else {
            if (!this._product_content_ui.hasClass('b_padding')) {
                this._product_content_ui.addClass('b_padding');
            }
        }
    }

    _onAfterAnimation() {
        const hasVariants = ProductUtils.productHasVariants(this._product);
        const hasChoiceGroups = ProductUtils.productHasChoiceGroups(this._product);

        const hideAddToCart = this._existingCartProductData;

        if (!hideAddToCart) {
            this._cartAddNav.show();
        }
        this._cartAddNav.show();

        if (this._isExistingCartProduct) {
            this._validateCartProductOnDemand();
        }
    }

    _pageClose(openCartPage = false) {
        this._isOpen = false;
        this._isNavSticky = false;
        this._product = null;
        const _this = this;
        try {
            this._cartAddNav.remove();
        } catch (err) {console.log(err)};
        EventBus.getInstance().triggerEvent(Events.PRODUCT_SCREEN_CLOSE_START, {});
        this._screen_ui.animate({
            top: jQuery(window).height() + animationTopVar,
        }, 700, 'easeInOutQuint', function() {
            _this.gcc();
            _this._screen_ui.addClass('aptdisplay_none')
        })
        if (openCartPage) {
            EventBus.getInstance().triggerEvent(Events.OPEN_CART_SCREEN_REQUEST, {});
        }
    }

    _handleHeader() {
        const productImage = _.get(this._product, 'meta.landscape_photo_images.appetit-cover-medium', '');
        this._screen_ui.find('.apt-cover-header').css('background-image', `url('${productImage}')`);
        this._screen_ui.find('.apt-cover-header').css('background-size', `cover`);
        this._screen_ui.find('.apt-cover-header').css('background-position', `center`);
    }

    _renderContent() {
        
        const productName = ProductUtils.getProductName(this._product);
        this._productInfo.renderProduct(this._product);
        this._apt_product_nav_sticky.find('.sticky-product-name').html(productName);

        
        if (this._existingCartProductData) {
            const existingCartProduct = _.get(this._pageData, 'existingCartProduct', null);

            const isUpdate = !_.isNil(existingCartProduct) && existingCartProduct instanceof CartProduct;
            if (!isUpdate) {
                this._existingProductInCartInfo = new ExistingProductInCartInfo(this._product_content_ui, 
                    Cart.getInstance().cartGetExistingProducts(this._product.ID)
                );
                this._existingProductInCartInfo.render();
            }
        }

        if (ProductUtils.productHasVariants(this._product)) {
            this._widgetVariantChoose = new WidgetVariantChoose(this._product, variantId => {
                this._cartProduct.setVariant(variantId);
                this._validateCartProductOnDemand();
            });
            this._widgetVariantChoose.render(this._product_content_ui);
            if (!_.isNil(this._cartProduct.getVariant())) {
                this._widgetVariantChoose.selectItem(this._cartProduct.getVariant());
            }
        } else if (ProductUtils.getProductSingleVariant(this._product)) {
            const variant = ProductUtils.getProductSingleVariant(this._product);
            this._cartProduct.setVariant(_.get(variant, 'ID', ''));
        }

        this._renderChoiceGroups();
        this._renderInstructions();
        this._validateCartProductAddOnInit();
    }

    _renderChoiceGroups() {
        if (!ProductUtils.productHasChoiceGroups(this._product))  {
            return;
        }
        const groups = ProductUtils.getProductGroups(this._product);
        const groupsInstances = groups.map(group => {
            const clonedGroup = { ...group };
            this._cartProduct.addGroup(clonedGroup);
            const selectedChoices = this._cartProduct.getGroupSelectedChoices(group);

            return new WidgetGroupChoose(group, this._product, payload => {
                if (payload instanceof WidgetGroupPayload) {
                    if (payload.method === WidgetGroupPayload.ADD) {
                        this._cartProduct.setChoice(payload.choiceId, payload.groupId);
                    } else if (payload.method === WidgetGroupPayload.REMOVE) {
                        this._cartProduct.removeChoice(payload.choiceId, payload.groupId);
                    }
                    this._validateCartProductOnDemand();
                }
            }, selectedChoices)
        })
        groupsInstances.forEach(widgetGroup => {
            widgetGroup.render(this._product_content_ui);
        });
        this._validateCartProductOnDemand();
    }

    _validateCartProductAddOnInit() {
        if (ProductUtils.productHasVariants(this._product)) {
            this._cartAddNav.setCanUpdate(false);
        } else {
            const variant = _.get(this.product, 'meta.product_variations[0]', null);
            if (!_.isNil(variant)) {
                this._cartProduct.setVariant(get(variant, 'ID'));
                this._cartAddNav.setCanUpdate(true);
            }
        }
    }

    _validateCartProductOnDemand() {
        const isCartProductValid = this._cartProduct.validate();
        this._cartAddNav.setCanUpdate(isCartProductValid);
    }

    _renderInstructions() {
        const disabled_add_to_cart = DataUtils.getInstance().getOption('disabled_add_to_cart');
        if (disabled_add_to_cart === 'ON') {
            return;
        }

        const hasVariants = ProductUtils.productHasVariants(this._product);
        const hasChoiceGroups = ProductUtils.productHasChoiceGroups(this._product);
        const hideNotes = this._existingCartProductData && !hasVariants && !hasChoiceGroups;

        if (hideNotes) {
            return;
        }

        const existingNotes = this._cartProduct ? this._cartProduct.getAdditionalNotes() : '';
        const template = `
            <div class="if_form_control" style="padding: 1em; background: #fbfbfb;">
                <div class="label" style="font-weight: bold">${ LanguageUtils.getInstance().getLabel('product_additional_notes') }</div>
                <textarea class="if_textarea_input additional_notes full_w" spellcheck="false">${ existingNotes }</textarea>
            </div>
        `;
        const additional_notes_ui = jQuery(template);
        additional_notes_ui.appendTo(this._product_content_ui);

        const _this = this;

        additional_notes_ui.find('.additional_notes').on('keyup', function(event) {
            event.preventDefault();
            const notes = additional_notes_ui.find('.additional_notes').val();
            if (notes !== '' && _this._cartProduct) {
                _this._cartProduct.setAdditionalNotes(notes);
            }
        })
    }

    gcc() {
        this._product_content_ui.html('');
        this._widgetVariantChoose = null;
        this._cartAddNav = null;
        this._isExistingCartProduct = false;
    }

    static getInstance() {
        if (!instance) {
            instance = new ProductPage(instanceKey);
        }
        return instance;
    }
}
export default ProductPage;