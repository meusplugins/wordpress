import DataUtils from '../../utils/DataUtils';
import Utils from '../../utils/Utils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import LanguageSwitch from './LanguageSwitch';
import ProductUtils from '../../utils/ProductUtils';
import ViewCartWidget from '../../cart/ViewCartWidget';
import Cart from '../../cart/Cart';
import RestManager from '../../services/RestManager';

let instance;
const instanceKey = '_*&3874*(239';
const PAGE_EFFECTS = {
    FADE_TOP: 'FADE_TOP'
};

class HomePage {

    static SCREEN_ID = 'apt_home_screen';

    _isOpen = true;
    _screen_ui;
    _apt_screen_content_ui;

    _products;
    _choice_groups;
    _choices;
    _product_categories;

    _categories_nav_fixed_ui;
    _categories_nav_in_document_ui;

    _isNavSticky = false;
    _categories_ui_slugs = [];
    _categories_nav_rectangle = {};

    _onProductScreenStartEvent;
    _onProductScreenStartCloseEvent;
    _onCartChangeEvent;
    _onRequestEditProduct;

    _viewCartWidget = new ViewCartWidget();

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this');
        }
    }

    init() {
        const _this = this;
        this._screen_ui = jQuery(`#${HomePage.SCREEN_ID}`);
        this._apt_screen_content_ui = this._screen_ui.find('.apt_screen_content_ui');

        this._products = DataUtils.getInstance().getProducts();
        this._choice_groups = DataUtils.getInstance().getFromData(DataUtils.CHOICE_GROUPS);
        this._choices = DataUtils.getInstance().getFromData(DataUtils.CHOICES);
        this._product_categories = DataUtils.getInstance().getFromData(DataUtils.PRODUCT_CATEGORIES);
        this._initMainNav();
        this._agregateCategories();
        this._viewCartWidget.render(this._apt_screen_content_ui);
        
        const windowResizeDebounce = _.debounce(() => {
            _this._detectReachCategoryOnScroll();
        }, 5)

        this._screen_ui[0].onscroll = scrollEvent => {
            this._handleMainNavStiky(scrollEvent);
            windowResizeDebounce();
        };
        this._handleMenuItems();
        this._renderHeaderData();

        const options = DataUtils.getInstance().getFromData(DataUtils.OPTIONS);
        if (_.get(options, 'secondary_lang_enabled', '') === 'ON') {
            LanguageSwitch.getInstance().renderTo(this._screen_ui.find('.apt-cover-header-overlay'));
        }

        this._renderCallWaiter();
        this._renderCallRestaurant();


        this._onProductScreenStartEvent = new Event(Events.PRODUCT_SCREEN_OPEN_START, data => this._pageClose(data, PAGE_EFFECTS.FADE_TOP));
        EventBus.getInstance().registerEvent(this._onProductScreenStartEvent);

        this._onProductScreenStartCloseEvent = new Event(Events.PRODUCT_SCREEN_CLOSE_START, data => this._pageShow(data));
        EventBus.getInstance().registerEvent(this._onProductScreenStartCloseEvent);

        this._onCartScreenStartEvent = new Event(Events.OPEN_CART_SCREEN_REQUEST, data => this._pageClose(data, PAGE_EFFECTS.FADE_TOP));
        EventBus.getInstance().registerEvent(this._onCartScreenStartEvent);

        this._onCartScreenStartCloseEvent = new Event(Events.CLOSE_CART_SCREEN_REQUEST, data => this._pageShow(data));
        EventBus.getInstance().registerEvent(this._onCartScreenStartCloseEvent);

        this._onAboutScreenStartEvent = new Event(Events.OPEN_SHOP_SCREEN_REQUEST, data => this._pageClose(data, PAGE_EFFECTS.FADE_TOP));
        EventBus.getInstance().registerEvent(this._onAboutScreenStartEvent);

        this._onAboutScreenStartCloseEvent = new Event(Events.CLOSE_SHOP_SCREEN_REQUEST, data => this._pageShow(data));
        EventBus.getInstance().registerEvent(this._onAboutScreenStartCloseEvent);

        this._onCartChangeEvent = new Event(Events.CART_CHANGED, ({ cartProduct }) => {  _this._handleCartChange(cartProduct) });
        EventBus.getInstance().registerEvent(this._onCartChangeEvent);

        this._onRequestEditProduct = new Event(Events.CLOSE_CART_SCREEN_AND_OPEN_EDIT_PRODUCT, data => {  _this._handleEditProductRequest(data) });
        EventBus.getInstance().registerEvent(this._onRequestEditProduct);
    }

    _renderCallRestaurant() {
        const is_open_now = DataUtils.getInstance().getOption('is_open_now');
        const enable_call_restaurant_homepage = DataUtils.getInstance().getOption('enable_call_restaurant_homepage');
        const canDineIn = DataUtils.getInstance().canDineIn();
        if (!is_open_now) {
            return;
        }
        if (canDineIn) {
            return;
        }
        if (enable_call_restaurant_homepage !== 'ON') {
            return;
        }
        
        const homescreen_call_restaurant = LanguageUtils.getInstance().getLabel('homescreen_call_restaurant');
        const template = `
            <div class="call_waiter_ui">
                <div class="bell_ui"><span style="font-size: 17px;" class="icon-phone call_waiter_bell primary_color"></span></div>
                <div class="call_popup_inside">
                    <div class="call_content primary_color">
                        <a href="tel:${ DataUtils.getInstance().getOption('restaurant_phone') }" class="call_restaurant_home_link">
                        ${ homescreen_call_restaurant }
                        </a>
                    </div>
                </div>
            </div>
        `;

        const callw_ui = jQuery(template);
        callw_ui.appendTo(this._screen_ui.find('.apt-cover-header-overlay'));

        callw_ui.find('.bell_ui').click(function(event) {
            event.preventDefault();
            callw_ui.find('.call_popup_inside').show();
        })

        callw_ui.hover(function() {}, function(event) {
            event.preventDefault();
            jQuery(this).find('.call_popup_inside').hide();
            return false;
        })
    }

    _renderCallWaiter() {
        const options = DataUtils.getInstance().getFromData(DataUtils.OPTIONS);
        const is_open_now = DataUtils.getInstance().getOption('is_open_now');
        const dineInEnabled = _.get(options, 'local_order_enabled', '') === 'ON';
        const canDineIn = DataUtils.getInstance().canDineIn();
        if (!is_open_now || !dineInEnabled) {
            return;
        }
        if (!canDineIn) {
            return;
        }

        const homescreen_call_waiter = LanguageUtils.getInstance().getLabel('homescreen_call_waiter');
        
        const template = `
            <div class="call_waiter_ui">
                <div class="bell_ui"><span class="icon-notifications_on call_waiter_bell primary_color"></span></div>
                <div class="call_popup_inside">
                    <div class="call_content primary_color">${ homescreen_call_waiter }</div>
                </div>
            </div>
        `;
        const callw_ui = jQuery(template);
        callw_ui.appendTo(this._screen_ui.find('.apt-cover-header-overlay'));
        
        callw_ui.find('.bell_ui').click(function(event) {
            event.preventDefault();
            callw_ui.find('.call_popup_inside').show();
        })

        callw_ui.hover(function() {}, function(event) {
            event.preventDefault();
            jQuery(this).find('.call_popup_inside').hide();
            return false;
        })
        const _this = this;
        callw_ui.find('.call_popup_inside').click(function(event) {
            event.preventDefault();
            jQuery(this).hide();

            if (DataUtils.getInstance().getOption('hasReCaptcha')) {
                _this._getReCaptchaToken()
                .then(token => {
                    _this._recaptchaToken = token;
                    _this._callWaiter();
                })
                return;
            }
            _this._callWaiter();
            return false;
        })
    }

    _callWaiter() {
        const table = DataUtils.getInstance().getCurrentTable();

        RestManager.getInstance().post('/waiter', {
            table,
            recaptcha_token: DataUtils.getInstance().getOption('hasReCaptcha') ? this._recaptchaToken : '',
        })
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            const call_waiter_response = LanguageUtils.getInstance().getLabel('call_waiter_response');
            EventBus.getInstance().triggerEvent(Events.ON_TOAST_REQUEST, { text: call_waiter_response, time: 4000 } );
        })
    }

    _getReCaptchaToken(callback) {
        return new Promise((resolve, reject) => {
            if (!window.grecaptcha) {
                console.log('Missing recaptcha');
                return;
            }
    
            window.grecaptcha.execute(IF_RECAPTCHA_SITE_KEY, {action: 'submit'}).then(function(token) {
                resolve(token);
            })
            .catch(err => {
                resolve('');
            })
        })
    }    


    _renderHeaderData() {
        const options = DataUtils.getInstance().getFromData(DataUtils.OPTIONS);

        const average_order_time = LanguageUtils.getInstance().getLabel('homescreen_about_restaurant');
        const shop_info_btn = jQuery(`<div><a href="#" class="overlay_button"><span class="icon-info mr_5"></span>${average_order_time}</a></div>`);
        shop_info_btn.appendTo(this._screen_ui.find('.apt-header-info'));

        shop_info_btn.click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.OPEN_SHOP_SCREEN_REQUEST, {} );
        })
        this._screen_ui.find('.apt-header-info .apt-header-title').html(LanguageUtils.getInstance().getLabel('restaurant_name'));
    }

    _productDescriptionHelper(originalString, maxLength) {
        if (typeof originalString !== 'string') {
            return originalString;
        }
        if (originalString.length <= maxLength) {
            return originalString;
        }

        let trimmedString = originalString.substr(0, maxLength);
        trimmedString = trimmedString.substr(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(" ")))
        const after = trimmedString.length > 0 ? '...' : '';
        return `${trimmedString} ${after}`;
    }

    _displayCategory(category, index, totalCats) {
        const products = _.get(category, 'products', []);
        let productsHtml = '';
        const lang = LanguageUtils.getInstance().getLang();
        const options = DataUtils.getInstance().getFromData(DataUtils.OPTIONS);

        const max_char_desc = _.get(options, 'homepage_product_description_length', '');
        let isStripDeschars = false;
        let maxDescLength = 0;
        if (max_char_desc !== '' && _.isNumber(parseInt(max_char_desc)) && parseInt(max_char_desc) > 0) {
            maxDescLength = parseInt(max_char_desc);
            isStripDeschars = true;
        }

        const price_from_home = LanguageUtils.getInstance().getLabel('price_from_homepage');


        for (let i = 0; i < products.length; i++) {
            const product = products[i];
            
            let price_display = _.get(product, 'meta.variation_min_price.price_display', '');
            price_display = jQuery("<div />").html(price_display).text();
            
            let productDescription = ProductUtils.getProductDescription(product);
            if (isStripDeschars) {
                productDescription = this._productDescriptionHelper(productDescription, maxDescLength)
            }

            let price_from_html = '';
            if (ProductUtils.productHasVariants(product)) {
                price_from_html = price_from_home !== '' ? `<span class="price_from_home text_grey">${price_from_home}</span>` : '';
            }


            productsHtml += `
            <div class="product_list_item${i !== products.length -1 ? ' product_underline' : ''}" data-id="${_.get(product, 'ID')}" data-item-category="${_.get(category, 'term_id')}">
                <div class="product_info">
                    <div class="product_title mb_20">${ProductUtils.getProductName(product)}</div>
                    <div class="product_description text_grey">${ productDescription }</div>
                    <div class="product_price_display">${price_from_html} ${price_display}</div>
                </div>
                <div class="product_thumb">
                    <img src="${_.get(product, 'meta.square_photo_images.appetit-aquare-small', '')}" alt="" />
                </div>
                <div class="product_list_item_cart_info info_number red"></div>
            </div>
            `;
        }
        const template = `
        <div id="cat_scroll_${category.slug}" class="category_entry screen_content_entry ${index !== totalCats - 1 ? 'underline mb_20' : ''}">
            <h2 class="apt_secondary_title">${_.get(category, `meta.${lang}category_name`, '')}</h2>
            <div class="category_entry_products">${productsHtml}</div>
        </div>
        `;
        this._categories_ui_slugs.push(category.slug);
        jQuery(template).appendTo(this._apt_screen_content_ui);
    }

    _agregateCategories() {
        let c = 0;
        this._product_categories.map(category => {
            const catProducts = this._findCategoryProducts(category.term_id);
            this._displayCategory({...category, products: catProducts}, c, this._product_categories.length);
            c++;
        });
    }

    _findCategoryProducts(categoryId) {
        const products = [];
        this._products.map(product => {
            const product_categories = _.get(product, 'meta.item_category', []);
            const catIdString = String(categoryId);
            const hasCat = _.includes(product_categories, catIdString);
            if (hasCat) {
                products.push(product);
            }
        });
        return products;
    }

    _initMainNav() {
        let categoriesHtml = '';
        this._product_categories.map(category => {
            const lang = LanguageUtils.getInstance().getLang();
            categoriesHtml += `
                <a class="apt-category-nav apt_cat_${_.get(category, 'slug', '')}" data-slug="${_.get(category, 'slug', '')}" href="#">
                <span>${_.get(category, `meta.${lang}category_name`, '')}</span>
                <span class="selected_underline"></span>
                </a>
            `;
        });
        const compiled = _.template(`
            <div class="apt-categories-nav-ui <%= catNavClass %>">
                <div class="apt-categories-nav">
                    <%= categoriesHtml %>
                </div>
            </div>
        `);
        const compiledTemplateInDocument = compiled({ 'catNavClass': '', categoriesHtml: categoriesHtml });
        this._categories_nav_in_document_ui = jQuery(compiledTemplateInDocument);
        this._categories_nav_in_document_ui.appendTo(jQuery('.apt-categories-nav-holder'));
        const compiledTemplateFixed = compiled({ 'catNavClass': 'categories-fixed-nav aptdisplay_none', categoriesHtml: categoriesHtml });
        
        this._categories_nav_fixed_ui = jQuery(compiledTemplateFixed);
        this._categories_nav_fixed_ui.appendTo(jQuery('.apt-categories-nav-holder'));
        this._categories_nav_rectangle = this._categories_nav_in_document_ui[0].getBoundingClientRect();
        this._handleCategoryNavigation();
    }

    _handleCategoryNavigation() {
        const _this = this;
        const menuSelectDebounce = _.debounce((catSlug) => {
            jQuery('.apt-category-nav').removeClass('nav-selected');
            jQuery((`.apt_cat_${catSlug}`)).addClass('nav-selected');
        }, 800)

        jQuery('.apt-category-nav').each(function(index) {
            jQuery(this).click(function(event) {
                event.preventDefault();
                const catSlug = jQuery(this).attr('data-slug');
                const scrollTo = _this._screen_ui[0].scrollTop + jQuery(`#cat_scroll_${catSlug}`).position().top - _.get(_this._categories_nav_rectangle, 'height', 0);
                _this._screen_ui[0].scrollTop = scrollTo;
                menuSelectDebounce(catSlug);
            })
        })
    }

    _handleMainNavStiky(scrollEvent) {
        if (!this._isNavSticky && this._categories_nav_in_document_ui.offset().top <= 0) {
            if (this._categories_nav_fixed_ui.hasClass('aptdisplay_none')) {
                this._categories_nav_fixed_ui.removeClass('aptdisplay_none');
            }
        } else {
            if (!this._categories_nav_fixed_ui.hasClass('aptdisplay_none')) {
                this._categories_nav_fixed_ui.addClass('aptdisplay_none');
            }
        }
    }

    _detectReachCategoryOnScroll() {
        for (let i = 0; i < this._categories_ui_slugs.length; i++) {
            const categorySlug = this._categories_ui_slugs[i];
            const catPosition = jQuery(`#cat_scroll_${categorySlug}`).position().top;
            const catBoundingBox = jQuery(`#cat_scroll_${categorySlug}`)[0].getBoundingClientRect();

            const catTopisInVieport = catPosition < _.get(this._categories_nav_rectangle, 'height', 0) + 10;
            const catBottomInViewport = catPosition + _.get(this._categories_nav_rectangle, 'height', 0) + 10 > _.get(this._categories_nav_rectangle, 'height', 0);

            if (catTopisInVieport && catBottomInViewport) {
                jQuery('.apt-category-nav').removeClass('nav-selected');
                jQuery((`.apt_cat_${categorySlug}`)).addClass('nav-selected');
                this._handleCatNavAutoScroll(categorySlug);
                break;
            }
        }
    }

    _handleCatNavAutoScroll(categorySlug) {
        jQuery('.apt-categories-nav').each(function(index) {
            const navContainer = jQuery(this);
            const navItem = navContainer.find(`.apt_cat_${categorySlug}`);
            const scrollTo = navContainer[0].scrollLeft + navItem.position().left;
            navContainer[0].scrollLeft = scrollTo;
        })
    }

    _handleMenuItems() {
        this._screen_ui.find('.product_list_item').each(function(index) {
            jQuery(this).click(function(event) {
                event.preventDefault();
                EventBus.getInstance().triggerEvent(Events.OPEN_PRODUCT_SCREEN_REQUEST, { 
                    productId: jQuery(this).attr('data-id'),
                    categoryId: jQuery(this).attr('data-item-category')
                } );
            })
        })
    }

    _handleCartChange(cartItem) {
        if (Cart.getInstance().cartHasItems()) {
            this._apt_screen_content_ui.css('paddingBottom', '80px');
        } else {
            this._apt_screen_content_ui.css('paddingBottom', '0px');
        }

        const productsWithQuantity = Cart.getInstance().getCartQuantityPerProduct();
        
        this._apt_screen_content_ui.find('.product_list_item').each(function(index) {
            const productId = parseInt(jQuery(this).attr('data-id'), 10);
            let quantity = 0;
            for (let i = 0; i < productsWithQuantity.length; i++) {
                const element = productsWithQuantity[i];
                const isProduct = _.get(element, 'porductId', '') === parseInt(productId, 10);
                const productCategoryId = parseInt(_.get(element, 'productCategoryId', ''), 10);
                const isCategory = productCategoryId === parseInt(jQuery(this).attr('data-item-category'), 10);
                if (isProduct && isCategory) {
                    quantity += parseInt(_.get(element, 'quantity', 0), 10);
                }
            }

            const product_list_item_cart_info = jQuery(this).find('.product_list_item_cart_info');
            if (quantity !== 0) {
                product_list_item_cart_info.html(quantity);
                if (!product_list_item_cart_info.hasClass('show')) {
                    product_list_item_cart_info.addClass('show');
                }
            } else {
                if (product_list_item_cart_info.hasClass('show')) {
                    product_list_item_cart_info.removeClass('show');
                }
            }
        })
    }

    _handleEditProductRequest(data) {
        EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_REQUEST);
        EventBus.getInstance().triggerEvent(Events.OPEN_PRODUCT_SCREEN_REQUEST, data);
    }

    _pageClose(data, effect = null) {
        if (!_.isNil(effect)) {
            if (effect === PAGE_EFFECTS.FADE_TOP) {
                this._screen_ui.animate({
                    top: -200,
                    opacity: .6
                }, 700, 'easeInOutQuint', () => {
                    this._isOpen = false;
                })
            }
        } else {
            this._isOpen = false;
        }
    }

    _pageShow(data) {
        this._screen_ui.animate({
            top: 0,
            left: 0,
            opacity: 1
        }, 700, 'easeInOutQuint', () => {
            this._isOpen = true;
        })
    }

    static getInstance() {
        if (!instance) {
            instance = new HomePage(instanceKey);
        }
        return instance;
    }
}
export default HomePage;