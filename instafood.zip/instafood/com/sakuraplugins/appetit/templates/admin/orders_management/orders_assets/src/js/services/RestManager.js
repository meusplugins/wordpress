import DataUtils from '../utils/DataUtils';
import EventBus, { Events, Event } from '../events/EventBus';

let instance;
const instanceKey = 'rest_manager';

class RestManager {
    static POST = 'POST';
    static GET = 'GET';

    API_ROOT = '';

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this.API_ROOT = DataUtils.getInstance().getOption('rest_url');
    }

    post(path, data = {}) {
        return new Promise((resolve, reject) => {
            jQuery.post(`${this.API_ROOT}${path}`, data, (result, status) => {
                if (!status === 'success') {
                    reject({ ...result, status });
                }
                resolve(result);
            });
        })
    }

    get(path, queryVars = {}) {
        return new Promise((resolve, reject) => {
            jQuery.get(`${this.API_ROOT}${path}`, (result, status) => {
                if (!status === 'success') {
                    reject({ ...result, status });
                }
                resolve(result);
            });
        })
    }

    postAjax(action, payload) {
        const data = {action, ...payload};

        return new Promise((resolve, reject) => {
            jQuery.post(ajaxurl, data, function(responseRaw) {
                try {
                    const response = JSON.parse(responseRaw);
                    resolve(response);
                } catch (err) {
                    reject(err);
                    console.log(err);
                }
            });
        })
    }

    changeOrderStatus(ID, order_action, _mode) {
        return new Promise((rsolve, reject) => {
            this.postAjax('order_status', {
                ID, order_action, _mode
            })
            .then(result => {
                rsolve(result);
                EventBus.getInstance().triggerEvent(Events.ORDER_CHANGED_STATUS, { ...result?.data });
            });
        })
    }

    static getInstance() {
        if (!instance) {
            instance = new RestManager(instanceKey);
        }
        return instance;
    }

}
export default RestManager;