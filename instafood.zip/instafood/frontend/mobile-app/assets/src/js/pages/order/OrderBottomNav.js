import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Events, Event } from '../../events/EventBus';
import Order from '../../order/Order';
import DataUtils from '../../utils/DataUtils';
import RestManager from '../../services/RestManager';
import Cart from '../../cart/Cart';

class OrderBottomNav {
    _parrentUI;
    _ui;
    _onOrderConfChanged;
    _onOrderPaymentChanged;
    _shopIsOpenEvent;
    _termsEvent;

    _isPlacingOrder = false;
    _recaptchaToken;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_nav_bottom');
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.update(data));
        EventBus.getInstance().registerEvent(this._onOrderConfChanged);
        this._onOrderPaymentChanged = new Event(Events.ORDER_PAYMENT_METHOD_CHANGED, data => this.update(data));
        EventBus.getInstance().registerEvent(this._onOrderPaymentChanged);
        this._shopIsOpenEvent = new Event(Events.SHOP_IS_OPEN_EVENT, data => this.update(data));
        EventBus.getInstance().registerEvent(this._shopIsOpenEvent);
        this._termsEvent = new Event(Events.USER_TERMS_CHANGED, data => this.update(data));
        EventBus.getInstance().registerEvent(this._termsEvent);
    }
    
    render() {
        const _this = this;
        const template = `
            <div class="cart_nav_bottom">
                <a href="#" class="apt_button primary place_order_btn ${ !Order.getInstance().canPlaceOrder() ? 'inactive' : ''}">
                ${ LanguageUtils.getInstance().getLabel('place_order_label') }
                </a>
            </div>
        `;
        jQuery(template).appendTo(this._ui);
        this._ui.find('.place_order_btn').click(function(event) {
            event.preventDefault();
            if (_this._isPlacingOrder) {
                return;
            }
            if (Order.getInstance().canPlaceOrder()) {
                const orderPayload = Order.getInstance().prepareData();

                if (DataUtils.getInstance().getOption('hasReCaptcha')) {
                    _this._getReCaptchaToken()
                    .then(token => {
                        _this._recaptchaToken = token;
                        _this._placeOrder(orderPayload);
                    })
                    return;
                }
                _this._placeOrder(orderPayload);
            }
        })
    }

    _placeOrder(order) {
        this._isPlacingOrder = true;
        if (!this._ui.find('.place_order_btn').hasClass('inactive')) {
            this._ui.find('.place_order_btn').addClass('inactive')
        }
        
        RestManager.getInstance().post('/order', {
            order, 
            recaptcha_token: DataUtils.getInstance().getOption('hasReCaptcha') ? this._recaptchaToken : '',
        })
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }

            const { data } = result;
            const { _payment_status, ID, _payment_method } = data;

            if (_payment_status === 'PENDING_TRANSACTION') {
                return this._redirect(ID, _payment_method);
            }

            EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_REQUEST);
            EventBus.getInstance().triggerEvent(Events.CLOSE_ORDER_SCREEN_REQUEST, {});
            Cart.getInstance().empty();
            setTimeout(() => {
                EventBus.getInstance().triggerEvent(Events.OPEN_ORDER_COMPLETE_SCREEN_REQUEST, data);
            }, 250);

            this._isPlacingOrder = false;
            if (this._ui.find('.place_order_btn').hasClass('inactive')) {
                this._ui.find('.place_order_btn').removeClass('inactive')
            }
        })
    }

    _redirect(orderId, paymentMethod = 'stripe') {
        if (DataUtils.getInstance().getOption('INSTAFOOD_PREVIEW_MODE')) {
            EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_REQUEST);
            EventBus.getInstance().triggerEvent(Events.CLOSE_ORDER_SCREEN_REQUEST, {});
            Cart.getInstance().empty();
            setTimeout(() => {
                EventBus.getInstance().triggerEvent(Events.OPEN_ORDER_COMPLETE_SCREEN_REQUEST, false);
            }, 250);

            this._isPlacingOrder = false;
            if (this._ui.find('.place_order_btn').hasClass('inactive')) {
                this._ui.find('.place_order_btn').removeClass('inactive')
            }
            return;
        }
        const currentUrl = window.location.href;
        const url = new URL(currentUrl);
        const search_params = url.searchParams;
        
        search_params.set('if_oid', orderId);
        search_params.set('ifp', paymentMethod);

        url.search = search_params.toString();
        var new_url = url.toString();
        window.location.href = new_url;
    }

    update() {
        const place_order_btn = this._ui.find('.place_order_btn');
        if (Order.getInstance().canPlaceOrder()) {
            if (place_order_btn.hasClass('inactive')) {
                place_order_btn.removeClass('inactive')
            }
        } else {
            if (!place_order_btn.hasClass('inactive')) {
                place_order_btn.addClass('inactive')
            }
        }
    }

    _getReCaptchaToken(callback) {
        return new Promise((resolve, reject) => {
            if (!window.grecaptcha) {
                console.log('Missing recaptcha');
                return;
            }
    
            window.grecaptcha.execute(IF_RECAPTCHA_SITE_KEY, {action: 'submit'}).then(function(token) {
                resolve(token);
            })
            .catch(err => {
                resolve('');
            })
        })
    }
}
export default OrderBottomNav;