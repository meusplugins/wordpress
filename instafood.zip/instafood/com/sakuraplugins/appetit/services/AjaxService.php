<?php
namespace com\sakuraplugins\appetit\services;
require_once(plugin_dir_path(__FILE__) . '../utils/UserManagement.php');
require_once(plugin_dir_path(__FILE__) . 'SearchEngine.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . 'TablesService.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/OrderTypes.php');
require_once(plugin_dir_path(__FILE__) . 'WaiterService.php');
require_once(plugin_dir_path(__FILE__) . '../utils/Sanitizer.php');
require_once(plugin_dir_path(__FILE__) . 'PrintNodeService.php');

use com\sakuraplugins\appetit\utils\UserManagement;
use com\sakuraplugins\appetit\utils\Sanitizer;
use com\sakuraplugins\appetit\rest_api\models\Order;
use com\sakuraplugins\appetit\rest_api\models\OrderTypes;
use com\sakuraplugins\appetit\services\PrintNodeService;

class AjaxService {
    static function fetchOrders() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

        $queryRaw = isset($_POST['query']) && is_array($_POST['query']) ? $_POST['query'] : [];
        $sanitizedQuery = Sanitizer::sanitizeDataArrayInput($queryRaw);

        $searchEngine = new SearchEngine($sanitizedQuery);
        $result = $searchEngine->search();
        
        self::respondSuccess($result);
    }

    static function changeOrderStatus() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

		$ID = Sanitizer::sanitizeVal(wp_unslash($_POST['ID'] ?? false));
		$order_action = Sanitizer::sanitizeVal(wp_unslash($_POST['order_action'] ?? false));
		$_mode = Sanitizer::sanitizeVal(wp_unslash($_POST['_mode'] ?? false));
		$_from_lightbox = Sanitizer::sanitizeVal(wp_unslash($_POST['_from_lightbox'] ?? false));


        if (!$ID || !$order_action || !$_mode) {
            self::respondError([esc_html__('Invalid ID order_action or _mode', 'instafood')]);
        }

        $order = new Order();
        $order->findOne($ID);

        $response = [
            'ID' => $ID,
            'order_action' => esc_html($order_action),
            '_mode' => esc_html($_mode),
            '_from_lightbox' => esc_html($_from_lightbox),
        ];

        if ($order_action === 'DELETE') {
            $order->delete();
            return self::respondSuccess($response);
        }

        $order->setOrderStatus($order_action);

        return self::respondSuccess($response);
    }

    static function fetchOrderSingle() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

		$ID = Sanitizer::sanitizeVal(wp_unslash($_POST['ID'] ?? false));

        if (!$ID) {
            self::respondError([esc_html__('Invalid ID', 'instafood')]);
        }

        $order = new Order();
        $order->findOne($ID);
        if (!$order->getProperty('ID')) {
            self::respondError([esc_html__('Order does not exist', 'instafood')]);
        }
        $_orderAll = $order->getAllProperties();
        $lineItemsData = $order->getLineItemsData();

        $_orderType = $_orderAll['_orderType'] ?? '';
        if ($_orderType === OrderTypes::DINEIN) {
            $_table = $_orderAll['_delivery_info']['_table'] ?? '';
            $validTable = TablesService::getInstance()->getTable($_table);

            $_orderAll['_delivery_info']['_table_details'] = [
                '_table' => esc_html($_table),
                '_tableDesc' => $validTable ? esc_html($validTable['tableDesc']) : '',
                '_validTable' => $validTable ? true : false,
            ];
        }

        return self::respondSuccess([
            '_orderAll' => $_orderAll, '_lineItemsData' => $lineItemsData
        ]);
    }

    static function fetchWaiterCalls() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

        $ws = new WaiterService();
        $calls = $ws->getAll();

        return self::respondSuccess([
            'waiter_calls' => $calls
        ]);
    }

    static function deleteWaiterCall() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

		$id = Sanitizer::sanitizeVal(wp_unslash($_POST['id'] ?? false));

        if ($id) {
            $ws = new WaiterService();
            $ws->removeCall($id);
        }

        return self::respondSuccess();
    }

    static function getPrintNodePrinters() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }
        $printers = PrintNodeService::getInstance()->getAvailablePrinters(true);
        return self::respondSuccess(is_array($printers) ? $printers : []);
    }

    static function printRemote() {
        if (!self::canAccess()) {
            self::respondError([esc_html__('You can not access this resource', 'instafood')]);
        }

		$ID = Sanitizer::sanitizeVal(wp_unslash($_POST['ID'] ?? false));
		$printerId = Sanitizer::sanitizeVal(wp_unslash($_POST['printerId'] ?? false));

        if (!$ID || !$printerId) {
            self::respondError([esc_html__('Invalid ID order_action or _mode', 'instafood')]);
        }

        do_action('instafood_manual_remote_print_request', intval($ID), $printerId);
        return self::respondSuccess();
    }

    static function respondSuccess($response = []) {
        echo json_encode([
            'status' => 'OK',
            'data' => $response
        ]);
        wp_die();
    }

    static function respondError($errors = []) {
        echo json_encode([
            'status' => 'FAIL',
            'errors' => $errors,
        ]);
        wp_die();
    }

    static function canAccess() {
        if (current_user_can(UserManagement::ORDERS_PAGE_CAP)) {
            return true;
        }
        return false;
    }
}
?>