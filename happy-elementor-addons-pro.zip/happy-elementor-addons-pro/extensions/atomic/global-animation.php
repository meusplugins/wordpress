<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Object_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;
use Happy_Addons_Pro\Classes\Atomic_Manager;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * One Custom Property of Global Animation: the property and its value(s).
 *
 * The meaning of the generic fields depends on the property (see the
 * "ha-anim-prop" editor control): value..value4 are text/number values,
 * choice/choice2 are select values and color/switch are the color and the
 * switch of the properties that use them.
 */
class Animation_Prop_Item_Prop_Type extends Object_Prop_Type {

	public static function get_key(): string {
		return 'ha-anim-prop';
	}

	protected function define_shape(): array {
		return [
			'property' => String_Prop_Type::make()->enum( array_keys( Global_Animation::properties() ) )->default( 'none' ),
			'value'    => String_Prop_Type::make(),
			'value2'   => String_Prop_Type::make(),
			'value3'   => String_Prop_Type::make(),
			'value4'   => String_Prop_Type::make(),
			'choice'   => String_Prop_Type::make(),
			'choice2'  => String_Prop_Type::make(),
			'color'    => Color_Prop_Type::make(),
			'switch'   => Boolean_Prop_Type::make(),
		];
	}
}

/**
 * The Custom Properties list. The key is what the editor builds for a
 * repeatable control whose items are "ha-anim-prop" (<item key>-array).
 */
class Animation_Prop_Items_Prop_Type extends Array_Prop_Type {

	public static function get_key(): string {
		return 'ha-anim-prop-array';
	}

	protected function define_item_type(): Prop_Type {
		return Animation_Prop_Item_Prop_Type::make();
	}
}

/**
 * Global Animation for the Atomic containers (e-flexbox, e-div-block, e-grid)
 * and the Atomic elements that render a single root (heading, paragraph,
 * image, button, SVG).
 *
 * Same settings and behaviour as the Classic Global Animation extension,
 * including the "Custom Properties" repeater (Add Item, then pick a property
 * and its value). Atomic settings are single valued (not per-breakpoint), so
 * the Classic responsive variants collapse into one value each.
 */
class Global_Animation extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_ga_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid', 'e-heading', 'e-paragraph', 'e-image', 'e-button', 'e-svg' ];
	}

	protected function feature_key() {
		return 'global-animation';
	}

	protected function section_label() {
		return __( 'Animation', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		if ( ! isset( $schema['classes'], $schema['link'] ) ) {
			return false;
		}

		// A container, or one of the single root elements listed in target_types().
		return isset( $schema['tag'] ) || isset( $schema['image'] ) || isset( $schema['svg'] );
	}

	/** Raw Custom Properties of the element being rendered. */
	private $raw_props = [];

	/**
	 * Classic loads the Lenis smooth scroll (happy-sms) with the feature.
	 */
	public function before_render( $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) ) {
			return;
		}

		if ( ! in_array( $element::get_element_type(), $this->target_types(), true ) ) {
			return;
		}

		// The items are read as stored: they are not resolved by Elementor's renderer.
		$this->raw_props = $element->get_settings( $this->prefix() . 'props' );

		parent::before_render( $element );

		$this->raw_props = [];

		$settings = $element->get_atomic_settings();

		if ( ! empty( $settings[ $this->prefix() . 'switcher' ] ) ) {
			Atomic_Manager::enqueue_smooth_scroll();
		}
	}

	/**
	 * Every animatable property, as in the Classic "Property" select.
	 *
	 * @return array<string,string>
	 */
	public static function properties() {
		return [
			'none'                 => __( 'None', 'happy-addons-pro' ),
			'opacity'              => __( 'Opacity', 'happy-addons-pro' ),
			'x'                    => __( 'X', 'happy-addons-pro' ),
			'y'                    => __( 'Y', 'happy-addons-pro' ),
			'width'                => __( 'Width', 'happy-addons-pro' ),
			'height'               => __( 'Height', 'happy-addons-pro' ),
			'maxWidth'             => __( 'Max Width', 'happy-addons-pro' ),
			'maxHeight'            => __( 'Max Height', 'happy-addons-pro' ),
			'minWidth'             => __( 'Min Width', 'happy-addons-pro' ),
			'minHeight'            => __( 'Min Height', 'happy-addons-pro' ),
			'scale'                => __( 'Scale', 'happy-addons-pro' ),
			'scaleX'               => __( 'ScaleX', 'happy-addons-pro' ),
			'scaleY'               => __( 'ScaleY', 'happy-addons-pro' ),
			'rotate'               => __( 'Rotate', 'happy-addons-pro' ),
			'rotateX'              => __( 'RotateX', 'happy-addons-pro' ),
			'rotateY'              => __( 'RotateY', 'happy-addons-pro' ),
			'skew'                 => __( 'Skew', 'happy-addons-pro' ),
			'flip'                 => __( 'Flip', 'happy-addons-pro' ),
			'transformOrigin'      => __( 'TransformOrigin', 'happy-addons-pro' ),
			'transformPerspective' => __( 'Perspective (3D)', 'happy-addons-pro' ),
			'padding'              => __( 'Padding', 'happy-addons-pro' ),
			'color'                => __( 'Color', 'happy-addons-pro' ),
			'background'           => __( 'Background', 'happy-addons-pro' ),
			'border'               => __( 'Border', 'happy-addons-pro' ),
			'borderRadius'         => __( 'Border Radius', 'happy-addons-pro' ),
			'boxShadow'            => __( 'BoxShadow', 'happy-addons-pro' ),
			'blur'                 => __( 'Blur', 'happy-addons-pro' ),
			'delay'                => __( 'Delay', 'happy-addons-pro' ),
			'duration'             => __( 'Duration', 'happy-addons-pro' ),
			'repeat'               => __( 'Repeat', 'happy-addons-pro' ),
			'repeatDelay'          => __( 'Repeat Delay', 'happy-addons-pro' ),
			'force3D'              => __( 'Force3D', 'happy-addons-pro' ),
			'yoyo'                 => __( 'YoYo', 'happy-addons-pro' ),
		];
	}

	protected function extra_props() {
		$type = Animation_Prop_Items_Prop_Type::make()->default( [] );

		$type->set_dependencies(
			Dependency_Manager::make( Dependency_Manager::RELATION_AND )
				->where( [
					'operator' => 'eq',
					'path'     => [ $this->prefix() . 'switcher' ],
					'value'    => true,
					'effect'   => 'hide',
				] )
				->get()
		);

		return [ $this->prefix() . 'props' => $type ];
	}

	protected function extra_controls() {
		$options = function ( array $list ) {
			$out = [];

			foreach ( $list as $value => $label ) {
				$out[] = [ 'value' => (string) $value, 'label' => $label ];
			}

			return $out;
		};

		$props = Repeatable_Control::bind_to( $this->prefix() . 'props' )
			->set_repeaterLabel( __( 'Custom Properties', 'happy-addons-pro' ) )
			->set_child_control_type( 'ha-anim-prop' )
			->set_child_control_props( [
				'properties'     => $options( self::properties() ),
				'origins'        => $options( [
					'0% 0%'     => __( 'Left - Top', 'happy-addons-pro' ),
					'50% 0%'    => __( 'Center - Top', 'happy-addons-pro' ),
					'100% 0%'   => __( 'Right - Top', 'happy-addons-pro' ),
					'0% 50%'    => __( 'Left - Center', 'happy-addons-pro' ),
					'50% 50%'   => __( 'Center - Center', 'happy-addons-pro' ),
					'100% 50%'  => __( 'Right - Center', 'happy-addons-pro' ),
					'0% 100%'   => __( 'Left - Bottom', 'happy-addons-pro' ),
					'50% 100%'  => __( 'Center - Bottom', 'happy-addons-pro' ),
					'100% 100%' => __( 'Right - Bottom', 'happy-addons-pro' ),
					'custom'    => __( 'Custom', 'happy-addons-pro' ),
				] ),
				'flipTypes'      => $options( [
					'mirror' => __( 'Mirror', 'happy-addons-pro' ),
					'3d'     => __( '3D', 'happy-addons-pro' ),
				] ),
				'flipDirections' => $options( [
					'horizontal' => __( 'Horizontal', 'happy-addons-pro' ),
					'vertical'   => __( 'Vertical', 'happy-addons-pro' ),
				] ),
				'borderStyles'   => $options( [
					'solid'  => __( 'Solid', 'happy-addons-pro' ),
					'double' => __( 'Double', 'happy-addons-pro' ),
					'dotted' => __( 'Dotted', 'happy-addons-pro' ),
					'dashed' => __( 'Dashed', 'happy-addons-pro' ),
					'groove' => __( 'Groove', 'happy-addons-pro' ),
				] ),
				'shadowPositions' => $options( [
					'outline' => __( 'Outline', 'happy-addons-pro' ),
					'inset'   => __( 'Inset', 'happy-addons-pro' ),
				] ),
				'labels'         => [
					'property'  => __( 'Property', 'happy-addons-pro' ),
					'value'     => __( 'Value', 'happy-addons-pro' ),
					'skewX'     => __( 'Skew X', 'happy-addons-pro' ),
					'skewY'     => __( 'Skew Y', 'happy-addons-pro' ),
					'flipType'  => __( 'Flip Type', 'happy-addons-pro' ),
					'direction' => __( 'Direction', 'happy-addons-pro' ),
					'rotation'  => __( 'Rotation (deg)', 'happy-addons-pro' ),
					'custom'    => __( 'Custom Value', 'happy-addons-pro' ),
					'width'     => __( 'Width', 'happy-addons-pro' ),
					'style'     => __( 'Style', 'happy-addons-pro' ),
					'color'     => __( 'Color', 'happy-addons-pro' ),
					'horizontal' => __( 'Horizontal (px)', 'happy-addons-pro' ),
					'vertical'  => __( 'Vertical (px)', 'happy-addons-pro' ),
					'blur'      => __( 'Blur (px)', 'happy-addons-pro' ),
					'spread'    => __( 'Spread (px)', 'happy-addons-pro' ),
					'position'  => __( 'Position', 'happy-addons-pro' ),
				],
				'descriptions'   => [
					'opacity'              => __( 'Set opacity: 0 = fully transparent, 1 = fully opaque.', 'happy-addons-pro' ),
					'position'             => __( 'Set position or size with unit. Use % to offset by percentage of the element\'s own width/height (e.g. 50% = element starts at 50% offset and animates to normal position with "From" method). A plain number is px.', 'happy-addons-pro' ),
					'size'                 => __( 'Set size in pixels or percentage, e.g. 600px, 80%.', 'happy-addons-pro' ),
					'scale'                => __( 'Scale factor, e.g. 0.5 or 1.2.', 'happy-addons-pro' ),
					'rotate'               => __( 'Enter rotation in degrees (deg). Positive = clockwise, negative = counter-clockwise. Example: 45, -90, 360.', 'happy-addons-pro' ),
					'skew'                 => __( 'Skew in degrees (deg). Positive or negative. Example: 15, -10.', 'happy-addons-pro' ),
					'flip'                 => __( 'Mirror = negative scale flip. 3D = rotate 180deg (adds perspective for depth).', 'happy-addons-pro' ),
					'transformOrigin'      => __( 'Enter custom transform origin value. Format: "x y" e.g. "0% 100%" or "bottom right".', 'happy-addons-pro' ),
					'transformPerspective' => __( '3D perspective depth in px (acts like CSS perspective, 100-3000). Lower = more dramatic tilt, higher = subtler.', 'happy-addons-pro' ),
					'padding'              => __( 'CSS padding with unit, e.g. 20px or 10px 20px 10px 20px.', 'happy-addons-pro' ),
					'borderRadius'         => __( 'CSS border radius with unit, e.g. 20px, 50% or 10px 20px 10px 20px.', 'happy-addons-pro' ),
					'blur'                 => __( 'Gaussian blur radius. Animates CSS filter: blur(). Use px/em/rem, e.g. 5px (% is not supported by CSS blur).', 'happy-addons-pro' ),
					'delay'                => __( 'Delay before animation starts (in seconds). Example: 0.5', 'happy-addons-pro' ),
					'duration'             => __( 'Animation duration (in seconds). Example: 1', 'happy-addons-pro' ),
					'repeat'               => __( 'Number of repeat cycles. Range: 0–10. 0 = no repeat.', 'happy-addons-pro' ),
					'repeatDelay'          => __( 'Delay between repeat cycles (in seconds). Example: 0.5', 'happy-addons-pro' ),
					'force3D'              => __( 'Enable Force3D to force GPU acceleration for smoother transforms.', 'happy-addons-pro' ),
					'yoyo'                 => __( 'Enable YoYo to make the animation alternate direction on each repeat cycle.', 'happy-addons-pro' ),
				],
			] )
			->set_initialValues( (object) [
				'property' => [ '$$type' => 'string', 'value' => 'none' ],
			] )
			->set_patternLabel( '${value.property.value}' )
			->set_placeholder( __( 'Property', 'happy-addons-pro' ) )
			->set_prop_key( 'ha-anim-prop-array' )
			->set_is_sortable( true )
			->hide_toggle();

		return [ 'easing' => $props ];
	}

	/**
	 * The Custom Properties join the other settings as a plain list.
	 */
	protected function sanitize_config( array $settings ) {
		$config          = parent::sanitize_config( $settings );
		$config['props'] = $this->sanitize_props( $this->raw_props );

		return $config;
	}

	private static function unwrap( $value ) {
		while ( is_array( $value ) && isset( $value['$$type'] ) && array_key_exists( 'value', $value ) ) {
			$value = $value['value'];
		}

		return $value;
	}

	private function sanitize_props( $raw ) {
		$items = self::unwrap( $raw );

		if ( ! is_array( $items ) ) {
			return [];
		}

		$known = self::properties();
		$list  = [];

		foreach ( $items as $item ) {
			$item = self::unwrap( $item );

			if ( ! is_array( $item ) ) {
				continue;
			}

			$property = (string) self::unwrap( $item['property'] ?? 'none' );

			if ( 'none' === $property || ! isset( $known[ $property ] ) ) {
				continue;
			}

			$color = $item['color'] ?? null;
			$entry = [ 'property' => $property ];

			foreach ( [ 'value', 'value2', 'value3', 'value4', 'choice', 'choice2' ] as $key ) {
				$value         = self::unwrap( $item[ $key ] ?? '' );
				$entry[ $key ] = is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
			}

			$entry['color']  = is_array( $color ) && 'color' === ( $color['$$type'] ?? '' ) ? self::sanitize_color( $color['value'] ?? '' ) : '';
			$entry['switch'] = (bool) self::unwrap( $item['switch'] ?? false );

			$list[] = $entry;
		}

		return $list;
	}

	private function positions() {
		return self::trigger_points();
	}

	protected function fields() {
		$on      = [ 'switcher' => true ];
		$scroll  = $on + [ 'trigger_mode' => [ 'scroll', 'playwithscroll' ] ];
		$custom  = $scroll + [ 'wrapper' => 'custom' ];
		$start   = $custom + [ 'anim_start' => 'custom' ];
		$end     = $custom + [ 'anim_end' => 'custom' ];

		return [
			'switcher'              => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable', 'happy-addons-pro' ),
				'description' => __( 'For best results, avoid using Happy Animations and Sticky Pin on the same element.', 'happy-addons-pro' ),
			],
			'animation'             => [
				'type'    => 'enum',
				'default' => 'from',
				'label'   => __( 'Animation', 'happy-addons-pro' ),
				'options' => [
					'from' => __( 'From', 'happy-addons-pro' ),
					'to'   => __( 'To', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'trigger_mode'          => [
				'type'    => 'enum',
				'default' => 'scroll',
				'label'   => __( 'Trigger Mode', 'happy-addons-pro' ),
				'options' => [
					'scroll'         => __( 'On Appearing', 'happy-addons-pro' ),
					'playwithscroll' => __( 'On Scroll', 'happy-addons-pro' ),
					'onPageLoad'     => __( 'On Page Load', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'wrapper'               => [
				'type'    => 'enum',
				'default' => 'default',
				'label'   => __( 'Wrapper', 'happy-addons-pro' ),
				'options' => [
					'default' => __( 'Default', 'happy-addons-pro' ),
					'custom'  => __( 'Custom', 'happy-addons-pro' ),
				],
				'show'    => $scroll,
			],
			'anim_start'            => [
				'type'        => 'enum',
				'default'     => 'top-center',
				'label'       => __( 'Animation Start', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position.', 'happy-addons-pro' ),
				'options'     => $this->positions(),
				'show'        => $custom,
			],
			'anim_start_custom'     => [
				'type'        => 'string',
				'default'     => 'top center',
				'label'       => __( 'Custom Start', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position. Supports offsets like "top top+=100" (100px below the viewport top) or "top top-=100" (100px above the viewport top).', 'happy-addons-pro' ),
				'show'        => $start,
			],
			'anim_end'              => [
				'type'        => 'enum',
				'default'     => 'bottom-center',
				'label'       => __( 'Animation End', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position.', 'happy-addons-pro' ),
				'options'     => $this->positions(),
				'show'        => $custom,
			],
			'anim_end_custom'       => [
				'type'        => 'string',
				'default'     => 'bottom center',
				'label'       => __( 'Custom End', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position. Supports offsets like "bottom bottom+=100" (100px below the viewport bottom) or "bottom bottom-=100" (100px above the viewport bottom).', 'happy-addons-pro' ),
				'show'        => $end,
			],
			'markers'               => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Markers', 'happy-addons-pro' ),
				'description' => __( 'Show ScrollTrigger markers for debugging the start/end positions.', 'happy-addons-pro' ),
				'show'        => $on + [ 'wrapper' => 'custom' ],
			],
			'easing'                => [
				'type'    => 'enum',
				'default' => 'power2.out',
				'label'   => __( 'Easing Functions', 'happy-addons-pro' ),
				'options' => [
					'none'          => __( 'None', 'happy-addons-pro' ),
					'power1.out'    => __( 'Power1 Out', 'happy-addons-pro' ),
					'power2.out'    => __( 'Power2 Out', 'happy-addons-pro' ),
					'power3.out'    => __( 'Power3 Out', 'happy-addons-pro' ),
					'power4.out'    => __( 'Power4 Out', 'happy-addons-pro' ),
					'power1.in'     => __( 'Power1 In', 'happy-addons-pro' ),
					'power2.in'     => __( 'Power2 In', 'happy-addons-pro' ),
					'power3.in'     => __( 'Power3 In', 'happy-addons-pro' ),
					'power4.in'     => __( 'Power4 In', 'happy-addons-pro' ),
					'power1.inOut'  => __( 'Power1 InOut', 'happy-addons-pro' ),
					'power2.inOut'  => __( 'Power2 InOut', 'happy-addons-pro' ),
					'power3.inOut'  => __( 'Power3 InOut', 'happy-addons-pro' ),
					'power4.inOut'  => __( 'Power4 InOut', 'happy-addons-pro' ),
					'back.out'      => __( 'Back Out', 'happy-addons-pro' ),
					'back.in'       => __( 'Back In', 'happy-addons-pro' ),
					'back.inOut'    => __( 'Back InOut', 'happy-addons-pro' ),
					'elastic.out'   => __( 'Elastic Out', 'happy-addons-pro' ),
					'elastic.in'    => __( 'Elastic In', 'happy-addons-pro' ),
					'elastic.inOut' => __( 'Elastic InOut', 'happy-addons-pro' ),
					'bounce.out'    => __( 'Bounce Out', 'happy-addons-pro' ),
					'bounce.in'     => __( 'Bounce In', 'happy-addons-pro' ),
					'bounce.inOut'  => __( 'Bounce InOut', 'happy-addons-pro' ),
					'circ.out'      => __( 'Circ Out', 'happy-addons-pro' ),
					'expo.out'      => __( 'Expo Out', 'happy-addons-pro' ),
					'sine.out'      => __( 'Sine Out', 'happy-addons-pro' ),
					'slowmo'        => __( 'Slowmo', 'happy-addons-pro' ),
					'stepped'       => __( 'Stepped', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],

			'enable_mobile'         => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable On Mobile', 'happy-addons-pro' ),
				'description' => __( 'When disabled, the animation will not run on mobile devices.', 'happy-addons-pro' ),
				'show'        => $on,
			],
		];
	}
}
