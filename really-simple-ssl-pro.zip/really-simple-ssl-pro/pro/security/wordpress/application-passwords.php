<?php defined( 'ABSPATH' ) or die();
/**
 * Disable application passwords
 */
$set_to_value = '__return_false';
if ( rsssl_is_in_deactivation_list('application-passwords') ){
	$set_to_value = '__return_true';
	rsssl_remove_from_deactivation_list('application-passwords');
}
add_filter( 'wp_is_application_passwords_available', $set_to_value );
