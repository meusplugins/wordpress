import EventBus, { Event, Events } from '../../events/EventBus';

let instance;
const instanceKey = '_toast_complete_screen';

class Toast {

    _isOpen = false;
    _ui;
    _onToastEvent;

    init() {
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onToastEvent = new Event(Events.ON_TOAST_REQUEST, data => this._show(data));
        EventBus.getInstance().registerEvent(this._onToastEvent);
    }

    _show({ text, time }) {
        if (jQuery('.appetit_toast')[0]) {
            jQuery('.appetit_toast').remove();
        }
        const template = `
        <div class="appetit_toast primary_color">${ text }</div>
        `
        this._ui = jQuery(template);
        // this._ui.css('top', jQuery(window).height());
        this._ui.appendTo('body');
        this._ui.animate({
            bottom: 0,
        }, 400, 'easeInOutQuint', () => { 
            setTimeout(() => {
                this._hide();
            }, time)
        });
    }

    _hide() {
        this._ui.animate({
            top: jQuery(window).height(),
        }, 600, 'easeInOutQuint', () => { 
            jQuery('.appetit_toast').remove();
        });
    }

    static getInstance() {
        if (!instance) {
            instance = new Toast(instanceKey);
        }
        return instance;
    }
}
export default Toast;