import ProductUtils from '../../utils/ProductUtils';
import LanguageUtils from '../../utils/LanguageUtils';

export class WidgetGroupPayload {
    static ADD = 'ADD';
    static REMOVE = 'REMOVE';

    constructor(choiceId, groupId, method) {
        this.choiceId = parseInt(choiceId, 10);
        this.groupId = parseInt(groupId, 10);
        this.method = method;
    }
}

class WidgetGroupChoose {

    _product;
    _group;
    _parent_ui;
    _widget_ui;
    _onSelect;
    _group_choices = [];
    _group_choices_ui = [];
    _existingSelectedChoices = [];

    constructor(group, product, onSelect, existingSelectedChoices = []) {
        this._group = group;
        this._product = product;
        this._onSelect = onSelect;
        this._existingSelectedChoices = existingSelectedChoices;
    }

    render(parent_ui) {
        this._parent_ui = parent_ui;
        const _this = this;
        this._group_choices = _.get(this._group, 'group_choices', []);

        const choicesArray = this._group_choices.map(choice => {
            const price_display = _.get(choice, 'price_display', '');
            const price_display_decoded = LanguageUtils.getInstance().decodeHtml(price_display);
            const isSelected = _.includes(this._existingSelectedChoices, choice.term_id);
            
            const choiceTemplate = `
            <div class="widget_radio_entry ${isSelected ? 'selected' : ''}" data-id="${choice.term_id}">
                <div class="square_symbol primary_color_border">
                    <div class="square_fill primary_color"><span class="icon-check"></span></div>
                </div>
                <div class="variant_info">${ ProductUtils.getChoiceName(choice) }</div>
                <div class="variant_price">+ ${ price_display_decoded }</div>
            </div>
            `;
            return choiceTemplate;
        })
        
        let requiredInfo = '';
        if (this._hasMinRequired()) {
            const requiredTemplate = _.template(LanguageUtils.getInstance().decodeHtml(LanguageUtils.getInstance().getLabel('product_required_option')));
            const min_choices_num = _.get(this._group, 'post_meta.min_choices_num', '');
            const compiledTemplate = requiredTemplate({ optionsNo: min_choices_num });
            requiredInfo = `<div class="options_required_info info_required">${ compiledTemplate }</div>`
        } else {
            requiredInfo = `<div class="options_required_info optional">${ LanguageUtils.getInstance().getLabel('product_choice_group_optional') }</div>`
        }

        let maxInfo = '';
        if (this._hasMaxRequired()) {
            const product_choiceMaxSelectTemplate = _.template(LanguageUtils.getInstance().decodeHtml(LanguageUtils.getInstance().getLabel('product_choice_group_max_select')));
            const max_choices_num = _.get(this._group, 'post_meta.max_choices_num', '');
            const compiledMaxChoiceTemplate = product_choiceMaxSelectTemplate({ optionsNo: max_choices_num });
            maxInfo = `<div class="max_allowed">(${ compiledMaxChoiceTemplate })</div>`;
        }

        const template = `
        <div class="product_widget" data-group-id="group_id_${_.get(this._group, 'ID', '')}">
            <div class="widget_info mb_15">
                <div class="widget_title">${ ProductUtils.getGroupName(this._group) }</div>
                ${ requiredInfo }
            </div>
            ${ maxInfo }
            <div class="widget_entries">${ choicesArray.join('') }</div>
        </div>
        `;
        this._widget_ui = jQuery(template);
        this._widget_ui.appendTo(this._parent_ui);

        this._widget_ui.find('.widget_radio_entry').each(function(index) {
            const widgetEntry = jQuery(this);
            widgetEntry.click(function(event) {
                event.preventDefault();
                const choiceId = jQuery(this).attr('data-id');
                _this.selectItem(choiceId);
            })
            _this._group_choices_ui.push(widgetEntry);
        })
    }

    selectItem(choiceId, silent = false) {
        for (let i = 0; i < this._group_choices_ui.length; i++) {
            const entry = this._group_choices_ui[i];
            if (entry.attr('data-id') === choiceId) {
                if (entry.hasClass('selected')) {
                    entry.removeClass('selected');
                    this._onSelect(new WidgetGroupPayload(choiceId, this._group.ID, WidgetGroupPayload.REMOVE));
                } else {
                    entry.addClass('selected');
                    this._onSelect(new WidgetGroupPayload(choiceId, this._group.ID, WidgetGroupPayload.ADD));
                }
            }
        }
        this.validate();
    }

    minIsValid(min_choices_num, selectedChoices) {
        if (isNaN(min_choices_num)) {
            return true;
        }
        if (_.isNumber(min_choices_num) && min_choices_num === 0) {
            return true;
        }
        if (_.isNumber(min_choices_num) && selectedChoices.length >= min_choices_num) {
            return true;
        }
        return false;
    }

    maxIsValid(max_choices_num, selectedChoices) {
        if (isNaN(max_choices_num)) {
            return true;
        }
        if (_.isNumber(max_choices_num) && max_choices_num === 0) {
            return true;
        }
        if (_.isNumber(max_choices_num) && selectedChoices.length <= max_choices_num) {
            return true;
        }
        return false;
    }

    validate() {
        const selectedChoices = [];
        for (let i = 0; i < this._group_choices_ui.length; i++) {
            const entry = this._group_choices_ui[i];
            if (entry.hasClass('selected')) {
                selectedChoices.push(entry.attr('data-id'));
            }
        }
        const min_choices_num = parseInt(_.get(this._group, 'post_meta.min_choices_num', ''), 10);
        const max_choices_num = parseInt(_.get(this._group, 'post_meta.max_choices_num', ''), 10);

        const _minIsValid = this.minIsValid(min_choices_num, selectedChoices);
        const _maxIsValid = this.maxIsValid(max_choices_num, selectedChoices);
        if (!_minIsValid && this._widget_ui.find('.info_required')[0]) {
            if (!this._widget_ui.find('.info_required').hasClass('info_error')) {
                this._widget_ui.find('.info_required').addClass('info_error');
            }
        } else if (_minIsValid && this._widget_ui.find('.info_required')[0]) {
            if (this._widget_ui.find('.info_required').hasClass('info_error')) {
                this._widget_ui.find('.info_required').removeClass('info_error');
            }
        }
        if (!_maxIsValid && this._widget_ui.find('.max_allowed')[0]) {
            if (!this._widget_ui.find('.max_allowed').hasClass('info_error')) {
                this._widget_ui.find('.max_allowed').addClass('info_error');
            }
        } else if (_maxIsValid && this._widget_ui.find('.max_allowed')[0]) {
            if (this._widget_ui.find('.max_allowed').hasClass('info_error')) {
                this._widget_ui.find('.max_allowed').removeClass('info_error');
            }
        }
    }

    _hasMinRequired() {
        let out = true;
        const min_choices_num = parseInt(_.get(this._group, 'post_meta.min_choices_num', ''), 10);
        if (isNaN(min_choices_num)) {
            return false;
        }
        if (_.isNumber(min_choices_num) && min_choices_num === 0) {
            return false;
        }
        return out;
    }

    _hasMaxRequired() {
        let out = true;
        const max_choices_num = parseInt(_.get(this._group, 'post_meta.max_choices_num', ''), 10);
        if (isNaN(max_choices_num)) {
            return false;
        }
        if (_.isNumber(max_choices_num) && max_choices_num === 0) {
            return false;
        }
        return out;
    }
}
export default WidgetGroupChoose;