<?php
namespace com\sakuraplugins\appetit\shortcodes;

require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
use com\sakuraplugins\appetit\utils\OptionUtil;

class ShortcodeManager {
    
    function registerShortcodes() {
        add_shortcode('instafood_embedded', [$this, 'renderInstafoodIFrame']);
    }

    function renderInstafoodIFrame($atts, $content = null) {
        $params = shortcode_atts( array(
            'mobile_web_app_info' => esc_html__("We've detected that you're visiting from a mobile device.", 'instafood'),
            'button_label' => esc_html__('Open mobile web app', 'instafood'),
        ), $atts);

        $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
        $mobileAppPageUrl = get_permalink($mobileAppPageId);
        $mobileAppPageUrl = $mobileAppPageUrl ? $mobileAppPageUrl : '';

        $isMobile = wp_is_mobile();

        ob_start();
        $this->renderCss();
        ?>
        <div class="instafood_ui">
			<?php if ($isMobile): ?>
                <p><?= esc_html__($params['mobile_web_app_info']) ?></p>
                <div>
                    <a class="instafood_btn" href="<?= esc_url($mobileAppPageUrl) ?>" target="_blank"><?= esc_html__($params['button_label']) ?></a>
                </div>
            <?php else: ?>
                <iframe class="instafood_iframe" src="<?= esc_url($mobileAppPageUrl) ?>" frameBorder="0"></iframe>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function renderCss() {
        ?>
        <style>
        .instafood_ui {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .instafood_iframe {
            width: 500px;
            height: 600px;
        }
        .instafood_btn:link {
            text-decoration: none;
            padding: .2em 2em;
            border: solid 1px #CCCCCC;
            display: block;
            margin-top: 1em;
            border-radius: 1em;
        }
        .instafood_btn:visited {
        }
        .instafood_btn:hover {
        }
        .instafood_btn:active {
        }
        </style>
        <?php
    }
}
?>