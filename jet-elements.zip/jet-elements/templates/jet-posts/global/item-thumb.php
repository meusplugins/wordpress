<?php
/**
 * Loop item thumbnail
 */
if ( 'yes' !== $this->get_attr( 'show_image' ) || 'background' === $this->get_attr( 'show_image_as' ) ) {
	return;
}

$html = '<div class="post-thumbnail"><a href="%1$s" %2$s><img class="post-thumbnail__img wp-post-image" src="%3$s" alt="%4$s" loading="lazy" %5$s></a></div>';

if ( 'yes' !== $this->get_attr( 'show_post_links' ) ) {
	$html = '<div class="post-thumbnail"><img class="post-thumbnail__img wp-post-image" src="%3$s" alt="%4$s" loading="lazy" %5$s></div>';
}

jet_elements_post_tools()->get_post_image( array(
	'size'        => $this->get_attr( 'thumb_size' ),
	'mobile_size' => $this->get_attr( 'thumb_size' ),
	'class'       => 'post-thumbnail__link',
	'html'        => $html,
	'placeholder' => false,
	'echo'        => true,
) );
