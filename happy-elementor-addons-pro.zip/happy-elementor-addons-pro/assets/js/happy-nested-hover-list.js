"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
!function () {
  "use strict";

  /**
   * Editor-side registration for the Hover Accordion widget.
   *
   * IMPORTANT: We intentionally do NOT override `getTemplate()`.
   *
   * Elementor's "atomic repeaters" (support_improved_repeaters) duplicate a child
   * `.e-con` and re-position it via NestedViewBase.getChildViewContainer()
   * (`.ha-n-hover-list-item:nth-child(index+1)`) after sortViewsByModels(),
   * WITHOUT a full widget re-render. Overriding getTemplate() with a manual
   * full-list rebuild races with that mechanism and, on rapid duplicate/move,
   * every duplicated child collapses into the last item.
   *
   * The native Nested Accordion follows the same rule: the editor view never
   * overrides the template — it relies on the PHP content_template() and a
   * frontend `elementor/nested-container/atomic-repeater` (linkContainer) handler.
   * We mirror that here.
   */
  var registered = false;
  function register() {
    if (registered) {
      return true;
    }
    if (typeof elementor === "undefined" || typeof $e === "undefined") {
      return false;
    }
    var component = $e.components && ($e.components.get("nested-elements/nested-repeater") || $e.components.get("nested-elements"));
    var nestedModule = component && component.exports ? component.exports : null;
    if (!nestedModule || !nestedModule.NestedViewBase || !nestedModule.NestedModelBase) {
      return false;
    }
    var NestedElementBase = elementor.modules && elementor.modules.elements && elementor.modules.elements.types && elementor.modules.elements.types.NestedElementBase;
    if (typeof NestedElementBase !== "function") {
      return false;
    }
    var NestedViewBase = nestedModule.NestedViewBase;

    /**
     * Thin view: only adds editor-only behavior (single-active title toggle).
     * It extends the native nested view and NEVER overrides getTemplate(),
     * so Elementor renders the PHP content_template() and manages child
     * container placement through the native atomic-repeater machinery.
     */
    var HappyNestedHoverListView = /*#__PURE__*/function (_NestedViewBase) {
      function HappyNestedHoverListView() {
        _classCallCheck(this, HappyNestedHoverListView);
        return _callSuper(this, HappyNestedHoverListView, arguments);
      }
      _inherits(HappyNestedHoverListView, _NestedViewBase);
      return _createClass(HappyNestedHoverListView, [{
        key: "events",
        value: function events() {
          var parentEvents = typeof NestedViewBase.prototype.events === "function" ? NestedViewBase.prototype.events.call(this) : {};
          return Object.assign({}, parentEvents, {
            "click .ha-n-hover-list-title": "onTitleClick",
            "keydown .ha-n-hover-list-title": "onTitleKeydown"
          });
        }
      }, {
        key: "onTitleClick",
        value: function onTitleClick(event) {
          var $title = jQuery(event.currentTarget);
          var $clickedItem = $title.closest(".ha-n-hover-list-item");
          var $list = $title.closest(".ha-n-hover-list");
          var wasActive = $clickedItem.hasClass('e-active');
          $list.children(".ha-n-hover-list-item").each(function () {
            var $item = jQuery(this);
            if ($item.hasClass('e-active')) {
              $item.removeClass('e-active');
              $item.children('.ha-n-hover-list-title').removeClass('e-active').attr('aria-expanded', 'false');
            }
          });
          if (!wasActive) {
            $clickedItem.addClass('e-active');
            $title.addClass('e-active').attr('aria-expanded', 'true');
          }
          this.openItemSettings($clickedItem);
        }
      }, {
        key: "openItemSettings",
        value: function openItemSettings($clickedItem) {
          try {
            if (typeof $e === 'undefined') {
              return;
            }
            var widgetContainer = this.container;
            if (!widgetContainer) {
              return;
            }
            var itemIndex = $clickedItem.index();
            $e.run('document/elements/select', {
              container: widgetContainer
            });
            if (itemIndex >= 0) {
              $e.run('document/repeater/select', {
                container: widgetContainer,
                index: itemIndex,
                options: {
                  useHistory: false
                }
              });
            }
          } catch (e) {
            // Selection is best-effort; never block the toggle.
          }
        }
      }, {
        key: "onTitleKeydown",
        value: function onTitleKeydown(event) {
          if ("Enter" !== event.key && " " !== event.key) {
            return;
          }
          event.preventDefault();
          jQuery(event.currentTarget).trigger("click");
        }
      }]);
    }(NestedViewBase);
    var HappyNestedHoverListElement = /*#__PURE__*/function (_NestedElementBase) {
      function HappyNestedHoverListElement() {
        _classCallCheck(this, HappyNestedHoverListElement);
        return _callSuper(this, HappyNestedHoverListElement, arguments);
      }
      _inherits(HappyNestedHoverListElement, _NestedElementBase);
      return _createClass(HappyNestedHoverListElement, [{
        key: "getType",
        value: function getType() {
          return "ha-happy-nested-hover-list";
        }
      }, {
        key: "getView",
        value: function getView() {
          return HappyNestedHoverListView;
        }
      }, {
        key: "getModel",
        value: function getModel() {
          return nestedModule.NestedModelBase;
        }
      }, {
        key: "getInitialConfig",
        value: function getInitialConfig() {
          return Object.assign({}, _superPropGet(HappyNestedHoverListElement, "getInitialConfig", this, 3)([]), {
            defaults: {
              repeater_title_setting: "item_title"
            }
          });
        }
      }]);
    }(NestedElementBase);
    elementor.elementsManager.registerElementType(new HappyNestedHoverListElement());
    registered = true;
    return true;
  }

  // Preferred hook: dispatched once Elementor's nested view base is ready.
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on("elementor/nested-element-type-loaded", register);
  }

  // Fallback polling in case the event was missed.
  jQuery(function () {
    if (registered) {
      return;
    }
    var attempts = 0;
    var interval = setInterval(function () {
      if (register() || ++attempts > 60) {
        clearInterval(interval);
      }
    }, 150);
  });
}();