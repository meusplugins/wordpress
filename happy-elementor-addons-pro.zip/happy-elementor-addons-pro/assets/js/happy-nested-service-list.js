"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
!function () {
  "use strict";

  /**
   * Editor-side registration for the Happy Nested Service List widget.
   *
   * Mirrors happy-nested-hover-list.js: we intentionally do NOT override
   * getTemplate() so Elementor's atomic repeater can manage child container
   * placement through the native nested-elements machinery.
   */
  var registered = false;
  function register() {
    if (registered) {
      return true;
    }
    if (typeof elementor === "undefined" || typeof $e === "undefined") {
      return false;
    }
    var component = $e.components && ($e.components.get("nested-elements/nested-repeater") || $e.components.get("nested-elements"));
    var nestedModule = component && component.exports ? component.exports : null;
    if (!nestedModule || !nestedModule.NestedViewBase || !nestedModule.NestedModelBase) {
      return false;
    }
    var NestedElementBase = elementor.modules && elementor.modules.elements && elementor.modules.elements.types && elementor.modules.elements.types.NestedElementBase;
    if (typeof NestedElementBase !== "function") {
      return false;
    }
    var NestedViewBase = nestedModule.NestedViewBase;
    var HappyNestedServiceListView = /*#__PURE__*/function (_NestedViewBase) {
      function HappyNestedServiceListView() {
        _classCallCheck(this, HappyNestedServiceListView);
        return _callSuper(this, HappyNestedServiceListView, arguments);
      }
      _inherits(HappyNestedServiceListView, _NestedViewBase);
      return _createClass(HappyNestedServiceListView, [{
        key: "events",
        value: function events() {
          var parentEvents = typeof NestedViewBase.prototype.events === "function" ? NestedViewBase.prototype.events.call(this) : {};
          return Object.assign({}, parentEvents, {
            "click .ha-nsl-title-wrap": "onTitleClick",
            "keydown .ha-nsl-title-wrap": "onTitleKeydown"
          });
        }
      }, {
        key: "onTitleClick",
        value: function onTitleClick(event) {
          var $title = jQuery(event.currentTarget);
          var $clickedItem = $title.closest(".ha-nsl-item");
          var $list = $title.closest(".ha-nsl-list");
          var wasActive = $clickedItem.hasClass('e-active');
          $list.children(".ha-nsl-item").each(function () {
            var $item = jQuery(this);
            if ($item.hasClass('e-active')) {
              $item.removeClass('e-active');
            }
          });
          if (!wasActive) {
            $clickedItem.addClass('e-active');
          }
          this.openItemSettings($clickedItem);
        }

        /**
         * The .ha-nsl-title-wrap is plain markup, not a registered
         * Elementor element, so a click never opens the settings panel.
         * Resolve the clicked item's child container and select it so
         * Elementor opens its settings.
         */
      }, {
        key: "openItemSettings",
        value: function openItemSettings($clickedItem) {
          try {
            var childEl = $clickedItem.children('.e-con, .elementor-element').first()[0];
            var childViews = this.children && this.children._views ? Object.values(this.children._views) : [];
            var childView = childViews.find(function (view) {
              return view.el === childEl;
            });
            if (childView && childView.getContainer && typeof $e !== 'undefined') {
              $e.run('editor/documents/elements/select', {
                container: childView.getContainer()
              });
            }
          } catch (e) {
            // Selection is best-effort; never block the toggle.
          }
        }
      }, {
        key: "onTitleKeydown",
        value: function onTitleKeydown(event) {
          if ("Enter" !== event.key && " " !== event.key) {
            return;
          }
          event.preventDefault();
          jQuery(event.currentTarget).trigger("click");
        }
      }]);
    }(NestedViewBase);
    var HappyNestedServiceListElement = /*#__PURE__*/function (_NestedElementBase) {
      function HappyNestedServiceListElement() {
        _classCallCheck(this, HappyNestedServiceListElement);
        return _callSuper(this, HappyNestedServiceListElement, arguments);
      }
      _inherits(HappyNestedServiceListElement, _NestedElementBase);
      return _createClass(HappyNestedServiceListElement, [{
        key: "getType",
        value: function getType() {
          return "ha-nested-service-list";
        }
      }, {
        key: "getView",
        value: function getView() {
          return HappyNestedServiceListView;
        }
      }, {
        key: "getModel",
        value: function getModel() {
          return nestedModule.NestedModelBase;
        }
      }, {
        key: "getInitialConfig",
        value: function getInitialConfig() {
          return Object.assign({}, _superPropGet(HappyNestedServiceListElement, "getInitialConfig", this, 3)([]), {
            defaults: {
              repeater_title_setting: "service_title"
            }
          });
        }
      }]);
    }(NestedElementBase);
    elementor.elementsManager.registerElementType(new HappyNestedServiceListElement());
    registered = true;
    return true;
  }

  // Preferred hook: dispatched once Elementor's nested view base is ready.
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on("elementor/nested-element-type-loaded", register);
  }

  // Fallback polling in case the event was missed.
  jQuery(function () {
    if (registered) {
      return;
    }
    var attempts = 0;
    var interval = setInterval(function () {
      if (register() || ++attempts > 60) {
        clearInterval(interval);
      }
    }, 150);
  });
}();