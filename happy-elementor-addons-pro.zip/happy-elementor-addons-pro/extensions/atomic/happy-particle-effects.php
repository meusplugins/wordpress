<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * Happy Particle Effects for the Atomic containers (e-flexbox, e-div-block, e-grid).
 *
 * Same settings as the Classic Happy Particle Effects extension: Style, custom
 * JSON, Particle Color, Opacity, Flow Direction and the Advanced settings
 * (Number, Size, Speed, Hover Effect). The effect is drawn by particles.js,
 * driven by the Atomic Pro runtime (happy-particle-effects.js).
 */
class Happy_Particle_Effects extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_pe_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	}

	protected function feature_key() {
		return 'happy-particle-effects';
	}

	protected function section_label() {
		return __( 'Happy Particle Effects', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['classes'], $schema['tag'], $schema['link'] )
			&& ! isset( $schema['title'], $schema['image'], $schema['text'], $schema['paragraph'] );
	}

	public function init() {
		parent::init();

		add_action( 'elementor/preview/enqueue_scripts', [ $this, 'enqueue_library' ] );
	}

	/**
	 * particles.js, shared with the Classic extension (same handle).
	 */
	public function enqueue_library() {
		\Happy_Addons_Pro\Classes\Atomic_Manager::register_particles();

		wp_enqueue_script( 'particles' );
	}

	public function before_render( $element ) {
		parent::before_render( $element );

		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) ) {
			return;
		}

		if ( in_array( $element::get_element_type(), $this->target_types(), true ) ) {
			$settings = $element->get_atomic_settings();

			if ( ! empty( $settings[ $this->prefix() . 'switcher' ] ) ) {
				$this->enqueue_library();
			}
		}
	}

	protected function fields() {
		$on      = [ 'switcher' => true ];
		$preset  = $on + [ 'style' => [ 'default', 'nasa', 'snow' ] ];
		$advance = $preset + [ 'advanced' => true ];

		return [
			'switcher'    => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Enable Particle Background', 'happy-addons-pro' ),
			],
			'style'       => [
				'type'    => 'enum',
				'default' => 'nasa',
				'label'   => __( 'Style', 'happy-addons-pro' ),
				'options' => [
					'default' => __( 'Polygon', 'happy-addons-pro' ),
					'nasa'    => __( 'NASA', 'happy-addons-pro' ),
					'snow'    => __( 'Snow', 'happy-addons-pro' ),
					'custom'  => __( 'Custom', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'json'        => [
				'type'        => 'textarea',
				'default'     => '',
				'label'       => __( 'Particle JSON', 'happy-addons-pro' ),
				'description' => __( 'Add custom JSON for the Particle Background. 1. Visit https://vincentgarreau.com/particles.js/ and choose the required attributes for the particles. 2. Once the custom style is created, download the JSON from the "Download current config (json)" link. 3. Copy the JSON code from the downloaded file and paste it here.', 'happy-addons-pro' ),
				'show'        => $on + [ 'style' => 'custom' ],
			],
			'color'       => [
				'type'    => 'color',
				'default' => '',
				'label'   => __( 'Particle Color', 'happy-addons-pro' ),
				'show'    => $preset,
			],
			'opacity'     => [
				'type'    => 'slider',
				'default' => null,
				'min'     => 0,
				'max'     => 1,
				'step'    => 0.1,
				'label'   => __( 'Opacity', 'happy-addons-pro' ),
				'show'    => $preset,
			],
			'direction'   => [
				'type'    => 'enum',
				'default' => 'bottom',
				'label'   => __( 'Flow Direction', 'happy-addons-pro' ),
				'options' => [
					'top'          => __( 'Top', 'happy-addons-pro' ),
					'bottom'       => __( 'Bottom', 'happy-addons-pro' ),
					'left'         => __( 'Left', 'happy-addons-pro' ),
					'right'        => __( 'Right', 'happy-addons-pro' ),
					'top-left'     => __( 'Top Left', 'happy-addons-pro' ),
					'top-right'    => __( 'Top Right', 'happy-addons-pro' ),
					'bottom-left'  => __( 'Bottom Left', 'happy-addons-pro' ),
					'bottom-right' => __( 'Bottom Right', 'happy-addons-pro' ),
				],
				'show'    => $on + [ 'style' => 'snow' ],
			],
			'advanced'    => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Advanced Settings', 'happy-addons-pro' ),
				'show'    => $preset,
			],
			'number'      => [
				'type'    => 'slider',
				'default' => null,
				'min'     => 1,
				'max'     => 500,
				'step'    => 1,
				'label'   => __( 'Number of Particles', 'happy-addons-pro' ),
				'show'    => $advance,
			],
			'size'        => [
				'type'    => 'slider',
				'default' => null,
				'min'     => 1,
				'max'     => 200,
				'step'    => 1,
				'label'   => __( 'Particle Size', 'happy-addons-pro' ),
				'show'    => $advance,
			],
			'speed'       => [
				'type'    => 'slider',
				'default' => null,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'label'   => __( 'Move Speed', 'happy-addons-pro' ),
				'show'    => $advance,
			],
			'interactive' => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable Hover Effect', 'happy-addons-pro' ),
				'description' => __( 'The hover effect does not work in the Elementor editor, or when the content/spacer inside the container fills the entire space and leaves it inaccessible. Adding padding to the container can resolve this.', 'happy-addons-pro' ),
				'show'        => $advance,
			],
		];
	}

	/**
	 * The custom JSON is sent decoded (an invalid one is dropped), not as text.
	 */
	protected function sanitize_config( array $settings ) {
		$config = parent::sanitize_config( $settings );
		$json   = $settings[ $this->prefix() . 'json' ] ?? '';
		$data   = is_string( $json ) && '' !== trim( $json ) ? json_decode( $json, true ) : null;

		$config['json'] = is_array( $data ) ? $data : null;

		return $config;
	}
}
