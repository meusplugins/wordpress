<?php
/**
 * Sync engine for file-managed snippets.
 *
 * With WPCODE_SNIPPETS_FROM_FILES on, the files in the snippets directory are the source of truth and the
 * database holds a read-only mirror so the admin list, error tracking, revisions and the frontend cache keep
 * working. This class detects changed files cheaply (one stat per file), imports changed files through
 * WPCode_Snippet::save() under a lock, deactivates mirrors whose file disappeared, exports the database once
 * when the mode is first enabled (and any file-capable snippet that turns up without a file later), and stores
 * a report of the last run.
 *
 * Timing: pending() and claim_lock() may run as early as plugins_loaded (they only stat files and write one
 * option row). sync() writes posts, which resolves the current user, so it must run at init or later, after
 * core has resolved the user itself (kses_init at init priority 10); running it earlier would pre-empt other
 * plugins' determine_current_user filters. The mode class keeps the snippets whose files changed from running
 * before the import in the request that holds the lock, so their code runs once, in the activation check.
 *
 * @package WPCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_Snippets_File_Sync.
 */
class WPCode_Snippets_File_Sync {

	const LOCK_OPTION            = 'wpcode_snippet_files_sync_lock';
	const REPORT_OPTION          = 'wpcode_snippet_files_sync';
	const EXPORTED_OPTION        = 'wpcode_snippet_files_exported';
	const EXPORT_PENDING_OPTION  = 'wpcode_snippet_files_export_pending';
	const INDEX_STALE_OPTION     = 'wpcode_snippet_files_index_stale';
	const MANIFEST_OPTION        = 'wpcode_snippet_files_manifest';
	const EXPORT_RETRY_TRANSIENT = 'wpcode_snippet_files_export_retry';
	const META_FILE              = '_wpcode_file';
	const META_MISSING           = '_wpcode_file_missing';
	const META_ERROR_HASH        = '_wpcode_file_error_hash';
	const META_KEY               = '_wpcode_file_key';
	const LOCK_TTL               = 60;
	const LOCK_REFRESH           = 20;
	const EXPORT_RETRY_TTL       = 300;
	const EXPORT_PAGE_SIZE       = 100;

	/**
	 * Whether an import is running in this request.
	 *
	 * @var bool
	 */
	protected static $syncing = false;

	/**
	 * Whether an export is running in this request.
	 *
	 * @var bool
	 */
	protected static $exporting = false;

	/**
	 * Whether this request already holds the lock, taken early by claim_lock() for a sync that runs later.
	 *
	 * @var bool
	 */
	protected static $lock_claimed = false;

	/**
	 * Ids of PHP-executing snippets imported in this request; their activation check already ran their code.
	 *
	 * @var int[]
	 */
	protected static $executed_ids = array();

	/**
	 * Whether this instance holds the lock, so export() called from sync() does not take it twice.
	 *
	 * @var bool
	 */
	protected $locked = false;

	/**
	 * The lock timestamp this request last wrote; static because claim_lock() acquires on another instance.
	 *
	 * @var int
	 */
	protected static $lock_value = 0;

	/**
	 * Whether snippets are managed from files.
	 *
	 * @return bool
	 */
	public static function mode_enabled() {
		return defined( 'WPCODE_SNIPPETS_FROM_FILES' ) && WPCODE_SNIPPETS_FROM_FILES;
	}

	/**
	 * Whether an import is running.
	 *
	 * @return bool
	 */
	public static function is_syncing() {
		return self::$syncing;
	}

	/**
	 * Whether an export is running.
	 *
	 * @return bool
	 */
	public static function is_exporting() {
		return self::$exporting;
	}

	/**
	 * Snippet ids whose code already ran in this request through the import's activation check.
	 *
	 * @return int[]
	 */
	public static function executed_ids() {
		return self::$executed_ids;
	}

	/**
	 * Whether the current writer is trusted: the importer or the exporter, never a user, WP-CLI or cron. The
	 * commands and cron reach the mirror only through sync() and export(), which set these flags themselves.
	 *
	 * @return bool
	 */
	public static function is_trusted_context() {
		return self::$syncing || self::$exporting;
	}

	/**
	 * Tell WPCode_Snippet::save() when a trusted writer is at work.
	 *
	 * @param bool $trusted The current value.
	 *
	 * @return bool
	 */
	public static function trusted_context( $trusted ) {
		return $trusted || self::is_trusted_context();
	}

	/**
	 * Ask the next sync to export file-capable snippets that have no file: a snippet untrashed by a user, or
	 * one whose file could not be written. An autoloaded flag, so pending() reads it for free.
	 *
	 * @return void
	 */
	public static function request_export() {
		self::set_flag( self::EXPORT_PENDING_OPTION, true );
	}

	/**
	 * Set or clear one of the autoloaded flags the per-request check reads. The row is kept with '0' rather
	 * than deleted: a missing option costs one query per request without a persistent object cache.
	 *
	 * @param string $option The option name.
	 * @param bool   $on     The value.
	 *
	 * @return void
	 */
	protected static function set_flag( $option, $on ) {
		update_option( $option, $on ? '1' : '0', true );
	}

	/**
	 * Whether this process may write snippet files. When core disallows file changes (DISALLOW_FILE_MODS or the
	 * file_mod_allowed filter) only WP-CLI exports, so no web request writes code to disk; snippets without a
	 * file keep running from the database.
	 *
	 * @return bool
	 */
	public static function file_writes_allowed() {
		return wp_is_file_mod_allowed( 'wpcode_snippet_files' ) || ( defined( 'WP_CLI' ) && WP_CLI );
	}

	/**
	 * Whether an export is due and not backing off after a failure: the one-time export, or a requested one.
	 * The autoloaded flags decide first; the transient is read only when one of them says an export is due.
	 *
	 * @return bool
	 */
	protected static function export_due() {
		if ( ! self::file_writes_allowed() ) {
			return false;
		}
		if ( get_option( self::EXPORTED_OPTION ) && ! get_option( self::EXPORT_PENDING_OPTION ) ) {
			return false;
		}

		return ! get_transient( self::EXPORT_RETRY_TRANSIENT );
	}

	/**
	 * What this request has to sync, decided cheaply enough for plugins_loaded: no database writes, no user
	 * resolution. Null when nothing is due. Otherwise 'all' says whether every snippet may be re-imported (files
	 * on disk but no manifest to compare against), and 'ids' lists the mirrors whose file changed or
	 * disappeared, so the mode can keep exactly those from running before the import.
	 *
	 * @return array|null array( 'all' => bool, 'ids' => int[] ) or null.
	 */
	public static function pending() {
		// XML-RPC requests never import: the post-type gate refuses every snippet write there.
		if ( ! self::mode_enabled() || ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || wp_installing() ) {
			return null;
		}
		$changes = ( new self() )->pending_changes();
		if ( null === $changes && self::export_due() ) {
			// An export writes files from the mirror and runs no snippet code.
			return array(
				'all' => false,
				'ids' => array(),
			);
		}

		return $changes;
	}

	/**
	 * Take the sync lock now for a sync that runs later in this request, so only the request that will import
	 * changes what runs. Released at shutdown if the sync never consumed it.
	 *
	 * @return bool Whether this request holds the lock.
	 */
	public static function claim_lock() {
		if ( self::$lock_claimed ) {
			return true;
		}
		if ( ! ( new self() )->acquire_lock() ) {
			return false;
		}
		self::$lock_claimed = true;
		add_action( 'shutdown', array( __CLASS__, 'release_unused_lock' ), 0 );

		return true;
	}

	/**
	 * Release a claimed lock that no sync consumed in this request.
	 *
	 * @return void
	 */
	public static function release_unused_lock() {
		if ( self::$lock_claimed ) {
			self::$lock_claimed = false;
			( new self() )->release_lock();
		}
	}

	/**
	 * Run the sync the mode scheduled: the export when it is due, the import when a file changed. Never under
	 * WP-CLI, where the command is the trigger, and never while WordPress is installing.
	 *
	 * @return void
	 */
	public static function maybe_sync() {
		if ( null === self::pending() ) {
			return;
		}
		( new self() )->sync();
	}

	/**
	 * An explicit sync (the Sync now button, the WP-CLI command): a failed export is retried at once instead
	 * of waiting out its back-off, unless nothing is written anyway.
	 *
	 * @param bool $force   Re-import every file, not only the changed ones.
	 * @param bool $dry_run Report what would change without writing anything.
	 *
	 * @return array The report; see sync().
	 */
	public static function sync_now( $force = false, $dry_run = false ) {
		if ( ! $dry_run ) {
			delete_transient( self::EXPORT_RETRY_TRANSIENT );
		}

		return ( new self() )->sync( $force, $dry_run );
	}

	/**
	 * The stored report of the last sync.
	 *
	 * @return array
	 */
	public static function report() {
		$report = get_option( self::REPORT_OPTION, array() );

		return is_array( $report ) ? $report : array();
	}

	/**
	 * Keep a copy of the manifest outside the index, for sites where the index file cannot be written. Stored
	 * before every index write, so it is never older than the index.
	 *
	 * @param array $files     The manifest entries.
	 * @param int   $dir_mtime The directory mtime recorded with them.
	 *
	 * @return void
	 */
	public static function store_manifest( $files, $dir_mtime ) {
		update_option(
			self::MANIFEST_OPTION,
			array(
				'files'     => $files,
				'dir_mtime' => (int) $dir_mtime,
			),
			false
		);
	}

	/**
	 * Remember whether the last index write succeeded. While it fails, the change check reads the manifest
	 * copy in the options table, so a stale index cannot make every request re-import the same files.
	 *
	 * @param bool $written Whether the index was written.
	 *
	 * @return void
	 */
	protected static function record_index_write( $written ) {
		self::set_flag( self::INDEX_STALE_OPTION, ! $written );
	}

	/**
	 * The manifest the change check compares against: from the index when it is readable and known to be
	 * current, else from the copy in the options table, else null.
	 *
	 * @return array|null array( 'files' => array, 'dir_mtime' => int ) or null.
	 */
	public static function manifest() {
		if ( ! get_option( self::INDEX_STALE_OPTION ) ) {
			$index = WPCode_Snippets_File_Handler::read_index();
			if ( is_array( $index ) && isset( $index['files'], $index['dir_mtime'] ) && is_array( $index['files'] ) ) {
				return array(
					'files'     => $index['files'],
					'dir_mtime' => (int) $index['dir_mtime'],
				);
			}
		}
		$stored = get_option( self::MANIFEST_OPTION );
		if ( is_array( $stored ) && isset( $stored['files'], $stored['dir_mtime'] ) && is_array( $stored['files'] ) ) {
			return $stored;
		}

		return null;
	}

	/**
	 * Hash a source file, including the SCSS companion when present.
	 *
	 * @param string $dir  The snippets directory with a trailing slash.
	 * @param string $file The relative file name.
	 *
	 * @return string
	 */
	public static function hash_file( $dir, $file ) {
		$hash = (string) md5_file( $dir . $file );
		if ( 'scss' === strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
			$companion = $dir . WPCode_Snippet_File::companion_for( $file );
			if ( file_exists( $companion ) ) {
				$hash .= md5_file( $companion );
			}
		}

		return $hash;
	}

	/**
	 * Source files present in the directory, sorted.
	 *
	 * @return string[] Relative file names.
	 */
	public static function list_source_files() {
		$dir     = WPCode_Snippets_File_Handler::get_snippets_dir();
		$entries = is_dir( $dir ) ? scandir( $dir ) : false;
		$files   = array();
		if ( ! is_array( $entries ) ) {
			return $files;
		}
		foreach ( $entries as $entry ) {
			if ( WPCode_Snippet_File::is_snippet_file( $entry ) && is_file( $dir . $entry ) ) {
				$files[] = $entry;
			}
		}
		sort( $files, SORT_STRING );

		return $files;
	}

	/**
	 * Mirror snippets keyed by their file name, in one query.
	 *
	 * @param array $warnings Collected warnings, by reference (file to message).
	 *
	 * @return array Relative file name to post id.
	 */
	public static function managed_files( &$warnings = array() ) {
		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one query for every managed snippet instead of one meta lookup each.
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_type = %s AND p.post_status IN ( 'publish', 'draft', 'pending', 'private', 'future' ) ORDER BY pm.post_id ASC",
				self::META_FILE,
				wpcode_get_post_type()
			)
		);

		$files = array();
		foreach ( (array) $rows as $row ) {
			$file = (string) $row->meta_value;
			$id   = (int) $row->post_id;
			if ( '' === $file ) {
				continue;
			}
			if ( isset( $files[ $file ] ) ) {
				/* translators: 1: a snippet id, 2: another snippet id, 3: the id that is kept. */
				$warnings[ $file ] = sprintf( __( 'Snippets #%1$d and #%2$d both claim this file; #%3$d is used.', 'wpcode-premium' ), $files[ $file ], $id, $files[ $file ] );
				continue;
			}
			$files[ $file ] = $id;
		}

		return $files;
	}

	/**
	 * Ids of file-capable snippets that have no file yet, one page at a time, in id order.
	 *
	 * @param int $offset Rows to skip: the snippets an earlier page failed to export, which stay in this set.
	 *
	 * @return int[]
	 */
	protected function unmanaged_snippet_ids( $offset = 0 ) {
		global $wpdb;

		$types        = array_merge( WPCode_Snippet_File::PHP_TYPES, WPCode_Snippet_File::ASSET_TYPES );
		$placeholders = implode( ', ', array_fill( 0, count( $types ), '%s' ) );
		$params       = array_merge( $types, array( self::META_FILE, wpcode_get_post_type(), self::EXPORT_PAGE_SIZE, max( 0, (int) $offset ) ) );

		// Build query structure with sprintf, escaping prepare() placeholders with %%.
		$query = sprintf(
			"SELECT DISTINCT p.ID FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'wpcode_type'
			INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id AND t.slug IN ( %s )
			LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %%s
			WHERE p.post_type = %%s AND p.post_status IN ( 'publish', 'draft', 'pending', 'private', 'future' ) AND pm.meta_id IS NULL
			ORDER BY p.ID ASC LIMIT %%d OFFSET %%d",
			$placeholders
		);

		$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one paged query joining the type term and the missing meta.
			$wpdb->prepare( $query, $params ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $query holds only placeholders and table names.
		);

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Build the manifest stored in the index: every source file present, its owning snippet id (0 when none),
	 * content hash, mtime and size, plus SCSS companions.
	 *
	 * @return array Relative file name to entry.
	 */
	public static function build_manifest() {
		clearstatcache();
		$dir      = WPCode_Snippets_File_Handler::get_snippets_dir();
		$managed  = self::managed_files();
		$manifest = array();
		foreach ( self::list_source_files() as $file ) {
			$path              = $dir . $file;
			$manifest[ $file ] = array(
				'id'    => isset( $managed[ $file ] ) ? $managed[ $file ] : 0,
				'hash'  => self::hash_file( $dir, $file ),
				'mtime' => (int) filemtime( $path ),
				'size'  => (int) filesize( $path ),
			);
			if ( 'scss' === strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
				$companion = WPCode_Snippet_File::companion_for( $file );
				if ( file_exists( $dir . $companion ) ) {
					$manifest[ $companion ] = array(
						'id'        => $manifest[ $file ]['id'],
						'companion' => true,
						'mtime'     => (int) filemtime( $dir . $companion ),
						'size'      => (int) filesize( $dir . $companion ),
					);
				}
			}
		}

		return $manifest;
	}

	/**
	 * What differs between the directory and the manifest. One stat per file (PHP caches the stat, so the
	 * three checks per path are one syscall); no file is read.
	 *
	 * @return array|null array( 'all' => bool, 'ids' => int[] ), or null when nothing changed.
	 */
	public function pending_changes() {
		$manifest = self::manifest();
		$dir      = WPCode_Snippets_File_Handler::get_snippets_dir();
		if ( null === $manifest ) {
			// Files but nothing to compare them against: every one of them may be imported. No files: nothing to do.
			if ( ! is_dir( $dir ) || ! self::list_source_files() ) {
				return null;
			}

			return array(
				'all' => true,
				'ids' => array(),
			);
		}
		$changed = ! is_dir( $dir ) || (int) filemtime( $dir ) !== (int) $manifest['dir_mtime'];
		$ids     = array();
		foreach ( $manifest['files'] as $file => $entry ) {
			$path = $dir . $file;
			if ( ! file_exists( $path ) || (int) filemtime( $path ) !== (int) $entry['mtime'] || (int) filesize( $path ) !== (int) $entry['size'] ) {
				$changed = true;
				if ( ! empty( $entry['id'] ) ) {
					$ids[] = (int) $entry['id'];
				}
			}
		}
		if ( ! $changed ) {
			return null;
		}

		return array(
			'all' => false,
			'ids' => array_values( array_unique( $ids ) ),
		);
	}

	/**
	 * Under the lock: export once when the mode is first enabled, export file-capable snippets that have no
	 * file, import changed files, deactivate orphans, rebuild the index and store the report.
	 *
	 * @param bool $force   Re-import every file, not only the changed ones, and retry a failed export at once.
	 * @param bool $dry_run Report what would change without writing anything; 'exported' then lists the files an export would write.
	 *
	 * @return array The report: time, dry_run, imported, exported, unchanged, removed, errors (per import file),
	 *               export_error (the directory-level export failure, this run's or a still-standing earlier one),
	 *               export_errors (per exported snippet), warnings, skipped.
	 */
	public function sync( $force = false, $dry_run = false ) {
		$report = array(
			'time'          => time(),
			'dry_run'       => (bool) $dry_run,
			'imported'      => array(),
			'exported'      => array(),
			'unchanged'     => 0,
			'removed'       => array(),
			'errors'        => array(),
			'export_error'  => '',
			'export_errors' => array(),
			'warnings'      => array(),
			'skipped'       => false,
		);

		// An export that is still failing (the one-time export or a later one) stays visible in the report.
		$previous = self::report();
		if ( ! empty( $previous['export_error'] ) && ( ! get_option( self::EXPORTED_OPTION ) || get_option( self::EXPORT_PENDING_OPTION ) ) ) {
			$report['export_error'] = (string) $previous['export_error'];
		}

		if ( ! $this->acquire_lock() ) {
			$report['skipped'] = true;

			return $report;
		}

		// Resolve the current user before touching kses: resolving it later, inside the first post write, would
		// re-run kses_init() and put the filters back mid-save.
		get_current_user_id();
		$kses_was_active = (bool) has_filter( 'content_save_pre', 'wp_filter_post_kses' );
		if ( $kses_was_active ) {
			kses_remove_filters();
		}
		// Every save() rebuilds the whole snippet cache; do it once, after the loop.
		add_filter( 'wpcode_cache_active_snippets', '__return_false' );

		try {
			$dir = WPCode_Snippets_File_Handler::get_snippets_dir();

			if ( $dry_run ) {
				$this->preview_export( $report );
			} elseif ( self::file_writes_allowed() && ! get_option( self::EXPORTED_OPTION ) && ( $force || ! get_transient( self::EXPORT_RETRY_TRANSIENT ) ) ) {
				$exported = $this->export();
				if ( is_wp_error( $exported ) ) {
					$report['export_error'] = $exported->get_error_message();
					// Do not retry on every request while the directory stays unwritable.
					set_transient( self::EXPORT_RETRY_TRANSIENT, 1, self::EXPORT_RETRY_TTL );
				} else {
					$report['export_error']  = '';
					$report['exported']      = $exported['exported'];
					$report['export_errors'] = $exported['errors'];
				}
			}

			$just_exported = $dry_run || ! self::file_writes_allowed() ? array() : $this->export_unmanaged( $dir, $report, $force );
			$manifest      = self::manifest();
			$manifest      = $manifest ? $manifest['files'] : array();
			$managed       = self::managed_files( $report['warnings'] );
			$files         = self::list_source_files();
			$present       = array_fill_keys( $files, true );

			foreach ( $files as $file ) {
				if ( isset( $just_exported[ $file ] ) ) {
					// Written from the mirror a moment ago; nothing to import.
					$report['unchanged'] ++;
					continue;
				}
				$hash      = self::hash_file( $dir, $file );
				$id        = isset( $managed[ $file ] ) ? $managed[ $file ] : 0;
				$unchanged = $id && isset( $manifest[ $file ]['hash'] ) && $manifest[ $file ]['hash'] === $hash && ! get_post_meta( $id, self::META_MISSING, true );

				if ( ! $force && $unchanged ) {
					$report['unchanged'] ++;
					continue;
				}

				$parsed = WPCode_Snippet_File::parse( $dir . $file );
				if ( is_wp_error( $parsed ) ) {
					$report['errors'][ $file ] = $parsed->get_error_message();
					continue;
				}
				$renamed_from = false;
				if ( '' !== $parsed['key'] ) {
					$claimed = $this->claim_key( $parsed['key'], $id, $present, $managed );
					if ( false === $claimed ) {
						/* translators: %s: the Key header value. */
						$parsed['warnings'][] = sprintf( __( 'Another snippet file already uses Key "%s"; this file is imported without it. Change or remove its Key header.', 'wpcode-premium' ), $parsed['key'] );
						$parsed['key']        = '';
					} elseif ( $claimed ) {
						$id           = $claimed;
						$renamed_from = array_search( $id, $managed, true );
						// Claimed now, so a second file with the same Key in this sync sees it as taken.
						$managed[ $file ] = $id;
						/* translators: %d: the snippet id. */
						$parsed['warnings'][] = sprintf( __( 'Renamed: its Key matches snippet #%d, which keeps this file.', 'wpcode-premium' ), $id );
					}
				}
				if ( ! empty( $parsed['warnings'] ) ) {
					$report['warnings'][ $file ] = implode( ' ', $parsed['warnings'] );
				}
				if ( in_array( $parsed['code_type'], array( 'php', 'universal' ), true ) && WPCode_Access::php_disabled() ) {
					$report['errors'][ $file ] = __( 'PHP snippets are disabled on this site.', 'wpcode-premium' );
					continue;
				}
				if ( $dry_run ) {
					$report['imported'][] = $file;
				} else {
					if ( ! $this->refresh_lock() ) {
						$report['warnings']['lock'] = __( 'Another sync took over the lock; it imports the remaining files.', 'wpcode-premium' );
						break;
					}
					$this->import_file( $dir, $file, $hash, $parsed, $id, $report );
				}
				// The old file of a rename leaves the orphan pass only once its new file imported.
				if ( false !== $renamed_from && in_array( $file, $report['imported'], true ) ) {
					unset( $managed[ $renamed_from ] );
				}
			}

			foreach ( $managed as $file => $id ) {
				if ( ! $this->locked ) {
					break;
				}
				if ( isset( $present[ $file ] ) ) {
					continue;
				}
				// Report an orphan once, but keep deactivating it until that succeeds.
				if ( ! get_post_meta( $id, self::META_MISSING, true ) ) {
					$report['removed'][] = $file;
				}
				if ( $dry_run ) {
					continue;
				}
				$snippet = wpcode_get_snippet( $id );
				if ( $snippet->is_active() ) {
					if ( ! $this->refresh_lock() ) {
						break;
					}
					self::$syncing = true;
					$snippet->deactivate();
					self::$syncing = false;
				}
				update_post_meta( $id, self::META_MISSING, 1 );
			}

			// Finalize shared state only while we still hold the lock: a sync that took it over owns the manifest,
			// index and report, so rewriting them here would record files this run never imported as already seen.
			if ( ! $dry_run && $this->locked ) {
				remove_filter( 'wpcode_cache_active_snippets', '__return_false' );
				if ( $report['imported'] || $report['removed'] || $report['exported'] ) {
					wpcode()->cache->cache_all_loaded_snippets();
				}
				$written = WPCode_Snippets_File_Handler::build_index_file( true );
				self::record_index_write( $written );
				if ( ! $written ) {
					$report['warnings']['index.php'] = __( 'The index file could not be written; the change check uses the copy stored in the database until it can.', 'wpcode-premium' );
				}
				update_option( self::REPORT_OPTION, $report, false );
			}
		} finally {
			self::$syncing = false;
			remove_filter( 'wpcode_cache_active_snippets', '__return_false' );
			wpcode()->execute->set_activation_code_slashed( false );
			if ( $kses_was_active ) {
				kses_init_filters();
			}
			// A lock lost to another sync is that sync's to release.
			if ( $this->locked ) {
				$this->release_lock();
			}
		}

		return $report;
	}

	/**
	 * List, without writing, the files an export would create for every file-capable snippet that has none.
	 *
	 * @param array $report The dry-run report, by reference.
	 *
	 * @return void
	 */
	protected function preview_export( &$report ) {
		$dir    = WPCode_Snippets_File_Handler::get_snippets_dir();
		$taken  = is_dir( $dir ) ? array_values( (array) scandir( $dir ) ) : array();
		$offset = 0;
		do {
			$ids = $this->unmanaged_snippet_ids( $offset );
			foreach ( $ids as $id ) {
				$snippet = new WPCode_Snippet( $id );
				if ( ! $snippet->get_id() || ! WPCode_Snippet_File::is_file_type( $snippet->get_code_type() ) ) {
					continue;
				}
				$file                 = WPCode_Snippet_File::slug_for( $snippet, $taken ) . '.' . WPCode_Snippet_File::extension_for( $snippet->get_code_type() );
				$taken[]              = $file;
				$report['exported'][] = $file;
			}
			// Nothing is written, so the set does not shrink: page by offset.
			$offset += self::EXPORT_PAGE_SIZE;
		} while ( count( $ids ) === self::EXPORT_PAGE_SIZE );
	}

	/**
	 * Write every file-capable snippet that has no file yet, remove the legacy md5 files it replaces, and
	 * prepare the directory for Git. Runs once when the mode is enabled; safe to run again. Takes the sync lock
	 * unless the calling sync() already holds it; when another sync holds it the report says 'skipped'.
	 *
	 * @return array|WP_Error The report (exported, removed_legacy, errors, skipped), or an error when the directory is not writable.
	 */
	public function export() {
		$report = array(
			'exported'       => array(),
			'removed_legacy' => 0,
			'errors'         => array(),
			'skipped'        => false,
		);

		if ( ! self::file_writes_allowed() ) {
			return new WP_Error( 'file_mods_disallowed', __( 'DISALLOW_FILE_MODS is set, so snippet files are written only by "wp wpcode snippets export".', 'wpcode-premium' ) );
		}

		$dir = WPCode_Snippets_File_Handler::get_snippets_dir();
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! wp_is_writable( $dir ) ) {
			/* translators: %s: the directory path. */
			return new WP_Error( 'not_writable', sprintf( __( 'The snippets directory %s is not writable.', 'wpcode-premium' ), $dir ) );
		}

		$own_lock = ! $this->locked;
		if ( $own_lock && ! $this->acquire_lock() ) {
			$report['skipped'] = true;

			return $report;
		}

		try {
			$failed = $this->export_all( $dir, $report );
			if ( is_wp_error( $failed ) ) {
				return $failed;
			}

			// Git ignores the generated index; Apache refuses direct requests (nginx sites rely on the ABSPATH guard).
			if ( ! file_exists( $dir . '.gitignore' ) ) {
				file_put_contents( $dir . '.gitignore', "index.php\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}
			if ( ! file_exists( $dir . '.htaccess' ) ) {
				file_put_contents( $dir . '.htaccess', "deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}

			self::record_index_write( WPCode_Snippets_File_Handler::build_index_file( true ) );
			// Autoloaded: pending() reads it on every request in the mode.
			update_option( self::EXPORTED_OPTION, time(), true );
			$this->settle_export( $failed );
			// Run on its own (WP-CLI export), no sync rewrites the stored report: drop the failure it fixed.
			$stored = $own_lock ? self::report() : array();
			if ( ! empty( $stored['export_error'] ) ) {
				$stored['export_error'] = '';
				update_option( self::REPORT_OPTION, $stored, false );
			}
		} finally {
			if ( $own_lock && $this->locked ) {
				$this->release_lock();
			}
		}

		return $report;
	}

	/**
	 * Export file-capable snippets that have no file although the one-time export already ran: a snippet
	 * untrashed later, or one whose file write failed. Writes their files from the mirror; nothing to import.
	 *
	 * @param string $dir    The snippets directory.
	 * @param array  $report The sync report, by reference.
	 * @param bool   $force  Retry although an earlier export failure is still backing off.
	 *
	 * @return array Relative file names written in this run, as keys.
	 */
	protected function export_unmanaged( $dir, &$report, $force = false ) {
		if ( ! get_option( self::EXPORTED_OPTION ) || ( ! $force && get_transient( self::EXPORT_RETRY_TRANSIENT ) ) ) {
			return array();
		}
		// A new attempt replaces an earlier failure; this one sets it again if it fails too.
		$report['export_error'] = '';
		$ids                    = $this->unmanaged_snippet_ids();
		if ( empty( $ids ) ) {
			$this->settle_export( 0 );

			return array();
		}
		if ( ! wp_is_writable( $dir ) ) {
			/* translators: %s: the directory path. */
			$report['export_error'] = sprintf( __( 'The snippets directory %s is not writable.', 'wpcode-premium' ), $dir );
			$this->settle_export( count( $ids ) );

			return array();
		}

		$partial = array(
			'exported'       => array(),
			'removed_legacy' => 0,
			'errors'         => array(),
		);
		$failed  = $this->export_all( $dir, $partial, $ids );
		if ( is_wp_error( $failed ) ) {
			$report['export_error'] = $failed->get_error_message();
			$failed                 = 1;
		}
		$this->settle_export( $failed );

		$report['exported']      = array_merge( $report['exported'], $partial['exported'] );
		$report['export_errors'] = array_merge( $report['export_errors'], $partial['errors'] );

		return array_fill_keys( $partial['exported'], true );
	}

	/**
	 * After an export: nothing left without a file clears the request flag; failures keep it set and back off
	 * for a while, so a snippet that cannot be written is retried every few minutes rather than on every request.
	 *
	 * @param int $failed How many snippets stayed without a file.
	 *
	 * @return void
	 */
	protected function settle_export( $failed ) {
		if ( $failed > 0 ) {
			self::request_export();
			set_transient( self::EXPORT_RETRY_TRANSIENT, 1, self::EXPORT_RETRY_TTL );
		} else {
			self::set_flag( self::EXPORT_PENDING_OPTION, false );
			delete_transient( self::EXPORT_RETRY_TRANSIENT );
		}
	}

	/**
	 * Export every unmanaged file-capable snippet, one page at a time. Exported snippets leave the unmanaged
	 * set; the ones that failed stay in it, ahead of every unseen id, so the next page starts past them.
	 *
	 * @param string     $dir        The snippets directory.
	 * @param array      $report     The export report (exported, removed_legacy, errors), by reference.
	 * @param int[]|null $first_page The first page of ids when the caller already fetched it.
	 *
	 * @return int|WP_Error How many snippets stayed without a file, or an error when the directory failed.
	 */
	protected function export_all( $dir, &$report, $first_page = null ) {
		$taken  = array_values( (array) scandir( $dir ) );
		$failed = 0;

		self::$exporting = true;
		try {
			$ids = null === $first_page ? $this->unmanaged_snippet_ids() : $first_page;
			while ( true ) {
				foreach ( $ids as $id ) {
					if ( ! $this->refresh_lock() ) {
						return new WP_Error( 'lock_lost', __( 'Another sync took over the lock before the export finished.', 'wpcode-premium' ) );
					}
					$result = $this->export_snippet( new WPCode_Snippet( $id ), $dir, $taken, $report );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
					// Only a snippet that stays in the unmanaged set moves the next page's offset.
					if ( false === $result ) {
						$failed ++;
					}
				}
				if ( count( $ids ) < self::EXPORT_PAGE_SIZE ) {
					break;
				}
				$ids = $this->unmanaged_snippet_ids( $failed );
			}
		} finally {
			self::$exporting = false;
		}

		return $failed;
	}

	/**
	 * Write one snippet's file(s), set its file meta and remove the generated md5 file it replaces, from the
	 * legacy directory and from the snippets directory itself (they differ under WPCODE_SNIPPETS_DIR).
	 *
	 * @param WPCode_Snippet $snippet The snippet.
	 * @param string         $dir     The snippets directory.
	 * @param string[]       $taken   File names already in the directory, by reference.
	 * @param array          $report  The export report, by reference.
	 *
	 * @return bool|null|WP_Error True when the snippet now has a file, false when it stays without one, null when it left the unmanaged set meanwhile, an error when the directory failed.
	 */
	protected function export_snippet( $snippet, $dir, &$taken, &$report ) {
		if ( ! $snippet->get_id() || ! WPCode_Snippet_File::is_file_type( $snippet->get_code_type() ) || get_post_meta( $snippet->get_id(), self::META_FILE, true ) ) {
			return null;
		}
		$slug = WPCode_Snippet_File::slug_for( $snippet, $taken );
		$file = $slug . '.' . WPCode_Snippet_File::extension_for( $snippet->get_code_type() );
		$key  = (string) get_post_meta( $snippet->get_id(), self::META_KEY, true );
		if ( '' === $key ) {
			$key = strtolower( wp_generate_password( 12, false ) );
		}
		$built = WPCode_Snippet_File::build( $snippet, $file, $key );
		if ( is_wp_error( $built ) ) {
			$report['errors'][ $file ] = $built->get_error_message();

			return false;
		}
		foreach ( $built as $name => $contents ) {
			if ( false === file_put_contents( $dir . $name, $contents ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				/* translators: %s: the file name. */
				return new WP_Error( 'write_failed', sprintf( __( 'The file %s could not be written.', 'wpcode-premium' ), $name ) );
			}
			$taken[] = $name;
		}
		update_post_meta( $snippet->get_id(), self::META_FILE, $file );
		update_post_meta( $snippet->get_id(), self::META_KEY, $key );
		$report['exported'][] = $file;

		if ( in_array( $snippet->get_code_type(), WPCode_Snippet_File::PHP_TYPES, true ) ) {
			$generated = md5( $snippet->get_id() ) . '.php';
			foreach ( array_unique( array( WPCode_Snippets_File_Handler::get_legacy_snippets_dir(), $dir ) ) as $legacy_dir ) {
				if ( file_exists( $legacy_dir . $generated ) ) {
					wp_delete_file( $legacy_dir . $generated );
					$report['removed_legacy'] ++;
				}
			}
		}

		return true;
	}

	/**
	 * Match a file's Key header to the snippet that owns it. A file not yet mapped takes over the snippet whose
	 * own file is gone (a rename); the caller drops that old file from $managed once the new one imports.
	 *
	 * @param string $key     The Key header value.
	 * @param int    $id      The snippet the file is already mapped to, or 0.
	 * @param array  $present Source file names on disk, as keys.
	 * @param array  $managed File name to snippet id.
	 *
	 * @return int|false The renamed snippet's id, 0 when the key needs no change, false when another snippet holds it.
	 */
	protected function claim_key( $key, $id, $present, $managed ) {
		$owners = get_posts(
			array(
				'post_type'        => wpcode_get_post_type(),
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'meta_key'         => self::META_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'       => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'post__not_in'     => $id ? array( (int) $id ) : array(),
				'fields'           => 'ids',
				'posts_per_page'   => 1,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);
		if ( empty( $owners ) ) {
			return 0;
		}
		$owner = (int) $owners[0];
		// The file is already another snippet's, or the key's snippet still has a file on disk (a copy).
		if ( $id || array_intersect_key( $present, array_flip( array_keys( $managed, $owner, true ) ) ) ) {
			return false;
		}

		return $owner;
	}

	/**
	 * Import one parsed file into its mirror snippet.
	 *
	 * @param string $dir    The snippets directory.
	 * @param string $file   The relative file name.
	 * @param string $hash   The file hash.
	 * @param array  $parsed The parsed file.
	 * @param int    $id     The existing mirror id, or 0.
	 * @param array  $report The report, by reference.
	 *
	 * @return void
	 */
	protected function import_file( $dir, $file, $hash, $parsed, $id, &$report ) {
		$data           = $parsed['data'];
		$data['id']     = $id;
		$data['active'] = $parsed['active'];

		// A snippet WPCode deactivated after an error stays inactive until its file changes.
		if ( $parsed['active'] && $id && 'publish' !== get_post_status( $id ) && get_post_meta( $id, self::META_ERROR_HASH, true ) === $hash ) {
			$data['active']              = false;
			$report['warnings'][ $file ] = __( 'Kept inactive: WPCode deactivated this snippet after an error and the file has not changed since.', 'wpcode-premium' );
		}

		// save() hands the data to wp_insert_post() and update_post_meta(), which unslash it: pass it slashed, as posted form data is.
		$snippet = wpcode_get_snippet( wp_slash( $data ) );
		if ( null !== $parsed['compiled_code'] ) {
			$snippet->compiled_code = wp_slash( $parsed['compiled_code'] );
		}

		// The activation check runs the code of an active PHP snippet in this request, whether or not the save
		// then succeeds; running the file too would redeclare its functions.
		$executes = $data['active'] && in_array( $parsed['code_type'], array( 'php', 'universal' ), true );
		if ( $executes && $id ) {
			self::$executed_ids[] = (int) $id;
		}

		wpcode()->error->clear_errors();
		wpcode()->execute->set_activation_code_slashed( true );
		self::$syncing = true;
		try {
			$saved = $snippet->save();
		} catch ( Throwable $e ) {
			// Top-level code in the file threw during the activation check; the mirror is left as it was.
			$saved                     = false;
			$report['errors'][ $file ] = sprintf(
				/* translators: %s: the exception message. */
				__( 'The snippet threw an exception when it was tested: %s', 'wpcode-premium' ),
				$e->getMessage()
			);
		} finally {
			self::$syncing = false;
			wpcode()->execute->set_activation_code_slashed( false );
		}

		if ( ! $saved ) {
			if ( ! isset( $report['errors'][ $file ] ) ) {
				$message                   = wpcode()->error->get_last_error_message();
				$report['errors'][ $file ] = $message ? $message : __( 'The snippet could not be saved.', 'wpcode-premium' );
			}

			return;
		}

		update_post_meta( $saved, self::META_FILE, $file );
		delete_post_meta( $saved, self::META_MISSING );
		if ( '' !== $parsed['key'] ) {
			update_post_meta( $saved, self::META_KEY, $parsed['key'] );
		} else {
			delete_post_meta( $saved, self::META_KEY );
		}

		if ( $executes && ! in_array( (int) $saved, self::$executed_ids, true ) ) {
			// A new snippet has its id only now.
			self::$executed_ids[] = (int) $saved;
		}

		if ( $data['active'] ) {
			clean_post_cache( $saved );
			if ( 'publish' !== get_post_status( $saved ) ) {
				$message                   = wpcode()->error->get_last_error_message();
				$report['errors'][ $file ] = $message ? $message : __( 'The snippet could not be activated.', 'wpcode-premium' );
			}
		}

		if ( function_exists( 'opcache_invalidate' ) && 'php' === strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
			opcache_invalidate( $dir . $file, true );
		}

		$report['imported'][] = $file;
	}

	/**
	 * Take the sync lock atomically (INSERT IGNORE, as WP_Upgrader::create_lock() does), or consume the lock
	 * claim_lock() took earlier in this request. A lock older than LOCK_TTL seconds is treated as abandoned.
	 *
	 * @return bool
	 */
	protected function acquire_lock() {
		global $wpdb;

		if ( self::$lock_claimed ) {
			self::$lock_claimed = false;
			$this->locked       = true;

			return true;
		}

		$value    = time();
		$inserted = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- add_option() is not atomic; INSERT IGNORE is.
			$wpdb->prepare(
				"INSERT IGNORE INTO `$wpdb->options` ( `option_name`, `option_value`, `autoload` ) VALUES ( %s, %s, 'off' ) /* LOCK */",
				self::LOCK_OPTION,
				$value
			)
		);

		if ( ! $inserted ) {
			wp_cache_delete( self::LOCK_OPTION, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			$held = (int) get_option( self::LOCK_OPTION );
			if ( ! $held || $held > time() - self::LOCK_TTL ) {
				return false;
			}
			// Abandoned by a request that died: clear exactly that stale row, never one another request may have
			// just installed, then try once more. INSERT IGNORE on the retry stays the single atomic arbiter.
			$wpdb->delete( $wpdb->options, array( 'option_name' => self::LOCK_OPTION, 'option_value' => (string) $held ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- delete only the abandoned row; the lock bypasses the option caches on purpose.
			wp_cache_delete( self::LOCK_OPTION, 'options' );

			return $this->acquire_lock();
		}

		$this->locked     = true;
		self::$lock_value = $value;

		return true;
	}

	/**
	 * Keep a long run's lock alive: a sync that imports many files (or --force) can outlive LOCK_TTL, and a
	 * concurrent request would otherwise treat the lock as abandoned and start a second import. The write only
	 * succeeds while the row still holds this request's value, so a lock another sync took over is not stolen back.
	 *
	 * @return bool Whether this request still holds the lock.
	 */
	protected function refresh_lock() {
		global $wpdb;

		if ( ! $this->locked ) {
			return false;
		}
		$now = time();
		if ( $now - self::$lock_value < self::LOCK_REFRESH ) {
			return true;
		}
		$updated = $wpdb->update( $wpdb->options, array( 'option_value' => (string) $now ), array( 'option_name' => self::LOCK_OPTION, 'option_value' => (string) self::$lock_value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the lock row bypasses the option caches on purpose.
		wp_cache_delete( self::LOCK_OPTION, 'options' );
		if ( ! $updated ) {
			$this->locked = false;

			return false;
		}
		self::$lock_value = $now;

		return true;
	}

	/**
	 * Release the sync lock.
	 *
	 * @return void
	 */
	protected function release_lock() {
		global $wpdb;

		$this->locked = false;
		// Delete only the row this request still owns, so a lock another sync took over is not cleared from under it.
		$wpdb->delete( $wpdb->options, array( 'option_name' => self::LOCK_OPTION, 'option_value' => (string) self::$lock_value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- release only our own lock row; the lock bypasses the option caches on purpose.
		wp_cache_delete( self::LOCK_OPTION, 'options' );
	}
}

add_filter( 'wpcode_snippet_save_trusted_context', array( 'WPCode_Snippets_File_Sync', 'trusted_context' ) );
