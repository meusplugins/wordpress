<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

class ResponseHelper  {

    const STATUS_FAIL = 'FAIL';
    const STATUS_OK = 'OK';
    /**
     *
     * @param WP_REST_Request $request Full data about the request.
     */
    static function respond($data, $status = 'OK', $errors = []) {
        return new \WP_REST_Response([
            'status' => $status,
            'data' => $data,
            'errors' => $errors,
        ], 200);
    }
    
}
?>