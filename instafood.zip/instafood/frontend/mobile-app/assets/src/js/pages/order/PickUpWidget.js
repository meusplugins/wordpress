import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';
import GenericPopup from '../../components/popup/GenericPopup';
import RestManager from '../../services/RestManager';

class PickUpWidget {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;
    _staticHolderUI;
    _genericPopup;
    _pickupDates = [];
    _existingPickupData = {};
    _pickupUI;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.render(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        const isPickup = Order.getInstance().isPickup();
        if (!isPickup) {
            return;
        }
        this._existingPickupData = Order.getInstance().getExistingPickupData();
        
        let infoTime = LanguageUtils.getInstance().getLabel('pickup_info_wgt_info');
        if (this._existingPickupData.day && this._existingPickupData.time) {
            infoTime = `${this._existingPickupData.day} - ${this._existingPickupData.time}`;
        }

        const template = `
        <div class="apt_content_widget mt_20 bm_20 pickup_time_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-calendar wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('pickup_info_wgt_title') }</div>
                    </div>
                    <div class="wgt_main_action"><span class="icon-edit-3"></span></div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="wgt_info_clickable time_inform">${ infoTime }</div>
                </div>
            </div>
        </div>
        `;

        const _this = this;
        this._ui = jQuery(template);
        this._ui.appendTo(this._staticHolderUI);

        this._ui.find('.wgt_main_action').click(function(event) {
            event.preventDefault();
            _this._openPickupTimeEdit();
        });
        this._ui.find('.wgt_info_clickable').click(function(event) {
            event.preventDefault();
            _this._openPickupTimeEdit();
        });
    }

    _openPickupTimeEdit() {
        this._genericPopup = new GenericPopup(LanguageUtils.getInstance().getLabel('pickup_info_popup_title'));
        this._genericPopup.render();
        const popupContentUI = this._genericPopup.getContentUI();
        popupContentUI.css('min-height', '300px');
        const popupFooterUI = this._genericPopup.getFooterContentUI();

        let existingDay = _.get(this._existingPickupData, 'day', '');
        if (existingDay === '') {
            existingDay = LanguageUtils.getInstance().getLabel('pickup_info_choose_day_placeholder')
        }

        const _this = this;

        const pickupTemplate = `
            <div class="if_form_control mb_15">
                <div class="label">${ LanguageUtils.getInstance().getLabel('pickup_info_choose_day') } *</div>
                <div class="if_text_input full_w datepicker">${ existingDay }</div>
                <div class="hours_picker mt_15">
                    <div class="title">${ LanguageUtils.getInstance().getLabel('choose_pickup_time') } *</div>
                    <div class="content">
                    </div>
                </div>
            </div>
            <div class="mb_15"></div>
        `;
        this._pickupUI = jQuery(pickupTemplate);
        this._pickupUI.appendTo(popupContentUI);
        this._genericPopup.showPreloader();

        this._popupOKBtn = jQuery(`<a href="#" class="apt_button primary validate_address_btn inactive">${ LanguageUtils.getInstance().getLabel('customer_save_pickup_date') }</a>`);
        this._popupOKBtn.appendTo(popupFooterUI);
        this._popupOKBtn.click(function(event) {
            event.preventDefault();
            if (!_this._canSavePickupTime()) {
                return;
            }
            Order.getInstance().setExistingPickupData(_this._existingPickupData, true);
            _this._ui.find('.wgt_info_clickable').html(`${_this._existingPickupData.day} - ${_this._existingPickupData.time}`);
            _this._genericPopup.close();
        })

        RestManager.getInstance().get('/pickup-dates')
        .then(result => {
            this._genericPopup.removePreloader();
            this._pickupDates = _.get(result, 'data.pickup_dates', []);
            this._handleDatePicker();
            if (this._existingPickupData.day) {
                this._onDateChoose(this._existingPickupData.day);
                this._validateDateAdd();
            }
        })
    }

    _handleDatePicker() {
        let options = {
            zIndex: 99999,
            autoHide: true,
        }
        if (_.get(this._pickupDates, '[0]', false)) {
            options.date = this._pickupDates[0]['day'];
            options.startDate = this._pickupDates[0]['startDate'];
            if (this._existingPickupData.day) {
                options.date = this._existingPickupData.day;
            }
            options.filter = (date, view) => {
                let month = date.getUTCMonth() + 1; //months from 1-12
                let day = date.getUTCDate() + 1;
                let year = date.getUTCFullYear();
                month = month < 10 ? `0${month}` : month;
                day = day < 10 ? `0${day}` : day;
                const composed = `${month}/${day}/${year}`;

                const found = _.find(this._pickupDates, { day : composed });
                if (!found) {
                    return false;
                }
            }
        }
        const _this = this;
        this._pickupUI.find('.datepicker').datepicker(options);
        this._pickupUI.find('.datepicker').on('pick.datepicker', function (event) {
            const { date } = event;
            let month = date.getUTCMonth() + 1; //months from 1-12
            let day = date.getUTCDate() + 1;
            let year = date.getUTCFullYear();
            month = month < 10 ? `0${month}` : month;
            day = day < 10 ? `0${day}` : day;
            const composed = `${month}/${day}/${year}`;
            _this._existingPickupData.day = composed;
            _this._existingPickupData.time = null;
            _this._onDateChoose(composed);
            _this._validateDateAdd();
        });
    }

    _onDateChoose(dateString) {
        this._pickupUI.find('.hours_picker').show();
        const content = this._pickupUI.find('.hours_picker .content');
        content.empty();
        content.scrollTop(0);

        const _this = this;
        let time = _.get(this._existingPickupData, 'time', '');

        const found = _.find(this._pickupDates, { day : dateString });
        if (!found) {
            return;
        }
        let { hours } = found;
        for (let i = 0; i < hours.length; i++) {
            const hoursTemplate = `
            <div class="product_widget delivery_widget local_delivery" data-hour="${ hours[i] }">
                <div class="widget_radio_entry ${ time === hours[i] ? 'selected' : '' }">
                    <div class="radio_symbol primary_color_border"><div class="radio_fill primary_color_background show"></div></div>
                    <div class="variant_info">${ hours[i] }</div>
                </div>
            </div>
            `;
            const hourUI = jQuery(hoursTemplate);
            hourUI.appendTo(content);
            hourUI.click(function(event) {
                event.preventDefault();
            
                content.find('.product_widget').each(function(index) {
                    if (jQuery(this).find('.widget_radio_entry').hasClass('selected')) {
                        jQuery(this).find('.widget_radio_entry').removeClass('selected')
                    }
                })
                if (!jQuery(this).find('.widget_radio_entry').hasClass('selected')) {
                    jQuery(this).find('.widget_radio_entry').addClass('selected')
                }
                _this._existingPickupData.time = jQuery(this).attr('data-hour');
                _this._validateDateAdd();
            })
        }
    }

    _canSavePickupTime() {
        return this._existingPickupData.day && this._existingPickupData.time;
    }

    _validateDateAdd() {
        if (this._canSavePickupTime()) {
            if (this._popupOKBtn.hasClass('inactive')) {
                this._popupOKBtn.removeClass('inactive');
            }
        } else {
            if (!this._popupOKBtn.hasClass('inactive')) {
                this._popupOKBtn.addClass('inactive');
            }
        }
    }
}
export default PickUpWidget;