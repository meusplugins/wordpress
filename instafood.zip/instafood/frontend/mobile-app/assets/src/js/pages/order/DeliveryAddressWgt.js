import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';
import GenericPopup from '../../components/popup/GenericPopup';
import Checkbox from '../../components/checkbox/Checkbox';
import RestManager from '../../services/RestManager';
import StorageUtil from '../../utils/StorageUtil';

class DeliveryAddressWgt {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;
    _staticHolderUI;
    _genericPopup;
    _popupOKBtn;
    _saveCustomerDeliveryInfo = false;
    _customerPhone = '';
    _customerCity = '';
    _customerAddress = '';
    _customer_notes = '';

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.render(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        const isDelivery = Order.getInstance().isDelivery();
        if (!isDelivery) {
            return;
        }
        const template = `
        <div class="apt_content_widget mt_20 bm_20 delivery_address_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-location wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('delivery_info_wgt_title') }</div>
                    </div>
                    <div class="wgt_main_action"><span class="icon-edit-3"></span></div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="wgt_info_clickable">${ LanguageUtils.getInstance().getLabel('delivery_info_wgt_info') }</div>
                </div>
            </div>
        </div>
        `;

        const _this = this;
        this._ui = jQuery(template);
        this._ui.appendTo(this._staticHolderUI);
        this._ui.find('.wgt_main_action').click(function(event) {
            event.preventDefault();
            _this._openAddressEdit();
        });
        this._ui.find('.wgt_info_clickable').click(function(event) {
            event.preventDefault();
            _this._openAddressEdit();
        });

        this._saveCustomerDeliveryInfo = StorageUtil.getData('_saveCustomerDeliveryInfo', false);
        
        const { _customer_notes } = Order.getInstance().getDeliveryInfo();
        if (this._saveCustomerDeliveryInfo) {
            if (this._customerPhone === '') {
                this._customerPhone = StorageUtil.getData('_customerPhone', '');
            }
            if (this._customerCity === '') {
                this._customerCity = StorageUtil.getData('_customerCity', '');
            }
            if (this._customerAddress === '') {
                this._customerAddress = StorageUtil.getData('_customerAddress', '');
            }
            if (this._customer_notes === '') {
                this._customer_notes = StorageUtil.getData('_customer_notes', '');
            }
        }

        // Order.getInstance().setCanDeliverToAddress(this._canAddAddress());
        if (this._canAddAddress()) {
            this._ui.find('.wgt_info_clickable').html(this._composeDisplayAddress());
            Order.getInstance().setDeliveryInfo({
                _customerPhone: this._customerPhone,
                _customerCity: this._customerCity,
                _customerAddress: this._customerAddress,
                _customer_notes: this._customer_notes,
            })
        }
    }

    _openAddressEdit() {
        this._genericPopup = new GenericPopup(LanguageUtils.getInstance().getLabel('delivery_info_popup_title'));
        this._genericPopup.render();
        const popupContentUI = this._genericPopup.getContentUI();
        const popupFooterUI = this._genericPopup.getFooterContentUI();

        const customer_phone = LanguageUtils.getInstance().getLabel('customer_phone');
        const customer_city = LanguageUtils.getInstance().getLabel('customer_city');
        const customer_address = LanguageUtils.getInstance().getLabel('customer_address');
        const customer_additional_delivery_info = LanguageUtils.getInstance().getLabel('customer_additional_delivery_info');

        if (_.isNil(this._customer_notes) || this._customer_notes === 'null') {
            this._customer_notes = '';
        }

        const addressTemplate = `
            <div class="if_form_control mb_15">
                <div class="label">${ customer_phone } *</div>
                <input class="if_text_input full_w customer_phone" type="tel" name="phone" value="${ this._customerPhone }" required autocomplete="tel" />
            </div>
            <div class="if_form_control mb_15">
                <div class="label">${ customer_city } *</div>
                <input class="if_text_input full_w customer_city" name="ship-city" value="${ this._customerCity }" autocomplete="shipping locality" type="text" />
            </div>
            <div class="if_form_control mb_15">
                <div class="label">${ customer_address } *</div>
                <input class="if_text_input full_w customer_address" name="ship-address" value="${ this._customerAddress }" autocomplete="shipping street-address" type="text" />
            </div>
            <div class="if_form_control">
                <div class="label">${ customer_additional_delivery_info }</div>
                <textarea class="if_textarea_input customer_notes full_w">${ this._customer_notes }</textarea>
            </div>
            <div class="mb_15"></div>
        `;

        const _this = this;
        const addressUI = jQuery(addressTemplate);
        addressUI.appendTo(popupContentUI);

        this._popupOKBtn = jQuery(`<a href="#" class="apt_button primary validate_address_btn inactive">${ LanguageUtils.getInstance().getLabel('customer_add_address') }</a>`);
        this._popupOKBtn.appendTo(popupFooterUI);
        this._popupOKBtn.click(function(event) {
            event.preventDefault();
            if (!_this._canAddAddress()) {
                return;
            }
            _this._validateAddress();
        })

        addressUI.find('.customer_phone').on('keyup', function(event) {
            event.preventDefault();
            _this._customerPhone = addressUI.find('.customer_phone').val();
            _this._validateAddAddress();
        })

        addressUI.find('.customer_city').on('keyup', function(event) {
            event.preventDefault();
            _this._customerCity = addressUI.find('.customer_city').val();
            _this._validateAddAddress();
        })

        addressUI.find('.customer_address').on('keyup', function(event) {
            event.preventDefault();
            _this._customerAddress = addressUI.find('.customer_address').val();
            _this._validateAddAddress();
        })

        addressUI.find('.customer_notes').on('keyup', function(event) {
            event.preventDefault();
            _this._customer_notes = addressUI.find('.customer_notes').val();
            _this._validateAddAddress();
        })

        // const agreeStoreAddressCB = new Checkbox(
        // popupContentUI, 
        // LanguageUtils.getInstance().getLabel('customer_delivery_save_data_lable'), 
        // val => {
        //     this._saveCustomerDeliveryInfo = val;
        // });
        // agreeStoreAddressCB.render();
        // agreeStoreAddressCB.setSelected(this._saveCustomerDeliveryInfo);

        _this._validateAddAddress();
    }

    _validateAddAddress() {
        const validate_address_btn = this._genericPopup.getFooterContentUI().find('.validate_address_btn');
        if (this._canAddAddress()) {
            if (validate_address_btn.hasClass('inactive')) {
                validate_address_btn.removeClass('inactive')
            }
        } else {
            if (!validate_address_btn.hasClass('inactive')) {
                validate_address_btn.addClass('inactive')
            }
        }
    }
    
    _canAddAddress() {
        return this._customerPhone !== '' && this._customerAddress !== '' && this._customerCity !== '';
    }

    _validateAddress() {
        this._genericPopup.showPreloader();
        RestManager.getInstance().post('/verify-delivery-distance', {
            city: this._customerCity,
            displayAddress: this._customerAddress,
        })
        .then(result => {
            this._genericPopup.removePreloader();
            this._genericPopup.close();
            const canOrder = _.get(result, 'data.canOrder', false);
            
            StorageUtil.setData('_saveCustomerDeliveryInfo', this._saveCustomerDeliveryInfo);

            Order.getInstance().setCanDeliverToAddress(canOrder, true);
            
            if (canOrder) {
                this._ui.find('.wgt_info_clickable').removeClass('_error');
                this._ui.find('.wgt_info_clickable').html(this._composeDisplayAddress());

                Order.getInstance().setDeliveryInfo({
                    _customerPhone: this._customerPhone,
                    _customerCity: this._customerCity,
                    _customerAddress: this._customerAddress,
                    _customer_notes: this._customer_notes,
                })
                if (this._saveCustomerDeliveryInfo) {
                    // save for later
                    StorageUtil.setData('_customerPhone', this._customerPhone);
                    StorageUtil.setData('_customerCity', this._customerCity);
                    StorageUtil.setData('_customerAddress', this._customerAddress);
                    StorageUtil.setData('_customer_notes', this._customer_notes);
                    StorageUtil.setData('_canOrderToAddress', true);
                } else {
                    StorageUtil.setData('_customerPhone', null);
                    StorageUtil.setData('_customerCity', null);
                    StorageUtil.setData('_customerAddress', null);
                    StorageUtil.setData('_customer_notes', null);
                    StorageUtil.setData('_canOrderToAddress', null);
                }
            } else {
                this._ui.find('.wgt_info_clickable').addClass('_error');
                this._ui.find('.wgt_info_clickable').html(LanguageUtils.getInstance().getLabel('error_delivery_distance'));
            }
        })
    }

    _composeDisplayAddress() {
        const canDeliver = Order.getInstance().getCanDeliverToAddress();
        if (canDeliver) {
            return `${ this._customerAddress }, ${ this._customerCity }, ${ this._customerPhone }`;
        } else {
            return `<span class="_error">${ this._customerAddress }, ${ this._customerCity }, ${ this._customerPhone }</span>`;
        }
    }

}
export default DeliveryAddressWgt;