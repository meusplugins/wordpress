<?php return array('dependencies' => array(), 'version' => '398dd917bf323604fa55');
