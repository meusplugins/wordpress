<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

use com\sakuraplugins\appetit\utils\OptionUtil;

class CustomCodeHelper {
    
    static function _eCustomCSS() {
        $custom_css = OptionUtil::getInstance()->getOption('custom_css', '');
        if ($custom_css === '') {
            return;
        }
        ?>
        <style><?= $custom_css ?></style>
        <?php
    }

    static function _eCustomJS() {
        $custom_js = OptionUtil::getInstance()->getOption('custom_js', '');
        if ($custom_js === '') {
            return;
        }
        ?>
        <script><?= $custom_js ?></script>
        <?php
    }

    static function _ePrimaryColor() {
        $newPrimaryColor = trim(OptionUtil::getInstance()->getOption('custom_primary_color', ''));
        if ($newPrimaryColor === '') {
            return;
        }
        ?>
        <style>
        .primary_color {
            color: <?= $newPrimaryColor ?>;
        }
        .apt-splashscreen {
            background: <?= $newPrimaryColor ?>;
        }
        .primary_color_background {
            background: <?= $newPrimaryColor ?>;
        }
        .primary_color_border {
            border-color: <?= $newPrimaryColor ?>;
        }
        .apt-cover-header .apt-cover-header-overlay .lang_switch_ui .inside .in-section-link.selected {
            color: <?= $newPrimaryColor ?>;
        }
        .apt-categories-nav .apt-category-nav.nav-selected {
            color: <?= $newPrimaryColor ?>;
        }
        .apt-categories-nav .apt-category-nav .selected_underline {
            background-color: <?= $newPrimaryColor ?>;
        }
        .round_nav:link, .round_nav:visited , .round_nav:hover, .round_nav:active{
        color: <?= $newPrimaryColor ?>;
        }
        .round_nav_fill:link, .round_nav_fill:visited, .round_nav_fill:hover, .round_nav_fill:active {
            background: <?= $newPrimaryColor ?>;
        }
        .round_nav_fill.reverse-color:link, .round_nav_fill.reverse-color:visited, .round_nav_fill.reverse-color:hover, .round_nav_fill.reverse-color:active {
            background: #f5f5f5;
            color: <?= $newPrimaryColor ?> !important;
        }
        .apt_button:link, .apt_button:visited , .apt_button:hover, .apt_button:active{
            color: <?= $newPrimaryColor ?>;
        }
        .apt_button.primary:link, .apt_button.primary:visited, .apt_button.primary:hover, .apt_button.primary:active {
            background: <?= $newPrimaryColor ?>;
        }
        .apt_button.inactive:link, .apt_button.inactive:visited, .apt_button.inactive:hover, .apt_button.inactive:active {
            background: #CCCCCC;
        }
        .info_number.red {
            background: <?= $newPrimaryColor ?>;
        }
        .cart-product-entry .cpe-product-info-ui .cpe-product-info .title {
            color: <?= $newPrimaryColor ?>;
        }
        .square_nav:link, .square_nav:visited , .square_nav:hover, .square_nav:active{
            color: <?= $newPrimaryColor ?>;
        }
        .apt_content_widget .in_content .wgt_header .wgt_title_ui .wgt_icon {
            color: <?= $newPrimaryColor ?>;
        }
        .apt_content_widget .in_content .wgt_header .wgt_main_action {
            color: <?= $newPrimaryColor ?>;
        }
        </style>
        <?php
    }
}
?>