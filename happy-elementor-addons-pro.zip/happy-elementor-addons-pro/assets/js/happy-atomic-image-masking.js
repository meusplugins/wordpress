"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/**
 * Happy Addons Pro — Image Masking, Elementor V4 editor preview.
 *
 * The canvas renders the Atomic Image client side, so PHP never
 * sees it there: the rules are built from the editor settings instead. The
 * frontend gets the same rules from PHP (Image_Masking::build_css), keep both
 * in sync. window.HappyAtomic.defaults['image-masking'] is printed by the free
 * plugin's Atomic_Manager::enqueue_preview_assets().
 */
(function (w, d) {
  'use strict';

  var KEY = 'image-masking';
  function isEditor() {
    return d.body.classList.contains('elementor-editor-active') || !!(w.elementorFrontend && w.elementorFrontend.isEditMode && w.elementorFrontend.isEditMode());
  }
  function num(value, fallback) {
    var parsed = parseFloat(value);
    return isNaN(parsed) ? fallback : parsed;
  }
  function unwrapProp(value) {
    while (value && 'object' === _typeof(value) && '$$type' in value) {
      value = value.value;
    }
    return value;
  }
  function editorSettings(id) {
    try {
      var editor = w.parent && w.parent.elementor || w.elementor;
      var container = editor && editor.getContainer && editor.getContainer(id);
      var settings = container && (container.settings || container.model && container.model.get('settings'));
      return settings ? settings.attributes || settings.toJSON && settings.toJSON() : null;
    } catch (e) {
      return null;
    }
  }
  function setting(settings, key, fallback) {
    var value = unwrapProp(settings['ha_imask_' + key]);
    return null === value || undefined === value || '' === value ? fallback : value;
  }
  function pick(value, allowed, fallback) {
    return allowed.indexOf(String(value)) > -1 ? String(value) : fallback;
  }
  function cssUrl(url) {
    return String(url || '').trim().replace(/"/g, '%22').replace(/\\/g, '%5C').replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/[\r\n]/g, '').replace(/ /g, '%20');
  }

  // The media library stores only the attachment id: resolve its URL (fetched once, then cached).
  var urlById = {};
  function attachmentUrl(id) {
    id = parseInt(id, 10);
    if (!id) {
      return '';
    }
    if (id in urlById) {
      return urlById[id] || '';
    }
    urlById[id] = '';
    try {
      var media = (w.parent && w.parent.wp || w.wp || {}).media;
      var attachment = media && media.attachment(id);
      if (attachment) {
        if (attachment.get('url')) {
          urlById[id] = attachment.get('url');
        } else {
          attachment.fetch().then(function () {
            urlById[id] = attachment.get('url') || '';
          });
        }
      }
    } catch (e) {}
    return urlById[id];
  }

  // Same value lists as Image_Masking::fields().
  var POSITIONS = ['center center', 'center left', 'center right', 'top center', 'top left', 'top right', 'bottom center', 'bottom left', 'bottom right'];
  var REPEATS = ['repeat', 'repeat-x', 'repeat-y', 'space', 'round', 'no-repeat', 'repeat space', 'round space', 'no-repeat round'];
  var SIZES = ['auto', 'cover', 'contain', 'initial'];
  var UNITS = ['%', 'px', 'em', 'vw'];
  function maskCss(s, settings, defaults) {
    var url;
    if (true !== unwrapProp(settings.ha_imask_switcher)) {
      return '';
    }
    if ('custom' === setting(settings, 'shape_type', defaults.shape_type)) {
      var image = unwrapProp(settings.ha_imask_custom);
      var src = image && unwrapProp(image.src);
      url = src ? unwrapProp(src.url) || attachmentUrl(unwrapProp(src.id)) : '';
    } else {
      var shape = String(setting(settings, 'shape', defaults.shape));
      url = /^shape\d+$/.test(shape) ? defaults.shape_base + shape + '.svg' : '';
    }
    url = cssUrl(url);
    if (!url) {
      return '';
    }
    var size = pick(setting(settings, 'size', defaults.size), SIZES, 'contain');
    if ('initial' === size) {
      size = Math.max(0, num(setting(settings, 'custom_size', defaults.custom_size), 100)) + pick(setting(settings, 'custom_unit', defaults.custom_unit), UNITS, '%');
    }
    var rules = {
      'mask-image': 'url("' + url + '")',
      'mask-position': pick(setting(settings, 'position', defaults.position), POSITIONS, 'center center'),
      'mask-size': size,
      'mask-repeat': pick(setting(settings, 'repeat', defaults.repeat), REPEATS, 'no-repeat')
    };
    var css = '';
    Object.keys(rules).forEach(function (property) {
      css += '-webkit-' + property + ':' + rules[property] + ';' + property + ':' + rules[property] + ';';
    });
    return s + '{' + css + '}';
  }
  function scanEditorImages() {
    var defaults = w.HappyAtomic && w.HappyAtomic.defaults && w.HappyAtomic.defaults[KEY];
    if (!defaults || !isEditor()) {
      return;
    }
    d.querySelectorAll('[data-id]').forEach(function (el) {
      var id = el.getAttribute('data-id');
      var settings = editorSettings(id);
      var tag = d.getElementById('ha-imask-' + id);

      // Only the Atomic Image carry the masking props.
      if (!settings || !('ha_imask_switcher' in settings)) {
        return;
      }

      // Keep in sync with Image_Masking::selector().
      var safeId = id.replace(/[^a-zA-Z0-9_-]/g, '');
      var base = '[data-id="' + safeId + '"]';
      var css = maskCss(base + ' img,img' + base, settings, defaults);
      if (!css) {
        if (tag) {
          tag.remove();
        }
        return;
      }
      if (!tag) {
        tag = d.createElement('style');
        tag.id = 'ha-imask-' + id;
        d.head.appendChild(tag);
      }
      if (tag.textContent !== css) {
        tag.textContent = css;
      }
    });
  }
  function boot() {
    scanEditorImages();

    // Settings changes fire no DOM mutation, so the editor is polled.
    setInterval(scanEditorImages, 500);
  }
  if ('loading' === d.readyState) {
    d.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window, document);