<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * Horizontal Scroll for the Atomic containers (e-flexbox, e-div-block, e-grid).
 *
 * Same settings as the Classic Horizontal Scroll extension: the container is
 * pinned while the page scrolls and its children slide horizontally.
 */
class Horizontal_Scroll extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_hs_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	}

	protected function feature_key() {
		return 'horizontal-scroll';
	}

	protected function section_label() {
		return __( 'Horizontal Scroll', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['classes'], $schema['tag'], $schema['link'] )
			&& ! isset( $schema['title'], $schema['image'], $schema['text'], $schema['paragraph'] );
	}

	protected function fields() {
		$on = [ 'switcher' => true ];

		return [
			'switcher'          => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable', 'happy-addons-pro' ),
				'description' => __( 'Applicable to Desktop layout only', 'happy-addons-pro' ),
			],
			'direction'         => [
				'type'    => 'enum',
				'default' => 'left',
				'label'   => __( 'Scroll Direction', 'happy-addons-pro' ),
				'options' => [
					'left'  => __( 'Left', 'happy-addons-pro' ),
					'right' => __( 'Right', 'happy-addons-pro' ),
				],
				'icons'   => [
					'left'  => 'ArrowLeftIcon',
					'right' => 'ArrowRightIcon',
				],
				'show'    => $on,
			],
			'start_offset'      => [
				'type'        => 'number',
				'default'     => 0,
				'min'         => 0,
				'max'         => 1000,
				'step'        => 1,
				'label'       => __( 'Start Offset (px)', 'happy-addons-pro' ),
				'description' => __( 'Distance from the top of the viewport where the horizontal scroll starts pinning.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'snap_scroll'       => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Snap Scrolling', 'happy-addons-pro' ),
				'description' => __( 'Allows the scroll position to automatically snap to each section or item.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'enable_auto_width' => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable Auto Width Items', 'happy-addons-pro' ),
				'description' => __( 'Allow child items to size themselves based on their content (use only for large text panels).', 'happy-addons-pro' ),
				'show'        => $on,
			],
		];
	}
}
