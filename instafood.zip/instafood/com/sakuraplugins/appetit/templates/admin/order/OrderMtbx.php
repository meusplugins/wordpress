<?php
namespace com\sakuraplugins\appetit\templates\admin\order;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../../../cpt/OrderCpt.php');

use com\sakuraplugins\appetit\cpt\OrderCpt;


class OrderMtbx {

    function render(): void {
        global $post;
        ?>
        <div class="container-fluid">
            <div class="row mt-4 mb-4">
                <div class="col-md-12"></div>
            </div>
        </div>
        <?php
    }
}
?>