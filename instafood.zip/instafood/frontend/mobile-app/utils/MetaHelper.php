<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

use com\sakuraplugins\appetit\utils\OptionUtil;

class MetaHelper {

    static function _renderMeta() {

        $restaurant_logo_image_id = OptionUtil::getInstance()->getOption('restaurant_logo_image_id');
        $restaurant_logo_image_url = '';
        if ($restaurant_logo_image_id) {
            $restaurant_logo_image_data = wp_get_attachment_image_src($restaurant_logo_image_id, 'appetit-aquare-large');
            $restaurant_logo_image_url = $restaurant_logo_image_data[0] ?? '';
        }

        $restaurant_logo_image_url = $restaurant_logo_image_url === '' ? INSTAFOOD_QR_MOBILE_APP_URL . '/assets/dist/img/appetit_logo_small.png' : $restaurant_logo_image_url;

        ?>
        <title><?= esc_html__(OptionUtil::getInstance()->getOption('apt_site_title', '')) ?></title>
        <meta name="description" content="<?= esc_attr(OptionUtil::getInstance()->getOption('apt_site_description', '')) ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta property="og:title" content="<?= esc_attr(OptionUtil::getInstance()->getOption('apt_site_title', '')) ?>">
        <meta property="og:description" content="<?= OptionUtil::getInstance()->getOption('apt_site_description', '') ?>">
        <meta property="og:image" content="<?= esc_attr($restaurant_logo_image_url) ?>">
        <?php
    }
}