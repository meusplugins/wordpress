<?php
namespace com\sakuraplugins\appetit\cpt;
if ( ! defined('ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . 'GenericPostType.php');
require_once(plugin_dir_path(__FILE__) . 'ICpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../utils/UserManagement.php');

use com\sakuraplugins\appetit\utils\OptionUtil as OptionUtil;
use com\sakuraplugins\appetit\utils\UserManagement;

class ChoiceGroupsCpt extends GenericPostType {

    const REWRITE_KEY = 'CHOICE_GROUPS_REWRITE_KEY';
    const DEFAULT_REWRITE_SLUG = 'choice-groups';

    const CHOICE_DEFAULT_REWRITE_SLUG = 'choice';
    const CHOICE_SLUG = 'appetit_choice_category';
    const CHOICE_META_KEY = 'appetit_choice_category_meta';

    public static function getMetaKey(): string {
        return 'appetit_choice_group_meta';
    }

    public static function getPostType(): string {
        return 'appetit_choice_group';
    }

    public static function getPostTypePlural(): string {
        return 'appetit_choice_groups';
    }

    public static function CPTSupports(): array {
        return ['title'];
    }

    static function getCategoryCaps() {
        return [
            'manage_terms' => 'manage_' . self::CHOICE_SLUG,
            'edit_terms' => 'edit_' . self::CHOICE_SLUG,
            'delete_terms' => 'delete_' . self::CHOICE_SLUG,
            'assign_terms' => 'assign_' . self::CHOICE_SLUG,
        ];
    }

    public function getSettings($rewrite, $menuPosition = 80): array {
        $labels = array(
            'name'               => _x('InstaFood choice groups', 'post type general name', 'instafood'),
            'singular_name'      => _x('InstaFood choice group', 'post type singular name', 'instafood'),
            'menu_name'          => _x('InstaFood choice groups', 'admin menu', 'instafood'),
            'name_admin_bar'     => _x('InstaFood choice group', 'add new on admin bar', 'instafood'),
            'add_new'            => _x('Add new choice group', 'add new item' , 'instafood'),
            'add_new_item'       => esc_html__('Add New choice group ', 'instafood'),
            'new_item'           => esc_html__('New InstaFood choice group', 'instafood'),
            'edit_item'          => esc_html__('Edit InstaFood choice group', 'instafood'),
            'view_item'          => esc_html__('View InstaFood item', 'instafood'),
            'all_items'          => esc_html__('All InstaFood choice groups', 'instafood'),
            'search_items'       => esc_html__('Search InstaFood choice groups', 'instafood'),
            'parent_item_colon'  => esc_html__('Parent InstaFood choice groups', 'instafood'),
            'not_found'          => esc_html__('No InstaFood choice groups found.', 'instafood'),
            'not_found_in_trash' => esc_html__('No InstaFood choice groups found in Trash.', 'instafood' )
        );
        
        $capabilities = UserManagement::compile_post_type_capabilities(self::getPostType(), self::getPostTypePlural());

        $args = array(
            'capabilities' => $capabilities,
            'labels'             => $labels,
            'description'        => esc_html__('Description', 'instafood'),
            'public'             => false,
            'publicly_queryable' => false,
            'show_in_rest' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => $rewrite),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => $menuPosition,
            'supports'           => self::CPTSupports(),
        );
        return $args;
    }

    public static function getTaxonomySettings(): array {

        $labels = [
            'name'              => _x( 'Menu choices', 'taxonomy general name', 'instafood' ),
            'singular_name'     => _x( 'Menu choice', 'taxonomy singular name', 'instafood' ),
            'search_items'      => esc_html__( 'Search Menu choice', 'instafood' ),
            'all_items'         => esc_html__( 'All Menu choices', 'instafood' ),
            'parent_item'       => esc_html__( 'Parent Menu choice', 'instafood' ),
            'parent_item_colon' => esc_html__( 'Parent Menu choice:', 'instafood' ),
            'edit_item'         => esc_html__( 'Edit Menu choice', 'instafood' ),
            'update_item'       => esc_html__( 'Update Menu choice', 'instafood' ),
            'add_new_item'      => esc_html__( 'Add new Menu choice', 'instafood' ),
            'new_item_name'     => esc_html__( 'New Menu choice', 'instafood' ),
            'menu_name'         => esc_html__( 'Menu choices', 'instafood' ),
        ];

        $args = [
            'capabilities' => self::getCategoryCaps(),
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'meta_box_cb'       => false,
            'show_admin_column' => true,
            'query_var'         => false,
            'show_tagcloud' => false,
            'has_archive' => false,
            'with_front' => false,
        ];
        return $args;
    }

    public static function registerTaxonomies(): void {
        $rewrite = OptionUtil::getInstance()->getOption('appetit_choice_rewrite', self::CHOICE_DEFAULT_REWRITE_SLUG);

        register_taxonomy(
            self::CHOICE_SLUG,
            self::getPostType(), array_merge(self::getTaxonomySettings(), [
                'rewrite' => ['slug' => $rewrite],
                'show_ui' => true,
            ])
        );
    }
}

?>
