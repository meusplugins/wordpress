"use strict";
(function() {
    toastr.options = {
        "debug": false,
        "positionClass": "toast-bottom-full-width",
        "onclick": null,
        "fadeIn": 300,
        "fadeOut": 800,
        "timeOut": 2000,
        "extendedTimeOut": 800
    }
    
    function handleChoices() {
        const add_choice_btn = jQuery('.add_choice_btn');
        const select_choice = jQuery('.select_choice');
        const max_choices_select = jQuery('#max_choices_select');
        const min_choices_select = jQuery('#min_choices_select');

        select_choice.select2();

        const choiceExists = (choiceId) => {
            let out = false;
            jQuery('.choice_entry').each(function(index) {
                if (jQuery(this).attr('data-choice-id') === choiceId) {
                    out = true;
                }
            });
            return out;
        }

        add_choice_btn.click(function(event) {
            event.preventDefault();

            const currentOption = select_choice.children('option:selected');
            if (currentOption.val() === '') {
                return;
            }

            const choice_name_1 = currentOption.attr('data-choice-name');
            const choice_name_2 = currentOption.attr('data-choice-name-s');
            let choice_price = currentOption.attr('data-choice-price');
            choice_price = choice_price === '' ? 0: choice_price;
            const choice_id = currentOption.attr('data-choice-id');

            if (choiceExists(choice_id)) {
                alert(lodash.get(APPETIT_CHOICE_GROUP, 'locales.choice_exists', ''));
                return;
            }

            const tr = `
                <tr class="choice_entry" data-choice-id="${choice_id}">
                    <td>${choice_name_1}<input type="hidden" value="${choice_id}" name="${lodash.get(APPETIT_CHOICE_GROUP, 'post_meta_key', '')}[choices_ids][]" /></td>
                    <td>${choice_name_2}</td>
                    <td>${choice_price}</td>
                    <td><a class="delete_choice_btn" href="#">${lodash.get(APPETIT_CHOICE_GROUP, 'locales.delete', '')}</a></td>
                </tr>
            `;
            const trUI = jQuery(tr);
            trUI.appendTo(jQuery('.choices_table'));
            handleChoiceRemove(trUI);
            handleMaxChoiceSelect();
            handleMinChoiceSelect();

            toastr.success(lodash.get(APPETIT_CHOICE_GROUP, 'locales.choice_successfully_added', ''), '', {
                iconClass: "appetit-toast-custom",
            });
        })

        select_choice.on('change', function(event) {
            add_choice_btn.removeAttr('disabled');
            if (this.value === '') {
                add_choice_btn.attr('disabled', true);
                return;
            }
        });

        const handleChoiceRemove = (choiceUI) => {
            choiceUI.find('.delete_choice_btn').click(function(event) {
                event.preventDefault();
                jQuery(this).parent().parent().remove();
                handleMaxChoiceSelect();
                handleMinChoiceSelect();
            });
        }

        const handleMaxChoiceSelect = function() {
            const previousValue = parseInt(max_choices_select.val(), 10);
            max_choices_select.empty();
            jQuery(`<option>${lodash.get(APPETIT_CHOICE_GROUP, 'locales.select', '')}</option>`).appendTo(max_choices_select);
            let c = 0;
            jQuery('.choice_entry').each(function(index) {
                c++;
                jQuery(`<option ${previousValue === c ? 'selected' : ''} value="${c}">${c}</option>`).appendTo(max_choices_select);
            });
        }

        const handleMinChoiceSelect = function() {
            const previousValue = parseInt(min_choices_select.val(), 10);
            min_choices_select.empty();
            jQuery(`<option>${lodash.get(APPETIT_CHOICE_GROUP, 'locales.select', '')}</option>`).appendTo(min_choices_select);
            let c = 0;
            jQuery('.choice_entry').each(function(index) {
                c++;
                jQuery(`<option ${previousValue === c ? 'selected' : ''} value="${c}">${c}</option>`).appendTo(min_choices_select);
            });
        }


        let max_choices_select_previous = '';

        max_choices_select.on('focusin', function() {
            max_choices_select_previous = max_choices_select.val();
        });
        
        max_choices_select.on('change', function() {
            const maxChoiceVal = parseInt(max_choices_select.val(), 10);
            const minChoiceVal = parseInt(min_choices_select.val(), 10);
            if (lodash.isNaN(maxChoiceVal) || lodash.isNaN(minChoiceVal) || minChoiceVal === 0) {
                return;
            }
            if (maxChoiceVal !== 0 && minChoiceVal > maxChoiceVal) {
                max_choices_select.val(max_choices_select_previous);
                alert(lodash.get(APPETIT_CHOICE_GROUP, 'locales.group_min_max_error', ''));
            }
        });

        let min_choices_select_previous = '';

        min_choices_select.on('focusin', function() {
            min_choices_select_previous = min_choices_select.val();
        });

        min_choices_select.on('change', function() {
            const maxChoiceVal = parseInt(max_choices_select.val(), 10);
            const minChoiceVal = parseInt(this.value, 10);
            if (lodash.isNaN(maxChoiceVal) || lodash.isNaN(minChoiceVal) || minChoiceVal === 0) {
                return;
            }
            if (maxChoiceVal !== 0 && minChoiceVal > maxChoiceVal) {
                min_choices_select.val(min_choices_select_previous);
                alert(lodash.get(APPETIT_CHOICE_GROUP, 'locales.group_min_max_error', ''));
            }
        });

        jQuery('.choice_entry').each(function(index) {
            handleChoiceRemove(jQuery(this));
        });
    }
    jQuery(document).ready(function() {
        handleChoices();
    });
})()