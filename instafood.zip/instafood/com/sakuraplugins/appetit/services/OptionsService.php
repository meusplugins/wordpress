<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../utils/PriceUtil.php');
require_once(plugin_dir_path(__FILE__) . '../utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . '../config.php');
require_once(plugin_dir_path(__FILE__) . '../templates/admin/settings/SettingsConfig.php');
require_once(plugin_dir_path(__FILE__) . 'LocalesService.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\PriceUtil;
use com\sakuraplugins\appetit\utils\TimeUtils;

class OptionsService {
    private static $instance = null;
    private $options = [];

    public function getOptions() {
        if (isset($this->options) && is_array($this->options) && sizeof($this->options) > 0) {
            return $this->options;
        }
        $this->options['INSTAFOOD_PREVIEW_MODE'] = INSTAFOOD_PREVIEW_MODE;
        $this->options['INSTAFOOD_QR_MOBILE_APP_URL'] = INSTAFOOD_QR_MOBILE_APP_URL;
        $this->options['rest_url'] = esc_url_raw(rest_url() . 'instafood');
        $this->options['delivery_enabled'] = OptionUtil::getInstance()->getOption("delivery_enabled", '');
        $this->options['delivery_payment_pethods'] = $this->_groupPaymentMethods(
            OptionUtil::getInstance()->getOption("delivery_payment_cash_on_delivery", ''),
            OptionUtil::getInstance()->getOption("delivery_payment_stripe", '')
        );

        $this->options['restaurant_delivery_min_order_value'] = OptionUtil::getInstance()->getOption("restaurant_delivery_min_order_value", '');
        $this->options['order_delivery_cost'] = OptionUtil::getInstance()->getOption("order_delivery_cost", '');
        
        $this->options['local_order_enabled'] = OptionUtil::getInstance()->getOption("local_order_enabled", '');
        $this->options['dinein_payment_pethods'] = $this->_groupPaymentMethods(
            OptionUtil::getInstance()->getOption("dine_in_payment_cash_on_delivery", ''),
            OptionUtil::getInstance()->getOption("dine_in_payment_stripe", '')
        );
        
        $this->options['pickup_order_enabled'] = OptionUtil::getInstance()->getOption("pickup_order_enabled", '');
        $this->options['pickup_payment_pethods'] = $this->_groupPaymentMethods(
            OptionUtil::getInstance()->getOption("pickup_payment_cash_on_delivery", ''),
            OptionUtil::getInstance()->getOption("pickup_payment_stripe", '')
        );

        $this->options['secondary_lang_enabled'] = OptionUtil::getInstance()->getOption("secondary_lang_enabled", '');
        $this->options['price_display_template'] = PriceUtil::getInstance()->getDisplayWithCurrency('<%= price %>');

        $this->options['tipping_percentage'] = OptionUtil::getInstance()->getOption("tipping_percentage", '');
        $this->options['hasReCaptcha'] = OptionUtil::getInstance()->hasReCaptcha();
        
        $this->options['restaurant_phone'] = OptionUtil::getInstance()->getOption("restaurant_phone", '');
        $this->options['restaurant_address'] = OptionUtil::getInstance()->getOption("restaurant_address", '');

        $this->options['business_hours'] = $this->_agregateBusinessHours();
        $this->options['is_open_now'] = TimeUtils::getInstance()->isOpenNow();

        $this->options['terms_link'] = urlencode(OptionUtil::getInstance()->getOption("terms_link", '#'));

        $this->options['homepage_product_description_length'] = OptionUtil::getInstance()->getOption("homepage_product_description_length", '');
        $this->options['disabled_add_to_cart'] = OptionUtil::getInstance()->getOption("disabled_add_to_cart", '');
        $this->options['frontend_enabled_decimal_dot'] = OptionUtil::getInstance()->getOption("frontend_enabled_decimal_dot", '');
        $this->options['enable_call_restaurant_homepage'] = OptionUtil::getInstance()->getOption("enable_call_restaurant_homepage", '');

        return $this->options;
    }

    private function _agregateBusinessHours() {
        $apt_locales = LocalesService::getInstance()->getLocales();
        $days = TimeUtils::getInstance()->getDays();
        $business_hours = [];
        foreach ($days as $day) {
            $jsonData = OptionUtil::getInstance()->getOption('business_hours_raw_data_' . $day['key'], '');
            $decoded_day_intervals_data = [];
            try {
                $decoded_day_intervals_data = json_decode($jsonData);
            } catch (Exception $e) {};
            $dayKey = $day['key'];
            $dayChecked = OptionUtil::getInstance()->getOption("business_hours_$dayKey", '');
            if ($dayChecked === '') {
                continue;
            }
            if (!is_array($decoded_day_intervals_data)) {
                continue;
            }
            if (sizeof($decoded_day_intervals_data) === 0) {
                continue;
            }
            $business_hours[] = [
                'day_key' => $dayKey,
                'day_locale' => $apt_locales[$dayKey] ?? '',
                'day_intervals' => $decoded_day_intervals_data,
            ];
        }
        return $business_hours;
    }

    private function _groupPaymentMethods($cash_on_delivery, $stripe): array {
        $out = [];
        if ($cash_on_delivery === 'ON') {
            array_push($out, 'cash_on_delivery');
        }
        if ($stripe === 'ON') {
            $isStripePublishableKey = trim(OptionUtil::getInstance()->getOption("stripe_public_api_key", '')) !== '';
            $isStripeSecretKey = trim(OptionUtil::getInstance()->getOption("stripe_secret_api_key", '')) !== '';
            if ($isStripePublishableKey && $isStripeSecretKey) {
                array_push($out, 'stripe');
            }
        }
        return $out;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new OptionsService();
        }
        return self::$instance;
    }
}
?>