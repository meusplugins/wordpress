<?php
namespace com\sakuraplugins\appetit\cpt;
if ( ! defined('ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . 'GenericPostType.php');
require_once(plugin_dir_path(__FILE__) . 'ICpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/UserManagement.php');

use com\sakuraplugins\appetit\utils\UserManagement;

class OrderCpt extends GenericPostType {

    const REWRITE_KEY = 'ORDER_REWRITE_KEY';
    const DEFAULT_REWRITE_SLUG = 'appetit-order';

    public static function getMetaKey(): string {
        return 'appetit_order_meta';
    }

    public static function getPostType(): string {
        return 'appetit_order';
    }
    
    public static function getPostTypePlural(): string {
        return 'appetit_orders';
    }

    public static function CPTSupports(): array {
        return ['title'];
    }

    public function getSettings($rewrite, $menuPosition = 80): array {
        $labels = [
            'name'               => _x('InstaFood orders', 'post type general name', 'instafood'),
            'singular_name'      => _x('InstaFood order', 'post type singular name', 'instafood'),
            'menu_name'          => _x('InstaFood orders', 'admin menu', 'instafood'),
            'name_admin_bar'     => _x('InstaFood order', 'add new on admin bar', 'instafood'),
            'add_new'            => _x('Add new order', 'add new item' , 'instafood'),
            'add_new_item'       => esc_html__('Add New order ', 'instafood'),
            'new_item'           => esc_html__('New InstaFood order', 'instafood'),
            'edit_item'          => esc_html__('Edit InstaFood order', 'instafood'),
            'view_item'          => esc_html__('View InstaFood order', 'instafood'),
            'all_items'          => esc_html__('All InstaFood orders', 'instafood'),
            'search_items'       => esc_html__('Search InstaFood orders', 'instafood'),
            'parent_item_colon'  => esc_html__('Parent InstaFood orders', 'instafood'),
            'not_found'          => esc_html__('No InstaFood orders found.', 'instafood'),
            'not_found_in_trash' => esc_html__('No InstaFood orders found in Trash.', 'instafood' )
        ];
        
        $capabilities = UserManagement::compile_post_type_capabilities(self::getPostType(), self::getPostTypePlural());

        $args = [
            'capabilities' => $capabilities,
            'labels'             => $labels,
            'description'        => esc_html__('Description', 'instafood'),
            'public'             => true,
            'publicly_queryable' => false,
            'show_in_rest'       => false,
            'exclude_from_search' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => $rewrite),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => $menuPosition,
            'supports'           => self::CPTSupports(),
        ];
        return $args;
    }
}

?>
