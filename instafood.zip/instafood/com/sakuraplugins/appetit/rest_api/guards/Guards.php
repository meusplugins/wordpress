<?php
namespace com\sakuraplugins\appetit\rest_api\guards;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'RecaptchaGuard.php');
require_once(plugin_dir_path(__FILE__) . 'UserGuard.php');

class Guards {
    const RecaptchaGuard = RecaptchaGuard::class;
    const UserGuard = UserGuard::class;

    public static function use(array $guards, \WP_REST_Request $request) {
        $firstErrorResponse = false;
        for ($i = 0; $i < sizeof($guards); $i++) { 
            $guardValidator = $guards[$i]::validateRequest($request);
            if ($guardValidator instanceof \WP_REST_Response) {
                $firstErrorResponse = $guardValidator;
                break;
            }
        }
        return $firstErrorResponse;
    }
}
?>