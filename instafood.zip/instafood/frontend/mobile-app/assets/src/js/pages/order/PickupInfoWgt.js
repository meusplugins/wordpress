import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';
import GenericPopup from '../../components/popup/GenericPopup';
import Checkbox from '../../components/checkbox/Checkbox';
import RestManager from '../../services/RestManager';
import StorageUtil from '../../utils/StorageUtil';

class PickupInfoWgt {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;
    _staticHolderUI;
    _genericPopup;
    _popupOKBtn;
    _savePickupInfo = false;
    _pickupCustomerPhone = '';
    _customerFirstName = '';

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.render(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        const isPickup = Order.getInstance().isPickup();
        if (!isPickup) {
            return;
        }
        const template = `
        <div class="apt_content_widget mt_20 bm_20 pickup_info_widget">
            <div class="in_content">
                <div class="wgt_header space_btw clickable">
                    <div class="wgt_title_ui">
                        <span class="icon-phone1 wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('pickup_person_info_wgt_title') }</div>
                    </div>
                    <div class="wgt_main_action"><span class="icon-edit-3"></span></div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="wgt_info_clickable">${ LanguageUtils.getInstance().getLabel('pickup_contact_info_wgt_info') }</div>
                </div>
            </div>
        </div>
        `;

        const _this = this;
        this._ui = jQuery(template);
        this._ui.appendTo(this._staticHolderUI);
        this._ui.find('.wgt_main_action').click(function(event) {
            event.preventDefault();
            _this._openPickupEdit();
        });
        this._ui.find('.wgt_info_clickable').click(function(event) {
            event.preventDefault();
            _this._openPickupEdit();
        });

        this._savePickupInfo = StorageUtil.getData('_savePickupInfo', false);
        
        if (this._savePickupInfo) {
            if (this._pickupCustomerPhone === '') {
                this._pickupCustomerPhone = StorageUtil.getData('_pickupCustomerPhone', '');
            }
            if (this._customerFirstName === '') {
                this._customerFirstName = StorageUtil.getData('_customerFirstName', '');
            }
        }

        // Order.getInstance().setCanDeliverToAddress(this._canAddPickupInfo());
        if (this._canAddPickupInfo()) {
            this._ui.find('.wgt_info_clickable').html(this._composePickupInfo());
            Order.getInstance().setPickupInfo({
                _pickupCustomerPhone: this._pickupCustomerPhone,
                _customerFirstName: this._customerFirstName,
            })
        }
    }

    _openPickupEdit() {
        this._genericPopup = new GenericPopup(LanguageUtils.getInstance().getLabel('pickup_person_info_popup_title'));
        this._genericPopup.setCloseHook(() => {
            StorageUtil.setData('_savePickupInfo', this._savePickupInfo);
            if (this._savePickupInfo) {
                // save for later
                StorageUtil.setData('_pickupCustomerPhone', this._pickupCustomerPhone);
                StorageUtil.setData('_customerFirstName', this._customerFirstName);
            } else {
                StorageUtil.setData('_pickupCustomerPhone', null);
                StorageUtil.setData('_customerFirstName', null);
            }
        })
        this._genericPopup.render();
        const popupContentUI = this._genericPopup.getContentUI();
        const popupFooterUI = this._genericPopup.getFooterContentUI();

        const customer_phone = LanguageUtils.getInstance().getLabel('customer_phone');
        const customer_name = LanguageUtils.getInstance().getLabel('customer_picku_first_name');


        const addressTemplate = `
            <div class="if_form_control mb_15">
                <div class="label">${ customer_name }</div>
                <input class="if_text_input full_w customer_name" name="ship-city" value="${ this._customerFirstName }" autocomplete="given-name" type="text" />
            </div>
            <div class="if_form_control mb_15">
                <div class="label">${ customer_phone } *</div>
                <input class="if_text_input full_w customer_phone" type="tel" name="phone" value="${ this._pickupCustomerPhone }" required autocomplete="tel" />
            </div>
            <div class="mb_15"></div>
        `;

        const _this = this;
        const addressUI = jQuery(addressTemplate);
        addressUI.appendTo(popupContentUI);

        this._popupOKBtn = jQuery(`<a href="#" class="apt_button primary validate_address_btn inactive">${ LanguageUtils.getInstance().getLabel('customer_save_contact') }</a>`);
        this._popupOKBtn.appendTo(popupFooterUI);
        this._popupOKBtn.click(function(event) {
            event.preventDefault();
            if (!_this._canAddPickupInfo()) {
                return;
            }
            _this._validatePickup();
        })

        addressUI.find('.customer_phone').on('keyup', function(event) {
            event.preventDefault();
            _this._pickupCustomerPhone = addressUI.find('.customer_phone').val();
            _this._validateAddPickupInfo();
        })

        addressUI.find('.customer_name').on('keyup', function(event) {
            event.preventDefault();
            _this._customerFirstName = addressUI.find('.customer_name').val();
            _this._validateAddPickupInfo();
        })

        // const agreeStoreAddressCB = new Checkbox(
        // popupContentUI, 
        // LanguageUtils.getInstance().getLabel('customer_delivery_save_data_lable'), 
        // val => {
        //     this._savePickupInfo = val;
        // });
        // agreeStoreAddressCB.render();
        // agreeStoreAddressCB.setSelected(this._savePickupInfo);

        _this._validateAddPickupInfo();
    }

    _validateAddPickupInfo() {
        const validate_address_btn = this._genericPopup.getFooterContentUI().find('.validate_address_btn');
        if (this._canAddPickupInfo()) {
            if (validate_address_btn.hasClass('inactive')) {
                validate_address_btn.removeClass('inactive')
            }
        } else {
            if (!validate_address_btn.hasClass('inactive')) {
                validate_address_btn.addClass('inactive')
            }
        }
    }
    
    _canAddPickupInfo() {
        return this._pickupCustomerPhone !== ''; // && this._customerFirstName !== '';
    }

    _validatePickup() {
        StorageUtil.setData('_savePickupInfo', this._savePickupInfo);
        if (this._savePickupInfo) {
            // save for later
            StorageUtil.setData('_pickupCustomerPhone', this._pickupCustomerPhone);
            StorageUtil.setData('_customerFirstName', this._customerFirstName);
        } else {
            StorageUtil.setData('_pickupCustomerPhone', null);
            StorageUtil.setData('_customerFirstName', null);
        }
        this._genericPopup.close();
        Order.getInstance().setPickupInfo({
            _pickupCustomerPhone: this._pickupCustomerPhone,
            _customerFirstName: this._customerFirstName,
        }, true)
    }

    _composePickupInfo() {
        if (this._customerFirstName && this._customerFirstName !== '') {
            return `${ this._customerFirstName }, ${ this._pickupCustomerPhone }`;
        }
        return `${ this._pickupCustomerPhone }`;
    }

}
export default PickupInfoWgt;