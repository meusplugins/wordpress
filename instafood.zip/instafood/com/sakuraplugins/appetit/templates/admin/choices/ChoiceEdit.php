<?php
namespace com\sakuraplugins\appetit\templates\admin\choices;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../../../cpt/ChoiceGroupsCpt.php');

use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt as ChoiceGroupsCpt;

class ChoiceEdit {

    function onNewChoice($taxonomy) {
        ?>
            <div class="form-group">
                <label for="choice_name_1"><?= esc_html__('Choice name (Primary language)*', 'instafood') ?></label>
                <input type="text" value="" required
                    class="form-control" id="choice_name_1" required name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[primary_lang_choice_name]') ?>">
            </div>
            <div class="form-group">
                <label for="choice_name_2"><?= esc_html__('Choice name (Optional - secondary language)', 'instafood') ?></label>
                <input type="text" value=""
                    class="form-control" id="choice_name_2" required name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[secondary_lang_choice_name]') ?>">
            </div>
            <div class="form-group">
                <label for="choice_price"><?= esc_html__('Price*', 'instafood') ?></label>
                <input type="number" value="0" min="0" step=".01" 
                    class="form-control" id="choice_price" required name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[choice_price]') ?>">
            </div>
        <?php
    }

    function onEditChoice($term) {
        $post_meta = get_term_meta($term->term_id, ChoiceGroupsCpt::CHOICE_META_KEY, true);
        ?>
            <tr>
                <th>
                    <?= esc_html__('Choice name (Primary language)*', 'instafood') ?>
                </th>
                <td>
                    <input type="text" required value="<?= isset($post_meta['primary_lang_choice_name']) ? esc_attr($post_meta['primary_lang_choice_name']) : '' ?>"
                    class="form-control" id="choice_name_2" name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[primary_lang_choice_name]') ?>">
                </td>
            </tr>
            <tr>
                <th>
                    <?= esc_html__('Choice name (Optional - secondary language)', 'instafood') ?>
                </th>
                <td>
                    <input type="text" value="<?= isset($post_meta['secondary_lang_choice_name']) ? esc_attr($post_meta['secondary_lang_choice_name']) : '' ?>"
                    class="form-control" id="choice_name_2" name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[secondary_lang_choice_name]') ?>">
                </td>
            </tr>
            <tr>
                <th>
                    <p><?= esc_html__('Price*', 'instafood') ?></p>
                    <p><?= esc_html__('Enter 0 if the choice is free.', 'instafood') ?></p>
                </th>
                <td>
                    <input type="number" min="0" step=".01" value="<?= isset($post_meta['choice_price']) ? esc_attr($post_meta['choice_price']) : 0 ?>"
                    class="form-control" id="choice_price" name="<?= esc_attr(ChoiceGroupsCpt::CHOICE_META_KEY . '[choice_price]') ?>">
                </td>
            </tr>
        <?php
    }
}
?>