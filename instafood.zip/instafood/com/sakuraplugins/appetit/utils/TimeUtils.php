<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . 'OptionUtil.php');

use com\sakuraplugins\appetit\utils\OptionUtil;

class TimeUtils {

    private static $instance = null;
    private $restaurant_timezone;
    private $order_pickup_start_date;
    private $order_pickup_end_date;
    private $days;

    private function __construct() {
        $this->restaurant_timezone = OptionUtil::getInstance()->getOption('restaurant_timezone', 'Europe/Amsterdam');
        $this->order_pickup_start_date = OptionUtil::getInstance()->getOption('order_pickup_start_date', '');
        $this->order_pickup_end_date = OptionUtil::getInstance()->getOption('order_pickup_end_date', '');
        $this->days = $this->getDays();
    }

    public function getAllowedPickupDays() {
        $pickup_order_enabled = OptionUtil::getInstance()->getOption("pickup_order_enabled", '');
        if ($pickup_order_enabled !== 'ON') {
            return false;
        }
        $dates = [];
        $startDate = new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));

        $isPickupStartDateInTheFuture = $this->order_pickup_start_date !== '' && $this->order_pickup_start_date !== 0 && is_numeric(intval($this->order_pickup_start_date));
        $isPickupEndDateInTheFuture = $this->order_pickup_end_date !== '' && $this->order_pickup_end_date !== 0 && is_numeric(intval($this->order_pickup_end_date));
        
        if ($isPickupStartDateInTheFuture) {
            $startDateDaysInFuture = intval($this->order_pickup_start_date);
            $startDate->add(new \DateInterval('P' . $startDateDaysInFuture . 'D'));
        }

        $safeStartDateInFuture = 0;
        while (!$this->_dayHasBussinessHours($startDate->format('Y-m-d'), !$isPickupStartDateInTheFuture) && $safeStartDateInFuture < 50) {
            $safeStartDateInFuture++;
            $startDate->add(new \DateInterval('P1D'));
        }
        
        array_push($dates, [
            'fe' => $startDate->format('m/d/Y'),
            'be' => $startDate->format('Y-m-d')
        ]);

        if ($isPickupEndDateInTheFuture) {
            $startDateClone = clone $startDate;
            $daysInFuture = intval($this->order_pickup_end_date);
            $count = 0;
            $safetyFutureCount = 0; // safety if has pickup in the future but no bussiness hours
            while ($count < $daysInFuture && $safetyFutureCount < 100) {
                $safetyFutureCount++;
                $startDateClone->add(new \DateInterval('P1D'));
                $hasBussinessHours = $this->_dayHasBussinessHours($startDateClone->format('Y-m-d'));
                if ($hasBussinessHours) {
                    array_push($dates, [
                        'fe' => $startDateClone->format('m/d/Y'),
                        'be' => $startDateClone->format('Y-m-d')
                    ]);
                    $count++;
                }
            }
        }

        $datesOptput = [];
        foreach ($dates as $dateEntry) {
            array_push($datesOptput, [
                'day' => $dateEntry['fe'],
                'hours' => $this->_getDayBussinessHours($dateEntry['be']),
            ]);
        }
        return $datesOptput;
    }

    private function _dayHasBussinessHours($dayDate, $checkToday = false) {
        $out = false;
        $d = new \DateTime($dayDate, new \DateTimeZone($this->restaurant_timezone));
        $dayKey = $d->format('D');
        $dayJsonData = OptionUtil::getInstance()->getOption('business_hours_raw_data_' . $dayKey, '');
        $dayChecked = OptionUtil::getInstance()->getOption("business_hours_$dayKey", '');
        if ($dayChecked === '') {
            return false;
        }

        $decoded_day_intervals_data = false;
        try {
            $decoded_day_intervals_data = json_decode($dayJsonData);
        } catch (Exception $e) {
            // no bussiness hours
            return false;
        };

        if (!is_array($decoded_day_intervals_data)) {
            return false;
        }

        if (sizeof($decoded_day_intervals_data) < 1) {
            return false;
        }

        if (!$checkToday) {
            return true;
        }

        $dateNow = new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));
        $isTodayinWeek = $dateNow->format('D') === $d->format('D');

        if (!$isTodayinWeek) {
            return true;
        }

        $firstInterval = $decoded_day_intervals_data[0];
        $lastInterval = end($decoded_day_intervals_data);

        $fi_interval_start_hh = $firstInterval->interval_start_hh;
        $fi_interval_start_mm = $firstInterval->interval_start_mm;
        $fi_am_pm_select_start = $firstInterval->am_pm_select_start;

        $li_interval_stop_hh = $lastInterval->interval_stop_hh;
        $li_interval_stop_mm = $lastInterval->interval_stop_mm;
        $li_am_pm_select_stop = $lastInterval->am_pm_select_stop;

        $format = 'Y-m-d h:i A';
        $dateStart = \DateTime::createFromFormat($format, "$dayDate $fi_interval_start_hh:$fi_interval_start_mm $fi_am_pm_select_start", new \DateTimeZone($this->restaurant_timezone));
        $dateEnd = \DateTime::createFromFormat($format, "$dayDate $li_interval_stop_hh:$li_interval_stop_mm $li_am_pm_select_stop", new \DateTimeZone($this->restaurant_timezone));

        if (($dateStart < $dateNow) && ($dateNow < $dateEnd)) {
            return true;
        }
        return $out;
    }

    private function _getDayBussinessHours($dayDate) {
        $hours = [];

        $d = new \DateTime($dayDate, new \DateTimeZone($this->restaurant_timezone));
        $dayKey = $d->format('D');
        $dayJsonData = OptionUtil::getInstance()->getOption('business_hours_raw_data_' . $dayKey, '');

        $dayChecked = OptionUtil::getInstance()->getOption("business_hours_$dayKey", '');
        if ($dayChecked === '') {
            return [];
        }

        $decoded_day_intervals_data = false;
        try {
            $decoded_day_intervals_data = json_decode($dayJsonData);
        } catch (Exception $e) {
            // no bussiness hours
            return [];
        };

        if (!is_array($decoded_day_intervals_data)) {
            return [];
        }

        if (sizeof($decoded_day_intervals_data) < 1) {
            return [];
        }

        $dateNow = new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));
        $isTodayinWeek = $dateNow->format('Y-m-d') === $d->format('Y-m-d');

        foreach ($decoded_day_intervals_data as $interval) {
            $interval_start_hh = $interval->interval_start_hh;
            $interval_start_mm = $interval->interval_start_mm;
            $am_pm_select_start = $interval->am_pm_select_start;
    
            $interval_stop_hh = $interval->interval_stop_hh;
            $interval_stop_mm = $interval->interval_stop_mm;
            $am_pm_select_stop = $interval->am_pm_select_stop;
            
            $format = 'Y-m-d h:i A';
            $dateStart = \DateTime::createFromFormat($format, "$dayDate $interval_start_hh:$interval_start_mm $am_pm_select_start", new \DateTimeZone($this->restaurant_timezone));
            $dateEnd = \DateTime::createFromFormat($format, "$dayDate $interval_stop_hh:$interval_stop_mm $am_pm_select_stop", new \DateTimeZone($this->restaurant_timezone));            

            $minDiff = abs($dateEnd->getTimestamp() - $dateStart->getTimestamp()) / 60;
            $minStepper = round($minDiff / 30);
            for ($i = 0; $i <= $minStepper; $i++) { 
                $dateStart->add(new \DateInterval('PT30M'));
                if ($dateStart <= $dateEnd) {
                    if ($isTodayinWeek) {
                        if ($dateNow <= $dateStart) {
                            array_push($hours, $dateStart->format('h:i A')); 
                        }
                    } else {
                        array_push($hours, $dateStart->format('h:i A')); 
                    }
                }
            }
        }
        

        return $hours;
    }

    public function isOpenNow(bool $showExtraInfo = false) {
        $isOpen = false;
        $d = new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));
        
        $dayKey = $d->format('D');
        $dayJsonData = OptionUtil::getInstance()->getOption('business_hours_raw_data_' . $dayKey, '');
        $dayChecked = OptionUtil::getInstance()->getOption("business_hours_$dayKey", '');
        if ($dayChecked === '') {
            return false;
        }

        $decoded_day_intervals_data = false;
        try {
            $decoded_day_intervals_data = json_decode($dayJsonData);
        } catch (Exception $e) {
            // no bussiness hours
            return false;
        };

        if (!is_array($decoded_day_intervals_data)) {
            return false;
        }

        if (sizeof($decoded_day_intervals_data) < 1) {
            return false;
        }

        $intervals = [];

        foreach ($decoded_day_intervals_data as $interval) {
            $interval_start_hh = $interval->interval_start_hh;
            $interval_start_mm = $interval->interval_start_mm;
            $am_pm_select_start = $interval->am_pm_select_start;
    
            $interval_stop_hh = $interval->interval_stop_hh;
            $interval_stop_mm = $interval->interval_stop_mm;
            $am_pm_select_stop = $interval->am_pm_select_stop;
            
            $format = 'Y-m-d h:i A';
            $dayDate = $d->format('Y-m-d');
            
            $dateStart = \DateTime::createFromFormat($format, "$dayDate $interval_start_hh:$interval_start_mm $am_pm_select_start", new \DateTimeZone($this->restaurant_timezone));
            $dateEnd = \DateTime::createFromFormat($format, "$dayDate $interval_stop_hh:$interval_stop_mm $am_pm_select_stop", new \DateTimeZone($this->restaurant_timezone));

            $isEndOfDay = $interval_stop_hh === 12 && $interval_stop_mm === '00' && $am_pm_select_stop === 'AM';
            if ($isEndOfDay) {
                $dateEnd = \DateTime::createFromFormat('Y-m-d h:i:s A', "$dayDate 11:59:59 PM", new \DateTimeZone($this->restaurant_timezone));
            }
            
            array_push($intervals, [
                'dateStart' => $dateStart,
                'dateEnd' => $dateEnd,
            ]);

            if (($dateStart < $d) && ($d < $dateEnd)) {
                $isOpen = true;
                break;
            }
        }

        if ($showExtraInfo) {
            return [
                'isOpen' => $isOpen,
                'intervals' => $intervals,
                'now' => $d
            ];
        }
        return $isOpen;
    }


    public function getDays() {
        return [
            ['key' => 'Sun', 'label' => esc_html__('Sunday', 'instafood')],
            ['key' => 'Mon', 'label' => esc_html__('Monday', 'instafood')],
            ['key' => 'Tue', 'label' => esc_html__('Tuesday', 'instafood')],
            ['key' => 'Wed', 'label' => esc_html__('Wednesday', 'instafood')],
            ['key' => 'Thu', 'label' => esc_html__('Thursday', 'instafood')],
            ['key' => 'Fri', 'label' => esc_html__('Friday', 'instafood')],
            ['key' => 'Sat', 'label' => esc_html__('Saturday', 'instafood')],
        ];
    }

    public function getDateNow() {
        return new \DateTime('NOW', new \DateTimeZone($this->restaurant_timezone));
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new TimeUtils();
        }
        return self::$instance;
    }   
}
?>