<?php
/**
 * Catalog of the Happy Addons Pro components available for Elementor V4 (Atomic).
 *
 * A plain static list, like the Happy Addons one: nothing is instantiated.
 * Entries use the Happy Addons registry format, plus the absolute 'path' and
 * the full class name ('fqcn') because the code lives in this plugin.
 */
namespace Happy_Addons_Pro\Classes;

defined( 'ABSPATH' ) || die();

class Atomic_Registry {

	/**
	 * @return array[]
	 */
	public static function features() {
		return [
			'global-animation' => [
				'title'     => __( 'Global Animation', 'happy-addons-pro' ),
				'icon'      => 'hm hm-alien',
				'is_active' => true,
				'is_pro'    => true,
				'is_gsap'   => true,
				'path'      => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/global-animation.php',
				'fqcn'      => 'Happy_Addons_Pro\\Extensions\\Atomic\\Global_Animation',
				'script'    => Atomic_Manager::SCRIPT_HANDLE,
				'style'     => 'happy-pro-atomic-global-animation',
				'prehide'   => false,
			],
			'infinite-marquee' => [
				'title'          => __( 'Infinite Marquee', 'happy-addons-pro' ),
				'icon'           => 'huge huge-infinity-02',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => true,
				'path'           => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/infinite-marquee.php',
				'fqcn'           => 'Happy_Addons_Pro\Extensions\Atomic\Infinite_Marquee',
				'script'         => Atomic_Manager::SCRIPT_HANDLE,
				'style'          => 'happy-pro-atomic-infinite-marquee',
				'editor_preview' => true,
			],
			'horizontal-scroll' => [
				'title'     => __( 'Horizontal Scroll', 'happy-addons-pro' ),
				'icon'      => 'huge huge-horizonal-scroll-point-round',
				'is_active' => true,
				'is_pro'    => true,
				'is_gsap'   => true,
				'path'      => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/horizontal-scroll.php',
				'fqcn'      => 'Happy_Addons_Pro\Extensions\Atomic\Horizontal_Scroll',
				'script'    => Atomic_Manager::SCRIPT_HANDLE,
				'style'     => 'happy-pro-atomic-horizontal-scroll',
			],
			'image-trails'     => [
				'title'          => __( 'Image Trails', 'happy-addons-pro' ),
				'icon'           => 'hm hm-media-all',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => true,
				'path'           => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/image-trails.php',
				'fqcn'           => 'Happy_Addons_Pro\Extensions\Atomic\Image_Trails',
				'script'         => Atomic_Manager::SCRIPT_HANDLE,
				'style'          => 'happy-pro-atomic-image-trails',
				'editor_preview' => true,
				'prehide'        => false,
			],
			'sticky-pin-element' => [
				'title'     => __( 'Sticky Pin Element', 'happy-addons-pro' ),
				'icon'      => 'hm hm-sticky',
				'is_active' => true,
				'is_pro'    => true,
				'is_gsap'   => true,
				'path'      => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/sticky-pin-element.php',
				'fqcn'      => 'Happy_Addons_Pro\\Extensions\\Atomic\\Sticky_Pin_Element',
				'script'    => Atomic_Manager::SCRIPT_HANDLE,
				'style'     => 'happy-pro-atomic-sticky-pin-element',
				'prehide'   => false,
			],
			'display-condition' => [
				'title'     => __( 'Display Condition', 'happy-addons-pro' ),
				'icon'      => 'hm hm-display-condition',
				'is_active' => true,
				'is_pro'    => true,
				'is_gsap'   => false,
				'path'      => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/display-condition.php',
				'fqcn'      => 'Happy_Addons_Pro\\Extensions\\Atomic\\Display_Condition',
			],
			'happy-particle-effects' => [
				'title'          => __( 'Happy Particle Effects', 'happy-addons-pro' ),
				'icon'           => 'hm hm-spark',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => false,
				'path'           => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/happy-particle-effects.php',
				'fqcn'           => 'Happy_Addons_Pro\\Extensions\\Atomic\\Happy_Particle_Effects',
				'script'         => Atomic_Manager::SCRIPT_HANDLE,
				'style'          => 'happy-pro-atomic-happy-particle-effects',
				'editor_preview' => true,
				'prehide'        => false,
			],
			'multi-layer-parallax' => [
				'title'          => __( 'Multi Layer Parallax', 'happy-addons-pro' ),
				'icon'           => 'huge huge-layers-02',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => false,
				'path'           => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/multi-layer-parallax.php',
				'fqcn'           => 'Happy_Addons_Pro\\Extensions\\Atomic\\Multi_Layer_Parallax',
				'script'         => Atomic_Manager::SCRIPT_HANDLE,
				'style'          => 'happy-pro-atomic-multi-layer-parallax',
				'editor_preview' => true,
				'prehide'        => false,
			],
			'global-badge' => [
				'title'          => __( 'Global Badge', 'happy-addons-pro' ),
				'icon'           => 'hm hm-global-badge',
				'is_active'      => true,
				'is_pro'         => true,
				'is_gsap'        => false,
				'path'           => HAPPY_ADDONS_PRO_DIR_PATH . 'extensions/atomic/global-badge.php',
				'fqcn'           => 'Happy_Addons_Pro\\Extensions\\Atomic\\Global_Badge',
				'script'         => Atomic_Manager::SCRIPT_HANDLE,
				'style'          => 'happy-pro-atomic-global-badge',
				'editor_preview' => true,
				'prehide'        => false,
			],
		];
	}
}
