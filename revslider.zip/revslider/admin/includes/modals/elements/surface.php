<?php
/** @author ThemePunch <info@themepunch.com> @copyright 2026 ThemePunch */
if(!defined('ABSPATH')) exit();
?>
<sr-separator keepborder id="sr_surface_material">
 <sr-separator-head notoggle>
  <sr-separator-title><?php _e('Surface Material','revslider'); ?></sr-separator-title>
  <sr-onoff style="right:0px" r="surface.u" data-sh=".sr_surface_fields" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra"></sr-onoff>
 </sr-separator-head>
 <sr-separator-body class="sr_surface_fields">
<sr-wrap id="sr_surface_essentials" style="--sr-v2-columns:2"></sr-wrap>
<sr-sp h="15"></sr-sp>
<sr-drop wide r="surface.preset" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra"><sr-drop-view><span class="sr--drop--value"></span><span class="sr--form--otitle"><?php _e('Material','revslider'); ?></span><span class="sr--drop--icon"><svg width="10" height="6"><use xlink:href="#Drop_Down"></use></svg></span></sr-drop-view><sr-drops data-v="chrome"><?php _e('Liquid Chrome','revslider'); ?></sr-drops><sr-drops data-v="satin"><?php _e('Satin Silver','revslider'); ?></sr-drops><sr-drops data-v="gold"><?php _e('Polished Gold','revslider'); ?></sr-drops><sr-drops data-v="holo"><?php _e('Holographic','revslider'); ?></sr-drops><sr-drops data-v="pearl"><?php _e('Pearl','revslider'); ?></sr-drops><sr-drops data-v="emboss"><?php _e('Light & Emboss','revslider'); ?></sr-drops></sr-drop>
<sr-input half class="sr--mr--10"><input name="Strength" replace r="surface.strength" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra" type="text" number="true" min="0" max="100" step="1" suffix="%" lastsuffix="%" livevisup dragnumber autocomplete="off" validate="true"><span noicon class="sr--form--otitle"><?php _e('Strength','revslider'); ?></span></sr-input><!--
--><sr-input half><input name="Speed" replace r="surface.speed" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra" type="text" number="true" min="0" max="100" step="1" suffix="%" lastsuffix="%" livevisup dragnumber autocomplete="off" validate="true"><span noicon class="sr--form--otitle"><?php _e('Speed','revslider'); ?></span></sr-input>
<sr-drop wide r="surface.detail" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra"><sr-drop-view><span class="sr--drop--value"></span><span class="sr--form--otitle"><?php _e('Contour','revslider'); ?></span><span class="sr--drop--icon"><svg width="10" height="6"><use xlink:href="#Drop_Down"></use></svg></span></sr-drop-view><sr-drops data-v="auto"><?php _e('Automatic','revslider'); ?></sr-drops><sr-drops data-v="fine"><?php _e('Fine / Lettering','revslider'); ?></sr-drops><sr-drops data-v="round"><?php _e('Rounded / Symbol','revslider'); ?></sr-drops></sr-drop>
<sr-input wide><input name="Bevel" replace r="surface.bevel" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra" type="text" number="true" min="0" max="100" step="1" suffix="%" lastsuffix="%" livevisup dragnumber autocomplete="off" validate="true"><span noicon class="sr--form--otitle"><?php _e('Bevel','revslider'); ?></span></sr-input>
<sr-wrap basic class="sr--form--grp sr--mb--15"><sr-onoff r="surface.pointer" class="sr--mr--10" data-onchange="editor.elements.surface.update" data-undoredo="editor.elements.surface.update" viewchild="layer_extra"></sr-onoff><span><?php _e('Follow Mouse','revslider'); ?></span></sr-wrap>
<sr-sp h="5"></sr-sp></sr-separator-body></sr-separator>
