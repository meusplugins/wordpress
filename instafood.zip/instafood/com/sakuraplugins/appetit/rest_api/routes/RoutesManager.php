<?php
namespace com\sakuraplugins\appetit\rest_api\routes;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../controllers/VerifyDeliveryAddressController.php');
require_once(plugin_dir_path(__FILE__) . '../controllers/GetPickupDatesController.php');
require_once(plugin_dir_path(__FILE__) . '../controllers/OrderController.php');
require_once(plugin_dir_path(__FILE__) . '../controllers/StripeWebhookController.php');
require_once(plugin_dir_path(__FILE__) . '../controllers/CallWaiterController.php');
require_once(plugin_dir_path(__FILE__) . '../controllers/GetAllDataController.php');

use com\sakuraplugins\appetit\rest_api\controllers\VerifyDeliveryAddressController;
use com\sakuraplugins\appetit\rest_api\controllers\GetPickupDatesController;
use com\sakuraplugins\appetit\rest_api\controllers\OrderController;
use com\sakuraplugins\appetit\rest_api\controllers\StripeWebhookController;
use com\sakuraplugins\appetit\rest_api\controllers\CallWaiterController;
use com\sakuraplugins\appetit\rest_api\controllers\GetAllDataController;

class RoutesManager {
    function registerRoutes() {
        $vdaC = new VerifyDeliveryAddressController();
        $vdaC->register_routes();
        $pkdc = new GetPickupDatesController();
        $pkdc->register_routes();
        $orderc = new OrderController();
        $orderc->register_routes();
        $stripeWebhook = new StripeWebhookController();
        $stripeWebhook->register_routes();
        $waiterCtrl = new CallWaiterController();
        $waiterCtrl->register_routes();
        $allDataCtrl = new GetAllDataController();
        $allDataCtrl->register_routes();
    }
}
?>