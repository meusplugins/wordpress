'use strict';

window.JetDashboardEventBus = new Vue();

window.JetDasboard = new JetDasboardClass();

//window.JetDasboard.initVueComponents();

window.JetDasboardPageInstance = JetDasboard.initDashboardPageInstance();
