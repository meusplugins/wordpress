<?php
namespace Jet_Engine\Query_Builder\File_Query;

use WP_Error;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once __DIR__ . '/base-parser.php';
require_once __DIR__ . '/csv-parser.php';
require_once __DIR__ . '/json-parser.php';
require_once __DIR__ . '/xlsx-parser.php';

/**
 * Public wrapper for file query parsing, validation, and source resolution.
 */
class Parser {

	/**
	 * Prefix reserved for parser-managed row fields.
	 *
	 * @var string
	 */
	const RESERVED_PREFIX = '__file_query_';

	/**
	 * In-request parse result cache.
	 *
	 * @var array
	 */
	protected static $memo = array();

	/**
	 * Get the default file query configuration.
	 *
	 * @return array
	 */
	public static function get_default_query() {
		return array(
			'data_type'      => 'json',
			'source_type'    => 'text',
			'source_text'    => '',
			'source_file'    => array(
				'id'   => 0,
				'name' => '',
				'url'  => '',
			),
			'items_per_page' => 0,
			'id_column'      => '',
			'order'          => 'asc',
			'orderby'        => '',
			'meta_query'     => array(),
			'json'           => array(
				'records_path' => '',
			),
			'csv'            => array(
				'row_delimiter'    => '\n',
				'column_delimiter' => ',',
				'has_header'       => true,
			),
			'xlsx'           => array(
				'sheet'      => '',
				'header_row' => 1,
			),
		);
	}

	/**
	 * Get parser limits used to constrain source size and normalized output.
	 *
	 * @return array
	 */
	public static function get_limits() {
		$limits = array(
			'max_textarea_bytes' => 2 * 1024 * 1024,
			'max_upload_bytes'   => 5 * 1024 * 1024,
			'max_rows'           => 5000,
			'max_columns'        => 200,
			'max_cell_length'    => 10000,
		);

		return apply_filters( 'jet-engine/query-builder/file-query/limits', $limits );
	}

	/**
	 * Get allowed file extensions and MIME types for each supported data type.
	 *
	 * @return array
	 */
	public static function get_allowed_mimes() {
		$mimes = array(
			'json' => array(
				'extensions' => array( 'json' ),
				'mimes'      => array( 'application/json', 'text/plain' ),
			),
			'csv'  => array(
				'extensions' => array( 'csv' ),
				'mimes'      => array(
					'text/csv',
					'text/plain',
					'application/csv',
					'text/comma-separated-values',
					'application/vnd.ms-excel',
				),
			),
			'xlsx' => array(
				'extensions' => array( 'xlsx' ),
				'mimes'      => array(
					'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
					'application/zip',
				),
			),
		);

		return apply_filters( 'jet-engine/query-builder/file-query/allowed-mimes', $mimes );
	}

	/**
	 * Normalize raw file query settings into the canonical internal shape.
	 *
	 * @param array $query Raw query settings.
	 *
	 * @return array
	 */
	public static function normalize_query( $query = array() ) {
		$query = wp_parse_args( is_array( $query ) ? $query : array(), self::get_default_query() );

		$query['data_type']              = sanitize_key( $query['data_type'] );
		$query['source_type']            = sanitize_key( $query['source_type'] );
		$query['source_text']            = is_scalar( $query['source_text'] ) ? (string) $query['source_text'] : '';
		$query['items_per_page']         = max( 0, absint( $query['items_per_page'] ) );
		$query['id_column']              = self::sanitize_property_key( $query['id_column'] );
		$query['order']                  = strtolower( sanitize_text_field( $query['order'] ) );
		$query['order']                  = in_array( $query['order'], array( 'asc', 'desc' ), true ) ? $query['order'] : 'asc';
		$query['orderby']                = self::sanitize_property_key( $query['orderby'] );
		$query['meta_query']             = is_array( $query['meta_query'] ) ? $query['meta_query'] : array();
		$query['source_file']            = self::normalize_source_file( $query['source_file'] );
		$query['json']                   = wp_parse_args( is_array( $query['json'] ) ? $query['json'] : array(), self::get_default_query()['json'] );
		$query['json']['records_path']   = sanitize_text_field( $query['json']['records_path'] );
		$query['csv']                    = wp_parse_args( is_array( $query['csv'] ) ? $query['csv'] : array(), self::get_default_query()['csv'] );
		$query['csv']['row_delimiter']   = is_scalar( $query['csv']['row_delimiter'] ) ? (string) $query['csv']['row_delimiter'] : '\n';
		$query['csv']['column_delimiter'] = is_scalar( $query['csv']['column_delimiter'] ) ? (string) $query['csv']['column_delimiter'] : ',';
		$query['csv']['has_header']      = filter_var( $query['csv']['has_header'], FILTER_VALIDATE_BOOLEAN );
		$query['xlsx']                   = wp_parse_args( is_array( $query['xlsx'] ) ? $query['xlsx'] : array(), self::get_default_query()['xlsx'] );
		$query['xlsx']['sheet']          = sanitize_text_field( $query['xlsx']['sheet'] );
		$query['xlsx']['header_row']     = max( 1, absint( $query['xlsx']['header_row'] ) );

		return $query;
	}

	/**
	 * Normalize the source file payload into the canonical structure.
	 *
	 * @param mixed $source_file Raw source file payload.
	 *
	 * @return array
	 */
	protected static function normalize_source_file( $source_file ) {
		if ( is_scalar( $source_file ) ) {
			$source_file = array(
				'id' => $source_file,
			);
		}

		$source_file = is_array( $source_file ) ? $source_file : array();

		return array(
			'id'   => ! empty( $source_file['id'] ) ? absint( $source_file['id'] ) : 0,
			'name' => ! empty( $source_file['name'] ) ? sanitize_text_field( $source_file['name'] ) : '',
			'url'  => ! empty( $source_file['url'] ) ? esc_url_raw( $source_file['url'] ) : '',
		);
	}

	/**
	 * Validate a file query configuration and optionally inspect the parsed props.
	 *
	 * @param array     $query   Raw query settings.
	 * @param array|bool $options Validation options or legacy boolean toggle.
	 *
	 * @return array
	 */
	public static function validate_query( $query = array(), $options = array() ) {
		if ( is_bool( $options ) ) {
			$options = array(
				'validate_source'  => $options,
				'validate_orderby' => $options,
			);
		}

		$options = wp_parse_args( $options, array(
			'validate_source'  => true,
			'validate_orderby' => true,
			'validate_id_column' => true,
		) );
		$query   = self::normalize_query( $query );
		$errors  = array();
		$props   = array();

		if ( ! in_array( $query['data_type'], array( 'json', 'csv', 'xlsx' ), true ) ) {
			$errors[] = __( 'Please select a valid file data type.', 'jet-engine' );
		}

		if ( ! in_array( $query['source_type'], array( 'text', 'upload' ), true ) ) {
			$errors[] = __( 'Please select a valid file source type.', 'jet-engine' );
		}

		if ( $options['validate_source'] && 'xlsx' === $query['data_type'] && 'text' === $query['source_type'] ) {
			$errors[] = __( 'XLSX sources are available only for uploaded files.', 'jet-engine' );
		}

		if ( $options['validate_source'] && 'text' === $query['source_type'] ) {
			if ( empty( $query['source_text'] ) ) {
				$errors[] = __( 'Please provide file query source text.', 'jet-engine' );
			}
		} elseif ( $options['validate_source'] && empty( $query['source_file']['id'] ) ) {
			$errors[] = __( 'Please select a media file for the file query.', 'jet-engine' );
		}

		if ( $options['validate_source'] && 'csv' === $query['data_type'] ) {
			$column_delimiter = Base_Parser::decode_delimiter( $query['csv']['column_delimiter'], false );

			if ( '' === $column_delimiter ) {
				$errors[] = __( 'CSV column delimiter cannot be empty.', 'jet-engine' );
			} elseif ( 1 < strlen( $column_delimiter ) ) {
				$errors[] = __( 'CSV column delimiter must be a single character.', 'jet-engine' );
			}
		}

		if ( ! empty( $errors ) || ! $options['validate_source'] ) {
			return array(
				'query'  => $query,
				'errors' => $errors,
				'props'  => $props,
			);
		}

		$parsed = self::parse( $query, array(
			'validate_item_ids' => ! empty( $options['validate_id_column'] ),
		) );

		if ( is_wp_error( $parsed ) ) {
			return array(
				'query'  => $query,
				'errors' => $parsed->get_error_messages(),
				'props'  => array(),
			);
		}

		$props = ! empty( $parsed['props'] ) ? $parsed['props'] : array();

		if ( $options['validate_orderby'] && ! empty( $query['orderby'] ) && ! in_array( $query['orderby'], $props, true ) ) {
			$errors[] = __( 'Order By field must match one of the parsed file properties.', 'jet-engine' );
		}

		if ( $options['validate_id_column'] && ! empty( $query['id_column'] ) && ! in_array( $query['id_column'], $props, true ) ) {
			$errors[] = __( 'ID column must match one of the parsed file properties.', 'jet-engine' );
		}

		return array(
			'query'  => $query,
			'errors' => $errors,
			'props'  => $props,
		);
	}

	/**
	 * Parse the configured file source and return normalized rows and properties.
	 *
	 * @param array $query Raw query settings.
	 *
	 * @return array|WP_Error
	 */
	public static function parse( $query = array(), $options = array() ) {
		$query  = self::normalize_query( $query );
		$options = wp_parse_args( $options, array(
			'validate_item_ids' => true,
		) );
		$limits = self::get_limits();
		$source = self::resolve_source( $query, $limits );

		if ( is_wp_error( $source ) ) {
			return $source;
		}

		$key = md5( wp_json_encode( array(
			'query'  => array(
				'data_type'   => $query['data_type'],
				'source_type' => $query['source_type'],
				'id_column'   => $query['id_column'],
				'json'        => $query['json'],
				'csv'         => $query['csv'],
				'xlsx'        => $query['xlsx'],
			),
			'options' => $options,
			'source' => $source['identity'],
			'limits' => $limits,
		) ) );

		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}

		$parser_class = self::get_parser_class( $query['data_type'] );
		$result       = $parser_class::parse( $source, $query, $limits );

		if ( ! is_wp_error( $result ) && ! empty( $options['validate_item_ids'] ) ) {
			$result = self::assign_item_ids( $result, $query, $source['identity'] );
		}

		if ( ! is_wp_error( $result ) ) {
			self::$memo[ $key ] = $result;
		}

		return $result;
	}

	/**
	 * Resolve stable internal item IDs for parsed rows.
	 *
	 * @param array  $parsed          Parsed row payload.
	 * @param array  $query           Normalized query settings.
	 * @param string $source_identity Deterministic source identity.
	 *
	 * @return array|\WP_Error
	 */
	protected static function assign_item_ids( $parsed, $query, $source_identity ) {
		$rows  = ! empty( $parsed['rows'] ) && is_array( $parsed['rows'] ) ? array_values( $parsed['rows'] ) : array();
		$props = ! empty( $parsed['props'] ) && is_array( $parsed['props'] ) ? array_values( $parsed['props'] ) : array();

		if ( empty( $rows ) ) {
			$parsed['id_mode'] = ! empty( $query['id_column'] ) ? 'explicit' : 'synthetic';
			$parsed['resolved_id_column'] = ! empty( $query['id_column'] ) ? $query['id_column'] : '';
			return $parsed;
		}

		$id_mode            = 'synthetic';
		$resolved_id_column = '';
		$item_ids           = array();

		if ( ! empty( $query['id_column'] ) ) {
			$id_mode            = 'explicit';
			$resolved_id_column = $query['id_column'];

			if ( ! in_array( $resolved_id_column, $props, true ) ) {
				return new WP_Error( 'file_query_invalid_id_column', __( 'The selected ID column was not found in the parsed file properties.', 'jet-engine' ) );
			}

			$item_ids = self::build_item_ids_from_column( $rows, $resolved_id_column, $id_mode );

			if ( is_wp_error( $item_ids ) ) {
				return $item_ids;
			}
		} else {
			$autodetected_column = self::autodetect_item_id_column( $rows, $props );

			if ( $autodetected_column ) {
				$id_mode            = 'autodetected';
				$resolved_id_column = $autodetected_column;
				$item_ids           = self::build_item_ids_from_column( $rows, $resolved_id_column, $id_mode );

				if ( is_wp_error( $item_ids ) ) {
					return $item_ids;
				}
			} else {
				$item_ids = self::build_synthetic_item_ids( $rows, $source_identity );
			}
		}

		foreach ( $rows as $index => $row ) {
			$rows[ $index ][ self::item_id_key() ] = apply_filters(
				'jet-engine/query-builder/file-query/item-id',
				$item_ids[ $index ],
				$row,
				$id_mode,
				$resolved_id_column,
				$query
			);
		}

		$parsed['rows']               = $rows;
		$parsed['id_mode']            = $id_mode;
		$parsed['resolved_id_column'] = $resolved_id_column;

		return $parsed;
	}

	/**
	 * Build deterministic internal item IDs from a configured row property.
	 *
	 * @param array  $rows    Parsed rows.
	 * @param string $column  Resolved ID column.
	 * @param string $id_mode ID mode.
	 *
	 * @return array|\WP_Error
	 */
	protected static function build_item_ids_from_column( $rows, $column, $id_mode ) {
		$item_ids = array();
		$seen_ids = array();

		foreach ( $rows as $row ) {
			$row_index = isset( $row[ self::index_key() ] ) ? absint( $row[ self::index_key() ] ) : 0;

			if ( ! array_key_exists( $column, $row ) ) {
				return new WP_Error( 'file_query_missing_row_id', sprintf( __( 'The selected ID column is missing for row %d.', 'jet-engine' ), $row_index ) );
			}

			$raw_id = self::normalize_item_id_value( $row[ $column ] );

			if ( null === $raw_id ) {
				return new WP_Error( 'file_query_invalid_row_id', sprintf( __( 'The selected ID column must contain a non-empty scalar value for row %d.', 'jet-engine' ), $row_index ) );
			}

			if ( isset( $seen_ids[ $raw_id ] ) ) {
				return new WP_Error( 'file_query_duplicate_row_id', sprintf( __( 'Duplicate File Query item ID #%1$s was found in rows %2$d and %3$d.', 'jet-engine' ), $raw_id, $seen_ids[ $raw_id ], $row_index ) );
			}

			$seen_ids[ $raw_id ] = $row_index;
			$item_ids[]          = self::build_internal_item_id( $id_mode, $column, $raw_id );
		}

		return $item_ids;
	}

	/**
	 * Auto-detect a conventional unique ID property from parsed props.
	 *
	 * @param array $rows  Parsed rows.
	 * @param array $props Parsed properties.
	 *
	 * @return string
	 */
	protected static function autodetect_item_id_column( $rows, $props ) {
		$candidates = array_intersect( array( 'id', 'item_id', 'uuid', 'guid' ), $props );
		$matches    = array();

		foreach ( $candidates as $candidate ) {
			$ids = self::build_item_ids_from_column( $rows, $candidate, 'autodetected' );

			if ( ! is_wp_error( $ids ) ) {
				$matches[] = $candidate;
			}
		}

		if ( 1 === count( $matches ) ) {
			return $matches[0];
		}

		return '';
	}

	/**
	 * Build deterministic synthetic IDs from normalized row payloads.
	 *
	 * @param array  $rows            Parsed rows.
	 * @param string $source_identity Deterministic source identity.
	 *
	 * @return array
	 */
	protected static function build_synthetic_item_ids( $rows, $source_identity ) {
		$item_ids     = array();
		$fingerprint_counts = array();

		foreach ( $rows as $row ) {
			$fingerprint = self::build_row_fingerprint( $row, $source_identity );

			if ( ! isset( $fingerprint_counts[ $fingerprint ] ) ) {
				$fingerprint_counts[ $fingerprint ] = 0;
			}

			$fingerprint_counts[ $fingerprint ]++;
			$item_ids[] = 'synthetic_' . $fingerprint . ( 1 < $fingerprint_counts[ $fingerprint ] ? '_' . $fingerprint_counts[ $fingerprint ] : '' );
		}

		return $item_ids;
	}

	/**
	 * Build a deterministic fingerprint for a normalized row payload.
	 *
	 * @param array  $row             Normalized row data.
	 * @param string $source_identity Deterministic source identity.
	 *
	 * @return string
	 */
	protected static function build_row_fingerprint( $row, $source_identity ) {
		$row = self::remove_reserved_keys( $row );
		$row = self::sort_recursive( $row );

		return md5( wp_json_encode( array(
			'source' => $source_identity,
			'row'    => $row,
		) ) );
	}

	/**
	 * Build a deterministic internal item ID from an explicit row ID value.
	 *
	 * @param string $id_mode  ID mode.
	 * @param string $column   Column name.
	 * @param string $raw_id   Canonical row ID value.
	 *
	 * @return string
	 */
	protected static function build_internal_item_id( $id_mode, $column, $raw_id ) {
		return $id_mode . '_' . md5( $column . '|' . $raw_id );
	}

	/**
	 * Normalize a row ID scalar into a stable comparable string.
	 *
	 * @param mixed $value Row ID value.
	 *
	 * @return string|null
	 */
	public static function normalize_item_id_value( $value ) {
		if ( is_array( $value ) || is_object( $value ) || null === $value ) {
			return null;
		}

		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}

		if ( is_int( $value ) || is_float( $value ) ) {
			return (string) wp_json_encode( $value );
		}

		$value = trim( (string) $value );

		return '' === $value ? null : $value;
	}

	/**
	 * Remove parser-managed keys from a normalized row payload.
	 *
	 * @param array $row Row payload.
	 *
	 * @return array
	 */
	protected static function remove_reserved_keys( $row ) {
		if ( ! is_array( $row ) ) {
			return array();
		}

		foreach ( array( self::index_key(), self::item_id_key() ) as $reserved_key ) {
			if ( array_key_exists( $reserved_key, $row ) ) {
				unset( $row[ $reserved_key ] );
			}
		}

		return $row;
	}

	/**
	 * Sort an array recursively to make fingerprinting deterministic.
	 *
	 * @param mixed $value Value to normalize.
	 *
	 * @return mixed
	 */
	protected static function sort_recursive( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		foreach ( $value as $key => $item ) {
			$value[ $key ] = self::sort_recursive( $item );
		}

		if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
			ksort( $value );
		}

		return $value;
	}

	/**
	 * Get the reserved row index key used in normalized rows.
	 *
	 * @return string
	 */
	public static function index_key() {
		return self::RESERVED_PREFIX . 'index';
	}

	/**
	 * Get the reserved row item ID key used in normalized rows.
	 *
	 * @return string
	 */
	public static function item_id_key() {
		return self::RESERVED_PREFIX . 'item_id';
	}

	/**
	 * Resolve the configured source into a content payload or readable file path.
	 *
	 * @param array $query  Normalized query settings.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	protected static function resolve_source( $query, $limits ) {
		if ( 'text' === $query['source_type'] ) {
			$bytes = strlen( $query['source_text'] );

			if ( $bytes > $limits['max_textarea_bytes'] ) {
				return new WP_Error( 'file_query_text_limit', __( 'File query source text exceeds the allowed size limit.', 'jet-engine' ) );
			}

			return array(
				'content'  => $query['source_text'],
				'identity' => 'text:' . md5( $query['source_text'] ),
				'file_path' => null,
			);
		}

		$file    = self::normalize_source_file( $query['source_file'] );
		$file_id = $file['id'];

		if ( ! $file_id ) {
			return new WP_Error( 'file_query_missing_file', __( 'File query upload is not set.', 'jet-engine' ) );
		}

		$file_path = get_attached_file( $file_id );

		if ( ! $file_path || ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
			return new WP_Error( 'file_query_unreadable_file', __( 'The selected file query attachment is missing or unreadable.', 'jet-engine' ) );
		}

		$validation = self::validate_attachment_file( $file_id, $file_path, $query['data_type'] );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$size = @filesize( $file_path );
		$size = false === $size ? 0 : absint( $size );

		if ( $size > $limits['max_upload_bytes'] ) {
			return new WP_Error( 'file_query_upload_limit', __( 'File query upload exceeds the allowed file size limit.', 'jet-engine' ) );
		}

		$content = null;

		if ( 'xlsx' !== $query['data_type'] ) {
			$content = file_get_contents( $file_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

			if ( false === $content ) {
				return new WP_Error( 'file_query_read_failed', __( 'Failed to read the selected file query attachment.', 'jet-engine' ) );
			}
		}

		return array(
			'content'   => $content,
			'identity'  => 'upload:' . $file_id . ':' . md5( $file_path . '|' . $size . '|' . filemtime( $file_path ) ),
			'file_path' => $file_path,
		);
	}

	/**
	 * Validate an uploaded attachment against the expected file type rules.
	 *
	 * @param int    $file_id   Attachment ID.
	 * @param string $file_path Absolute file path.
	 * @param string $data_type Configured file data type.
	 *
	 * @return bool|WP_Error
	 */
	protected static function validate_attachment_file( $file_id, $file_path, $data_type ) {
		$allowed = self::get_allowed_mimes();

		if ( empty( $allowed[ $data_type ] ) ) {
			return new WP_Error( 'file_query_invalid_type', __( 'Selected file query data type is not supported.', 'jet-engine' ) );
		}

		$extension = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
		$filetype  = wp_check_filetype_and_ext( $file_path, wp_basename( $file_path ) );
		$post_mime = get_post_mime_type( $file_id );
		$mimes     = array_filter( array_unique( array(
			$post_mime,
			! empty( $filetype['type'] ) ? $filetype['type'] : '',
		) ) );

		if ( ! in_array( $extension, $allowed[ $data_type ]['extensions'], true ) ) {
			return new WP_Error( 'file_query_invalid_extension', __( 'The selected file query attachment has an unsupported file extension.', 'jet-engine' ) );
		}

		if ( empty( array_intersect( $mimes, $allowed[ $data_type ]['mimes'] ) ) ) {
			return new WP_Error( 'file_query_invalid_mime', __( 'The selected file query attachment has an unsupported MIME type.', 'jet-engine' ) );
		}

		return true;
	}

	/**
	 * Sanitize a property key exposed by the parser to the query layer.
	 *
	 * @param mixed $key Raw property key.
	 *
	 * @return string
	 */
	public static function sanitize_property_key( $key ) {
		$key = is_scalar( $key ) ? strtolower( trim( (string) $key ) ) : '';
		$key = preg_replace( '/\s+/', '_', $key );
		$key = preg_replace( '/[^a-z0-9\._]/', '', $key );
		$key = preg_replace( '/_+/', '_', $key );
		$key = preg_replace( '/\.{2,}/', '.', $key );
		$key = trim( $key, '._' );

		if ( 0 === strpos( $key, self::RESERVED_PREFIX ) ) {
			return '';
		}

		return $key;
	}

	/**
	 * Resolve the concrete parser class for the configured data type.
	 *
	 * @param string $data_type File data type.
	 *
	 * @return string
	 */
	protected static function get_parser_class( $data_type ) {
		switch ( $data_type ) {
			case 'csv':
				return CSV_Parser::class;

			case 'xlsx':
				return XLSX_Parser::class;

			case 'json':
			default:
				return JSON_Parser::class;
		}
	}
}
