import SplashScreen from './pages/SplashScreen';
import ButtonMaterialEfx from './utils/ButtonMaterialEfx';
import DataUtils from './utils/DataUtils';
import LanguageUtils, { Languages } from './utils/LanguageUtils';
import StorageUtil from './utils/StorageUtil';
import HomePage from './pages/homepage/HomePage';
import Toast from './components/toast/Toast';
import AboutShopPage from './pages/shop/AboutShopPage';
import ProductPage from './pages/product/ProductPage';
import CartPage from './pages/cartpage/CartPage';
import OrderPage from './pages/order/OrderPage';
import OrderCompletePage from './pages/order_complete/OrderCompletePage';
import EventBus, { Events, Event } from './events/EventBus';

DataUtils.getInstance().setupData(jQuery('#appetit_data').html());


// Utils to automatically load primary or secondary language based on the URL query var
// possible values: 
// - your_domain/instafood?lng=secondary_lang_
// - your_domain/instafood?lng=primary_lang_
// and using table no
// - your_domain/instafood?ift=1&lng=secondary_lang_
// - your_domain/instafood?ift=1&lng=primary_lang_

const handlePresetedLanguage = () => {
    if (DataUtils.getInstance().hasLanguagePreset()) {
        const presetLang = DataUtils.getInstance().getLanguagePreset();
        const currentLang = LanguageUtils.getInstance().getLang();
        const shouldChangeLang = presetLang !== currentLang && (presetLang === Languages.PRIMARY || presetLang === Languages.SECONDARY);
        if (shouldChangeLang) {
            StorageUtil.setLanguage(presetLang);
        }
    }
}
handlePresetedLanguage();

new SplashScreen().start();
Toast.getInstance().init();
HomePage.getInstance().init();
AboutShopPage.getInstance().init();
ProductPage.getInstance().init();
CartPage.getInstance().init();
OrderPage.getInstance().init();
OrderCompletePage.getInstance().init();
ButtonMaterialEfx.addRippleEffectToMany('apt-category-nav');


const handleTempOrder = () => {
    const APPETIT_TEMP_ORDER = localStorage.getItem('APPETIT_TEMP_ORDER');
    if (APPETIT_TEMP_ORDER) {
        localStorage.removeItem('APPETIT_TEMP_ORDER');
        try {
            if (APPETIT_TEMP_ORDER === 'fail') {
                setTimeout(() => {
                    EventBus.getInstance().triggerEvent(Events.OPEN_ORDER_COMPLETE_SCREEN_REQUEST, false);
                }, 1200);
                return;
            }
            const decoded = JSON.parse(APPETIT_TEMP_ORDER);
            setTimeout(() => {
                EventBus.getInstance().triggerEvent(Events.OPEN_ORDER_COMPLETE_SCREEN_REQUEST, decoded);
            }, 1200)
        } catch (error) {
            console.log(error);
        }
    }
}
handleTempOrder();
