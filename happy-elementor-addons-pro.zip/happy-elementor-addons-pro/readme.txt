=== Happy Addons Pro ===
Plugin Name: Happy Addons Pro
Version: 3.6.1
Author: Leevio
Author URI: https://happyaddons.com/
Contributors: thehappymonster, happyaddons, hasinhayder, mosaddek73, tareq1988, sourav926, wedevs, iqbalrony, mrokon, obiplabon, sayedulsayem
Tags: Elementor Page Builder, Elementor Addons, Widgets, Editor, Web Page Builder
Requires at least: 6.8
Tested up to: 7.0.2
Stable tag: 3.6.1
Requires PHP: 8.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
