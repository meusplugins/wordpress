<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Link_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Url_Prop_Type;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;
use Elementor\Modules\AtomicWidgets\Utils\Image\Placeholder_Image;
use Happy_Addons\Elementor\Classes\Atomic_Field_Control;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;
use Happy_Addons\Elementor\Widget\Atomic\Image_Item_Prop_Type;
use Happy_Addons\Elementor\Widget\Atomic\Image_Items_Prop_Type;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';
require_once __DIR__ . '/prop-types/image-item-prop-types.php';

/**
 * Image Trails for the Atomic containers (e-flexbox, e-div-block, e-grid).
 *
 * Same settings as the Classic Image Trails extension (extensions/happy-image-trails.php).
 * Atomic settings are single valued (not per-breakpoint), the image size, radius
 * and cursor style are plain settings here: the runtime passes them to the CSS
 * as custom properties instead of Elementor selectors. The trail images are the
 * "images" repeater (the same item as the Image Cycle widget).
 */
class Image_Trails extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_it_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	}

	protected function feature_key() {
		return 'image-trails';
	}

	protected function section_label() {
		return __( 'Image Trails', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['classes'], $schema['tag'], $schema['link'] )
			&& ! isset( $schema['title'], $schema['image'], $schema['text'], $schema['paragraph'] );
	}

	protected function fields() {
		$on      = [ 'switcher' => true ];
		$falling = $on + [ 'trail_style' => 'falling' ];
		$cursor  = $on + [ 'cursor' => true ];

		return [
			'switcher'            => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Enable Image Trails', 'happy-addons-pro' ),
			],
			'show_in_editor'      => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Show in Editor', 'happy-addons-pro' ),
				'description' => __( 'Run the trail inside the editor preview. It never runs on mobile devices.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'trail_style'         => [
				'type'    => 'enum',
				'default' => 'normal',
				'label'   => __( 'Trail Style', 'happy-addons-pro' ),
				'options' => [
					'normal'  => __( 'Normal', 'happy-addons-pro' ),
					'falling' => __( 'Falling', 'happy-addons-pro' ),
				],
				'show'    => $on,
			],
			'image_width'         => [
				'type'    => 'slider',
				'default' => 250,
				'min'     => 50,
				'max'     => 800,
				'step'    => 1,
				'label'   => __( 'Image Width (px)', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'image_height'        => [
				'type'        => 'slider',
				'default'     => 0,
				'min'         => 0,
				'max'         => 800,
				'step'        => 1,
				'label'       => __( 'Image Height (px)', 'happy-addons-pro' ),
				'description' => __( '0 keeps the image square.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'image_radius'        => [
				'type'    => 'number',
				'default' => 10,
				'min'     => 0,
				'max'     => 500,
				'step'    => 1,
				'label'   => __( 'Border Radius (px)', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'image_opacity'       => [
				'type'    => 'slider',
				'default' => 1,
				'min'     => 0,
				'max'     => 1,
				'step'    => 0.05,
				'label'   => __( 'Opacity', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'image_z_index'       => [
				'type'    => 'number',
				'default' => 1,
				'min'     => 1,
				'max'     => 9999,
				'step'    => 1,
				'label'   => __( 'Z-index', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'threshold'           => [
				'type'        => 'slider',
				'default'     => 80,
				'min'         => 20,
				'max'         => 300,
				'step'        => 1,
				'label'       => __( 'Trail Distance', 'happy-addons-pro' ),
				'description' => __( 'Minimum mouse distance before showing next image.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'animation_duration'  => [
				'type'    => 'slider',
				'default' => 0.4,
				'min'     => 0.1,
				'max'     => 2,
				'step'    => 0.05,
				'label'   => __( 'Animation Duration (s)', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'rotation_duration'   => [
				'type'        => 'slider',
				'default'     => 0.5,
				'min'         => 0.1,
				'max'         => 3,
				'step'        => 0.05,
				'label'       => __( 'Rotation Duration (s)', 'happy-addons-pro' ),
				'description' => __( 'Controls how fast images rotate in Falling style.', 'happy-addons-pro' ),
				'show'        => $falling,
			],
			'cursor'              => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Enable Magic Cursor', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'cursor_width'        => [
				'type'    => 'slider',
				'default' => 14,
				'min'     => 4,
				'max'     => 80,
				'step'    => 1,
				'label'   => __( 'Cursor Width (px)', 'happy-addons-pro' ),
				'show'    => $cursor,
			],
			'cursor_height'       => [
				'type'    => 'slider',
				'default' => 14,
				'min'     => 4,
				'max'     => 80,
				'step'    => 1,
				'label'   => __( 'Cursor Height (px)', 'happy-addons-pro' ),
				'show'    => $cursor,
			],
			'cursor_color'        => [
				'type'    => 'color',
				'default' => '#FF535B',
				'label'   => __( 'Cursor Color', 'happy-addons-pro' ),
				'show'    => $cursor,
			],
			'cursor_radius'       => [
				'type'    => 'slider',
				'default' => 50,
				'min'     => 0,
				'max'     => 50,
				'step'    => 1,
				'label'   => __( 'Cursor Radius (%)', 'happy-addons-pro' ),
				'show'    => $cursor,
			],
			'cursor_transition'   => [
				'type'    => 'slider',
				'default' => 0.3,
				'min'     => 0,
				'max'     => 2,
				'step'    => 0.05,
				'label'   => __( 'Transition Speed (s)', 'happy-addons-pro' ),
				'show'    => $cursor,
			],
		];
	}

	/**
	 * The trail images are an "ha-image-item" repeater, which the field spec
	 * cannot describe: added next to the fields.
	 */
	public function add_props( $schema ) {
		$schema = parent::add_props( $schema );

		if ( ! is_array( $schema ) || ! isset( $schema[ $this->prefix() . 'switcher' ] ) ) {
			return $schema;
		}

		$images = Image_Items_Prop_Type::make()->default( [] );

		if ( method_exists( $images, 'set_dependencies' ) ) {
			$images->set_dependencies(
				Dependency_Manager::make( Dependency_Manager::RELATION_AND )
					->where( [
						'operator' => 'eq',
						'path'     => [ $this->prefix() . 'switcher' ],
						'value'    => true,
						'effect'   => 'hide',
					] )
					->get()
			);
		}

		$schema[ $this->prefix() . 'images' ] = $images;

		return $schema;
	}

	public function add_controls( $controls, $element ) {
		$controls = parent::add_controls( $controls, $element );

		foreach ( $controls as $section ) {
			if ( ! $section instanceof Section || $this->prefix() . 'section' !== $section->get_id() ) {
				continue;
			}

			$items = $section->get_items();

			// Right below the Enable switch.
			array_splice( $items, 1, 0, [ $this->bulk_images_control(), $this->images_control() ] );
			$section->set_items( $items );
		}

		return $controls;
	}

	/**
	 * "Add Multiple Images" button (media library, multiple selection), rendered by
	 * "ha-it-bulk-images"; it appends one repeater item per picked image.
	 */
	private function bulk_images_control() {
		return Atomic_Field_Control::custom(
			$this->prefix() . 'images',
			'ha-it-bulk-images',
			[
				'label'  => __( 'Add Multiple Images', 'happy-addons-pro' ),
				'title'  => __( 'Select Trail Images', 'happy-addons-pro' ),
				'button' => __( 'Add Images', 'happy-addons-pro' ),
			]
		);
	}

	private function images_control() {
		return Repeatable_Control::bind_to( $this->prefix() . 'images' )
			->set_repeaterLabel( __( 'Trail Images', 'happy-addons-pro' ) )
			->set_patternLabel( '' )
			->set_child_control_type( 'ha-image-item' )
			->set_child_control_props( [
				'sizes'       => Image_Sizes::get_all(),
				'linkOptions' => Link_Control::bind_to( 'link' )->get_props(),
			] )
			->set_initialValues( (object) [
				'image' => Image_Item_Prop_Type::generate( [
					'image' => Image_Prop_Type::generate( [
						'src'  => Image_Src_Prop_Type::generate( [
							'id'  => null,
							'url' => Url_Prop_Type::generate( Placeholder_Image::get_placeholder_image() ),
						] ),
						'size' => String_Prop_Type::generate( 'large' ),
					] ),
				] )['value']['image'],
				'link'  => null,
			] )
			->set_placeholder( __( 'Image', 'happy-addons-pro' ) )
			->set_prop_key( 'ha-image-item-array' )
			->set_is_sortable( true )
			->hide_toggle();
	}

	/**
	 * The editor preview reads the settings from the editor; it needs the
	 * images key to carry them over.
	 */
	public function defaults() {
		return parent::defaults() + [ 'images' => [] ];
	}

	/**
	 * Settings plus the trail image URLs (the runtime gets URLs, not item props).
	 */
	protected function sanitize_config( array $settings ) {
		$config = parent::sanitize_config( $settings );

		$config['images'] = [];

		$items = $settings[ $this->prefix() . 'images' ] ?? [];

		foreach ( is_array( $items ) ? $items : [] as $item ) {
			$src = $item['image']['src'] ?? '';

			if ( is_array( $src ) ) {
				$src = $src['url'] ?? '';
			}

			$url = esc_url_raw( (string) $src );

			if ( '' !== $url ) {
				$config['images'][] = $url;
			}
		}

		$config['images'] = array_slice( $config['images'], 0, 50 );

		return $config;
	}
}
