<?php
namespace Jet_Engine\Query_Builder\File_Query;

use WP_Error;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * XLSX-specific file query parser.
 */
class XLSX_Parser extends Base_Parser {

	/**
	 * Parse XLSX content into normalized rows and properties.
	 *
	 * @param array $source Resolved source payload.
	 * @param array $query  Normalized file query arguments.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	public static function parse( $source, $query, $limits ) {
		$file_path = $source['file_path'];

		if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
			return new WP_Error( 'file_query_xlsx_unreadable', __( 'The XLSX file is not readable.', 'jet-engine' ) );
		}

		if ( ! class_exists( '\\ZipArchive' ) ) {
			return new WP_Error( 'file_query_missing_zip', __( 'XLSX parsing requires the PHP Zip extension.', 'jet-engine' ) );
		}

		if ( ! function_exists( 'simplexml_load_string' ) ) {
			return new WP_Error( 'file_query_missing_xml', __( 'XLSX parsing requires PHP XML support.', 'jet-engine' ) );
		}

		$zip = new \ZipArchive();

		if ( true !== $zip->open( $file_path ) ) {
			return new WP_Error( 'file_query_xlsx_open', __( 'Failed to open the XLSX file.', 'jet-engine' ) );
		}

		$workbook_xml = $zip->getFromName( 'xl/workbook.xml' );
		$rels_xml     = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );

		if ( false === $workbook_xml || false === $rels_xml ) {
			$zip->close();
			return new WP_Error( 'file_query_xlsx_structure', __( 'The XLSX file is missing required workbook metadata.', 'jet-engine' ) );
		}

		$relationships = self::parse_xlsx_relationships( $rels_xml );

		if ( is_wp_error( $relationships ) ) {
			$zip->close();
			return $relationships;
		}

		$sheets = self::parse_xlsx_sheets( $workbook_xml, $relationships );

		if ( is_wp_error( $sheets ) ) {
			$zip->close();
			return $sheets;
		}

		if ( empty( $sheets ) ) {
			$zip->close();
			return new WP_Error( 'file_query_xlsx_no_sheets', __( 'The XLSX file does not contain readable worksheets.', 'jet-engine' ) );
		}

		$sheet = null;

		if ( ! empty( $query['xlsx']['sheet'] ) ) {
			foreach ( $sheets as $sheet_data ) {
				if ( $sheet_data['name'] === $query['xlsx']['sheet'] ) {
					$sheet = $sheet_data;
					break;
				}
			}

			if ( ! $sheet ) {
				$zip->close();
				return new WP_Error( 'file_query_xlsx_sheet', __( 'The selected XLSX sheet was not found.', 'jet-engine' ) );
			}
		} else {
			$sheet = $sheets[0];
		}

		$sheet_xml = $zip->getFromName( $sheet['path'] );

		if ( false === $sheet_xml ) {
			$zip->close();
			return new WP_Error( 'file_query_xlsx_sheet_xml', __( 'The selected XLSX worksheet is unreadable.', 'jet-engine' ) );
		}

		$shared_strings = array();

		if ( false !== $zip->locateName( 'xl/sharedStrings.xml' ) ) {
			$shared_strings_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
			$shared_strings     = self::parse_xlsx_shared_strings( $shared_strings_xml );

			if ( is_wp_error( $shared_strings ) ) {
				$zip->close();
				return $shared_strings;
			}
		}

		$zip->close();

		$rows = self::parse_xlsx_sheet_rows( $sheet_xml, $shared_strings, $limits );

		if ( is_wp_error( $rows ) ) {
			return $rows;
		}

		if ( empty( $rows ) ) {
			return new WP_Error( 'file_query_xlsx_empty', __( 'The selected XLSX worksheet does not contain readable rows.', 'jet-engine' ) );
		}

		return self::normalize_tabular_rows( $rows, array(
			'has_header' => true,
			'header_row' => max( 1, absint( $query['xlsx']['header_row'] ) ),
			'limits'     => $limits,
		) );
	}

	/**
	 * Parse workbook relationships and map relationship IDs to worksheet paths.
	 *
	 * @param string $xml Relationships XML.
	 *
	 * @return array|WP_Error
	 */
	protected static function parse_xlsx_relationships( $xml ) {
		$rels = self::load_xml( $xml, 'xlsx relationships' );

		if ( is_wp_error( $rels ) ) {
			return $rels;
		}

		$result = array();

		$rels->registerXPathNamespace( 'pkg', 'http://schemas.openxmlformats.org/package/2006/relationships' );
		$relations = $rels->xpath( '//pkg:Relationship' );

		if ( false === $relations ) {
			return new WP_Error( 'file_query_xlsx_relationships', __( 'Failed to parse XLSX relationships.', 'jet-engine' ) );
		}

		foreach ( $relations as $relation ) {
			$id     = (string) $relation['Id'];
			$target = self::resolve_xlsx_target_path( (string) $relation['Target'] );

			if ( $id && $target ) {
				$result[ $id ] = $target;
			}
		}

		return $result;
	}

	/**
	 * Parse workbook metadata and collect available worksheets.
	 *
	 * @param string $xml           Workbook XML.
	 * @param array  $relationships Parsed relationship paths.
	 *
	 * @return array|WP_Error
	 */
	protected static function parse_xlsx_sheets( $xml, $relationships ) {
		$workbook = self::load_xml( $xml, 'xlsx workbook' );

		if ( is_wp_error( $workbook ) ) {
			return $workbook;
		}

		$namespaces = $workbook->getDocNamespaces( true );

		if ( ! empty( $namespaces ) ) {
			foreach ( $namespaces as $prefix => $namespace ) {
				$workbook->registerXPathNamespace( $prefix ? $prefix : 'default', $namespace );
			}
		}

		$sheets = $workbook->xpath( '//default:sheets/default:sheet' );

		if ( false === $sheets ) {
			return new WP_Error( 'file_query_xlsx_sheets', __( 'Failed to parse XLSX worksheet list.', 'jet-engine' ) );
		}

		$result = array();

		foreach ( $sheets as $sheet ) {
			$attributes = $sheet->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' );
			$rid        = isset( $attributes['id'] ) ? (string) $attributes['id'] : '';

			if ( ! $rid || empty( $relationships[ $rid ] ) ) {
				continue;
			}

			$result[] = array(
				'name' => (string) $sheet['name'],
				'path' => $relationships[ $rid ],
			);
		}

		return $result;
	}

	/**
	 * Parse the shared strings table from the XLSX archive.
	 *
	 * @param string $xml Shared strings XML.
	 *
	 * @return array|WP_Error
	 */
	protected static function parse_xlsx_shared_strings( $xml ) {
		$strings = self::load_xml( $xml, 'xlsx shared strings' );

		if ( is_wp_error( $strings ) ) {
			return $strings;
		}

		$result = array();

		$strings->registerXPathNamespace( 'main', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
		$items = $strings->xpath( '//main:si' );

		if ( false === $items ) {
			return new WP_Error( 'file_query_xlsx_shared_strings', __( 'Failed to parse XLSX shared strings.', 'jet-engine' ) );
		}

		foreach ( $items as $string ) {
			$result[] = self::extract_xlsx_text_node( $string );
		}

		return $result;
	}

	/**
	 * Parse worksheet rows into tabular cell arrays keyed by row number.
	 *
	 * @param string $xml            Worksheet XML.
	 * @param array  $shared_strings Shared strings lookup.
	 * @param array  $limits         Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	protected static function parse_xlsx_sheet_rows( $xml, $shared_strings, $limits ) {
		$sheet = self::load_xml( $xml, 'xlsx sheet data' );

		if ( is_wp_error( $sheet ) ) {
			return $sheet;
		}

		$result = array();

		$sheet->registerXPathNamespace( 'main', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
		$rows = $sheet->xpath( '//main:sheetData/main:row' );

		if ( false === $rows || empty( $rows ) ) {
			return $result;
		}

		foreach ( $rows as $row ) {
			$row_index  = isset( $row['r'] ) ? absint( $row['r'] ) : 0;
			$cells      = array();
			$next_column = 0;
			$row->registerXPathNamespace( 'main', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main' );
			$cell_nodes = $row->xpath( './main:c' );

			if ( false === $cell_nodes ) {
				continue;
			}

			foreach ( $cell_nodes as $cell ) {
				$reference = isset( $cell['r'] ) ? (string) $cell['r'] : '';
				$column    = self::xlsx_column_to_index( $reference );

				if ( null === $column ) {
					$column = $next_column;
				}

				$value = self::get_xlsx_cell_value( $cell, $shared_strings, $limits['max_cell_length'] );

				$cells[ $column ] = $value;
				$next_column      = $column + 1;
			}

			if ( ! $row_index ) {
				$row_index = count( $result ) + 1;
			}

			ksort( $cells );
			$result[ $row_index ] = $cells;
		}

		ksort( $result );

		return $result;
	}

	/**
	 * Normalize a worksheet cell into the value used by the parser.
	 *
	 * @param \SimpleXMLElement $cell            Cell node.
	 * @param array              $shared_strings Shared strings lookup.
	 * @param int                $max_cell_length Maximum string length.
	 *
	 * @return mixed
	 */
	protected static function get_xlsx_cell_value( $cell, $shared_strings, $max_cell_length ) {
		$type         = isset( $cell['t'] ) ? (string) $cell['t'] : '';
		$raw_value    = self::get_xlsx_child_text( $cell, 'v' );
		$inline_value = self::get_xlsx_child_text( $cell, 'is' );

		if ( 'inlineStr' === $type ) {
			return $inline_value;
		}

		if ( 's' === $type ) {
			$index = absint( $raw_value );
			return isset( $shared_strings[ $index ] ) ? $shared_strings[ $index ] : '';
		}

		if ( 'b' === $type ) {
			return ( '1' === $raw_value );
		}

		if ( '' !== $raw_value ) {
			return self::normalize_scalar_value( $raw_value, $max_cell_length );
		}

		if ( '' !== $inline_value ) {
			return $inline_value;
		}

		return '';
	}

	/**
	 * Safely load XML from a string with internal libxml error handling.
	 *
	 * @param string $xml   XML source.
	 * @param string $label Human-readable XML label.
	 *
	 * @return \SimpleXMLElement|WP_Error
	 */
	protected static function load_xml( $xml, $label ) {
		if ( false === $xml || '' === $xml ) {
			return new WP_Error( 'file_query_xml_empty', sprintf( __( 'Failed to read %s.', 'jet-engine' ), $label ) );
		}

		$previous = libxml_use_internal_errors( true );
		$object   = simplexml_load_string( $xml );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( false === $object ) {
			return new WP_Error( 'file_query_xml_parse', sprintf( __( 'Failed to parse %s.', 'jet-engine' ), $label ) );
		}

		return $object;
	}

	/**
	 * Extract combined text from an XLSX rich text node.
	 *
	 * @param \SimpleXMLElement $node XML node.
	 *
	 * @return string
	 */
	protected static function extract_xlsx_text_node( $node ) {
		$namespace = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
		$text      = '';
		$children  = $node->children( $namespace );

		if ( isset( $children->t ) ) {
			$text .= (string) $children->t;
		}

		if ( isset( $children->r ) ) {
			foreach ( $children->r as $run ) {
				$run_children = $run->children( $namespace );

				if ( isset( $run_children->t ) ) {
					$text .= (string) $run_children->t;
				}
			}
		}

		return $text;
	}

	/**
	 * Read a named child value from an XLSX cell node.
	 *
	 * @param \SimpleXMLElement $node       XML node.
	 * @param string            $child_name Child element name.
	 *
	 * @return string
	 */
	protected static function get_xlsx_child_text( $node, $child_name ) {
		$namespace = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
		$children  = $node->children( $namespace );

		if ( ! isset( $children->$child_name ) ) {
			return '';
		}

		if ( 'is' === $child_name ) {
			return self::extract_xlsx_text_node( $children->$child_name );
		}

		return (string) $children->$child_name;
	}

	/**
	 * Normalize a zip entry path by removing relative segments.
	 *
	 * @param string $path Zip entry path.
	 *
	 * @return string
	 */
	protected static function normalize_zip_path( $path ) {
		$parts = explode( '/', str_replace( '\\', '/', $path ) );
		$out   = array();

		foreach ( $parts as $part ) {
			if ( '' === $part || '.' === $part ) {
				continue;
			}

			if ( '..' === $part ) {
				array_pop( $out );
				continue;
			}

			$out[] = $part;
		}

		return implode( '/', $out );
	}

	/**
	 * Resolve an XLSX relationship target into a zip entry path.
	 *
	 * @param string $target Raw relationship target.
	 *
	 * @return string
	 */
	protected static function resolve_xlsx_target_path( $target ) {
		$target = ltrim( (string) $target, '/' );

		if ( '' === $target ) {
			return '';
		}

		if ( 0 !== strpos( $target, 'xl/' ) ) {
			$target = 'xl/' . $target;
		}

		return self::normalize_zip_path( $target );
	}

	/**
	 * Convert an Excel column reference into a zero-based numeric index.
	 *
	 * @param string $reference Cell reference.
	 *
	 * @return int|null
	 */
	protected static function xlsx_column_to_index( $reference ) {
		if ( ! preg_match( '/^([A-Z]+)/', strtoupper( $reference ), $matches ) ) {
			return null;
		}

		$letters = $matches[1];
		$index   = 0;

		for ( $i = 0; $i < strlen( $letters ); $i++ ) {
			$index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
		}

		return $index - 1;
	}
}
