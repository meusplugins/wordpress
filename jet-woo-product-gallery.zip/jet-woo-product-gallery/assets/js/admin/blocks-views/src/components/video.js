const { __ } = wp.i18n;

const {
	MediaUpload,
	MediaUploadCheck
} = wp.blockEditor;

const {
	Button,
	PanelBody,
	SelectControl,
	ToggleControl
} = wp.components;

export default props => {

	const {
		attributes,
		setAttributes
	} = props;

	return (
		<PanelBody title={ __( 'Video', 'jet-woo-product-gallery' ) } initialOpen={ false }>
			<SelectControl
				label={ __( 'Display Video In', 'jet-woo-product-gallery' ) }
				value={ attributes.video_display_in }
				options={ [
					{
						value: 'content',
						label: __( 'Content', 'jet-woo-product-gallery' )
					},
					{
						value: 'popup',
						label: __( 'Popup', 'jet-woo-product-gallery' )
					}
				] }
				onChange={ ( newValue ) => {
					setAttributes( { video_display_in: newValue } );
				} }
			/>

			<SelectControl
				label={ __( 'Aspect Ratio', 'jet-woo-product-gallery' ) }
				help = { __( 'Worked just with youtube and vimeo video types.', 'jet-woo-product-gallery' ) }
				value={ attributes.aspect_ratio }
				options={ [
					{
						value: '16-9',
						label: '16:9'
					},
					{
						value: '21-9',
						label: '21:9'
					},
					{
						value: '9-16',
						label: '9:16'
					},
					{
						value: '4-3',
						label: '4:3'
					},
					{
						value: '2-3',
						label: '2:3'
					},
					{
						value: '3-2',
						label: '3:2'
					},
					{
						value: '1-1',
						label: '1:1'
					}
				] }
				onChange={ ( newValue ) => {
					setAttributes( { aspect_ratio: newValue } );
				} }
			/>

			{ 'content' === attributes.video_display_in &&
				<ToggleControl
					label={ __( 'Display Video at First Place', 'jet-woo-product-gallery' ) }
					checked={ attributes.first_place_video }
					onChange={ () => {
						setAttributes( { first_place_video: ! attributes.first_place_video } );
					} }
				/>
			}

			{ 'content' === attributes.video_display_in && attributes.first_place_video && [ 'products', 'cpt' ].includes( attributes.gallery_source ) &&
				<SelectControl
					label={ __( 'Video Priority', 'jet-woo-product-gallery' ) }
					value={ attributes.video_priority }
					options={ [
						{
							value: 'before_featured_image',
							label: __( 'Before Featured Image', 'jet-woo-product-gallery' )
						},
						{
							value: 'after_featured_image',
							label: __( 'After Featured Image', 'jet-woo-product-gallery' )
						}
					] }
					onChange={ ( newValue ) => {
						setAttributes( { video_priority: newValue } );
					} }
				/>
			}

			<div className="jet-gallery-heading">Options</div>

			<ToggleControl
				label={ __( 'Autoplay', 'jet-woo-product-gallery' ) }
				checked={ attributes.autoplay }
				onChange={ () => {
					setAttributes( { autoplay: ! attributes.autoplay } );
				} }
			/>

			<ToggleControl
				label={ __( 'Mute', 'jet-woo-product-gallery' ) }
				checked={ attributes.mute }
				onChange={ () => {
					setAttributes( { mute: ! attributes.mute } );
				} }
			/>

			<ToggleControl
				label={ __( 'Loop', 'jet-woo-product-gallery' ) }
				checked={ attributes.loop }
				onChange={ () => {
					setAttributes( { loop: ! attributes.loop } );
				} }
			/>

			{ 'products' !== attributes.gallery_source && attributes.enable_video &&
				<div className="jet-gallery-heading">{ __( 'Player Controls', 'jet-woo-product-gallery' ) }</div>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'youtube' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Native Controls', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_youtube_show_controls }
					onChange={ () => {
						setAttributes( { video_youtube_show_controls: ! attributes.video_youtube_show_controls } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'youtube' === attributes.video_type && attributes.video_youtube_show_controls &&
				<ToggleControl
					label={ __( 'Show Fullscreen Button', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_youtube_show_fullscreen }
					onChange={ () => {
						setAttributes( { video_youtube_show_fullscreen: ! attributes.video_youtube_show_fullscreen } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'vimeo' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Play Controls', 'jet-woo-product-gallery' ) }
					help={ __( 'Note: If disabled, use Autoplay to start Vimeo videos.', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_vimeo_show_controls }
					onChange={ () => {
						setAttributes( { video_vimeo_show_controls: ! attributes.video_vimeo_show_controls } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'vimeo' === attributes.video_type && attributes.video_vimeo_show_controls &&
				<ToggleControl
					label={ __( 'Show Title', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_vimeo_show_title }
					onChange={ () => {
						setAttributes( { video_vimeo_show_title: ! attributes.video_vimeo_show_title } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'vimeo' === attributes.video_type && attributes.video_vimeo_show_controls &&
				<ToggleControl
					label={ __( 'Show Author Name', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_vimeo_show_author_name }
					onChange={ () => {
						setAttributes( { video_vimeo_show_author_name: ! attributes.video_vimeo_show_author_name } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'vimeo' === attributes.video_type && attributes.video_vimeo_show_controls &&
				<ToggleControl
					label={ __( 'Show Author Avatar', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_vimeo_show_author_avatar }
					onChange={ () => {
						setAttributes( { video_vimeo_show_author_avatar: ! attributes.video_vimeo_show_author_avatar } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'vimeo' === attributes.video_type && attributes.video_vimeo_show_controls &&
				<ToggleControl
					label={ __( 'Show Fullscreen Button', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_vimeo_show_fullscreen }
					onChange={ () => {
						setAttributes( { video_vimeo_show_fullscreen: ! attributes.video_vimeo_show_fullscreen } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Play/Pause Button', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_play_pause }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_play_pause: ! attributes.video_self_hosted_show_play_pause } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Current Time', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_current_time }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_current_time: ! attributes.video_self_hosted_show_current_time } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Progress Bar', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_progress_bar }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_progress_bar: ! attributes.video_self_hosted_show_progress_bar } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Duration', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_duration }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_duration: ! attributes.video_self_hosted_show_duration } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Volume Control', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_volume }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_volume: ! attributes.video_self_hosted_show_volume } );
					} }
				/>
			}

			{ 'products' !== attributes.gallery_source && attributes.enable_video && 'self_hosted' === attributes.video_type &&
				<ToggleControl
					label={ __( 'Show Fullscreen Button', 'jet-woo-product-gallery' ) }
					checked={ attributes.video_self_hosted_show_fullscreen }
					onChange={ () => {
						setAttributes( { video_self_hosted_show_fullscreen: ! attributes.video_self_hosted_show_fullscreen } );
					} }
				/>
			}

			{ 'content' === attributes.video_display_in &&
				<div className={ "components-base-control" }>
					<div className="jet-gallery-heading">Play Button</div>

					<ToggleControl
						label={ __( 'Show', 'jet-woo-product-gallery' ) }
						checked={ attributes.show_play_button }
						onChange={ () => {
							setAttributes( { show_play_button: ! attributes.show_play_button } );
						} }
					/>

					{ attributes.show_play_button &&
						<MediaUploadCheck>
							{ 0 !== Object.keys( attributes.play_button_icon ).length &&
								<div className={ "preview-jet-gallery-media preview-jet-gallery-media-icon" }>
									<Button className={ "jet-remove-button" } isPrimary icon="no-alt" onClick={ () => {
										setAttributes( { play_button_icon: {} } );
									} }
									></Button>
									<img src={ attributes.play_button_icon.url } width="100%" height="auto" />
								</div>
							}
							<div className="components-base-control jet-media-control">
								<MediaUpload
									allowedTypes={ [ 'image/svg+xml' ] }
									value={ attributes.play_button_icon.id }
									onSelect={ ( media ) => {
										const iconData = {
											id:  media.id,
											url: media.url
										};

										setAttributes( { play_button_icon: iconData } );
									} }
									render={ ( { open } ) => (
										<Button
											isSecondary
											icon="edit"
											onClick={ open }
										>{ __( 'Select Play Button Icon', 'jet-woo-product-gallery' ) }</Button>
									) }
								/>
							</div>
						</MediaUploadCheck>
					}
				</div>
			}

			{ 'popup' === attributes.video_display_in &&
				<MediaUploadCheck>
					{ 0 !== Object.keys( attributes.popup_button_icon ).length &&
						<div className={ "preview-jet-gallery-media preview-jet-gallery-media-icon" }>
							<Button className={ "jet-remove-button" } isPrimary icon="no-alt" onClick={ () => {
								setAttributes( { popup_button_icon: {} } );
							} }
							></Button>
							<img src={ attributes.popup_button_icon.url } width="100%" height="auto" />
						</div>
					}
					<div className="components-base-control jet-media-control">
						<MediaUpload
							allowedTypes={ [ 'image/svg+xml' ] }
							value={ attributes.popup_button_icon.id }
							onSelect={ ( media ) => {
								const iconData = {
									id:  media.id,
									url: media.url
								};

								setAttributes( { popup_button_icon: iconData } );
							} }
							render={ ( { open } ) => (
								<Button
									isSecondary
									icon="edit"
									onClick={ open }
								>{ __( 'Select Popup Button Icon', 'jet-woo-product-gallery' ) }</Button>
							) }
						/>
					</div>
				</MediaUploadCheck>
			}
		</PanelBody>
	);

};
