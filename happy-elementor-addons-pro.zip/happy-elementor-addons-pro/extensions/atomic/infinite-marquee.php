<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * Infinite Marquee for the Atomic containers (e-flexbox, e-div-block, e-grid).
 *
 * Same settings as the Classic Infinite Marquee extension. Atomic settings are
 * single valued (not per-breakpoint), so the Classic responsive variants
 * collapse into one value each.
 */
class Infinite_Marquee extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_im_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	}

	protected function feature_key() {
		return 'infinite-marquee';
	}

	protected function section_label() {
		return __( 'Marquee', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['classes'], $schema['tag'], $schema['link'] )
			&& ! isset( $schema['title'], $schema['image'], $schema['text'], $schema['paragraph'] );
	}

	protected function fields() {
		$on  = [ 'switcher' => true ];
		$arc = $on + [ 'mode' => 'horizontal', 'elips' => true ];

		return [
			'switcher'             => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable', 'happy-addons-pro' ),
				'description' => __( 'You must set your container to full width for this feature to work.', 'happy-addons-pro' ),
			],
			'disable_in_editor'    => [
				'type'        => 'bool',
				'default'     => true,
				'label'       => __( 'Disable in Editor', 'happy-addons-pro' ),
				'description' => __( 'Turn off the marquee animation inside the editor so you can edit the items in their normal layout. Does not affect the live site.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'pause_hover'          => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Pause on Hover', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'speed'                => [
				'type'    => 'number',
				'default' => 120,
				'min'     => 1,
				'max'     => 10000,
				'step'    => 1,
				'label'   => __( 'Speed(ms)', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'mode'                 => [
				'type'    => 'enum',
				'default' => 'horizontal',
				'label'   => __( 'Mode', 'happy-addons-pro' ),
				'options' => [
					'horizontal' => __( 'Horizontal', 'happy-addons-pro' ),
					'vertical'   => __( 'Vertical', 'happy-addons-pro' ),
				],
				'icons'   => [
					'horizontal' => 'ArrowsMoveHorizontalIcon',
					'vertical'   => 'ArrowsMoveVerticalIcon',
				],
				'show'    => $on,
			],
			'horizontal_direction' => [
				'type'    => 'enum',
				'default' => 'left',
				'label'   => __( 'Direction', 'happy-addons-pro' ),
				'options' => [
					'left'  => __( 'Left', 'happy-addons-pro' ),
					'right' => __( 'Right', 'happy-addons-pro' ),
				],
				'icons'   => [
					'left'  => 'ArrowLeftIcon',
					'right' => 'ArrowRightIcon',
				],
				'show'    => $on + [ 'mode' => 'horizontal' ],
			],
			'vertical_direction'   => [
				'type'    => 'enum',
				'default' => 'top',
				'label'   => __( 'Direction', 'happy-addons-pro' ),
				'options' => [
					'top'    => __( 'Top', 'happy-addons-pro' ),
					'bottom' => __( 'Bottom', 'happy-addons-pro' ),
				],
				'icons'   => [
					'top'    => 'ArrowUpIcon',
					'bottom' => 'ArrowDownIcon',
				],
				'show'    => $on + [ 'mode' => 'vertical' ],
			],
			'gap_between_iem'      => [
				'type'    => 'number',
				'default' => 5,
				'min'     => 0,
				'max'     => 1000,
				'step'    => 1,
				'label'   => __( 'Items Gap', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'elips'                => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Ellipse (Arc) Effect', 'happy-addons-pro' ),
				'description' => __( 'Display marquee items along a smooth curved arc instead of a straight line.', 'happy-addons-pro' ),
				'show'        => $on + [ 'mode' => 'horizontal' ],
			],
			'elips_curve'          => [
				'type'    => 'slider',
				'default' => 130,
				'min'     => 0,
				'max'     => 360,
				'step'    => 1,
				'label'   => __( 'Curve Depth', 'happy-addons-pro' ),
				'show'    => $arc,
			],
			'scroll_effect'        => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Scroll Effect', 'happy-addons-pro' ),
				'description' => __( 'Temporarily increase the marquee speed while the page is scrolling.', 'happy-addons-pro' ),
				'show'        => $arc,
			],
			'elips_rotate'         => [
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Rotate Effect', 'happy-addons-pro' ),
				'show'    => $arc,
			],
			'elips_zoom'           => [
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Zoom Effect', 'happy-addons-pro' ),
				'show'    => $arc,
			],
			'elips_fade'           => [
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Fade Effect', 'happy-addons-pro' ),
				'show'    => $arc,
			],
			'elips_blur'           => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Blur Effect', 'happy-addons-pro' ),
				'show'    => $arc,
			],
			'enable_on_mobile'     => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable On Mobile', 'happy-addons-pro' ),
				'description' => __( 'When disabled, the marquee animation will not run on mobile devices.', 'happy-addons-pro' ),
				'show'        => $on,
			],
		];
	}
}
