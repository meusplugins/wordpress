<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/Currency.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/TimezoneUtils.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\Currency;
use com\sakuraplugins\appetit\utils\TimezoneUtils;
use com\sakuraplugins\appetit\utils\TimeUtils;
use com\sakuraplugins\appetit\Config;

class GeneralSettings {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Restaurant management', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->renderManagement() ?></div>
        </div>

        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Restaurant business hours', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?= $this->renderBussinessHours(); ?></div>
        </div>

        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Restaurant location', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?= $this->renderLocation(); ?></div>
        </div>
        <?php
    }

    private function renderManagement() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Restaurant name', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_name', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_name]"
                            class="form-control">
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Restaurant about', 'instafood'); ?></label>
                        <textarea class="w-100" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_about]"><?= esc_textarea(OptionUtil::getInstance()->getOption('restaurant_about', '')) ?></textarea>
                        <div class="option-entry-info"><?= esc_html__('Short description', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Restaurant address', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_address', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_address]"
                            class="form-control">
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Restaurant phone', 'instafood'); ?></label>
                        <input type="tel"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_phone', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_phone]"
                            class="form-control">
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('VAT percentage', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('vat_percentage', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[vat_percentage]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('Used when printing the bill.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Currency', 'instafood'); ?></label>
                        <?php
                        $restaurant_currency_code = OptionUtil::getInstance()->getOption('restaurant_currency_code', '');
                        ?>
                        <select name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_currency_code]" class="form-select apt-display-block wd_100 select_currency" style="width: 100%;">
                            <option value=""><?= esc_html__('Select currency ...', 'instafood'); ?></option>
                            <?php foreach (Currency::getCurrencies() as $currency): ?>
                                <option <?= $restaurant_currency_code === $currency['code'] ? 'selected' : ''; ?> value="<?= esc_attr($currency['code']); ?>"><?= esc_html($currency['name']) ?> (<?= esc_html($currency['symbol']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <div class="option-entry-info"><?= esc_html__('Currency is being displayed in the frontend and also could be used with payment gateways.', 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_20 mt_10">
                        <?php
                        $currency_position = OptionUtil::getInstance()->getOption('currency_position', 'BEFORE');
                        ?>
                        <label class="option-entry-label"><?= esc_html__('Currency position', 'instafood'); ?></label>
                        <div class="form-check">
                            <input type="radio" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[currency_position]" 
                            value="BEFORE"
                            id="currency_position_1" <?= $currency_position === 'BEFORE' ? 'checked="checked"' : '' ?>>
                            <label class="form-check-label" for="currency_position_1" style="font-size: 15px;">
                            <?= esc_html__('Currency symbol displays before the price', 'instafood'); ?>
                            </label>
                        </div>
                        <div class="form-check">
                            <input type="radio" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[currency_position]" 
                            value="AFTER"
                            id="currency_position_2" <?= $currency_position === 'AFTER' ? 'checked="checked"' : '' ?>>
                            <label class="form-check-label" for="currency_position_2" style="font-size: 15px;">
                            <?= esc_html__('Currency symbol displays after the price', 'instafood'); ?>
                            </label>
                        </div>
                    </div>
                    <div class="apt-option-entry mb_10 mt_30">
                        <label class="option-entry-label"><?= esc_html__('Price decimal display', 'instafood'); ?></label>
                        <?php
                        $frontend_enabled_decimal_dot = OptionUtil::getInstance()->getOption("frontend_enabled_decimal_dot", '');
                        ?>
                        <div class="custom-control custom-switch" style="margin-top: 0px;">
                            <input type="checkbox" class="custom-control-input day_abailable_cb"  
                            id="frontend_enabled_decimal_dot_id"
                            value="ON"
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[frontend_enabled_decimal_dot]" 
                            <?= $frontend_enabled_decimal_dot === 'ON' ? "checked" : "" ?>
                            >
                            <label class="custom-control-label" for="frontend_enabled_decimal_dot_id"><?= esc_html__('Enable display decimal prices with dot', 'instafood'); ?></label>
                            <div class="option-entry-info"><?= esc_html__("Use dot instead of comma. Ex ($22.00 instead of $22,00)", 'instafood'); ?></div>
                        </div>

                    </div>
                    <div class="apt-option-entry mb_10 mt_30">
                        <?php
                        $restaurant_timezone = OptionUtil::getInstance()->getOption('restaurant_timezone', 'Europe/Amsterdam');
                        $timezoneUtils = new TimezoneUtils();
                        ?>
                        <label class="option-entry-label"><?= esc_html__('Restaurant time zone', 'instafood'); ?></label>
                        <select name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_timezone]" class="form-select apt-display-block wd_100 select_timezone" style="width: 100%;">
                            <option value=""><?= esc_html__('Select timezone ...', 'instafood'); ?></option>
                            <?php foreach ($timezoneUtils->getTimezones() as $key => $value): ?>
                                <option value="<?= esc_attr($value) ?>" <?= $restaurant_timezone === $value ? 'selected' : '' ?>><?= esc_html($key) ?> (<?= esc_html($value) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <div class="option-entry-info"><?= esc_html__('Timezone will be used to determine if the restaurant is open, will also be used for different pickup options.', 'instafood'); ?></div>
                    </div>

                    <div class="apt-option-entry mb_10 mt_30">
                        <?php
                        $secondary_lang_enabled = OptionUtil::getInstance()->getOption("secondary_lang_enabled", '');
                        ?>
                        <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                            <input type="checkbox" class="custom-control-input day_abailable_cb"  
                            id="secondary_lang_enabled_id"
                            value="ON"
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[secondary_lang_enabled]" 
                            <?= $secondary_lang_enabled === 'ON' ? "checked" : "" ?>
                            >
                            <label class="custom-control-label" for="secondary_lang_enabled_id"><?= esc_html__('Enable secondary language', 'instafood'); ?></label>
                        </div>

                        <div class="apt-option-entry mb_10">
                            <label class="option-entry-label"><?= esc_html__('Primary language country code', 'instafood'); ?></label>
                            <input type="text"
                                value="<?= esc_attr(OptionUtil::getInstance()->getOption('primary_lang_ccode', 'EN')); ?>" 
                                name="<?= esc_attr(Config::getOptionsGroupSlug());?>[primary_lang_ccode]"
                                class="form-control">
                            <div class="option-entry-info"><?= esc_html__("Ex: EN", 'instafood'); ?></div>
                        </div>
                        <div class="apt-option-entry mb_10">
                            <label class="option-entry-label"><?= esc_html__('Secondary language country code', 'instafood'); ?></label>
                            <input type="text"
                                value="<?= esc_attr(OptionUtil::getInstance()->getOption('secondary_lang_ccode', '')); ?>" 
                                name="<?= esc_attr(Config::getOptionsGroupSlug());?>[secondary_lang_ccode]"
                                class="form-control">
                            <div class="option-entry-info"><?= esc_html__("Ex: FR", 'instafood'); ?></div>
                        </div>

                        
                    </div>


                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
                <div class="col-md-6">
                    <!-- cover image -->
                    <p><strong><?= esc_html__('Restaurant cover image', 'instafood') ?></strong></p>
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Upload a high quality photo to showcase your restaurant. Recommended dimension 1000px x 500px.", 'instafood') ?>
                    </div>
                    <?php
                        $restaurant_cover_image_id = OptionUtil::getInstance()->getOption('restaurant_cover_image_id');
                        $restaurant_cover_image_url = '';
                        if ($restaurant_cover_image_id) {
                            $restaurant_cover_image_data = wp_get_attachment_image_src($restaurant_cover_image_id, 'medium');
                            if (is_array($restaurant_cover_image_data) && isset($restaurant_cover_image_data[0])) {
                                $restaurant_cover_image_url = $restaurant_cover_image_data[0];
                            }
                        }
                    ?>
                    <div class="upload_img_ui">
                        <div class="item-image-uploaded mb-3">
                            <?php if ($restaurant_cover_image_url !== ''): ?>
                                <img src="<?= esc_attr($restaurant_cover_image_url) ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <input class="photo_id" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_cover_image_id]" value="<?= $restaurant_cover_image_id ?>" type="hidden">
                        <div class="d-flex flex-row">
                            <button type="button" class="btn btn-secondary upload_btn mr-4"><?= esc_html__('Upload image', 'instafood') ?></button>
                            <a href="#" class="remove_btn <?= $restaurant_cover_image_url === '' ? 'd-none' : '' ?>"><?= esc_html__('Remove image', 'instafood') ?></a>
                        </div>
                    </div>
                    <!-- end cover image -->
                    <!-- logo image -->
                    
                    <p class="mt-4"><strong><?= esc_html__('Restaurant logo image', 'instafood') ?></strong></p>
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Upload a high quality photo to showcase your restaurant. Minimum recommended dimension 500px on height.", 'instafood') ?>
                    </div>
                    <?php
                        $restaurant_logo_image_id = OptionUtil::getInstance()->getOption('restaurant_logo_image_id');
                        $restaurant_logo_image_url = '';
                        if ($restaurant_logo_image_id) {
                            $restaurant_logo_image_data = wp_get_attachment_image_src($restaurant_logo_image_id, 'medium');
                            if (is_array($restaurant_logo_image_data) && isset($restaurant_logo_image_data[0])) {
                                $restaurant_logo_image_url = $restaurant_logo_image_data[0];
                            }
                        }
                    ?>
                    <div class="upload_img_ui">
                        <div class="item-image-uploaded mb-3">
                            <?php if ($restaurant_logo_image_url !== ''): ?>
                                <img src="<?= esc_attr($restaurant_logo_image_url) ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <input class="photo_id" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_logo_image_id]" value="<?= $restaurant_logo_image_id ?>" type="hidden">
                        <div class="d-flex flex-row">
                            <button type="button" class="btn btn-secondary upload_btn mr-4"><?= esc_html__('Upload image', 'instafood') ?></button>
                            <a href="#" class="remove_btn <?= $restaurant_logo_image_url === '' ? 'd-none' : '' ?>"><?= esc_html__('Remove image', 'instafood') ?></a>
                        </div>
                    </div>
                    <!-- end logo image -->

                    <div class="apt_hr mt_20 mb_20"></div>

                    <div class="apt-option-entry mb_10 mt_20">
                        <label class="option-entry-label"><?= esc_html__('Mobile app site title', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('apt_site_title', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_site_title]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Add title", 'instafood'); ?></div>
                    </div>

                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Mobile app site description', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('apt_site_description', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_site_description]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Add description", 'instafood'); ?></div>
                    </div>

                    <div class="apt_hr mt_20 mb_20"></div>

                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Terms & conditions link', 'instafood'); ?></label>
                        <input type="text"
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('terms_link', '#')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[terms_link]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Add Terms & conditions url", 'instafood'); ?></div>
                    </div>

                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('Product description length', 'instafood'); ?></label>
                        <input type="number" min="1" max="1000" 
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('homepage_product_description_length', '')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[homepage_product_description_length]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__('HomePage max characters for product description (Leave empty if there is no restriction).', 'instafood'); ?></div>
                    </div>


                    <div class="apt-option-entry mb_10">
                        <?php
                        $enable_call_restaurant_homepage = OptionUtil::getInstance()->getOption("enable_call_restaurant_homepage", '');
                        ?>
                        <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                            <input type="checkbox" class="custom-control-input day_abailable_cb"  
                            id="enable_call_restaurant_homepage_id"
                            value="ON"
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[enable_call_restaurant_homepage]" 
                            <?= $enable_call_restaurant_homepage === 'ON' ? "checked" : "" ?>
                            >
                            <label class="custom-control-label" for="enable_call_restaurant_homepage_id"><?= esc_html__('Enable homepage call restaurant', 'instafood'); ?></label>
                        </div>
                    </div>


                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderBussinessHours() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Select business hours for weekdays, will be used to determine if the restaurant is open. Multiple intervals per day are possible (Ex: Saturday: 10:00am - 01:00pm && 04:00pm - 08:00pm).", 'instafood') ?>
                    </div>
                    <div class="bussiness-hours">
                        <?php
                            
                        $days = TimeUtils::getInstance()->getDays();

                        foreach ($days as $day) {
                            $jsonData = OptionUtil::getInstance()->getOption('business_hours_raw_data_' . $day['key'], '');
                            $decoded_day_intervals_data = [];
                            try {
                                $decoded_day_intervals_data = json_decode($jsonData);
                            } catch (Exception $e) {};
                            ?>
                            <div class="day-entry">
                                <textarea style="display: none;" class="day_raw_data" name="<?= esc_attr(Config::getOptionsGroupSlug());?>[business_hours_raw_data_<?= $day['key'] ?>]"><?= esc_html__($jsonData) ?></textarea>
                            <?php
                                $this->e_bussinessHDayHelper($day['key'], $day['label']);
                            ?>
                                <div class="day-content">
                                    <div class="day-intervals">
                                        <?php if (is_array($decoded_day_intervals_data) && sizeof($decoded_day_intervals_data) > 0): ?>
                                            <?php foreach ($decoded_day_intervals_data as $dayInterval): ?>

                                                <div class="day-interval">
                                                    <div class="interval-start-stop interval-start mr_10">
                                                        <div class="info"><?= esc_html__('Shift start', 'instafood') ?></div>
                                                        <div class="interval-controls">
                                                            <div class="handle-counter apt-display-flex">                                             
                                                                <input min="1" max="12" class="counter_input hours" type="number" value="<?= $dayInterval->interval_start_hh ?>">
                                                                <div class="ml_5 mr_5">:</div>
                                                                <input min="0" max="59" class="counter_input minutes" type="number" value="<?= $dayInterval->interval_start_mm ?>">
                                                            </div>
                                                            <select class="am_pm_select ml_5" name="">
                                                                <option value="AM" <?= $dayInterval->am_pm_select_start === 'AM' ? 'selected' : '' ?>><?= esc_html__('AM', 'instafood') ?></option>
                                                                <option value="PM" <?= $dayInterval->am_pm_select_start === 'PM' ? 'selected' : '' ?>><?= esc_html__('PM', 'instafood') ?></option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div>-</div>
                                                    <div class="interval-start-stop interval-stop mr_10">
                                                        <div class="info"><?= esc_html__('Shift stop', 'instafood') ?></div>
                                                        <div class="interval-controls">
                                                            <div class="handle-counter apt-display-flex">                                             
                                                                <input min="1" max="12" class="counter_input hours" type="number" value="<?= $dayInterval->interval_stop_hh ?>">
                                                                <div class="ml_5 mr_5">:</div>
                                                                <input min="0" max="59" class="counter_input minutes" type="number" value="<?= $dayInterval->interval_stop_mm ?>">
                                                            </div>
                                                            <select class="am_pm_select ml_5" name="">
                                                                <option value="AM" <?= $dayInterval->am_pm_select_stop === 'AM' ? 'selected' : '' ?>><?= esc_html__('AM', 'instafood') ?></option>
                                                                <option value="PM" <?= $dayInterval->am_pm_select_stop === 'PM' ? 'selected' : '' ?>><?= esc_html__('PM', 'instafood') ?></option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <a class="remove_interval_btn" href="#"><span class="icon-trash-2"></span></a>
                                                </div>

                                            <?php endforeach; ?>
                                        <?php endif; ?>                                        
                                        <div class="div"><button type="button" class="btn btn-secondary btn-sm day-add-interval mt_5 mb_5"><?= esc_html__('Add new interval', 'instafood') ?></button></div>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                        ?>
                    </div>
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function e_bussinessHDayHelper($dayKey, $dayLabel) {
        $day = OptionUtil::getInstance()->getOption("business_hours_$dayKey", '');
        ?>
            <div class="day <?= "day_$dayKey"; ?>">
                <?php
                ?>
                <div class="custom-control custom-switch" style="margin-bottom: 20px;">
                    <input type="checkbox" class="custom-control-input day_abailable_cb"  
                    id="_day_id_<?= $dayKey ?>"
                    value="<?= esc_attr($dayKey); ?>"
                    name="<?= esc_attr(Config::getOptionsGroupSlug());?>[business_hours_<?= $dayKey ?>]" 
                    <?= $day === $dayKey ? "checked" : "" ?>
                    >
                    <label class="custom-control-label" for="_day_id_<?= $dayKey ?>"><?= $dayLabel ?></label>
                </div>
            </div>
        <?php
    }

    
    private function renderLocation() {
        $gMapKey = OptionUtil::getInstance()->getOption('gmap_api_key', '');
        ?>
        <div class="container-fluid">
            <div class="row">
                <?php if ($gMapKey === ''): ?>
                    <div class="col-md-12 mb-3">
                        <div class="alert alert-warning" role="alert" style="font-size: 14px;">
                            <?= esc_html__('Google Maps API Key has not been set up yet. You can set up Google Maps API Key from "Credentials".', 'instafood') ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-md-12 mb-3">
                        <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                            <?= esc_html__('If delivery is activated, Google Maps API will be used to determine the max delivery distance.', 'instafood') ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php if ($gMapKey !== ''): ?>
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <input id="restaurant_address_input" type="text"
                            value="" 
                            name=""
                            placeholder="<?= esc_html__('Restaurant address', 'instafood'); ?>"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Enter the restaurant's address.", 'instafood'); ?></div>
                    </div>
                    <button id="geocode_btn" type="button" class="btn btn-secondary" disabled><?= esc_html__("Geocode", 'instafood'); ?></button>

                    <div class="apt-option-entry mb_10 mt_20">
                        <input id="restaurant_lat" type="text" 
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_lat', '51.5073509')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_lat]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Latitude", 'instafood'); ?></div>
                    </div>
                    <div class="apt-option-entry mb_10">
                        <input id="restaurant_lng" type="text" 
                            value="<?= esc_attr(OptionUtil::getInstance()->getOption('restaurant_lng', '-0.1277583')); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[restaurant_lng]"
                            class="form-control">
                        <div class="option-entry-info"><?= esc_html__("Longitude", 'instafood'); ?></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("To determine geo-coordinates, enter the restaurant's address and click Geolocate. You can also drag the marker on the map.", 'instafood') ?>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div id="apt-gmap" class="apt-gmap"></div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
?>