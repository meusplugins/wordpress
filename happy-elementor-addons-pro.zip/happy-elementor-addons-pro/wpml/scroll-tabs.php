<?php
/**
 * Scroll Tabs integration
 */
namespace Happy_Addons_Pro\Wpml;

defined( 'ABSPATH' ) || die();

class Scroll_Tabs extends \WPML_Elementor_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'scroll_tabs_list';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'nav_text',
			'editor',
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'nav_text':
				return __( 'Scroll Tabs: Nav Text', 'happy-addons-pro' );
			case 'editor':
				return __( 'Scroll Tabs: Content', 'happy-addons-pro' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'nav_text':
				return 'LINE';
			case 'editor':
				return 'VISUAL';
			default:
				return '';
		}
	}
}
