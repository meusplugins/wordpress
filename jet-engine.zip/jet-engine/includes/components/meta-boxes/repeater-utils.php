<?php
/**
 * Shared nested repeater helpers.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Repeater_Utils' ) ) {

	class Jet_Engine_Repeater_Utils {

		const DEFAULT_MAX_PATH_LENGTH   = 200;
		const DEFAULT_MAX_SEGMENT_COUNT = 20;

		protected static $reserved_segments = array(
			'__proto__',
			'prototype',
			'constructor',
		);

		public static function get_child_fields( $field ) {

			if ( ! empty( $field['fields'] ) && is_array( $field['fields'] ) ) {
				return $field['fields'];
			}

			if ( empty( $field['repeater-fields'] ) || ! is_array( $field['repeater-fields'] ) ) {
				return array();
			}

			$result = array();

			foreach ( $field['repeater-fields'] as $child ) {
				if ( ! empty( $child['name'] ) ) {
					$result[ $child['name'] ] = $child;
				}
			}

			return $result;
		}

		public static function get_field_label( $field ) {

			if ( ! empty( $field['title'] ) ) {
				return $field['title'];
			}

			if ( ! empty( $field['label'] ) ) {
				return $field['label'];
			}

			return ! empty( $field['name'] ) ? $field['name'] : '';
		}

		public static function get_field_options( $field ) {

			$result       = array();
			$child_fields = self::get_child_fields( $field );

			foreach ( $child_fields as $child_key => $child_field ) {
				$result[ $child_key ] = self::get_field_label( $child_field );
			}

			return $result;
		}

		public static function get_path_string( $segments ) {

			if ( ! is_array( $segments ) ) {
				return '';
			}

			$segments = array_values( array_filter( array_map( function( $segment ) {
				return is_scalar( $segment ) ? trim( (string) $segment ) : '';
			}, $segments ) ) );

			return implode( '.', $segments );
		}

		public static function normalize_path( $path, $return = 'segments' ) {

			if ( is_array( $path ) ) {
				$path = self::get_path_string( $path );
			} else {
				$path = is_scalar( $path ) ? trim( (string) $path ) : '';
			}

			if ( '' === $path ) {
				return ( 'string' === $return ) ? '' : array();
			}

			if ( false !== strpos( $path, '[' ) || false !== strpos( $path, ']' ) ) {
				return new \WP_Error( 'invalid_repeater_path', __( 'Bracket syntax is not supported in nested repeater paths.', 'jet-engine' ) );
			}

			$path = preg_replace( '/\s*\.\s*/', '.', $path );

			if ( '' === $path ) {
				return ( 'string' === $return ) ? '' : array();
			}

			if ( '.' === $path[0] || '.' === substr( $path, -1 ) || false !== strpos( $path, '..' ) ) {
				return new \WP_Error( 'invalid_repeater_path', __( 'Nested repeater path must use dot notation without empty segments.', 'jet-engine' ) );
			}

			if ( ! preg_match( '/^[A-Za-z0-9_:\.\-]+$/', $path ) ) {
				return new \WP_Error( 'invalid_repeater_path', __( 'Nested repeater path contains unsupported characters.', 'jet-engine' ) );
			}

			if ( strlen( $path ) > self::get_max_path_length() ) {
				return new \WP_Error( 'invalid_repeater_path', __( 'Nested repeater path is too long.', 'jet-engine' ) );
			}

			$segments = explode( '.', $path );

			if ( count( $segments ) > self::get_max_segment_count() ) {
				return new \WP_Error( 'invalid_repeater_path', __( 'Nested repeater path contains too many segments.', 'jet-engine' ) );
			}

			foreach ( $segments as $segment ) {
				if ( ! self::is_valid_path_segment( $segment ) ) {
					return new \WP_Error( 'invalid_repeater_path', sprintf( __( 'Nested repeater path contains an invalid segment: %s', 'jet-engine' ), $segment ) );
				}

				if ( self::is_reserved_path_segment( $segment ) ) {
					return new \WP_Error( 'invalid_repeater_path', sprintf( __( 'Nested repeater path contains a reserved segment: %s', 'jet-engine' ), $segment ) );
				}
			}

			if ( 'string' === $return ) {
				return implode( '.', $segments );
			}

			return $segments;
		}

		public static function path_exists( $value, $segments ) {

			$segments = self::normalize_path( $segments );

			if ( is_wp_error( $segments ) || empty( $segments ) ) {
				return false;
			}

			return self::path_exists_in_value( $value, $segments );
		}

		public static function resolve_path( $value, $segments ) {

			$segments = self::normalize_path( $segments );

			if ( is_wp_error( $segments ) ) {
				return array();
			}

			if ( empty( $segments ) ) {
				return is_array( $value ) ? $value : array();
			}

			return self::resolve_path_in_value( $value, $segments );
		}

		public static function get_repeater_field_for_path( $field, $path ) {

			if ( empty( $field['type'] ) || 'repeater' !== $field['type'] ) {
				return array();
			}

			$segments = self::normalize_path( $path );

			if ( is_wp_error( $segments ) ) {
				return array();
			}

			if ( ! empty( $segments ) && ! empty( $field['name'] ) && $segments[0] === $field['name'] ) {
				array_shift( $segments );
			}

			if ( empty( $segments ) ) {
				return $field;
			}

			$current = $field;

			foreach ( $segments as $segment ) {
				$child_fields = self::get_child_fields( $current );

				if ( empty( $child_fields[ $segment ] ) ) {
					return array();
				}

				$current = $child_fields[ $segment ];

				if ( empty( $current['type'] ) || 'repeater' !== $current['type'] ) {
					return array();
				}
			}

			return $current;
		}

		public static function get_nested_repeater_path_options( $field, $include_root = false ) {

			$result = array();

			if ( empty( $field['type'] ) || 'repeater' !== $field['type'] || empty( $field['name'] ) ) {
				return $result;
			}

			if ( $include_root ) {
				$result[] = array(
					'value' => $field['name'],
					'label' => self::get_field_label( $field ),
				);
			}

			self::collect_nested_repeater_paths( $field, array( $field['name'] ), array( self::get_field_label( $field ) ), $result );

			return $result;
		}

		public static function walk_repeater_value( $value, $field, $leaf_callback, $args = array() ) {

			$args = wp_parse_args( $args, array(
				'preserve_unknown' => false,
				'unknown_filter'   => 'jet-engine/repeater/allow-unknown-submitted-key',
				'path'             => array(),
			) );

			if ( empty( $field['type'] ) || 'repeater' !== $field['type'] ) {
				return is_callable( $leaf_callback ) ? call_user_func( $leaf_callback, $value, $field, $args['path'] ) : $value;
			}

			if ( ! is_array( $value ) ) {
				return array();
			}

			$child_fields = self::get_child_fields( $field );

			if ( empty( $child_fields ) ) {
				return array();
			}

			$result = array();

			foreach ( $value as $item_id => $item ) {

				if ( ! is_array( $item ) ) {
					continue;
				}

				$result[ $item_id ] = array();

				foreach ( $item as $child_key => $child_value ) {

					if ( ! isset( $child_fields[ $child_key ] ) ) {

						$allow_unknown = apply_filters(
							$args['unknown_filter'],
							$args['preserve_unknown'],
							$child_key,
							$child_value,
							$field,
							$args['path']
						);

						if ( $allow_unknown ) {
							$result[ $item_id ][ $child_key ] = $child_value;
						}

						continue;
					}

					$child_field = $child_fields[ $child_key ];
					$child_path  = array_merge( $args['path'], array( $child_key ) );

					if ( ! empty( $child_field['type'] ) && 'repeater' === $child_field['type'] ) {
						$result[ $item_id ][ $child_key ] = self::walk_repeater_value(
							$child_value,
							$child_field,
							$leaf_callback,
							array_merge( $args, array( 'path' => $child_path ) )
						);
					} else {
						$result[ $item_id ][ $child_key ] = is_callable( $leaf_callback )
							? call_user_func( $leaf_callback, $child_value, $child_field, $child_path )
							: $child_value;
					}
				}
			}

			return $result;
		}

		public static function collect_scalar_leaf_values( $value, $field, $top_key ) {

			$values = array();

			if ( empty( $field['type'] ) || 'repeater' !== $field['type'] || ! is_array( $value ) ) {
				return $values;
			}

			self::collect_leaf_values_for_rows( $value, $field, array( $top_key ), $values );

			return $values;
		}

		public static function collect_scalar_leaf_values_from_schema( $field, $top_key ) {

			$leaves = array();

			if ( empty( $field['type'] ) || 'repeater' !== $field['type'] ) {
				return $leaves;
			}

			self::collect_leaf_schema( $field, array( $top_key ), $leaves );

			return $leaves;
		}

		private static function collect_leaf_schema( $field, $path, &$leaves ) {

			$child_fields = self::get_child_fields( $field );

			foreach ( $child_fields as $child_key => $child_field ) {

				$child_path = array_merge( $path, array( $child_key ) );

				if ( ! empty( $child_field['type'] ) && 'repeater' === $child_field['type'] ) {
					self::collect_leaf_schema( $child_field, $child_path, $leaves );
					continue;
				}

				$leaves[] = array(
					'path'  => $child_path,
					'field' => $child_field,
				);
			}
		}

		private static function collect_leaf_values_for_rows( $rows, $field, $path, &$values ) {

			$child_fields = self::get_child_fields( $field );

			if ( empty( $child_fields ) || ! is_array( $rows ) ) {
				return;
			}

			foreach ( $rows as $row ) {

				if ( ! is_array( $row ) ) {
					continue;
				}

				foreach ( $child_fields as $child_key => $child_field ) {

					if ( ! array_key_exists( $child_key, $row ) ) {
						continue;
					}

					$child_path = array_merge( $path, array( $child_key ) );
					$child_val  = $row[ $child_key ];

					if ( ! empty( $child_field['type'] ) && 'repeater' === $child_field['type'] ) {
						self::collect_leaf_values_for_rows( $child_val, $child_field, $child_path, $values );
						continue;
					}

					$key = implode( '.', $child_path );

					if ( ! isset( $values[ $key ] ) ) {
						$values[ $key ] = array(
							'path'  => $child_path,
							'field' => $child_field,
							'value' => array(),
						);
					}

					$values[ $key ]['value'][] = $child_val;
				}
			}
		}

		private static function collect_nested_repeater_paths( $field, $path, $labels, &$result ) {

			$child_fields = self::get_child_fields( $field );

			foreach ( $child_fields as $child_key => $child_field ) {

				if ( empty( $child_field['type'] ) || 'repeater' !== $child_field['type'] ) {
					continue;
				}

				$child_path   = array_merge( $path, array( $child_key ) );
				$child_labels = array_merge( $labels, array( self::get_field_label( $child_field ) ) );

				$result[] = array(
					'value' => self::get_path_string( $child_path ),
					'label' => implode( ' > ', $child_labels ),
				);

				self::collect_nested_repeater_paths( $child_field, $child_path, $child_labels, $result );
			}
		}

		private static function is_assoc_array( $array ) {

			if ( ! is_array( $array ) ) {
				return false;
			}

			if ( function_exists( 'array_is_list' ) ) {
				return ! array_is_list( $array );
			}

			return array_keys( $array ) !== range( 0, count( $array ) - 1 );
		}

		private static function resolve_path_in_value( $value, $segments ) {

			if ( empty( $segments ) ) {
				return is_array( $value ) ? $value : array();
			}

			if ( is_object( $value ) ) {
				$value = get_object_vars( $value );
			}

			if ( is_array( $value ) && self::is_assoc_array( $value ) ) {

				$segment = array_shift( $segments );

				if ( ! array_key_exists( $segment, $value ) ) {
					return array();
				}

				return self::resolve_path_in_value( $value[ $segment ], $segments );
			}

			if ( ! is_array( $value ) ) {
				return array();
			}

			$segment = array_shift( $segments );
			$result  = array();

			foreach ( $value as $row ) {

				if ( is_object( $row ) ) {
					$row = get_object_vars( $row );
				}

				if ( ! is_array( $row ) || ! array_key_exists( $segment, $row ) ) {
					continue;
				}

				$resolved = self::resolve_path_in_value( $row[ $segment ], $segments );

				if ( empty( $segments ) ) {
					if ( is_array( $resolved ) ) {
						foreach ( $resolved as $item ) {
							$result[] = $item;
						}
					}
				} elseif ( ! empty( $resolved ) ) {
					foreach ( $resolved as $item ) {
						$result[] = $item;
					}
				}
			}

			return $result;
		}

		private static function path_exists_in_value( $value, $segments ) {

			if ( empty( $segments ) ) {
				return true;
			}

			if ( is_object( $value ) ) {
				$value = get_object_vars( $value );
			}

			if ( is_array( $value ) && self::is_assoc_array( $value ) ) {
				$segment = array_shift( $segments );

				if ( ! array_key_exists( $segment, $value ) ) {
					return false;
				}

				return self::path_exists_in_value( $value[ $segment ], $segments );
			}

			if ( ! is_array( $value ) ) {
				return false;
			}

			$segment = array_shift( $segments );

			foreach ( $value as $row ) {

				if ( is_object( $row ) ) {
					$row = get_object_vars( $row );
				}

				if ( ! is_array( $row ) || ! array_key_exists( $segment, $row ) ) {
					continue;
				}

				if ( self::path_exists_in_value( $row[ $segment ], $segments ) ) {
					return true;
				}
			}

			return false;
		}

		private static function is_valid_path_segment( $segment ) {

			$segment = is_scalar( $segment ) ? (string) $segment : '';

			if ( '' === $segment ) {
				return false;
			}

			if ( preg_match( '/^\d+$/', $segment ) ) {
				return true;
			}

			return (bool) preg_match( '/^[A-Za-z_][A-Za-z0-9_:\-]*$/', $segment );
		}

		private static function is_reserved_path_segment( $segment ) {
			return in_array( strtolower( (string) $segment ), self::$reserved_segments, true );
		}

		private static function get_max_path_length() {
			return max( 1, absint( apply_filters( 'jet-engine/repeater/max-path-length', self::DEFAULT_MAX_PATH_LENGTH ) ) );
		}

		private static function get_max_segment_count() {
			return max( 1, absint( apply_filters( 'jet-engine/repeater/max-segment-count', self::DEFAULT_MAX_SEGMENT_COUNT ) ) );
		}
	}
}
