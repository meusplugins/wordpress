<?php return array('dependencies' => array(), 'version' => '1cf6c790487da3788426');
