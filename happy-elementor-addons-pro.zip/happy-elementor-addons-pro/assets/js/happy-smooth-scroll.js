"use strict";

(function ($) {
  "use strict";

  /**
   * Initialize Lenis smooth scrolling once for the whole page.
   *
   * Unlike the old GSAP ScrollSmoother approach, Lenis drives the real
   * window scroll via requestAnimationFrame, so position:sticky,
   * position:fixed and Elementor Motion Effects (Parallax/Sticky/Mouse)
   * keep working.
   *
   * This is opt-in (Smooth Scroll feature toggle) and is skipped on:
   *  - touch / coarse-pointer devices (native momentum scroll)
   *  - the Elementor editor and preview
   *  - pages where another smoother is already running (e.g. WCF)
   */
  function initLenis() {
    if (typeof Lenis === "undefined" || typeof gsap === "undefined") {
      return;
    }

    // Never run inside the Elementor editor / preview iframe.
    if (typeof elementorFrontend !== "undefined" && elementorFrontend.isEditMode && elementorFrontend.isEditMode()) {
      return;
    }

    // Skip on touch / coarse-pointer devices so native momentum + mobile
    // Elementor sticky/parallax are preserved.
    var coarse = window.matchMedia && window.matchMedia("(hover: none), (pointer: coarse)").matches;
    if (coarse || navigator.maxTouchPoints && navigator.maxTouchPoints > 0 && !window.matchMedia("(hover: hover)").matches) {
      return;
    }

    // Never stack multiple smoothers (ours or from another plugin/theme).
    if (window.__haLenis) {
      return;
    }
    if (typeof ScrollSmoother !== "undefined" && ScrollSmoother.get && ScrollSmoother.get()) {
      return;
    }

    // Use Lenis' native lerp-based smoothing (default lerp ~0.1) for a
    // responsive, seamless feel. Setting `duration` would switch to a
    // fixed-length ease that feels heavy/laggy, so it is intentionally
    // left unset.
    var lenis = new Lenis({
      smoothWheel: true
    });
    window.__haLenis = lenis;

    // Wire Lenis -> ScrollTrigger so GSAP scroll animations stay in sync.
    if (typeof ScrollTrigger !== "undefined") {
      gsap.registerPlugin(ScrollTrigger);
      lenis.on("scroll", ScrollTrigger.update);
    }

    // Drive Lenis from the GSAP ticker (synced RAF loop).
    gsap.ticker.add(function (time) {
      lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    // Recalculate trigger positions once fonts/images settle.
    window.addEventListener("load", function () {
      if (typeof ScrollTrigger !== "undefined") {
        ScrollTrigger.refresh();
      }
    });
  }
  $(window).on("elementor/frontend/init", function () {
    initLenis();
  });
})(jQuery);