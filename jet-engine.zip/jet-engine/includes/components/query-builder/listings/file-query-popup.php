<?php
namespace Jet_Engine\Query_Builder\Listings;

use Jet_Engine\Query_Builder\Manager as Query_Manager;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Handles popup object resolution for file-query listing items.
 *
 * Listens to the compatibility filter fired by the Popup Package and resolves
 * the correct file-query item so the popup renders with the right context.
 */
class File_Query_Popup {

	/**
	 * Reference to the listings manager, used to extract query IDs from item IDs.
	 *
	 * @var Manager
	 */
	protected $manager;

	/**
	 * Constructor.
	 *
	 * Stores the manager reference and registers the popup object filter.
	 *
	 * @param Manager $manager The query-builder listings manager instance.
	 */
	public function __construct( Manager $manager ) {
		$this->manager = $manager;

		add_filter(
			'jet-engine/compatibility/popup-package/query/file-query/post-object',
			array( $this, 'set_popup_object' ),
			10, 3
		);
	}

	/**
	 * Resolve the correct file-query item to use as the popup post object.
	 *
	 * Attempts to identify the originating file query from the item ID embedded
	 * in the popup data, initialises the query (including any active
	 * JetSmartFilters state), and returns the matching item object so the popup
	 * renders with correct context.
	 *
	 * @param \WP_Post|object $post_obj   The default post object passed to the popup.
	 * @param array           $popup_data Popup request data, including `postId` and optionally `filtered_query`.
	 * @param object|false    $query      The query instance currently associated with the popup, or false.
	 * @return \WP_Post|object The resolved item object, or the original $post_obj as fallback.
	 */
	public function set_popup_object( $post_obj, $popup_data, $query ) {

		$item_id = ! empty( $popup_data['postId'] ) && is_scalar( $popup_data['postId'] ) ? (string) $popup_data['postId'] : '';

		if ( ! $item_id ) {
			return $post_obj;
		}

		$query = $this->maybe_get_query_from_item_id( $item_id, $query );

		if ( ! $query || ! method_exists( $query, 'get_item_by_stable_id' ) ) {
			return $post_obj;
		}

		$this->setup_query_for_popup( $query, $popup_data );

		$item = $query->get_item_by_stable_id( $item_id );

		return $item ? $item : $post_obj;
	}

	/**
	 * Initialise a file query and apply any active JetSmartFilters state for popup rendering.
	 *
	 * Calls `setup_query()` on the given query object and, when JetSmartFilters is
	 * active and a `filtered_query` payload is present in the popup data, iterates
	 * over the filter properties and pushes them into the query via `set_filtered_prop`.
	 *
	 * @param object $query      The file-query instance to set up.
	 * @param array  $popup_data Popup request data, optionally containing `filtered_query`.
	 * @return void
	 */
	protected function setup_query_for_popup( $query, $popup_data ) {
		$query->setup_query();

		if ( function_exists( 'jet_smart_filters' ) && ! empty( $popup_data['filtered_query'] ) ) {
			$filtered_query = jet_smart_filters()->query->get_query_from_request( $popup_data['filtered_query'] );

			if ( ! empty( $filtered_query ) ) {
				foreach ( $filtered_query as $prop => $value ) {
					$query->set_filtered_prop( $prop, $value );
				}
			}
		}
	}

	/**
	 * Attempt to resolve a file-query instance from an item ID.
	 *
	 * Extracts the query ID prefix from the item ID string. If the prefix matches
	 * the already-known query, returns it directly. Otherwise looks up the query
	 * by ID and verifies it is a file-query type before returning it. Falls back
	 * to the provided $query argument when resolution fails.
	 *
	 * @param string       $item_id The stable item identifier, expected to start with `{queryId}-`.
	 * @param object|false $query   An already-resolved query instance to use as a fallback, or false.
	 * @return object|false The resolved file-query instance, or $query on failure.
	 */
	protected function maybe_get_query_from_item_id( $item_id, $query = false ) {
		$item_query_id = $this->manager->extract_query_id_from_item_id( $item_id );

		if ( ! $item_query_id ) {
			return $query;
		}

		if ( $query && absint( $query->id ) === $item_query_id ) {
			return $query;
		}

		$resolved_query = Query_Manager::instance()->get_query_by_id( $item_query_id );

		if ( ! $resolved_query || 'file-query' !== $resolved_query->get_query_type() ) {
			return $query;
		}

		return $resolved_query;
	}

}
