<?php
class WPML_Elementor_Integration_Factory {

	const SLUG = 'elementor';

	public function create() {

		$action_filter_loader = new WPML_Action_Filter_Loader();
		$action_filter_loader->load(
			array(
				'WPML_Elementor_Translate_IDs_Factory',
				'WPML_Elementor_URLs_Factory',
				'WPML_Elementor_Adjust_Global_Widget_ID_Factory',
				'WPML_PB_Elementor_Handle_Custom_Fields_Factory',
				'WPML_Elementor_Media_Hooks_Factory',
				'WPML_Elementor_WooCommerce_Hooks_Factory',
				\WPML\PB\Elementor\Hooks\WooCommerce::class,
				\WPML\PB\Elementor\LanguageSwitcher\LanguageSwitcher::class,
				\WPML\PB\Elementor\Hooks\DynamicElements::class,
				\WPML\PB\Elementor\V4\Hooks::class,
				\WPML\PB\Elementor\V4\Component\QueryHooks::class,
				\WPML\PB\Elementor\V4\Component\Cache::class,
				\WPML\PB\Elementor\V4\Component\CopiedData::class,
				\WPML\PB\Elementor\V4\Component\Styles::class,
				\WPML\PB\Elementor\Hooks\FormPopup::class,
				\WPML\PB\Elementor\Hooks\PopupQueue::class,
				\WPML\PB\Elementor\Hooks\GutenbergCleanup::class,
				\WPML\PB\Elementor\Hooks\Frontend::class,
				\WPML\PB\Elementor\Hooks\DomainsWithMultisite::class,
				\WPML\PB\Elementor\Config\Factory::class,
				\WPML\PB\Elementor\AutoConfig\Factory::class,
				\WPML\PB\Elementor\Hooks\LandingPages::class,
				\WPML\PB\Elementor\Hooks\Editor::class,
				\WPML\PB\Elementor\Hooks\PreviewRedirect::class,
				\WPML\PB\Elementor\Hooks\WordPressWidgets::class,
				\WPML\PB\Elementor\Hooks\Templates::class,
				\WPML\PB\Elementor\Hooks\AppearedOnSite::class,
				\WPML\PB\Elementor\Hooks\Cache::class,
				\WPML\PB\Elementor\Hooks\KitDeletion::class,
				\WPML_PB_Fix_Maintenance_Query::class,
				\WPML\PB\Elementor\Hooks\TranslationJobImages::class,
				\WPML\PB\Elementor\Hooks\FormEmailPlaceholders::class,
				\WPML\PB\Elementor\Hooks\CustomFonts::class,
				\WPML\PB\Elementor\Hooks\QueryFilter::class,
				\WPML\PB\Elementor\Hooks\SavePostActions::class,
				\WPML\PB\Elementor\Hooks\EditorLanguage::class,
				\WPML\PB\Elementor\Hooks\Shortcodes::class,
				\WPML\PB\Elementor\Hooks\RawHtmlSetting::class,
				\WPML\PB\Elementor\Hooks\DisplayConditions::class,
				\WPML\PB\Elementor\Config\IdsInWidgets::class,
				\WPML\PB\Elementor\Hooks\TranslationGuiLabels::class,
				\WPML\PB\Elementor\Hooks\DisambiguateMediaCarouselUrls::class,
				\WPML\PB\Elementor\Hooks\SiteSettings::class,
				\WPML\PB\Elementor\Hooks\HeaderFooterFields::class,
				\WPML\PB\Elementor\Hooks\QueryWidgetFields::class,
				\WPML\PB\Elementor\Hooks\EditorTemplateIds::class,
				\WPML\PB\Elementor\Hooks\FormFields::class,
				\WPML\PB\Elementor\Hooks\RecaptchaLanguage::class,
			)
		);

		$nodes                = new WPML_Elementor_Translatable_Nodes();
		$elementor_db_factory = new WPML_Elementor_DB_Factory();
		$data_settings        = new WPML_Elementor_Data_Settings( $elementor_db_factory->create() );

		( new \WPML\PB\Duplication\Hooks( $data_settings, new \WPML\PB\Links\PostDataLinks( $data_settings ) ) )->add_hooks();

		$string_registration_factory = new WPML_String_Registration_Factory( $data_settings->get_pb_name() );
		$string_registration         = $string_registration_factory->create();

		$register_strings   = new WPML_Elementor_Register_Strings( $nodes, $data_settings, $string_registration );
		$update_translation = new WPML_Elementor_Update_Translation(
			$nodes,
			$data_settings,
			new \WPML\PB\Elementor\V4\Component\InstanceIds(),
			new \WPML\PB\Elementor\V4\Component\Cache()
		);

		return new WPML_Page_Builders_Integration( $register_strings, $update_translation, $data_settings );
	}
}
