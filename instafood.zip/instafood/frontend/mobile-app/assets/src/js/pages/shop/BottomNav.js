import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Events, Event } from '../../events/EventBus';
import DataUtils from '../../utils/DataUtils';

class BottomNav {
    _parrentUI;
    _ui;
    _onOrderConfChanged;
    _onOrderPaymentChanged;

    _isPlacingOrder = false;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._ui = this._parrentUI.find('.both_nav_apt_nav_bottom');
    }
    
    render() {
        const _this = this;
        const template = `
            <div class="cart_nav_bottom">
                <a href="tel:${ DataUtils.getInstance().getOption('restaurant_phone') }" class="apt_button primary bottom_close_btn">
                <span class="icon-phone" style="margin-right: .7em;"></span>
                ${ LanguageUtils.getInstance().getLabel('phone_call_label') }
                </a>
            </div>
        `;
        jQuery(template).appendTo(this._ui);
    }
}
export default BottomNav;