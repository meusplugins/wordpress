<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;

if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . 'GeneralSettings.php');
require_once(plugin_dir_path(__FILE__) . 'Credentials.php');
require_once(plugin_dir_path(__FILE__) . 'WebApps.php');
require_once(plugin_dir_path(__FILE__) . 'OrderOptions.php');
require_once(plugin_dir_path(__FILE__) . 'LocalesSettings.php');
require_once(plugin_dir_path(__FILE__) . 'CustomCode.php');
require_once(plugin_dir_path(__FILE__) . 'TableManagement.php');
require_once(plugin_dir_path(__FILE__) . '../../../utils/TimeUtils.php');

use com\sakuraplugins\appetit\utils\TimeUtils;

class SettingsConfig {
    static function get(): array {
        return [
            [
                'menu_label' => esc_html__('General settings', 'instafood'),
                'content_id' => 'general_settings',
                'SectionClass' => new GeneralSettings(),
                'isActive' => true,
            ],
            [
                'menu_label' => esc_html__('Credentials', 'instafood'),
                'content_id' => 'credentials',
                'SectionClass' => new Credentials(),
                'isActive' => false,
            ],
            [
                'menu_label' => esc_html__('Web apps', 'instafood'),
                'content_id' => 'web-apps',
                'SectionClass' => new WebApps(),
                'isActive' => false,
            ],
            [
                'menu_label' => esc_html__('Order options', 'instafood'),
                'content_id' => 'order-options',
                'SectionClass' => new OrderOptions(),
                'isActive' => false,
            ],
            [
                'menu_label' => esc_html__('Locales', 'instafood'),
                'content_id' => 'locales',
                'SectionClass' => new LocalesSettings(),
                'isActive' => false,
            ],
            [
                'menu_label' => esc_html__('Tables & QrCodes', 'instafood'),
                'content_id' => 'tables_orders',
                'SectionClass' => new TableManagement(),
                'isActive' => false,
            ],
            [
                'menu_label' => esc_html__('Custom styles & JS', 'instafood'),
                'content_id' => 'custom_code',
                'SectionClass' => new CustomCode(),
                'isActive' => false,
            ],
        ];
    }

    static function getLocales() {
        $locales = [
            [
                'db_key' => 'delivery_time',
                'primary_lang_' => esc_html__('Delivery <%= orderPrepareTime %> min', 'instafood'),
                'secondary_lang_' => esc_html__('Delivery <%= orderPrepareTime %> min', 'instafood'),
                'label' => esc_html__('Delivery time', 'instafood'),
                'info' => esc_html__('Used on mobile web homepage', 'instafood'),
            ],
            [
                'db_key' => 'product_variants_price_info',
                'primary_lang_' => esc_html__('from <%= productPrice %>', 'instafood'),
                'secondary_lang_' => esc_html__('from <%= productPrice %>', 'instafood'),
                'label' => esc_html__('Product price info', 'instafood'),
                'info' => esc_html__('Used for products with variants on mobile web product screen', 'instafood'),
            ],
            [
                'db_key' => 'product_required_option',
                'primary_lang_' => esc_html__('<%= optionsNo %> Required', 'instafood'),
                'secondary_lang_' => esc_html__('Obligatoire <%= optionsNo %>', 'instafood'),
                'label' => esc_html__('Required option', 'instafood'),
                'info' => esc_html__('Required label for product with variations or choice groups', 'instafood'),
            ],
            [
                'db_key' => 'product_add_to_cart',
                'primary_lang_' => esc_html__('Add to cart', 'instafood'),
                'secondary_lang_' => esc_html__('Ajouter au panier', 'instafood'),
                'label' => esc_html__('Add to cart label', 'instafood'),
                'info' => esc_html__('Used on the product screen to update/add product quantity', 'instafood'),
            ],
            [
                'db_key' => 'product_udapte_cart',
                'primary_lang_' => esc_html__('Update', 'instafood'),
                'secondary_lang_' => esc_html__('Mettre à jour', 'instafood'),
                'label' => esc_html__('Udapte cart', 'instafood'),
                'info' => esc_html__('Used on the product screen to update/add product quantity', 'instafood'),
            ],
            [
                'db_key' => 'product_variation',
                'primary_lang_' => esc_html__('Variation', 'instafood'),
                'secondary_lang_' => esc_html__('Variation', 'instafood'),
                'label' => esc_html__('Product variation label', 'instafood'),
                'info' => esc_html__('Used on the product screen within choices groups', 'instafood'),
            ],
            [
                'db_key' => 'product_choice_group_optional',
                'primary_lang_' => esc_html__('Optional', 'instafood'),
                'secondary_lang_' => esc_html__('Optional', 'instafood'),
                'label' => esc_html__('Choice group optional label', 'instafood'),
                'info' => esc_html__('Used on the product screen within choices groups', 'instafood'),
            ],
            [
                'db_key' => 'product_choice_group_max_select',
                'primary_lang_' => esc_html__('Select up to <%= optionsNo %>', 'instafood'),
                'secondary_lang_' => esc_html__('Select up to <%= optionsNo %>', 'instafood'),
                'label' => esc_html__('Choice group max choice select label', 'instafood'),
                'info' => esc_html__('Used on the product screen within choices groups', 'instafood'),
            ],
            [
                'db_key' => 'product_additional_notes',
                'primary_lang_' => esc_html__('Additional notes', 'instafood'),
                'secondary_lang_' => esc_html__('Notes complémentaires', 'instafood'),
                'label' => esc_html__('Product additional notes', 'instafood'),
                'info' => esc_html__('Used on the product screen', 'instafood'),
            ],
            [
                'db_key' => 'view_cart_label',
                'primary_lang_' => esc_html__('View cart', 'instafood'),
                'secondary_lang_' => esc_html__('Voir le panier', 'instafood'),
                'label' => esc_html__('View cart label', 'instafood'),
            ],
            [
                'db_key' => 'cart_title',
                'primary_lang_' => esc_html__('Cart', 'instafood'),
                'secondary_lang_' => esc_html__('Chariot', 'instafood'),
                'label' => esc_html__('Cart screen title', 'instafood'),
            ],
            [
                'db_key' => 'cart_top_nav_total',
                'primary_lang_' => esc_html__('Total', 'instafood'),
                'secondary_lang_' => esc_html__('Total', 'instafood'),
                'label' => esc_html__('Cart total (top nav) label', 'instafood'),
            ],
            [
                'db_key' => 'cart_top_nav_vat_info',
                'primary_lang_' => esc_html__('(incl. VAT)', 'instafood'),
                'secondary_lang_' => esc_html__('(TVA incluse)', 'instafood'),
                'label' => esc_html__('Cart VAT info (top nav) label', 'instafood'),
            ],
            [
                'db_key' => 'review_order_label',
                'primary_lang_' => esc_html__('Review order', 'instafood'),
                'secondary_lang_' => esc_html__('Vérifier la commande', 'instafood'),
                'label' => esc_html__('Review order label', 'instafood'),
            ],
            [
                'db_key' => 'edit_in_cart_label',
                'primary_lang_' => esc_html__('Edit in cart', 'instafood'),
                'secondary_lang_' => esc_html__('Modifier dans le panier', 'instafood'),
                'label' => esc_html__('Edit in cart label', 'instafood'),
            ],
            [
                'db_key' => 'already_in_cart_label',
                'primary_lang_' => esc_html__('Already in your cart', 'instafood'),
                'secondary_lang_' => esc_html__('Déjà dans votre panier', 'instafood'),
                'label' => esc_html__('Already in cart label', 'instafood'),
            ],
            [
                'db_key' => 'min_order_info',
                'primary_lang_' => esc_html__('You are <%= minOrderValueDif %> away from the minimum order', 'instafood'),
                'secondary_lang_' => esc_html__('Vous êtes à <%= minOrderValueDif %> du minimum de commande', 'instafood'),
                'label' => esc_html__('Minimum order info', 'instafood'),
            ],
            [
                'db_key' => 'order_page_title',
                'primary_lang_' => esc_html__('Order review', 'instafood'),
                'secondary_lang_' => esc_html__('Examen de la commande', 'instafood'),
                'label' => esc_html__('Order screen title', 'instafood'),
            ],
            [
                'db_key' => 'place_order_label',
                'primary_lang_' => esc_html__('Place order', 'instafood'),
                'secondary_lang_' => esc_html__('Passer la commande', 'instafood'),
                'label' => esc_html__('Place order label', 'instafood'),
            ],
            [
                'db_key' => 'order_summary_widget_label',
                'primary_lang_' => esc_html__('Order summary', 'instafood'),
                'secondary_lang_' => esc_html__('Récapitulatif de la commande', 'instafood'),
                'label' => esc_html__('Order summary label (Order review screen)', 'instafood'),
            ],
            [
                'db_key' => 'tip_percentage_summary_label',
                'primary_lang_' => esc_html__('Tip (<%= tipPercent %> %)', 'instafood'),
                'secondary_lang_' => esc_html__('Pourboire (<%= tipPercent %> %)', 'instafood'),
                'label' => esc_html__('Tipping percentage label', 'instafood'),
            ],
            [
                'db_key' => 'order_summary_widget_subtotal_label',
                'primary_lang_' => esc_html__('Subtotal', 'instafood'),
                'secondary_lang_' => esc_html__('Subtotal', 'instafood'),
                'label' => esc_html__('Order summary subtotal label', 'instafood'),
            ],
            [
                'db_key' => 'order_summary_widget_total_label',
                'primary_lang_' => esc_html__('Total', 'instafood'),
                'secondary_lang_' => esc_html__('Total', 'instafood'),
                'label' => esc_html__('Order summary total label', 'instafood'),
            ],
            [
                'db_key' => 'delivery_method_label',
                'primary_lang_' => esc_html__('Delivery method', 'instafood'),
                'secondary_lang_' => esc_html__('Méthode de livraison', 'instafood'),
                'label' => esc_html__('Delivery method label', 'instafood'),
            ],
            [
                'db_key' => 'local_delivery_label',
                'primary_lang_' => esc_html__('Local delivery', 'instafood'),
                'secondary_lang_' => esc_html__('Livraison à domicile', 'instafood'),
                'label' => esc_html__('Local delivery label', 'instafood'),
            ],
            [
                'db_key' => 'pickup_delivery_label',
                'primary_lang_' => esc_html__('Store pickup', 'instafood'),
                'secondary_lang_' => esc_html__('Cueillette au magasin', 'instafood'),
                'label' => esc_html__('Store pickup label', 'instafood'),
            ],
            [
                'db_key' => 'delivery_fee_label',
                'primary_lang_' => esc_html__('Delivery fee', 'instafood'),
                'secondary_lang_' => esc_html__('Frais de livraison', 'instafood'),
                'label' => esc_html__('Delivery fee label', 'instafood'),
            ],
            [
                'db_key' => 'free_delivery_label',
                'primary_lang_' => esc_html__('Free', 'instafood'),
                'secondary_lang_' => esc_html__('Gratuit', 'instafood'),
                'label' => esc_html__('Free delivery label', 'instafood'),
            ],
            [
                'db_key' => 'delivery_info_wgt_title',
                'primary_lang_' => esc_html__('Delivery information', 'instafood'),
                'secondary_lang_' => esc_html__('Informations de livraison', 'instafood'),
                'label' => esc_html__('Delivery info title', 'instafood'),
            ],
            [
                'db_key' => 'delivery_info_wgt_info',
                'primary_lang_' => esc_html__('Add delivery information', 'instafood'),
                'secondary_lang_' => esc_html__('Ajouter des informations de livraison', 'instafood'),
                'label' => esc_html__('Delivery widget info', 'instafood'),
            ],
            [
                'db_key' => 'delivery_info_popup_title',
                'primary_lang_' => esc_html__('Delivery information', 'instafood'),
                'secondary_lang_' => esc_html__('Informations de livraison', 'instafood'),
                'label' => esc_html__('Delivery info popup title', 'instafood'),
            ],
            [
                'db_key' => 'customer_phone',
                'primary_lang_' => esc_html__('Phone', 'instafood'),
                'secondary_lang_' => esc_html__('Téléphone', 'instafood'),
                'label' => esc_html__('Customer phone label', 'instafood'),
            ],
            [
                'db_key' => 'customer_city',
                'primary_lang_' => esc_html__('City', 'instafood'),
                'secondary_lang_' => esc_html__('Ville', 'instafood'),
                'label' => esc_html__('Customer city label', 'instafood'),
            ],
            [
                'db_key' => 'customer_address',
                'primary_lang_' => esc_html__('Address', 'instafood'),
                'secondary_lang_' => esc_html__('Adresse', 'instafood'),
                'label' => esc_html__('Customer address label', 'instafood'),
            ],
            [
                'db_key' => 'customer_additional_delivery_info',
                'primary_lang_' => esc_html__('Additional delivery information', 'instafood'),
                'secondary_lang_' => esc_html__('Informations de livraison supplémentaires', 'instafood'),
                'label' => esc_html__('Customer additional delivery info', 'instafood'),
            ],
            [
                'db_key' => 'customer_delivery_save_data_lable',
                'primary_lang_' => esc_html__('Save for future use', 'instafood'),
                'secondary_lang_' => esc_html__('Enregistrer pour une utilisation future', 'instafood'),
                'label' => esc_html__('Customer save address locally label', 'instafood'),
            ],
            [
                'db_key' => 'customer_add_address',
                'primary_lang_' => esc_html__('Save address', 'instafood'),
                'secondary_lang_' => esc_html__("Enregistrer l'adresse", 'instafood'),
                'label' => esc_html__('Save address label', 'instafood'),
            ],
            [
                'db_key' => 'error_delivery_distance',
                'primary_lang_' => esc_html__('We are sorry we cannot deliver to your area', 'instafood'),
                'secondary_lang_' => esc_html__("Nous sommes désolés de ne pouvoir livrer dans votre région", 'instafood'),
                'label' => esc_html__('Delivery distance error', 'instafood'),
            ],
            [
                'db_key' => 'pickup_info_wgt_title',
                'primary_lang_' => esc_html__('Pickup time', 'instafood'),
                'secondary_lang_' => esc_html__('Pickup time', 'instafood'),
                'label' => esc_html__('Pickup widget info title', 'instafood'),
            ],
            [
                'db_key' => 'pickup_info_wgt_info',
                'primary_lang_' => esc_html__('Add pickup time', 'instafood'),
                'secondary_lang_' => esc_html__('Add pickup time', 'instafood'),
                'label' => esc_html__('Pickup widget time info', 'instafood'),
            ],
            [
                'db_key' => 'pickup_info_popup_title',
                'primary_lang_' => esc_html__('Pickup date', 'instafood'),
                'secondary_lang_' => esc_html__('Date de ramassage', 'instafood'),
                'label' => esc_html__('Pickup info popup title', 'instafood'),
            ],
            [
                'db_key' => 'pickup_info_choose_day',
                'primary_lang_' => esc_html__('Choose day', 'instafood'),
                'secondary_lang_' => esc_html__('Choisissez le jour', 'instafood'),
                'label' => esc_html__('Pickup date label', 'instafood'),
            ],
            [
                'db_key' => 'pickup_info_choose_day_placeholder',
                'primary_lang_' => esc_html__('tap to choose day', 'instafood'),
                'secondary_lang_' => esc_html__('appuyez pour choisir le jour', 'instafood'),
                'label' => esc_html__('Pickup choose day placeholder', 'instafood'),
            ],
            [
                'db_key' => 'customer_save_pickup_date',
                'primary_lang_' => esc_html__('Save date', 'instafood'),
                'secondary_lang_' => esc_html__("Save date", 'instafood'),
                'label' => esc_html__('Add/Save pickup date label', 'instafood'),
            ],
            [
                'db_key' => 'choose_pickup_time',
                'primary_lang_' => esc_html__('Choose pickup time', 'instafood'),
                'secondary_lang_' => esc_html__("Choisissez l'heure de prise en charge", 'instafood'),
                'label' => esc_html__('Choose pickup hour label', 'instafood'),
            ],
            [
                'db_key' => 'payment_method_wgt_title',
                'primary_lang_' => esc_html__('Payment method', 'instafood'),
                'secondary_lang_' => esc_html__('Mode de paiement', 'instafood'),
                'label' => esc_html__('Payment method widget title', 'instafood'),
            ],
            [
                'db_key' => 'payment_method_cash',
                'primary_lang_' => esc_html__('Cash on delivery', 'instafood'),
                'secondary_lang_' => esc_html__('Paiement à la livraison', 'instafood'),
                'label' => esc_html__('Cash on delivery label', 'instafood'),
            ],
            [
                'db_key' => 'payment_method_stripe',
                'primary_lang_' => esc_html__('Card (Stripe)', 'instafood'),
                'secondary_lang_' => esc_html__('Carte (Stripe)', 'instafood'),
                'label' => esc_html__('Stripe delivery label', 'instafood'),
            ],
            [
                'db_key' => 'pickup_person_info_wgt_title',
                'primary_lang_' => esc_html__('Contact information', 'instafood'),
                'secondary_lang_' => esc_html__('Informations de contact', 'instafood'),
                'label' => esc_html__('Pickup person info title', 'instafood'),
            ],
            [
                'db_key' => 'pickup_contact_info_wgt_info',
                'primary_lang_' => esc_html__('Add contact information', 'instafood'),
                'secondary_lang_' => esc_html__('Ajouter des informations de contact', 'instafood'),
                'label' => esc_html__('Pickup contact widget info', 'instafood'),
            ],
            [
                'db_key' => 'pickup_person_info_popup_title',
                'primary_lang_' => esc_html__('Phone & name', 'instafood'),
                'secondary_lang_' => esc_html__('Téléphone et nom', 'instafood'),
                'label' => esc_html__('Pickup person info popup title', 'instafood'),
            ],
            [
                'db_key' => 'customer_picku_first_name',
                'primary_lang_' => esc_html__('First name', 'instafood'),
                'secondary_lang_' => esc_html__('Prénom', 'instafood'),
                'label' => esc_html__('Customer first name label', 'instafood'),
            ],
            [
                'db_key' => 'customer_save_contact',
                'primary_lang_' => esc_html__('Save contact', 'instafood'),
                'secondary_lang_' => esc_html__("Enregistrer le contact", 'instafood'),
                'label' => esc_html__('Save contact label', 'instafood'),
            ],
            [
                'db_key' => 'order_complete_title',
                'primary_lang_' => esc_html__('Order complete', 'instafood'),
                'secondary_lang_' => esc_html__('Commande terminée', 'instafood'),
                'label' => esc_html__('Order complete screen success title', 'instafood'),
            ],
            [
                'db_key' => 'order_complete_fail_title',
                'primary_lang_' => esc_html__('Order failed', 'instafood'),
                'secondary_lang_' => esc_html__('La commande a échoué', 'instafood'),
                'label' => esc_html__('Order complete screen fail title', 'instafood'),
            ],
            [
                'db_key' => 'order_fail_message',
                'primary_lang_' => esc_html__('Unfortunately, the order has been cancelled.', 'instafood'),
                'secondary_lang_' => esc_html__('Malheureusement, la commande a été annulée.', 'instafood'),
                'label' => esc_html__('Order fail message', 'instafood'),
                'info' => esc_html__('Most likely the user has cancelled the payment', 'instafood'),
            ],
            [
                'db_key' => 'order_success_dinein_msg',
                'primary_lang_' => esc_html__('Thank you for your order, someone will be with you shortly.', 'instafood'),
                'secondary_lang_' => esc_html__("Merci pour votre commande, quelqu'un sera avec vous sous peu.", 'instafood'),
                'label' => esc_html__('Order success dine-in message', 'instafood'),
                'info' => esc_html__('Text within the app order complete screen', 'instafood'),
            ],
            [
                'db_key' => 'order_success_delivery_msg',
                'primary_lang_' => esc_html__('Thank you for your order. Your order should arrive within the next 30-45 minutes.', 'instafood'),
                'secondary_lang_' => esc_html__("Nous vous remercions de votre commande. Votre commande devrait arriver dans les 30 à 45 prochaines minutes.", 'instafood'),
                'label' => esc_html__('Order success delivery message', 'instafood'),
                'info' => esc_html__('Text within the app order complete screen', 'instafood'),
            ],
            [
                'db_key' => 'order_success_pickup_msg',
                'primary_lang_' => esc_html__("Thank you for your order. Your order will be ready for you to pick up on <%= orderPickupDate %> at the restaurant location (Street Address...).", 'instafood'),
                'secondary_lang_' => esc_html__("Nous vous remercions de votre commande. Votre commande sera prête à être récupérée le <%= orderPickupDate %> à l'emplacement du restaurant (adresse de la rue...).", 'instafood'),
                'label' => esc_html__('Order success pickup message', 'instafood'),
                'info' => esc_html__('Text within the app order complete screen', 'instafood'),
            ],
            [
                'db_key' => 'order_success_pickup_safe_match_msg',
                'primary_lang_' => esc_html__("In order to safely pick up your order, take a print screen with the code below and show it to the person at the store.", 'instafood'),
                'secondary_lang_' => esc_html__("Afin de récupérer votre commande en toute sécurité, prenez un écran d'impression avec le code ci-dessous et montrez-le à la personne en magasin.", 'instafood'),
                'label' => esc_html__('Order success pickup safematch message', 'instafood'),
                'info' => esc_html__('Text within the app order complete screen', 'instafood'),
            ],
            [
                'db_key' => 'shop_closed_message',
                'primary_lang_' => esc_html__("The restaurant is currently closed, delivery or dine-in is not possible.", 'instafood'),
                'secondary_lang_' => esc_html__("Le restaurant est actuellement fermé, la livraison ou le dîner sur place n'est pas possible.", 'instafood'),
                'label' => esc_html__('Shop currently closed message', 'instafood'),
                'info' => esc_html__('The message shows for dine-in and delivery when an order is about to be placed outside business hours.', 'instafood'),
            ],
            [
                'db_key' => 'phone_call_label',
                'primary_lang_' => esc_html__('Call', 'instafood'),
                'secondary_lang_' => esc_html__('Call', 'instafood'),
                'label' => esc_html__('Call restaurant label', 'instafood'),
            ],
            [
                'db_key' => 'restaurant_about_wdg_title',
                'primary_lang_' => esc_html__('About', 'instafood'),
                'secondary_lang_' => esc_html__('About', 'instafood'),
                'label' => esc_html__('Restaurant about widget title', 'instafood'),
            ],
            [
                'db_key' => 'restaurant_address_wdg_title',
                'primary_lang_' => esc_html__('Address', 'instafood'),
                'secondary_lang_' => esc_html__('Address', 'instafood'),
                'label' => esc_html__('Restaurant about widget title', 'instafood'),
            ],
            [
                'db_key' => 'restaurant_working_hours_wdg_title',
                'primary_lang_' => esc_html__('Working hours', 'instafood'),
                'secondary_lang_' => esc_html__('Working hours', 'instafood'),
                'label' => esc_html__('Restaurant working hours widget title', 'instafood'),
            ],
            [
                'db_key' => 'homescreen_about_restaurant',
                'primary_lang_' => esc_html__('About', 'instafood'),
                'secondary_lang_' => esc_html__('About', 'instafood'),
                'label' => esc_html__('About label (homescreen)', 'instafood'),
            ],
            [
                'db_key' => 'homescreen_call_waiter',
                'primary_lang_' => esc_html__('Call waiter', 'instafood'),
                'secondary_lang_' => esc_html__('Appelle le serveur', 'instafood'),
                'label' => esc_html__('Call waiter label (homescreen)', 'instafood'),
            ],
            [
                'db_key' => 'call_waiter_response',
                'primary_lang_' => esc_html__('Someone will be with you shortly.', 'instafood'),
                'secondary_lang_' => esc_html__("Quelqu'un sera avec vous sous peu", 'instafood'),
                'label' => esc_html__('Call waiter response', 'instafood'),
            ],
            [
                'db_key' => 'terms_and_conditions_text',
                'primary_lang_' => esc_html__('I agree with the <%= termsLinkLabel %>.', 'instafood'),
                'secondary_lang_' => esc_html__("Je suis d'accord avec le <%= termsLinkLabel %>.", 'instafood'),
                'label' => esc_html__('Terms and conditions text', 'instafood'),
                'info' => esc_html__('Used on mobile web checkout page', 'instafood'),
            ],
            [
                'db_key' => 'terms_and_conditions_link_label',
                'primary_lang_' => esc_html__('Terms and Conditions', 'instafood'),
                'secondary_lang_' => esc_html__("Termes et conditions", 'instafood'),
                'label' => esc_html__('Terms and conditions link label', 'instafood'),
                'info' => esc_html__('Used on mobile web checkout page', 'instafood'),
            ],
            [
                'db_key' => 'price_from_homepage',
                'primary_lang_' => esc_html__('', 'instafood'),
                'secondary_lang_' => esc_html__("", 'instafood'),
                'label' => esc_html__('Price from label', 'instafood'),
                'info' => esc_html__('Used on homepage product list', 'instafood'),
            ],
            [
                'db_key' => 'order_types_not_available',
                'primary_lang_' => esc_html__('Currently, we do not support online ordering, please use the button below to call us.', 'instafood'),
                'secondary_lang_' => esc_html__('Actuellement, nous ne prenons pas en charge les commandes en ligne, veuillez utiliser le bouton ci-dessous pour nous appeler.', 'instafood'),
                'label' => esc_html__('Online order not avialble', 'instafood'),
                'info' => esc_html__('Online order not avialble info, if all order types are disabled, used on order summary page', 'instafood'),
            ],
            [
                'db_key' => 'homescreen_call_restaurant',
                'primary_lang_' => esc_html__('Call restaurant', 'instafood'),
                'secondary_lang_' => esc_html__('Call restaurant', 'instafood'),
                'label' => esc_html__('Homescreen call restaurant', 'instafood'),
            ],
        ];

        $days = TimeUtils::getInstance()->getDays();
        $days_locales = [];
        foreach ($days as $day) {
            $days_locales[] = [
                'db_key' => $day['key'],
                'primary_lang_' => esc_html__($day['label']),
                'secondary_lang_' => esc_html__($day['label']),
                'label' => esc_html__($day['label'] . ' label', 'instafood'),
            ];
        }

        return array_merge($locales, $days_locales);
    }
}
?>