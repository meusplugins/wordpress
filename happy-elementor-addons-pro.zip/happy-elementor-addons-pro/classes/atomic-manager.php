<?php
/**
 * Plugs the Happy Addons Pro components into Elementor V4 (Atomic).
 *
 * The Atomic engine (feature base class, dashboard, active lists, editor
 * controls and runtime) belongs to Happy Addons and is reused, not copied:
 * Pro lists its components through the "happyaddons_atomic_features" filter
 * and ships its own assets. Happy Addons loads and gates them, so nothing
 * runs unless the Atomic integration and the component are both on.
 */
namespace Happy_Addons_Pro\Classes;

defined( 'ABSPATH' ) || die();

class Atomic_Manager {

	const SCRIPT_HANDLE = 'happy-addons-atomic-pro';

	public static function init() {
		// An older Happy Addons has no Atomic engine to plug into.
		if ( ! class_exists( '\Happy_Addons\Elementor\Classes\Atomic_Registry' ) ) {
			return;
		}

		add_filter( 'happyaddons_atomic_features', [ __CLASS__, 'add_features' ] );
		add_action( 'init', [ __CLASS__, 'register_assets' ], 20 );
		// After the Happy Addons editor script it builds on.
		add_action( 'elementor/editor/v2/scripts/enqueue', [ __CLASS__, 'enqueue_editor_script' ], 20 );
	}

	public static function add_features( $features ) {
		return array_merge( is_array( $features ) ? $features : [], Atomic_Registry::features() );
	}

	/**
	 * Editor panel controls of the Global Animation "Custom Properties" and Display Condition "Conditions" repeaters.
	 */
	public static function enqueue_editor_script() {
		$atomic = '\Happy_Addons\Elementor\Classes\Atomic_Manager';

		if ( ! $atomic::is_supported()
			|| ! array_intersect( [ 'global-animation', 'display-condition', 'global-badge', 'multi-layer-parallax', 'image-trails' ], $atomic::get_active( 'features' ) )
			|| ! wp_script_is( $atomic::EDITOR_SCRIPT_HANDLE, 'enqueued' ) ) {
			return;
		}

		$suffix = function_exists( 'ha_is_script_debug_enabled' ) && ha_is_script_debug_enabled() ? '.' : '.min.';

		wp_enqueue_script(
			'happy-addons-atomic-editor-pro',
			HAPPY_ADDONS_PRO_ASSETS . 'js/happy-addons-atomic-editor-pro' . $suffix . 'js',
			[ $atomic::EDITOR_SCRIPT_HANDLE ],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}

	public static function register_assets() {
		$suffix = function_exists( 'ha_is_script_debug_enabled' ) && ha_is_script_debug_enabled() ? '.' : '.min.';

		// Common runtime for every Pro Atomic component (loads after the Happy Addons one).
		wp_register_script(
			self::SCRIPT_HANDLE,
			HAPPY_ADDONS_PRO_ASSETS . 'js/happy-addons-atomic-pro' . $suffix . 'js',
			[ 'happy-elementor-addons-atomic' ],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);

		wp_register_style(
			'happy-pro-atomic-global-animation',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/global-animation' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-infinite-marquee',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/infinite-marquee' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-horizontal-scroll',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/horizontal-scroll' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);
		
		wp_register_style(
			'happy-pro-atomic-image-trails',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/image-trails' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-global-badge',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/global-badge' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-happy-particle-effects',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/happy-particle-effects' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-multi-layer-parallax',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/multi-layer-parallax' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);

		wp_register_style(
			'happy-pro-atomic-sticky-pin-element',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/atomic/sticky-pin-element' . $suffix . 'css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);
	}

	/**
	 * particles.js for Happy Particle Effects. Registered on demand: the Classic
	 * extension (same handle) may be switched off or register it later.
	 */
	public static function register_particles() {
		if ( wp_script_is( 'particles', 'registered' ) ) {
			return;
		}

		wp_register_script(
			'particles',
			HAPPY_ADDONS_PRO_ASSETS . 'vendor/particles/particles.min.js',
			[ 'jquery' ],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}

	/**
	 * Lenis smooth scroll that Global Animation loads on the frontend, as in
	 * Classic. Registered on demand: the Classic extension may be switched off.
	 */
	public static function enqueue_smooth_scroll() {
		$suffix = function_exists( 'ha_is_script_debug_enabled' ) && ha_is_script_debug_enabled() ? '.' : '.min.';

		if ( ! wp_script_is( 'ha-tamrir', 'registered' ) ) {
			wp_register_script(
				'ha-tamrir',
				HAPPY_ADDONS_PRO_ASSETS . 'vendor/tamrir/tamrir.min.js',
				[],
				'1.3.25',
				true
			);
		}

		if ( ! wp_script_is( 'happy-sms', 'registered' ) ) {
			wp_register_script(
				'happy-sms',
				HAPPY_ADDONS_PRO_ASSETS . 'js/happy-sms' . $suffix . 'js',
				[ 'jquery', 'gsap', 'scroll-trigger', 'ha-tamrir' ],
				HAPPY_ADDONS_PRO_VERSION,
				true
			);
		}

		if ( ! wp_style_is( 'happy-sms', 'registered' ) ) {
			wp_register_style(
				'happy-sms',
				HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/happy-sms.min.css',
				[],
				HAPPY_ADDONS_PRO_VERSION
			);
		}

		wp_enqueue_script( 'happy-sms' );
		wp_enqueue_style( 'happy-sms' );
	}
}
