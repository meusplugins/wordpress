<?php
/**
 * Class used to handle requests to the personal library.
 *
 * @package WPCode
 */

/**
 * Class WPCode My Library.
 */
class WPCode_My_Library extends WPCode_Library {

	/**
	 * Transient prefix for a single-use deploy nonce issued to the library.
	 *
	 * @var string
	 */
	const DEPLOY_NONCE_PREFIX = 'wpcode_deploy_nonce_';

	/**
	 * Lifetime of a single-use deploy nonce, in seconds.
	 *
	 * @var int
	 */
	const DEPLOY_NONCE_TTL = 300;

	/**
	 * Transient prefix for the per-IP nonce endpoint rate limiter.
	 *
	 * @var string
	 */
	const DEPLOY_NONCE_RATE_PREFIX = 'wpcode_deploy_nonce_rate_';

	/**
	 * Maximum nonce requests allowed per IP per rate window.
	 *
	 * @var int
	 */
	const DEPLOY_NONCE_RATE_LIMIT = 10;

	/**
	 * Length of the nonce endpoint rate window, in seconds.
	 *
	 * @var int
	 */
	const DEPLOY_NONCE_RATE_WINDOW = 60;

	/**
	 * Key for storing snippets in the cache.
	 *
	 * @var string
	 */
	protected $cache_key = 'my-snippets';

	/**
	 * Library endpoint for loading all data.
	 *
	 * @var string
	 */
	protected $all_snippets_endpoint = 'mysnippets';
	/**
	 * The default time to live for library items that are cached.
	 * 10 minutes for the "my-library" area.
	 *
	 * @var int
	 */
	protected $ttl = 600;
	/**
	 * Meta Key used for storing the library id.
	 *
	 * @var string
	 */
	protected $snippet_library_id_meta_key = '_wpcode_cloud_id';

	/**
	 * Key for transient used to store already installed snippets.
	 *
	 * @var string
	 */
	protected $used_snippets_transient_key = 'wpcode_used_my_cloud_snippets';

	/**
	 * Whether to stamp the connected username as the library author on import.
	 *
	 * @var bool
	 */
	protected $stamp_library_author = true;

	/**
	 * Constructor for class.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
		$this->ajax_hooks();
		$this->push_hooks();

		// Add cloud snippets to the list of snippets with updates.
		add_filter( 'wpcode_snippets_with_updates', array( $this, 'add_cloud_snippets_with_updates' ) );

		// Nudge push-enabled legacy connections to reconnect for passkey deploys.
		add_action( 'wpcode_admin_notices', array( $this, 'maybe_show_passkey_reconnect_notice' ) );
	}

	/**
	 * Show a notice on push-enabled legacy (HMAC) connections inviting the user
	 * to reconnect and enable passkey-secured deploys. Passkey management is
	 * done by reconnecting, so this doubles as the "how to manage keys" hint.
	 *
	 * @return void
	 */
	public function maybe_show_passkey_reconnect_notice() {
		if ( ! class_exists( 'WPCode_Notice' ) ) {
			return;
		}

		$auth = wpcode()->library_auth;

		// Only for a connected, legacy (non-passkey) connection...
		if ( ! $auth->has_auth() || $auth->requires_passkey() ) {
			return;
		}

		// ...that actually has deploys enabled (a webhook secret was issued).
		if ( empty( $auth->get_webhook_secret() ) ) {
			return;
		}

		WPCode_Notice::info(
			esc_html__( 'Your WPCode Library connection can now authorize deploys with a hardware-backed passkey. Reconnect to the WPCode Library to enable passkey-secured deploys — reconnecting is also how you manage the passkeys allowed to deploy to this site.', 'wpcode-premium' ),
			array(
				'slug'    => 'wpcode_passkey_reconnect',
				'dismiss' => WPCode_Notice::DISMISS_GLOBAL,
			)
		);
	}

	/**
	 * Separate method for ajax handlers that can optionally not be inherited
	 *
	 * @return void
	 */
	protected function ajax_hooks() {
		// Ajax handlers.
		add_action( 'wp_ajax_wpcode_save_to_cloud', array( $this, 'save_snippet_handler' ) );
		add_action( 'wp_ajax_wpcode_my_library_delete_snippet', array( $this, 'delete_snippet_handler' ) );
	}

	/**
	 * Adds hooks for receiving requests from the library.
	 *
	 * @return void
	 */
	protected function push_hooks() {
		add_action( 'plugins_loaded', array( $this, 'maybe_receive_request' ), 0 );
	}

	/**
	 * Check if the request is an AJAX request for updating snippets from the library.
	 *
	 * @return void
	 */
	public function maybe_receive_request() {
		if ( ! wp_doing_ajax() || ! isset( $_GET['wpcode_library'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$route = sanitize_key( $_GET['wpcode_library'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'push' === $route ) {
			// Don't execute any snippet when we execute the logic for updating snippets from the library.
			add_filter( 'wpcode_do_auto_insert', '__return_false' );
			add_action( 'wp_ajax_nopriv_wpcode_update_from_library', array( $this, 'update_from_library' ) );
		} elseif ( 'nonce' === $route ) {
			// Single-use preflight nonce for passkey deploys.
			add_filter( 'wpcode_do_auto_insert', '__return_false' );
			add_action( 'wp_ajax_nopriv_wpcode_library_deploy_nonce', array( $this, 'deploy_nonce_endpoint' ) );
		}
	}

	/**
	 * Endpoint: issue a fresh single-use deploy nonce to the library.
	 *
	 * Unauthenticated by design (the nonce is worthless without a passkey
	 * signature), but only passkey connections issue one, and only over POST.
	 *
	 * @return void
	 */
	public function deploy_nonce_endpoint() {
		// Every failure mode returns the same generic response so an
		// unauthenticated probe cannot fingerprint how (or whether) this site
		// is connected for passkey deploys.
		if ( empty( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request', 'wpcode-premium' ) ) );
		}

		if ( ! wpcode()->library_auth->requires_passkey() ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request', 'wpcode-premium' ) ) );
		}

		// Rate limit after the connection check so probes against sites without
		// passkey deploys write nothing at all.
		if ( ! $this->deploy_nonce_rate_limit_allows() ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request', 'wpcode-premium' ) ) );
		}

		wp_send_json_success(
			array(
				'nonce'   => $this->issue_deploy_nonce(),
				'expires' => time() + self::DEPLOY_NONCE_TTL,
			)
		);
	}

	/**
	 * Bounded per-IP rate limiter for the unauthenticated nonce endpoint, so
	 * it cannot be used to flood the options table with nonce transients.
	 *
	 * @return bool True when this request is within the rate limit.
	 */
	protected function deploy_nonce_rate_limit_allows() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		$key   = self::DEPLOY_NONCE_RATE_PREFIX . md5( $ip );
		$count = (int) get_transient( $key );

		if ( $count >= self::DEPLOY_NONCE_RATE_LIMIT ) {
			return false;
		}

		// Not atomic, but a small overshoot is harmless here - the goal is
		// bounding transient writes, not exact counting.
		set_transient( $key, $count + 1, self::DEPLOY_NONCE_RATE_WINDOW );

		return true;
	}

	/**
	 * Listener to trigger an update from the library based on the request.
	 *
	 * @return void
	 */
	public function update_from_library() {
		// Let's drop it if not a POST request.
		if ( empty( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
			wp_send_json_error(
				array(
					'message' => __( 'Invalid request', 'wpcode-premium' ),
				)
			);
		}

		$snippet_id = isset( $_REQUEST['snippet_id'] ) ? sanitize_key( $_REQUEST['snippet_id'] ) : ''; // phpcs:ignore
		$unique_id  = isset( $_POST['t'] ) ? sanitize_key( $_POST['t'] ) : ''; // Unique id of this request.

		if ( empty( $snippet_id ) || empty( $unique_id ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Missing authorization data', 'wpcode-premium' ),
				)
			);
		}

		// Remote-only mode accepts passkey-approved deploys only: the legacy HMAC
		// secret is stored in this site's own options, so it cannot authorize
		// changes against a compromised local admin.
		if ( WPCode_Access::remote_only() && ! wpcode()->library_auth->requires_passkey() ) {
			wp_send_json_error(
				array(
					'message' => __( 'This site only accepts passkey-approved deploys. Remove WPCODE_REMOTE_ONLY from wp-config.php, reconnect the site to the WPCode Library with a passkey-enabled connection, then add it back.', 'wpcode-premium' ),
				)
			);
		}

		// The stored connection mode is authoritative for which verification
		// runs below; the pushed auth_mode is only consulted to surface an
		// actionable message when the library and this site disagree about the
		// connection (e.g. a failed store or a reconnect in another tab).
		$pushed_auth_mode = isset( $_POST['auth_mode'] ) ? sanitize_key( $_POST['auth_mode'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nopriv endpoint authorized by HMAC/assertion below; auth_mode only selects an error message.

		if ( 'passkey' === $pushed_auth_mode && ! wpcode()->library_auth->requires_passkey() ) {
			wp_send_json_error(
				array(
					'message' => __( 'The library connection stored on this site does not support passkey deploys. Reconnect this site to the WPCode Library and try again.', 'wpcode-premium' ),
				)
			);
		}

		// The verified target this deploy was approved for (passkey path only).
		$verified_target = array();
		// The deploy's activation choice for this site; null when the library
		// sent none, in which case the snippet's current state is left alone.
		$deploy_active = null;

		if ( wpcode()->library_auth->requires_passkey() ) {
			// Passkey connection: authorize with a live WebAuthn assertion,
			// verified before any snippet write. Never falls back to HMAC.
			$verified = $this->verify_deploy_assertion( $snippet_id );

			if ( is_wp_error( $verified ) ) {
				wp_send_json_error(
					array(
						'message' => $verified->get_error_message(),
					)
				);
			}

			$verified_target = $verified;

			// Covered by the passkey approval: the flag is part of the signed
			// target list, so it cannot be altered after the user approved it.
			if ( isset( $verified_target['active'] ) ) {
				$deploy_active = (bool) $verified_target['active'];
			}
		} else {
			// Legacy HMAC connection - unchanged.
			$auth_key = isset( $_REQUEST['auth_key'] ) ? sanitize_key( $_REQUEST['auth_key'] ) : ''; // phpcs:ignore

			if ( empty( $auth_key ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Missing authorization data', 'wpcode-premium' ),
					)
				);
			}

			$signed_data = wpcode()->library_auth->sign( $snippet_id . $unique_id );
			// Check if the request is legit.
			if ( empty( $signed_data ) || ! hash_equals( $signed_data, $auth_key ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'Invalid authorization data', 'wpcode-premium' ),
					)
				);
			}

			if ( isset( $_POST['active'] ) && in_array( wp_unslash( $_POST['active'] ), array( '0', '1' ), true ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nopriv endpoint authorized by the HMAC signature above; validated against a whitelist.
				$deploy_active = '1' === wp_unslash( $_POST['active'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated above.
			}
		}

		// Let's update the library now.
		$this->get_from_server();

		// Let's find the snippet on the site and update it or create a new snippet if it doesn't exist.
		$cloud_snippet = $this->grab_snippet_from_api( $snippet_id );

		if ( false === $cloud_snippet ) {
			wp_send_json_error(
				array(
					'message'    => __( 'Loading new snippets timed out, please try again.', 'wpcode-premium' ),
					'snippet_id' => $snippet_id,
				)
			);
		}

		// Content integrity: the passkey signed a hash of the snippet code, so
		// the code we just fetched must match what the user approved before it
		// is written. Only enforced when the library supplied a code_hash, so
		// older connections keep working.
		if ( ! empty( $verified_target['code_hash'] ) ) {
			// The library serves the code wp_slash()ed, so unslash before hashing
			// to match the library's hash of the same unslashed served code.
			$fetched_code = isset( $cloud_snippet['code'] ) ? (string) wp_unslash( $cloud_snippet['code'] ) : '';
			if ( ! hash_equals( (string) $verified_target['code_hash'], hash( 'sha256', $fetched_code ) ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'The snippet content did not match what you approved, so the deploy was cancelled. Please try again.', 'wpcode-premium' ),
					)
				);
			}
		}

		// Revocation: get_from_server() just fetched the library's current active
		// passkey hashes over our own authenticated connection. If the passkey
		// that signed this deploy is no longer in that list, it was removed from
		// the account - reject even though our stored snapshot still trusts it.
		// Enforced only when the library supplied the list (older libraries omit
		// it); an empty list means no active passkeys, so nothing may deploy.
		$library_data = $this->get_data();
		if ( is_array( $library_data ) && isset( $library_data['active_key_hashes'] ) && is_array( $library_data['active_key_hashes'] ) && ! empty( $verified_target['signing_key_hash'] ) ) {
			if ( ! in_array( $verified_target['signing_key_hash'], $library_data['active_key_hashes'], true ) ) {
				wp_send_json_error(
					array(
						'message' => __( 'This passkey has been removed from your account, so the deploy was cancelled. Deploy again with one of your current passkeys.', 'wpcode-premium' ),
					)
				);
			}
		}

		$local_snippets = wpcode()->my_library->get_used_library_snippets();

		// A site managing snippets from files does not take file-type code from the library.
		$refusal = WPCode_Snippets_From_Files::library_deploy_refusal( $cloud_snippet, isset( $local_snippets[ $snippet_id ] ) ? (int) $local_snippets[ $snippet_id ] : 0 );
		if ( '' !== $refusal ) {
			wp_send_json_error( array( 'message' => $refusal ) );
		}

		kses_remove_filters();

		// The deploy request was already authenticated above (HMAC signature or
		// WebAuthn assertion), but it runs on the nopriv endpoint with no
		// logged-in user. WPCode gates snippet writes on wpcode_edit_snippets and
		// status changes on wpcode_activate_snippets, so grant just those two caps
		// for the duration of this deploy write and remove them immediately after.
		$grant_deploy_caps = static function ( $allcaps ) {
			$allcaps['wpcode_edit_snippets']     = true;
			$allcaps['wpcode_activate_snippets'] = true;

			return $allcaps;
		};
		add_filter( 'user_has_cap', $grant_deploy_caps );

		if ( isset( $local_snippets[ $snippet_id ] ) ) {
			// Let's see if this unique_id has been used already using the remote_id_exists method in the revisions instance.
			if ( wpcode()->revisions->remote_id_exists( $local_snippets[ $snippet_id ], $unique_id ) ) {
				wp_send_json_success(
					array(
						'message' => __( 'Snippet already updated.', 'wpcode-premium' ),
					)
				);
			}
			$cloud_snippet['id'] = $local_snippets[ $snippet_id ];
			$snippet             = wpcode_get_snippet( $cloud_snippet );
			wpcode()->revisions->set_remote_id( $unique_id );
			// Save the snippet.
			$snippet->save();
			// Keep the stored snippet version in sync. The create path records this
			// via create_snippet_from_data(); without it here, a re-pushed snippet
			// keeps its old version and the site shows a false "Update available"
			// even though it just received the current version.
			if ( ! empty( $cloud_snippet['version'] ) ) {
				update_post_meta( $local_snippets[ $snippet_id ], '_wpcode_snippet_version', $cloud_snippet['version'] );
			}
		} else {
			wpcode()->revisions->set_remote_id( $unique_id );
			$created_snippet = wpcode()->my_library->create_new_snippet( $snippet_id );
		}

		// Apply the deploy's activation choice on the stored snippet. Reloading
		// from the database matters: the activation check executes the code, and
		// the in-memory deploy payload is still wp_slash()ed (the library serves
		// it slashed for wp_insert_post), so evaluating it directly false-fails
		// with a parse error on any code containing quotes.
		$activation_note   = '';
		$activation_failed = false;
		if ( null !== $deploy_active ) {
			$deployed_post_id = 0;
			if ( isset( $local_snippets[ $snippet_id ] ) ) {
				$deployed_post_id = $local_snippets[ $snippet_id ];
			} elseif ( isset( $created_snippet ) && is_object( $created_snippet ) ) {
				$deployed_post_id = $created_snippet->get_id();
			}
			if ( $deployed_post_id ) {
				$stored_snippet = wpcode_get_snippet( $deployed_post_id );
				if ( $deploy_active ) {
					$stored_snippet->activate();
					if ( 'publish' !== get_post_status( $deployed_post_id ) ) {
						$activation_failed = true;
						$activation_note   = ' ' . __( 'It could not be activated because running its code caused an error; fix the snippet in your library and deploy it again.', 'wpcode-premium' );
					}
				} else {
					$stored_snippet->deactivate();
				}
			}
		}

		remove_filter( 'user_has_cap', $grant_deploy_caps );

		$response = array(
			'message' => __( 'Snippet updated.', 'wpcode-premium' ) . $activation_note,
		);
		// Lets the library flag the deploy row without parsing the translated note.
		if ( $activation_failed ) {
			$response['activated'] = false;
		}

		wp_send_json_success( $response );
	}

	/**
	 * Issue a fresh single-use deploy nonce and remember it for later
	 * consumption during assertion verification.
	 *
	 * @return string The nonce value.
	 */
	public function issue_deploy_nonce() {
		$nonce = bin2hex( random_bytes( 32 ) );

		set_transient( self::DEPLOY_NONCE_PREFIX . $nonce, 1, self::DEPLOY_NONCE_TTL );

		return $nonce;
	}

	/**
	 * Check that a deploy nonce was issued by this site and is still unused,
	 * without consuming it.
	 *
	 * @param string $nonce The nonce presented in the deploy target.
	 *
	 * @return bool
	 */
	protected function deploy_nonce_is_valid( $nonce ) {
		if ( '' === (string) $nonce ) {
			return false;
		}

		return false !== get_transient( self::DEPLOY_NONCE_PREFIX . $nonce );
	}

	/**
	 * Consume a deploy nonce exactly once.
	 *
	 * The delete return value is the claim: of two concurrent requests
	 * presenting the same nonce, only one can see the underlying transient
	 * deleted and win.
	 *
	 * @param string $nonce The nonce presented in the deploy target.
	 *
	 * @return bool True if this request consumed the nonce.
	 */
	protected function consume_deploy_nonce( $nonce ) {
		if ( ! $this->deploy_nonce_is_valid( $nonce ) ) {
			return false;
		}

		return delete_transient( self::DEPLOY_NONCE_PREFIX . $nonce );
	}

	/**
	 * Verify the passkey assertion for a push before any snippet is written.
	 *
	 * Reconstructs the batch challenge from the raw forwarded target list,
	 * locates this site's own target, consumes its single-use nonce, and
	 * verifies the assertion against the stored public key for the presented
	 * credential. On success the credential's sign count is persisted.
	 *
	 * @param string $snippet_id The hashed snippet id being pushed.
	 *
	 * @return array|WP_Error The verified target (incl. its code_hash) when
	 *                        verified, WP_Error otherwise.
	 */
	protected function verify_deploy_assertion( $snippet_id ) {
		if ( ! class_exists( 'WPCode_WebAuthn_Verifier' ) ) {
			return new WP_Error( 'wpcode_passkey_unavailable', __( 'Passkey verification is unavailable on this site.', 'wpcode-premium' ) );
		}

		// The assertion blobs are base64url; validate the charset before decoding.
		$credential_id      = $this->get_base64url_request_value( 'credential_id' );
		$authenticator_data = $this->get_base64url_request_value( 'authenticator_data' );
		$client_data_json   = $this->get_base64url_request_value( 'client_data_json' );
		$signature          = $this->get_base64url_request_value( 'signature' );
		// The target list is hashed as raw bytes, so read it unmodified (only
		// unslashed) - re-encoding it would change the challenge.
		$targets_json = isset( $_POST['targets'] ) ? wp_unslash( $_POST['targets'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- nopriv endpoint authorized by the assertion; targets are hashed as opaque bytes, not rendered or stored.

		if ( '' === $credential_id || '' === $authenticator_data || '' === $client_data_json || '' === $signature || ! is_string( $targets_json ) || '' === $targets_json ) {
			return new WP_Error( 'wpcode_passkey_missing', __( 'This site requires passkey approval. Deploy again and approve when prompted, or reconnect the site to your library account.', 'wpcode-premium' ) );
		}

		$targets = json_decode( $targets_json, true );
		if ( ! is_array( $targets ) ) {
			return new WP_Error( 'wpcode_passkey_targets', __( 'Invalid deploy targets.', 'wpcode-premium' ) );
		}

		// Find this site's own target by the client id assigned at connect.
		// Bail on an empty client id so target-matching fails closed: an empty
		// value would hash_equals-match an attacker-supplied empty client_id.
		$client_id = wpcode()->library_auth->get_client_id();
		if ( '' === (string) $client_id ) {
			return new WP_Error( 'wpcode_passkey_client', __( 'This site is not fully connected for passkey deploys.', 'wpcode-premium' ) );
		}

		$target = null;
		foreach ( $targets as $candidate ) {
			if ( isset( $candidate['client_id'] ) && hash_equals( (string) $client_id, (string) $candidate['client_id'] ) ) {
				$target = $candidate;
				break;
			}
		}

		if ( null === $target ) {
			return new WP_Error( 'wpcode_passkey_no_target', __( 'This deploy was not authorized for this site.', 'wpcode-premium' ) );
		}

		// The signed snippet must be the one this request is installing.
		if ( ! isset( $target['snippet_hash'] ) || ! hash_equals( (string) $target['snippet_hash'], (string) $snippet_id ) ) {
			return new WP_Error( 'wpcode_passkey_snippet', __( 'The approved snippet does not match this request.', 'wpcode-premium' ) );
		}

		// The nonce must have been issued here and still be unused. It is only
		// consumed after the assertion signature verifies, so a request with a
		// forged signature cannot burn a legitimate deploy's nonce.
		if ( empty( $target['nonce'] ) || ! $this->deploy_nonce_is_valid( $target['nonce'] ) ) {
			return new WP_Error( 'wpcode_passkey_nonce', __( 'This deploy request has expired, please try again.', 'wpcode-premium' ) );
		}

		$stored_key = wpcode()->library_auth->get_public_key_by_credential_id( $credential_id );
		if ( null === $stored_key || empty( $stored_key['public_key'] ) ) {
			return new WP_Error( 'wpcode_passkey_credential', __( 'This passkey is not authorized to deploy to this site. If it was added to your library account recently, reconnect this site to the WPCode Library to sync your passkeys.', 'wpcode-premium' ) );
		}

		// The challenge the browser signed is the SHA-256 of the exact target
		// bytes we received; recompute over those raw bytes.
		$expected_challenge = hash( 'sha256', $targets_json, true );

		try {
			$cose_key = WPCode_WebAuthn_Verifier::cbor_decode( WPCode_WebAuthn_Verifier::base64url_decode( $stored_key['public_key'] ) );

			// Pin the verification algorithm independently of the stored COSE
			// blob: prefer the algorithm recorded at connect, and in all cases
			// allow only the two algorithms this verifier supports.
			$algorithm = isset( $stored_key['alg'] ) && null !== $stored_key['alg']
				? (int) $stored_key['alg']
				: ( isset( $cose_key[3] ) && is_int( $cose_key[3] ) ? $cose_key[3] : 0 );

			if ( ! in_array( $algorithm, array( WPCode_WebAuthn_Verifier::COSE_ALG_ES256, WPCode_WebAuthn_Verifier::COSE_ALG_RS256 ), true ) ) {
				return new WP_Error( 'wpcode_passkey_algorithm', __( 'This passkey uses an unsupported algorithm.', 'wpcode-premium' ) );
			}

			$result = WPCode_WebAuthn_Verifier::verify_assertion(
				array(
					'credential_public_key'     => $cose_key,
					'authenticator_data'        => WPCode_WebAuthn_Verifier::base64url_decode( $authenticator_data ),
					'client_data_json'          => WPCode_WebAuthn_Verifier::base64url_decode( $client_data_json ),
					'signature'                 => WPCode_WebAuthn_Verifier::base64url_decode( $signature ),
					'expected_challenge'        => $expected_challenge,
					'expected_rp_id'            => wpcode()->library_auth->get_rp_id(),
					'expected_origin'           => wpcode()->library_auth->get_expected_origin(),
					'require_user_verification' => true,
					'previous_sign_count'       => isset( $stored_key['sign_count'] ) ? (int) $stored_key['sign_count'] : 0,
					'expected_algorithm'        => $algorithm,
				)
			);
		} catch ( Exception $e ) {
			return new WP_Error( 'wpcode_passkey_verify', __( 'Passkey verification failed.', 'wpcode-premium' ) );
		}

		// Consume the nonce exactly once, now that the assertion has verified.
		// A false return means a concurrent request already claimed it, so this
		// one is a replay and must fail.
		if ( ! $this->consume_deploy_nonce( $target['nonce'] ) ) {
			return new WP_Error( 'wpcode_passkey_nonce', __( 'This deploy request has expired, please try again.', 'wpcode-premium' ) );
		}

		// Persist the increased sign count for clone detection next time.
		wpcode()->library_auth->update_sign_count( $credential_id, $result['sign_count'] );

		// Expose the signing key's hash so the caller can confirm, against the
		// library's fresh active-key list, that this passkey has not been removed.
		$target['signing_key_hash'] = hash( 'sha256', (string) $stored_key['public_key'] );

		// Return the verified target so the caller can enforce content integrity
		// (its code_hash) and revocation (its signing_key_hash) before saving.
		return $target;
	}

	/**
	 * Read a base64url-encoded request value, returning an empty string if it
	 * is missing or contains characters outside the base64url alphabet.
	 *
	 * @param string $key The request key.
	 *
	 * @return string
	 */
	protected function get_base64url_request_value( $key ) {
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- request auth is the assertion itself, verified by the caller.
			return '';
		}

		$value = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- validated against the base64url charset below.

		if ( ! is_string( $value ) || '' === $value || strlen( $value ) > 8192 ) {
			return '';
		}

		return preg_match( '/^[A-Za-z0-9_-]+$/', $value ) ? $value : '';
	}

	/**
	 * Get the editor base URL. Used for pointing user to the page to edit their snippets.
	 *
	 * @return string
	 */
	public function get_editor_url() {
		return trailingslashit( wpcode()->library_auth->library_url ) . 'editor/';
	}

	/**
	 * Save a snippet to the user's cloud.
	 *
	 * @param int|WPCode_Snippet $snippet The snippet to save.
	 *
	 * @return bool
	 */
	public function save_snippet_to_cloud( $snippet ) {
		if ( ! $snippet instanceof WPCode_Snippet ) {
			$snippet = wpcode_get_snippet( $snippet );
		}

		$data = $snippet->get_data_for_caching();

		$data['cloud_id']         = $snippet->get_cloud_id();
		$data['tags']             = $snippet->get_tags();
		$data['note']             = $snippet->get_note();
		$data['custom_shortcode'] = $snippet->get_custom_shortcode();

		// Get current snippet_version.
		$current_snippet_version = get_post_meta( $snippet->get_id(), '_wpcode_snippet_version', true );

		// If no snippet_version exists, set default to 1.0.0.
		if ( empty( $current_snippet_version ) ) {
			$current_snippet_version = '1.0.0';
		}

		// Increment the snippet_version (1.0.0 -> 1.0.1).
		$version_parts = explode( '.', $current_snippet_version );
		if ( count( $version_parts ) === 3 ) {
			$version_parts[2]    = intval( $version_parts[2] ) + 1;
			$new_snippet_version = implode( '.', $version_parts );

			// Update the snippet version in the database.
			update_post_meta( $snippet->get_id(), '_wpcode_snippet_version', $new_snippet_version );
		}

		if ( 'blocks' === $snippet->get_code_type() ) {
			$data['code'] = wpcode()->snippet_block_editor->get_blocks_content( $snippet );
		}

		// Let's check if the cloud id is still relevant.
		if ( false === $this->grab_snippet_from_api( $data['cloud_id'] ) ) {
			// If we can't find the snippet don't send a cloud id so it gets saved as a new snippet.
			unset( $data['cloud_id'] );
		}

		$request = $this->make_request(
			'snippet/save',
			'POST',
			array(
				'snippet' => $data,
			)
		);

		$response = json_decode( $request, true );

		if ( ! empty( $response['status'] ) && ! empty( $response['data'] ) && ! empty( $response['data']['cloud_id'] ) ) {
			$snippet->set_cloud_id( $response['data']['cloud_id'] );
			$snippet->save();

			$this->delete_cache();
			$this->clear_used_snippets();
		}

		return isset( $response['status'] ) && 'success' === $response['status'];
	}

	/**
	 * Delete a snippet from the library site.
	 *
	 * @param string $cloud_id The snippet id (hash).
	 *
	 * @return bool
	 */
	public function delete_cloud_snippet( $cloud_id ) {

		$request = $this->make_request(
			'snippet/' . $cloud_id,
			'DELETE'
		);

		$response = json_decode( $request );

		return isset( $response->status ) && 'success' === $response->status;
	}

	/**
	 * Grab a snippet data from the API.
	 *
	 * @param int $library_id The id of the snippet in the Library api.
	 *
	 * @return array|array[]|false
	 */
	public function grab_snippet_from_api( $library_id ) {
		$snippets      = $this->get_data();
		$cloud_snippet = array();

		if ( ! empty( $snippets['snippets'] ) ) {
			foreach ( $snippets['snippets'] as $snippet ) {
				if ( $library_id === $snippet['cloud_id'] ) {
					$cloud_snippet = $snippet;
					break;
				}
			}
		}

		return empty( $cloud_snippet ) ? false : $cloud_snippet;
	}

	/**
	 * Grab the library id from the snippet by snippet id.
	 *
	 * @param int $snippet_id The snippet id.
	 *
	 * @return int
	 */
	public function get_snippet_library_id( $snippet_id ) {
		$snippet = wpcode_get_snippet( $snippet_id );

		return $snippet->get_cloud_id();
	}

	/**
	 * Stamp the connected username on imported snippets so the badge can attribute them.
	 *
	 * @param int $library_id The cloud id of the snippet to import.
	 *
	 * @return false|WPCode_Snippet
	 */
	public function create_new_snippet( $library_id ) {
		$snippet = parent::create_new_snippet( $library_id );

		if ( $this->stamp_library_author && $snippet && $snippet->get_id() > 0 ) {
			$auth_username = wpcode()->library_auth->get_auth_username();
			if ( ! empty( $auth_username ) && empty( get_post_meta( $snippet->get_id(), '_wpcode_library_author', true ) ) ) {
				update_post_meta( $snippet->get_id(), '_wpcode_library_author', sanitize_key( $auth_username ) );
			}
		}

		return $snippet;
	}


	/**
	 * Ajax handler to save a snippet to the cloud.
	 *
	 * @return void
	 */
	public function save_snippet_handler() {
		check_ajax_referer( 'wpcode_admin' );

		if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { // phpcs:ignore
			// If they don't have this they shouldn't be able to load the snippet manager in the first place.
			wp_send_json_error(
				array(
					'title' => __( 'Not allowed', 'wpcode-premium' ),
					'text'  => __( 'You do not have permission to save snippets to the library.', 'wpcode-premium' ),
				)
			);
		}

		if ( ! wpcode()->library_auth->has_auth() ) {
			wp_send_json_error(
				array(
					'message' => __( 'You need to be authenticated to save snippets to the library.', 'wpcode-premium' ),
				)
			);
		}

		$snippet_id = isset( $_POST['snippet_id'] ) ? absint( $_POST['snippet_id'] ) : 0;

		if ( ! $snippet_id ) {
			wp_send_json_error(
				array(
					'message' => __( 'Snippet not found.', 'wpcode-premium' ),
				)
			);
		}

		// A file-managed snippet cannot store the cloud id the save returns.
		$refusal = WPCode_Snippets_From_Files::cloud_refusal( $snippet_id );
		if ( '' !== $refusal ) {
			wp_send_json_error( array( 'message' => $refusal ) );
		}

		if ( $this->save_snippet_to_cloud( $snippet_id ) ) {
			$snippet = wpcode_get_snippet( $snippet_id );
			wp_send_json_success(
				array(
					'title'    => __( 'Snippet saved to the library.', 'wpcode-premium' ),
					'message'  => '',
					'cloud_id' => $snippet->get_cloud_id(),
					'edit_url' => $this->get_editor_url() . $snippet->get_cloud_id(),
				)
			);
		}

		wp_send_json_error(
			array(
				'message' => __( 'Something went wrong. Please try again.', 'wpcode-premium' ),
			)
		);
	}

	/**
	 * Ajax handler for making a request to delete a snippet.
	 *
	 * @return void
	 */
	public function delete_snippet_handler() {
		check_ajax_referer( 'wpcode_admin' );

		if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { // phpcs:ignore
			// If they don't have this they shouldn't be able to load the snippet manager in the first place.
			wp_send_json_error(
				array(
					'title' => __( 'Not allowed', 'wpcode-premium' ),
					'text'  => __( 'You do not have permission to delete snippets from the library.', 'wpcode-premium' ),
				)
			);
		}

		$snippet_id = isset( $_POST['snippet_id'] ) ? absint( $_POST['snippet_id'] ) : false;
		$cloud_id   = isset( $_POST['cloud_id'] ) ? sanitize_key( $_POST['cloud_id'] ) : false;

		if ( ! $cloud_id ) {
			wp_send_json_error(
				array(
					'title' => __( 'Invalid snippet ID', 'wpcode-premium' ),
					'text'  => __( 'Missing parameter in the request, please reload the page and try again.', 'wpcode-premium' ),
				)
			);
		}

		// A file-managed snippet cannot clear its cloud id after the remote delete.
		$refusal = $snippet_id ? WPCode_Snippets_From_Files::cloud_refusal( $snippet_id ) : '';
		if ( '' !== $refusal ) {
			wp_send_json_error(
				array(
					'title' => __( 'Not available', 'wpcode-premium' ),
					'text'  => $refusal,
				)
			);
		}

		if ( $this->delete_cloud_snippet( $cloud_id ) ) {
			$this->delete_cache();
			if ( 0 !== $snippet_id ) {
				$snippet = new WPCode_Snippet( $snippet_id );
				$snippet->set_cloud_id( '' );
				$snippet->save();
			}
			wp_send_json_success();
		}

		wp_send_json_error(
			array(
				'title' => __( 'We encountered an error deleting the snippet', 'wpcode-premium' ),
				'text'  => __( 'The request to the Library site to delete the snippet has not been sucessful, please try again in a few minutes as this might be a temporary error.', 'wpcode-premium' ),
			)
		);
	}

	/**
	 * Get data from the options table.
	 *
	 * @param string $key The key to get the data for.
	 * @param int    $ttl The time to live for the cache similar to how we use it for the file cache for consistency.
	 *
	 * @return array|array[]|false|mixed
	 */
	public function get_from_cache( $key, $ttl = 0 ) {
		if ( empty( $ttl ) ) {
			$ttl = $this->ttl;
		}

		$key = $this->get_option_key( $key );

		$data = get_option( $key, false );

		if ( ! isset( $data['data'] ) || isset( $data['time'] ) && $data['time'] + $ttl < time() ) {
			return false;
		}

		if ( isset( $data['data']['error'] ) && isset( $data['data']['time'] ) ) {
			if ( $data['data']['time'] + 10 * MINUTE_IN_SECONDS < time() ) {
				return false;
			} else {
				return $this->get_empty_array();
			}
		}

		return $data['data'];
	}

	/**
	 * Delete the cache.
	 *
	 * @return void
	 */
	public function delete_cache() {
		$key = $this->get_option_key( $this->cache_key );

		delete_option( $key );
	}

	/**
	 * Refresh the library cache.
	 * This method handles the common logic for refreshing the library cache.
	 *
	 * @return bool True if the cache was refreshed, false otherwise.
	 */
	public function refresh_library_cache() {
		// Check rate limiting - only allow 1 refresh per minute.
		$last_update = get_transient( 'wpcode_library_cache_last_update' );
		if ( false !== $last_update ) {
			$time_diff = time() - $last_update;
			if ( $time_diff < 60 ) { // Less than 1 minute.
				return false;
			}
		}

		// Delete the cache.
		$this->delete_cache();

		// Set transient to track when the cache was last refreshed.
		set_transient( 'wpcode_library_cache_last_update', time(), HOUR_IN_SECONDS );

		return true;
	}

	/**
	 * Save to the db for this library type.
	 *
	 * @param string $key The key to save the data under.
	 * @param array  $data The data to save.
	 *
	 * @return void
	 */
	public function save_to_cache( $key, $data ) {
		$key = $this->get_option_key( $key );

		$save_data = array(
			'data' => $data,
			'time' => time(),
		);

		update_option( $key, $save_data, false );
	}

	/**
	 * Get the key to an option in the db using a prefix.
	 *
	 * @param string $key The key to grab data for.
	 *
	 * @return string
	 */
	public function get_option_key( $key ) {
		return 'wpcode_' . $key;
	}

	/**
	 * Get all the snippets that were created from the cloud library, by cloud ID.
	 * Results are cached in a transient.
	 *
	 * @return array
	 */
	public function get_used_library_snippets() {
		if ( isset( $this->library_snippets ) ) {
			return $this->library_snippets;
		}

		$snippets_from_library = get_transient( $this->used_snippets_transient_key );

		if ( false === $snippets_from_library ) {
			$snippets_from_library = array();

			$args     = array(
				'post_type'   => wpcode_get_post_type(),
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => $this->snippet_library_id_meta_key,
						'compare' => 'EXISTS',
					),
				),
				'fields'      => 'ids',
				'post_status' => 'any',
				'nopaging'    => true,
			);
			$snippets = get_posts( $args );

			foreach ( $snippets as $snippet_id ) {
				$snippets_from_library[ $this->get_snippet_library_id( $snippet_id ) ] = $snippet_id;
			}

			set_transient( $this->used_snippets_transient_key, $snippets_from_library );
		}

		$this->library_snippets = $snippets_from_library;

		return $this->library_snippets;
	}

	/**
	 * Check if a snippet has an update available by comparing with cached data.
	 *
	 * @param int    $snippet_id The snippet ID.
	 * @param string $cloud_id The cloud ID.
	 * @param bool   $is_cloud Whether this is a cloud snippet.
	 *
	 * @return bool|array False if no update, array with version info if update available.
	 */
	public function check_snippet_update( $snippet_id, $cloud_id, $is_cloud = true ) {
		// Get current version from post meta.
		$current_version = get_post_meta( $snippet_id, '_wpcode_snippet_version', true );

		// Get latest version from cache.
		// For cloud snippets, get from my_library cache.
		$cached_data   = $this->get_data();
		$cloud_snippet = null;

		if ( ! empty( $cached_data['snippets'] ) ) {
			foreach ( $cached_data['snippets'] as $snippet ) {
				if ( $cloud_id === $snippet['cloud_id'] ) {
					$cloud_snippet = $snippet;
					break;
				}
			}
		}

		if ( ! $cloud_snippet || empty( $cloud_snippet['version'] ) ) {
			return false;
		}

		$latest_version = $cloud_snippet['version'];

		// If either version is empty, set it to 1.0.0.
		if ( empty( $current_version ) ) {
			$current_version = '1.0.0';
		}

		if ( empty( $latest_version ) ) {
			$latest_version = '1.0.0';
		}

		// If latest version is greater than current version, update is available.
		if ( version_compare( $latest_version, $current_version, '>' ) ) {
			return array(
				'current_version' => $current_version,
				'latest_version'  => $latest_version,
				'is_cloud'        => true,
			);
		}

		return false;
	}

	/**
	 * Get the list of snippets that have updates available.
	 * Checks on the fly using cached data.
	 *
	 * @return array
	 */
	public function get_snippets_with_updates() {
		// Get all snippets with cloud IDs.
		$cloud_snippets = $this->get_used_library_snippets();

		$snippets_with_updates = array();

		// Check cloud snippets.
		foreach ( $cloud_snippets as $cloud_id => $snippet_id ) {
			$update_info = $this->check_snippet_update( $snippet_id, $cloud_id );
			if ( $update_info ) {
				$snippets_with_updates[] = $snippet_id;
			}
		}

		return $snippets_with_updates;
	}

	/**
	 * Add cloud snippets to the list of snippets with updates.
	 *
	 * @param array $snippets_with_updates The list of snippets with updates.
	 *
	 * @return array
	 */
	public function add_cloud_snippets_with_updates( $snippets_with_updates ) {
		// Get cloud snippets with updates.
		$cloud_snippets_with_updates = $this->get_snippets_with_updates();

		// Merge with existing snippets with updates.
		return array_merge( $snippets_with_updates, $cloud_snippets_with_updates );
	}

	/**
	 * Update a snippet from the cloud library.
	 *
	 * @param int    $snippet_id The ID of the snippet to update.
	 * @param string $cloud_id The ID of the cloud snippet to fetch.
	 *
	 * @return array|false Array with success data or false on failure.
	 */
	public function update_snippet_from_library( $snippet_id, $cloud_id ) {
		// Get snippet data from cloud library.
		$cloud_snippet = $this->grab_snippet_from_api( $cloud_id );

		if ( ! $cloud_snippet ) {
			return false;
		}

		// Update snippet.
		$cloud_snippet['id'] = $snippet_id;
		$snippet             = wpcode_get_snippet( $cloud_snippet );
		$result              = $snippet->save();

		if ( ! $result ) {
			return false;
		}

		// Update local version metadata.
		if ( ! empty( $cloud_snippet['version'] ) ) {
			update_post_meta( $snippet_id, '_wpcode_snippet_version', $cloud_snippet['version'] );
		}

		return array(
			'success' => true,
			'version' => ! empty( $cloud_snippet['version'] ) ? $cloud_snippet['version'] : '',
		);
	}
}
