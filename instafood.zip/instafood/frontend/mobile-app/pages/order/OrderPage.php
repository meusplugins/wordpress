<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../IAppetitPage.php');

class OrderPage implements IAppetitPage {

    public function render(): void {
        ?>
        <section id="apt_order_screen" class="apt-page apt-page-full no-scroll hide screen_with_both_navs">
            <?php $this->renderHeader() ?>
            <?php $this->renderContentContent() ?>
            <?php $this->renderFooter() ?>
        </section>
        <?php
    }

    private function renderHeader(): void {
        ?>
        <div class="both_nav_apt_top_nav"></div>
        <?php
    }

    private function renderContentContent(): void {
        ?>
        <div class="both_nav_apt_content_ui"></div>
        <?php
    }

    private function renderFooter(): void {
        ?>
        <div class="both_nav_apt_nav_bottom"></div>
        <?php
    }
}
?>