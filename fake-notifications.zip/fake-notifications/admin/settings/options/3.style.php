<?php

use HerdEffectsPro\Settings_Helper;

defined( 'ABSPATH' ) || exit;

return [
	//region Location
	'herd_top' => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Top', 'wow-herd-effects-pro' ),
			'name'   => 'include_herd_top',
			'toggle' => true,
			'val'    => 1
		],
		'val'   => '10',
		'atts'  => [
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'herd_top_unit',
			'val'  => '%',
			'atts' => [
				'%'  => __( '%', 'wow-herd-effects-pro' ),
				'px' => __( 'px', 'wow-herd-effects-pro' ),
			],
		],
	],

	'herd_bottom' => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Bottom', 'wow-herd-effects-pro' ),
			'name'   => 'include_herd_bottom',
			'toggle' => true,
			'val'    => 0
		],
		'val'   => '10',
		'atts'  => [
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'herd_bottom_unit',
			'val'  => '%',
			'atts' => [
				'%'  => __( '%', 'wow-herd-effects-pro' ),
				'px' => __( 'px', 'wow-herd-effects-pro' ),
			],
		],
	],

	'herd_left' => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Left', 'wow-herd-effects-pro' ),
			'name'   => 'include_herd_left',
			'toggle' => true,
			'val'    => 0
		],
		'val'   => '10',
		'atts'  => [
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'herd_left_unit',
			'val'  => '%',
			'atts' => [
				'%'  => __( '%', 'wow-herd-effects-pro' ),
				'px' => __( 'px', 'wow-herd-effects-pro' ),
			],
		],
	],

	'herd_right' => [
		'type'  => 'number',
		'title' => [
			'label'  => __( 'Right', 'wow-herd-effects-pro' ),
			'name'   => 'include_herd_right',
			'toggle' => true,
			'val'    => 1
		],
		'val'   => '10',
		'atts'  => [
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'herd_right_unit',
			'val'  => '%',
			'atts' => [
				'%'  => __( '%', 'wow-herd-effects-pro' ),
				'px' => __( 'px', 'wow-herd-effects-pro' ),
			],
		],
	],
	//endregion

	//region Title

	'title_size' => [
		'type'  => 'number',
		'title' => __( 'Font Size', 'wow-herd-effects-pro' ),
		'val'   => '18',
		'addon' => 'px',
		'atts'  => [
			'min' => 0,
		],
	],

	'title_line_height' => [
		'type'  => 'number',
		'title' => __( 'Line Height', 'wow-herd-effects-pro' ),
		'val'   => '32',
		'addon' => 'px',
		'atts'  => [
			'min' => 0,
		],
	],

	'title_font' => [
		'type'  => 'select',
		'title' => __( 'Font Family', 'wow-herd-effects-pro' ),
		'val'   => 'inherit',
		'atts'  => [
			'inherit'         => __( 'Use Your Themes', 'wow-herd-effects-pro' ),
			'Tahoma'          => 'Tahoma',
			'Georgia'         => 'Georgia',
			'Comic Sans MS'   => 'Comic Sans MS',
			'Arial'           => 'Arial',
			'Lucida Grande'   => 'Lucida Grande',
			'Times New Roman' => 'Times New Roman',
		],
	],

	'title_font_weight' => [
		'type'  => 'select',
		'title' => __( 'Font Weight', 'wow-herd-effects-pro' ),
		'val'   => 'bolder',
		'atts'  => [
			'normal'  => 'Normal',
			'bold'    => 'Bold',
			'bolder'  => 'Bolder',
			'lighter' => 'Lighter',
		],
	],

	'title_font_style' => [
		'type'  => 'select',
		'title' => __( 'Font Style', 'wow-herd-effects-pro' ),
		'val'   => 'normal',
		'atts'  => [
			'normal' => 'Normal',
			'italic' => 'Italic',
		],
	],

	'title_align' => [
		'type'  => 'select',
		'title' => __( 'Align', 'wow-herd-effects-pro' ),
		'val'   => 'left',
		'atts'  => [
			'left'   => 'Left',
			'center' => 'Center',
			'right'  => 'Right',
		],
	],

	'title_color' => [
		'type'  => 'text',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'val'   => '#ffffff',
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	//endregion

	//region Content

	'content_width' => [
		'type'  => 'number',
		'title' => __( 'Block Width', 'wow-herd-effects-pro' ),
		'val'   => '200',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'content_width_unit',
			'val'  => 'px',
			'atts' => [
				'px' => __( 'px', 'wow-herd-effects-pro' ),
				'%' => __( '%', 'wow-herd-effects-pro' ),
			],
		],
	],

	'content_height' => [
		'type'  => 'number',
		'title' => __( 'Block Height', 'wow-herd-effects-pro' ),
		'val'   => '0',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => [
			'type' => 'select',
			'name' => 'content_height_unit',
			'val'  => 'auto',
			'atts' => [
				'auto' => __( 'auto', 'wow-herd-effects-pro' ),
				'px' => __( 'px', 'wow-herd-effects-pro' ),
			],
		],
	],

	'content_size' => [
		'type'  => 'number',
		'title' => __( 'Font Size', 'wow-herd-effects-pro' ),
		'addon' => 'px',
		'val'   => 14,
		'atts'  => [
			'min' => '0',
		],
	],

	'content_padding' => [
		'type'  => 'number',
		'title' => __( 'Padding', 'wow-herd-effects-pro' ),
		'val'   => '10',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'px'
	],

	'content_font'  => [
		'type'  => 'select',
		'title' => __( 'Font Family', 'wow-herd-effects-pro' ),
		'val'   => 'inherit',
		'atts'  => [
			'inherit'         => __( 'Use Your Themes', 'wow-herd-effects-pro' ),
			'Sans-Serif'      => 'Sans-Serif',
			'Tahoma'          => 'Tahoma',
			'Georgia'         => 'Georgia',
			'Comic Sans MS'   => 'Comic Sans MS',
			'Arial'           => 'Arial',
			'Lucida Grande'   => 'Lucida Grande',
			'Times New Roman' => 'Times New Roman',
		],
	],

	'content_line_height' => [
		'type'  => 'number',
		'title' => __( 'Line Height', 'wow-herd-effects-pro' ),
		'val'   => '18',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'px',
	],

	'bg_color' => [
		'type'  => 'text',
		'val'   => 'rgba(0,0,0,0.75)',
		'title' => __( 'Background', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	'text_color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Text color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],
	//endregion

	//region Icon
	'icon_width' => [
		'type'  => 'number',
		'title' => __( 'Block Width', 'wow-herd-effects-pro' ),
		'val'   => '60',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'px',
	],

	'icon_size' => [
		'type'  => 'number',
		'title' => __( 'Size', 'wow-herd-effects-pro' ),
		'val'   => '40',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'px',
	],

	'icon_background' => [
		'type'  => 'text',
		'val'   => 'rgba(0,0,0,0.75)',
		'title' => __( 'Background', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	'icon_color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	//endregion

	//region Close Button
	'show_close' => [
		'type'  => 'checkbox',
		'title' => __( 'Close Button', 'wow-herd-effects-pro' ),
		'label' => __( 'Enable', 'wow-herd-effects-pro' ),
	],

	'close_size' => [
		'type'  => 'number',
		'title' => __( 'Size', 'wow-herd-effects-pro' ),
		'val'   => '24',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'px',
	],

	'close_offset_x' => [
		'type'  => 'number',
		'title' => __( 'Offset Horizontal', 'wow-herd-effects-pro' ),
		'val'   => '5',
		'atts' => [
			'step' => 1,
		],
		'addon' => 'px',
	],

	'close_offset_y' => [
		'type'  => 'number',
		'title' => __( 'Offset Vertical', 'wow-herd-effects-pro' ),
		'val'   => '5',
		'atts' => [
			'step' => 1,
		],
		'addon' => 'px',
	],

	'close_color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	'close_h_color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Hover Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	//endregion

	//region Border
	'border_radius'  => [
		'type'  => 'number',
		'title' => __( 'Radius', 'wow-herd-effects-pro' ),
		'val'   => 5,
		'atts'  => [
			'min' => '0',
		],
		'addon' => 'px',
	],

	'border_style' => [
		'type'  => 'select',
		'title' => __( 'Style', 'wow-herd-effects-pro' ),
		'val'   => 'none',
		'atts'  => [
			'none'   => __( 'None', 'wow-herd-effects-pro' ),
			'solid'  => __( 'Solid', 'wow-herd-effects-pro' ),
			'dotted' => __( 'Dotted', 'wow-herd-effects-pro' ),
			'dashed' => __( 'Dashed', 'wow-herd-effects-pro' ),
			'double' => __( 'Double', 'wow-herd-effects-pro' ),
			'groove' => __( 'Groove', 'wow-herd-effects-pro' ),
			'inset'  => __( 'Inset', 'wow-herd-effects-pro' ),
			'outset' => __( 'Outset', 'wow-herd-effects-pro' ),
			'ridge'  => __( 'Ridge', 'wow-herd-effects-pro' ),
		],
	],

	'border_width' => [
		'type'  => 'number',
		'title' => __( 'Thickness', 'wow-herd-effects-pro' ),
		'val'   => 0,
		'atts'  => [
			'min' => '0',
		],
		'addon' => 'px',
	],

	'border_color' => [
		'type'  => 'text',
		'val'   => '#ffffff',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],

	//endregion

	//region Shadow
	'shadow'       => [
		'type'  => 'select',
		'title' => __( 'Shadow', 'wow-herd-effects-pro' ),
		'val'   => 'none',
		'atts'  => [
			'none'   => __( 'None', 'wow-herd-effects-pro' ),
			'outset' => __( 'Yes', 'wow-herd-effects-pro' ),
		],
	],

	'shadow_h_offset' => [
		'type'  => 'number',
		'title' => __( 'Horizontal Position', 'wow-herd-effects-pro' ),
		'addon' => 'px',
		'val'   => 0,
	],

	'shadow_v_offset' => [
		'type'  => 'number',
		'title' => __( 'Vertical Position', 'wow-herd-effects-pro' ),
		'addon' => 'px',
		'val'   => 0,
	],

	'shadow_blur' => [
		'type'  => 'number',
		'title' => __( 'Blur', 'wow-herd-effects-pro' ),
		'addon' => 'px',
		'val'   => 3,
	],

	'shadow_spread' => [
		'type'  => 'number',
		'title' => __( 'Spread', 'wow-herd-effects-pro' ),
		'addon' => 'px',
		'val'   => 0,
	],

	'shadow_color'  => [
		'type'  => 'text',
		'val'   => '#020202',
		'title' => __( 'Color', 'wow-herd-effects-pro' ),
		'atts'  => [
			'class'              => 'wpie-color',
			'data-alpha-enabled' => 'true',
		],
	],
	//endregion
];