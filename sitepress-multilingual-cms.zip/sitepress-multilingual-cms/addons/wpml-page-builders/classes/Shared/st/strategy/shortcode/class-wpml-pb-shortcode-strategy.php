<?php

use WPML\LIB\WP\Gutenberg;
use WPML\FP\Obj;

class WPML_PB_Shortcode_Strategy implements IWPML_PB_Strategy {

	private $shortcodes = [
		WPML_PB_Shortcode_Content_Wrapper::WRAPPER_SHORTCODE_NAME => [
			'encoding'           => '',
			'encoding-condition' => '',
			'type'               => '',
			'ignore-content'     => false,
			'attributes'         => [],
		],
	];

	private $factory;

	private $page_builder_settings;

	private $shortcodes_provider = null;

	public function __construct( WPML_Page_Builder_Settings $page_builder_settings ) {
		$this->page_builder_settings = $page_builder_settings;
	}

	public function set_shortcodes_provider( callable $provider ) {
		$this->shortcodes_provider = $provider;
	}

	private function ensure_shortcodes_loaded() {
		if ( null !== $this->shortcodes_provider ) {
			$provider                  = $this->shortcodes_provider;
			$this->shortcodes_provider = null;
			$this->add_shortcodes( (array) $provider() );
		}
	}

	public function add_shortcodes( $shortcode_data ) {

		foreach ( $shortcode_data as $shortcode ) {
			$tag         = $shortcode['tag']['value'];
			$is_raw_html = isset( $shortcode['tag']['raw-html'] ) && $shortcode['tag']['raw-html'];

			if ( $is_raw_html && ! $this->page_builder_settings->is_raw_html_translatable() ) {
				continue;
			}

			$tag_settings = [
				'encoding'           => $shortcode['tag']['encoding'],
				'encoding-condition' => isset( $shortcode['tag']['encoding-condition'] ) ? $shortcode['tag']['encoding-condition'] : '',
				'type'               => isset( $shortcode['tag']['type'] ) ? $shortcode['tag']['type'] : '',
				'ignore-content'     => isset( $shortcode['tag']['ignore-content'] ) ? (bool) $shortcode['tag']['ignore-content'] : false,
				'label'              => isset( $shortcode['tag']['label'] ) ? $shortcode['tag']['label'] : '',
			];

			if ( ! isset( $this->shortcodes[ $tag ] ) ) {
				$this->shortcodes[ $tag ] = $tag_settings + [ 'attributes' => [] ];
			} else {
				$this->shortcodes[ $tag ] = $this->merge_settings( $this->shortcodes[ $tag ], $tag_settings );
			}

			if ( isset( $shortcode['attributes'] ) ) {
				foreach ( $shortcode['attributes'] as $attribute ) {
					$name = $attribute['value'];

					$this->shortcodes[ $tag ]['attributes'][ $name ] = isset( $this->shortcodes[ $tag ]['attributes'][ $name ] )
						? $this->merge_settings( $this->shortcodes[ $tag ]['attributes'][ $name ], $attribute )
						: $attribute;
				}
			}
		}
	}

	private function merge_settings( array $earlier, array $later ) {
		foreach ( $later as $key => $value ) {
			if ( 'attributes' === $key ) {
				continue;
			}
			if ( ! isset( $earlier[ $key ] ) || ( '' !== $value && false !== $value && null !== $value ) ) {
				$earlier[ $key ] = $value;
			}
		}

		return $earlier;
	}

	public function get_shortcodes() {
		$this->ensure_shortcodes_loaded();
		return array_keys( $this->shortcodes );
	}

	public function get_shortcode_attributes( $tag ) {
		$this->ensure_shortcodes_loaded();
		return array_keys( $this->shortcodes[ $tag ]['attributes'] );
	}

	public function get_shortcode_tag_encoding( $tag ) {
		$this->ensure_shortcodes_loaded();
		return $this->shortcodes[ $tag ]['encoding'];
	}

	public function get_shortcode_tag_encoding_condition( $tag ) {
		$this->ensure_shortcodes_loaded();
		return $this->shortcodes[ $tag ]['encoding-condition'];
	}

	public function get_shortcode_tag_type( $tag ) {
		$this->ensure_shortcodes_loaded();
		if ( $this->shortcodes[ $tag ]['type'] ) {
			return strtoupper( $this->shortcodes[ $tag ]['type'] );
		}
		return 'VISUAL';
	}

	public function get_shortcode_ignore_content( $tag ) {
		$this->ensure_shortcodes_loaded();
		return $this->shortcodes[ $tag ]['ignore-content'];
	}

	public function get_shortcode_attribute_encoding( $tag, $attribute ) {
		$this->ensure_shortcodes_loaded();
		return $this->shortcodes[ $tag ]['attributes'][ $attribute ]['encoding'];
	}

	public function get_shortcode_attribute_type( $tag, $attribute ) {
		$this->ensure_shortcodes_loaded();
		if ( $this->shortcodes[ $tag ]['attributes'][ $attribute ]['type'] ) {
			return strtoupper( $this->shortcodes[ $tag ]['attributes'][ $attribute ]['type'] );
		}
		return 'LINE';
	}

	public function get_shortcode_attribute_label( $tag, $attribute ) {
		$this->ensure_shortcodes_loaded();
		$labelPath = 'content' === $attribute ? [ $tag, 'label' ] : [ $tag, 'attributes', $attribute, 'label' ];

		return Obj::pathOr( '', $labelPath, $this->shortcodes );
	}

	public function get_shortcode_parser() {
		return $this->factory->get_shortcode_parser( $this );
	}

	public function register_strings( $post ) {
		if ( Gutenberg::doesNotHaveBlock( $post->post_content ) ) {
			$this->register_strings_in_content( $post->ID, $post->post_content, null );
		}
	}

	public function register_strings_in_content( $post_id, $content, ?WPML\PB\Shortcode\StringCleanUp $stringCleanUp = null ) {
		$register_shortcodes = $this->factory->get_register_shortcodes( $this );

		return $register_shortcodes->register_shortcode_strings( $post_id, $content, $stringCleanUp );
	}

	public function set_factory( $factory ) {
		$this->factory = $factory;
	}

	public function get_package_key( $page_id ) {
		return array(
			'kind'    => $this->get_package_kind(),
			'name'    => $page_id,
			'title'   => 'Page Builder Page ' . $page_id . ': shortcodes',
			'post_id' => $page_id,
		);
	}

	public function get_package_kind() {
		return 'Page Builder ShortCode Strings';
	}

	public function get_update_post( $package_data ) {
		return $this->factory->get_update_post( $package_data, $this );
	}

	public function get_content_updater() {
		return $this->factory->get_shortcode_content_updater( $this );
	}

	public function get_package_strings( $package_data ) {
		return $this->factory->get_string_translations( $this )->get_package_strings( $package_data );
	}

	public function get_package_strings_by_name( $package_data ) {
		return $this->factory->get_string_translations( $this )->get_package_strings_by_name( $package_data );
	}

	public function remove_string( $string_data ) {
		return $this->factory->get_string_translations( $this )->remove_string( $string_data );
	}

	public function migrate_location( $post_id, $post_content ) {
		$migrate_locations = $this->factory->get_register_shortcodes( $this, true );
		$migrate_locations->register_shortcode_strings( $post_id, $post_content, null );
	}
}
