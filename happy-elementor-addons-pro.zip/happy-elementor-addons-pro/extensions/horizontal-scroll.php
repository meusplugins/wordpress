<?php
namespace Happy_Addons_Pro\Extensions;

// Elementor Classes.
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Horizontal_Scroll {

/**
 * @var mixed
 */
	private static $instance = null;

	/**
	 * @var mixed
	 */
	private $load_script = null;

	public static function instance() {
		if ( null === ( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {

		// Enqueue the required JS file.
		add_action( 'wp_enqueue_scripts', [$this, 'register_scripts'] );
		add_action( 'wp_enqueue_scripts', [$this, 'register_styles'] );

		add_action( 'elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts'] );

		// Creates Horizontal Scroll tab at the end of layout/content & section advance tab.
		// Container
		if ( defined( 'ELEMENTOR_VERSION' ) && ha_elementor()->experiments->is_feature_active( 'container' ) ) {
			add_action( 'elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 1 );
		}

		// Section
		add_action( 'elementor/element/section/section_advanced/after_section_end', [$this, 'register_controls'], 1 );

		add_action( 'elementor/frontend/container/before_render', [$this, 'before_render'] );

	}

	// Register Scripts
	public function register_scripts() {
		$suffix = ha_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'happy-horizontal-scroll',
			HAPPY_ADDONS_PRO_ASSETS . 'js/horizontal-scroll' . $suffix . 'js',
			['jquery', 'happy-elementor-addons'],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}

	// Register Styles
	public function register_styles() {
		$suffix = ha_is_script_debug_enabled() ? '.' : '.min.';
		wp_register_style(
			'happy-horizontal-scroll',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/horizontal-scroll.min.css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);
	}

	// Enqueue Preview Scripts
	public function enqueue_preview_scripts() {
		wp_enqueue_script( 'gsap' );
		wp_enqueue_script( 'scroll-trigger' );
		wp_enqueue_script( 'happy-horizontal-scroll' );

		wp_enqueue_style( 'happy-horizontal-scroll' );
	}

	public function register_controls( $element ) {

		$element->start_controls_section(
			'_ha_hs_section',
			[
				'label' => esc_html__( 'Horizontal Scroll', 'happy-addons-pro' ) . ha_get_section_icon(),
				'tab'   => Controls_Manager::TAB_ADVANCED
			]
		);

		$element->add_control(
			'ha_hs_help_url_notice_box',
			[
				'type'        => Controls_Manager::NOTICE,
				'notice_type' => 'info',
				'content'     => sprintf(
					esc_html__( 'Need help? %s', 'happy-addons-pro' ),
					'<a href="https://happyaddons.com/docs/happy-addons-for-elementor-pro/features/horizontal-scroll/" target="_blank" rel="noopener noreferrer">'
					. esc_html__( 'Read Documentation', 'happy-addons-pro' )
					. '</a>'
				),
			]
		);

		$this->add_content_controls( $element );

		$element->end_controls_section();
	}

	public function add_content_controls( $element ) {

		$element->add_control(
			'ha_hs_switcher',
			[
				'label'              => __( 'Enable', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'prefix_class'       => 'ha-hs-',
				'render_type'        => 'template',
				'return_value'       => 'yes',
				'style_transfer'     => false,
				'frontend_available' => true,
				'description'        => __( 'Applicable to Desktop layout only', 'happy-addons-pro' ),
				'assets'             => [
					'scripts' => [
						[
							'name'       => 'elementor-frontend',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_hs_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						],
						[
							'name'       => 'gsap',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_hs_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						],
						[
							'name'       => 'scroll-trigger',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_hs_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						],
						[
							'name'       => 'happy-horizontal-scroll',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_hs_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						]
					],
					'styles'  => [
						[
							'name'       => 'happy-horizontal-scroll',
							'conditions' => [
								'terms' => [
									[
										'name'     => 'ha_hs_switcher',
										'operator' => '===',
										'value'    => 'yes'
									]
								]
							]
						]
					]
				]
			]
		);

		$element->add_control(
			'ha_hs_direction',
			[
				'label'              => __( 'Scroll Direction', 'happy-addons-pro' ),
				'type'               => Controls_Manager::CHOOSE,
				'render_type'        => 'template',
				'frontend_available' => true,
				'options'            => [
					'left'  => [
						'title' => __( 'Left', 'happy-addons-pro' ),
						'icon'  => 'eicon-h-align-left'
					],
					'right' => [
						'title' => __( 'Right', 'happy-addons-pro' ),
						'icon'  => 'eicon-h-align-right'
					]
				],
				'condition'          => [
					'ha_hs_switcher' => 'yes'
				],
				'default'            => 'left',
				'toggle'             => false,
				'style_transfer'     => true
			]
		);

		$element->add_control(
			'ha_snap_scroll_switcher',
			[
				'label'              => __( 'Sanp Scrolling', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'render_type'        => 'template',
				'return_value'       => 'yes',
				'style_transfer'     => true,
				'frontend_available' => true,
				'condition'          => [
					'ha_hs_switcher' => 'yes'
				],
				'description'        => __( 'Allows the scroll position to automatically snap to each section or item.', 'happy-addons-pro' )
			]
		);

		$element->add_control(
			'ha_hs_enable_auto_width',
			[
				'label'              => __( 'Enable Auto Width Items', 'happy-addons-pro' ),
				'type'               => Controls_Manager::SWITCHER,
				'render_type'        => 'template',
				'return_value'       => 'yes',
				'style_transfer'     => true,
				'frontend_available' => true,
				'condition'          => [
					'ha_hs_switcher' => 'yes'
				],
				'description'        => __( 'Allow child items to size themselves based on their content (use only for large text panels).', 'happy-addons-pro' )
			]
		);
		/*
		$element->add_control(
            'ha_hs_enable_editor_preview',
            [
                'label'              => __( 'Enable Preview in Editor', 'happy-addons-pro' ),
                'description'        => __( 'When enabled, animations will run inside the Elementor editor. Keep off for better editor performance.', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'separator'          => 'before',
                'condition'          => [
                    'ha_hs_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        ); */

	}

	/**
	 * Render Global badge output on the frontend.
	 * @param \Elementor\Element $element Elementor Element instance.
	 * @return void
	 *
	 */
	public function before_render( $element ) {
		$settings     = $element->get_settings_for_display();
		$element_type = $element->get_type();

		$id = $element->get_id();

		if ( empty( $settings['ha_hs_switcher'] ) || 'yes' !== $settings['ha_hs_switcher'] ) {
			return;
		}

		$ha_hs_switcher = $settings['ha_hs_switcher'] ?? 'no';

		// Base classes
		$classes = ['ha-hs-wrapper'];

		if ( ! empty( $settings['ha_hs_enable_auto_width'] ) && 'yes' === $settings['ha_hs_enable_auto_width'] ) {
			$classes[] = 'ha-hs-auto-width-enabled';
		}

		// Attach to wrapper
		$element->add_render_attribute(
			'_wrapper',
			[
				'class'      => implode( ' ', $classes ),
				'data-ha-hs' => '1'
			]
		);
		
	}

}
