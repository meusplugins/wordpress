=== Wow Herd Effects Pro ===
Author: Wow-Company
Author URI: https://wow-estore.com
Requires at least: 5.5
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 5.0

Designed to create a "sense of queue" or "herd effect", motivating the visitors of the page to perform any actions.

== Description ==
The WordPress plugin Wow Herd Effects Pro – is an effective marketing tool designed to stimulate the conversion of site visitors into customers. It helps you to configure and place animated notifications in the required location of the web resource, showing the activity of the registered users. The extension is designed to create a "sense of queue" or "herd effect", motivating the visitors of the page to perform any actions.

= Main features =
- **Beautiful Animations:** Choose from 32 different animation transitions to enhance your notification’s visual appeal.
- **Number of notifications:** Control of the number of notifications for one user.
- **Powerful positioning:** Position notification anywhere on the screen.
- **Notification Link:** Transform notifications into clickable links, enhancing their functionality and user engagement. With this feature, you can set any notification to act as a hyperlink, directing users to a specific URL when clicked.
- **Highly Customizable:** Build a more powerful and influential style for notifications
- **Scheduling:** Add scheduling options to your notifications. With multiple schedule types, you can precisely schedule your notifications in just a few minutes.
- **Variables:** Set up to 6 different variables per notification
- **Forced Interaction:** Briefly disable the close button to ensure users see your crucial information or complete an action (use with caution).
- **Activate by URL:** Target specific pages based on URL parameters (e.g., show a discount notification only on page with URL parameter).
- **Activate by Referrer URL:** Tailor notification experiences for visitors arriving from particular websites (e.g., display a welcome message to users coming from a partner site).
- **Geotargeting:** Take your notifications to the next level with geotargeting functionality! This powerful plugin feature allows you to display targeted notifications based on the country location of your website visitors.
- **Responsive Visibility:** Choose to hide the notiofication on mobile or desktop devices to optimize for different screen sizes.
- **Display Rules:** Control exactly where your notification appear using page types, post categories/tags, author pages, taxonomies and date archives.
- **Scheduling:** Schedule notification appearances based on specific days, times, and dates. This allows you to promote temporary events or campaigns without cluttering your website permanently.
- **User Role:** Define which user roles (e.g., Administrator, Editor, Author) have the ability to see the notification. This can be helpful for displaying internal notification relevant only to website administrators or for specific user groups.
- **Multi-Language:** For websites catering to a global audience, Wow Herd Effects Pro allows you to restrict notification visibility to specific languages. This ensures users only see button relevant to their chosen language setting.
- **Browsers:**  Deactivate notification selectively for specific browsers.
- **Lightweight & Efficient:** The plugin operates without jQuery, relying solely on JavaScript for efficient performance.
- **GDPR Compliant:** The plugin leverages a cookie-free approach, ensuring compliance with data privacy regulations.


== Frequently Asked Questions ==
= Using plugin on a Multisite Network =
It's important to activate the plugin individually on each subsite, not just the network level.

= Error 'Update Failed' =
This is happening either because the license key is expired or it is not activated on the URL the extension is installed on. This can sometimes happen if you install the plugin and activate the license key on a temporary URL and then update the site to the final URL.

To resolve the problem, [log into your account](https://wow-estore.com/login/) go to page "Account" > "License Keys ", then click on the "Manage Sites" link for the license key. From that page, you will be able to add or remove URLs for the license. Once the proper URL is registered on the license key, you will be able to install the update.

= Upgrade License =
You can upgrade the license key:

1.  Go to your dashboard on [Wow-Estore.com](https://wow-estore.com/)
2.  Go to the page 'Account' > 'License keys'
3.  Click on the link 'View Upgrade'
4.  Click on the link 'Upgrade License'

== Support ==
Search for answers and ask your questions at [support center](https://wow-estore.com/message-support/).
Or write to us via page 'Support' in the plugin.