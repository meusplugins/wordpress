<?php
namespace com\sakuraplugins\appetit;
if ( ! defined( 'ABSPATH' ) ) exit;

class Config {

    // return app specific slugs
    public static function getSlugs() {
        return [
            'menuSlug' => 'appetit-dashboard',
        ];
    }

    static function getSettingsPageSlug() {
        return 'appetit_settings_page';
    }

    static function getOrdersPageSlug() {
        return 'appetit_orders_page';
    }

    static function getOptionsGroupSlug() {
        return 'appetit_options_group_sett';
    }
}
?>