<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');
require_once(plugin_dir_path(__FILE__) . '../../../services/PrintNodeService.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;
use com\sakuraplugins\appetit\services\PrintNodeService;

class WebApps {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Mobile web app', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->renderWebMobileApp() ?></div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Bill page', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->_renderInvoicePage() ?></div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Shortcodes', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->_renderShortcodesPage() ?></div>
        </div>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Connect PrintNode', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->_renderPrintNode() ?></div>
        </div>
        <?php
    }

    private function renderWebMobileApp() {
        $pages = get_pages(['post_type' => 'page']);
        $mobileAppPageId = OptionUtil::getInstance()->getOption('mobile_web_app_page', '');
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                <?php if (is_array($pages) && sizeof($pages) > 0): ?>
                    <select name="<?= esc_attr(Config::getOptionsGroupSlug());?>[mobile_web_app_page]" class="form-select wd_100" style="width: 100%;">
                        <option value=""><?= esc_html__('Select page ...', 'instafood'); ?></option>
                        <?php foreach ($pages as $page): ?>
                            <option value="<?= esc_attr($page->ID); ?>" <?= (int) $mobileAppPageId === $page->ID ? 'selected' : '' ?>><?= esc_html__($page->post_title) ?></option>
                        <?php endforeach; ?>
                    </select>
                    
                    <?php
                    $frontend_is_homepage_enabled = OptionUtil::getInstance()->getOption("frontend_is_homepage_enabled", '');
                    ?>
                    <div class="custom-control custom-switch" style="margin-top: 25px;">
                        <input type="checkbox" class="custom-control-input day_abailable_cb"  
                        id="frontend_is_homepage_enabled_id"
                        value="ON"
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[frontend_is_homepage_enabled]" 
                        <?= $frontend_is_homepage_enabled === 'ON' ? "checked" : "" ?>
                        >
                        <label class="custom-control-label" for="frontend_is_homepage_enabled_id"><?= esc_html__('Mobile Web App displays on the homepage', 'instafood'); ?></label>
                        <div class="option-entry-info"><?= esc_html__("Renders the mobile web app on the homepage (it's not required to modify the WP's reading settings).", 'instafood'); ?></div>
                    </div>

                <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Select the page that will render the mobile web app within the front end.", 'instafood') ?>
                    </div>
                    <div class="alert alert-warning" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Note! Changing the webpage will cause the regeneration of all QR codes.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderInvoicePage() {
        $pages = get_pages(['post_type' => 'page']);
        $invoicePageId = OptionUtil::getInstance()->getOption('invoice_page_id', '');
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                <?php if (is_array($pages) && sizeof($pages) > 0): ?>
                    <select name="<?= esc_attr(Config::getOptionsGroupSlug());?>[invoice_page_id]" class="form-select wd_100" style="width: 100%;">
                        <option value=""><?= esc_html__('Select page ...', 'instafood'); ?></option>
                        <?php foreach ($pages as $page): ?>
                            <option value="<?= esc_attr($page->ID); ?>" <?= (int) $invoicePageId === $page->ID ? 'selected' : '' ?>><?= esc_html__($page->post_title) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Select the page that will generate the PDF bills for orders.", 'instafood') ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderShortcodesPage() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <h6><?php esc_html_e('Usage example', 'instafood'); ?></h6>
                    <h6 style="font-weight: 400; background: #f7f7f7; padding: 1em; border-radius: .3em;">[instafood_embedded mobile_web_app_info="We've detected that you're visiting from a mobile device." button_label="Open mobile web app"]</h6>
                </div>

                <div class="col-md-6">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?php esc_html_e("Even if InstaFood is mainly purposed for mobile devices, there is the possibility to embed the mobile app within regular WordPress pages. In order to do that you can use the [instafood_embedded] shortcode.", 'instafood'); ?>
                    </div>
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?php esc_html_e("The way it works: If the user visiting the website uses a mobile device will be prompted to open the mobile web app on another page, if the user comes from a desktop device the mobile web app will be embedded within the visited page.", 'instafood'); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function _renderPrintNode() {
        $apiKey = trim(OptionUtil::getInstance()->getOption('printnode_api_key', ''));
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 mb_10">
                    <p>Connect any printer to your application with the <a href="https://www.printnode.com" target="_blank">PrintNode</a>.</p>
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__('PrintNode API Key', 'instafood'); ?></label>
                        <input id="printnode_api_key_id" type="text"
                            value="<?= esc_attr(trim(OptionUtil::getInstance()->getOption('printnode_api_key', ''))); ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[printnode_api_key]"
                            class="form-control">
                            <div class="option-entry-info"><?= esc_html__('Obtain the API key from https://app.printnode.com/app/apikeys', 'instafood'); ?></div>
                    </div>
                    <?php if ($apiKey !== ''): ?>
                        <div class="retrive_printers_content">
                            <button id="refresh_connected_printers" class="btn btn-secondary mb_20"><?php esc_html_e('Refresh connected printers', 'instafood'); ?></button>
                            <div id="printers_loading" class="loading d_none" style="display: none;"><div class="lds-ripple"><div></div><div></div></div></div>
                            <h6>Connected Printers:</h6>
                            <div>
                                <?php
                                $printersResult = PrintNodeService::getInstance()->getAvailablePrinters(false);
                                $hasPrinters = !isset($printersResult['error']) && is_array($printersResult) && sizeof($printersResult) > 0;
                                ?>
                                <ul id="printers_list">
                                    <?php if ($hasPrinters): ?>
                                        <?php
                                        $printers = $printersResult ?? [];
                                        ?>
                                        <?php foreach ($printers as $printer): ?>
                                            <li style="color: #838383; font-style: italic;">- <?= esc_html($printer['name'] ?? 'Unknown name') ?> (<?= esc_html($printer['description'] ?? 'Unknown description') ?>)</li>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </ul>
                                
                                <div id="printers_error">
                                    <?php if (!$hasPrinters): ?>
                                        <p>There are no connected printers</p>
                                        <?php if (isset($printersResult['error'])): ?>
                                            <p style="color: red">PrintNode Error: <?= $printersResult['error']['message']?? 'Unknown error' ?></p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="retrive_printers_content_info" style="display: <?= $apiKey === '' ? 'block' : 'none' ?>">
                        <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                            <?= esc_html__("Connected printers can be retrieved once the API key has been added and saved.", 'instafood') ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                </div>
                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }
}