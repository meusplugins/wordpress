<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 *
 * The image source taken from a meta: an icon inside the Image URL field of a layer image and of a background.
 * Shown only while some meta is registered as an image (img:true), which core itself has none of.
 */

if(!defined('ABSPATH')) exit();
?><sr-wrap-dep dep="imagemetas" basic="" class="sr--input--meta--wrap"><sr-drop clean="" data-type="search" data-onchange="editor.elements.metas.selectImage" data-source="metas" data-source-type="image" dropsw="500" dropsh="380" data-v="default" title="<?php esc_attr_e('Meta','revslider'); ?>" class="sr--input--meta"><svg class="sr--icon" width="17" height="17" transform="rotate(-45)"><use xlink:href="#Options_Select_Meta"></use></svg></sr-drop></sr-wrap-dep>