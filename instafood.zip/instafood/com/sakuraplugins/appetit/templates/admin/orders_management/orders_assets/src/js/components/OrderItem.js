import DataUtils from '../utils/DataUtils';
import RestManager from '../services/RestManager';
import EventBus, { Events, Event } from '../events/EventBus';

export class OrderMode {
    static LIVE_ORDER = 'LIVE_ORDER';
    static REGULAR_ORDER = 'REGULAR_ORDER';
}

class OrderItem {

    _order;
    _mode;
    _ui;

    _isLoading = false;
    _onOrdersStatusChange;

    constructor(order, mode = OrderMode.LIVE_ORDER) {
        this._order = order;
        this._mode = mode;
    }

    setOrder(order) {
        this._order = order;
    }

    getTemplate(showBackground) {
        const { ID, _orderType, _orderStatus, _orderDate, _orderTotal, 
        _payment_status } = this._order;
        const orderTypeLabel = DataUtils.getInstance().getOrderTypeLabel(_orderType);

        const order_statuses_mapped = DataUtils.getInstance().getOption('order_statuses_mapped', {});

        const t = DataUtils.getInstance().getOption('price_display_template');
        const priceTemplate = lodash.template(DataUtils.getInstance().decodeHtml(t));

        const statusColor = this._getOrderStatusColor(_orderStatus);
        const editIndicator = _orderStatus === 'NEW_ORDER' ? '<span class="icon-eye"></span>' : '<span class="icon-edit-3"></span>';

        const backgroundStyle = _payment_status === 'PAYMENT_CANCELED' ? 'background: #ff9999' : '';

        const template = `
            <tr class="order_entry${ showBackground ? ' fill' : '' }" style="${ backgroundStyle }" data-id="${ID}">
                <th scope="row" class="o_id"><a class="order_item_id_btn" href="#">${ID}</a></th>
                <td class="clickable o_type"><div class="status_info ${ this._getOrderTypeClass(_orderType) }">${ orderTypeLabel }</div></td>
                <td class="clickable o_status"><div class="status_info" style="background: ${ statusColor }">${ order_statuses_mapped[_orderStatus] }</div></td>
                <td class="clickable o_date">${ _orderDate ? _orderDate : '' }</td>
                <td class="clickable o_price">${ priceTemplate({ price: Number.parseFloat(_orderTotal).toFixed(2) }) }</td>
                <td class="o_actions">
                    <div class="order_actions_ui"></div>
                </td>
                <td class="o_edit">
                    <a class="action_btn open_edit_btn" href="#">${ editIndicator }</a>
                </td>
            </tr>
        `;
        this._ui = jQuery(template);
        this._upateQuickActionButton();

        const _this = this;
        this._ui.find('.open_edit_btn').click(function(event) {
            EventBus.getInstance().triggerEvent(Events.REQUEST_OPEN_SINGLE_ORDER, { ID: _this._order?.ID, _mode: _this._mode });
        })
        this._ui.find('.order_item_id_btn').click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.REQUEST_OPEN_SINGLE_ORDER, { ID: _this._order?.ID, _mode: _this._mode });
        })
        return this._ui;
    }

    _updateOrderStatusInfo() {
        const { _orderStatus } = this._order;
        const statusColor = this._getOrderStatusColor(_orderStatus);
        const order_statuses_mapped = DataUtils.getInstance().getOption('order_statuses_mapped', {});

        const order_change_status_info = DataUtils.getInstance().getLabel('order_change_status_info');
        toastr.success(`#${ this._order.ID } - ${ order_change_status_info }: ${ order_statuses_mapped[_orderStatus] }`, '', {
            iconClass: "appetit-toast-custom",
        });

        this._ui.find('.o_status').html(`<div class="status_info" style="background: ${ statusColor }">${ order_statuses_mapped[_orderStatus] }</div>`);
    }

    _upateQuickActionButton() {
        const { ID, _orderStatus, _payment_status } = this._order;
        this._ui.find('.order_actions_ui').empty();
        const btnTemplate = this._getActionButton(_orderStatus, _payment_status, ID);
        const btn = jQuery(btnTemplate);
        btn.appendTo(this._ui.find('.order_actions_ui'));

        const _this = this;
        
        btn.click(function(event) {
            event.preventDefault();
            const order_action = jQuery(this).attr('data-action');
            _this._changeOrderStatus(order_action);
        })
    }

    _changeOrderStatus(order_action) {
        if (this._isLoading) {
            return;
        }
        this._isLoading = true;
        const ID = this._order.ID;

        RestManager.getInstance().changeOrderStatus(ID, order_action, this._mode)
        .then(result => {
            this._isLoading = false;
        });
    }

    _getActionButton(_orderStatus, _payment_status, orderId) {
        
        let html = '';
        switch (_orderStatus) {
            case 'NEW_ORDER':
                html = `<button type="button" data-action="ACCEPTED" data-id="${ orderId }" class="btn btn-dark change_status_btn">${ DataUtils.getInstance().getLabel('accept') }</button>`;
            break;
            case 'ACCEPTED':
                html = `<button type="button" data-action="PREPARED" data-id="${ orderId }" class="btn btn-dark change_status_btn">${ DataUtils.getInstance().getLabel('prepared') }</button>`;
            break;
            case 'PREPARED':
                html = `<button type="button" data-action="DELIVERED" data-id="${ orderId }" class="btn btn-dark change_status_btn">${ DataUtils.getInstance().getLabel('delivered') }</button>`;
            break;
            case 'DELIVERED':
                html = `<button type="button" data-action="CLOSED" data-id="${ orderId }" class="btn btn-dark change_status_btn">${ DataUtils.getInstance().getLabel('closed') }</button>`;
            break;
            case 'CLOSED':
                html = `<span class="status_fade">${ DataUtils.getInstance().getLabel('order_closed') }</span>`;
            break;
            case 'REJECTED':
                html = `<span class="status_fade">${ DataUtils.getInstance().getLabel('order_rejected') }</span>`;
            break;
        }

        if (_payment_status === 'PAYMENT_CANCELED') {
            html = `<button type="button" data-action="DELETE" data-id="${ orderId }" class="btn btn-dark change_status_btn">${ DataUtils.getInstance().getLabel('delete') }</button>`;
        }

        return html;
    }

    _getOrderTypeClass(_orderType) {
        let cls = 'dinein';
        switch (_orderType) {
            case 'DELIVERY':
                cls = 'delivery';
                break;
            case 'PICKUP':
                cls = 'pickup';
                break;
            case 'DINEIN':
                cls = 'dinein';
                break;
        }
        return cls;
    }

    _getOrderStatusColor(_orderStatus) {
        const order_statuses_colors = DataUtils.getInstance().getOption('order_statuses_colors', {});
        return order_statuses_colors[_orderStatus]
    }

    getOrder() {
        return this._order;
    }

    getMode() {
        return this._mode;
    }

    updateStatus(status) {
        this._order = { ...this._order, _orderStatus: status };
        this._upateQuickActionButton();
        this._updateOrderStatusInfo();
    }

    updateStatusSoft(status) {
        this._order = { ...this._order, _orderStatus: status };
        this._updateOrderStatusInfo();   
    }

    removeUI() {
        this._ui.remove();
    }
    
}
export default OrderItem;