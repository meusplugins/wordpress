<?php
/**
 * Class that handles generic access helpers.
 *
 * @package WPCode
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_Access.
 */
class WPCode_Access {

	/**
	 * Check if PHP is disabled.
	 *
	 * @return bool
	 */
	public static function php_disabled() {
		$disabled = defined( 'WPCODE_DISABLE_PHP' ) && WPCODE_DISABLE_PHP;

		if ( ! $disabled && isset( wpcode()->settings ) ) {
			$disabled = (bool) wpcode()->settings->get_option( 'completely_disable_php' );
		}

		return $disabled;
	}

	/**
	 * Check if snippets are managed exclusively through the WPCode Library.
	 *
	 * Constant-only by design, with no settings fallback: a database-backed
	 * option could be flipped by the same compromised admin session this
	 * mode is meant to contain. Off when snippets are managed from files
	 * (WPCODE_SNIPPETS_FROM_FILES): the two modes would refuse each other's
	 * writes, so the files mode wins.
	 *
	 * @return bool
	 */
	public static function remote_only() {
		// Read the constant directly: this runs before the file sync class loads.
		if ( defined( 'WPCODE_SNIPPETS_FROM_FILES' ) && WPCODE_SNIPPETS_FROM_FILES ) {
			return false;
		}

		return defined( 'WPCODE_REMOTE_ONLY' ) && WPCODE_REMOTE_ONLY;
	}

	/**
	 * Get an array of the custom capabilities that WPCode uses.
	 *
	 * @return array
	 */
	public static function capabilities() {
		return wpcode_custom_capabilities();
	}

	/**
	 * Get the custom capability from the settings specific to each code type.
	 *
	 * @param string $code_type The code type to check for.
	 *
	 * @return string
	 */
	public static function capability_for_code_type( $code_type ) {
		switch ( $code_type ) {
			case 'text':
			case 'blocks':
				return 'wpcode_edit_text_snippets';
			case 'html':
			case 'js':
			case 'css':
			case 'scss':
				return 'wpcode_edit_html_snippets';
			case 'php':
			case 'universal':
				return 'wpcode_edit_php_snippets';
			default:
				return '';
		}
	}
}