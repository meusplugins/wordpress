<?php
namespace Jet_Engine\Query_Builder\File_Query;

use WP_Error;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Base utilities shared by file query format parsers.
 */
abstract class Base_Parser {

	/**
	 * Parse the resolved source into normalized rows and properties.
	 *
	 * @param array $source Resolved source payload.
	 * @param array $query  Normalized file query arguments.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	abstract public static function parse( $source, $query, $limits );

	/**
	 * Normalize a set of tabular rows into file query rows.
	 *
	 * @param array $rows Raw tabular rows.
	 * @param array $args Normalization arguments.
	 *
	 * @return array|WP_Error
	 */
	protected static function normalize_tabular_rows( $rows, $args ) {
		$rows       = is_array( $rows ) ? $rows : array();
		$has_header = ! empty( $args['has_header'] );
		$header_row = ! empty( $args['header_row'] ) ? absint( $args['header_row'] ) : 1;
		$limits     = ! empty( $args['limits'] ) ? $args['limits'] : Parser::get_limits();
		$header     = array();

		if ( $has_header ) {
			if ( ! isset( $rows[ $header_row ] ) ) {
				return new WP_Error( 'file_query_header_row', __( 'Header row was not found in the selected source.', 'jet-engine' ) );
			}

			$header = self::normalize_numeric_row( $rows[ $header_row ] );
		}

		$data_rows   = array();
		$max_columns = count( $header );

		foreach ( $rows as $index => $row ) {
			if ( $has_header && $index <= $header_row ) {
				continue;
			}

			$row = self::normalize_numeric_row( $row );

			if ( empty( $row ) || ! self::row_has_meaningful_values( $row ) ) {
				continue;
			}

			$data_rows[] = array(
				'index' => absint( $index ),
				'row'   => $row,
			);
			$max_columns = max( $max_columns, count( $row ) );
		}

		if ( $max_columns > $limits['max_columns'] ) {
			return new WP_Error( 'file_query_columns_limit', __( 'The selected source exceeds the allowed column limit.', 'jet-engine' ) );
		}

		$result = array();

		foreach ( $data_rows as $index => $row_data ) {
			$normalized = array();
			$row        = $row_data['row'];

			for ( $column = 0; $column < $max_columns; $column++ ) {
				$key   = isset( $header[ $column ] ) ? $header[ $column ] : '';
				$value = array_key_exists( $column, $row ) ? $row[ $column ] : null;

				$assigned = self::assign_tabular_value( $normalized, $key, $value, $column + 1, $limits );

				if ( is_wp_error( $assigned ) ) {
					return $assigned;
				}
			}

			$normalized[ self::reserved_index_key() ] = ! empty( $row_data['index'] ) ? $row_data['index'] : ( $index + 1 );
			$result[] = $normalized;
		}

		return self::finalize_rows( $result, $limits );
	}

	/**
	 * Normalize a numeric row so its values can be assigned consistently.
	 *
	 * @param mixed $row Source row.
	 *
	 * @return array
	 */
	protected static function normalize_numeric_row( $row ) {
		if ( ! is_array( $row ) ) {
			return array();
		}

		$limits = Parser::get_limits();

		ksort( $row );
		$row = array_values( $row );

		return array_map( function( $value ) use ( $limits ) {
			if ( is_string( $value ) ) {
				return self::normalize_scalar_value( $value, $limits['max_cell_length'] );
			}

			return $value;
		}, $row );
	}

	/**
	 * Assign a prepared value into a normalized tabular row.
	 *
	 * @param array  $row           Normalized row being built.
	 * @param string $raw_key       Raw property name.
	 * @param mixed  $value         Source value.
	 * @param int    $column_number Fallback column number.
	 * @param array  $limits        Parsing limits.
	 *
	 * @return bool|WP_Error
	 */
	protected static function assign_tabular_value( &$row, $raw_key, $value, $column_number, $limits ) {
		$normalized = self::prepare_normalized_value( $value, $limits );

		if ( is_wp_error( $normalized ) ) {
			return $normalized;
		}

		$key      = self::generate_unique_key( array_keys( $row ), $raw_key, 'col_' . $column_number );
		$row[ $key ] = $normalized;

		return true;
	}

	/**
	 * Convert a raw source value into a normalized scalar-compatible value.
	 *
	 * @param mixed $value  Source value.
	 * @param array $limits Parsing limits.
	 *
	 * @return mixed
	 */
	protected static function prepare_normalized_value( $value, $limits ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			$value = wp_json_encode( $value );
		}

		if ( is_bool( $value ) || is_null( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			return self::normalize_scalar_value( $value, $limits['max_cell_length'] );
		}

		if ( is_scalar( $value ) ) {
			return self::normalize_scalar_value( (string) $value, $limits['max_cell_length'] );
		}

		return '';
	}

	/**
	 * Normalize a scalar string representation and cast numeric values when safe.
	 *
	 * @param mixed $value      Source value.
	 * @param int   $max_length Maximum allowed string length.
	 *
	 * @return int|float|string
	 */
	protected static function normalize_scalar_value( $value, $max_length ) {
		$value = (string) $value;

		if ( strlen( $value ) > $max_length ) {
			$value = substr( $value, 0, $max_length );
		}

		if ( preg_match( '/^-?(?:0|[1-9]\d*)$/', $value ) ) {
			return (int) $value;
		}

		if ( preg_match( '/^-?(?:0|[1-9]\d*)\.\d+$/', $value ) ) {
			$float = (float) $value;

			if ( wp_json_encode( $float ) === $value ) {
				return $float;
			}
		}

		return $value;
	}

	/**
	 * Finalize normalized rows and build the filterable properties list.
	 *
	 * @param array $rows   Normalized rows.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	protected static function finalize_rows( $rows, $limits ) {
		$rows  = array_values( array_filter( $rows, function( $row ) {
			return is_array( $row ) && ! empty( $row );
		} ) );
		$count = count( $rows );

		if ( $count > $limits['max_rows'] ) {
			return new WP_Error( 'file_query_rows_limit', __( 'The selected source exceeds the allowed row limit.', 'jet-engine' ) );
		}

		$props = array();

		foreach ( $rows as $index => $row ) {
			$row = apply_filters( 'jet-engine/query-builder/file-query/normalized-row', $row, $index + 1 );

			foreach ( $row as $key => $value ) {
				if ( self::reserved_index_key() === $key ) {
					continue;
				}

				if ( ! in_array( $key, $props, true ) ) {
					$props[] = $key;
				}
			}

			$rows[ $index ] = $row;
		}

		$rows  = apply_filters( 'jet-engine/query-builder/file-query/rows', $rows );
		$props = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			foreach ( $row as $key => $value ) {
				if ( self::reserved_index_key() === $key ) {
					continue;
				}

				if ( ! in_array( $key, $props, true ) ) {
					$props[] = $key;
				}
			}
		}

		$props = apply_filters( 'jet-engine/query-builder/file-query/filterable-props', $props, $rows );
		$props = array_values( array_filter( array_unique( array_map( array( __NAMESPACE__ . '\\Parser', 'sanitize_property_key' ), (array) $props ) ) ) );

		return array(
			'rows'  => array_values( is_array( $rows ) ? $rows : array() ),
			'props' => $props,
		);
	}

	/**
	 * Generate a unique property key for the current row.
	 *
	 * @param array  $existing Existing keys.
	 * @param string $raw_key  Preferred key.
	 * @param string $fallback Fallback key.
	 *
	 * @return string
	 */
	protected static function generate_unique_key( $existing, $raw_key, $fallback ) {
		$key = Parser::sanitize_property_key( $raw_key );

		if ( ! $key ) {
			$key = Parser::sanitize_property_key( $fallback );
		}

		if ( ! $key ) {
			$key = 'col_1';
		}

		$base = $key;
		$i    = 2;

		while ( in_array( $key, $existing, true ) ) {
			$key = $base . '_' . $i;
			$i++;
		}

		return $key;
	}

	/**
	 * Resolve a dot-notated path inside a decoded JSON structure.
	 *
	 * @param mixed  $data Source data.
	 * @param string $path Dot-notated path.
	 *
	 * @return mixed|null
	 */
	protected static function resolve_records_path( $data, $path ) {
		$parts = array_filter( explode( '.', $path ), 'strlen' );

		foreach ( $parts as $part ) {
			if ( ! is_array( $data ) || ! array_key_exists( $part, $data ) ) {
				return null;
			}

			$data = $data[ $part ];
		}

		return $data;
	}

	/**
	 * Check whether an array uses sequential numeric keys.
	 *
	 * @param mixed $array Candidate value.
	 *
	 * @return bool
	 */
	protected static function is_sequential_array( $array ) {
		if ( ! is_array( $array ) ) {
			return false;
		}

		return array_keys( $array ) === range( 0, count( $array ) - 1 );
	}

	/**
	 * Determine whether a normalized row contains any meaningful value.
	 *
	 * @param array $row Row values.
	 *
	 * @return bool
	 */
	protected static function row_has_meaningful_values( $row ) {
		foreach ( $row as $value ) {
			if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
				return true;
			}

			if ( null !== $value && '' !== trim( (string) $value ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Remove a UTF-8 byte order mark from the start of a string.
	 *
	 * @param string $content Source text.
	 *
	 * @return string
	 */
	protected static function strip_utf8_bom( $content ) {
		return preg_replace( '/^\xEF\xBB\xBF/', '', $content );
	}

	/**
	 * Decode escaped delimiter values used by the editor.
	 *
	 * @param string $delimiter   Raw delimiter.
	 * @param bool   $allow_empty Whether an empty result is allowed.
	 *
	 * @return string
	 */
	public static function decode_delimiter( $delimiter, $allow_empty = true ) {
		$delimiter = (string) $delimiter;
		$delimiter = str_replace( array( '\\r\\n', '\\n', '\\r', '\\t' ), array( "\r\n", "\n", "\r", "\t" ), $delimiter );

		if ( ! $allow_empty && '' === $delimiter ) {
			return '';
		}

		return $delimiter;
	}

	/**
	 * Get the reserved row index key used in normalized rows.
	 *
	 * @return string
	 */
	protected static function reserved_index_key() {
		return Parser::index_key();
	}
}
