<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../vendor/stripe-php/init.php');
require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/OrderPaymentStatus.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\rest_api\models\OrderPaymentStatus;

class StripeService {
    public $hasCredentials = false;
    private $secret;
    private $apiKey;
    private $currency_code;

    private $errors = [];
    private $_order_payment_status = false;
    private $_order_id;
    private $receipt_url = '';
    private $stripe_endpoint_secret;

    function __construct() {
        $stripe = OptionUtil::getInstance()->getOption("delivery_payment_stripe", '');
        $this->currency_code = OptionUtil::getInstance()->getOption('restaurant_currency_code', 'USD');

        if ($stripe === 'ON') {
            $this->secret = trim(OptionUtil::getInstance()->getOption("stripe_secret_api_key", ''));
            $this->apiKey = trim(OptionUtil::getInstance()->getOption("stripe_public_api_key", ''));
            $this->stripe_endpoint_secret = trim(OptionUtil::getInstance()->getOption("stripe_endpoint_secret", ''));

            if ($this->secret !== '' && $this->apiKey !== '') {
                $this->hasCredentials = true;
                \Stripe\Stripe::setApiKey($this->secret);
            }
        }
    }

    function createSession(array $line_items, string $success_url, string $cancel_url, $client_reference_id): void {
        
        $checkout_session = \Stripe\Checkout\Session::create([
            'line_items' => $line_items,
            'payment_method_types' => [
              'card',
            ],
            'mode' => 'payment',
            'success_url' => $success_url,
            'cancel_url' => $cancel_url,
            'payment_intent_data' => [
                'metadata' => [
                    'order_id' => $client_reference_id
                ]
            ]
            
        ]);

        header('Content-Type: application/json');
        header("HTTP/1.1 303 See Other");
        header("Location: " . $checkout_session->url);
    }


    function handleIncommingWebhook() {
        $endpoint_secret = $this->stripe_endpoint_secret;

        $payload = @file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
        $event = null;
        
        try {
          $event = \Stripe\Webhook::constructEvent(
            $payload, $sig_header, $endpoint_secret
          );
        } catch(\UnexpectedValueException $e) {
            // Invalid payload
            $this->errors[] = 400;
            return;
        } catch(\Stripe\Exception\SignatureVerificationException $e) {
            // Invalid signature
            $this->errors[] = 400;
            return;
        }

        $this->_order_id = $event->data->object->metadata->order_id ?? '';
        $this->receipt_url = $event->data->object->receipt_url ?? '';


        if ($event->type == "charge.succeeded") {
            $this->_order_payment_status = OrderPaymentStatus::PAID;
        } elseif ($event->type == "invoice.payment_succeeded") {
            $this->_order_payment_status = OrderPaymentStatus::PAID;
        } elseif ($event->type == "charge.failed") {
            $this->_order_payment_status = OrderPaymentStatus::PAYMENT_FAILED;
        } elseif ($event->type == "charge.expired") {
            $this->_order_payment_status = OrderPaymentStatus::PAYMENT_FAILED;
        } elseif ($event->type == "payment_intent.succeeded") {
            $this->_order_payment_status = OrderPaymentStatus::PAYMENT_INTENT_SUCCEDED;
        }
    }

    function getOrderPaymentStatus() {
        return $this->_order_payment_status;
    }

    function get_receipt_url() {
        return $this->receipt_url;
    }

    function getCurrentOrderId() {
        return $this->_order_id;
    }

    function hasErrors() {
        return sizeof($this->errors) > 0;
    }

    function getErrors() {
        return $this->errors;
    }
}