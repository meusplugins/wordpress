<?php
    /**
 * Svg Morphing
 * @package Happy_Addons_Pro
 */
    namespace Happy_Addons_Pro\Widget;

    use Elementor\Repeater;
use Elementor\Controls_Manager;

    defined( 'ABSPATH' ) || die();

    class Svg_Morphing extends Base {

    public function get_title() {
        return __( 'Svg Morphing ', 'happy-addons-pro' );
    }

    public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/svg-morphing/';
    }

    public function get_icon() {
        return 'hm hm-hexa';
    }

    public function get_keywords() {
        return ['morph-svg', 'morph', 'svg', 'animation', 'morphing', 'svg-animation', 'shape-morphing', 'shape-animation'];
    }

    protected function register_content_controls() {
        $this->__morph_content_controls();
        $this->__settings_content_controls();
    }

    protected function __morph_content_controls() {

        $this->start_controls_section(
            '_section_morph_contents',
            [
                'label' => __( 'Morph SVG Shapes', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'svg_source',
            [
                'label'   => __( 'SVG Source', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'custom',
                'options' => [
                    'upload' => __( 'Upload SVG', 'happy-addons-pro' ),
                    'custom' => __( 'Custom SVG Code', 'happy-addons-pro' )
                ]
            ]
        );

        $repeater->add_control(
            'svg_upload',
            [
                'label'       => __( 'Upload SVG File', 'happy-addons-pro' ),
                'type'        => Controls_Manager::MEDIA,
                'media_types' => ['image/svg+xml'],
                'condition'   => [
                    'svg_source' => 'upload'
                ]
            ]
        );

        $repeater->add_control(
            'svg_name',
            [
                'label'       => __( 'SVG Name', 'happy-addons-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => '',
                'placeholder' => __( 'e.g. My Custom Shape', 'happy-addons-pro' ),
                'label_block' => true,
                'condition'   => [
                    'svg_source' => 'custom'
                ]
            ]
        );

        $repeater->add_control(
            'custom_svg_code',
            [
                'label'             => __( 'Custom SVG Code', 'happy-addons-pro' ),
                'type'              => Controls_Manager::TEXTAREA,
                'sanitize_callback' => 'wp_kses_post',
                'description'       => 'You can use these sites to Convert SVG image to code: <a href="https://nikitahl.github.io/svg-2-code/" target="_blank">SVG 2 CODE</a> ',
                'default'           => '',
                'placeholder'       => __( '<svg viewBox="0 0 100 100"><path d="M50 10..." fill="currentColor"/></svg>', 'happy-addons-pro' ),
                'rows'              => 6,
                'condition'         => [
                    'svg_source' => 'custom'
                ]
            ]
        );

        $repeater->add_control(
            'shape_gradient_type',
            [
                'label'   => __( 'Fill Type', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    ''       => __( 'General (Use Common Style)', 'happy-addons-pro' ),
                    'solid'  => __( 'Solid Color', 'happy-addons-pro' ),
                    'linear' => __( 'Linear Gradient', 'happy-addons-pro' ),
                    'radial' => __( 'Radial Gradient', 'happy-addons-pro' )
                ]
            ]
        );

        $repeater->add_control(
            'shape_solid_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fb8305',
                'condition' => [
                    'shape_gradient_type' => 'solid'
                ],
                'render_type'        => 'template',
            ]
        );

        $repeater->add_control(
            'shape_gradient_angle',
            [
                'label'     => __( 'Angle', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 45,
                'min'       => 0,
                'max'       => 360,
                'step'      => 1,
                'condition' => [
                    'shape_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $repeater->add_control(
            'shape_gradient_color_1',
            [
                'label'     => __( 'Color 1', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ff8709',
                'condition' => [
                    'shape_gradient_type' => ['linear', 'radial']
                ],
                'render_type'        => 'template',
            ]
        );

        $repeater->add_control(
            'shape_gradient_color_1_stop',
            [
                'label'     => __( 'Stop 1', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 0.2,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'condition' => [
                    'shape_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $repeater->add_control(
            'shape_gradient_color_2',
            [
                'label'     => __( 'Color 2', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f7bdf8',
                'condition' => [
                    'shape_gradient_type' => ['linear', 'radial']
                ],
                'render_type'        => 'template',
            ]
        );

        $repeater->add_control(
            'shape_gradient_color_2_stop',
            [
                'label'     => __( 'Stop 2', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 0.7,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'condition' => [
                    'shape_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_control(
            'morph_shapes',
            [
                'show_label' => false,
                'type'       => Controls_Manager::REPEATER,
                'fields'     => $repeater->get_controls(),
                'default'    => [
                    [
                        'svg_source'                  => 'custom',
                        'svg_name'                    => '6-Point Star',
                        'custom_svg_code'             => '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M50 10 L60 32.7 L84.6 30 L70 50 L84.6 70 L60 67.3 L50 90 L40 67.3 L15.4 70 L30 50 L15.4 30 L40 32.7 Z" fill="currentColor"/></svg>',
                        'shape_gradient_type'         => '',
                        'shape_solid_color'           => '#fb8305',
                        'shape_gradient_angle'        => 45,
                        'shape_gradient_color_1'      => '#ff8709',
                        'shape_gradient_color_1_stop' => 0.2,
                        'shape_gradient_color_2'      => '#f7bdf8',
                        'shape_gradient_color_2_stop' => 0.7
                    ],
                    [
                        'svg_source'                  => 'custom',
                        'svg_name'                    => 'Infinity',
                        'custom_svg_code'             => '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M50 50 C70 16 90 28 70 50 C90 72 70 84 50 50 C30 84 10 72 30 50 C10 28 30 16 50 50 Z" fill="currentColor"/></svg>',
                        'shape_gradient_type'         => '',
                        'shape_solid_color'           => '#fb8305',
                        'shape_gradient_angle'        => 45,
                        'shape_gradient_color_1'      => '#ff8709',
                        'shape_gradient_color_1_stop' => 0.2,
                        'shape_gradient_color_2'      => '#f7bdf8',
                        'shape_gradient_color_2_stop' => 0.7
                    ],
                    [
                        'svg_source'                  => 'custom',
                        'svg_name'                    => 'Lightning',
                        'custom_svg_code'             => '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M54 10 L36 48 L52 48 L46 90 L64 52 L48 52 Z" fill="currentColor"/></svg>',
                        'shape_gradient_type'         => '',
                        'shape_solid_color'           => '#fb8305',
                        'shape_gradient_angle'        => 45,
                        'shape_gradient_color_1'      => '#ff8709',
                        'shape_gradient_color_1_stop' => 0.2,
                        'shape_gradient_color_2'      => '#f7bdf8',
                        'shape_gradient_color_2_stop' => 0.7
                    ]
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function __settings_content_controls() {

        $this->start_controls_section(
            '_section_morph_settings',
            [
                'label' => __( 'Animation Settings', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control(
            'morph_duration',
            [
                'label'   => __( 'Duration (s)', 'happy-addons-pro' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 2,
                'min'     => 0.1,
                'step'    => 0.1
            ]
        );

        $this->add_control(
            'morph_repeat_delay',
            [
                'label'   => __( 'Repeat Delay (s)', 'happy-addons-pro' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 0.5,
                'min'     => 0,
                'step'    => 0.1
            ]
        );

        $this->add_control(
            'morph_stagger',
            [
                'label'   => __( 'Stagger (s)', 'happy-addons-pro' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 0.5,
                'min'     => 0,
                'step'    => 0.1
            ]
        );

        $this->add_control(
            'morph_speed',
            [
                'label'   => __( 'Speed', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '0.25' => '0.25x',
                    '0.5'  => '0.5x',
                    '1'    => '1x',
                    '1.5'  => '1.5x',
                    '2'    => '2x'
                ]
            ]
        );

        $this->add_control(
            'morph_autoplay',
            [
                'label'   => __( 'Auto Play', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'true'  => __( 'True', 'happy-addons-pro' ),
                    'false' => __( 'False', 'happy-addons-pro' )
                ]
            ]
        );

        $this->add_control(
            'morph_yoyo',
            [
                'label'   => __( 'Yoyo', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'true'  => __( 'True', 'happy-addons-pro' ),
                    'false' => __( 'False', 'happy-addons-pro' )
                ]
            ]
        );

        $this->add_control(
            'morph_ease',
            [
                'label'   => __( 'Ease', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'expo.inOut',
                'options' => [
                    'power1.inOut'  => 'power1.inOut',
                    'power2.inOut'  => 'power2.inOut',
                    'power3.inOut'  => 'power3.inOut',
                    'power4.inOut'  => 'power4.inOut',
                    'power1.in'     => 'power1.in',
                    'power2.in'     => 'power2.in',
                    'power3.in'     => 'power3.in',
                    'power4.in'     => 'power4.in',
                    'power1.out'    => 'power1.out',
                    'power2.out'    => 'power2.out',
                    'power3.out'    => 'power3.out',
                    'power4.out'    => 'power4.out',
                    'expo.inOut'    => 'expo.inOut',
                    'back.in'       => 'back.in',
                    'back.out'      => 'back.out',
                    'back.inOut'    => 'back.inOut',
                    'elastic.in'    => 'elastic.in',
                    'elastic.out'   => 'elastic.out',
                    'elastic.inOut' => 'elastic.inOut',
                    'bounce.in'     => 'bounce.in',
                    'bounce.out'    => 'bounce.out',
                    'bounce.inOut'  => 'bounce.inOut',
                    'circ.inOut'    => 'circ.inOut',
                    'sine.inOut'    => 'sine.inOut'
                ]
            ]
        );

        $this->add_control(
            'morph_svg_scale',
            [
                'label'       => __( 'SVG Scale', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'render_type' => 'template',
                'size_units'  => ['%'],
                'default'     => [
                    'unit' => '%',
                    'size' => 100
                ],
                'range'       => [
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ]
                ]
            ]
        );

        $this->add_control(
            'morph_svg_width',
            [
                'label'       => __( 'SVG Width', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'render_type' => 'template',
                'size_units'  => ['px'],
                'default'     => [
                    'unit' => 'px',
                    'size' => 100
                ],
                'range'       => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 3000,
                        'step' => 1
                    ]
                ]
            ]
        );

        $this->add_control(
            'morph_svg_height',
            [
                'label'       => __( 'SVG Height', 'happy-addons-pro' ),
                'type'        => Controls_Manager::SLIDER,
                'render_type' => 'template',
                'size_units'  => ['px'],
                'default'     => [
                    'unit' => 'px',
                    'size' => 100
                ],
                'range'       => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 3000,
                        'step' => 1
                    ]
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function register_style_controls() {
        $this->__morph_style_controls();
    }

    protected function __morph_style_controls() {

        $this->start_controls_section(
            '_section_morph_style',
            [
                'label' => __( 'Gradient Style', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_control(
            'common_gradient_type',
            [
                'label'   => __( 'Fill Type', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'linear',
                'options' => [
                    'linear' => __( 'Linear Gradient', 'happy-addons-pro' ),
                    'radial' => __( 'Radial Gradient', 'happy-addons-pro' ),
                    'solid'  => __( 'Solid Color', 'happy-addons-pro' )
                ]
            ]
        );

        $this->add_control(
            'common_solid_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fb8305',
                'condition' => [
                    'common_gradient_type' => 'solid'
                ]
            ]
        );

        $this->add_control(
            'common_gradient_angle',
            [
                'label'     => __( 'Angle', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 45,
                'min'       => 0,
                'max'       => 360,
                'step'      => 1,
                'condition' => [
                    'common_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_control(
            'common_gradient_color_1',
            [
                'label'     => __( 'Color 1', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ff8709',
                'condition' => [
                    'common_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_control(
            'common_gradient_color_1_stop',
            [
                'label'     => __( 'Stop 1', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 0.2,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'condition' => [
                    'common_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_control(
            'common_gradient_color_2',
            [
                'label'     => __( 'Color 2', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f7bdf8',
                'condition' => [
                    'common_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_control(
            'common_gradient_color_2_stop',
            [
                'label'     => __( 'Stop 2', 'happy-addons-pro' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 0.7,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'condition' => [
                    'common_gradient_type' => ['linear', 'radial']
                ]
            ]
        );

        $this->add_responsive_control(
				'canvas_align',
				[
					'label'     => __( 'Alignment', 'happy-elementor-addons' ),
					'type'      => Controls_Manager::CHOOSE,
					'options'   => [
						'start'   => [
							'title' => __( 'Left', 'happy-elementor-addons' ),
							'icon'  => 'eicon-text-align-left'
						],
						'center' => [
							'title' => __( 'Center', 'happy-elementor-addons' ),
							'icon'  => 'eicon-text-align-center'
						],
						'end'  => [
							'title' => __( 'Right', 'happy-elementor-addons' ),
							'icon'  => 'eicon-text-align-right'
						]
					],
					'default'   => 'center',
					'selectors' => [
						'{{WRAPPER}} .ha-morph-svg-wrapper' => 'justify-content: {{VALUE}};'
					],
					'toggle'    => false
				]
			);

            $this->add_responsive_control(
				'canvas_align_margin',
				[
					'label'              => __( 'Margin', 'happy-addons-pro' ),
					'type'               => Controls_Manager::DIMENSIONS,
					'size_units'         => ['px', 'em', '%'],
					'selectors'          => [
						'{{WRAPPER}} .ha-morph-svg-wrapper .ha-morph-svg-canvas' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
					],
					'style_transfer'     => true,
					'frontend_available' => true
				]
			);

            $this->add_responsive_control(
				'canvas_align_padding',
				[
					'label'              => __( 'Padding', 'happy-addons-pro' ),
					'type'               => Controls_Manager::DIMENSIONS,
					'size_units'         => ['px', 'em', '%'],
					'selectors'          => [
						'{{WRAPPER}} .ha-morph-svg-wrapper .ha-morph-svg-canvas' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
					],
					'style_transfer'     => true,
					'frontend_available' => true
				]
			);

        $this->end_controls_section();
    }

    private function ha_parse_svg_path_data( $svg_content ) {
        if ( empty( $svg_content ) ) {
            return '';
        }

        $svg_content = trim( $svg_content );

        if ( preg_match( '/^[MmLlHhVvCcSsQqTtAaZz0-9\s,.\-+eE]+$/', $svg_content ) ) {
            return $svg_content;
        }

        libxml_use_internal_errors( true );
        $doc = new \DOMDocument();
        $doc->loadXML( $svg_content );
        libxml_clear_errors();

        $paths = $doc->getElementsByTagName( 'path' );
        $all_d = '';

        if ( $paths->length > 0 ) {
            foreach ( $paths as $path ) {
                $d = $path->getAttribute( 'd' );
                if ( !empty( $d ) ) {
                    $all_d .= $d . ' ';
                }
            }
        }

        if ( empty( $all_d ) ) {
            $polygons = $doc->getElementsByTagName( 'polygon' );
            if ( $polygons->length > 0 ) {
                $points = trim( $polygons->item( 0 )->getAttribute( 'points' ) );
                $pts    = preg_split( '/\s+/', $points );
                $d      = '';
                foreach ( $pts as $i => $p ) {
                    $coords = explode( ',', $p );
                    if ( count( $coords ) >= 2 ) {
                        $d .= ( $i === 0 ? 'M' : 'L' ) . $coords[0] . ',' . $coords[1] . ' ';
                    }
                }
                $all_d = $d . 'Z';
            }
        }

        if ( empty( $all_d ) ) {
            $circles = $doc->getElementsByTagName( 'circle' );
            if ( $circles->length > 0 ) {
                $c     = $circles->item( 0 );
                $cx    = floatval( $c->getAttribute( 'cx' ) ?: 50 );
                $cy    = floatval( $c->getAttribute( 'cy' ) ?: 50 );
                $r     = floatval( $c->getAttribute( 'r' ) ?: 40 );
                $all_d = $this->ha_arc_path( $cx, $cy, $r, $r );
            }
        }

        if ( empty( $all_d ) ) {
            $rects = $doc->getElementsByTagName( 'rect' );
            if ( $rects->length > 0 ) {
                $rect  = $rects->item( 0 );
                $rx    = floatval( $rect->getAttribute( 'x' ) ?: 0 );
                $ry    = floatval( $rect->getAttribute( 'y' ) ?: 0 );
                $rw    = floatval( $rect->getAttribute( 'width' ) ?: 100 );
                $rh    = floatval( $rect->getAttribute( 'height' ) ?: 100 );
                $all_d = 'M' . $rx . ' ' . $ry . ' L' . ( $rx + $rw ) . ' ' . $ry .
                    ' L' . ( $rx + $rw ) . ' ' . ( $ry + $rh ) . ' L' . $rx . ' ' . ( $ry + $rh ) . ' Z';
            }
        }

        return trim( $all_d );
    }

    private function ha_arc_path( $cx, $cy, $rx, $ry ) {
        $r = function ( $n ) {return round( $n * 10 ) / 10;};

        return 'M' . $cx . ' ' . $r( $cy - $ry ) .
            ' A' . $rx . ' ' . $ry . ' 0 0 1 ' . $r( $cx + $rx ) . ' ' . $cy .
            ' A' . $rx . ' ' . $ry . ' 0 0 1 ' . $cx . ' ' . $r( $cy + $ry ) .
            ' A' . $rx . ' ' . $ry . ' 0 0 1 ' . $r( $cx - $rx ) . ' ' . $cy .
            ' A' . $rx . ' ' . $ry . ' 0 0 1 ' . $cx . ' ' . $r( $cy - $ry ) . ' Z';
    }

    private function ha_resolve_global_color( $color_value, $globals = [] ) {
        if ( empty( $color_value ) || ! is_string( $color_value ) ) {
            return $color_value;
        }

        if ( 0 !== strpos( $color_value, 'globals/colors?id=' ) ) {
            return $color_value;
        }

        $global_id = substr( $color_value, strlen( 'globals/colors?id=' ) );

        if ( empty( $global_id ) || empty( $globals[ $global_id ] ) ) {
            return '';
        }

        return $globals[ $global_id ];
    }

    private function ha_get_raw_shape( $raw_settings, $index ) {
        if ( ! empty( $raw_settings['morph_shapes'][ $index ] ) && is_array( $raw_settings['morph_shapes'][ $index ] ) ) {
            return $raw_settings['morph_shapes'][ $index ];
        }

        return [];
    }

    private function ha_get_control_global_ref( $item_globals, $control_name, $fallback_value ) {
        if ( ! empty( $item_globals[ $control_name ] ) && is_string( $item_globals[ $control_name ] ) ) {
            return $item_globals[ $control_name ];
        }

        return $fallback_value;
    }

    private function ha_get_active_kit_colors() {
        $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();

        $colors = [];

        foreach ( [ 'system_colors', 'custom_colors' ] as $setting_key ) {
            $items = $kit->get_settings_for_display( $setting_key );

            if ( ! is_array( $items ) ) {
                continue;
            }

            foreach ( $items as $item ) {
                if ( ! empty( $item['_id'] ) && ! empty( $item['color'] ) ) {
                    $colors[ $item['_id'] ] = $item['color'];
                }
            }
        }

        return $colors;
    }

    private function ha_get_uploaded_svg_path( $attachment_id ) {
        if ( !$attachment_id ) {
            return '';
        }

        $file_path = get_attached_file( $attachment_id );
        if ( !$file_path || !file_exists( $file_path ) ) {
            return '';
        }

        $svg_content = file_get_contents( $file_path );

        return $this->ha_parse_svg_path_data( $svg_content );
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $global_colors = $this->ha_get_active_kit_colors();
        $raw_settings  = $this->get_raw_data()['settings'] ?? [];
        $settings_globals = ! empty( $settings['__globals__'] ) && is_array( $settings['__globals__'] )
            ? $settings['__globals__']
            : [];

        $common_solid_raw = $this->ha_get_control_global_ref(
            $settings_globals,
            'common_solid_color',
            ! empty( $raw_settings['common_solid_color'] ) ? $raw_settings['common_solid_color'] : ''
        );

        $common_grad_1_raw = $this->ha_get_control_global_ref(
            $settings_globals,
            'common_gradient_color_1',
            ! empty( $raw_settings['common_gradient_color_1'] ) ? $raw_settings['common_gradient_color_1'] : ''
        );

        $common_grad_2_raw = $this->ha_get_control_global_ref(
            $settings_globals,
            'common_gradient_color_2',
            ! empty( $raw_settings['common_gradient_color_2'] ) ? $raw_settings['common_gradient_color_2'] : ''
        );

        $resolved_common_solid = $this->ha_resolve_global_color( $common_solid_raw, $global_colors );
        if ( ! empty( $resolved_common_solid ) ) {
            $settings['common_solid_color'] = $resolved_common_solid;
        }

        $resolved_common_grad_1 = $this->ha_resolve_global_color( $common_grad_1_raw, $global_colors );
        if ( ! empty( $resolved_common_grad_1 ) ) {
            $settings['common_gradient_color_1'] = $resolved_common_grad_1;
        }

        $resolved_common_grad_2 = $this->ha_resolve_global_color( $common_grad_2_raw, $global_colors );
        if ( ! empty( $resolved_common_grad_2 ) ) {
            $settings['common_gradient_color_2'] = $resolved_common_grad_2;
        }

        $shapes = [];
        if ( !empty( $settings['morph_shapes'] ) ) {
            foreach ( $settings['morph_shapes'] as $index => $shape ) {
                $path_d = '';

                if ( $shape['svg_source'] === 'upload' && !empty( $shape['svg_upload']['id'] ) ) {
                    $path_d = $this->ha_get_uploaded_svg_path( $shape['svg_upload']['id'] );
                } else {
                    $path_d = $this->ha_parse_svg_path_data( $shape['custom_svg_code'] );
                }

                if ( empty( $path_d ) ) {
                    continue;
                }

                $shape_name = !empty( $shape['svg_name'] ) ? $shape['svg_name'] : 'Shape ' . ( $index + 1 );

                $shape_data = [
                    'name' => $shape_name,
                    'd'    => $path_d
                ];

                $shape_data['fillType'] = !empty( $shape['shape_gradient_type'] ) ? $shape['shape_gradient_type'] : null;

                $raw_shape  = $this->ha_get_raw_shape( $raw_settings, $index );
                $row_globals = ! empty( $raw_shape['__globals__'] ) && is_array( $raw_shape['__globals__'] )
                    ? $raw_shape['__globals__']
                    : [];

                if ( $shape_data['fillType'] === 'solid' ) {
                    $raw_solid = $this->ha_get_control_global_ref(
                        $row_globals,
                        'shape_solid_color',
                        ! empty( $shape['shape_solid_color'] )
                            ? $shape['shape_solid_color']
                            : ( ! empty( $raw_shape['shape_solid_color'] ) ? $raw_shape['shape_solid_color'] : '' )
                    );

                    $resolved_solid = $this->ha_resolve_global_color( $raw_solid, $global_colors );
                    $shape_data['solidColor'] = ! empty( $resolved_solid )
                        ? $resolved_solid
                        : ( ! empty( $raw_solid ) ? $raw_solid : '#fb8305' );
                } elseif ( in_array( $shape_data['fillType'], ['linear', 'radial'], true ) ) {
                    $raw_stop_1 = $this->ha_get_control_global_ref(
                        $row_globals,
                        'shape_gradient_color_1',
                        ! empty( $shape['shape_gradient_color_1'] )
                            ? $shape['shape_gradient_color_1']
                            : ( ! empty( $raw_shape['shape_gradient_color_1'] ) ? $raw_shape['shape_gradient_color_1'] : '' )
                    );

                    $raw_stop_2 = $this->ha_get_control_global_ref(
                        $row_globals,
                        'shape_gradient_color_2',
                        ! empty( $shape['shape_gradient_color_2'] )
                            ? $shape['shape_gradient_color_2']
                            : ( ! empty( $raw_shape['shape_gradient_color_2'] ) ? $raw_shape['shape_gradient_color_2'] : '' )
                    );

                    $resolved_stop_1 = $this->ha_resolve_global_color( $raw_stop_1, $global_colors );
                    $resolved_stop_2 = $this->ha_resolve_global_color( $raw_stop_2, $global_colors );

                    $shape_data['gradientAngle'] = floatval( $shape['shape_gradient_angle'] ?? 45 );
                    $shape_data['gradientStops'] = [
                        [
                            'color'  => ! empty( $resolved_stop_1 ) ? $resolved_stop_1 : ( ! empty( $raw_stop_1 ) ? $raw_stop_1 : '#ff8709' ),
                            'offset' => floatval( $shape['shape_gradient_color_1_stop'] ?? 0.2 )
                        ],
                        [
                            'color'  => ! empty( $resolved_stop_2 ) ? $resolved_stop_2 : ( ! empty( $raw_stop_2 ) ? $raw_stop_2 : '#f7bdf8' ),
                            'offset' => floatval( $shape['shape_gradient_color_2_stop'] ?? 0.7 )
                        ]
                    ];
                }

                $shapes[] = $shape_data;
            }
        }

        if ( count( $shapes ) < 2 ) {
            echo '<div class="ha-morph-svg-wrapper"><p class="ha-morph-svg-notice">' .
            esc_html__( 'Please add at least 2 SVG shapes for morph animation.', 'happy-addons-pro' ) .
                '</p></div>';

            return;
        }

        $morph_data = [
            'shapes'         => $shapes,
            'animation'      => [
                'duration'    => floatval( $settings['morph_duration'] ?? 2 ),
                'repeatDelay' => floatval( $settings['morph_repeat_delay'] ?? 0.5 ),
                'stagger'     => floatval( $settings['morph_stagger'] ?? 0.5 ),
                'speed'       => floatval( $settings['morph_speed'] ?? 1 ),
                'autoPlay'    => ( $settings['morph_autoplay'] ?? 'true' ) === 'true',
                'yoyo'        => ( $settings['morph_yoyo'] ?? 'true' ) === 'true',
                'ease'        => $settings['morph_ease'] ?? 'expo.inOut'
            ],
            'canvas'         => [
                'width'      => $settings['morph_svg_width'] ?? ['size' => 100, 'unit' => 'px'],
                'height'     => $settings['morph_svg_height'] ?? ['size' => 100, 'unit' => 'px'],
                'svgScale'   => $settings['morph_svg_scale'] ?? ['size' => 100, 'unit' => '%'],
            ],
            'commonGradient' => [
                'type'       => $settings['common_gradient_type'] ?? 'linear',
                'solidColor' => $settings['common_solid_color'] ?? '#fb8305',
                'angle'      => floatval( $settings['common_gradient_angle'] ?? 45 ),
                'stops'      => [
                    [
                        'color'  => $settings['common_gradient_color_1'] ?? '#ff8709',
                        'offset' => floatval( $settings['common_gradient_color_1_stop'] ?? 0.2 )
                    ],
                    [
                        'color'  => $settings['common_gradient_color_2'] ?? '#f7bdf8',
                        'offset' => floatval( $settings['common_gradient_color_2_stop'] ?? 0.7 )
                    ]
                ]
            ]
        ];

        ?>
        <div class="ha-morph-svg-wrapper" data-morph-settings="<?php echo esc_attr( wp_json_encode( $morph_data ) ); ?>">
            <canvas class="ha-morph-svg-canvas"></canvas>
        </div>
        <?php
            }

        }