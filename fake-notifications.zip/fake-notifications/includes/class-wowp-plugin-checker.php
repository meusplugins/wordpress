<?php

/**
 * Class WOWP_Plugin_Checker
 *
 * This class is responsible for checking the license key of the plugin
 *
 * @package    WowPlugin
 * @subpackage Updater
 * @author     Dmytro Lobov <dev@wow-company.com>, Wow-Company
 * @copyright  2024 Dmytro Lobov
 * @license    GPL-2.0+
 */

namespace HerdEffectsPro;

defined( 'ABSPATH' ) || exit;

use HerdEffectsPro\Admin\DashboardHelper;
use HerdEffectsPro\Admin\Link;

class WOWP_Plugin_Checker {
	public function __construct() {
		add_filter( WOWP_Plugin::PREFIX . '_admin_filter_file', [ $this, 'filter_file' ], 10, 2 );
		add_action( 'admin_init', array( $this, 'register_option' ) );
		add_action( 'admin_init', array( $this, 'activate_license' ) );
		add_action( 'admin_init', array( $this, 'deactivate_license' ) );
		add_action( 'admin_notices', [ $this, 'admin_notices' ] );
		register_deactivation_hook( WOWP_Plugin::file(), array( $this, 'deactivate_plugin' ) );
		add_filter( WOWP_Plugin::PREFIX . '_conditions', [ $this, 'check_license' ], 10 );
	}

	public function filter_file( $file, $current ) {
		if ( ( $current === 'list' || $current === 'settings' ) && ! self::key() ) {
			return DashboardHelper::get_file( 'license', 'pages' );
		}

		return $file;
	}

	public static function key(): bool {
		$license = get_option( 'wow_license_key_' . WOWP_Plugin::PREFIX );
		$status  = get_option( 'wow_license_status_' . WOWP_Plugin::PREFIX );

		return ! empty( $license ) && $status === 'valid';
	}


	public function register_option(): void {
		register_setting( 'wow_license_' . WOWP_Plugin::PREFIX, 'wow_license_key_' . WOWP_Plugin::PREFIX, [
			$this,
			'sanitize_license'
		] );
	}

	public function sanitize_license( $new ) {
		$old = get_option( 'wow_license_key_' . WOWP_Plugin::PREFIX );
		if ( $old && $old !== $new ) {
			delete_option( 'wow_license_status_' . WOWP_Plugin::PREFIX );
		}

		return $new;
	}


	public function activate_license() {
		$action = WOWP_Plugin::PREFIX . '_license_activation';

		if ( ! isset( $_POST[ $action ] ) ) {
			return false;
		}

		if ( ! check_admin_referer( WOWP_Plugin::PREFIX . '_nonce', $action ) ) {
			return false;
		}


		$license = ! empty( $_POST[ 'wow_license_key_' . WOWP_Plugin::PREFIX ] ) ? sanitize_text_field( $_POST[ 'wow_license_key_' . WOWP_Plugin::PREFIX ] ) : '';

		if ( ! $license ) {
			return;
		}

		$license = trim( $license );

		$api_params = array(
			'action'        => 'activate',
			'purchase_code' => $license,
			'site'          => home_url(),
		);

		$response = wp_remote_post( WOWP_Plugin::info( 'store' ),
			[
				'timeout'   => 60,
				'sslverify' => false,
				'body'      => $api_params,
			]
		);

		$result = json_decode( wp_remote_retrieve_body( $response ) );

		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.', 'floating-button' );
			}
		} else {
			if ( $result->purshase_status !== 'ok' ) {
				$message = $result->message;
			}
		}

		if ( ! empty( $message ) ) {
			$redirect = Link::create( [
				'tab'           => 'license',
				'sl_activation' => 'false',
				'prefix'        => WOWP_Plugin::PREFIX,
				'messanger'     => rawurlencode( $message )
			] );

			wp_safe_redirect( $redirect );
			exit();
		}

		update_option( 'wow_license_key_' . WOWP_Plugin::PREFIX, $license );

		update_option( 'wow_license_status_' . WOWP_Plugin::PREFIX, $result->license );
		wp_safe_redirect( Link::create( [ 'tab' => 'list' ] ) );
		exit();
	}

	public function deactivate_license() {
		$action = WOWP_Plugin::PREFIX . '_license_deactivated';

		if ( ! isset( $_POST[ $action ] ) ) {
			return false;
		}

		if ( ! check_admin_referer( WOWP_Plugin::PREFIX . '_nonce', $action ) ) {
			return false;
		}

		$license = ! empty( $_POST[ 'wow_license_key_' . WOWP_Plugin::PREFIX ] ) ? sanitize_text_field( $_POST[ 'wow_license_key_' . WOWP_Plugin::PREFIX ] ) : '';


		if ( ! $license ) {
			return;
		}

		$license = trim( $license );

		$api_params = array(
			'action'        => 'disabled',
			'purchase_code' => $license,
			'site'          => home_url()
		);

		$response = wp_remote_post(
			WOWP_Plugin::info( 'store' ),
			array(
				'timeout'   => 60,
				'sslverify' => false,
				'body'      => $api_params,
			)
		);


		// make sure the response came back okay
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$message = __( 'An error occurred, please try again.', 'floating-button' );
			}

			$redirect = Link::create( [
				'tab'           => 'license',
				'sl_activation' => 'false',
				'prefix'        => WOWP_Plugin::PREFIX,
				'messanger'     => rawurlencode( $message )
			] );

			wp_safe_redirect( $redirect );
			exit();
		}

		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if ( $license_data->license == 'deactivated' ) {
			delete_option( 'wow_license_status_' . WOWP_Plugin::PREFIX, );
		}

		wp_safe_redirect( Link::create( [ 'tab' => 'license' ] ) );
		exit();
	}

	public function deactivate_plugin(): void {
		$license = trim( get_option( 'wow_license_key_' . WOWP_Plugin::PREFIX ) );

		$api_params = array(
			'action'        => 'disabled',
			'purchase_code' => $license,
			'site'          => home_url()
		);

		$response = wp_remote_post(
			WOWP_Plugin::info( 'store' ),
			array(
				'timeout'   => 60,
				'sslverify' => false,
				'body'      => $api_params,
			)
		);


		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		// $license_data->license will be either "deactivated" or "failed"
		if ( $license_data->license == 'deactivated' ) {
			delete_option( 'wow_license_status_' . WOWP_Plugin::PREFIX, );
		}
	}

	public function admin_notices(): void {
		if ( isset( $_GET['sl_activation'] ) && ! empty( $_GET['messanger'] ) && WOWP_Plugin::PREFIX === $_GET['prefix'] ) {
			switch ( $_GET['sl_activation'] ) {
				case 'false':
					$message = urldecode( $_GET['messanger'] );
					?>
                    <div class="error">
                        <p><?php
							echo wp_kses_post( $message ); ?></p>
                    </div>
					<?php
					break;

				case 'true':
				default:
					// Developers can put a custom success message here for when activation is successful if they way.
					break;
			}
		}
	}

	public function check_license( $check ) {
		$license = get_option( 'wow_license_key_' . WOWP_Plugin::PREFIX );
		$status  = get_option( 'wow_license_status_' . WOWP_Plugin::PREFIX );

		$check['license'] = ! empty( $license ) && $status === 'valid';

		return $check;
	}
}