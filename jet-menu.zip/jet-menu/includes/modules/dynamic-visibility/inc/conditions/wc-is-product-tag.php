<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class WC_Is_Product_Tag extends Base_Condition {

	public function get_key() {
		return 'wc_is_product_tag';
	}

	public function check( $rule, $context ) {
		return function_exists( 'is_product_tag' ) ? is_product_tag() : false;
	}
}
