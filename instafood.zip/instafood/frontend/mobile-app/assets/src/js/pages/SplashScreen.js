class SplashScreen {

    constructor(height, width) {
        if (!jQuery('.apt-splashscreen')[0]) {
            return;
        }
        this.splashscreen = jQuery('.apt-splashscreen');
        this.logoUI = this.splashscreen.find('.apt-logo-ui');
    }

    start() {
        if (!this.splashscreen) {
            return;
        }

        const _this = this;
        const logoUrl = this.logoUI.attr('data-logourl');
        this.imgUI = jQuery(`<img src="${logoUrl}" alt="">`);
        this.imgUI.bind('load', function() {
            _this.logoUI.animate({
                opacity: 1, 
            }, 1300, 'swing', function() {
                _this.logoUI.addClass('scale-out');
                _this.splashscreen.animate({
                    opacity: 0
                }, 700, function() {
                    _this.splashscreen.remove();
                });
            });
        });
        this.imgUI.appendTo(this.logoUI);
    }
}
export default SplashScreen;