<?php
namespace com\sakuraplugins\appetit\cpt;
if ( ! defined('ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . 'GenericPostType.php');
require_once(plugin_dir_path(__FILE__) . 'ICpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../utils/UserManagement.php');

use com\sakuraplugins\appetit\utils\OptionUtil as OptionUtil;
use com\sakuraplugins\appetit\utils\UserManagement;

class MenuItemCpt extends GenericPostType implements ICpt {

    const REWRITE_KEY = 'MENU_ITEM_REWRITE_KEY';
    const DEFAULT_REWRITE_SLUG = 'menu-items';

    const MENU_CAT_DEFAULT_REWRITE_SLUG = 'menu-category';
    const MENU_CAT_SLUG = 'appetit_items_category';
    const MENU_CAT_META_KEY = 'appetit_items_category_meta';


    public static function getMetaKey(): string {
        return 'appetit_item_meta';
    }

    public static function getPostType(): string {
        return 'appetit_item';
    }

    public static function getPostTypePlural(): string {
        return 'appetit_items';
    }

    public static function CPTSupports(): array {
        return ['title', 'thumbnail'];
    }

    static function getCategoryCaps() {
        return [
            'manage_terms' => 'manage_' . self::MENU_CAT_SLUG,
            'edit_terms' => 'edit_' . self::MENU_CAT_SLUG,
            'delete_terms' => 'delete_' . self::MENU_CAT_SLUG,
            'assign_terms' => 'assign_' . self::MENU_CAT_SLUG,
        ];
    }

    public function getSettings($rewrite, $menuPosition = 80): array {
        $labels = [
            'name'               => _x('InstaFood products', 'post type general name', 'instafood'),
            'singular_name'      => _x('InstaFood product', 'post type singular name', 'instafood'),
            'menu_name'          => _x('InstaFood products', 'admin menu', 'instafood'),
            'name_admin_bar'     => _x('InstaFood product', 'add new on admin bar', 'instafood'),
            'add_new'            => _x('Add new item', 'add new item' , 'instafood'),
            'add_new_item'       => esc_html__('Add New item ', 'instafood'),
            'new_item'           => esc_html__('New InstaFood product', 'instafood'),
            'edit_item'          => esc_html__('Edit InstaFood product', 'instafood'),
            'view_item'          => esc_html__('View InstaFood product', 'instafood'),
            'all_items'          => esc_html__('All InstaFood products', 'instafood'),
            'search_items'       => esc_html__('Search InstaFood products', 'instafood'),
            'parent_item_colon'  => esc_html__('Parent InstaFood products', 'instafood'),
            'not_found'          => esc_html__('No InstaFood products found.', 'instafood'),
            'not_found_in_trash' => esc_html__('No InstaFood products found in Trash.', 'instafood' )
        ];

        $capabilities = UserManagement::compile_post_type_capabilities(self::getPostType(), self::getPostTypePlural());
    
        $args = [
            'capabilities' => $capabilities,
            'labels'             => $labels,
            'description'        => esc_html__('Description', 'instafood'),
            'public'             => false,
            'publicly_queryable' => false,
            'show_in_rest' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => $rewrite),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => $menuPosition,
            'supports'           => self::CPTSupports(),
        ];
        return $args;
    }

    public static function getTaxonomySettings(): array {

        $labels = [
            'name'              => _x( 'Menu categories', 'taxonomy general name', 'instafood' ),
            'singular_name'     => _x( 'Menu category', 'taxonomy singular name', 'instafood' ),
            'search_items'      => esc_html__( 'Search Menu category', 'instafood' ),
            'all_items'         => esc_html__( 'All Menu categories', 'instafood' ),
            'parent_item'       => esc_html__( 'Parent Menu category', 'instafood' ),
            'parent_item_colon' => esc_html__( 'Parent Menu category:', 'instafood' ),
            'edit_item'         => esc_html__( 'Edit Menu category', 'instafood' ),
            'update_item'       => esc_html__( 'Update Menu category', 'instafood' ),
            'add_new_item'      => esc_html__( 'Add new Menu category', 'instafood' ),
            'new_item_name'     => esc_html__( 'New Menu category', 'instafood' ),
            'menu_name'         => esc_html__( 'Menu categories', 'instafood' ),
        ];
        
        $args = [
            'capabilities' => self::getCategoryCaps(),
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'meta_box_cb'       => false,
            'show_admin_column' => true,
            'query_var'         => true,
            'show_tagcloud' => false,
            'has_archive' => false,
            'with_front' => true,
        ];
        return $args;
    }

    public static function registerTaxonomies(): void {
        $rewrite = OptionUtil::getInstance()->getOption('appetit_category_rewrite', self::MENU_CAT_DEFAULT_REWRITE_SLUG);

        register_taxonomy(
            self::MENU_CAT_SLUG,
            self::getPostType(), array_merge(self::getTaxonomySettings(), [
                'rewrite' => ['slug' => $rewrite],
                'show_ui' => true,
            ])
        );
    }
}

?>
