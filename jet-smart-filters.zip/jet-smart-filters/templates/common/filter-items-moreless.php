<?php
/**
 * Filter items moreless template
 */

if ( empty( $args['less_items_count'] ) || $args['less_items_count'] > count( $options ) ) {
	return;
}

$less_items_count = $args['less_items_count'];
$more_text        = $args['more_text'];
$less_text        = $args['less_text'];

?>
<div
	class="jet-filter-items-moreless"
	data-less-items-count="<?php echo esc_attr( $less_items_count ); ?>"
	data-more-text="<?php echo esc_attr( $more_text ); ?>"
	data-less-text="<?php echo esc_attr( $less_text ); ?>"
	role="button"
	aria-expanded="false"
	<?php
	// Tabindex attribute is generated internally and considered safe.
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo jet_smart_filters()->data->get_tabindex_attr();
	?>
>
	<div class="jet-filter-items-moreless__toggle">
		<?php echo esc_html( $more_text ); ?>
	</div>
</div>
