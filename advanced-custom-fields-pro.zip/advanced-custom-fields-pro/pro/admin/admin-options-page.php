<?php
/**
 * @package ACF
 * @author  WP Engine
 *
 * © 2026 Advanced Custom Fields (ACF®). All rights reserved.
 * "ACF" is a trademark of WP Engine.
 * Licensed under the GNU General Public License v2 or later.
 * https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'acf_admin_options_page' ) ) :

	class acf_admin_options_page {

		/** @var array Contains the current options page */
		var $page;


		/**
		 * Initialize filters, action, variables and includes
		 *
		 * @since   5.0.0
		 */
		public function __construct() {
			// add menu items
			add_action( 'admin_menu', array( $this, 'admin_menu' ), 99, 0 );
		}


		/**
		 * description
		 *
		 * @since   5.0.0
		 */
		public function admin_menu() {

			// vars
			$pages = acf_get_options_pages();

			// bail early if no pages
			if ( empty( $pages ) ) {
				return;
			}

			// loop
			foreach ( $pages as $page ) {

				// vars
				$slug = '';
				// parent
				if ( empty( $page['parent_slug'] ) ) {
					$slug = add_menu_page( $page['page_title'], $page['menu_title'], $page['capability'], $page['menu_slug'], array( $this, 'html' ), $page['icon_url'], $page['position'] );
					// child
				} else {
					$slug = add_submenu_page( $page['parent_slug'], $page['page_title'], $page['menu_title'], $page['capability'], $page['menu_slug'], array( $this, 'html' ), $page['position'] );
				}

				// actions
				add_action( "load-{$slug}", array( $this, 'admin_load' ) );
			}
		}


		/**
		 * description
		 *
		 * @type    function
		 * @date    2/02/13
		 * @since   3.6
		 *
		 * @param   $post_id (int)
		 * @return  $post_id (int)
		 */
		function admin_load() {

			// globals
			global $plugin_page;

			// vars
			$this->page = acf_get_options_page( $plugin_page );

			// get post_id (allow lang modification)
			$this->page['post_id'] = acf_get_valid_post_id( $this->page['post_id'] );

			// verify and remove nonce
			if ( acf_verify_nonce( 'options' ) ) {

				// Restrict submitted values to fields belonging to field groups assigned to the current options page.
				// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above via acf_verify_nonce().
				if ( isset( $_POST['acf'] ) && is_array( $_POST['acf'] ) ) {
					$_POST['acf'] = $this->filter_options_page_field_values( $_POST['acf'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Sanitized downstream; save pipeline expects slashed input.
				}
				// phpcs:enable WordPress.Security.NonceVerification.Missing

				// save data
				if ( acf_validate_save_post( true ) ) {

					// set autoload
					acf_update_setting( 'autoload', $this->page['autoload'] );

					// save
					acf_save_post( $this->page['post_id'] );

					/**
					 * Fires after publishing a save on an options page.
					 *
					 * @since 6.1.7
					 *
					 * @param string|int  $post_id   The current id.
					 * @param string      $menu_slug The current options page menu slug.
					 */
					do_action( 'acf/options_page/save', $this->page['post_id'], $this->page['menu_slug'] );

					// redirect
					wp_safe_redirect( add_query_arg( array( 'message' => '1' ) ) );
					exit;
				}
			}

			// load acf scripts
			acf_enqueue_scripts();

			// Localize options page slug for repeater pagination capability checks.
			acf_localize_data( array( 'options_page_slug' => $this->page['menu_slug'] ) );

			// actions
			add_action( 'acf/input/admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
			add_action( 'acf/input/admin_head', array( $this, 'admin_head' ) );

			// add columns support
			add_screen_option(
				'layout_columns',
				array(
					'max'     => 2,
					'default' => 2,
				)
			);
		}


		/**
		 * This function will enqueue the 'post.js' script which adds support for 'Screen Options' column toggle
		 *
		 * @since   5.3.2
		 */
		public function admin_enqueue_scripts() {

			wp_enqueue_script( 'post' );
		}


		/**
		 * This action will find and add field groups to the current edit page
		 *
		 * @type    action (admin_head)
		 * @since   3.1.8
		 */
		public function admin_head() {

			// get field groups
			$field_groups = acf_get_field_groups(
				array(
					'options_page' => $this->page['menu_slug'],
				)
			);

			// notices
			if ( ! empty( $_GET['message'] ) && $_GET['message'] == '1' ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Used to display a notice.
				acf_add_admin_notice( $this->page['updated_message'], 'success' );
			}

			// add submit div
			add_meta_box( 'submitdiv', __( 'Publish', 'acf' ), array( $this, 'postbox_submitdiv' ), 'acf_options_page', 'side', 'high' );

			if ( empty( $field_groups ) ) {
				acf_add_admin_notice( sprintf( __( 'No Custom Field Groups found for this options page. <a href="%s">Create a Custom Field Group</a>', 'acf' ), admin_url( 'post-new.php?post_type=acf-field-group' ) ), 'warning' );
			} else {
				foreach ( $field_groups as $i => $field_group ) {
					$id       = "acf-{$field_group['key']}";
					$context  = $field_group['position'];
					$priority = 'high';
					$args     = array( 'field_group' => $field_group );

					// tweaks to vars
					if ( $context == 'acf_after_title' ) {
						$context = 'normal';
					} elseif ( $context == 'side' ) {
						$priority = 'core';
					}

					// filter for 3rd party customization
					$priority = apply_filters( 'acf/input/meta_box_priority', $priority, $field_group );

					// add meta box
					add_meta_box(
						$id,
						acf_esc_html( acf_get_field_group_title( $field_group ) ),
						array( $this, 'postbox_acf' ),
						'acf_options_page',
						$context,
						$priority,
						$args
					);
				}
				// foreach
			}
			// if
		}


		/**
		 * This function will render the submitdiv metabox
		 *
		 * @type    function
		 * @date    23/03/2016
		 * @since   5.3.2
		 *
		 * @param   n/a
		 * @return  n/a
		 */
		function postbox_submitdiv( $post, $args ) {

			/**
			*  Fires before the major-publishing-actions div.
			*
			* @date    24/9/18
			* @since   5.7.7
			*
			* @param array $page The current options page.
			*/
			do_action( 'acf/options_page/submitbox_before_major_actions', $this->page );
			?>
		<div id="major-publishing-actions">

			<div id="publishing-action">
				<span class="spinner"></span>
				<input type="submit" accesskey="p" value="<?php echo esc_attr( $this->page['update_button'] ); ?>" class="button button-primary button-large" id="publish" name="publish">
			</div>
			
			<?php
			/**
			 *  Fires before the major-publishing-actions div.
			 *
			 * @date    24/9/18
			 * @since   5.7.7
			 *
			 * @param array $page The current options page.
			 */
			do_action( 'acf/options_page/submitbox_major_actions', $this->page );
			?>
			<div class="clear"></div>
		
		</div>
			<?php
		}


		/**
		 * Renders a postbox on an ACF options page.
		 *
		 * @since   5.0.0
		 *
		 * @param object $post The post object
		 * @param array  $args The metabox arguments
		 */
		public function postbox_acf( $post, $args ) {
			$id          = $args['id'];
			$field_group = $args['args']['field_group'];

			// vars
			$o = array(
				'id'         => $id,
				'key'        => $field_group['key'],
				'style'      => $field_group['style'],
				'label'      => $field_group['label_placement'],
				'editLink'   => '',
				'editTitle'  => __( 'Edit field group', 'acf' ),
				'visibility' => true,
			);

			// edit_url
			if ( $field_group['ID'] && acf_current_user_can_admin() ) {
				$o['editLink'] = admin_url( 'post.php?post=' . $field_group['ID'] . '&action=edit' );
			}

			// load fields
			$fields = acf_get_fields( $field_group );

			// render
			acf_render_fields( $fields, $this->page['post_id'], 'div', $field_group['instruction_placement'] );

			?>
<script type="text/javascript">
if( typeof acf !== 'undefined' ) {
		
	acf.newPostbox(<?php echo json_encode( $o ); ?>);	

}
</script>
			<?php
		}


		/**
		 * Returns the field groups assigned to the current options page.
		 *
		 * Used to derive the set of $_POST['acf'] keys the current save is allowed
		 * to accept — see get_options_page_allowed_field_keys().
		 *
		 * @since 6.8.7
		 *
		 * @return array
		 */
		protected function get_options_page_field_groups() {
			return acf_get_field_groups(
				array(
					'options_page' => $this->page['menu_slug'],
				)
			);
		}

		/**
		 * Returns the top-level $_POST['acf'] keys the current options page accepts on save.
		 *
		 * Iterates the field groups assigned to this page and collects each field's top-level
		 * POST root, with special handling for seamless clone subfields whose input names nest
		 * below the parent clone's key.
		 *
		 * @since 6.8.7
		 *
		 * @return array
		 */
		protected function get_options_page_allowed_field_keys() {
			$keys = array();

			foreach ( $this->get_options_page_field_groups() as $field_group ) {
				$fields = acf_get_fields( $field_group );

				if ( ! $fields ) {
					continue;
				}

				foreach ( $fields as $field ) {
					$prefix = $field['prefix'] ?? 'acf';

					if ( $prefix === 'acf' ) {
						if ( ! empty( $field['key'] ) ) {
							$keys[] = $field['key'];
						}
					} elseif ( preg_match( '/^acf\[([^]]+)]$/', $prefix, $matches ) ) {
						$keys[] = $matches[1];
					}
				}
			}

			$keys = array_values( array_unique( array_filter( $keys ) ) );

			/**
			 * Filters the list of $_POST['acf'] keys an options page save is allowed to save.
			 *
			 * Use this to permit additional field keys when a developer dynamically injects fields
			 * into an options page via JavaScript that aren't part of any field group assigned to
			 * the page.
			 *
			 * @since 6.8.7
			 *
			 * @param array $keys The allowed top-level $_POST['acf'] keys.
			 * @param array $page The current options page configuration.
			 */
			$keys = apply_filters( 'acf/options_page/allowed_field_keys', $keys, $this->page );

			// Re-normalize after the filter so a misbehaving callback can't break array_flip()
			// downstream in admin_load() with non-scalar or empty values.
			$keys = array_filter( (array) $keys, 'is_scalar' );
			return array_values( array_unique( array_filter( array_map( 'strval', $keys ) ) ) );
		}

		/**
		 * Filters submitted ACF values to the top-level keys accepted by the current options page.
		 *
		 * @since 6.8.7
		 *
		 * @param array $values Submitted ACF values (typically $_POST['acf']).
		 * @return array
		 */
		protected function filter_options_page_field_values( array $values ): array {
			return array_intersect_key( $values, array_flip( $this->get_options_page_allowed_field_keys() ) );
		}

		/**
		 * description
		 *
		 * @since 2.0.4
		 */
		function html() {

			// load view
			acf_get_view( __DIR__ . '/views/html-options-page.php', $this->page );
		}
	}


	// initialize
	new acf_admin_options_page();
endif;

?>
