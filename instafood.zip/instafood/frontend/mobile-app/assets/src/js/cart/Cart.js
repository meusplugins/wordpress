import CartProduct from './CartProduct';
import EventBus, { Events } from '../events/EventBus';
import ProductUtils from '../utils/ProductUtils';

let instance;
const instanceKey = '_*&*(239';

class Cart {

    _items = [];

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._items = [];
    }

    add(cartProduct) {
        if (!cartProduct instanceof CartProduct) {
            throw new Error(`Only CartProduct instances are allowed`);
        }
        const existingIndex = this._getExistingCartProductIndex(cartProduct.id);
        if (existingIndex !== -1) {
            throw new Error(`cannot allow same CartProduct instances to be added`);
        }
        this._items.push(cartProduct);
        EventBus.getInstance().triggerEvent(Events.CART_CHANGED, { cartProduct } );
        return this;
    }

    getAll() {
        return this._items;
    }

    update(cartProduct) {
        if (!cartProduct instanceof CartProduct) {
            throw new Error(`Only CartProduct instances are allowed`);
        }
        const existingIndex = this._getExistingCartProductIndex(cartProduct.id);
        if (existingIndex !== -1) {
            this._items[existingIndex] = cartProduct;
            EventBus.getInstance().triggerEvent(Events.CART_CHANGED, { cartProduct } );
        }
        return this;
    }

    remove(cartProduct) {
        const existingIndex = this._getExistingCartProductIndex(cartProduct.id);
        if (existingIndex !== -1) {
            this._items.splice(existingIndex, 1);
        }
        EventBus.getInstance().triggerEvent(Events.CART_CHANGED, { cartProduct } );
        return this;
    }

    cartHasItems() {
        return Array.isArray(this._items) && this._items.length > 0;
    }

    cartHasProduct(productId) {
        let out = false;
        if (Array.isArray(this._items)) {
            for (const cartProduct of this._items) {
                const product = cartProduct.getProduct();
                if (product.ID === productId) {
                    out = { 
                        product, 
                        quantity: cartProduct.getQuantity()
                    }
                    break;
                }
            }
        }
        return out;
    }

    cartGetExistingProducts(productId) {
        let out = [];
        if (Array.isArray(this._items)) {
            for (const cartProduct of this._items) {
                const product = cartProduct.getProduct();
                if (product.ID === productId) {
                    out.push({
                        product, 
                        quantity: cartProduct.getQuantity(),
                        productName: ProductUtils.getProductName(product)
                    })
                }
            }
        }
        return out;
    }

    getCartQuantity() {
        let q = 0;
        this._items.forEach(cartProduct => {
            q += cartProduct.getQuantity();
        })
        return q;
    }

    getCartQuantityPerProduct() {
        let out = [];
        this._items.forEach(cartProduct => {
            out.push(cartProduct.getProductAndGroupWithQuantity());
        })
        return out;
    }

    getCartItemsWithInfo() {
        const cartItemsParsedData = [];
        this._items.forEach(cartProduct => {
            const q = cartProduct.getQuantity();
            const productVariant = cartProduct.getSelectedVariantData();
            let productTitle = ProductUtils.getProductName(cartProduct.getProduct());

            const hasManyVariants = cartProduct.hasManyVariants();
            if (hasManyVariants) {
                productTitle += ` <span class="variation_info">(${ ProductUtils.getVariationName(productVariant) })</span>`;
            }
            const variantPrice = _.get(productVariant, 'price_float_val', 0);

            let cartProductTotal = variantPrice;
            let choicesInfo = ``;

            const cartGroupsWithChoices = cartProduct.getGroupsWithChoicesData();

            const choices_collection = [];
            if (Array.isArray(cartGroupsWithChoices) && cartGroupsWithChoices.length > 0) {
                cartGroupsWithChoices.forEach(cartGroupData => {
                    const { choices } = cartGroupData;
                    if (Array.isArray(choices)) {
                        choices_collection.push(...choices)
                    }
                });
            }

            if (Array.isArray(choices_collection) && choices_collection.length > 0) {
                let choiceCount = 0;
                choices_collection.forEach(choice => {
                    const choiceName = ProductUtils.getChoiceName(choice);
                    choicesInfo += `${ choiceName }${ choiceCount < choices_collection.length - 1 && choices_collection.length !== 1 ? ', ' : '' }`;
                    cartProductTotal += _.get(choice, 'price_float_val', 0);
                    choiceCount++;
                });
            }
            cartItemsParsedData.push({
                cartProduct,
                cartItemTotal: q * cartProductTotal,
                choicesInfo,
                quantity: q,
                productTitle: productTitle,
            })
        })
        return cartItemsParsedData;
    }

    getCartTotal() {
        let total = 0;
        this._items.forEach(cartProduct => {
            const productTotal = cartProduct.getTotal();
            total += productTotal;
        })
        return total;
    }

    _getExistingCartProductIndex(id) {
        let index = -1;
        for (let i = 0; i < this._items.length; i++) {
            const cartProduct = this._items[i];
            if (cartProduct.id === id) {
                index = i;
                break;
            }
        }
        return index;
    }

    empty() {
        this._items = [];
        EventBus.getInstance().triggerEvent(Events.CART_CHANGED, {} );
    }

    static getInstance() {
        if (!instance) {
            instance = new Cart(instanceKey);
        }
        return instance;
    }
}
export default Cart;