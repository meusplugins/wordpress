<?php

namespace WPML\PB;

class OldPlugin {

	public static function handle() {
		if (
			defined( 'WPML_PAGE_BUILDERS_VERSION' )
			&& version_compare( constant( 'WPML_PAGE_BUILDERS_VERSION' ), '2', '<' )
		) {
			deactivate_plugins( 'wpml-page-builders/plugin.php' );
			self::addNotice();
			if ( ! wpml_is_cli() && wp_safe_redirect( $_SERVER['REQUEST_URI'], 302, 'wpml' ) ) {
				die;
			}

			return true;
		}

		return false;
	}

	private static function addNotice() {
		/* translators: Heading of the admin notice shown when the separate WPML Page Builders plugin is too old and WPML has switched it off. It is a product name and stays in English. */
		$text = '<h2>' . __( 'Update needed for WPML Page Builders plugin', 'sitepress' ) . '</h2>';
		/* translators: First paragraph of that notice. */
		$text .= '<p>' . __( 'To prevent conflicts with WPML, we have deactivated your outdated WPML Page Builders plugin. Please update and reactivate it to continue receiving compatibility updates for your page builders as they become available.', 'sitepress' ) . '</p>';
		/* translators: Second paragraph of that notice. */
		$text .= '<p>' . __( 'You can still receive compatibility updates without WPML Page Builders as part of the WPML core plugin. However, keeping the standalone plugin allows you to receive these updates sooner and more often.', 'sitepress' ) . '</p>';

		$notices = wpml_get_admin_notices();
		$notice  = $notices->create_notice( 'deactivated-notice', $text, __CLASS__ );
		$notice->set_flash();
		$notice->set_hideable( true );
		$notice->set_css_class_types( [ 'notice-info' ] );
		$notices->add_notice( $notice );
	}
}
