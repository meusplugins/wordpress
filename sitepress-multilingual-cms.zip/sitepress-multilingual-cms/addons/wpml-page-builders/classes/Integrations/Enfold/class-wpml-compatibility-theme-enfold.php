<?php

class WPML_Compatibility_Theme_Enfold {

	public function init_hooks() {
		add_action( 'wp_insert_post', [ $this, 'wp_insert_post_action' ], 10, 2 );
		add_filter( 'wpml_pb_before_replace_string_with_translation', [ $this, 'replace_single_quotes' ], 10, 2 );
		add_filter( 'wpml_pb_shortcode_content_for_translation', [ $this, 'get_content_from_custom_field' ], 10, 2 );
		add_action( 'icl_make_duplicate', [ $this, 'sync_duplicate' ], 10, 4 );
		add_filter( 'wpml_pb_is_post_built_with_shortcodes', [ $this, 'isPostBuiltWithShortcodes' ], 10, 2 );
	}

	public function wp_insert_post_action( $post_id, $post ) {
		if ( (int) $post_id <= 0 || ! $post instanceof WP_Post ) {
			return;
		}

		if ( $this->is_using_standard_wp_editor() || wp_is_post_revision( $post_id ) ) {
			return;
		}

		$is_original = apply_filters( 'wpml_is_original_content', false, $post_id, 'post_' . $post->post_type );

		if ( ! $is_original ) {
			if ( $this->is_active( $post_id ) && $this->is_post_using_tm_editor( $post_id ) ) {
				update_post_meta( $post_id, '_aviaLayoutBuilderCleanData', $post->post_content );
			}
		}
	}

	public static function getPreviousRegistrationForms( $value ) {
		$decoded = html_entity_decode( $value );

		return $decoded === $value ? [] : [ $decoded ];
	}

	public function get_content_from_custom_field( $content, $post_id ) {
		if ( $this->is_active( $post_id ) ) {
			$content = str_replace( "\r\n", "\n", get_post_meta( $post_id, '_aviaLayoutBuilderCleanData', true ) );
		}

		return $content;
	}

	public function sync_duplicate( $master_post_id, $lang, $post_array, $id ) {
		if ( $this->is_active( $master_post_id ) ) {
			$duplicate_content = get_post_field( 'post_content', $id, 'raw' );
			update_post_meta( $id, '_aviaLayoutBuilderCleanData', wp_slash( $duplicate_content ) );
		}
	}

	private function is_active( $post_id ) {
		$page_builder_active         = get_post_meta( $post_id, '_aviaLayoutBuilder_active', true );
		$page_builder_shortcode_tree = get_post_meta( $post_id, '_avia_builder_shortcode_tree', true );

		return $page_builder_active && '' !== $page_builder_shortcode_tree;
	}

	private function is_using_standard_wp_editor() {
		$doc_translation_method = wpml_get_tm_sub_setting( 'doc_translation_method', ICL_TM_TMETHOD_MANUAL );

		return (string) ICL_TM_TMETHOD_MANUAL === (string) $doc_translation_method;
	}

	protected function is_post_using_tm_editor( $post_id ) {
		global $sitepress;
		$is_using_tm_editor = \WPML_TM_Post_Edit_TM_Editor_Mode::is_using_tm_editor( $sitepress, $post_id );

		return $is_using_tm_editor;
	}

	public function replace_single_quotes( $translation, $is_attribute ) {
		if ( $translation && $is_attribute ) {
			$translation = preg_replace( "/'/", '’', $translation );
		}

		return $translation;
	}

	public function isPostBuiltWithShortcodes( $isBuiltWithShortcodes, \WP_Post $post ) {
		return $isBuiltWithShortcodes || $this->is_active( $post->ID );
	}
}
