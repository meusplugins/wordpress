<?php

namespace Happy_Addons_Pro\Extensions;

// Elementor Classes.
use Elementor\Repeater;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || die();

class Global_Animation {

    /**
     * @var mixed
     */
    private static $instance = null;

    /**
     * @var mixed
     */
    private $load_script = null;

    public static function instance() {
        if ( null === ( self::$instance ) ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function init() {

        // Enqueue the required JS file.
        add_action( 'wp_enqueue_scripts', [$this, 'register_scripts'] );
        add_action( 'wp_enqueue_scripts', [$this, 'register_styles'] );

        add_action( 'elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts'] );

        // Creates Global Animation tab at the end of layout/content & section advance tab.
        // Container
        if ( defined( 'ELEMENTOR_VERSION' ) && ha_elementor()->experiments->is_feature_active( 'container' ) ) {
            add_action( 'elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 1 );
            add_action( 'elementor/frontend/container/before_render', [$this, 'before_render'] );
        }

        // Widget
        add_action( 'elementor/element/common/_section_style/after_section_end', [$this, 'register_controls'], 1 );
        add_action( 'elementor/frontend/widget/before_render', [$this, 'before_render'] );

    }

    // Register Scripts
    public function register_scripts() {
        $suffix = ha_is_script_debug_enabled() ? '.' : '.min.';

        // global-animation script so smooth scroll is not tied to a widget.
        wp_register_script(
            'happy-sms',
            HAPPY_ADDONS_PRO_ASSETS . 'js/happy-sms' . $suffix . 'js',
            ['jquery', 'gsap', 'scroll-trigger', 'ha-tamrir'],
            HAPPY_ADDONS_PRO_VERSION,
            true
        );

        wp_register_script(
            'global-animation',
            HAPPY_ADDONS_PRO_ASSETS . 'js/global-animation' . $suffix . 'js',
            ['jquery', 'happy-elementor-addons', 'gsap', 'scroll-trigger'],
            HAPPY_ADDONS_PRO_VERSION,
            true
        );
    }

    // Register Styles
    public function register_styles() {
        wp_register_style(
            'global-animation',
            HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/global-animation.min.css',
            [],
            HAPPY_ADDONS_PRO_VERSION
        );

        // Required Lenis runtime styles.
        wp_register_style(
            'happy-sms',
            HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/happy-sms.min.css',
            [],
            HAPPY_ADDONS_PRO_VERSION
        );
    }

    // Enqueue Preview Scripts
    public function enqueue_preview_scripts() {
        wp_enqueue_script( 'gsap' );
        wp_enqueue_script( 'scroll-trigger' );
        wp_enqueue_script( 'global-animation' );

        wp_enqueue_style( 'global-animation' );

        // Never run inside the Elementor preview iframe.
        if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
            return;
        }

        wp_enqueue_script( 'happy-sms' );
        wp_enqueue_style( 'happy-sms' );
    }

    public function register_controls( $element ) {

        $element->start_controls_section(
            '_ha_ga_section',
            [
                'label' => esc_html__( 'Animation', 'happy-addons-pro' ) . ha_get_section_icon(),
                'tab'   => Controls_Manager::TAB_ADVANCED
            ]
        );

        $this->add_content_controls( $element );

        $element->end_controls_section();
    }

    public function add_content_controls( $element ) {

        $element->add_control(
            'ha_ga_init_notice',
            [
                'type'       => Controls_Manager::ALERT,
                'alert_type' => 'info',
                'heading'    => __( 'Note:', 'happy-addons-pro' ),
                'content'    => sprintf(
                    __( 'For best results, avoid using Happy Animations and Sticky Pin on the same element. Need help? <a href="%s" target="_blank" rel="noopener noreferrer">Read Documentation</a>', 'happy-addons-pro' ),
                    esc_url( 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/features/global-animation/' )
                ),
            ]
        );

        $ga_switcher_terms = [
            'terms' => [
                [
                    'name'     => 'ha_ga_switcher',
                    'operator' => '===',
                    'value'    => 'yes'
                ]
            ]
        ];

        $ga_assets_scripts = [
            ['name' => 'elementor-frontend', 'conditions' => $ga_switcher_terms],
            ['name' => 'gsap', 'conditions' => $ga_switcher_terms],
            ['name' => 'scroll-trigger', 'conditions' => $ga_switcher_terms],
            ['name' => 'global-animation', 'conditions' => $ga_switcher_terms]
        ];

        $ga_assets_styles = [
            ['name' => 'global-animation', 'conditions' => $ga_switcher_terms]
        ];

        // Load Happy Sms.
        $ga_assets_scripts[] = ['name' => 'happy-sms', 'conditions' => $ga_switcher_terms];
        $ga_assets_styles[]  = ['name' => 'happy-sms', 'conditions' => $ga_switcher_terms];

        $element->add_control(
            'ha_ga_switcher',
            [
                'label'              => __( 'Enable', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'prefix_class'       => 'ha-ga-',
                'render_type'        => 'template',
                'return_value'       => 'yes',
                'style_transfer'     => true,
                'frontend_available' => true,
                'assets'             => [
                    'scripts' => $ga_assets_scripts,
                    'styles'  => $ga_assets_styles
                ]
            ]
        );

        $element->add_responsive_control(
            'ha_ga_animation',
            [
                'label'              => __( 'Animation', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'from',
                'options'            => [
                    'from' => __( 'From', 'happy-addons-pro' ),
                    'to'   => __( 'To', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_trigger_mode',
            [
                'label'              => __( 'Trigger Mode', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'scroll',
                'options'            => [
                    'scroll'         => __( 'On Appearing', 'happy-addons-pro' ),
                    'playwithscroll' => __( 'On Scroll', 'happy-addons-pro' ),
                    'onPageLoad'     => __( 'On Page Load', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_wrapper',
            [
                'label'              => __( 'Wrapper', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'default',
                'options'            => [
                    'default' => __( 'Default', 'happy-addons-pro' ),
                    'custom'  => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_ga_switcher'     => 'yes',
                    'ha_ga_trigger_mode' => ['scroll', 'playwithscroll']
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Custom wrapper settings
        $element->add_responsive_control(
            'ha_ga_anim_start',
            [
                'label'              => __( 'Animation Start', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'top-center',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'description'        => __(
                    'First value is the element position, second is the viewport position.',
                    'happy-addons-pro'
                ),
                'condition'          => [
                    'ha_ga_switcher'     => 'yes',
                    'ha_ga_wrapper'      => 'custom',
                    'ha_ga_trigger_mode' => ['scroll', 'playwithscroll']
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_anim_start_custom',
            [
                'label'              => __( 'Custom Start', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'default'            => 'top center',
                'placeholder'        => __( 'e.g., top top', 'happy-addons-pro' ),
                'description'        => __(
                    'First value is the element position, second is the viewport position. Supports offsets like "top top+=100" (100px below the viewport top) or "top top-=100" (100px above the viewport top).',
                    'happy-addons-pro'
                ),
                'condition'          => [
                    'ha_ga_switcher'   => 'yes',
                    'ha_ga_wrapper'    => 'custom',
                    'ha_ga_anim_start' => 'custom'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_anim_end',
            [
                'label'              => __( 'Animation End', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'bottom-center',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'description'        => __(
                    'First value is the element position, second is the viewport position.',
                    'happy-addons-pro'
                ),
                'condition'          => [
                    'ha_ga_switcher'     => 'yes',
                    'ha_ga_wrapper'      => 'custom',
                    'ha_ga_trigger_mode' => ['scroll', 'playwithscroll']
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_anim_end_custom',
            [
                'label'              => __( 'Custom End', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'default'            => 'bottom center',
                'placeholder'        => __( 'e.g., bottom bottom', 'happy-addons-pro' ),
                'description'        => __(
                    'First value is the element position, second is the viewport position. Supports offsets like "bottom bottom+=100" (100px below the viewport bottom) or "bottom bottom-=100" (100px above the viewport bottom).',
                    'happy-addons-pro'
                ),
                'condition'          => [
                    'ha_ga_switcher'     => 'yes',
                    'ha_ga_wrapper'      => 'custom',
                    'ha_ga_anim_end'     => 'custom',
                    'ha_ga_trigger_mode' => ['scroll', 'playwithscroll']
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Easing Functions
        $element->add_responsive_control(
            'ha_ga_markers',
            [
                'label'              => __( 'Markers', 'happy-addons-pro' ),
                'description'        => __( 'Show ScrollTrigger markers for debugging the start/end positions.', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'label_on'           => __( 'Yes', 'happy-addons-pro' ),
                'label_off'          => __( 'No', 'happy-addons-pro' ),
                'return_value'       => 'yes',
                'default'            => '',
                'condition'          => [
                    'ha_ga_switcher' => 'yes',
                    'ha_ga_wrapper'  => 'custom'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_responsive_control(
            'ha_ga_easing',
            [
                'label'              => __( 'Easing Functions', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'power2.out',
                'options'            => [
                    'none'          => __( 'None', 'happy-addons-pro' ),
                    'power1.out'    => __( 'Power1 Out', 'happy-addons-pro' ),
                    'power2.out'    => __( 'Power2 Out', 'happy-addons-pro' ),
                    'power3.out'    => __( 'Power3 Out', 'happy-addons-pro' ),
                    'power4.out'    => __( 'Power4 Out', 'happy-addons-pro' ),
                    'power1.in'     => __( 'Power1 In', 'happy-addons-pro' ),
                    'power2.in'     => __( 'Power2 In', 'happy-addons-pro' ),
                    'power3.in'     => __( 'Power3 In', 'happy-addons-pro' ),
                    'power4.in'     => __( 'Power4 In', 'happy-addons-pro' ),
                    'power1.inOut'  => __( 'Power1 InOut', 'happy-addons-pro' ),
                    'power2.inOut'  => __( 'Power2 InOut', 'happy-addons-pro' ),
                    'power3.inOut'  => __( 'Power3 InOut', 'happy-addons-pro' ),
                    'power4.inOut'  => __( 'Power4 InOut', 'happy-addons-pro' ),
                    'back.out'      => __( 'Back Out', 'happy-addons-pro' ),
                    'back.in'       => __( 'Back In', 'happy-addons-pro' ),
                    'back.inOut'    => __( 'Back InOut', 'happy-addons-pro' ),
                    'elastic.out'   => __( 'Elastic Out', 'happy-addons-pro' ),
                    'elastic.in'    => __( 'Elastic In', 'happy-addons-pro' ),
                    'elastic.inOut' => __( 'Elastic InOut', 'happy-addons-pro' ),
                    'bounce.out'    => __( 'Bounce Out', 'happy-addons-pro' ),
                    'bounce.in'     => __( 'Bounce In', 'happy-addons-pro' ),
                    'bounce.inOut'  => __( 'Bounce InOut', 'happy-addons-pro' ),
                    'circ.out'      => __( 'Circ Out', 'happy-addons-pro' ),
                    'expo.out'      => __( 'Expo Out', 'happy-addons-pro' ),
                    'sine.out'      => __( 'Sine Out', 'happy-addons-pro' ),
                    'slowmo'        => __( 'Slowmo', 'happy-addons-pro' ),
                    'stepped'       => __( 'Stepped', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Custom Properties Repeater
        $repeater = new Repeater();

        $repeater->add_control(
            'property',
            [
                'label'              => __( 'Property', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'none',
                'options'            => [
                    'none'                 => __( 'None', 'happy-addons-pro' ),
                    'opacity'              => __( 'Opacity', 'happy-addons-pro' ),
                    'x'                    => __( 'X', 'happy-addons-pro' ),
                    'y'                    => __( 'Y', 'happy-addons-pro' ),
                    'width'                => __( 'Width', 'happy-addons-pro' ),
                    'height'               => __( 'Height', 'happy-addons-pro' ),
                    'maxWidth'             => __( 'Max Width', 'happy-addons-pro' ),
                    'maxHeight'            => __( 'Max Height', 'happy-addons-pro' ),
                    'minWidth'             => __( 'Min Width', 'happy-addons-pro' ),
                    'minHeight'            => __( 'Min Height', 'happy-addons-pro' ),
                    'scale'                => __( 'Scale', 'happy-addons-pro' ),
                    'scaleX'               => __( 'ScaleX', 'happy-addons-pro' ),
                    'scaleY'               => __( 'ScaleY', 'happy-addons-pro' ),
                    'rotate'               => __( 'Rotate', 'happy-addons-pro' ),
                    'rotateX'              => __( 'RotateX', 'happy-addons-pro' ),
                    'rotateY'              => __( 'RotateY', 'happy-addons-pro' ),
                    'skew'                 => __( 'Skew', 'happy-addons-pro' ),
                    'flip'                 => __( 'Flip', 'happy-addons-pro' ),
                    'transformOrigin'      => __( 'TransformOrigin', 'happy-addons-pro' ),
                    'transformPerspective' => __( 'Perspective (3D)', 'happy-addons-pro' ),
                    'padding'              => __( 'Padding', 'happy-addons-pro' ),
                    'color'                => __( 'Color', 'happy-addons-pro' ),
                    'background'           => __( 'Background', 'happy-addons-pro' ),
                    'border'               => __( 'Border', 'happy-addons-pro' ),
                    'borderRadius'         => __( 'Border Radius', 'happy-addons-pro' ),
                    'boxShadow'            => __( 'BoxShadow', 'happy-addons-pro' ),
                    'blur'                 => __( 'Blur', 'happy-addons-pro' ),
                    'delay'                => __( 'Delay', 'happy-addons-pro' ),
                    'duration'             => __( 'Duration', 'happy-addons-pro' ),
                    'repeat'               => __( 'Repeat', 'happy-addons-pro' ),
                    'repeatDelay'          => __( 'Repeat Delay', 'happy-addons-pro' )
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Text value (default for string-based properties)
        $repeater->add_control(
            'value_text',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'placeholder'        => __( 'Enter value', 'happy-addons-pro' ),
                'description'        => __( 'Enter a CSS value, string, or number based on the selected property.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['none']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Transform Origin value
        $repeater->add_control(
            'value_transform_origin',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => '100% 100%',
                'options'            => [
                    '0% 0%'     => __( 'Left - Top', 'happy-addons-pro' ),
                    '50% 0%'    => __( 'Center - Top', 'happy-addons-pro' ),
                    '100% 0%'   => __( 'Right - Top', 'happy-addons-pro' ),
                    '0% 50%'    => __( 'Left - Center', 'happy-addons-pro' ),
                    '50% 50%'   => __( 'Center - Center', 'happy-addons-pro' ),
                    '100% 50%'  => __( 'Right - Center', 'happy-addons-pro' ),
                    '0% 100%'   => __( 'Left - Bottom', 'happy-addons-pro' ),
                    '50% 100%'  => __( 'Center - Bottom', 'happy-addons-pro' ),
                    '100% 100%' => __( 'Right - Bottom', 'happy-addons-pro' ),
                    'custom'    => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'property' => ['transformOrigin']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_control(
            'value_transform_origin_custom',
            [
                'label'              => __( 'Custom Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'placeholder'        => __( '0% 100%', 'happy-addons-pro' ),
                'default'            => '0% 100%',
                'description'        => __( 'Enter custom transform origin value. Format: "x y" e.g. "0% 100%" or "bottom right".', 'happy-addons-pro' ),
                'condition'          => [
                    'property'               => ['transformOrigin'],
                    'value_transform_origin' => 'custom'
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Transform Perspective value (3D depth in px, like CSS perspective)
        $repeater->add_responsive_control(
            'value_perspective',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'size_units'         => ['px'],
                'range'              => [
                    'px' => [
                        'min'  => 100,
                        'max'  => 3000,
                        'step' => 10
                    ]
                ],
                'default'            => [
                    'size' => 1200,
                    'unit' => 'px'
                ],
                'description'        => __( '3D perspective depth in px (acts like CSS perspective). Lower = more dramatic tilt, higher = subtler.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['transformPerspective']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Color value
        $repeater->add_responsive_control(
            'value_color',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::COLOR,
                'condition'          => [
                    'property' => ['color', 'background']
                ],
                // 'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Slider value (0-1 range)
        $repeater->add_responsive_control(
            'value_slider',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min'  => 0,
                        // 'max'  => 10,
                        'step' => 0.01
                    ]
                ],
                'default'            => [
                    'size' => 1,
                    'unit' => 'px'
                ],
                'condition'          => [
                    'property' => ['scale', 'scaleX', 'scaleY']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_responsive_control(
            'value_opacity',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1,
                        'step' => 0.01
                    ]
                ],
                'default'            => [
                    'size' => 1
                ],
                'description'        => __( 'Set opacity: 0 = fully transparent, 1 = fully opaque.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['opacity', 'autoAlpha']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_control(
            'value_autoAlpha_desc',
            [
                'type'               => Controls_Manager::RAW_HTML,
                'raw'                => __( '0 = hidden & invisible, 1 = visible & opaque. Controls both opacity and visibility.', 'happy-addons-pro' ),
                'content_classes'    => 'elementor-descriptor',
                'condition'          => [
                    'property' => ['autoAlpha']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Dimensions value
        $repeater->add_responsive_control(
            'value_dimensions',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', '%', 'em', 'rem'],
                'condition'          => [
                    'property' => ['padding', 'borderRadius']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Number value (legacy, kept for backward compat)
        $repeater->add_control(
            'value_number',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'placeholder'        => __( '0', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['__none__']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Position/Size slider with unit support
        $repeater->add_responsive_control(
            'value_position',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'size_units'         => ['px', '%', 'em', 'rem', 'vh', 'vw'],
                'range'              => [
                    'px'  => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 1
                    ],
                    '%'   => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ],
                    'em'  => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 0.1
                    ],
                    'rem' => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 0.1
                    ],
                    'vh'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ],
                    'vw'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ]
                ],
                'default'            => [
                    'unit' => 'px'
                ],
                'description'        => __( 'Set position or size with unit. Use % to offset by percentage of the element\'s own width/height (e.g. 50% = element starts at 50% offset and animates to normal position with "From" method). px/em/rem: 0–2000. vh/vw: 0–100.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['x', 'y', 'width', 'height']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Rotation value in degrees
        $repeater->add_responsive_control(
            'value_rotate',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'default'            => 30,
                'placeholder'        => __( '30', 'happy-addons-pro' ),
                'description'        => __( 'Enter rotation in degrees (deg). Positive = clockwise, negative = counter-clockwise. Example: 45, -90, 360.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['rotate', 'rotateX', 'rotateY']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Skew X value in degrees (used by combined skew)
        $repeater->add_responsive_control(
            'value_skew_x',
            [
                'label'              => __( 'Skew X', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'default'            => 0,
                'placeholder'        => __( '0', 'happy-addons-pro' ),
                'description'        => __( 'Skew X in degrees (deg). Positive or negative. Example: 15, -10.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['skew']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Skew Y value in degrees (used by combined skew)
        $repeater->add_responsive_control(
            'value_skew_y',
            [
                'label'              => __( 'Skew Y', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'default'            => 0,
                'placeholder'        => __( '0', 'happy-addons-pro' ),
                'description'        => __( 'Skew Y in degrees (deg). Positive or negative. Example: 15, -10.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['skew']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Blur radius (CSS filter: blur()), length units only (% not supported by CSS blur)
        $repeater->add_responsive_control(
            'value_blur',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'size_units'         => ['px', 'em', 'rem'],
                'range'              => [
                    'px'  => ['min' => 0, 'max' => 30, 'step' => 0.1],
                    'em'  => ['min' => 0, 'max' => 20, 'step' => 0.1],
                    'rem' => ['min' => 0, 'max' => 20, 'step' => 0.1]
                ],
                'default'            => [
                    'size' => 1,
                    'unit' => 'px'
                ],
                'description'        => __( 'Gaussian blur radius. Animates CSS filter: blur(). Use px/em/rem (% is not supported by CSS blur).', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['blur']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Flip type: mirror (negative scale) or 3d (rotate 180deg with perspective)
        $repeater->add_control(
            'value_flip_type',
            [
                'label'              => __( 'Flip Type', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'mirror',
                'options'            => [
                    'mirror' => __( 'Mirror', 'happy-addons-pro' ),
                    '3d'     => __( '3D', 'happy-addons-pro' )
                ],
                'description'        => __( 'Mirror = negative scale flip. 3D = rotate 180deg (adds perspective for depth).', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['flip']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Flip direction: horizontal or vertical
        $repeater->add_control(
            'value_flip_direction',
            [
                'label'              => __( 'Direction', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'horizontal',
                'options'            => [
                    'horizontal' => __( 'Horizontal', 'happy-addons-pro' ),
                    'vertical'   => __( 'Vertical', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'property' => ['flip']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Flip rotation degree (only used by the 3D flip type)
        $repeater->add_responsive_control(
            'value_flip_deg',
            [
                'label'              => __( 'Rotation (deg)', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => -360,
                'max'                => 360,
                'default'            => 180,
                'placeholder'        => __( '180', 'happy-addons-pro' ),
                'description'        => __( 'Rotation in degrees for the 3D flip. Range: -360 to 360.', 'happy-addons-pro' ),
                'condition'          => [
                    'property'        => ['flip'],
                    'value_flip_type' => '3d'
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Repeat count
        $repeater->add_responsive_control(
            'value_repeat',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => 0,
                'max'                => 10,
                'placeholder'        => __( '0', 'happy-addons-pro' ),
                'description'        => __( 'Number of repeat cycles. Range: 0–10. 0 = no repeat.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['repeat']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        // Switcher value
        $repeater->add_responsive_control(
            'value_delay',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 10,
                        'step' => 0.1
                    ]
                ],
                'default'            => [
                    'size' => 0.1,
                    'unit' => 'px'
                ],
                'description'        => __( 'Delay before animation starts (in seconds). Example: 0.5', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['delay']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_responsive_control(
            'value_duration',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'range'              => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 10,
                        'step' => 0.1
                    ]
                ],
                'default'            => [
                    'size' => 0.6,
                    'unit' => 'px'
                ],
                'description'        => __( 'Animation duration (in seconds). Example: 1', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['duration']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_responsive_control(
            'value_repeat_delay',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'placeholder'        => __( '0.5', 'happy-addons-pro' ),
                'description'        => __( 'Delay between repeat cycles (in seconds). Example: 0.5', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['repeatDelay']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_responsive_control(
            'value_size',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SLIDER,
                'size_units'         => ['px', '%'],
                'range'              => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 2000,
                        'step' => 1
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1
                    ]
                ],
                'default'            => [
                    'unit' => 'px'
                ],
                'description'        => __( 'Set size in pixels or percentage.', 'happy-addons-pro' ),
                'condition'          => [
                    'property' => ['maxWidth', 'maxHeight', 'minWidth', 'minHeight']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_control(
            'value_switcher',
            [
                'label'              => __( 'Value', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'condition'          => [
                    'property' => ['force3D', 'yoyo']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_control(
            'value_force3d_desc',
            [
                'type'               => Controls_Manager::RAW_HTML,
                'raw'                => __( 'Enable Force3D to force GPU acceleration for smoother transforms.', 'happy-addons-pro' ),
                'content_classes'    => 'elementor-descriptor',
                'condition'          => [
                    'property' => ['force3D']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_control(
            'value_yoyo_desc',
            [
                'type'               => Controls_Manager::RAW_HTML,
                'raw'                => __( 'Enable YoYo to make the animation alternate direction on each repeat cycle.', 'happy-addons-pro' ),
                'content_classes'    => 'elementor-descriptor',
                'condition'          => [
                    'property' => ['yoyo']
                ],
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'               => 'value_border',
                'selector'           => '{{WRAPPER}} .ha-ga-dummy-border',
                'condition'          => [
                    'property' => ['border']
                ],
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $repeater->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'               => 'value_box_shadow',
                'selector'           => '{{WRAPPER}} .ha-ga-dummy-shadow',
                'condition'          => [
                    'property' => ['boxShadow']
                ],
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $element->add_control(
            'ha_ga_custom_props',
            [
                'label'              => __( 'Custom Properties', 'happy-addons-pro' ),
                'type'               => Controls_Manager::REPEATER,
                'fields'             => $repeater->get_controls(),
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'label_block'        => true,
                'title_field'        => '{{{ property }}}',
                'separator'          => 'before',
                'render_type'        => 'ui',
                'frontend_available' => true,
                'style_transfer'     => false
            ]
        );

        /*
        $element->add_responsive_control(
            'ha_ga_enable_editor_preview',
            [
                'label'              => __( 'Enable Preview in Editor', 'happy-addons-pro' ),
                'description'        => __( 'When enabled, animations will run inside the Elementor editor. Keep off for better editor performance.', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => '',
                'separator'          => 'before',
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        ); */

        $element->add_control(
            'ha_ga_enable_mobile',
            [
                'label'              => __( 'Enable On Mobile', 'happy-addons-pro' ),
                'description'        => __( 'When disabled, the animation will not run on mobile devices.', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'default'            => 'no',
                'condition'          => [
                    'ha_ga_switcher' => 'yes'
                ],
                'render_type'        => 'none',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

    }

    /**
     * Render animation class on the frontend.
     *
     * @param  \Elementor\Element_Base $element
     * @return void
     */
    public function before_render( $element ) {
        // Read the raw settings (not get_settings_for_display()) so resolving
        // the global colors below is not lost to the active-settings cache.
        $settings = $element->get_settings();

        if ( empty( $settings['ha_ga_switcher'] ) || 'yes' !== $settings['ha_ga_switcher'] ) {
            return;
        }

        $this->resolve_custom_props_global_colors( $element );

        $element->add_render_attribute( '_wrapper', 'class', 'ha-ga-animation' );
    }

    /**
     * Resolve Elementor global color references used by the repeater colors.
     *
     * When a global color is picked for the repeater's `value_color` control,
     * Elementor stores only a reference inside the repeater item's
     * `__globals__` map (e.g. `value_color => globals/colors?id=primary`)
     * while the `value_color` value itself stays empty. The frontend settings
     * handed to JS are not passed through Elementor's global resolver, so the
     * animation handler receives no color. Resolve the reference to the actual
     * kit color and write it back before the wrapper `data-settings` is built.
     *
     * @param  \Elementor\Element_Base $element
     * @return void
     */
    private function resolve_custom_props_global_colors( $element ) {
        $settings = $element->get_settings();

        if ( empty( $settings['ha_ga_custom_props'] ) || ! is_array( $settings['ha_ga_custom_props'] ) ) {
            return;
        }

        $global_colors = $this->get_active_kit_colors();

        if ( empty( $global_colors ) ) {
            return;
        }

        $changed = false;

        foreach ( $settings['ha_ga_custom_props'] as $index => $item ) {
            if ( empty( $item['__globals__']['value_color'] ) || ! is_string( $item['__globals__']['value_color'] ) ) {
                continue;
            }

            $resolved = $this->resolve_global_color( $item['__globals__']['value_color'], $global_colors );

            if ( ! empty( $resolved ) ) {
                $settings['ha_ga_custom_props'][ $index ]['value_color'] = $resolved;
                $changed = true;
            }
        }

        if ( $changed ) {
            $element->set_settings( $settings );

            // Elementor may have already cached the parsed settings (other
            // before_render hooks can call get_settings_for_display()), so the
            // mutated value must force the caches to be rebuilt.
            $this->reset_settings_cache( $element );
        }
    }

    /**
     * Clear Elementor's cached parsed/active settings on the element only.
     *
     * `reset_render_state()` would also wipe already-added render attributes,
     * so the three private settings caches are cleared directly and narrowly.
     *
     * @param  \Elementor\Element_Base $element
     * @return void
     */
    private function reset_settings_cache( $element ) {
        if ( ! class_exists( '\ReflectionObject' ) ) {
            return;
        }

        foreach ( [ 'active_settings', 'parsed_active_settings', 'parsed_dynamic_settings' ] as $property_name ) {
            try {
                $class = new \ReflectionObject( $element );

                while ( $class && ! $class->hasProperty( $property_name ) ) {
                    $class = $class->getParentClass();
                }

                if ( ! $class ) {
                    continue;
                }

                $property = $class->getProperty( $property_name );
                $property->setAccessible( true );
                $property->setValue( $element, null );
            } catch ( \Exception $e ) {
                // Ignore: the property layout changed in a newer Elementor.
                continue;
            }
        }
    }

    /**
     * Resolve a single global color reference against the kit colors.
     *
     * @param  string $color_value e.g. "globals/colors?id=primary".
     * @param  array  $globals     Map of global color id => color value.
     * @return string
     */
    private function resolve_global_color( $color_value, $globals = [] ) {
        if ( empty( $color_value ) || ! is_string( $color_value ) ) {
            return $color_value;
        }

        if ( 0 !== strpos( $color_value, 'globals/colors?id=' ) ) {
            return $color_value;
        }

        $global_id = substr( $color_value, strlen( 'globals/colors?id=' ) );

        if ( empty( $global_id ) || empty( $globals[ $global_id ] ) ) {
            return '';
        }

        return $globals[ $global_id ];
    }

    /**
     * Get the active kit's system and custom colors, keyed by global color id.
     *
     * @return array
     */
    private function get_active_kit_colors() {
        static $colors = null;

        if ( null !== $colors ) {
            return $colors;
        }

        $colors = [];

        if ( ! class_exists( '\Elementor\Plugin' ) || empty( \Elementor\Plugin::$instance->kits_manager ) ) {
            return $colors;
        }

        $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();

        if ( ! $kit ) {
            return $colors;
        }

        foreach ( [ 'system_colors', 'custom_colors' ] as $setting_key ) {
            $items = $kit->get_settings_for_display( $setting_key );

            if ( ! is_array( $items ) ) {
                continue;
            }

            foreach ( $items as $item ) {
                if ( ! empty( $item['_id'] ) && ! empty( $item['color'] ) ) {
                    $colors[ $item['_id'] ] = $item['color'];
                }
            }
        }

        return $colors;
    }

}
