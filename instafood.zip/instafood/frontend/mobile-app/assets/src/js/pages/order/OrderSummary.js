import Cart from '../../cart/Cart';
import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';

class OrderSummary {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.update(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {

        const cartProductsData = Cart.getInstance().getCartItemsWithInfo();
        if (!Array.isArray(cartProductsData)) {
            return;
        }
        const t = DataUtils.getInstance().getOption('price_display_template');
        const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));

        let lineItemsHtml = '';
        for (let i = 0; i < cartProductsData.length; i++) {
            const cartItemData = cartProductsData[i];
            const total = _.get(cartItemData, 'cartItemTotal', 0);
            const formattedPrice = DataUtils.getInstance().getFormmatedPriceDisplay(total);
            const priceTotal = priceTemplate({ price: formattedPrice });
            lineItemsHtml += `
                <div class="line_item ${ i < cartProductsData.length -1 ? 'space_b' : '' }">
                    <div class="line_item_title"><span>${ _.get(cartItemData, 'quantity', 1) }x</span>${ _.get(cartItemData, 'productTitle', '') }</div>
                    <div class="ml_15">${ priceTotal }</div>
                </div>
            `;
        }


        const template = `
        <div class="apt_content_widget mt_20 bm_20 order_summary_widget">
            <div class="in_content">
                <div class="wgt_header">
                    <div class="wgt_title_ui">
                        <span class="icon-file-text wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('order_summary_widget_label') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    ${ lineItemsHtml }
                    <div class="wgt_hr_line mt_10 mb_10"></div>
                    <div class="order_summary_dynamic_content"></div>
                </div>
            </div>
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._parrentUI);
        this._order_summary_dynamic_content = this._ui.find('.order_summary_dynamic_content');
        this.update();
    }

    update() {
        const { isDineIn, isPickup, isDelivery } = Order.getInstance().getShippingOptions();
        const t = DataUtils.getInstance().getOption('price_display_template');
        const priceTemplate = _.template(LanguageUtils.getInstance().decodeHtml(t));

        const order_summary_dynamic_content = this._ui.find('.order_summary_dynamic_content');
        order_summary_dynamic_content.empty();

        const subtotal = Number.parseFloat(Cart.getInstance().getCartTotal()).toFixed(2);
        const formattedSubtotalPrice = DataUtils.getInstance().getFormmatedPriceDisplay(subtotal);

        const subtotalTemplate = `
            <div class="line_item space_b">
                <div class="line_item_title"><span>${ LanguageUtils.getInstance().getLabel('order_summary_widget_subtotal_label') }</div>
                <div class="ml_15">${ priceTemplate({ price: formattedSubtotalPrice }) }</div>
            </div>
        `;
        jQuery(subtotalTemplate).appendTo(order_summary_dynamic_content);
        
        if ((isDineIn || isDelivery) && Order.getInstance().getTipPercent() !== 0) {
            const tipPercentageInfoHtml = LanguageUtils.getInstance().getLabel('tip_percentage_summary_label');
            const tipPercentageTemplate = _.template(LanguageUtils.getInstance().decodeHtml(tipPercentageInfoHtml));

            const tipValueRaw = Order.getInstance().getTipValue();
            const tip = Number.parseFloat(tipValueRaw).toFixed(2);
            const formattedSubtotalPrice = DataUtils.getInstance().getFormmatedPriceDisplay(tip);

            const tipTotal = priceTemplate({ price: formattedSubtotalPrice });
            const tipTemplate = `
                <div class="line_item space_b">
                    <div class="line_item_title"><span>${ tipPercentageTemplate({ tipPercent: Order.getInstance().getTipPercent() }) }</div>
                    <div class="ml_15">${ tipTotal }</div>
                </div>
            `;
            jQuery(tipTemplate).appendTo(order_summary_dynamic_content);
        }

        if (isDelivery) {
            const deliveryValue = Order.getInstance().getDeliveryValue();
            let deliveryFeeTxt = LanguageUtils.getInstance().getLabel('free_delivery_label');
            if (deliveryValue !== 0) {
                const deliveryPrice = Number.parseFloat(deliveryValue);
                const formattedDeliveryPrice = DataUtils.getInstance().getFormmatedPriceDisplay(deliveryPrice);
                deliveryFeeTxt = priceTemplate({ price: formattedDeliveryPrice });
            }
            const deliveryTemplate = `
                <div class="line_item space_b">
                    <div class="line_item_title"><span>${ LanguageUtils.getInstance().getLabel('delivery_fee_label') }</div>
                    <div class="ml_15">${ deliveryFeeTxt }</div>
                </div>
            `;
            jQuery(deliveryTemplate).appendTo(order_summary_dynamic_content);
        }

        const grandTotalPrice = Number.parseFloat(Order.getInstance().getGrandTotal()).toFixed(2);
        const formattedGrandTotalPrice = DataUtils.getInstance().getFormmatedPriceDisplay(grandTotalPrice);

        const totalTemplate = `
            <div class="line_item space_b">
                <div class="line_item_title"><span>${ LanguageUtils.getInstance().getLabel('order_summary_widget_total_label') }</div>
                <div class="ml_15">${ priceTemplate({ price: formattedGrandTotalPrice }) }</div>
            </div>
        `;
        jQuery(totalTemplate).appendTo(order_summary_dynamic_content);
    }
}
export default OrderSummary;