import DataUtils from '../utils/DataUtils';

let instance;
const instanceKey = 'rest_manager92339';

class RestManager {
    static POST = 'POST';
    static GET = 'GET';

    API_ROOT = '';

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this.API_ROOT = DataUtils.getInstance().getOption('rest_url');
    }

    post(path, data = {}) {
        return new Promise((resolve, reject) => {
            jQuery.post(`${this.API_ROOT}${path}`, data, (result, status) => {
                if (!status === 'success') {
                    reject({ ...result, status });
                }
                resolve(result);
            });
        })
    }

    get(path, queryVars = {}) {
        return new Promise((resolve, reject) => {
            jQuery.get(`${this.API_ROOT}${path}`, (result, status) => {
                if (!status === 'success') {
                    reject({ ...result, status });
                }
                resolve(result);
            });
        })
    }

    static getInstance() {
        if (!instance) {
            instance = new RestManager(instanceKey);
        }
        return instance;
    }

}
export default RestManager;