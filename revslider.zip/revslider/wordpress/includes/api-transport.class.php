<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

if(!defined('ABSPATH')) exit();

/**
 * The WordPress transport of the API: REST route wiring, the preview short-circuit that
 * serves HTML through the REST server, the cookie-auth preview gate, and the ops that
 * exist only to drive WordPress admin services. RevSliderApi keeps every frozen public
 * as a delegation shell; the dispatch tables stay core.
 */
class RevSliderWpTransport extends RevSliderFunctions {

	/** @var RevSliderApi */
	private $api;

	public function __construct($api){
		parent::__construct();
		$this->api = $api;
	}

	/**
	 * Init the REST API
	 * used only for frontend functionality
	 * the routes themselves are RevSliderApi::REST_ROUTES, so a second host answers the same paths
	 * @return void
	 **/
	public function init_rest_api(){
		//what the table's gates mean here: 'public' only installs the core's exception handler, 'editor'
		//checks the auth cookie first. An unknown gate falls to the strictest one, it never opens a route.
		$gates = ['public' => 'setup_exception_handler', 'editor' => 'preview_permission_check'];

		foreach(RevSliderApi::REST_ROUTES as $route){
			$parts	= explode('/', $route['path'], 2); //WordPress wants the namespace apart from the route
			$path	= $this->get_val($parts, 1);
			foreach($route['params'] as $name => $pattern){
				$path = str_replace('{'.$name.'}', '(?P<'.$name.'>'.$pattern.')', $path);
			}

			register_rest_route($this->get_val($parts, 0), '/'.$path, [
				'methods'				=> $route['method'],
				'callback'				=> [$this->api, $route['call']],
				'permission_callback'	=> [$this->api, $this->get_val($gates, $route['gate'], 'preview_permission_check')]
			]);
		}
	}

	/** @return bool */
	public function init_rest_api_return($served, $result, $request, $server){
		$route	= $request->get_route();
		$path	= RevSliderApi::REST_ROUTES['preview']['path'];
		$prefix	= '/' . (strstr($path, '{', true) ?: $path); //the table owns the path; recognising it here must not spell it again

		if(strpos($route, $prefix) !== 0) return $served;
	
		// Output as real HTML so the browser renders the page
		$charset = get_option('blog_charset') ?: 'UTF-8';
		header('Content-Type: text/html; charset=' . $charset);

		// $result is WP_REST_Response here
		$data = ($result instanceof WP_REST_Response) ? $result->get_data() : (string)$result;
		if(is_array($data)) $data = json_encode($data);
		echo (string)$data;

		return true; // short-circuit: we've sent the response ourselves
	}

	/**
	 * true when the calling browser session belongs to a user who may see unsaved module drafts.
	 *
	 * The preview route is opened as an iframe from the editor, so it carries the WP auth cookies but no REST
	 * nonce - and WP forces the current user to 0 for nonce-less REST requests (rest_cookie_check_errors), so
	 * current_user_can() would report "not allowed" even for a logged in editor. The route is a read-only GET,
	 * so the missing nonce is not a CSRF concern: an attacker cannot read the cross-origin response.
	 * @return bool
	 */
	private static function can_view_module_preview(){
		$user_id = wp_validate_auth_cookie('', 'logged_in');

		return ($user_id && user_can($user_id, 'edit_posts')) ? true : false;
	}

	/**
	 * the 'editor' gate of RevSliderApi::REST_ROUTES: a logged in user who may edit.
	 * the preview renders the module from the *preview* (unsaved editor draft) tables and its URL is only ever
	 * handed out inside the admin editor (SR7.E.preview_url in core/admin/views/header.php); the font list
	 * carries the site's own uploaded families and their URLs. The public routes stay public on purpose:
	 * the front-end fetches slider data anonymously.
	 * @return bool
	 */
	public function preview_permission_check(){
		$this->api->setup_exception_handler();

		return self::can_view_module_preview();
	}

	/** @return void */
	public function handle_rest_exceptions(Throwable $exception){
		wp_send_json(['success'	=> false, 'message'	=> $exception->getMessage()]);
	}

	/** @return string the rendered preview page */
	public static function get_slider_preview(WP_REST_Request $req){
		global $SR_api;
		$key         = isset($req['module']) ? intval($req['module']) : '';
		$singleslide = isset($req['singleslide']) ? intval($req['singleslide']) : '';
		$preview     = isset($_GET['preview']) ? $SR_api->_truefalse($_GET['preview']) : false;

		//defense in depth: the route's permission callback already restricts this to editors, but never let
		//?preview=1 switch the reads to the unsaved draft tables for a session that may not see them
		if($preview === true && !self::can_view_module_preview()) $preview = false;
		
		// Optional headers
		nocache_headers(); // or send Cache-Control public if you want caching

		if (!defined('SHOW_CT_BUILDER')) define('SHOW_CT_BUILDER', false);

		if (!$key) self::load_404();

		// Render inside your template (same as before)
		if (extension_loaded('newrelic') && function_exists('newrelic_disable_autorum')) newrelic_disable_autorum();

		$module = $SR_api->prepare_preview($key, $singleslide, $preview);
		if($module === false) self::load_404();

		$boxed	 = ($module['fullwidth'] === false && $module['fullheight'] === false);
		$_pre	 = $boxed ? '<div style="max-width:1240px; text-align:center;width:auto; height:auto; margin:auto; display:block;position:relative">'."\n" : '';
		$_post	 = $boxed ? '</div>'."\n" : '';
		$content = $_pre.'[sr7 alias="' . esc_attr($module['alias']) . '"][/sr7]'.$_post;
		$title	 = __('Slider Revolution Preview', 'revslider');
		
		$rev_slider_front = new RevSliderFront(); //needed to be called, to load header properly
		//$admin = new RevSliderAdmin();
		$post = $rev_slider_front->create_fake_post($content, $title);
		$_rs_orig_query = $_rs_orig_the_query = $_rs_orig_post = null;
		if($post instanceof WP_Post){
			global $wp_query, $wp_the_query;

			//remember the real globals: this endpoint deliberately fakes the main query for the template render,
			//and without restoring them rest_post_dispatch filters / shutdown hooks would still see the fake page
			$_rs_orig_query		= $wp_query;
			$_rs_orig_the_query	= $wp_the_query;
			$_rs_orig_post		= $GLOBALS['post'] ?? null;

			$wp_query = new WP_Query([
				'post__in'				 => [$post->ID],
				'post_type'				 => 'any',
				'posts_per_page'		 => 1,
				'ignore_sticky_posts'	 => true,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'no_found_rows'			 => true,
				'fields'				 => 'all',
			]);

			$wp_the_query					= $wp_query;
			$wp_query->post					= $post;
			$wp_query->posts				= [$post];
			$wp_query->post_count			= 1;
			$wp_query->is_singular			= true;
			$wp_query->is_page				= true;
			$wp_query->queried_object		= $post;
			$wp_query->queried_object_id	= $post->ID;
			
			setup_postdata($post);
		}else{
			self::load_404();
		}

		ob_start();
		try{
			include RS_PLUGIN_PATH . 'wordpress/public/views/revslider-page-template.php';
		}finally{
			$html = ob_get_clean(); //always close the buffer, even if the template throws

			//hand the real main query back before returning (wp_reset_postdata() alone would only reset to our fake one)
			if($_rs_orig_query !== null){
				$GLOBALS['wp_query']	 = $_rs_orig_query;
				$GLOBALS['wp_the_query'] = $_rs_orig_the_query;
				$GLOBALS['post']		 = $_rs_orig_post;
				wp_reset_postdata();
			}
		}

		return new WP_REST_Response($html, 200, ['Content-Type'=>'text/html; charset=UTF-8']);
	}

	/** @return void ends the request */
	public static function load_404(){
		RevSliderApi::load_404(); //the answer itself is the core's
	}

	/** @return void the response is sent by ajax_response_*(), which ends the request */
	public function create_wordpress_media(){
		$return = $this->import_upload_media();
		
		if($this->get_val($return, 'error', false) !== false) $this->api->ajax_response_error($this->get_val($return, 'error', false));
		
		$this->api->ajax_response_data($return);
	}

	/** @return void the response is sent by ajax_response_*(), which ends the request */
	public function create_wordpress_draft_page($data){
		$data		= $this->api->get_data($data);
		$response	= ['open' => false, 'edit' => false];
		$sliders	= $this->get_val($data, 'sliders');
		$modals		= $this->get_val($data, 'modals', []);
		$additions	= $this->get_val($data, 'additions', []);
		$page_id	= self::create_slider_page($sliders, $modals, $additions);
		
		if($page_id > 0){
			$response['open'] = str_replace('&amp;', '&', get_permalink($page_id));
			$response['edit'] = str_replace('&amp;', '&', get_edit_post_link($page_id));
		}
		$this->api->ajax_response_data($response);
	}
	/**
	 * a WP_Post that exists only in memory (id 999999999), so the_content filters can be run
	 * against arbitrary content - used by the preview and the HTML export
	 * @return WP_Post
	 **/
	public static function fake_post($content, $title = 'Slider Revolution'){
		$fake_id				= 999999999;
		$post					= new stdClass();
		$post->ID				= $fake_id;
		$post->post_author		= get_current_user_id();
		$post->post_date		= current_time('mysql');
		$post->post_date_gmt	= current_time('mysql', 1);
		$post->post_title		= $title;
		$post->post_content		= $content;
		$post->post_status		= 'publish';
		$post->comment_status	= 'closed';
		$post->ping_status		= 'closed';
		$post->post_name		= 'rs-fake-page-' . rand(1, 99999);
		$post->post_type		= 'page';
		$post->filter			= 'raw';

		$wp_post = new WP_Post($post);

		wp_cache_add($wp_post->ID, $wp_post, 'posts');

		return $wp_post;
	}

	/**
	 * The Ajax Action part for backend actions only
	 * @return void the response is sent by ajax_response_*(), which ends the request
	 **/
	public function do_ajax_action(){
		if(!is_user_logged_in()){
			wp_send_json( ['success' => false, 'message' => __('Please login to continue', 'revslider')], 401 );
			exit;
		}

		$this->api->handle_admin_request($this->get_request_var('client_action'), $this->api->request_nonce(), $this->get_request_var('data', '', false));
		wp_die();
	}

	/**
	 * Ajax handling for frontend, no privileges here
	 * @return void the response is sent by ajax_response_*(), which ends the request
	 */
	public function do_front_ajax_action(){
		//throttle anonymous (nopriv) callers before doing any work; sends 429 and exits if exceeded
		$retry = $this->api->front_rate_limit_retry(is_user_logged_in()); //the pluggable answer, as a site may have replaced it
		if($retry > 0){
			if(!headers_sent()) header('Retry-After: ' . (int)$retry);
			wp_send_json(['success' => false, 'message' => __('Too many requests. Please slow down and try again in a moment.', 'revslider')], 429);
		}

		$this->api->handle_front_request($this->get_request_var('client_action'));

		exit;
	}

	/**
	 * @since: 5.3.0
	 * create a page with revslider shortcodes included
	 * @return int the id of the created page
	 **/
	public static function create_slider_page($added, $modals = [], $additions = []){
		global $wp_version;

		$new_page_id = 0;

		if(!is_array($added)) return apply_filters('revslider_create_slider_page', $new_page_id, $added);

		$f = RevSliderGlobals::instance()->get('RevSliderFunctions');
		$content = '';

		//get alias of all new Sliders that got created and add them as a shortcode onto a page
		foreach($added ?? [] as $sid){
			$slider = new RevSliderSlider();
			$slider->init_by_id($sid);
			$alias = $slider->get_alias();
			if(empty($alias)) continue;

			$usage		= isset($modals[$sid]) ? ' usage="modal"' : '';
			$addition	= (isset($additions[$sid])) ? ' ' . $additions[$sid] : '';
			if(strpos($addition, 'usage=\"modal\"') !== false) $usage = ''; //remove as not needed two times

			if(version_compare($wp_version, '5.0', '>=')){ //add gutenberg code
				$ov_data = $slider->get_overview_data();
				$title	 = $slider->get_val($ov_data, 'title', '');
				//bg used to be an array and is a plain url now, so reading only bg.src returns nothing on
				//current data - which is why pages made here stopped carrying a preview picture.
				$img	 = $slider->get_val($ov_data, 'bg', '');
				if(!is_string($img) || $img === '') $img = (string)$slider->get_val($ov_data, ['bg', 'src'], '');

				//The block reads its module from these attributes and nowhere else - the shortcode below is
				//text to it. Without `alias` the card stops before it fetches anything, which is why every
				//module on a generated page sat there as the empty placeholder.
				$attrs = [
					'alias'		=> $alias,
					'moduleId'	=> (string)$sid,
					'slides'	=> count((array)$slider->get_val($ov_data, 'children', [])),
				];
				if($img !== '')		$attrs['image'] = $img;
				if($title !== '')	$attrs['title'] = $title;
				$type = (string)$slider->get_val($ov_data, 'type', '');
				if($type !== '')	$attrs['type'] = $type;
				//Character for character what save() writes, empty id and empty style included. Anything else
				//and WordPress falls back to an older shape of this block and drops the attributes above.
				$div_addition	= ' id="" data-slidertitle="'.esc_attr($title).'" style="';

				$zindex_pos = strpos($addition, 'zindex=\"');
				if($zindex_pos !== false){
					$zindex = substr($addition, $zindex_pos + 9, strpos($addition, '\"', $zindex_pos + 9) - ($zindex_pos + 9));
					$div_addition .= 'z-index:'.$zindex;
					$attrs['zindex'] = $zindex;
				}

				$div_addition .= '"';

				$content .= '<!-- wp:themepunch/revslider '.wp_json_encode($attrs).' -->'."\n";
				$content .= '<div class="wp-block-themepunch-revslider revslider"'.$div_addition.'>';
			}

			$content .= '[rev_slider alias="'.$alias.'"'.$usage.$addition.'][/rev_slider]'; //this way we will reorder as last comes first

			if(version_compare($wp_version, '5.0', '>=')){ //add gutenberg code
				$content .= '</div>'."\n".'<!-- /wp:themepunch/revslider -->'."\n";
			}
		}

		if($content !== ''){
			$page_id = $f->get_options(['other', 'page-id'], 1);
			$new_page_id = wp_insert_post(
				[
					'post_title'    => wp_strip_all_tags('RevSlider Page '.$page_id), //$title
					'post_content'  => $content,
					'post_type'   	=> 'page',
					'post_status'   => 'draft',
					'page_template' => RevSliderPageTemplate::KEY
				]
			);

			if(is_wp_error($new_page_id)) $new_page_id = 0; //fallback to 0

			$page_id++;
			$f->update_option(['other', 'page-id'], $page_id);
		}

		return apply_filters('revslider_create_slider_page', $new_page_id, $added);
	}

	/**
	 * import a media file uploaded through the browser to the media library
	 * @return array ['id' => attachment id] or ['error' => message]
	 **/
	public function import_upload_media(){
		require_once(ABSPATH . 'wp-admin/includes/file.php');

		$checked = $this->api->check_upload($this->get_val($_FILES, 'import_file'));
		if(isset($checked['error'])) return $checked;

		$file_name	= $checked['name'];
		$file_mime	= $checked['mime'];
		$new_path	= $checked['target'];

		if(!move_uploaded_file($checked['path'], $new_path)) return ['error' => __('File not found', 'revslider')];

		$upload_id = wp_insert_attachment(
			[
				'guid'			 => $new_path,
				'post_mime_type' => $file_mime,
				'post_title'	 => preg_replace( '/\.[^.]+$/', '', $file_name),
				'post_name'		 => sanitize_title_with_dashes(str_replace('_', '-', $file_name)),
				'post_content'	 => '',
				'post_status'    => 'inherit'
			],
			$new_path
		);

		require_once(ABSPATH . 'wp-admin/includes/image.php');

		@wp_update_attachment_metadata($upload_id, wp_generate_attachment_metadata($upload_id, $new_path));

		$img_dim = @wp_get_attachment_image_src($upload_id, 'full');
		$width	 = ($img_dim !== false) ? $this->get_val($img_dim, 1, '') : '';
		$height	 = ($img_dim !== false) ? $this->get_val($img_dim, 2, '') : '';

		return ['error' => false, 'id' => $upload_id, 'path' => wp_get_attachment_url($upload_id), 'width' => $width, 'height' => $height]; //$new_path
	}

	/**
	 * @return bool are we on a post/widget edit screen?
	 */
	public function is_edit_page(){
		if(!$this->environment()->is_admin_area()) return false;
		global $pagenow;

		return in_array($pagenow, ['post.php', 'post-new.php', 'widgets.php']);
	}
}
