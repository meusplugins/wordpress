import DataUtils from '../../utils/DataUtils';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';

class ShippingMethod {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;
    _staticHolderUI;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._addEventListeners();
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.render(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        const canDineIn = DataUtils.getInstance().canDineIn();
        if (canDineIn) {
            return;
        }
        const canDeliver = DataUtils.getInstance().canDeliver();
        const canPickUp = DataUtils.getInstance().canPickUp();
        
        if (canDeliver && canPickUp) {
            this._renderDeliverPickupChoose();
            return;
        }

    }

    _renderDeliverPickupChoose() {
        const template = `
        <div class="apt_content_widget mt_20 bm_20 shipping_choose_widget">
            <div class="in_content">
                <div class="wgt_header">
                    <div class="wgt_title_ui">
                        <span class="icon-shop wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('delivery_method_label') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="product_widget delivery_widget local_delivery">
                        <div class="widget_radio_entry ${ Order.getInstance().isDelivery() ? 'selected' : '' }">
                            <div class="radio_symbol primary_color_border"><div class="radio_fill primary_color_background show"></div></div>
                            <div class="variant_info">${ LanguageUtils.getInstance().getLabel('local_delivery_label') }</div>
                        </div>
                    </div>
                    <div class="product_widget delivery_widget local_pickup">
                        <div class="widget_radio_entry ${ Order.getInstance().isPickup() ? 'selected' : '' }">
                            <div class="radio_symbol primary_color_border"><div class="radio_fill primary_color_background show"></div></div>
                            <div class="variant_info">${ LanguageUtils.getInstance().getLabel('pickup_delivery_label') }</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._staticHolderUI);
        const _this = this;
        this._ui.find('.local_delivery').click(function(event) {
            event.preventDefault();
            Order.getInstance().setIsDelivery();
        })
        this._ui.find('.local_pickup').click(function(event) {
            event.preventDefault();
            Order.getInstance().setIsPickup();
        })
    }
}
export default ShippingMethod;