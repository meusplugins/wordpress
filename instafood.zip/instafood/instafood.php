<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Don't allow direct access
/*
Plugin Name: InstaFood - QR Menu, food delivery, pickup and dine-in
Plugin URI: https://www.sakuraplugins.com
Description: Contactless restaurant menu, food delivery, pickup and dine-in
Author: SakuraPlugins
Version: 1.6.0
Author URI: https://www.sakuraplugins.com/contact
Text Domain: instafood
Domain Path: /languages
*/

require_once(plugin_dir_path(__FILE__) . 'com/sakuraplugins/appetit/core.php');
require_once(plugin_dir_path(__FILE__) . 'com/sakuraplugins/appetit/utils/UserManagement.php');

use com\sakuraplugins\appetit\AppetitCore;
use com\sakuraplugins\appetit\utils\UserManagement;


define('INSTAFOOD_QR_BASE_URL', plugins_url('',  __FILE__ ));
define('INSTAFOOD_QR_MOBILE_APP_URL', plugins_url('frontend/mobile-app',  __FILE__ ));
define('INSTAFOOD_PREVIEW_MODE', false);


add_action( 'init', 'instafood_load_textdomain' );
 
function instafood_load_textdomain() {
    load_plugin_textdomain('instafood', false, dirname( plugin_basename( __FILE__ ) ) . '/languages'); 
}

$qrInstance = new AppetitCore();
$qrInstance->run();


function instafood_handle_activation() {
    UserManagement::addRoles();
}

function instafood_handle_deactivation() {
    UserManagement::removeRoles();
}

register_activation_hook(__FILE__, 'instafood_handle_activation');
register_deactivation_hook(__FILE__, 'instafood_handle_deactivation');


?>