<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../cpt/MenuItemCpt.php');
require_once(plugin_dir_path(__FILE__) . '../utils/PriceUtil.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt;
use com\sakuraplugins\appetit\utils\PriceUtil;


class ProductSevice {

    private static $instance = null;
    private $products = [];

    public function getAllProducts() {
        if (isset($this->products) && is_array($this->products) && sizeof($this->products) > 0) {
            return $this->products;
        }
        $args = [
            'posts_per_page' => -1,
            'post_type'      => MenuItemCpt::getPostType(),
            'post_status'    => 'publish',
        ];
        $the_query = new \WP_Query($args);
        if ($the_query->have_posts()) {
            while ($the_query->have_posts()) {
                $the_query->the_post();
                $post_id = get_the_ID();
                $post_meta = get_post_meta($post_id, MenuItemCpt::getMetaKey(), true);

                $product = new \stdClass();
                $product->ID = get_the_ID();
                $product->title = get_the_title();
                $product->meta = $post_meta;
                if (isset($product->meta)) {
                    if (isset($product->meta['product_variations']) && is_array($product->meta['product_variations'])) {
                        foreach ($product->meta['product_variations'] as $key => $variation) {
                            if (isset($variation['price']) && $variation['price'] !== '') {
                                $product->meta['product_variations'][$key]['price_display'] = PriceUtil::getInstance()->getPriceDisplay($variation['price']);
                            } else {
                                $product->meta['product_variations'][$key]['price_display'] = PriceUtil::getInstance()->getPriceDisplay(0);
                            }
                        }
                    }
                    if (isset($product->meta['square_photo']) && $product->meta['square_photo'] !== '') {
                        $product->meta['square_photo_images'] = $this->getAppetitImagesFromId($product->meta['square_photo']);
                    }
                    if (isset($product->meta['landscape_photo']) && $product->meta['landscape_photo'] !== '') {
                        $product->meta['landscape_photo_images'] = $this->getAppetitImagesFromId($product->meta['landscape_photo']);
                    }
                }
                array_push($this->products, $product);
            }
        }
        wp_reset_postdata();
        wp_reset_query();
        return $this->products;
    }

    public function getAppetitImagesFromId($id, $sizes = [
        'appetit-cover-large', 'appetit-cover-medium', 'appetit-aquare-large', 'appetit-aquare-medium', 'appetit-aquare-small'
    ]): array {
        $images = [];
        if (isset($id) && $id !== '') {
            foreach ($sizes as $size) {
                $image_data = wp_get_attachment_image_src($id, $size);
                if (is_array($image_data) && isset($image_data[0])) {
                    $images[$size] = $image_data[0];
                }
            }
        }
        return $images;
    }

    public static function getProduct(int $productId) {
        $postResult = get_post($productId);
        if ($postResult->post_status !== 'publish') {
            return false;
        }
        return $postResult;
    }

    public static function getProductMeta(int $productId) {
        return get_post_meta($productId, MenuItemCpt::getMetaKey(), true);
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new ProductSevice();
        }
        return self::$instance;
    }
}
?>