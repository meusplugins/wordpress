<?php

namespace ACFML\Upgrade\Commands;

interface Command {

	public static function run();
}
