"use strict";
(function() {
    toastr.options = {
        "debug": false,
        "positionClass": "toast-bottom-full-width",
        "onclick": null,
        "fadeIn": 300,
        "fadeOut": 800,
        "timeOut": 2000,
        "extendedTimeOut": 800
    }

    function handleUpload() {
        jQuery('.upload_img_ui').each(function(index) {
            const upload_img_ui = jQuery(this);
            const remove_btn = jQuery(this).find('.remove_btn');
            const photo_id = jQuery(this).find('.photo_id');
            jQuery(this).find('.upload_btn').click(function(event) {
                event.preventDefault();
                AppetitMediaUpload(false, (items) => {
                    if (lodash.isArray(items) && items.length > 0) {
                        upload_img_ui.find('.item-image-uploaded').empty();
                        const imgHtml = `
                        <img src="${lodash.get(items, '[0].attributes.sizes.medium.url', '')}" />
                        `;
                        jQuery(imgHtml).appendTo(upload_img_ui.find('.item-image-uploaded'));
                        remove_btn.removeClass('d-none');
                        photo_id.val(lodash.get(items, '[0].attributes.id', ''));
                        jQuery('.general_settings_accordion').accordion('refresh');
                    }
                })
            })
            remove_btn.click(function(event) {
                event.preventDefault();
                upload_img_ui.find('.item-image-uploaded').empty();
                remove_btn.addClass('d-none');
                photo_id.val('');
            });
        })
    }

    function handleBussinessHours(dayEntryUI) {
        const day_raw_data = dayEntryUI.find('.day_raw_data');
        const intervalsUI = dayEntryUI.find('.day-intervals');
        const day_add_interval_btn = dayEntryUI.find('.day-add-interval');

        dayEntryUI.find('.day_abailable_cb').change(function() {
            handleBussinessHoursError();
        });
        

        day_add_interval_btn.click(function(event) {
            event.preventDefault();
            const newIntervalUI = jQuery(getIntervalHtml());
            newIntervalUI.insertBefore(day_add_interval_btn);
            handleInterval(newIntervalUI);
            persistData();
        });


        intervalsUI.find('.day-interval').each(function(index) {
            handleInterval(jQuery(this));
        })

        const persistData = function() {
            // persist data
            const intervals = [];
            intervalsUI.find('.day-interval').each(function(index) {
                const intervalUI = jQuery(this);
                const interval_start = intervalUI.find('.interval-start');
                const am_pm_select_start = interval_start.find('.am_pm_select');
                const interval_stop = intervalUI.find('.interval-stop');
                const am_pm_select_stop = interval_stop.find('.am_pm_select');
                const remove_interval_btn = intervalUI.find('.remove_interval_btn');

                intervals.push({
                    interval_start_hh: padNumber(interval_start.find('.hours').val()),
                    interval_start_mm: padNumber(interval_start.find('.minutes').val()),
                    interval_stop_hh: padNumber(interval_stop.find('.hours').val()),
                    interval_stop_mm: padNumber(interval_stop.find('.minutes').val()),
                    am_pm_select_start: am_pm_select_start.find(':selected').val(),
                    am_pm_select_stop: am_pm_select_stop.find(':selected').val(),
                });
            })
            day_raw_data.text(JSON.stringify(intervals))
        }

        function handleInterval(intervalUI) {
            const interval_start = intervalUI.find('.interval-start');
            const am_pm_select_start = interval_start.find('.am_pm_select');
            const interval_stop = intervalUI.find('.interval-stop');
            const am_pm_select_stop = interval_stop.find('.am_pm_select');
            const remove_interval_btn = intervalUI.find('.remove_interval_btn');

            am_pm_select_start.on('change', function() {
                persistData();
            })

            am_pm_select_stop.on('change', function() {
                persistData();
            })

            const hourValidator = function(val) {
                const intVal = parseInt(val, 10);
                if (isNaN(intVal)) {
                    return 0;
                }
                if (intVal < 0) {
                    return 0;
                }
                if (intVal > 12) {
                    return 12;
                }
                return intVal;
            }

            const minutesValidator = function(val) {
                const intVal = parseInt(val, 10);
                if (isNaN(intVal)) {
                    return 0;
                }
                if (intVal < 0) {
                    return 0;
                }
                if (intVal > 59) {
                    return 59;
                }
                return intVal;
            }

            interval_start.find('.hours').on('keyup', function(event) {
                jQuery(this).val(hourValidator(jQuery(this).val()));
                persistData();
            })
            interval_start.find('.hours').on('change', function(event) {
                jQuery(this).val(hourValidator(jQuery(this).val()));
                persistData();
            })
            interval_start.find('.minutes').on('keyup', function(event) {
                jQuery(this).val(minutesValidator(jQuery(this).val()));
                persistData();
            })
            interval_start.find('.minutes').on('change', function(event) {
                jQuery(this).val(minutesValidator(jQuery(this).val()));
                persistData();
            })

            interval_stop.find('.hours').on('keyup', function(event) {
                jQuery(this).val(hourValidator(jQuery(this).val()));
                persistData();
            })
            interval_stop.find('.hours').on('change', function(event) {
                jQuery(this).val(hourValidator(jQuery(this).val()));
                persistData();
            })
            interval_stop.find('.minutes').on('keyup', function(event) {
                jQuery(this).val(minutesValidator(jQuery(this).val()));
                persistData();
            })
            interval_stop.find('.minutes').on('change', function(event) {
                jQuery(this).val(minutesValidator(jQuery(this).val()));
                persistData();
            })

            remove_interval_btn.click(function(event) {
                event.preventDefault();
                intervalUI.remove();
                persistData();
            })
        }

        function getIntervalHtml() {
            return `
<div class="day-interval">
    <div class="interval-start-stop interval-start mr_10">
        <div class="info">${APPETIT_SETTINGS.locales.start}</div>
        <div class="interval-controls">
            <div class="handle-counter apt-display-flex">                                             
                <input min="1" max="12" class="counter_input hours" type="number" value="09">
                <div class="ml_5 mr_5">:</div>
                <input min="0" max="59" class="counter_input minutes" type="number" value="00">
            </div>
            <select class="am_pm_select ml_5" name="">
                <option value="AM">${APPETIT_SETTINGS.locales.am}</option>
                <option value="PM">${APPETIT_SETTINGS.locales.pm}</option>
            </select>
        </div>
    </div>
    <div>-</div>
    <div class="interval-start-stop interval-stop mr_10">
        <div class="info">${APPETIT_SETTINGS.locales.stop}</div>
        <div class="interval-controls">
            <div class="handle-counter apt-display-flex">                                             
                <input min="1" max="12" class="counter_input hours" type="number" value="09">
                <div class="ml_5 mr_5">:</div>
                <input min="0" max="59" class="counter_input minutes" type="number" value="00">
            </div>
            <select class="am_pm_select ml_5" name="">
                <option value="AM">${APPETIT_SETTINGS.locales.am}</option>
                <option selected value="PM">${APPETIT_SETTINGS.locales.pm}</option>
            </select>
        </div>
    </div>
    <a class="remove_interval_btn" href="#"><span class="icon-trash-2"></span></a>
</div>
            `;
        }

    }

    function handleCounter(counterUI) {
        const minus_btn = counterUI.find('.counter-minus');
        const minus_plus = counterUI.find('.counter-plus');

        minus_btn.click(function(event) {
            event.preventDefault();
        })
        minus_plus.click(function(event) {
            event.preventDefault();
        })
    }

    function hasAtLeastOneDayWithBussinessHours() {
        let out = false;
        jQuery('.day-entry').each(function(index) {
            const isChecked = jQuery(this).find('.day_abailable_cb').is(':checked');
            const hasIntervals = jQuery(this).find('.day_raw_data').html().trim() !== '';
            if (isChecked && hasIntervals) {
                out = true;
            }
        })
        return out;
    }
    
    function handleBussinessHoursError() {
        const hasBussinesHours = hasAtLeastOneDayWithBussinessHours();
        if (!hasBussinesHours) {
            jQuery('#pickup_order_enabled_id').prop('checked', false);
            jQuery('.pickup_error_info').show();
        } else {
            jQuery('.pickup_error_info').hide();
        }
    }

    function handlePickupEnabled() {
        jQuery('.pickup_error_info').hide();
        jQuery('#pickup_order_enabled_id').change(function() {
            if(this.checked) {
                handleBussinessHoursError();
            } else {
                jQuery('.pickup_error_info').hide();
            }
        });
    }

    jQuery(document).ready(function() {
        handleUpload();
        jQuery('.select_currency').select2();
        jQuery('.select_timezone').select2();
        jQuery('.day-entry').each(function(index) {
            handleBussinessHours(jQuery(this));
        })
        handlePickupEnabled();
        _handleQrCodes();
    });

    // utils
    const padNumber = function(n) {
        const intNo = parseInt(n, 10);
        if (isNaN(intNo)) {
            return '00';
        }
        if (intNo < 10) {
            return `0${intNo}`
        }
        return intNo;
    }

})()

let map;
let marker;
let geocoder;
let restaurant_address_input;
let geocode_btn;
let restaurant_lat;
let restaurant_lng;

function initAdminGmap() {
    restaurant_address_input = jQuery('#restaurant_address_input');
    geocode_btn = jQuery('#geocode_btn');
    restaurant_lat = jQuery('#restaurant_lat');
    restaurant_lng = jQuery('#restaurant_lng');

    restaurant_address_input.on('keyup', function() {
        if (this.value !== '') {
            geocode_btn.attr('disabled', false);
        } else {
            geocode_btn.attr('disabled', true);
        }
    })

    geocode_btn.click(function(event) {
        event.preventDefault();
        if (restaurant_address_input.val() === '') {
            alert(`${APPETIT_SETTINGS.locales.restaurant_empty_address}`);
            return;
        }
        geocode({ address: restaurant_address_input.val() })
        restaurant_address_input.val('');
    })

    geocoder = new google.maps.Geocoder();

    let initialPosition = { lat: parseFloat(restaurant_lat.val()), lng: parseFloat(restaurant_lng.val()) };
    map = new google.maps.Map(document.getElementById("apt-gmap"), {
        zoom: 15,
        center: initialPosition,
        mapTypeControl: false,
    });

    marker = new google.maps.Marker({
        map: map,
        draggable: true,
        animation: google.maps.Animation.DROP,
        position: initialPosition
    });

    marker.addListener('dragend', function(data) {
        updateGeo({
            lat: data.latLng.lat(),
            lng: data.latLng.lng()
        })
    });

    function geocode(request) {
        geocoder
        .geocode(request)
        .then((result) => {
          const { results } = result;
    
          map.setCenter(results[0].geometry.location);
          marker.setPosition(results[0].geometry.location);
          marker.setMap(map);
          updateGeo({
              lat: results[0].geometry.location.lat(), 
              lng: results[0].geometry.location.lng()
          })
          return results;
        })
        .catch((e) => {
          alert(APPETIT_SETTINGS.locales.restaurant_geocode_error + e);
        })
    }

    function updateGeo(geo) {
        restaurant_lat.val(geo.lat);
        restaurant_lng.val(geo.lng);
        toastr.success(lodash.get(APPETIT_SETTINGS, 'locales.restaurant_geocode_success', ''), '', {
            iconClass: "appetit-toast-custom",
        });
    }
}


function _handleQrCodes() {
    
    const createQrCode = (parentUI, canvasId, tableNo) => {
        
        const { colorLight, colorDark, mobileAppPageUrl } = APPETIT_SETTINGS?.options;
        const { qr_code_download, qr_delete_table, table_delete_warn } = APPETIT_SETTINGS?.locales;

        let text = mobileAppPageUrl;

        parentUI.empty();
        jQuery(`<div id="${ canvasId }"></div>`).appendTo(parentUI);
        
        let tableNoImg = '';

        if (tableNo !== false) {
            _createDummy(`${ canvasId }_dummy`, tableNo, parentUI, colorDark, colorLight);
            const dummyCanvas = document.getElementById(`${ canvasId }_dummy`);
            tableNoImg = dummyCanvas.toDataURL("image/png", 1.0);

            const currentUrl = text;
            const url = new URL(currentUrl);
            const search_params = url.searchParams;
            
            search_params.set('ift', tableNo);
    
            url.search = search_params.toString();
            text = url.toString();
        }

        let optionsCanvasVisible = {
            text,
            width: 150,
            height: 150,
            colorDark,
            colorLight,
            correctLevel : QRCode.CorrectLevel.H, // L, M, Q, H
        };

        if (tableNo !== false) {
            optionsCanvasVisible.logo = tableNoImg;
        }
        
        // Create QRCode Object
        const canvasDataSmall = new QRCode(document.getElementById(canvasId), optionsCanvasVisible);

        const canvasLargeUI = jQuery(`<div style="display: none;" id="${canvasId}_large"></div>`);
        canvasLargeUI.appendTo(parentUI);
        let optionsCanvasHidden = { ...optionsCanvasVisible, width: 600, height: 600 };
        const canvasDataLarge = new QRCode(document.getElementById(`${canvasId}_large`), optionsCanvasHidden);
        
        const buttons_ui = jQuery(`<div style="margin-top: 15px;" class="buttons_ui"></div>`);
        buttons_ui.appendTo(parentUI);

        const download_qr_btn = jQuery(`<button type="button" style="margin-right: 15px;" class="btn btn-secondary download_qr_btn">${ qr_code_download }</button>`);

        download_qr_btn.appendTo(buttons_ui);
        download_qr_btn.click(function(event) {
            event.preventDefault();
            const canvasLarge = canvasLargeUI.find('canvas')[0];
            const imageCanvasLarge = canvasLarge.toDataURL("image/png", 1.0).replace("image/png", "image/octet-stream");
            
            const fileName = tableNo !== false ? `${tableNo}_qr.png` : `qr.png`;
            var link = document.createElement('a');
            link.download = fileName;
            link.href = imageCanvasLarge;
            link.click();
        })

        const table_entry_ui = parentUI.parent().parent().parent();

        const delete_table_btn = jQuery(`<button type="button" class="btn btn-danger">${ qr_delete_table }</button>`)
        delete_table_btn.appendTo(buttons_ui);
        delete_table_btn.click(function(event) {
            event.preventDefault();
            if (confirm(table_delete_warn)) {
                parentUI, table_entry_ui.remove();
            }
        })
    }

    const _createDummy = (canvasId, tableNo, parentUI, colorDark, colorLight) => {
        const w = 200, h = 200;
        const dummy = jQuery(`<canvas id="${ canvasId }" style="display: none;" width="${ w }" height="${ h }">`)
        dummy.appendTo(parentUI);

        var c = document.getElementById(canvasId);
        var ctx = c.getContext("2d");

        ctx.fillStyle = colorLight;
        ctx.fillRect(0, 0, c.width, c.height);
        
        ctx.font = "100px Arial";
        
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = colorDark;
        ctx.fillText(tableNo, w / 2, h / 2);
    }

    const qr_tables_ui = jQuery('.qr_tables_ui');

    function _addTable() {

        const { table_no, table_no_ex, table_description, table_description_ex } = APPETIT_SETTINGS?.locales;
        const { options_group_slug } = APPETIT_SETTINGS?.options;

        const uuid = _generate_uuidv4();
        const template = `
        <div class="row qr_table_entry">
            <div class="apt_hr mt_20 mb_20"></div>

            <div class="col-md-6">
                <div class="apt-option-entry mb_10">
                    <div id="${ uuid }" class="qr_canvas_ui"></div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="apt-option-entry mb_10">
                    <label class="option-entry-label">${ table_no }</label>
                    <input type="number"
                        value="" 
                        name="${ options_group_slug }[qr_tables_no][]"
                        class="form-control table_no_input">
                    <div class="option-entry-info">${ table_no_ex }</div>
                </div>
                <div class="apt-option-entry mb_10">
                    <label class="option-entry-label">${ table_description }</label>
                    <input type="text"
                        value="" 
                        name="${ options_group_slug }[qr_tables_desc][]"
                        class="form-control">
                    <div class="option-entry-info">${ table_description_ex }</div>
                </div>
            </div>
        </div>
        `;
        const table_ui = jQuery(template);
        table_ui.prependTo(qr_tables_ui);
        createQrCode(table_ui.find('.qr_canvas_ui'), uuid, false);
        table_ui.find('.table_no_input').keyup(function() {
            const tableNo = jQuery(this).val() !== '' ? jQuery(this).val() : false;
            createQrCode(table_ui.find('.qr_canvas_ui'), uuid, tableNo);
        })
    }


    jQuery('.add_table_btn').click(function(event) {
        event.preventDefault();
        _addTable();
    })

    // render general QR code
    const { mobileAppPageUrl } = APPETIT_SETTINGS?.options;
    createQrCode(jQuery('.general_qr_ui'), 'general_qr', false);

    jQuery('.qr_table_entry').each(function(index) {
        const table_ui = jQuery(this);
        let tableNo = table_ui.find('.table_no_input').val();
        if (!tableNo || tableNo === '') {
            tableNo = false;
        }
        const uuid = table_ui.find('.qr_canvas_ui').attr('id');
        
        createQrCode(table_ui.find('.qr_canvas_ui'), uuid, tableNo);
        table_ui.find('.table_no_input').keyup(function() {
            const tableNo = jQuery(this).val() !== '' ? jQuery(this).val() : false;
            createQrCode(table_ui.find('.qr_canvas_ui'), uuid, tableNo);
        })
    })
}

function _generate_uuidv4() {
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
}

// handle PrintNode
(function() {
    function initPrintNode() {
        const refreshPrintersBtn = jQuery('#refresh_connected_printers');
        const printers_loading = jQuery('#printers_loading');
        handleLoad();

        function handleLoad(show = false) {
            const handle = show ? printers_loading.show() : printers_loading.hide();
        }

        const initialKey = jQuery('#printnode_api_key_id').val();
        const hasInitialKey = initialKey !== '';

        jQuery('#printnode_api_key_id').keyup(function(event) {
            if (hasInitialKey && initialKey === jQuery('#printnode_api_key_id').val()) {
                return;
            }
            jQuery('.retrive_printers_content').hide();
            jQuery('.retrive_printers_content_info').show();
        })

        refreshPrintersBtn.click(function(event) {
            event.preventDefault();
            handleLoad(true);
            jQuery('#printers_list').empty();
            jQuery('#printers_error').hide();
            const serviceAjx = new AjaxService();
            serviceAjx.post('get_printnode_printers', {})
            .then(response => {
                handleLoad(false);
                if (response?.data?.error) {
                    jQuery('#printers_error').show();
                    jQuery('#printers_error').html(`
                    <p style="color: red">PrintNode Error: ${response?.data?.error?.message ? response?.data?.error?.message : 'Unknown Error'}</p>
                    `);
                    return;
                }
                const printers = Array.isArray(response?.data) ? response?.data : [];
                let html = ``;
                printers.map(printer => {
                    html += `<li style="color: #838383; font-style: italic;">- ${printer?.name ? printer.name : 'Unknown name'} (${ printer?.description ? printer.description : 'Unknown description' })</li>`;
                })
                jQuery('#printers_list').html(html);
            })
            .catch(err => {
                handleLoad(false);
            })
        })
    }

    jQuery(document).ready(function() {
        initPrintNode();
    })
})()

function AjaxService() {
    this.post = function(action, payload) {
        const data = {action, ...payload};
    
        return new Promise((resolve, reject) => {
            jQuery.post(ajaxurl, data, function(responseRaw) {
                try {
                    const response = JSON.parse(responseRaw);
                    resolve(response);
                } catch (err) {
                    reject(err);
                    console.log(err);
                }
            });
        })
    }
}