"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function ($) {
  "use strict";

  var GlobalAnimation = elementorModules.frontend.handlers.Base.extend({
    tween: null,
    colorTargets: null,
    onInit: function onInit() {
      if (typeof gsap === "undefined") {
        return;
      }
      if (typeof ScrollTrigger !== "undefined") {
        gsap.registerPlugin(ScrollTrigger);
      }
      elementorModules.frontend.handlers.Base.prototype.onInit.apply(this, arguments);
      this.initAnimation();
    },
    onElementChange: function onElementChange(changedProp) {
      if (changedProp && changedProp.indexOf('ha_ga_') === 0) {
        this.initAnimation();
      }
    },
    onDestroy: function onDestroy() {
      this.destroyAnimation();
      elementorModules.frontend.handlers.Base.prototype.onDestroy.apply(this, arguments);
    },
    initAnimation: function initAnimation() {
      var settings = this.getElementSettings();
      if (settings.ha_ga_switcher !== 'yes') {
        return;
      }

      // Reset any previous animation state before (re)building.
      this.destroyAnimation();
      var isEdit = elementorFrontend.isEditMode();
      var editorPreview = this.getResponsiveSetting('ha_ga_enable_editor_preview');
      if (isEdit && editorPreview !== 'yes') {
        return;
      }

      // "Enable On Mobile" toggle (default on).  When the user turns it
      // off, skip building any tween while the viewport is in a mobile
      // breakpoint.  Works on both the frontend and the editor device
      // preview because getCurrentDeviceMode() is matchMedia-driven.
      var enableMobile = this.getResponsiveSetting('ha_ga_enable_mobile');
      var deviceMode = elementorFrontend.getCurrentDeviceMode();
      var isMobile = deviceMode === 'mobile' || deviceMode === 'mobile_extra';
      if (isMobile && enableMobile !== 'yes') {
        return;
      }
      var method = this.getResponsiveSetting('ha_ga_animation') || 'from';
      var triggerMode = this.getResponsiveSetting('ha_ga_trigger_mode') || 'scroll';
      var wrapper = this.getResponsiveSetting('ha_ga_wrapper') || 'default';
      var easing = this.getResponsiveSetting('ha_ga_easing') || 'power2.out';
      var customProps = settings.ha_ga_custom_props;
      var config = this.buildConfig(customProps, easing);

      // Ease alone is not enough to animate.
      var hasProps = Object.keys(config).some(function (key) {
        return key !== 'ease';
      });
      if (!hasProps) {
        return;
      }
      this.applyAnimation({
        method: method,
        triggerMode: triggerMode,
        wrapper: wrapper,
        config: config
      });
    },
    destroyAnimation: function destroyAnimation() {
      var wrapper = this.$element[0];
      if (!wrapper) {
        return;
      }
      var target = this.getAnimationTarget();
      if (typeof gsap !== "undefined") {
        if (target) {
          gsap.killTweensOf(target);
        }
        if (this.colorTargets && this.colorTargets.length) {
          gsap.killTweensOf(this.colorTargets);
          gsap.set(this.colorTargets, {
            clearProps: 'color'
          });
          this.colorTargets = null;
        }
        if (target !== wrapper) {
          gsap.killTweensOf(wrapper);
        }
      }
      if (typeof ScrollTrigger !== "undefined") {
        var triggers = [wrapper];
        if (target && target !== wrapper) {
          triggers.push(target);
        }
        ScrollTrigger.getAll().forEach(function (st) {
          if (st.vars && triggers.indexOf(st.vars.trigger) !== -1) {
            st.kill();
          }
        });
      }
      this.$element.removeClass('ha-ga-animating');
      this.$element.css('transition', '');
      if (target) {
        target.style.willChange = '';
        target.style.transition = '';
      }
      this.tween = null;
    },
    /**
     * Resolve the actual DOM element to animate.
     *
     * For image widgets the inner <img> is targeted so that CSS sizing
     * properties (width, height, min/max, borderRadius, padding) and
     * transforms actually affect the image itself, not the wrapper div.
     */
    getAnimationTarget: function getAnimationTarget() {
      var el = this.$element[0];
      if (!el) {
        return null;
      }
      if (el.tagName === 'IMG') {
        return el;
      }
      if (this.$element.hasClass('elementor-widget-image')) {
        var img = el.querySelector('img');
        if (img) {
          return img;
        }
      }
      return el;
    },
    applyAnimation: function applyAnimation(opts) {
      var method = opts.method;
      var triggerMode = opts.triggerMode;
      var wrapper = opts.wrapper;
      var config = opts.config;
      var $target = this.$element;
      var targetEl = this.getAnimationTarget();
      if (!targetEl) {
        return;
      }
      if (typeof gsap[method] !== 'function') {
        method = 'from';
      }
      var tweenVars = $.extend({}, config);

      // Trigger mode mapping:
      //   scroll         -> On Appearing (play once when entering viewport)
      //   playwithscroll -> On Scroll (scrubbed to scroll position)
      //   onPageLoad     -> On Page Load (run immediately, no ScrollTrigger)
      var isEdit = elementorFrontend.isEditMode();
      var isScrollBased = !isEdit && (triggerMode === 'scroll' || triggerMode === 'playwithscroll');
      if (isScrollBased) {
        var st = {
          trigger: targetEl,
          start: 'top 85%'
        };
        if (triggerMode === 'playwithscroll') {
          st.scrub = true;
        } else {
          st.toggleActions = 'play none none none';
        }
        if (wrapper === 'custom') {
          var startPos = this.getResponsiveSetting('ha_ga_anim_start');
          var startCustom = this.getResponsiveSetting('ha_ga_anim_start_custom');
          var endPos = this.getResponsiveSetting('ha_ga_anim_end');
          var endCustom = this.getResponsiveSetting('ha_ga_anim_end_custom');
          var markers = this.getResponsiveSetting('ha_ga_markers');
          if (startPos === 'custom') {
            if (startCustom) {
              st.start = startCustom;
            }
          } else if (startPos) {
            st.start = this.convertPosition(startPos);
          }
          if (endPos === 'custom') {
            if (endCustom) {
              st.end = endCustom;
            }
          } else if (endPos) {
            st.end = this.convertPosition(endPos);
          }
          if (markers === 'yes') {
            st.markers = true;
          }
        }
        tweenVars.scrollTrigger = st;
      }
      var isScrub = isScrollBased && triggerMode === 'playwithscroll';

      // Scrubbed ("On Scroll") animations must track the scroll position
      // 1:1. When no easing is selected we pass 'none' explicitly,
      // otherwise GSAP falls back to its default ease (power1.out) which
      // front-loads the tween and makes it complete before the end point
      // (and look stuttery as it reaches the end).
      if (isScrub && !tweenVars.ease) {
        tweenVars.ease = 'none';
      }

      // For a scrubbed `from` tween, transformPerspective / transformOrigin
      // are constant *setup* values, not animation targets. 
      if (isScrub && method === 'from') {
        var baseline = {};
        if (config.transformPerspective !== undefined) {
          baseline.transformPerspective = config.transformPerspective;
        }
        if (config.transformOrigin !== undefined) {
          baseline.transformOrigin = config.transformOrigin;
        }
        if (Object.keys(baseline).length) {
          gsap.set(targetEl, baseline);
        }
      }
      gsap.killTweensOf(targetEl);

      // The .ha-ga-animation class promotes the *wrapper* to a GPU layer,
      // but the transform is applied to `targetEl` (e.g. the <img>). 
      targetEl.style.willChange = 'transform';
      targetEl.style.transition = 'none';
      $target.css('transition', 'none');
      $target.removeClass('ha-ga-animating');

      // 3D flips (rotateX/rotateY 180deg via transformPerspective) must render properly.
      if (config.transformPerspective !== undefined) {
        targetEl.style.WebkitBackfaceVisibility = 'visible';
        targetEl.style.backfaceVisibility = 'visible';
      }
      var clearOnComplete = method === 'from' && triggerMode !== 'playwithscroll';
      var clearProps = clearOnComplete ? this.buildClearProps(config) : '';
      this.tween = gsap[method](targetEl, $.extend({}, tweenVars, {
        onStart: function onStart() {
          targetEl.style.willChange = 'transform';
          targetEl.style.transition = 'none';
          $target.css('transition', 'none');
          $target.addClass('ha-ga-animating');
        },
        onComplete: function onComplete() {
          $target.removeClass('ha-ga-animating');
          if (clearOnComplete && clearProps) {
            gsap.set(targetEl, {
              clearProps: clearProps
            });
          }
          // The element is at rest here (no transform delta), so
          // restoring the transition is instant and won't stutter.
          targetEl.style.transition = '';
          $target.css('transition', '');
        }
      }));
      if (config.color !== undefined) {
        this.applyColorAnimation(targetEl, method, tweenVars, clearOnComplete);
      }
      if (isScrollBased && typeof ScrollTrigger !== "undefined") {
        setTimeout(function () {
          if (typeof ScrollTrigger !== "undefined") {
            ScrollTrigger.refresh();
          }
        }, 120);
      }
    },
    /**
     * Animate the `color` property on the real text-bearing elements.
     *
     * Elementor renders text colours on inner elements (e.g.
     * .elementor-heading-title, .elementor-button-text), so we need to animate those instead of the wrapper element.
     */
    applyColorAnimation: function applyColorAnimation(targetEl, method, tweenVars, clearOnComplete) {
      var colorEls = this.getTextColorTargets(targetEl);
      if (!colorEls || !colorEls.length) {
        return;
      }
      this.colorTargets = colorEls;
      gsap.killTweensOf(colorEls);

      // Whitelist: colour + timing only.  Everything else (border,
      // boxShadow, transforms, sizing, …) remains exclusive to the main target element.
      var colorVars = {
        color: tweenVars.color
      };
      var timingKeys = ['ease', 'duration', 'delay', 'repeat', 'repeatDelay', 'yoyo', 'force3D'];
      timingKeys.forEach(function (key) {
        if (tweenVars[key] !== undefined) {
          colorVars[key] = tweenVars[key];
        }
      });
      if (tweenVars.scrollTrigger) {
        colorVars.scrollTrigger = $.extend(true, {}, tweenVars.scrollTrigger);
      }
      gsap[method](colorEls, $.extend({}, colorVars, {
        onComplete: function onComplete() {
          if (clearOnComplete) {
            gsap.set(colorEls, {
              clearProps: 'color'
            });
          }
        }
      }));
    },
    /**
     * Resolve the descendant elements that actually carry the text colour
     * for the most common Elementor widgets.  Falls back to generic heading
     * / paragraph / anchor tags when no widget-specific selector matches.
     */
    getTextColorTargets: function getTextColorTargets(wrapper) {
      if (!wrapper || !wrapper.querySelectorAll) {
        return null;
      }
      var selectors = ['.elementor-heading-title', '.elementor-button-text', '.elementor-button', '.elementor-icon-box-title', '.elementor-icon-box-description', '.elementor-icon-box-content', '.elementor-counter-number', '.elementor-counter-number-wrapper', '.elementor-counter-title', '.elementor-testimonial-name', '.elementor-testimonial-job', '.elementor-star-rating', '.elementor-price-list-title', '.elementor-price-list-description', '.elementor-price-list-price', '.elementor-tab-title', '.elementor-tab-content', '.elementor-accordion-title', '.elementor-toggle-title'];
      var targets = [];
      var seen = {};
      selectors.forEach(function (sel) {
        var els = wrapper.querySelectorAll(sel);
        for (var i = 0; i < els.length; i++) {
          if (!seen[els[i]]) {
            seen[els[i]] = true;
            targets.push(els[i]);
          }
        }
      });
      if (!targets.length) {
        var els = wrapper.querySelectorAll('h1, h2, h3, h4, h5, h6, p, a');
        for (var i = 0; i < els.length; i++) {
          targets.push(els[i]);
        }
      }
      return targets.length ? targets : null;
    },
    buildConfig: function buildConfig(customProps, easing) {
      var config = {};
      var ease = this.resolveEase(easing);
      if (ease) {
        config.ease = ease;
      }
      if (!customProps || !Array.isArray(customProps) || !customProps.length) {
        return config;
      }
      var self = this;
      customProps.forEach(function (item) {
        if (!item) {
          return;
        }
        var property = item.property;
        if (!property || property === 'none') {
          return;
        }
        var resolved = self.resolveProperty(item, property);
        if (resolved === null || resolved === undefined) {
          return;
        }
        if (_typeof(resolved) === 'object' && !Array.isArray(resolved)) {
          $.extend(config, resolved);
        } else {
          config[property] = resolved;
        }
      });
      return config;
    },
    resolveProperty: function resolveProperty(item, property) {
      switch (property) {
        case 'opacity':
        case 'autoAlpha':
          return this.sliderSize(this.getResponsiveItemValue(item, 'value_opacity'));
        case 'scale':
        case 'scaleX':
        case 'scaleY':
          return this.sliderSize(this.getResponsiveItemValue(item, 'value_slider'));
        case 'x':
        case 'y':
        case 'width':
        case 'height':
          return this.sliderUnit(this.getResponsiveItemValue(item, 'value_position'));
        case 'maxWidth':
        case 'maxHeight':
        case 'minWidth':
        case 'minHeight':
          return this.sliderUnit(this.getResponsiveItemValue(item, 'value_size'));
        case 'rotate':
        case 'rotateX':
        case 'rotateY':
          return this.toFloat(this.getResponsiveItemValue(item, 'value_rotate'));
        case 'repeat':
          return this.toInt(this.getResponsiveItemValue(item, 'value_repeat'));
        case 'repeatDelay':
          return this.toFloat(this.getResponsiveItemValue(item, 'value_repeat_delay'));
        case 'delay':
          return this.sliderSize(this.getResponsiveItemValue(item, 'value_delay'));
        case 'duration':
          return this.sliderSize(this.getResponsiveItemValue(item, 'value_duration'));
        case 'transformOrigin':
          {
            var origin = item.value_transform_origin;
            if (origin === 'custom') {
              origin = item.value_transform_origin_custom;
            }
            return origin ? origin : null;
          }
        case 'transformPerspective':
          return this.sliderSize(this.getResponsiveItemValue(item, 'value_perspective'));
        case 'color':
          return this.getResponsiveItemValue(item, 'value_color') || null;
        case 'background':
          return this.getResponsiveItemValue(item, 'value_color') ? {
            backgroundColor: this.getResponsiveItemValue(item, 'value_color')
          } : null;
        case 'padding':
          return this.parseDimensions(this.getResponsiveItemValue(item, 'value_dimensions'), 'padding');
        case 'borderRadius':
          return this.parseDimensions(this.getResponsiveItemValue(item, 'value_dimensions'), 'borderRadius');
        case 'force3D':
        case 'yoyo':
          return item.value_switcher === 'yes' ? true : null;
        case 'border':
          return this.parseBorder(item);
        case 'boxShadow':
          return this.parseBoxShadow(item);
        case 'skew':
          {
            var sx = this.toFloat(this.getResponsiveItemValue(item, 'value_skew_x'));
            var sy = this.toFloat(this.getResponsiveItemValue(item, 'value_skew_y'));
            var obj = {};
            if (sx !== null) {
              obj.skewX = sx;
            }
            if (sy !== null) {
              obj.skewY = sy;
            }
            return Object.keys(obj).length ? obj : null;
          }
        case 'blur':
          {
            var v = this.sliderUnit(this.getResponsiveItemValue(item, 'value_blur')); // e.g. "5px" / "2em"
            if (!v) {
              return null;
            }
            return {
              filter: 'blur(' + v + ')'
            };
          }
        case 'flip':
          {
            var type = item.value_flip_type || 'mirror';
            var dir = item.value_flip_direction || 'horizontal';
            if (type === '3d') {
              var deg = this.toFloat(this.getResponsiveItemValue(item, 'value_flip_deg'));
              if (deg === null) {
                deg = 180;
              }
              // transformPerspective gives the 3D turn real depth without parent CSS changes.
              return dir === 'horizontal' ? {
                rotateY: deg,
                transformPerspective: 800
              } : {
                rotateX: deg,
                transformPerspective: 800
              };
            }
            return dir === 'horizontal' ? {
              scaleX: -1
            } : {
              scaleY: -1
            };
          }
        default:
          return this.parseScalar(item.value_text);
      }
    },
    sliderSize: function sliderSize(val) {
      if (val === null || val === undefined) {
        return null;
      }
      if (_typeof(val) === 'object') {
        if (val.size !== undefined && val.size !== '' && !isNaN(val.size)) {
          return parseFloat(val.size);
        }
        return null;
      }
      return this.toFloat(val);
    },
    sliderUnit: function sliderUnit(val) {
      if (val === null || val === undefined) {
        return null;
      }
      if (_typeof(val) === 'object') {
        if (val.size === undefined || val.size === '' || isNaN(val.size)) {
          return null;
        }
        var unit = val.unit || 'px';
        return val.size + unit;
      }
      return this.parseScalar(val);
    },
    toFloat: function toFloat(val) {
      if (val === undefined || val === null || val === '') {
        return null;
      }
      var n = parseFloat(val);
      return isNaN(n) ? null : n;
    },
    toInt: function toInt(val) {
      if (val === undefined || val === null || val === '') {
        return null;
      }
      var n = parseInt(val, 10);
      return isNaN(n) ? null : n;
    },
    parseScalar: function parseScalar(val) {
      if (val === undefined || val === null || val === '') {
        return null;
      }
      if (typeof val === 'string') {
        var lower = val.toLowerCase().trim();
        if (lower === 'true') {
          return true;
        }
        if (lower === 'false') {
          return false;
        }
        if (/^-?\d+(\.\d+)?$/.test(val)) {
          return parseFloat(val);
        }
        return val;
      }
      return val;
    },
    parseDimensions: function parseDimensions(dim, prop) {
      if (!dim) {
        return null;
      }
      var unit = dim.unit || 'px';
      var top = dim.top || 0;
      var right = dim.right || 0;
      var bottom = dim.bottom || 0;
      var left = dim.left || 0;
      if (!top && !right && !bottom && !left) {
        return null;
      }
      var result = {};
      if (top === right && right === bottom && bottom === left) {
        result[prop] = top + unit;
      } else {
        result[prop] = top + unit + ' ' + right + unit + ' ' + bottom + unit + ' ' + left + unit;
      }
      return result;
    },
    parseBorder: function parseBorder(item) {
      var w = item.value_border_width;
      var color = item.value_border_color;
      var style = item.value_border_style;

      // If the group control is completely empty, there's nothing to tween.
      if (!w && !color && !style) {
        return null;
      }
      var unit = w && w.unit ? w.unit : 'px';
      var top = w && w.top ? w.top : 0;
      // Fall back to "solid" so borderColor is actually visible.
      var borderStyle = style && style !== 'none' ? style : 'solid';
      var borderColor = color || 'currentColor';

      // Use the CSS `border` shorthand — confirmed in GSAP's CSSPlugin —
      // so width + style + color are applied together and reliably animate.
      return {
        border: top + unit + ' ' + borderStyle + ' ' + borderColor
      };
    },
    parseBoxShadow: function parseBoxShadow(item) {
      if (!item.value_box_shadow_type || item.value_box_shadow_type !== 'yes') {
        return null;
      }
      var h = this.shadowNum(item.value_box_shadow_horizontal);
      var v = this.shadowNum(item.value_box_shadow_vertical);
      var blur = this.shadowNum(item.value_box_shadow_blur);
      var spread = this.shadowNum(item.value_box_shadow_spread);
      var color = item.value_box_shadow_color || 'rgba(0,0,0,0.5)';
      var inset = item.value_box_shadow_position === 'inset' ? 'inset ' : '';
      return {
        boxShadow: inset + h + 'px ' + v + 'px ' + blur + 'px ' + spread + 'px ' + color
      };
    },
    shadowNum: function shadowNum(val) {
      if (val === undefined || val === null || val === '') {
        return 0;
      }
      if (_typeof(val) === 'object') {
        if (val.size !== undefined && val.size !== '' && !isNaN(val.size)) {
          return parseFloat(val.size);
        }
        return 0;
      }
      var n = parseFloat(val);
      return isNaN(n) ? 0 : n;
    },
    resolveEase: function resolveEase(ease) {
      if (!ease || ease === 'none') {
        return null;
      }
      if (ease === 'slowmo') {
        return 'slowMo';
      }
      if (ease === 'stepped') {
        return 'steps(12)';
      }
      return ease;
    },
    convertPosition: function convertPosition(pos) {
      if (!pos || pos === 'custom') {
        return null;
      }
      return String(pos).replace(/-/g, ' ');
    },
    buildClearProps: function buildClearProps(config) {
      var map = {
        x: 'transform',
        y: 'transform',
        scale: 'transform',
        scaleX: 'transform',
        scaleY: 'transform',
        rotation: 'transform',
        rotate: 'transform',
        rotateX: 'transform',
        rotateY: 'transform',
        rotationX: 'transform',
        rotationY: 'transform',
        skewX: 'transform',
        skewY: 'transform',
        opacity: 'opacity',
        autoAlpha: 'opacity,visibility',
        color: 'color',
        backgroundColor: 'background-color',
        background: 'background-color',
        width: 'width',
        height: 'height',
        maxWidth: 'max-width',
        maxHeight: 'max-height',
        minWidth: 'min-width',
        minHeight: 'min-height',
        padding: 'padding',
        borderRadius: 'border-radius',
        border: 'border',
        borderWidth: 'border-width',
        borderColor: 'border-color',
        borderStyle: 'border-style',
        boxShadow: 'box-shadow',
        transformOrigin: 'transform-origin',
        filter: 'filter',
        transformPerspective: 'transform'
      };
      var tweenVars = ['ease', 'delay', 'duration', 'repeat', 'repeatDelay', 'yoyo', 'force3D', 'onStart', 'onComplete', 'onUpdate', 'scrollTrigger', 'immediateRender', 'toggleActions', 'paused'];
      var set = {};
      Object.keys(config).forEach(function (key) {
        if (tweenVars.indexOf(key) !== -1) {
          return;
        }
        var css = map[key] || key;
        css.split(',').forEach(function (c) {
          set[c] = true;
        });
      });
      return Object.keys(set).join(',');
    },
    getResponsiveSetting: function getResponsiveSetting(controlName) {
      var settings = this.getElementSettings();
      var currentDevice = elementorFrontend.getCurrentDeviceMode();
      if (window.elementorFrontend && elementorFrontend.utils && elementorFrontend.utils.controls && typeof elementorFrontend.utils.controls.getResponsiveControlValue === 'function') {
        var devices = ['mobile', 'mobile_extra', 'tablet', 'tablet_extra', 'laptop', 'desktop', 'widescreen'];
        var currentIndex = devices.indexOf(currentDevice);
        var start = currentIndex >= 0 ? currentIndex : devices.indexOf('desktop');
        var i, value;
        for (i = start; i < devices.length; i++) {
          value = elementorFrontend.utils.controls.getResponsiveControlValue(settings, controlName, '', devices[i]);
          if (value !== undefined && value !== null && value !== '') {
            return value;
          }
        }
        for (i = start - 1; i >= 0; i--) {
          value = elementorFrontend.utils.controls.getResponsiveControlValue(settings, controlName, '', devices[i]);
          if (value !== undefined && value !== null && value !== '') {
            return value;
          }
        }
      }
      return this.getElementSettings(controlName);
    },
    /**
     * Resolve a single repeater item field for the active device.
     *
     * Responsive repeater controls store their per-device values under
     * suffixed keys (e.g. value_rotate_tablet).  Desktop uses the bare
     * key.  This mirrors the inheritance walk used by
     * getResponsiveSetting() so a missing device value falls back to the
     * next larger breakpoint and finally the desktop value.
     */
    getResponsiveItemValue: function getResponsiveItemValue(item, fieldName) {
      if (!item) {
        return undefined;
      }
      var currentDevice = elementorFrontend.getCurrentDeviceMode();
      var devices = ['mobile', 'mobile_extra', 'tablet', 'tablet_extra', 'laptop', 'desktop', 'widescreen'];
      var start = devices.indexOf(currentDevice);
      if (start === -1) {
        start = devices.indexOf('desktop');
      }
      var suffix, value, i;
      for (i = start; i < devices.length; i++) {
        suffix = devices[i] === 'desktop' ? '' : '_' + devices[i];
        value = item[fieldName + suffix];
        if (value !== undefined && value !== null && value !== '') {
          return value;
        }
      }
      for (i = start - 1; i >= 0; i--) {
        suffix = devices[i] === 'desktop' ? '' : '_' + devices[i];
        value = item[fieldName + suffix];
        if (value !== undefined && value !== null && value !== '') {
          return value;
        }
      }
      return item[fieldName];
    }
  });

  /**
   * Site-wide smooth scrolling is now handled by Lenis via the separate
   * "Smooth Scroll" feature toggle (see assets/dev/js/smooth-scroll.js).
   * The old GSAP ScrollSmoother wrapper setup has been removed so that
   * Elementor Motion Effects (Parallax/Sticky/Mouse) keep working.
   */

  $(window).on('elementor/frontend/init', function () {
    if (typeof gsap === "undefined") {
      return;
    }
    if (typeof ScrollTrigger !== "undefined") {
      gsap.registerPlugin(ScrollTrigger);
    }
    elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
      elementorFrontend.elementsHandler.addHandler(GlobalAnimation, {
        $element: $scope
      });
    });
  });
})(jQuery);