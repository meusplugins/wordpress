<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

abstract class Base_Condition {

	abstract public function get_key();

	/**
	 * Check condition.
	 *
	 * @param array $rule
	 * @param \Jet_Menu\Modules\Dynamic_Visibility\Context $context
	 *
	 * @return bool
	 */
	abstract public function check( $rule, $context );

	protected function get_rule_attrs( $rule ) {

		$attrs = isset( $rule['attrs'] ) ? $rule['attrs'] : array();
		$attrs = is_array( $attrs ) ? $attrs : array();

		return $attrs;
	}

	protected function get_rule_operator( $rule, $default = '=' ) {

		$attrs = $this->get_rule_attrs( $rule );

		$operator = isset( $attrs['operator'] ) ? $attrs['operator'] : $default;
		$operator = is_string( $operator ) ? $operator : $default;

		return $operator;
	}

	protected function get_rule_value( $rule, $key, $default = null ) {

		$attrs = $this->get_rule_attrs( $rule );

		if ( isset( $attrs[ $key ] ) ) {
			return $attrs[ $key ];
		}

		return $default;
	}
}