<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');
require_once(plugin_dir_path(__FILE__) . 'SettingsConfig.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\Config;

class LocalesSettings {
    public function render(): void {
        ?>
        <div class="apt-section-entry">
            <div class="apt-section-header">
                <span class="accordion-icon icon-chevron-right"></span>
                <?= esc_html__('Locales', 'instafood') ?>
            </div>
            <div class="apt-section-content"><?php $this->renderLocales() ?></div>
        </div>
        <?php
    }

    private function renderLocales() {
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-primary" role="alert" style="font-size: 14px;">
                        <?= esc_html__("Set up locales used across frontend. Note! Some locales contain variables (ex: <%= orderPrepareTime %>) You can change / swap the order of those variables within the locale string according to your language. Note !!! Variables should not be re-named.", 'instafood') ?>
                    </div>
                </div>
                <?php $this->renderAllLocales() ?>

                <div class="col-md-12">
                    <div class="apt_hr mt_20 mb_20"></div>
                    <button type="submit" class="btn btn-secondary float-right mb_20"><?php esc_html_e('Save settings', 'instafood'); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderAllLocales() {
        $apt_locales = OptionUtil::getInstance()->getOption("apt_locales", []);
        $locales_config = SettingsConfig::getLocales();
        ?>
        <?php for ($i=0; $i < sizeof($locales_config); $i++): ?>
            <?php 
                $defaultLocaleEntry = $locales_config[$i];
                $localeEntry = isset($apt_locales[$i]) ? $apt_locales[$i] : $defaultLocaleEntry;
                $localeEntryVal = isset($apt_locales[$defaultLocaleEntry['db_key']]) ? $apt_locales[$defaultLocaleEntry['db_key']] : [];
                $supports_html = $defaultLocaleEntry['supports_html'] ?? false;
            ?>
            <?php if ($supports_html): ?>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__($defaultLocaleEntry['label']); ?> <span class="inside_info">(<?= esc_html__('Primary language', 'instafood') ?>)</span></label>
                        <textarea 
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_locales][<?= $defaultLocaleEntry['db_key'] ?>][primary_lang_]"
                            class="form-control"><?= isset($localeEntryVal['primary_lang_']) ? $localeEntryVal['primary_lang_'] : $localeEntry['primary_lang_'] ?></textarea>

                            <?php if (isset($defaultLocaleEntry['info'])): ?>
                                <div class="option-entry-info"><?= esc_html__($defaultLocaleEntry['info']); ?></div>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__($defaultLocaleEntry['label']); ?> <span class="inside_info">(<?= esc_html__('Secondary language', 'instafood') ?>)</span></label>
                        <textarea 
                        name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_locales][<?= $defaultLocaleEntry['db_key'] ?>][secondary_lang_]"
                            class="form-control"><?= isset($localeEntryVal['secondary_lang_']) ? $localeEntryVal['secondary_lang_'] : $localeEntry['secondary_lang_'] ?></textarea>
                            <?php if (isset($defaultLocaleEntry['info'])): ?>
                                <div class="option-entry-info"><?= esc_html__($defaultLocaleEntry['info']); ?></div>
                            <?php endif; ?>

                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__($defaultLocaleEntry['label']); ?> <span class="inside_info">(<?= esc_html__('Primary language', 'instafood') ?>)</span></label>
                        <input type="text" value="<?= isset($localeEntryVal['primary_lang_']) ? esc_attr($localeEntryVal['primary_lang_']) : $localeEntry['primary_lang_']; ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_locales][<?= $defaultLocaleEntry['db_key'] ?>][primary_lang_]"
                            class="form-control">
                            <?php if (isset($defaultLocaleEntry['info'])): ?>
                                <div class="option-entry-info"><?= esc_html__($defaultLocaleEntry['info']); ?></div>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="apt-option-entry mb_10">
                        <label class="option-entry-label"><?= esc_html__($defaultLocaleEntry['label']); ?> <span class="inside_info">(<?= esc_html__('Secondary language', 'instafood') ?>)</span></label>
                        <input type="text" value="<?= isset($localeEntryVal['secondary_lang_']) ? esc_attr($localeEntryVal['secondary_lang_']) : $localeEntry['secondary_lang_']; ?>" 
                            name="<?= esc_attr(Config::getOptionsGroupSlug());?>[apt_locales][<?= $defaultLocaleEntry['db_key'] ?>][secondary_lang_]"
                            class="form-control">
                            <?php if (isset($defaultLocaleEntry['info'])): ?>
                                <div class="option-entry-info"><?= esc_html__($defaultLocaleEntry['info']); ?></div>
                            <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        <?php endfor; ?>
        <?php
    }
}