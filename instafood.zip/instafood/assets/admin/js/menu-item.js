"use strict";
(function() {

    const uuidv4 = function() {
        return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
          (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }

    toastr.options = {
        "debug": false,
        "positionClass": "toast-bottom-full-width",
        "onclick": null,
        "fadeIn": 300,
        "fadeOut": 800,
        "timeOut": 2000,
        "extendedTimeOut": 800
    }

    function handleUpload() {
        jQuery('.upload_img_ui').each(function(index) {
            const upload_img_ui = jQuery(this);
            const remove_btn = jQuery(this).find('.remove_btn');
            const photo_id = jQuery(this).find('.photo_id');
            jQuery(this).find('.upload_btn').click(function(event) {
                event.preventDefault();
                AppetitMediaUpload(false, (items) => {
                    if (lodash.isArray(items) && items.length > 0) {
                        upload_img_ui.find('.item-image-uploaded').empty();
                        const imgHtml = `
                        <img src="${lodash.get(items, '[0].attributes.sizes.medium.url', '')}" />
                        `;
                        jQuery(imgHtml).appendTo(upload_img_ui.find('.item-image-uploaded'));
                        remove_btn.removeClass('d-none');
                        photo_id.val(lodash.get(items, '[0].attributes.id', ''));
                    }
                })
            })
            remove_btn.click(function(event) {
                event.preventDefault();
                upload_img_ui.find('.item-image-uploaded').empty();
                remove_btn.addClass('d-none');
                photo_id.val('');
            });
        })
    }

    function handleItemVariations() {
        const variation_container = jQuery('.variation_container');
        const add_variation_btn = jQuery('.add_variation_btn');

        const buildVariationTemplate = (count) => {
            return `
            <div class="row mb-3 variation_item">
                <div class="col-md-2">
                    <div class="form-group variation_price_ui">
                        <label>${APPETIT_ITEM.locales.price}*</label>
                        <input type="number" step=".01" min="0" value="" required
                        class="form-control" name="${APPETIT_ITEM.post_meta_key}[product_variations][${count}][price]">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group variation_name_ui">
                        <label>${APPETIT_ITEM.locales.v_name}</label>
                        <input type="text" value=""
                        class="form-control" name="${APPETIT_ITEM.post_meta_key}[product_variations][${count}][variation_name_1]">
                        <small class="form-text text-muted">${APPETIT_ITEM.locales.variation_name_example}</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group variation_name_2_ui">
                        <label>${APPETIT_ITEM.locales.v_name_1}</label>
                        <input type="text" value=""
                        class="form-control" name="${APPETIT_ITEM.post_meta_key}[product_variations][${count}][variation_name_2]">
                        <small class="form-text text-muted">${APPETIT_ITEM.locales.variation_name_example}</small>
                        <input type="hidden" value="${uuidv4()}" name="${APPETIT_ITEM.post_meta_key}[product_variations][${count}][ID]">
                    </div>
                </div>
                <div class="col-md-2">
                    <a class="delete_variation_btn" href="#">${APPETIT_ITEM.locales.delete}</a>
                </div>
            </div>
            `;
        }

        add_variation_btn.click(function(event) {
            event.preventDefault();
            // console.log(jQuery('.variation_item').length);
            // return;
            const template = buildVariationTemplate(jQuery('.variation_item').length);
            const templateUI = jQuery(template);
            templateUI.appendTo(variation_container);
            handleVariationEvents(templateUI);
            handleGeneralVariations();
        });

        const handleVariationEvents = (variationUI) => {
            variationUI.find('.delete_variation_btn').click(function(event) {
                event.preventDefault();
                jQuery(this).parent().parent().remove();
                handleGeneralVariations();
            })
        };

        const handleGeneralVariations = () => {
            if (jQuery('.variation_item').length === 1) {
                jQuery('.variation_item').first().find('.variation_name_ui').addClass('d-none');
                jQuery('.variation_item').first().find('.variation_name_2_ui').addClass('d-none');
            } else {
                jQuery('.variation_item').first().find('.variation_name_ui').removeClass('d-none');
                jQuery('.variation_item').first().find('.variation_name_2_ui').removeClass('d-none');
            }
        }

        jQuery('.variation_item').each(function(index) {
            handleVariationEvents(jQuery(this));
        })
    }

    function handleGroups() {
        const add_group_btn = jQuery('.add_choice_group_btn');
        const select_choice_group = jQuery('.select_choice_group');
        const sortable_groups = jQuery("#sortable-groups");
        const menuItemMetaKey = sortable_groups.attr('data-metakey');

        select_choice_group.select2();

        add_group_btn.click(function(event) {
            event.preventDefault();

            const currentOption = select_choice_group.children('option:selected');
            if (currentOption.val() === '') {
                return;
            }

            const group_name = currentOption.attr('data-group-name');
            const group_id = currentOption.attr('data-group-id');
            const edit_link = currentOption.attr('data-edit-link');
            if (groupExists(group_id)) {
                alert(lodash.get(APPETIT_ITEM, 'locales.group_exists', ''));
                return;
            }

            const groupHTML = `
<li class="ui-state-default" data-id="${group_id}">
    <div class="choice-group-dragable">
        <span class="icon-drag_indicator"></span>
        <div class="group-title apt-display-flex apt-flex-center"><span class="mr-2 apt-display-block">${group_name}</span><a class="apt-no-decoration apt-display-block" href="${edit_link}" target="_blank"><span class="icon-external-link"></span></a>
            <input type="hidden" name="${menuItemMetaKey}[choice_groups][]" value="${group_id}" />
        </div>
        <div><a class="delete_group" href="#"><span class="icon-trash-2"></span></a></div>
    </div>
</li>
`;
            const groupEntryUI = jQuery(groupHTML);
            sortable_groups.append(groupEntryUI);
            sortable_groups.sortable('refresh');

            handleGroupDelete(groupEntryUI);

            toastr.success(lodash.get(APPETIT_ITEM, 'locales.group_successfully_added', ''), '', {
                iconClass: "appetit-toast-custom",
            });
        });

        select_choice_group.on('change', function(event) {
            add_group_btn.removeAttr('disabled');
            if (this.value === '') {
                add_group_btn.attr('disabled', true);
                return;
            }
        });

        function groupExists(groupId) {
            let exists = false;
            sortable_groups.find('li').each(function(index) {
                console.log(parseInt(jQuery(this).attr('data-id'), 10), parseInt(groupId, 10))
                if (parseInt(jQuery(this).attr('data-id'), 10) === parseInt(groupId, 10)) {
                    exists = true;
                }
            })
            return exists;
        }

        function handleGroupDelete(groupEntryUI) {
            groupEntryUI.find('.delete_group').click(function(event) {
                event.preventDefault();
                jQuery(this).parent().parent().parent().remove();
                sortable_groups.sortable('refresh');
            })
        }

        sortable_groups.sortable({
            change: function( event, ui ) {
                console.log(event, ui);
            }
        });
        sortable_groups.find('li').each(function() {
            handleGroupDelete(jQuery(this));
        })
    }

    jQuery(document).ready(function() {
        handleUpload();
        handleItemVariations();
        handleGroups();
    });
})()