<?php
/**
 *  Plugin Name:       Fake Notifications
 *  Plugin URI:        https://codecanyon.net/item/fake-notifications-for-wordpress-creating-effective-herd-effects/19992068
 *  Description:       Create and show fake notifications to motivate users to take action on your site
 *  Version:           5.0
 *  Author:            Wow-Company
 *  Author URI:        https://codecanyon.net/user/wow-company/
 *  License:           GPL-2.0+
 *  License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *  Text Domain:       wow-herd-effects-pro
 *  Domain Path:       /languages
 *  Item ID:           18
 *  Store URI:         https://wow-company.com/codecanyon-wow-company/
 *  Author Email:      hey@wow-company.com
 *  Plugin Menu:       Fake Notifications
 *  Rating URI:        https://codecanyon.net/item/fake-notifications-for-wordpress-creating-effective-herd-effects/reviews/19992068
 *  Support URI:       https://codecanyon.net/item/fake-notifications-for-wordpress-creating-effective-herd-effects/19992068/support
 *  Item URI:          https://codecanyon.net/item/fake-notifications-for-wordpress-creating-effective-herd-effects/19992068
 *  Documentation:     https://wow-estore.com/documentations/wow-herd-effects-pro-documentation/
 *  Envato Code:       https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-
 *
 *  PHP version        7.4
 *
 * @category    Wordpress_Plugin
 * @package     Wow_Plugin
 * @author      Dmytro Lobov <hey@wow-company.com>, Wow-Company
 * @copyright   2024 Dmytro Lobov
 * @license     GPL-2.0+
 */

namespace HerdEffectsPro;

use HerdEffectsPro\Admin\DBManager;
use HerdEffectsPro\Update\UpdateDB;

defined( 'ABSPATH' ) || exit;

update_option( 'wow_license_status_hep', "valid" );
update_option( 'wow_license_key_hep', "123456-123456-123456-123456" );

if ( ! class_exists( 'WOWP_Plugin' ) ) :

	final class WOWP_Plugin {

		// Plugin slug
		public const SLUG = 'wow-herd-effects-pro';

		// Plugin prefix
		public const PREFIX = 'wow_hep';

		// Plugin Shortcode
		public const SHORTCODE = 'Herd-Effects';

		private static $instance;

		private WOWP_Admin $admin;
		private Autoloader $autoloader;
		private WOWP_Public $public;
		private WOWP_Plugin_Checker $check;

		public static function instance(): WOWP_Plugin {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {
				self::$instance = new self;

				self::$instance->includes();

				self::$instance->autoloader = new Autoloader( 'HerdEffectsPro' );
				self::$instance->admin      = new WOWP_Admin();
				self::$instance->public     = new WOWP_Public();
				self::$instance->check      = new WOWP_Plugin_Checker();

				register_activation_hook( __FILE__, [ self::$instance, 'plugin_activate' ] );
				add_action( 'plugins_loaded', [ self::$instance, 'loaded' ] );
			}


			return self::$instance;
		}

		// Plugin Root File.
		public static function file(): string {
			return __FILE__;
		}

		// Plugin Base Name.
		public static function basename(): string {
			return plugin_basename( __FILE__ );
		}

		// Plugin Folder Path.
		public static function dir(): string {
			return plugin_dir_path( __FILE__ );
		}

		// Plugin Folder URL.
		public static function url(): string {
			return plugin_dir_url( __FILE__ );
		}

		// Get Plugin Info
		public static function info( $show = '' ): string {
			$data        = [
				'name'       => 'Plugin Name',
				'version'    => 'Version',
				'url'        => 'Plugin URI',
				'author'     => 'Author',
				'email'      => 'Author Email',
				'store'      => 'Store URI',
				'item_id'    => 'Item ID',
				'menu_title' => 'Plugin Menu',
				'rating'     => 'Rating URI',
				'support'    => 'Support URI',
				'pro'        => 'Item URI',
				'docs'       => 'Documentation',
				'code'       => 'Envato Code',
			];
			$plugin_data = get_file_data( __FILE__, $data, false );

			return $plugin_data[ $show ] ?? '';
		}

		/**
		 * Include required files.
		 *
		 * @access private
		 * @since  1.0
		 */
		private function includes(): void {
			if ( ! class_exists( 'Wow_Company' ) ) {
				require_once self::dir() . 'includes/class-wow-company.php';
			}

			require_once self::dir() . 'classes/Autoloader.php';
			require_once self::dir() . 'admin/class-wowp-admin.php';
			require_once self::dir() . 'public/class-wowp-public.php';
			require_once self::dir() . 'includes/class-wowp-plugin-checker.php';
		}

		/**
		 * Throw error on object clone.
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @return void
		 * @access protected
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_attr__( 'Cheatin&#8217; huh?', 'wow-herd-effects-pro' ), '1.0' );
		}

		/**
		 * Disable unserializing of the class.
		 *
		 * @return void
		 * @access protected
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_attr__( 'Cheatin&#8217; huh?', 'wow-herd-effects-pro' ), '1.0' );
		}

		public function plugin_activate(): void {

			if ( is_plugin_active( 'mwp-herd-effect/mwp-herd-effect.php' ) ) {
				deactivate_plugins( 'mwp-herd-effect/mwp-herd-effect.php' );
			}

			$columns = "
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			title VARCHAR(200) DEFAULT '' NOT NULL,
			param longtext DEFAULT '' NOT NULL,
			status boolean DEFAULT 0 NOT NULL,
			mode boolean DEFAULT 0 NOT NULL,
			tag text DEFAULT '' NOT NULL,
			PRIMARY KEY  (id)
			";
			DBManager::create( $columns );
		}

		/**
		 * Download the folder with languages.
		 *
		 * @access Publisher
		 * @return void
		 */
		public function loaded(): void {
			UpdateDB::init();
			$languages_folder = dirname( plugin_basename( __FILE__ ) ) . '/languages/';
			load_plugin_textdomain( 'wow-herd-effects-pro', false, $languages_folder );
		}
	}

endif;

function wp_plugin_run(): WOWP_Plugin {
	return WOWP_Plugin::instance();
}

wp_plugin_run();


