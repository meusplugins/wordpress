<?php return array('dependencies' => array(), 'version' => 'c08f55c89a83668db149');
