<?php
/**
 * Remote-only snippet management mode.
 *
 * When the WPCODE_REMOTE_ONLY constant is true, snippets on this site can only
 * change through verified WPCode Library deploys. Both capabilities stay
 * granted so the admin pages render exactly as they do today and every
 * configuration remains visible, but every local write is refused: content,
 * lifecycle, and status writes all stop at the gates below (the quick toggle
 * routes through save(), Execute Now sits behind the editor's read-only early
 * return, and raw status writes hit the insert gate), and the editor renders
 * read-only. Library deploys run without a
 * logged-in user (the push endpoint authenticates with a passkey assertion
 * before writing), so "no logged-in user" is the trust boundary all gates
 * share. force_deactivate() writes directly through $wpdb and stays available
 * as the fatal-error safety valve. With WPCODE_SNIPPETS_FROM_FILES also set,
 * the files mode wins and none of this applies (see WPCode_Access::remote_only()).
 *
 * @package WPCode
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_Remote_Only.
 */
class WPCode_Remote_Only {

	/**
	 * Constructor, hooks the gates only when the mode is enabled, and the notice when the files mode overrides it.
	 */
	public function __construct() {
		if ( WPCode_Access::remote_only() ) {
			$this->hooks();
		} elseif ( defined( 'WPCODE_REMOTE_ONLY' ) && WPCODE_REMOTE_ONLY ) {
			// The constant is set but the files mode won: say which mode is active.
			add_action( 'wpcode_admin_notices', array( $this, 'render_files_mode_notice' ) );
		}
	}

	/**
	 * Register the write gates and notices.
	 *
	 * @return void
	 */
	private function hooks() {
		// Everything routed through WPCode_Snippet::save() (editor, quick toggle, packs, importers, generator, sync, preview CSS).
		add_filter( 'wpcode_pre_save_snippet', array( $this, 'block_local_save' ), 5, 2 );
		// Raw wp_insert_post/wp_update_post writes (bulk actions, block editor, testing mode, REST).
		add_filter( 'wp_insert_post_empty_content', array( $this, 'block_local_post_writes' ), 5, 2 );
		// Deletes and trashing never pass through wp_insert_post.
		add_filter( 'pre_trash_post', array( $this, 'block_local_delete' ), 5, 2 );
		add_filter( 'pre_untrash_post', array( $this, 'block_local_delete' ), 5, 2 );
		add_filter( 'pre_delete_post', array( $this, 'block_local_delete' ), 5, 2 );
		// Explain the mode on the snippet list and the snippet editor.
		add_action( 'wpcode_admin_notices', array( $this, 'render_mode_notice' ) );
		// Admin UI: refuse bulk actions up front, render the editor read-only, hide Testing Mode.
		add_filter( 'wpcode_snippets_bulk_action_refusal', array( $this, 'bulk_refusal' ) );
		add_filter( 'wpcode_snippet_manager_is_read_only', '__return_true' );
		add_filter( 'wpcode_snippet_manager_read_only_message', '__return_empty_string' );
		add_filter( 'wpcode_show_testing_mode_toggle', '__return_false' );
		// The library connection is the deploy trust anchor, so a local admin can't swap or drop it.
		add_action( 'wp_ajax_wpcode_library_store_auth', array( $this, 'block_library_connection_change' ), 1 );
		add_action( 'wp_ajax_wpcode_library_delete_auth', array( $this, 'block_library_connection_change' ), 1 );
	}

	/**
	 * The message shown when a local write is refused.
	 *
	 * @return string
	 */
	private function refusal_message() {
		return __( 'Snippets on this site are managed from the WPCode Library. Make your changes there and deploy them to this site.', 'wpcode-premium' );
	}

	/**
	 * Refuse reconnecting or disconnecting the WPCode Library once the site is connected.
	 *
	 * A reconnect could point deploys at another library account and its passkeys, so changing the
	 * connection requires removing WPCODE_REMOTE_ONLY first. The first connection is still allowed.
	 *
	 * @return void
	 */
	public function block_library_connection_change() {
		check_ajax_referer( 'wpcode_admin' );

		// Users who can't connect get core's own permissions error, so the mode stays undisclosed to them.
		if ( ! current_user_can( 'wpcode_activate_snippets' ) || ! wpcode()->library_auth->has_auth() ) {
			return;
		}

		wp_send_json_error( esc_html__( 'This site is in remote-only mode, so its WPCode Library connection cannot be changed here. Remove WPCODE_REMOTE_ONLY from wp-config.php to change it.', 'wpcode-premium' ) );
	}

	/**
	 * Refuse the whole bulk action batch up front: the per-item writes would fail at the gates while the
	 * summary still reported success counts.
	 *
	 * @param string $refusal The refusal message, empty to allow.
	 *
	 * @return string
	 */
	public function bulk_refusal( $refusal ) {
		return '' !== $refusal ? $refusal : $this->refusal_message();
	}

	/**
	 * Whether the current context is local management rather than a library deploy.
	 *
	 * @return bool
	 */
	private function is_local_context() {
		// Library deploys run nopriv; cron and WP-CLI are trusted no-user contexts.
		return is_user_logged_in();
	}

	/**
	 * Refuse WPCode_Snippet::save() for any logged-in user.
	 *
	 * @param int|false      $pre_save Whether to short-circuit the save.
	 * @param WPCode_Snippet $snippet  The snippet being saved.
	 *
	 * @return int|false
	 */
	public function block_local_save( $pre_save, $snippet ) {
		if ( ! $this->is_local_context() ) {
			return $pre_save;
		}

		wpcode()->error->add_error(
			array(
				'message' => $this->refusal_message(),
				'type'    => 'permissions',
			)
		);

		// The quick toggle sets $active before saving and reports success off it.
		if ( isset( $snippet->active ) ) {
			unset( $snippet->active );
		}

		return 0;
	}

	/**
	 * Abort raw post writes for snippet post types from any logged-in user.
	 *
	 * @param bool  $maybe_empty Whether to treat the post as empty (abort save).
	 * @param array $postarr     The post data being inserted.
	 *
	 * @return bool
	 */
	public function block_local_post_writes( $maybe_empty, $postarr ) {
		if ( empty( $postarr['post_type'] ) || ! in_array( $postarr['post_type'], $this->post_types(), true ) ) {
			return $maybe_empty;
		}

		if ( $this->is_local_context() ) {
			return true;
		}

		return $maybe_empty;
	}

	/**
	 * Abort trash/untrash/delete for snippet post types from any logged-in user.
	 *
	 * @param null|mixed $delete Whether to short-circuit the operation.
	 * @param WP_Post    $post   The post being deleted or trashed.
	 *
	 * @return null|false
	 */
	public function block_local_delete( $delete, $post ) {
		if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, $this->post_types(), true ) ) {
			return $delete;
		}

		if ( $this->is_local_context() ) {
			return false;
		}

		return $delete;
	}

	/**
	 * Explain the mode on the snippet list and the snippet add/edit screens.
	 *
	 * The message adapts to the connection state: not connected asks to
	 * connect, a legacy connection asks for a passkey reconnect (the mode
	 * refuses HMAC pushes), and a passkey connection gets the standard copy.
	 *
	 * @return void
	 */
	public function render_mode_notice() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display check.
		if ( ! in_array( $page, array( 'wpcode', 'wpcode-snippet-manager' ), true ) ) {
			return;
		}
		$auth = isset( wpcode()->library_auth ) ? wpcode()->library_auth : null;
		?>
		<div class="notice notice-info">
			<p>
				<?php
				if ( $auth && ! $auth->has_auth() ) {
					esc_html_e( 'Snippets on this site are managed remotely from the WPCode Library and are read-only here. Connect this site to your WPCode Library account to manage its snippets.', 'wpcode-premium' );
				} elseif ( $auth && ! $auth->requires_passkey() ) {
					esc_html_e( 'Snippets on this site are managed remotely from the WPCode Library and are read-only here, but the current library connection does not support passkey-approved deploys. Remove WPCODE_REMOTE_ONLY from wp-config.php, reconnect this site to the WPCode Library, then add it back.', 'wpcode-premium' );
				} else {
					esc_html_e( 'Snippets on this site are managed remotely from the WPCode Library and are read-only here. Make changes from your library account and deploy them to this site.', 'wpcode-premium' );
				}
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * On the snippet list, explain that remote-only mode is off because snippets are managed from files.
	 *
	 * @return void
	 */
	public function render_files_mode_notice() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display check.
		if ( 'wpcode' !== $page ) {
			return;
		}
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				echo wp_kses(
					sprintf(
						/* translators: 1: the remote-only constant name, 2: the files mode constant name. */
						__( 'Remote-only mode is off: %1$s is ignored because snippets on this site are managed from files (%2$s). Remove %1$s from wp-config.php to hide this notice.', 'wpcode-premium' ),
						'<code>WPCODE_REMOTE_ONLY</code>',
						'<code>WPCODE_SNIPPETS_FROM_FILES</code>'
					),
					array( 'code' => array() )
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * The post types covered by remote-only management.
	 *
	 * @return string[]
	 */
	private function post_types() {
		// The registered keys, not literals: 'wpcodeblock' is the block post
		// type's capability_type, while the post type itself is 'wpcode-blocks'.
		return array( wpcode_get_post_type(), WPCode_Snippet_Block_Editor::$post_type_key );
	}
}

new WPCode_Remote_Only();
