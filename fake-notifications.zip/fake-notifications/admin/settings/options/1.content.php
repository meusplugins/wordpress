<?php

use HerdEffectsPro\Settings_Helper;

defined( 'ABSPATH' ) || exit;

return [
	'herd_title' => [
		'title' => __( 'Notification title', 'wow-herd-effects-pro' ),
		'type'  => 'text',
		'atts'  => [
			'placeholder' => __( 'Enter notification title', 'wow-herd-effects-pro' ),
		],
	],

	'image_type' => [
		'type'  => 'select',
		'title' => __( 'Icon type', 'wow-herd-effects-pro' ),
		'val'   => 'icon',
		'atts'  => [
			'icon'   => __( 'Icons', 'wow-herd-effects-pro' ),
			'custom' => __( 'Image', 'wow-herd-effects-pro' ),
			'emoji'  => __( 'Emoji', 'wow-herd-effects-pro' ),
			'class'  => __( 'Icon Class', 'wow-herd-effects-pro' ),
			'none'   => __( 'None', 'wow-herd-effects-pro' ),
		],
	],

	'menu_icon' => [
		'type'  => 'select',
		'title' => __( 'Icon', 'wow-herd-effects-pro' ),
		'val'   => '',
		'class' => 'wpie-icon-box',
		'atts'  => Settings_Helper::icons(),
	],

	'herd_custom_link' => [
		'title' => __( 'Image URL', 'wow-herd-effects-pro' ),
		'type'  => 'text',
		'atts'  => [
			'placeholder' => __( 'Enter Image URL', 'wow-herd-effects-pro' ),
		],
		'class' => 'wpie-image-download',
		'addon' => ' ',
	],

	'image_emoji' => [
		'title' => __( 'Set Emoji', 'wow-herd-effects-pro' ),
		'type'  => 'text',
	],

	'herd_text' => [
		'type'  => 'editor',
		'class' => 'is-full',
		'val'   => __( '[variable_1] from [variable_2] has just bought <strong>Wow Herd Effects Pro</strong> [amount] minutes ago.','wow-herd-effects-pro' ),
		'atts'  => [
			'class' => 'wpie-fulleditor',
		],

	],

];