<?php

/**
 * Happy Image Trails Extension
 *
 * Adds interactive image trail animation following the mouse cursor.
 *
 * @package Happy_Addons_Pro
 */

namespace Happy_Addons_Pro\Extensions;

use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Repeater;

defined('ABSPATH') || die();

class Happy_Image_Trails {

	private static $instance = null;

	public static function instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {
		add_action('wp_enqueue_scripts', [$this, 'register_scripts']);
		add_action('wp_enqueue_scripts', [$this, 'register_styles']);
		add_action('elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts']);

		add_action('elementor/element/section/section_layout/after_section_end', [$this, 'register_controls'], 10);
		add_action('elementor/element/column/section_layout/after_section_end', [$this, 'register_controls'], 10);
		add_action('elementor/element/common/_section_style/after_section_end', [$this, 'register_controls'], 10);

		add_action('elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 10);

		add_action('elementor/frontend/section/before_render', [$this, 'before_render'], 10, 1);
		add_action('elementor/frontend/column/before_render', [$this, 'before_render'], 10, 1);
		add_action('elementor/frontend/container/before_render', [$this, 'before_render'], 10, 1);

		add_action('elementor/section/print_template', [$this, 'print_template'], 10, 2);
		add_action('elementor/column/print_template', [$this, 'print_template'], 10, 2);
		add_action('elementor/container/print_template', [$this, 'print_template'], 10, 2);
	}

	public function register_scripts() {
		$suffix = ha_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'happy-image-trails',
			HAPPY_ADDONS_PRO_ASSETS . 'js/happy-image-trails' . $suffix . 'js',
			['jquery', 'gsap', 'imagesloaded'],
			HAPPY_ADDONS_PRO_VERSION,
			true
		);
	}

	public function register_styles() {
		wp_register_style(
			'happy-image-trails',
			HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/happy-image-trails.min.css',
			[],
			HAPPY_ADDONS_PRO_VERSION
		);
	}

	public function enqueue_preview_scripts() {
		wp_enqueue_script('gsap');
		wp_enqueue_script('imagesloaded');
		wp_enqueue_script('happy-image-trails');

		wp_enqueue_style('happy-image-trails');
	}

	public function register_controls($element) {

		$tab = Controls_Manager::TAB_ADVANCED;
		if ('common' === $element->get_name()) {
			$tab = Controls_Manager::TAB_ADVANCED;
		}

		$element->start_controls_section(
			'_ha_image_trails_section',
			[
				'label' => __('Image Trails', 'happy-addons-pro') . ha_get_section_icon(),
				'tab'   => $tab,
			]
		);

		$element->add_control(
			'ha_image_trails_help_url_notice_box',
			[
				'type'        => Controls_Manager::NOTICE,
				'notice_type' => 'info',
				'content'     => sprintf(
					esc_html__( 'Need help? %s', 'happy-addons-pro' ),
					'<a href="https://happyaddons.com/docs/happy-addons-for-elementor-pro/features/image-trail/" target="_blank" rel="noopener noreferrer">'
					. esc_html__( 'Read Documentation', 'happy-addons-pro' )
					. '</a>'
				),
			]
		);

		$this->add_content_controls($element);
		$this->add_image_controls($element);
		$this->add_image_style_controls($element);
		$this->add_magic_cursor_controls($element);

		$element->end_controls_section();
	}

	public function add_content_controls($element) {

		$element->add_control(
			'ha_it_enable',
			[
				'label'        => __('Enable Image Trails', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'ha-it-',
				'render_type'  => 'template',
				'return_value' => 'yes',
				'style_transfer' => false,
				'frontend_available' => true,
				'assets' => [
					'scripts' => [
						[
							'name' => 'gsap',
							'conditions' => [
								'terms' => [
									[
										'name' => 'ha_it_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
						[
							'name' => 'imagesloaded',
							'conditions' => [
								'terms' => [
									[
										'name' => 'ha_it_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
						[
							'name' => 'happy-image-trails',
							'conditions' => [
								'terms' => [
									[
										'name' => 'ha_it_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
					],
					'styles' => [
						[
							'name' => 'happy-image-trails',
							'conditions' => [
								'terms' => [
									[
										'name' => 'ha_it_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
					],
				],
			]
		);
	}

	public function add_image_controls($element) {

		$element->add_control(
			'ha_it_gallery_label',
			[
				'label' => __('Trail Images', 'happy-addons-pro'),
				'type'  => Controls_Manager::HEADING,
				'condition' => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_gallery',
			[
				'label'       => __('Choose Images', 'happy-addons-pro'),
				'type'        => Controls_Manager::GALLERY,
				'default'     => [],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
				'render_type' => 'template',
			]
		);
	}

	public function add_image_style_controls($element) {

		$element->add_control(
			'ha_it_image_style_label',
			[
				'label'     => __('Image Style', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_trail_style',
			[
				'label'        => __('Trail Style', 'happy-addons-pro'),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'normal',
				'prefix_class' => 'ha-it-style-',
				'render_type'  => 'template',
				'options'      => [
					'normal'  => __('Normal', 'happy-addons-pro'),
					'falling' => __('Falling', 'happy-addons-pro'),
				],
				'condition'    => [
					'ha_it_enable' => 'yes',
				],
			]
		);


		$element->add_responsive_control(
			'ha_it_image_width',
			[
				'label'       => __('Image Width', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 250,
					'unit' => 'px',
				],
				'range'       => [
					'px' => [
						'min'  => 50,
						'max'  => 800,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .ha-it-content .ha-it-content__img' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_it_image_height',
			[
				'label'       => __('Image Height', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => '',
					'unit' => 'px',
				],
				'range'       => [
					'px' => [
						'min'  => 50,
						'max'  => 800,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .ha-it-content .ha-it-content__img' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);


		$element->add_responsive_control(
			'ha_it_image_border_radius',
			[
				'label'      => __('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default'    => [
					'top'    => '10',
					'right'  => '10',
					'bottom' => '10',
					'left'   => '10',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .ha-it-content .ha-it-content__img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_image_opacity',
			[
				'label'       => __('Opacity', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 1,
				],
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.05,
					],
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_image_z_index',
			[
				'label'       => __('Z-index', 'happy-addons-pro'),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 1,
				'min'         => 1,
				'max'         => 9999,
				'selectors'   => [
					'{{WRAPPER}} .ha-it-content .ha-it-content__img' => 'z-index: {{SIZE}};',
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_threshold',
			[
				'label'       => __('Trail Distance', 'happy-addons-pro'),
				'description' => __('Minimum mouse distance before showing next image.', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 80,
				],
				'range'       => [
					'px' => [
						'min'  => 20,
						'max'  => 300,
						'step' => 1,
					],
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_animation_duration',
			[
				'label'       => __('Animation Duration (s)', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 0.4,
				],
				'range'       => [
					'px' => [
						'min'  => 0.1,
						'max'  => 2,
						'step' => 0.05,
					],
				],
				'condition'   => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_rotation_duration',
			[
				'label'       => __('Rotation Duration (s)', 'happy-addons-pro'),
				'description' => __('Controls how fast images rotate in Falling style.', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 0.5,
				],
				'range'       => [
					'px' => [
						'min'  => 0.1,
						'max'  => 3,
						'step' => 0.05,
					],
				],
				'condition'   => [
					'ha_it_enable'    => 'yes',
					'ha_it_trail_style' => 'falling',
				],
			]
		);


		$element->add_control(
			'ha_it_show_in_editor',
			[
				'label'        => __('Show in Editor', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'render_type'  => 'template',
				'condition'    => [
					'ha_it_enable' => 'yes',
				],
			]
		);
	}

	public function add_magic_cursor_controls($element) {

		$element->add_control(
			'ha_it_cursor_heading',
			[
				'label'     => __('Magic Cursor', 'happy-addons-pro'),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_cursor_enable',
			[
				'label'        => __('Enable Magic Cursor', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'ha-it-cursor-',
				'render_type'  => 'template',
				'condition'    => [
					'ha_it_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_cursor_width',
			[
				'label'       => __('Cursor Width', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 14,
					'unit' => 'px',
				],
				'range'       => [
					'px' => [
						'min'  => 4,
						'max'  => 80,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .ha-it-cursor .ha-it-cursor__ball' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'ha_it_enable'         => 'yes',
					'ha_it_cursor_enable'  => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_cursor_height',
			[
				'label'       => __('Cursor Height', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 14,
					'unit' => 'px',
				],
				'range'       => [
					'px' => [
						'min'  => 4,
						'max'  => 80,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .ha-it-cursor .ha-it-cursor__ball' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'ha_it_enable'         => 'yes',
					'ha_it_cursor_enable'  => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_cursor_bg_color',
			[
				'label'       => __('Background Color', 'happy-addons-pro'),
				'type'        => Controls_Manager::COLOR,
				'default'     => '#FF535B',
				'selectors'   => [
					'{{WRAPPER}} .ha-it-cursor .ha-it-cursor__ball' => 'background-color: {{VALUE}};',
				],
				'condition'   => [
					'ha_it_enable'         => 'yes',
					'ha_it_cursor_enable'  => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'ha_it_cursor_border_radius',
			[
				'label'      => __('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
				],
				'selectors'  => [
					'{{WRAPPER}} .ha-it-cursor .ha-it-cursor__ball' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'ha_it_enable'         => 'yes',
					'ha_it_cursor_enable'  => 'yes',
				],
			]
		);

		$element->add_control(
			'ha_it_cursor_transition',
			[
				'label'       => __('Transition Speed', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [
					'size' => 0.3,
					'unit' => 's',
				],
				'range'       => [
					's' => [
						'min'  => 0,
						'max'  => 2,
						'step' => 0.05,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .ha-it-cursor .ha-it-cursor__ball' => 'transition: width {{SIZE}}{{UNIT}} ease, height {{SIZE}}{{UNIT}} ease, background-color {{SIZE}}{{UNIT}} ease;',
				],
				'condition'   => [
					'ha_it_enable'         => 'yes',
					'ha_it_cursor_enable'  => 'yes',
				],
			]
		);
	}

	public function before_render($element) {
		$settings = $element->get_settings();

		if ('yes' !== ($settings['ha_it_enable'] ?? null)) {
			return;
		}

		$gallery = ! empty($settings['ha_it_gallery']) ? $settings['ha_it_gallery'] : [];

		$trail_data = [
			'images'           => [],
			'imageOpacity'     => isset($settings['ha_it_image_opacity']['size']) ? (float) $settings['ha_it_image_opacity']['size'] : 1,
			'threshold'        => ! empty($settings['ha_it_threshold']['size']) ? (int) $settings['ha_it_threshold']['size'] : 80,
			'duration'         => ! empty($settings['ha_it_animation_duration']['size']) ? (float) $settings['ha_it_animation_duration']['size'] : 0.4,
			'rotationDuration' => ! empty($settings['ha_it_rotation_duration']['size']) ? (float) $settings['ha_it_rotation_duration']['size'] : 0.5,
			'trailStyle'       => ! empty($settings['ha_it_trail_style']) ? $settings['ha_it_trail_style'] : 'normal',
			'cursor'           => 'yes' === ($settings['ha_it_cursor_enable'] ?? null),
			'disableMobile'    => true,
			'showInEditor'     => 'yes' === ($settings['ha_it_show_in_editor'] ?? null),
		];

		if (! empty($gallery) && is_array($gallery)) {
			foreach ($gallery as $image) {
				if (! empty($image['id'])) {
					$img_url = wp_get_attachment_image_url($image['id'], 'full');
					if ($img_url) {
						$trail_data['images'][] = $img_url;
					}
				} elseif (! empty($image['url'])) {
					$trail_data['images'][] = $image['url'];
				}
			}
		}

		$element->add_render_attribute('_wrapper', 'data-ha-image-trails', wp_json_encode($trail_data));
	}

	public function print_template($template, $widget) {

		$old_template = $template;
		ob_start();
?>
		<# if ( 'yes'===settings.ha_it_enable ) { #>

			<#
				var trailData={
				images: [],
				imageOpacity: settings.ha_it_image_opacity ? settings.ha_it_image_opacity.size : 1,
				threshold: settings.ha_it_threshold ? settings.ha_it_threshold.size : 80,
				duration: settings.ha_it_animation_duration ? settings.ha_it_animation_duration.size : 0.4,
				rotationDuration: settings.ha_it_rotation_duration ? settings.ha_it_rotation_duration.size : 0.5,
				cursor: settings.ha_it_cursor_enable==='yes' ,
				disableMobile: true,
				showInEditor: settings.ha_it_show_in_editor==='yes' ,
				trailStyle: settings.ha_it_trail_style || 'normal'
				};

				if ( settings.ha_it_gallery && settings.ha_it_gallery.length ) {
				_.each( settings.ha_it_gallery, function( image ) {
				if ( image.url ) {
				trailData.images.push( image.url );
				}
				});
				}
				#>

				<div class="ha-it-content" data-ha-image-trails="{{ JSON.stringify( trailData ) }}"></div>

				<# } #>
			<?php
			$trail_content = ob_get_contents();
			ob_end_clean();
			$template = $trail_content . $old_template;

			return $template;
		}
	}
