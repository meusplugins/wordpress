<?php

use HerdEffectsPro\Settings_Helper;

defined( 'ABSPATH' ) || exit;

return [
	//region Link
	'herd_link' => [
		'type'  => 'text',
		'title' => __( 'Link', 'wow-herd-effects-pro' ),
		'atts'  => [
			'placeholder' => __( 'Enter URL', 'wow-herd-effects-pro' ),
		],
	],

	'click_link' => [
		'type'  => 'checkbox',
		'title' => __( "Don't show after click", 'wow-herd-effects-pro' ),
		'label' => __( 'Enable', 'wow-herd-effects-pro' ),
	],

	'link_target' => [
		'type' => 'select',
		'title' => __('Link target', 'wow-herd-effects-pro'),
		'val' => '_self',
		'atts' => [
			'_self'  => __( 'In the same frame', 'wow-herd-effects-pro' ),
			'_blank' => __( 'In a new window', 'wow-herd-effects-pro' ),
		],
	],

	//endregion

	//region Show
	'sec_step' => [
		'type' => 'select',
		'title' => __('Appearance mode', 'wow-herd-effects-pro'),
		'val' => 'stable',
		'atts' => [
			'stable' => __( 'Stable', 'herd-effects' ),
			'random' => __( 'Random', 'herd-effects' ),
		],
	],

	'speed' => [
		'type'  => 'number',
		'title' => __( 'Show every', 'wow-herd-effects-pro' ),
		'val'   => '5',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'sec',
	],

	'speed_min' => [
		'type'  => 'number',
		'title' => __( 'Min', 'wow-herd-effects-pro' ),
		'val'   => '5',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'sec',
	],

	'speed_max' => [
		'type'  => 'number',
		'title' => __( 'Max', 'wow-herd-effects-pro' ),
		'val'   => '10',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'sec',
	],

	'auto_close' => [
		'type'  => 'number',
		'title' => __( 'Auto-close', 'wow-herd-effects-pro' ),
		'val'   => '5',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
		'addon' => 'sec',
	],

	'number' => [
		'type'  => 'number',
		'title' => __( 'Number of notifications', 'wow-herd-effects-pro' ),
		'val'   => '3',
		'atts' => [
			'min'  => 0,
			'step' => 1,
		],
	],
	//endregion

	//region Animation

	'window_animate' => [
		'type' => 'select',
		'title' => __('Animation In', 'wow-herd-effects-pro'),
		'val' => '1',
		'atts' => Settings_Helper::animationIn(),
	],

	'window_animate_out' => [
		'type' => 'select',
		'title' => __('Animation Out', 'wow-herd-effects-pro'),
		'val' => '1',
		'atts' => Settings_Helper::animationOut(),
	],

	//endregion

];