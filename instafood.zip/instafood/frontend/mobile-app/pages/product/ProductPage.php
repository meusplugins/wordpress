<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../IAppetitPage.php');

class ProductPage implements IAppetitPage {

    public function render(): void {
        ?>
        <section id="apt_product_screen" class="apt-page apt-page-full aptdisplay_none">
            <?php $this->renderHeader() ?>
            <?php $this->renderProductContent() ?>
        </section>
        <?php
    }

    private function renderHeader(): void {
        ?>
        <div class="apt-cover-header" style="background-size: cover; background-position: center;">
            <div class="apt-product-header-overlay">
                <div class="header_close_screen_ui"><a class="round_nav header_close_btn" href="#"><span class="icon-clear"></span></a></div>
            </div>
        </div>
        <?php
    }

    private function renderProductContent(): void {
        ?>
        <div class="apt_screen_content_ui">
            <div class="apt-product-nav"></div>
            <div class="apt-productnav_main apt-product-nav-sticky">
                <div class="sticky-content">
                    <a class="round_nav_fill header_float_close_btn" href="#"><span class="icon-clear"></span></a>
                    <span class="sticky-product-name"></span>
                </div>
            </div>
            <div class="product_content_ui"></div>
        </div>
        <?php
    }
}
?>