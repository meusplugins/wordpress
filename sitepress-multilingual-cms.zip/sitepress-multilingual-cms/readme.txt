=== SitePress Multilingual CMS ===
Stable tag: 4.7.6