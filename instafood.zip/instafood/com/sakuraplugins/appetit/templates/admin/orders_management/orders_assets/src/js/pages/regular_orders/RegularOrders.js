import RestManager from '../../services/RestManager';
import DataUtils from '../../utils/DataUtils';
import OrderItem, { OrderMode } from '../../components/OrderItem';
import EventBus, { Events, Event } from '../../events/EventBus';

let instance;
const instanceKey = '23__ad84ad7238_KSJK';

class RegularOrders {

    _ui;
    _order_pagination;

    _ordersInstances = [];
    _orders = [];
    _onOrdersStatusChange;
    _onOrdersReloadRequest;

    result_per_page = 20;
    paged = 1;
    max_num_pages = 1;
    filter_order_status = false;
    filter_order_type = false;
    filter_order_id = false;
    filter_order_safe_match = false;

    filter_by_status;
    filter_by_order_type;
    search_id_ui;
    search_safe_match_ui;
    apt_filters_dynamic;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._ui = jQuery('#orders');
        this._order_pagination = this._ui.find('.order_pagination');
        this.filter_by_status = this._ui.find('.filter_by_status');
        this.filter_by_order_type = this._ui.find('.filter_by_order_type');
        this.search_id_ui = this._ui.find('.search_id_ui');
        this.search_safe_match_ui = this._ui.find('.search_safe_match_ui');
        this.apt_filters_dynamic = this._ui.find('.apt_filters_dynamic');
        this._handleFilters();

        this._onOrdersStatusChange = new Event(Events.ORDER_CHANGED_STATUS, (data) => {
            this._handleOrderStatusChange(data);
        });
        EventBus.getInstance().registerEvent(this._onOrdersStatusChange);

        this._onOrdersReloadRequest = new Event(Events.RELOAD_REGULAR_ORDERS, (data) => {
            this.resetAll();
            this.fetchOrders();
        });
        EventBus.getInstance().registerEvent(this._onOrdersReloadRequest);
    }

    init() {
        this.fetchOrders();
    }

    fetchOrders() {
        this._order_pagination.empty();
        this._retrieveOrders()
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            
            const { currentPage, max_num_pages, orders, total_posts } = result?.data?.data;

            this._paged = parseInt(currentPage, 10);
            this._max_num_pages = parseInt(max_num_pages, 10);

            this._orders = [...orders].reverse();
            this._ordersInstances = [];
            this._ui.find('.appetit_table_body').empty();

            let c = 0;
            this._orders.forEach(order => {
                const showBackground = c % 2 === 1;
                const orderItem = new OrderItem(order, OrderMode.REGULAR_ORDER);
                this._ordersInstances.push(orderItem);
                const orderTemplateUI = orderItem.getTemplate(showBackground)
                orderTemplateUI.prependTo(this._ui.find('.appetit_table_body'));
                c++;
            });

            this._custom_pagination();
            this._handleNotfound();
        })
    }

    _retrieveOrders() {
        this._ui.find('.orders_loading').css('opacity', 1);
        return new Promise((resolve, reject) => {
            const query = {
                orderby: 'date_desc',
                result_per_page: this.result_per_page,
                paged: this.paged
            }

            if (this.filter_order_status !== false) {
                query.filter_order_status = this.filter_order_status
            }

            if (this.filter_order_type !== false) {
                query.filter_order_type = this.filter_order_type
            }

            if (this.filter_order_id !== false) {
                query.filter_order_id = this.filter_order_id
            }

            if (this.filter_order_safe_match !== false) {
                query.filter_order_safe_match = this.filter_order_safe_match
            }

            RestManager.getInstance()
            .postAjax('fetch_orders', {
                query
            })
            .then(result => {
                this._ui.find('.orders_loading').css('opacity', 0);
                resolve(result);
            });
        })
    }

    _custom_pagination($range = 2, $current_url = '') {
        this._order_pagination.empty();
        let $pages = this._max_num_pages;

        let $showitems = ($range * 2) + 1;  
    
        let $paged = this._paged;

        if (!$paged) $paged = 1;
        
    
        if (!$pages) {
            $pages = 1;
        }

        let template = ``;

        if (1 != $pages) {
            
            template += "<div class='if-pagination'>";

            if ($paged > 2 && $paged > $range+1 && $showitems < $pages) {
                const $firstPage = `#${1}`;
                template += "<a class='if-paginate-link' data-page="+ 1 +" href='"+ $firstPage +"'>&laquo;</a>";
            }
            if ($paged > 1 && $showitems < $pages) {
                const $previousPage = `#${$paged - 1}`;
                template += "<a class='if-paginate-link' data-page="+ parseInt($paged - 1) +" href='"+ $previousPage +"'>&lsaquo;</a>";
            }
    
            for (let $i = 1; $i <= $pages; $i++)
            {
                if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
                    const $pageUrl = `#${$i}`;
                    template += ($paged == $i) ? "<a class='if-paginate-link if-paginate-link-active' data-page='false' href='#' class='inactive' >"+$i+"</a>" : "<a class='if-paginate-link' data-page="+ $i +" href='"+ $pageUrl +"' class='inactive' >"+$i+"</a>";
                }
            }
            if ($paged < $pages && $showitems < $pages) {
                const $nextPage = `#${$paged + 1}`;
                template += "<a class='if-paginate-link' data-page="+ parseInt($paged + 1) +" href='"+ $nextPage +"'>&rsaquo;</a>";  
            }
            if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) {
                const $lastPage = `#${$pages}`;
                template += "<a class='if-paginate-link' data-page="+ $pages +" href='"+ $lastPage +"'>&raquo;</a>";
            }
            template += "</div>";
        }
        jQuery(template).appendTo(this._order_pagination);
        const _this = this;

        this._order_pagination.find('.if-paginate-link').each(function(index) {

            jQuery(this).click(function() {
                event.preventDefault();
                const toPage = jQuery(this).attr('data-page');
                if (toPage !== 'false') {
                    _this.paged = toPage;
                    _this.fetchOrders();
                }
            })
        })
    }

    _handleFilters() {
        const _this = this;
        this.filter_by_status.on('change', function() {
            if (this.value === 'false') {
                _this._removeFilter('order_status');
                return;
            }
            _this._addFilter('order_status', this.value);
        });
        this.filter_by_order_type.on('change', function() {
            if (this.value === 'false') {
                _this._removeFilter('order_type');
                return;
            }
            _this._addFilter('order_type', this.value);
        });
        this.search_id_ui.find('.btn').click(function(event) {
            event.preventDefault();
            let s = _this.search_id_ui.find('.searchbox').val().trim();
            if (s === '') {
                return;
            }
            _this._addFilter('filter_order_id', s);
        })
        this.search_safe_match_ui.find('.btn').click(function(event) {
            event.preventDefault();
            let s = _this.search_safe_match_ui.find('.searchbox').val().trim();
            if (s === '') {
                return;
            }
            _this._addFilter('filter_order_safe_match', s);
        })
    }

    _addFilter(filterType, filterValue) {
        this.filter_order_id = false;
        this.filter_order_safe_match = false;
        switch (filterType) {
            case 'order_status':
                this.filter_order_status = filterValue;
            break;
            case 'order_type':
                this.filter_order_type = filterValue;
            break;
            case 'filter_order_id':
                this.filter_order_id = filterValue;
                this._addFilterUI('filter_order_id');
            break;
            case 'filter_order_safe_match':
                this.filter_order_safe_match = filterValue;
                this._addFilterUI('filter_order_safe_match');
            break;
        }
        this.paged = 1;
        this.fetchOrders();
    }

    _removeFilter(filterType) {
        switch (filterType) {
            case 'order_status':
                this.filter_order_status = false;
            break;
            case 'order_type':
                this.filter_order_type = false;
            break;
            case 'filter_order_id':
                this.filter_order_id = false;
            break;
            case 'filter_order_safe_match':
                this.filter_order_safe_match = false;
            break;
        }
        this.paged = 1;
        this.fetchOrders();
    }

    _addFilterUI(type) {
        this.apt_filters_dynamic.empty();

        let template = '';
        switch (type) {
            case 'filter_order_id':
                if (!this.filter_order_id) {
                    return;
                }
                this.search_safe_match_ui.find('.searchbox').val('');
                template = `
                    <div class="filter" data-type="filter_order_id">
                        <div class="mr_10">${ DataUtils.getInstance().getLabel('search_by_order_id') } ${ this.filter_order_id }</div>
                        <div class="close_filter"><span class="icon-clear"></span></div>
                    </div>
                `;
            break;
            case 'filter_order_safe_match':
                if (!this.filter_order_safe_match) {
                    return;
                }
                this.search_id_ui.find('.searchbox').val('');
                template = `
                    <div class="filter" data-type="filter_order_safe_match">
                        <div class="mr_10">${ DataUtils.getInstance().getLabel('search_by_safematch_code') } ${ this.filter_order_safe_match }</div>
                        <div class="close_filter"><span class="icon-clear"></span></div>
                    </div>
                `;
            break;
        }
        const _this = this;

        const filter = jQuery(template);
        filter.appendTo(this.apt_filters_dynamic);
        filter.find('.close_filter').click(function(event) {
            event.preventDefault();
            const type = jQuery(this).parent().attr('data-type');
            if (type === 'filter_order_id') {
                _this.search_id_ui.find('.searchbox').val('');
            }
            if (type === 'filter_order_safe_match') {
                _this.search_safe_match_ui.find('.searchbox').val('');
            }
            _this._removeFilter(type)
            jQuery(this).parent().remove();
        })
    }


    resetAll() {
        if (this._ui[0] && this._ui.find('.appetit_table_body')[0]) {
            this._ui.find('.appetit_table_body').empty();
        }
        
        this._ordersInstances = [];
        this._orders = [];
    
        this.result_per_page = 20;
        this.paged = 1;
        this.max_num_pages = 1;
        this.filter_order_status = false;
        this.filter_order_type = false;
        this.filter_order_id = false;
        this.filter_order_safe_match = false;
    }

    _handleNotfound() {
        this._ui.find('.not_found').hide();
        if (this._orders.length !== 0) {
            this._ui.find('.not_found').hide();
        } else {
            this._ui.find('.not_found').show();
        }
    }

    _handleOrderStatusChange({ ID, order_action, _mode, _from_lightbox }) {
        const instanceData = this._findOrderInstance(ID);
        if (!instanceData) {
            return;
        }

        const { index, instance } = instanceData;

        if (instance.getMode() !== _mode) {
            return;
        }

        if (order_action === 'DELETE') {
            instance.removeUI();
            this._ordersInstances.splice(index, 1);
            this._orders.splice(index, 1);
            EventBus.getInstance().triggerEvent(Events.RELOAD_REGULAR_ORDERS, {});
            return;
        }
        instance.updateStatus(order_action);
    }

    _findOrderInstance(orderId) {
        let instanceData = false;
        for (let i = 0; i < this._ordersInstances.length; i++) {
            const orderItem = this._ordersInstances[i];
            if (parseInt(orderId) === parseInt(orderItem.getOrder().ID)) {
                instanceData = { index: i, instance: orderItem }
                break;
            }
        }
        return instanceData;
    }
    
    static getInstance() {
        if (!instance) {
            instance = new RegularOrders(instanceKey);
        }
        return instance;
    }
}
export default RegularOrders;