<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

if(!defined('ABSPATH')) exit();
?>
<!-- List: a menu list with fields of its own (settings.menus), on the layer that repeats over it and every layer inside it.
     The rows are built by SR7.editor.elements.contentlist.read -->
<sr-separator keepborder>
	<sr-separator-head>
		<sr-separator-title><?php _e('List','revslider'); ?></sr-separator-title><sr-tooltip key="contentlist"></sr-tooltip>
		<sr-separator-toggle><svg class="sr--icon" width="20" height="12"><use xlink:href="#General_Expand_Large"></use></svg></sr-separator-toggle>
	</sr-separator-head>
	<sr-separator-body>
		<sr-wrap id="sr_list_img"></sr-wrap>
		<sr-wrap id="sr_list_items" class="sr--separator--group"></sr-wrap>
		<sr-button full clean class="sr--cta sr--mb--15" data-action="editor.elements.contentlist.add"><svg class="sr--icon" width="10" height="10"><use xlink:href="#General_Add"></use></svg> <?php _e('Add Item','revslider'); ?></sr-button>
		<sr-input id="sr_list_st" wide><input name="Delay per Item" r="menu.st" type="text" number="true" dragnumber min="0" max="400" step="10" validate autocomplete="off"><span noicon class="sr--form--otitle"><?php _e('Delay per Item (ms)','revslider'); ?></span></sr-input>
		<sr-sp h="5"></sr-sp>
	</sr-separator-body>
</sr-separator>
<sr-separator keepborder>
	<sr-separator-head>
		<sr-separator-title><?php _e('List Fields','revslider'); ?></sr-separator-title><sr-tooltip key="contentlistfields"></sr-tooltip>
		<sr-separator-toggle><svg class="sr--icon" width="20" height="12"><use xlink:href="#General_Expand_Large"></use></svg></sr-separator-toggle>
	</sr-separator-head>
	<sr-separator-body>
		<sr-wrap id="sr_list_fields"></sr-wrap>
		<sr-button full clean class="sr--cta sr--mb--15" data-action="editor.elements.contentlist.addField"><svg class="sr--icon" width="10" height="10"><use xlink:href="#General_Add"></use></svg> <?php _e('Add Field','revslider'); ?></sr-button>
		<sr-sp h="5"></sr-sp>
	</sr-separator-body>
</sr-separator>
