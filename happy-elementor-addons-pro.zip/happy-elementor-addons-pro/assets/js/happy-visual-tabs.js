"use strict";

!function () {
  "use strict";

  var BREAKPOINT = 768;
  function clamp(v, min, max) {
    return v < min ? min : v > max ? max : v;
  }
  function smoothstep(t) {
    return t * t * (3 - 2 * t);
  }
  function parseFloatSafe(v, fb) {
    var n = parseFloat(v);
    return isNaN(n) ? fb : n;
  }
  function cssEasingFor(rawEasing) {
    var map = {
      'ease': 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      'ease-in': 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
      'ease-out': 'cubic-bezier(0.215, 0.61, 0.355, 1)',
      'ease-in-out': 'cubic-bezier(0.645, 0.045, 0.355, 1)',
      'bounce': 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
      'elastic': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)'
    };
    return map[rawEasing] || 'cubic-bezier(0.25, 0.46, 0.45, 0.94)';
  }
  function publishVisualTabsTitleWidths(list) {
    if (!list || !list.classList.contains('ha-v-tabs-zoom')) {
      return;
    }
    var wraps = list.querySelectorAll(':scope > .ha-v-tabs-item > .ha-v-tabs-title-wrap');
    for (var i = 0; i < wraps.length; i++) {
      var wrap = wraps[i];
      var title = wrap.querySelector(':scope > .ha-v-tabs-service-title');
      if (!title) {
        continue;
      }
      var next = Math.round(title.offsetWidth) + 'px';
      if (wrap.style.getPropertyValue('--ha-v-tabs-title-w') !== next) {
        wrap.style.setProperty('--ha-v-tabs-title-w', next);
      }
    }
  }
  var CLIP = {
    none: null,
    revealBottomIn: 'inset(0 0 0% 0)',
    revealBottomOut: 'inset(0 0 100% 0)',
    revealTopIn: 'inset(0% 0 0 0)',
    revealTopOut: 'inset(0 0 100% 0)',
    verticalIn: 'inset(0% 0 0 0)',
    verticalOut: 'inset(100% 0 0 0)',
    squareIn: 'inset(0% 0% 0% 0%)',
    squareOut: 'inset(100% 100% 100% 100%)',
    circleIn: 'circle(100% at 50% 50%)',
    circleOut: 'circle(0% at 50% 50%)',
    slideDownIn: 'inset(0% 0 0 0)',
    slideDownOut: 'inset(0 0 0% 0)',
    slideUpIn: 'inset(0 0 0% 0)',
    slideUpOut: 'inset(0% 0 0 0)'
  };
  var SELF_SCALED = {
    zoom: true,
    'zoom-blur': true
  };
  function clipInFor(animation) {
    switch (animation) {
      case 'vertical-reveal':
      case 'reveal-top':
      case 'slide-down-reveal':
        return CLIP.revealTopIn;
      case 'reveal-bottom':
      case 'slide-up-reveal':
        return CLIP.revealBottomIn;
      case 'square-reveal':
        return CLIP.squareIn;
      case 'mask-reveal':
        return CLIP.circleIn;
    }
    return CLIP.none;
  }
  function clipOutFor(animation) {
    switch (animation) {
      case 'vertical-reveal':
      case 'reveal-bottom':
      case 'reveal-top':
        return CLIP.verticalOut;
      case 'square-reveal':
        return CLIP.squareOut;
      case 'mask-reveal':
        return CLIP.circleOut;
      case 'slide-down-reveal':
        return CLIP.slideDownOut;
      case 'slide-up-reveal':
        return CLIP.slideUpOut;
    }
    return CLIP.none;
  }
  function clipOutOverrideFor(animation) {
    if (animation === 'reveal-bottom') {
      return CLIP.verticalOut;
    }
    if (animation === 'slide-down-reveal') {
      return CLIP.slideDownOut;
    }
    if (animation === 'slide-up-reveal') {
      return CLIP.verticalOut;
    }
    return null;
  }
  function initialStateFor(animation) {
    var s = {
      opacity: 0
    };
    if (animation !== 'fade' && !SELF_SCALED[animation]) {
      s.scale = 0.95;
    }
    switch (animation) {
      case 'vertical-reveal':
      case 'reveal-top':
        s.clip = CLIP.verticalOut;
        break;
      case 'reveal-bottom':
        s.clip = CLIP.revealBottomOut;
        break;
      case 'square-reveal':
        s.clip = CLIP.squareOut;
        break;
      case 'mask-reveal':
        s.clip = CLIP.circleOut;
        break;
      case 'zoom':
        s.scale = 0.85;
        break;
      case 'blur':
        s.filter = 'blur(20px)';
        break;
      case 'flip-3d':
        s.rotationY = -90;
        break;
      case 'zoom-blur':
        s.scale = 0.5;
        s.filter = 'blur(12px)';
        break;
      case 'slide-down-reveal':
        s.y = 80;
        s.clip = CLIP.slideDownOut;
        break;
      case 'slide-up-reveal':
        s.y = -80;
        s.clip = CLIP.slideUpOut;
        break;
    }
    return s;
  }
  function visibleStateFor(animation) {
    var s = {
      opacity: 1
    };
    if (animation !== 'fade' && !SELF_SCALED[animation]) {
      s.scale = 1;
    }
    switch (animation) {
      case 'vertical-reveal':
      case 'reveal-top':
        s.clip = CLIP.revealTopIn;
        break;
      case 'reveal-bottom':
        s.clip = CLIP.revealBottomIn;
        break;
      case 'square-reveal':
        s.clip = CLIP.squareIn;
        break;
      case 'mask-reveal':
        s.clip = CLIP.circleIn;
        break;
      case 'zoom':
        s.scale = 1;
        break;
      case 'blur':
        s.filter = 'blur(0px)';
        break;
      case 'flip-3d':
        s.rotationY = 0;
        break;
      case 'zoom-blur':
        s.scale = 1;
        s.filter = 'blur(0px)';
        break;
      case 'slide-down-reveal':
        s.y = 0;
        s.clip = CLIP.slideDownIn;
        break;
      case 'slide-up-reveal':
        s.y = 0;
        s.clip = CLIP.slideUpIn;
        break;
    }
    return s;
  }
  function hiddenStateFor(animation) {
    var s = {
      opacity: 0
    };
    if (animation !== 'fade' && !SELF_SCALED[animation]) {
      s.scale = 0.95;
    }
    var override = clipOutOverrideFor(animation);
    var clip = override !== null ? override : clipOutFor(animation);
    if (clip) {
      s.clip = clip;
    }
    switch (animation) {
      case 'zoom':
        s.scale = 0.85;
        break;
      case 'blur':
        s.filter = 'blur(20px)';
        break;
      case 'flip-3d':
        s.rotationY = -90;
        break;
      case 'zoom-blur':
        s.scale = 0.5;
        s.filter = 'blur(12px)';
        break;
      case 'slide-down-reveal':
        s.y = 80;
        break;
      case 'slide-up-reveal':
        s.y = -80;
        break;
    }
    return s;
  }
  function transformFor(p) {
    var parts = [];
    if (p.y) {
      parts.push('translate3d(0,' + p.y + 'px,0)');
    }
    if (p.rotationY) {
      parts.push('rotateY(' + p.rotationY + 'deg)');
    }
    if (p.scale) {
      parts.push('scale(' + p.scale + ')');
    }
    return parts.length ? parts.join(' ') : 'none';
  }
  function frameFor(p) {
    var f = {
      opacity: p.opacity != null ? String(p.opacity) : '1'
    };
    if (p.clip) {
      f.clipPath = p.clip;
    }
    if (p.filter) {
      f.filter = p.filter;
    }
    f.transform = transformFor(p);
    return f;
  }
  var hasWAAPI = typeof Element !== 'undefined' && !!Element.prototype.animate;
  function animatePanel(el, fromState, toState, duration, easing) {
    var old = el.__haVtabsAnim;
    if (old) {
      try {
        old.cancel();
      } catch (e) {}
      el.__haVtabsAnim = null;
    }
    if (!hasWAAPI) {
      applyFrame(el, toState);
      return null;
    }
    var anim = el.animate([frameFor(fromState), frameFor(toState)], {
      duration: Math.max(0, duration || 0),
      easing: easing,
      fill: 'both'
    });
    el.__haVtabsAnim = anim;
    return anim;
  }
  function applyFrame(el, state) {
    el.style.opacity = state.opacity != null ? String(state.opacity) : '';
    if (state.clip) {
      el.style.clipPath = state.clip;
    } else if (state.clip !== undefined && !state.clip) {
      el.style.clipPath = '';
    }
    if (state.filter) {
      el.style.filter = state.filter;
    } else if (state.filter !== undefined && !state.filter) {
      el.style.filter = '';
    }
    el.style.transform = transformFor(state);
  }
  function setDisplay(el, show) {
    if (el) {
      el.style.display = show ? 'block' : 'none';
    }
  }
  function syncListHeight($list) {
    var list = $list[0];
    if (!list) {
      return;
    }
    var prev = $list.data('ha-v-tabs-heightsync');
    if (prev) {
      if (prev.ro) {
        prev.ro.disconnect();
      }
      if (prev.mo) {
        prev.mo.disconnect();
      }
      if (prev.onResize) {
        jQuery(window).off('resize.haVTabsHeight', prev.onResize);
      }
      $list.removeData('ha-v-tabs-heightsync');
    }
    var panelOf = function panelOf(item) {
      var wrap = item.querySelector(':scope > .ha-v-tabs-sticky-container');
      var host = wrap || item;
      return {
        wrap: wrap || null,
        content: host.querySelector(':scope > .e-con, :scope > .elementor-element')
      };
    };
    var selectType = String($list.attr('data-select-type') || 'scroll');
    var followActivePanel = selectType === 'hover' || selectType === 'click';
    var measurePanel = function measurePanel(parts) {
      var el = parts && parts.content;
      if (!el) {
        return 0;
      }
      var wrapSt = parts.wrap ? parts.wrap.style : null;
      var savedWrapDisplay = wrapSt ? wrapSt.display : '';
      var st = el.style;
      var savedBottom = st.bottom;
      var savedHeight = st.height;
      if (wrapSt && savedWrapDisplay === 'none') {
        wrapSt.display = 'block';
      }
      st.bottom = 'auto';
      st.height = 'auto';
      var h = el.offsetHeight;
      st.bottom = savedBottom;
      st.height = savedHeight;
      if (wrapSt) {
        wrapSt.display = savedWrapDisplay;
      }
      return h;
    };
    var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(schedule) : null;
    var roObserved = ro && typeof WeakSet !== 'undefined' ? new WeakSet() : null;
    var pending = false;
    var track = function track(el) {
      if (ro && roObserved && el && !roObserved.has(el)) {
        roObserved.add(el);
        ro.observe(el);
      }
    };
    var measure = function measure() {
      pending = false;
      publishVisualTabsTitleWidths(list);
      if (list.hasAttribute('data-vtabs-pinned')) {
        return;
      }
      var h = 0;
      var $panels;
      if (followActivePanel) {
        var $active = $list.children('.ha-v-tabs-item.e-active').first();
        $panels = $active.length ? $active : $list.children('.ha-v-tabs-item').first();
      } else {
        $panels = $list.children('.ha-v-tabs-item');
      }
      $panels.each(function () {
        var ph = measurePanel(panelOf(this));
        if (ph > h) {
          h = ph;
        }
      });
      if (list.classList.contains('ha-v-tabs-zoom')) {
        $list.children('.ha-v-tabs-item').each(function () {
          var titleWrap = this.querySelector(':scope > .ha-v-tabs-title-wrap');
          track(titleWrap ? titleWrap.querySelector(':scope > .ha-v-tabs-service-title') : null);
        });
      }
      var next = Math.ceil(h) + 'px';
      if (list.style.getPropertyValue('--ha-v-tabs-content-height') !== next) {
        list.style.setProperty('--ha-v-tabs-content-height', next);
      }
      if (ro) {
        track(list);
        $list.children('.ha-v-tabs-item').each(function () {
          var el = panelOf(this).content;
          if (!el) {
            return;
          }
          track(el);
          jQuery(el).find('.elementor-widget-container').each(function () {
            track(this);
          });
        });
      }
    };
    function schedule() {
      if (pending) {
        return;
      }
      pending = true;
      requestAnimationFrame(measure);
    }
    track(list);
    var mo = null;
    if (typeof MutationObserver !== 'undefined') {
      mo = new MutationObserver(schedule);
      mo.observe(list, {
        subtree: true,
        childList: true,
        attributeFilter: ['class']
      });
    }
    var onResize = function onResize() {
      schedule();
    };
    jQuery(window).on('resize.haVTabsHeight', onResize);
    schedule();
    $list.data('ha-v-tabs-heightsync', {
      ro: ro,
      mo: mo,
      onResize: onResize
    });
  }
  function buildItemRef($item) {
    var $title = $item.children('.ha-v-tabs-title-wrap');
    var $container = $item.children('.e-con, .elementor-element').first();
    var $sticky = $item.children('.ha-v-tabs-sticky-container');
    if ($container.length && !$sticky.length) {
      $container.wrap('<div class="ha-v-tabs-sticky-container"></div>');
      $sticky = $item.children('.ha-v-tabs-sticky-container');
    }
    return {
      item: $item,
      title: $title,
      sticky: $sticky
    };
  }
  function Swapper(listEl, cfg) {
    this.list = listEl;
    this.$list = jQuery(listEl);
    this.cfg = cfg;
    this.easing = cssEasingFor(cfg.easing);
    this.duration = cfg.duration;
    this.inactiveOpacity = cfg.inactiveOpacity;
    this.animation = cfg.contentAnimation;
    this.current = 0;
    this.refs = [];
    this.$items = this.$list.children('.ha-v-tabs-item');
    var self = this;
    this.$items.each(function (i) {
      self.refs.push(buildItemRef(jQuery(this)));
    });
  }
  Swapper.prototype.setup = function () {
    var self = this;
    if (self.animation === 'none') {
      this.$items.each(function () {
        var item = this;
        var $title = jQuery(item).children('.ha-v-tabs-title-wrap');
        var $sticky = jQuery(item).children('.ha-v-tabs-sticky-container');
        item.style.opacity = '';
        item.style.transform = '';
        if ($sticky.length) {
          var s = $sticky[0];
          s.style.opacity = '';
          s.style.transform = '';
          s.style.filter = '';
          s.style.clipPath = '';
          s.style.display = '';
        }
        if ($title.length) {
          $title[0].style.opacity = jQuery(item).index() === 0 ? '1' : String(self.inactiveOpacity);
        }
      });
      return;
    }
    this.$items.each(function (i) {
      var ref = self.refs[i];
      var $title = ref.title;
      var $sticky = ref.sticky;
      if ($title.length) {
        var isActive = i === 0;
        $title[0].style.opacity = isActive ? '1' : String(self.inactiveOpacity);
      }
      if ($sticky && $sticky.length) {
        var s = $sticky[0];
        if (i === 0) {
          var anim = s.__haVtabsAnim;
          if (anim) {
            try {
              anim.cancel();
            } catch (e) {}
          }
          s.__haVtabsAnim = null;
          s.style.display = 'block';
          applyFrame(s, visibleStateFor(self.animation));
        } else {
          self.park(i);
        }
      }
    });
  };
  Swapper.prototype.park = function (i) {
    var s = this.refs[i].sticky;
    if (!s || !s.length) {
      return;
    }
    var el = s[0];
    var anim = el.__haVtabsAnim;
    if (anim) {
      try {
        anim.cancel();
      } catch (e) {}
    }
    el.__haVtabsAnim = null;
    setDisplay(el, false);
    applyFrame(el, initialStateFor(this.animation));
  };
  Swapper.prototype.hideIfInactive = function (i) {
    var self = this;
    return function () {
      var ref = self.refs[i];
      if (ref && ref.item && ref.item.hasClass('e-active')) {
        return;
      }
      if (ref && ref.sticky && ref.sticky.length) {
        setDisplay(ref.sticky[0], false);
      }
    };
  };
  Swapper.prototype.deactivate = function (i) {
    var ref = this.refs[i];
    if (!ref) {
      return;
    }
    var $title = ref.title;
    var $sticky = ref.sticky;
    if ($title && $title.length) {
      var t = $title[0];
      if (this.animation === 'none') {
        t.style.opacity = String(this.inactiveOpacity);
      } else {
        t.style.opacity = String(this.inactiveOpacity);
      }
    }
    if ($sticky && $sticky.length) {
      var s = $sticky[0];
      if (this.animation === 'none') {
        s.style.opacity = '0';
        setDisplay(s, false);
      } else {
        var out = hiddenStateFor(this.animation);
        var anim = animatePanel(s, visibleStateFor(this.animation), out, this.duration, this.easing);
        if (anim) {
          anim.onfinish = this.hideIfInactive(i);
        } else {
          setDisplay(s, false);
        }
      }
    }
    ref.item.removeClass('e-active');
  };
  Swapper.prototype.activate = function (i) {
    var ref = this.refs[i];
    if (!ref) {
      return;
    }
    var $title = ref.title;
    var $sticky = ref.sticky;
    var self = this;
    var outgoingIndex = this.current;
    if ($title && $title.length) {
      $title[0].style.opacity = '1';
    }
    if ($sticky && $sticky.length) {
      var s = $sticky[0];
      var outRef = this.refs[outgoingIndex];
      var useTimeline = this.animation !== 'none' && outRef && outRef.sticky && outRef.sticky.length && outgoingIndex !== i;
      if (useTimeline) {
        var prevAnim = outRef.sticky[0].__haVtabsAnim;
        if (prevAnim) {
          try {
            prevAnim.cancel();
          } catch (e) {}
        }
        outRef.sticky[0].__haVtabsAnim = null;
        setDisplay(s, true);
        animatePanel(s, initialStateFor(self.animation), visibleStateFor(self.animation), self.duration, self.easing);
        var outState = hiddenStateFor(self.animation);
        var outAnim = animatePanel(outRef.sticky[0], visibleStateFor(self.animation), outState, self.duration, self.easing);
        if (outAnim) {
          outAnim.onfinish = this.hideIfInactive(outgoingIndex);
        } else {
          setDisplay(outRef.sticky[0], false);
        }
      } else {
        if (this.animation === 'none') {
          var old = s.__haVtabsAnim;
          if (old) {
            try {
              old.cancel();
            } catch (e) {}
          }
          s.__haVtabsAnim = null;
          s.style.opacity = '';
          s.style.transform = '';
          s.style.filter = '';
          s.style.clipPath = '';
          s.style.display = 'block';
        } else {
          setDisplay(s, true);
          animatePanel(s, initialStateFor(this.animation), visibleStateFor(self.animation), self.duration, self.easing);
        }
      }
    }
    ref.item.addClass('e-active');
    this.current = i;
  };
  function initSwappable(listEl, cfg, selectType) {
    var listData = jQuery(listEl).data('ha-v-tabs-swapper');
    if (listData) {
      listData.teardown();
    }
    var swapper = new Swapper(listEl, cfg);
    swapper.setup();
    var refs = swapper.refs;
    var $list = swapper.$list;
    var $items = swapper.$items;
    syncListHeight($list);
    function activateIndex(i) {
      var wasActive = $items.eq(i).hasClass('e-active');
      $items.each(function (j) {
        if (j !== i && swapper.refs[j] && swapper.refs[j].item.hasClass('e-active')) {
          swapper.deactivate(j);
        }
      });
      if (!wasActive) {
        swapper.activate(i);
      }
      syncListHeight($list);
    }
    if (selectType === 'click') {
      $items.each(function (i) {
        jQuery(this).off('.haVTabsClick').on('click.haVTabsClick', function () {
          activateIndex(i);
        });
      });
    } else if (selectType === 'hover') {
      var resetHoverToFirst = function resetHoverToFirst() {
        var firstIndex = -1;
        for (var j = 0; j < refs.length; j++) {
          if (refs[j] && refs[j].item.hasClass('e-active')) {
            firstIndex = j;
          }
        }
        if (firstIndex > 0) {
          $items.each(function (j) {
            if (j !== 0 && refs[j] && refs[j].item.hasClass('e-active')) {
              swapper.deactivate(j);
            }
          });
          swapper.activate(0);
          syncListHeight($list);
        }
      };
      $items.each(function (i) {
        jQuery(this).off('.haVTabsHover').on('mouseenter.haVTabsHover', function () {
          if (refs[i] && !refs[i].item.hasClass('e-active')) {
            activateIndex(i);
          }
        });
      });
      $list.off('mouseleave.haVTabsHoverReset').on('mouseleave.haVTabsHoverReset', resetHoverToFirst);
    }
    var teardown = function teardown() {
      $items.each(function () {
        var item = this;
        var $sticky = jQuery(item).children('.ha-v-tabs-sticky-container');
        var $title = jQuery(item).children('.ha-v-tabs-title-wrap');
        item.classList.toggle('e-active', jQuery(item).index() === 0);
        if ($title.length) {
          var t = $title[0];
          t.style.opacity = '';
          t.style.transition = '';
          t.style.transform = '';
        }
        if ($sticky.length) {
          var s = $sticky[0];
          var anim = s.__haVtabsAnim;
          if (anim) {
            try {
              anim.cancel();
            } catch (e) {}
          }
          s.__haVtabsAnim = null;
          s.removeAttribute('style');
        }
      });
      $items.off('.haVTabsClick');
      $items.off('.haVTabsHover');
      $list.off('.haVTabsHoverReset');
    };
    jQuery(listEl).data('ha-v-tabs-swapper', {
      teardown: teardown,
      swapper: swapper
    });
    return {
      teardown: teardown
    };
  }
  function ScrollStory(listEl, cfg) {
    this.list = listEl;
    this.$list = jQuery(listEl);
    this.cfg = cfg;
    this.count = 0;
    this.items = [];
    this.titles = [];
    this.titleEls = [];
    this.panels = [];
    this.offsets = [];
    this.heights = [];
    this.contentHeights = [];
    this.contentOverflow = [];
    this.totalTitleHeight = 0;
    this.visibleHeight = 0;
    this.maxTranslate = 0;
    this.stagePadTop = 0;
    this.stagePadBottom = 0;
    this.active = -1;
    this.enabled = false;
    this.released = false;
    this.pinDistance = 0;
    this.mq = null;
    this._panelOffsets = {};
    this._rafId = null;
    this._lastY = null;
    this._wrapper = null;
    this._contentRO = null;
    this._loadWired = false;
    this._onScroll = this._onScroll.bind(this);
    this._onResize = this._onResize.bind(this);
    this._onLoad = this._onResize;
    this._onMqChange = this._onMqChange.bind(this);
    this._tick = this._tick.bind(this);
  }
  ScrollStory.prototype.cacheElements = function () {
    var itemEls = this.list.querySelectorAll(':scope > .ha-v-tabs-item');
    this.items = [];
    this.titles = [];
    this.titleEls = [];
    this.panels = [];
    for (var i = 0; i < itemEls.length; i++) {
      var item = itemEls[i];
      var title = item.querySelector(':scope > .ha-v-tabs-title-wrap');
      var panel = item.querySelector(':scope > .ha-v-tabs-sticky-container');
      this.items.push(item);
      this.titles.push(title);
      this.panels.push(panel || null);
      if (title) {
        this.titleEls.push(title);
      }
    }
    this.count = this.items.length;
  };
  ScrollStory.prototype.measurePanelContent = function (index) {
    var panel = this.panels[index];
    if (!panel) {
      return 0;
    }
    var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
    if (!content) {
      return 0;
    }
    var ps = panel.style;
    var st = content.style;
    var savedDisplay = ps.display;
    var savedBottom = st.bottom;
    var savedHeight = st.height;
    if (savedDisplay === 'none') {
      ps.display = 'block';
    }
    st.bottom = 'auto';
    st.height = 'auto';
    var h = content.offsetHeight;
    st.bottom = savedBottom;
    st.height = savedHeight;
    ps.display = savedDisplay;
    return h;
  };
  ScrollStory.prototype.calculate = function () {
    publishVisualTabsTitleWidths(this.list);
    var cs = window.getComputedStyle(this.list);
    var rowGap = parseFloatSafe(cs.rowGap, 0);
    this.stagePadTop = parseFloatSafe(cs.paddingTop, 0);
    this.stagePadBottom = parseFloatSafe(cs.paddingBottom, 0);
    this.heights = [];
    this.offsets = [];
    var cumulative = 0;
    for (var i = 0; i < this.count; i++) {
      var title = this.titles[i];
      var h = title ? title.offsetHeight : 0;
      this.heights.push(h);
      this.offsets.push(cumulative);
      cumulative += h + (i < this.count - 1 ? rowGap : 0);
    }
    this.totalTitleHeight = cumulative;
    this.visibleHeight = Math.max(0, this.list.clientHeight - this.stagePadTop - this.stagePadBottom);
    this.maxTranslate = Math.max(0, this.totalTitleHeight - this.visibleHeight);
    this.contentHeights = [];
    this.contentOverflow = [];
    for (var j = 0; j < this.count; j++) {
      var ch = this.measurePanelContent(j);
      this.contentHeights.push(ch);
      this.contentOverflow.push(Math.max(0, ch - this.visibleHeight));
    }
  };
  ScrollStory.prototype._maxPanelContent = function () {
    var m = 0;
    if (this.contentHeights) {
      for (var i = 0; i < this.contentHeights.length; i++) {
        if (this.contentHeights[i] > m) {
          m = this.contentHeights[i];
        }
      }
    }
    return m;
  };
  ScrollStory.prototype.stageHeightFor = function (contentPx, capToViewport) {
    var titles = this.totalTitleHeight || 0;
    var stickyTop = this.stagePadTop || 0;
    var h = Math.max(contentPx || 0, titles) + stickyTop;
    if (h < stickyTop + 50) {
      h = window.innerHeight;
    }
    if (capToViewport) {
      h = Math.min(h, window.innerHeight);
    }
    return h;
  };
  ScrollStory.prototype.pinDistanceFor = function () {
    var vh = window.innerHeight;
    var distance = this.count * vh * (1 / Math.max(0.1, this.cfg.scrollSpeed || 3));
    return Math.max(vh * 0.25, distance);
  };
  ScrollStory.prototype.build = function () {
    if (this._wrapper) {
      return;
    }
    var wrapper = document.createElement('div');
    wrapper.className = 'ha-v-tabs-scroll-stage';
    this.list.parentNode.insertBefore(wrapper, this.list);
    wrapper.appendChild(this.list);
    this._wrapper = wrapper;
  };
  ScrollStory.prototype.teardownWrapper = function () {
    if (this._wrapper && this._wrapper.parentNode) {
      var parent = this._wrapper.parentNode;
      parent.insertBefore(this.list, this._wrapper);
      parent.removeChild(this._wrapper);
    }
    this._wrapper = null;
    this.list.style.position = '';
    this.list.style.top = '';
    this.list.style.transform = '';
    this.list.style.removeProperty('--ha-v-tabs-stage-height');
  };
  ScrollStory.prototype._setStageHeight = function (px) {
    var next = Math.ceil(px) + 'px';
    if (this.list.style.getPropertyValue('--ha-v-tabs-stage-height') !== next) {
      this.list.style.setProperty('--ha-v-tabs-stage-height', next);
    }
  };
  ScrollStory.prototype._setWrapperHeight = function (px) {
    this._wrapper.style.height = Math.ceil(px) + 'px';
  };
  ScrollStory.prototype._initPanels = function () {
    var anim = this.cfg.contentAnimation;
    for (var i = 0; i < this.count; i++) {
      var panel = this.panels[i];
      if (!panel) {
        continue;
      }
      var a = panel.__haVtabsAnim;
      if (a) {
        try {
          a.cancel();
        } catch (e) {}
      }
      panel.__haVtabsAnim = null;
      var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
      if (content) {
        content.style.transform = '';
      }
      if (i === 0) {
        panel.style.display = 'block';
        applyFrame(panel, visibleStateFor(anim));
      } else {
        panel.style.display = 'none';
        applyFrame(panel, initialStateFor(anim));
      }
    }
    this._panelOffsets = {};
  };
  ScrollStory.prototype._animateContent = function (prev, next) {
    var nextPanel = this.panels[next];
    if (!nextPanel) {
      return;
    }
    var anim = this.cfg.contentAnimation;
    var duration = this.cfg.duration;
    var easing = cssEasingFor(this.cfg.easing);
    if (anim === 'none') {
      for (var k = 0; k < this.count; k++) {
        var p = this.panels[k];
        if (!p) {
          continue;
        }
        var a = p.__haVtabsAnim;
        if (a) {
          try {
            a.cancel();
          } catch (e) {}
        }
        p.__haVtabsAnim = null;
        p.style.display = k === next ? 'block' : 'none';
        p.style.opacity = k === next ? '1' : '0';
        p.style.transform = '';
        p.style.filter = '';
        p.style.clipPath = '';
      }
      return;
    }
    var prevPanel = prev >= 0 ? this.panels[prev] : null;
    var hasPrev = prev >= 0 && prev !== next && !!prevPanel;
    for (var u = 0; u < this.count; u++) {
      if (u !== next && u !== prev && this.panels[u]) {
        var uninvolved = this.panels[u];
        var ua = uninvolved.__haVtabsAnim;
        if (ua) {
          try {
            ua.cancel();
          } catch (e) {}
        }
        uninvolved.__haVtabsAnim = null;
        uninvolved.style.display = 'none';
        applyFrame(uninvolved, initialStateFor(anim));
      }
    }
    nextPanel.style.display = 'block';
    var self = this;
    if (hasPrev) {
      var outAnim = animatePanel(prevPanel, visibleStateFor(anim), hiddenStateFor(anim), duration, easing);
      if (outAnim) {
        outAnim.onfinish = function () {
          var item = self.items[prev];
          if (!item || !item.classList.contains('e-active')) {
            prevPanel.style.display = 'none';
          }
        };
      } else {
        prevPanel.style.display = 'none';
      }
    }
    animatePanel(nextPanel, initialStateFor(anim), visibleStateFor(anim), duration, easing);
  };
  ScrollStory.prototype.updatePanelContent = function (index, offset) {
    var applied = this._panelOffsets[index] || 0;
    if (applied === offset) {
      return;
    }
    var panel = this.panels[index];
    if (!panel) {
      return;
    }
    var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
    if (!content) {
      return;
    }
    if (offset > 0) {
      content.style.transform = 'translate3d(0,' + -Math.round(offset) + 'px,0)';
    } else {
      content.style.transform = '';
    }
    this._panelOffsets[index] = offset;
  };
  ScrollStory.prototype._contentOffsetAt = function (p, active) {
    if (!this.contentOverflow || !this.contentOverflow[active]) {
      return 0;
    }
    if (this.count < 2) {
      return 0;
    }
    var pos = p * (this.count - 1);
    var half = 0.5;
    var start;
    var end;
    if (active === 0) {
      start = 0;
      end = half;
    } else if (active === this.count - 1) {
      start = this.count - 1 - half;
      end = this.count - 1;
    } else {
      start = active - half;
      end = active + half;
    }
    var frac = (pos - start) / (end - start);
    frac = clamp(frac, 0, 1);
    return frac * this.contentOverflow[active];
  };
  ScrollStory.prototype.enable = function () {
    if (this.enabled) {
      return;
    }
    this.enabled = true;
    this.list.removeAttribute('data-vtabs-static');
    this.list.setAttribute('data-vtabs-pinned', '1');
    this.cacheElements();
    this.calculate();
    if (this.count < 2) {
      this._initPanels();
      this._setStageHeight(this.stageHeightFor(this._maxPanelContent(), false));
      for (var s = 0; s < this.count; s++) {
        this.items[s].classList.toggle('e-active', s === 0);
      }
      this.active = 0;
      return;
    }
    this.build();
    var pinned = this.stageHeightFor(this._maxPanelContent(), true);
    this.pinDistance = this.pinDistanceFor();
    this._setStageHeight(pinned);
    this._setWrapperHeight(pinned + this.pinDistance);
    this.list.style.position = 'sticky';
    this.list.style.top = '0px';
    for (var j = 0; j < this.titleEls.length; j++) {
      this.titleEls[j].style.transition = 'opacity 0.3s ease';
    }
    for (var k = 0; k < this.count; k++) {
      this.items[k].classList.toggle('e-active', k === 0);
      if (this.titles[k]) {
        this.titles[k].style.transform = 'translate3d(0,0,0)';
      }
    }
    this._initPanels();
    this.active = 0;
    this.released = false;
    this._lastY = null;
    window.addEventListener('resize', this._onResize);
    window.addEventListener('orientationchange', this._onResize);
    window.addEventListener('scroll', this._onScroll, {
      passive: true
    });
    this._observeContent();
    var self = this;
    requestAnimationFrame(function () {
      self.calculate();
      self.reflow();
      self._update(self._currentProgress());
    });
    if (document.readyState === 'complete') {
      this.reflow();
    } else if (!this._loadWired) {
      this._loadWired = true;
      window.addEventListener('load', this._onLoad);
    }
  };
  ScrollStory.prototype.disable = function () {
    if (!this.enabled) {
      return;
    }
    this.enabled = false;
    window.removeEventListener('resize', this._onResize);
    window.removeEventListener('orientationchange', this._onResize);
    window.removeEventListener('scroll', this._onScroll);
    if (this._loadWired) {
      this._loadWired = false;
      window.removeEventListener('load', this._onLoad);
    }
    this._stopRaf();
    this._unobserveContent();
    if (this._wrapper) {
      this.teardownWrapper();
    }
    for (var i = 0; i < this.count; i++) {
      var item = this.items[i];
      if (item) {
        item.classList.toggle('e-active', i === 0);
      }
      if (this.titles[i]) {
        this.titles[i].style.transform = '';
        this.titles[i].style.transition = '';
      }
      var panel = this.panels[i];
      if (panel) {
        var a = panel.__haVtabsAnim;
        if (a) {
          try {
            a.cancel();
          } catch (e) {}
        }
        panel.__haVtabsAnim = null;
        panel.style.display = '';
        panel.style.opacity = '';
        panel.style.transform = '';
        panel.style.filter = '';
        panel.style.clipPath = '';
        var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
        if (content) {
          content.style.transform = '';
        }
      }
    }
    this._panelOffsets = {};
    this.active = 0;
    this.released = false;
    this.list.removeAttribute('data-vtabs-pinned');
    this.list.setAttribute('data-vtabs-static', '1');
    this.list.style.removeProperty('--ha-v-tabs-stage-height');
  };
  ScrollStory.prototype._observeContent = function () {
    if (typeof ResizeObserver === 'undefined') {
      return;
    }
    var self = this;
    this._contentRO = new ResizeObserver(function () {
      if (!self.enabled) {
        return;
      }
      self.reflow();
    });
    var track = function track(el) {
      if (el) {
        self._contentRO.observe(el);
      }
    };
    track(this.list);
    for (var i = 0; i < this.count; i++) {
      var panel = this.panels[i];
      if (!panel) {
        continue;
      }
      track(panel);
      var content = panel.querySelector(':scope > .e-con, :scope > .elementor-element');
      if (!content) {
        continue;
      }
      track(content);
      var inners = content.querySelectorAll('.elementor-widget-container');
      for (var k = 0; k < inners.length; k++) {
        track(inners[k]);
      }
    }
  };
  ScrollStory.prototype._unobserveContent = function () {
    if (this._contentRO) {
      this._contentRO.disconnect();
      this._contentRO = null;
    }
  };
  ScrollStory.prototype.reflow = function () {
    if (!this.enabled) {
      return;
    }
    this.calculate();
    this.pinDistance = this.pinDistanceFor();
    if (this.released) {
      var lastContent = this.contentHeights && this.contentHeights[this.count - 1] || 0;
      var exit = this.stageHeightFor(lastContent, false);
      this._setStageHeight(exit);
      this._setWrapperHeight(this.pinDistance + exit);
    } else {
      var pinned = this.stageHeightFor(this._maxPanelContent(), true);
      this._setStageHeight(pinned);
      this._setWrapperHeight(this.pinDistance + pinned);
    }
  };
  ScrollStory.prototype._onResize = function () {
    if (!this.enabled) {
      return;
    }
    this.reflow();
    this._update(this._currentProgress());
  };
  ScrollStory.prototype._onScroll = function () {
    if (!this.enabled) {
      return;
    }
    if (this._rafId === null) {
      this._rafId = requestAnimationFrame(this._tick);
    }
  };
  ScrollStory.prototype._tick = function () {
    this._rafId = null;
    if (!this.enabled) {
      return;
    }
    if (!this._wrapper || !this._wrapper.isConnected) {
      this.disable();
      return;
    }
    var rect = this._wrapper.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    if (rect.bottom < -vh * 0.5 || rect.top > vh * 1.5) {
      this._lastY = null;
      return;
    }
    var s = window.pageYOffset || document.documentElement.scrollTop || 0;
    if (this._lastY === s) {
      return;
    }
    this._lastY = s;
    this._update(this._progressFromRect(rect, s));
  };
  ScrollStory.prototype._wrapperTop = function (rect, s) {
    return rect.top + s;
  };
  ScrollStory.prototype._progressFromRect = function (rect, s) {
    var A = this._wrapperTop(rect, s);
    var P = this.pinDistance || 1;
    return clamp((s - A) / P, 0, 1);
  };
  ScrollStory.prototype._currentProgress = function () {
    var s = window.pageYOffset || document.documentElement.scrollTop || 0;
    var rect = this._wrapper.getBoundingClientRect();
    return this._progressFromRect(rect, s);
  };
  ScrollStory.prototype._update = function (p) {
    if (!this.enabled || this.count < 1) {
      return;
    }
    p = clamp(p, 0, 1);
    var rect = this._wrapper.getBoundingClientRect();
    var s = window.pageYOffset || document.documentElement.scrollTop || 0;
    var A = this._wrapperTop(rect, s);
    var pinEnd = A + (this.pinDistance || 0);
    if (!this.released && p >= 1) {
      this.released = true;
      var lastContent = this.contentHeights && this.contentHeights[this.count - 1] || 0;
      var exit = this.stageHeightFor(lastContent, false);
      this._setStageHeight(exit);
      this._setWrapperHeight(this.pinDistance + exit);
      this.updatePanelContent(this.count - 1, 0);
    } else if (this.released && s < pinEnd - 1) {
      this.released = false;
      var pinned = this.stageHeightFor(this._maxPanelContent(), true);
      this._setStageHeight(pinned);
      this._setWrapperHeight(this.pinDistance + pinned);
    }
    var active = this.count > 1 ? Math.round(p * (this.count - 1)) : 0;
    active = clamp(active, 0, this.count - 1);
    var delta = this.maxTranslate > 0 && this.count > 1 ? this._trackOffsetAt(p) : 0;
    this._updateTitlePosition(delta);
    var contentOffset = this._contentOffsetAt(p, active);
    this.updatePanelContent(active, contentOffset);
    if (active !== this.active) {
      var prev = this.active;
      this.active = active;
      if (prev >= 0 && this.items[prev]) {
        this.items[prev].classList.remove('e-active');
      }
      if (this.items[active]) {
        this.items[active].classList.add('e-active');
      }
      this._animateContent(prev, active);
    }
  };
  ScrollStory.prototype._updateTitlePosition = function (delta) {
    var tr = delta > 0 ? 'translate3d(0,-' + delta + 'px,0)' : 'translate3d(0,0,0)';
    for (var i = 0; i < this.titleEls.length; i++) {
      if (this.titleEls[i].style.transform !== tr) {
        this.titleEls[i].style.transform = tr;
      }
    }
  };
  ScrollStory.prototype._trackOffsetAt = function (p) {
    if (this.count < 2) {
      return 0;
    }
    var pos = p * (this.count - 1);
    var i = Math.floor(pos);
    if (i >= this.count - 1) {
      return Math.min(this.offsets[this.count - 1], this.maxTranslate);
    }
    var frac = pos - i;
    var from = this.offsets[i] || 0;
    var to = this.offsets[i + 1] || 0;
    var half = 0.3,
      center = 0.5;
    var t;
    if (frac <= center - half) {
      t = 0;
    } else if (frac >= center + half) {
      t = 1;
    } else {
      t = smoothstep((frac - (center - half)) / (2 * half));
    }
    return clamp(from + (to - from) * t, 0, this.maxTranslate);
  };
  ScrollStory.prototype._stopRaf = function () {
    if (this._rafId !== null) {
      cancelAnimationFrame(this._rafId);
      this._rafId = null;
    }
  };
  ScrollStory.prototype._wireBreakpoint = function () {
    this.mq = window.matchMedia('(min-width: ' + BREAKPOINT + 'px)');
    this._onBreakpoint(this.mq.matches);
    if (typeof this.mq.addEventListener === 'function') {
      this.mq.addEventListener('change', this._onMqChange);
    } else if (typeof this.mq.addListener === 'function') {
      this.mq.addListener(this._onMqChange);
    }
  };
  ScrollStory.prototype._unwireBreakpoint = function () {
    if (!this.mq) {
      return;
    }
    if (typeof this.mq.removeEventListener === 'function') {
      this.mq.removeEventListener('change', this._onMqChange);
    } else if (typeof this.mq.removeListener === 'function') {
      this.mq.removeListener(this._onMqChange);
    }
    this.mq = null;
  };
  ScrollStory.prototype._onMqChange = function (e) {
    this._onBreakpoint(e.matches);
  };
  ScrollStory.prototype._onBreakpoint = function (matches) {
    if (matches) {
      this.enable();
    } else {
      this.disable();
    }
  };
  ScrollStory.prototype.destroy = function () {
    this._unwireBreakpoint();
    this.disable();
  };
  function initScrollStory(listEl, cfg) {
    var prev = jQuery(listEl).data('ha-v-tabs-scroll');
    if (prev && typeof prev.destroy === 'function') {
      prev.destroy();
    }
    jQuery(listEl).children('.ha-v-tabs-item').each(function () {
      buildItemRef(jQuery(this));
    });
    var story = new ScrollStory(listEl, cfg);
    story._wireBreakpoint();
    jQuery(listEl).data('ha-v-tabs-scroll', story);
    return story;
  }
  function setupWidget($scope) {
    var $serviceList = $scope.find('.ha-v-tabs-list');
    if (!$serviceList.length) {
      return;
    }
    var widgetId = $scope.data('id');
    var reindexItems = function reindexItems() {
      $serviceList.first().children('.ha-v-tabs-item').each(function (i) {
        var count = i + 1;
        jQuery(this).attr('data-service-index', count);
      });
    };
    var linkContainer = function linkContainer(e) {
      var detail = e && (e.detail || e.originalEvent && e.originalEvent.detail) || {};
      var container = detail.container;
      if (!container || !container.model) {
        return;
      }
      if (String(container.model.get('id')) !== String(widgetId)) {
        return;
      }
      var index = detail.index;
      var targetContainer = detail.targetContainer;
      var type = detail.action && detail.action.type;
      var $items = $serviceList.first().children('.ha-v-tabs-item');
      var itemNode = null;
      var contentNode = targetContainer && targetContainer.view ? targetContainer.view.$el[0] : null;
      if ('duplicate' === type) {
        itemNode = $items[index + 1];
      } else if ('move' === type) {
        itemNode = $items[index];
      }
      if (itemNode && contentNode) {
        itemNode.appendChild(contentNode);
      }
      reindexItems();
    };
    if (typeof elementorFrontend !== 'undefined' && elementorFrontend.elements && elementorFrontend.elements.$window) {
      elementorFrontend.elements.$window.off('elementor/nested-container/atomic-repeater.haVTabs');
      elementorFrontend.elements.$window.on('elementor/nested-container/atomic-repeater.haVTabs', linkContainer);
    }
    if ($scope.hasClass('elementor-element-edit-mode')) {
      return;
    }
    $serviceList.each(function () {
      var $currentList = jQuery(this);
      var list = this;
      var selectType = $currentList.attr('data-select-type') || 'scroll';
      var cfg = {
        inactiveOpacity: parseFloatSafe($currentList.attr('data-inactive-opacity'), 1),
        contentAnimation: $currentList.attr('data-content-animation') || 'fade',
        duration: parseInt($currentList.attr('data-content-animation-duration') || '400', 10),
        easing: $currentList.attr('data-content-animation-easing') || 'ease',
        scrollSpeed: parseFloatSafe($currentList.attr('data-scroll-speed'), 3)
      };
      if (isNaN(cfg.duration) || cfg.duration <= 0) {
        cfg.duration = 400;
      }
      if (isNaN(cfg.inactiveOpacity)) {
        cfg.inactiveOpacity = 1;
      }
      if (cfg.scrollSpeed <= 0) {
        cfg.scrollSpeed = 3;
      }
      syncListHeight($currentList);
      if (selectType === 'scroll') {
        initScrollStory(list, cfg);
      } else if (selectType === 'hover' || selectType === 'click') {
        initSwappable(list, cfg, selectType);
      }
    });
  }
  var registered = false;
  function registerHook() {
    if (registered || typeof elementorFrontend === 'undefined' || !elementorFrontend.hooks) {
      return false;
    }
    registered = true;
    elementorFrontend.hooks.addAction('frontend/element_ready/ha-visual-tabs.default', setupWidget);
    return true;
  }
  jQuery(window).on('elementor/frontend/init', function () {
    registerHook();
  });
  jQuery(function () {
    if (!registerHook()) {
      var attempts = 0;
      var interval = setInterval(function () {
        if (registerHook() || ++attempts > 40) {
          clearInterval(interval);
        }
      }, 150);
    }
  });
}();