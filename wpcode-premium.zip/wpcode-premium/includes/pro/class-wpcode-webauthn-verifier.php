<?php
/**
 * Minimal WebAuthn assertion verifier (ES256 / RS256 only, no external dependency).
 *
 * @package WPCode
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_WebAuthn_Verifier.
 *
 * Verifies a WebAuthn authentication assertion using only PHP's `openssl`
 * extension: a minimal CBOR decoder for COSE_Key / authenticatorData, DER
 * construction of the public key, and `openssl_verify()` for the signature
 * check. Restricted to ES256 (P-256/ECDSA) and RS256 (RSA/PKCS#1 v1.5), both
 * of which are verified as SHA-256 signatures.
 *
 * This class only checks cryptographic and structural validity of an
 * assertion; it does not touch storage, nonces, or WordPress hooks. Callers
 * are responsible for nonce single-use enforcement and persisting the
 * returned sign count. Methods throw `Exception` on any invalid, malformed,
 * or unsupported input — callers should catch and translate to a rejection.
 */
class WPCode_WebAuthn_Verifier {

	/**
	 * COSE key type: 2-coordinate elliptic curve key.
	 *
	 * @var int
	 */
	const COSE_KTY_EC2 = 2;

	/**
	 * COSE key type: RSA key.
	 *
	 * @var int
	 */
	const COSE_KTY_RSA = 3;

	/**
	 * COSE curve: P-256.
	 *
	 * @var int
	 */
	const COSE_CRV_P256 = 1;

	/**
	 * COSE algorithm: ES256 (ECDSA with SHA-256).
	 *
	 * @var int
	 */
	const COSE_ALG_ES256 = -7;

	/**
	 * COSE algorithm: RS256 (RSASSA-PKCS1-v1_5 with SHA-256).
	 *
	 * @var int
	 */
	const COSE_ALG_RS256 = -257;

	/**
	 * authenticatorData flag bit: User Present.
	 *
	 * @var int
	 */
	const FLAG_USER_PRESENT = 0x01;

	/**
	 * authenticatorData flag bit: User Verified.
	 *
	 * @var int
	 */
	const FLAG_USER_VERIFIED = 0x04;

	/**
	 * authenticatorData flag bit: Attested credential data included.
	 *
	 * @var int
	 */
	const FLAG_ATTESTED_DATA = 0x40;

	/**
	 * Verify a WebAuthn authentication assertion.
	 *
	 * @param array $args {
	 *     Assertion data and expectations.
	 *
	 *     @type array  $credential_public_key     Stored COSE public key for the credential (as returned by self::parse_authenticator_data()).
	 *     @type string $authenticator_data         Raw `authenticatorData` bytes.
	 *     @type string $client_data_json           Raw `clientDataJSON` bytes.
	 *     @type string $signature                  Raw signature bytes.
	 *     @type string $expected_challenge          Raw (decoded) challenge bytes expected in `clientDataJSON.challenge`. Must be non-empty.
	 *     @type string $expected_rp_id              Expected RP ID, e.g. `library.wpcode.com`.
	 *     @type string $expected_origin             Expected `clientDataJSON.origin`, e.g. `https://library.wpcode.com`.
	 *     @type bool   $require_user_verification   Whether the UV flag must be set. Default false.
	 *     @type int    $previous_sign_count         Previously stored sign count, for clone detection. Optional. When
	 *                                                supplied, the presented count must strictly increase unless both
	 *                                                counts are zero (authenticator without a counter).
	 *     @type int    $expected_algorithm          COSE algorithm identifier (e.g. -7 for ES256, -257 for RS256) the
	 *                                                stored credential was registered with. When supplied, the
	 *                                                credential's COSE `alg` must match exactly. Callers should
	 *                                                always pass this once a credential's registered algorithm is
	 *                                                on record, so a public key can never be verified under a
	 *                                                different algorithm than the one it was enrolled with.
	 * }
	 * @return array { @type int $sign_count The sign count reported in this assertion. }
	 * @throws Exception If the assertion is malformed, unsupported, or fails verification.
	 */
	public static function verify_assertion( array $args ) {
		if ( ! isset( $args['credential_public_key'] ) || ! is_array( $args['credential_public_key'] ) ) {
			throw new Exception( 'Missing or malformed credential public key.' );
		}

		foreach ( array( 'authenticator_data', 'client_data_json', 'signature', 'expected_rp_id', 'expected_origin' ) as $required_string ) {
			if ( ! isset( $args[ $required_string ] ) || ! is_string( $args[ $required_string ] ) || '' === $args[ $required_string ] ) {
				throw new Exception( 'Missing or malformed argument: ' . $required_string . '.' );
			}
		}

		if ( ! isset( $args['expected_challenge'] ) || ! is_string( $args['expected_challenge'] ) || '' === $args['expected_challenge'] ) {
			// Refuse to verify without a real challenge binding: hash_equals( '', '' )
			// is true, so an empty expectation would silently disable replay protection.
			throw new Exception( 'Expected challenge must be a non-empty string.' );
		}

		$client_data = json_decode( $args['client_data_json'], true );

		// The three fields must be strings: clientDataJSON is attacker-controlled,
		// and a JSON array/number here would throw a TypeError (not an Exception)
		// inside strtr()/hash_equals() further down.
		if (
			! is_array( $client_data )
			|| ! isset( $client_data['type'], $client_data['challenge'], $client_data['origin'] )
			|| ! is_string( $client_data['type'] )
			|| ! is_string( $client_data['challenge'] )
			|| ! is_string( $client_data['origin'] )
		) {
			throw new Exception( 'Malformed clientDataJSON.' );
		}

		if ( 'webauthn.get' !== $client_data['type'] ) {
			throw new Exception( 'Unexpected clientDataJSON type.' );
		}

		if ( ! hash_equals( $args['expected_challenge'], self::base64url_decode( $client_data['challenge'] ) ) ) {
			throw new Exception( 'Challenge mismatch.' );
		}

		if ( ! hash_equals( $args['expected_origin'], $client_data['origin'] ) ) {
			throw new Exception( 'Origin mismatch.' );
		}

		$authenticator_data = self::parse_authenticator_data( $args['authenticator_data'] );

		if ( ! hash_equals( hash( 'sha256', $args['expected_rp_id'], true ), $authenticator_data['rp_id_hash'] ) ) {
			throw new Exception( 'rpIdHash mismatch.' );
		}

		if ( ! $authenticator_data['flags']['up'] ) {
			throw new Exception( 'User Presence flag not set.' );
		}

		if ( ! empty( $args['require_user_verification'] ) && ! $authenticator_data['flags']['uv'] ) {
			throw new Exception( 'User Verification flag not set.' );
		}

		// WebAuthn section 7.2 step 21: if either the presented or the stored sign
		// count is nonzero, the presented count must strictly increase. Only when
		// both are zero (authenticator never implements a counter) is the check
		// skipped — otherwise a cloned authenticator could evade detection by
		// simply reporting zero.
		if (
			isset( $args['previous_sign_count'] )
			&& ( 0 !== $authenticator_data['sign_count'] || 0 !== $args['previous_sign_count'] )
			&& $authenticator_data['sign_count'] <= $args['previous_sign_count']
		) {
			throw new Exception( 'Sign count did not strictly increase; possible cloned authenticator.' );
		}

		if ( isset( $args['expected_algorithm'] )
			&& ( ! isset( $args['credential_public_key'][3] ) || $args['expected_algorithm'] !== $args['credential_public_key'][3] )
		) {
			throw new Exception( 'Credential algorithm mismatch.' );
		}

		$public_key_pem = self::cose_key_to_pem( $args['credential_public_key'] );
		$signed_data    = $args['authenticator_data'] . hash( 'sha256', $args['client_data_json'], true );

		if ( ! self::verify_signature( $public_key_pem, $signed_data, $args['signature'] ) ) {
			throw new Exception( 'Signature verification failed.' );
		}

		return array(
			'sign_count' => $authenticator_data['sign_count'],
		);
	}

	/**
	 * Verify a raw signature against a PEM-encoded public key.
	 *
	 * @param string $public_key_pem PEM-encoded SubjectPublicKeyInfo.
	 * @param string $signed_data    The exact bytes that were signed.
	 * @param string $signature      Raw signature bytes (DER for ECDSA, PKCS#1 v1.5 for RSA).
	 * @return bool
	 * @throws Exception If the public key cannot be loaded or verification errors out.
	 */
	public static function verify_signature( $public_key_pem, $signed_data, $signature ) {
		if ( ! function_exists( 'openssl_verify' ) ) {
			// The plugin has no other openssl dependency, so a PHP build
			// without the extension must fail closed with a clear message
			// instead of a fatal "undefined function" error.
			throw new Exception( 'The OpenSSL PHP extension is required to verify passkey signatures.' );
		}

		$public_key = openssl_pkey_get_public( $public_key_pem );

		if ( false === $public_key ) {
			throw new Exception( 'Unable to load public key: ' . openssl_error_string() );
		}

		$result = openssl_verify( $signed_data, $signature, $public_key, OPENSSL_ALGO_SHA256 );

		if ( -1 === $result ) {
			throw new Exception( 'openssl_verify() error: ' . openssl_error_string() );
		}

		return 1 === $result;
	}

	/**
	 * Parse an `authenticatorData` byte string per WebAuthn section 6.1.
	 *
	 * @param string $binary Raw `authenticatorData` bytes.
	 * @return array {
	 *     @type string     $rp_id_hash             32-byte SHA-256 of the RP ID.
	 *     @type array      $flags                  { @type bool up, @type bool uv, @type bool at, @type bool ed }.
	 *     @type int        $sign_count             32-bit unsigned sign count.
	 *     @type string|null $aaguid                16-byte AAGUID, if attested credential data is present.
	 *     @type string|null $credential_id         Credential ID, if attested credential data is present.
	 *     @type array|null $credential_public_key  Decoded COSE_Key, if attested credential data is present.
	 * }
	 * @throws Exception If the data is truncated or malformed.
	 */
	public static function parse_authenticator_data( $binary ) {
		if ( strlen( $binary ) < 37 ) {
			throw new Exception( 'authenticatorData: too short.' );
		}

		$flags_byte = ord( $binary[32] );

		$result = array(
			'rp_id_hash'            => substr( $binary, 0, 32 ),
			'flags'                 => array(
				'up' => (bool) ( $flags_byte & self::FLAG_USER_PRESENT ),
				'uv' => (bool) ( $flags_byte & self::FLAG_USER_VERIFIED ),
				'at' => (bool) ( $flags_byte & self::FLAG_ATTESTED_DATA ),
			),
			'sign_count'            => self::unpack_uint32_be( substr( $binary, 33, 4 ) ),
			'aaguid'                => null,
			'credential_id'         => null,
			'credential_public_key' => null,
		);

		if ( ! $result['flags']['at'] ) {
			return $result;
		}

		$offset = 37;
		self::require_length( $binary, $offset, 18 );

		$result['aaguid'] = substr( $binary, $offset, 16 );
		$offset          += 16;

		$credential_id_length = self::unpack_uint16_be( substr( $binary, $offset, 2 ) );
		$offset              += 2;

		self::require_length( $binary, $offset, $credential_id_length );
		$result['credential_id'] = substr( $binary, $offset, $credential_id_length );
		$offset                 += $credential_id_length;

		list( $cose_key ) = self::cbor_decode_item( $binary, $offset );

		$result['credential_public_key'] = $cose_key;

		return $result;
	}

	/**
	 * Convert a decoded COSE_Key into a PEM-encoded SubjectPublicKeyInfo.
	 *
	 * @param array $cose_key Decoded COSE_Key map (integer keys, per RFC 9053 section 7).
	 * @return string PEM-encoded public key.
	 * @throws Exception If the key type or curve is unsupported, or the key is malformed.
	 */
	public static function cose_key_to_pem( array $cose_key ) {
		if ( ! isset( $cose_key[1] ) ) {
			throw new Exception( 'COSE key missing key type (kty).' );
		}

		switch ( $cose_key[1] ) {
			case self::COSE_KTY_EC2:
				return self::ec2_cose_key_to_pem( $cose_key );
			case self::COSE_KTY_RSA:
				return self::rsa_cose_key_to_pem( $cose_key );
			default:
				throw new Exception( 'Unsupported COSE key type; only EC2 (ES256) and RSA (RS256) are supported.' );
		}
	}

	/**
	 * Convert an EC2/P-256 COSE_Key into a PEM-encoded SubjectPublicKeyInfo.
	 *
	 * @param array $cose_key Decoded COSE_Key map.
	 * @return string
	 * @throws Exception If the curve is unsupported or the coordinates are malformed.
	 */
	private static function ec2_cose_key_to_pem( array $cose_key ) {
		if ( ! isset( $cose_key[-1] ) || self::COSE_CRV_P256 !== $cose_key[-1] ) {
			throw new Exception( 'Unsupported EC2 curve; only P-256 is supported.' );
		}

		$x = isset( $cose_key[-2] ) ? $cose_key[-2] : '';
		$y = isset( $cose_key[-3] ) ? $cose_key[-3] : '';

		if ( 32 !== strlen( $x ) || 32 !== strlen( $y ) ) {
			throw new Exception( 'Malformed EC2 public key coordinates.' );
		}

		// Fixed DER header for a P-256 SubjectPublicKeyInfo (id-ecPublicKey + prime256v1 OIDs),
		// followed by the SEC1 uncompressed point (0x04 || x || y).
		$header = "\x30\x59\x30\x13\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07\x03\x42\x00";

		return self::der_to_pem( $header . "\x04" . $x . $y );
	}

	/**
	 * Convert an RSA COSE_Key into a PEM-encoded SubjectPublicKeyInfo.
	 *
	 * @param array $cose_key Decoded COSE_Key map.
	 * @return string
	 * @throws Exception If the modulus/exponent are missing.
	 */
	private static function rsa_cose_key_to_pem( array $cose_key ) {
		$modulus  = isset( $cose_key[-1] ) ? $cose_key[-1] : '';
		$exponent = isset( $cose_key[-2] ) ? $cose_key[-2] : '';

		if ( '' === $modulus || '' === $exponent ) {
			throw new Exception( 'Malformed RSA public key.' );
		}

		$rsa_public_key = self::der_sequence( array( self::der_integer( $modulus ), self::der_integer( $exponent ) ) );

		// Fixed DER AlgorithmIdentifier for rsaEncryption (1.2.840.113549.1.1.1) with NULL parameters.
		$algorithm_id     = "\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
		$subject_key_info = self::der_sequence( array( $algorithm_id, self::der_bit_string( $rsa_public_key ) ) );

		return self::der_to_pem( $subject_key_info );
	}

	/**
	 * Decode a base64url string to raw binary.
	 *
	 * @param string $data Base64url-encoded string.
	 * @return string
	 */
	public static function base64url_decode( $data ) {
		$remainder = strlen( $data ) % 4;

		if ( $remainder ) {
			$data .= str_repeat( '=', 4 - $remainder );
		}

		return (string) base64_decode( strtr( $data, '-_', '+/' ), true );
	}

	/**
	 * Encode raw binary to a base64url string.
	 *
	 * @param string $data Raw binary.
	 * @return string
	 */
	public static function base64url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}

	/**
	 * Decode a CBOR-encoded byte string into a PHP value.
	 *
	 * Supports only the major types used by COSE_Key: unsigned int (0),
	 * negative int (1), byte string (2), text string (3), array (4), and
	 * map (5). Sufficient for this verifier's needs only.
	 *
	 * @param string $data Raw CBOR bytes.
	 * @return mixed
	 * @throws Exception If the structure is truncated or uses an unsupported major type.
	 */
	public static function cbor_decode( $data ) {
		list( $value ) = self::cbor_decode_item( $data, 0 );

		return $value;
	}

	/**
	 * Decode a single CBOR data item starting at the given offset.
	 *
	 * @param string $data   Raw CBOR bytes.
	 * @param int    $offset Offset to start decoding at.
	 * @return array { @type mixed 0 Decoded value, @type int 1 Offset after this item. }
	 * @throws Exception If the structure is truncated or uses an unsupported major type.
	 */
	private static function cbor_decode_item( $data, $offset, $depth = 0 ) {
		// WebAuthn structures are shallow (COSE keys nest 1 level); a hard depth
		// cap keeps hostile deeply-nested CBOR - reachable pre-verification via
		// authenticatorData with the AT flag set - from exhausting the PHP
		// stack, which would crash the worker instead of throwing.
		if ( $depth > 8 ) {
			throw new Exception( 'CBOR: nesting too deep.' );
		}

		self::require_length( $data, $offset, 1 );

		$initial_byte = ord( $data[ $offset ] );
		$major_type   = $initial_byte >> 5;
		$additional   = $initial_byte & 0x1f;
		$offset++;

		list( $length, $offset ) = self::cbor_read_argument( $data, $offset, $additional );

		switch ( $major_type ) {
			case 0: // Unsigned integer.
				return array( $length, $offset );

			case 1: // Negative integer.
				return array( -1 - $length, $offset );

			case 2: // Byte string.
			case 3: // Text string.
				self::require_length( $data, $offset, $length );
				return array( substr( $data, $offset, $length ), $offset + $length );

			case 4: // Array.
				$items = array();
				for ( $i = 0; $i < $length; $i++ ) {
					list( $item, $offset ) = self::cbor_decode_item( $data, $offset, $depth + 1 );
					$items[]               = $item;
				}
				return array( $items, $offset );

			case 5: // Map.
				$map = array();
				for ( $i = 0; $i < $length; $i++ ) {
					list( $key, $offset ) = self::cbor_decode_item( $data, $offset, $depth + 1 );

					// COSE map keys are always integers (or, rarely, strings). A
					// non-scalar key would be a TypeError when used as an array
					// offset, escaping the class's Exception contract.
					if ( ! is_int( $key ) && ! is_string( $key ) ) {
						throw new Exception( 'CBOR: unsupported map key type.' );
					}

					// RFC 8949 section 5.6: maps with duplicate keys are not valid.
					if ( array_key_exists( $key, $map ) ) {
						throw new Exception( 'CBOR: duplicate map key.' );
					}

					list( $value, $offset ) = self::cbor_decode_item( $data, $offset, $depth + 1 );

					$map[ $key ] = $value;
				}
				return array( $map, $offset );

			default:
				throw new Exception( sprintf( 'CBOR: unsupported major type %d.', $major_type ) );
		}
	}

	/**
	 * Read a CBOR item's argument (length/value) per RFC 8949 section 3.
	 *
	 * @param string $data       Raw CBOR bytes.
	 * @param int    $offset     Offset immediately after the initial byte.
	 * @param int    $additional The 5-bit "additional information" from the initial byte.
	 * @return array { @type int 0 Argument value, @type int 1 Offset after the argument. }
	 * @throws Exception If the encoding is indefinite-length or otherwise unsupported.
	 */
	private static function cbor_read_argument( $data, $offset, $additional ) {
		if ( $additional < 24 ) {
			return array( $additional, $offset );
		}

		switch ( $additional ) {
			case 24:
				self::require_length( $data, $offset, 1 );
				return array( ord( $data[ $offset ] ), $offset + 1 );

			case 25:
				self::require_length( $data, $offset, 2 );
				return array( self::unpack_uint16_be( substr( $data, $offset, 2 ) ), $offset + 2 );

			case 26:
				self::require_length( $data, $offset, 4 );
				return array( self::unpack_uint32_be( substr( $data, $offset, 4 ) ), $offset + 4 );

			default:
				throw new Exception( 'CBOR: unsupported or indefinite-length encoding.' );
		}
	}

	/**
	 * Ensure at least `$needed` bytes remain in `$data` starting at `$offset`.
	 *
	 * @param string $data   Raw bytes.
	 * @param int    $offset Offset to check from.
	 * @param int    $needed Number of bytes required.
	 * @return void
	 * @throws Exception If the data is truncated.
	 */
	private static function require_length( $data, $offset, $needed ) {
		if ( $offset + $needed > strlen( $data ) ) {
			throw new Exception( 'Unexpected end of data.' );
		}
	}

	/**
	 * Unpack a 2-byte big-endian unsigned integer.
	 *
	 * @param string $bytes Exactly 2 bytes.
	 * @return int
	 */
	private static function unpack_uint16_be( $bytes ) {
		$unpacked = unpack( 'n', $bytes );

		return $unpacked[1];
	}

	/**
	 * Unpack a 4-byte big-endian unsigned integer.
	 *
	 * @param string $bytes Exactly 4 bytes.
	 * @return int
	 * @throws Exception On 32-bit PHP when the value exceeds PHP_INT_MAX.
	 */
	private static function unpack_uint32_be( $bytes ) {
		$unpacked = unpack( 'N', $bytes );

		if ( $unpacked[1] < 0 ) {
			// 32-bit PHP: values >= 2^31 unpack as negative, which would corrupt
			// sign-count comparisons and CBOR length bounds checks. Fail closed.
			throw new Exception( 'Unsigned 32-bit value out of range on this platform.' );
		}

		return $unpacked[1];
	}

	/**
	 * DER-encode a length per the ASN.1 definite-length rules.
	 *
	 * @param int $length The length to encode.
	 * @return string
	 */
	private static function der_length( $length ) {
		if ( $length < 128 ) {
			return chr( $length );
		}

		$bytes = '';

		while ( $length > 0 ) {
			$bytes  = chr( $length & 0xff ) . $bytes;
			$length = $length >> 8;
		}

		return chr( 0x80 | strlen( $bytes ) ) . $bytes;
	}

	/**
	 * DER-encode an unsigned big-endian byte string as an ASN.1 INTEGER.
	 *
	 * @param string $bytes Big-endian magnitude bytes (e.g. an RSA modulus or exponent).
	 * @return string
	 */
	private static function der_integer( $bytes ) {
		if ( strlen( $bytes ) > 0 && ( ord( $bytes[0] ) & 0x80 ) ) {
			// High bit set: prepend a zero byte so DER doesn't read this as negative.
			$bytes = "\x00" . $bytes;
		}

		while ( strlen( $bytes ) > 1 && "\x00" === $bytes[0] && ! ( ord( $bytes[1] ) & 0x80 ) ) {
			$bytes = substr( $bytes, 1 );
		}

		return "\x02" . self::der_length( strlen( $bytes ) ) . $bytes;
	}

	/**
	 * DER-encode a SEQUENCE from already-encoded child elements.
	 *
	 * @param string[] $der_items Already DER-encoded child elements.
	 * @return string
	 */
	private static function der_sequence( array $der_items ) {
		$body = implode( '', $der_items );

		return "\x30" . self::der_length( strlen( $body ) ) . $body;
	}

	/**
	 * DER-encode a BIT STRING with zero unused bits.
	 *
	 * @param string $bytes Raw bytes to wrap.
	 * @return string
	 */
	private static function der_bit_string( $bytes ) {
		$body = "\x00" . $bytes;

		return "\x03" . self::der_length( strlen( $body ) ) . $body;
	}

	/**
	 * Wrap a DER-encoded SubjectPublicKeyInfo in PEM armor.
	 *
	 * @param string $der DER-encoded bytes.
	 * @return string
	 */
	private static function der_to_pem( $der ) {
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}
}
