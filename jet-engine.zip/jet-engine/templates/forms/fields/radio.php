<?php
/**
 * input[type="hidden"] template
 */

$required    = $this->get_required_val( $args );
$name        = $this->get_field_name( $args['name'] );
$default     = ! Jet_Engine_Tools::is_empty( $args['default'] ) ? $args['default'] : false;
$data_switch = '';

if ( $required ) {
	$required = 'required="required"';
}

if ( ! empty( $args['switch_on_change'] ) ) {
	$data_switch = ' data-switch="1"';
}

if ( ! empty( $args['field_options'] ) ) {

	echo '<div class="jet-form__fields-group checkradio-wrap">';

	foreach ( $args['field_options'] as $value => $option ) {

		$checked = '';
		$calc    = '';

		if ( is_array( $option ) ) {
			$val   = isset( $option['value'] ) ? $option['value'] : $value;
			$label = isset( $option['label'] ) ? $option['label'] : $val;
		} else {
			$val   = $value;
			$label = $option;
		}

		if ( $default || '0' === $default ) {
			$checked = checked( $default, $val, false );
		}

		if ( is_array( $option ) && isset( $option['calculate'] ) ) {
			$calc = ' data-calculate="' . esc_attr( $option['calculate'] ) . '"';
		}

		$custom_template = false;

		if ( ! empty( $args['custom_item_template'] ) ) {
			$custom_template = $this->get_custom_template( $val, $args, $checked );
		}

		?>
		<div class="jet-form__field-wrap radio-wrap checkradio-wrap">
			<?php if ( $custom_template ) {
				echo $custom_template;
			} ?>
			<label class="jet-form__field-label">
				<input
					type="radio"
					name="<?php echo esc_attr( $name ); ?>"
					class="jet-form__field radio-field checkradio-field"
					value="<?php echo esc_attr( $val ); ?>"
					data-field-name="<?php echo esc_attr( $args['name'] ); ?>"
					<?php echo $checked; ?>
					<?php echo $required; ?>
					<?php echo $calc ? wp_kses_post( $calc ) : ''; ?>
					<?php echo $data_switch ? wp_kses_post( $data_switch ) : ''; ?>
				>
				<?php echo esc_html( $label ); ?>
			</label>
		</div>
		<?php

	}

	if ( $custom_template ) {
		wp_reset_postdata();
		wp_reset_query();
	}

	echo '</div>';

}
