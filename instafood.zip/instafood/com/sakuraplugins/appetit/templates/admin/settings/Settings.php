<?php
namespace com\sakuraplugins\appetit\templates\admin\settings;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . 'SettingsConfig.php');
require_once(plugin_dir_path(__FILE__) . '../../../config.php');

use com\sakuraplugins\appetit\Config as Config;

class Settings {
    function render(): void {
        $sections = SettingsConfig::get();
        ?>
         <form method="post" action="options.php">
            <?php settings_fields(Config::getOptionsGroupSlug()); ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <?php foreach ($sections as $section): ?>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link <?= $section['isActive'] ? 'active' : '' ?>" id="<?= esc_attr($section['content_id']) ?>-tab" data-toggle="tab" href="#<?= $section['content_id'] ?>" role="tab" aria-controls="home" aria-selected="true"><?= $section['menu_label'] ?></a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <?php foreach ($sections as $section): ?>
                                <div class="tab-pane fade show <?= $section['isActive'] ? 'active' : '' ?>" id="<?= esc_attr($section['content_id']) ?>" role="tabpanel" aria-labelledby="<?= esc_attr($section['content_id']) ?>-tab">
                                    <div class="settings-tab-content">
                                        <?php $section['SectionClass']->render(); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                        </div>

                    </div>
                </div>
            </div>
         </form>
        <?php
    }
}
?>