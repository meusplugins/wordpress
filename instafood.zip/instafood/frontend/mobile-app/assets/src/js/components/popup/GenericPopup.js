class GenericPopup {

    _ui;
    _supportClose = true;
    _isClosing = false;
    _title = '';
    _closeHook;

    constructor(title = '', supportClose = true) {
        this._supportClose = supportClose;
        this._title = title;
    }

    setCloseHook(closeHook) {
        this._closeHook = closeHook;
    }

    render() {
        const template = `
        <div class="generic_popup">
            <div class="gp_back"></div>
            <div class="gp_ui">
                <div class="cp_win">
                    <div class="win_title_ui">
                        <div class="win_title">${ this._title }</div>
                        ${ this._supportClose ? `<a class="round_nav_fill reverse-color close_popup_btn" href="#"><span class="icon-clear"></span></a>` : '' }
                    </div>
                    <div class="win_content_ui"></div>
                    <div class="win_footer"></div>
                    <div class="loading d_none"><div class="lds-ripple"><div></div><div></div></div></div>
                </div>
            </div>
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo('body');
        const _this = this;
        if (this._supportClose) {
            this._ui.find('.close_popup_btn').click(function(event) {
                event.preventDefault();
                _this.close();
            })
        }
        this._onShow();
    }

    getContentUI() {
        return this._ui.find('.win_content_ui');
    }

    getFooterContentUI() {
        return this._ui.find('.win_footer');
    }

    _onShow() {
        jQuery('.generic_popup').find('.gp_back').animate({
            opacity: 1
        }, 800, 'easeInOutQuint', () => {});
        jQuery('.generic_popup').find('.gp_ui').animate({
            opacity: 1
        }, 800, 'easeInOutQuint', () => {});
    }

    showPreloader() {
        this._ui.find('.loading').removeClass('d_none');
    }

    removePreloader() {
        this._ui.find('.loading').addClass('d_none');
    }

    close() {
        if (this._isClosing) {
            return;
        }
        if (this._closeHook) {
            this._closeHook();
        }
        this._isClosing = true;
        jQuery('.generic_popup').find('.gp_back').animate({
            opacity: 0
        }, 800, 'easeInOutQuint', () => {
            jQuery('.generic_popup').remove();
        });
        jQuery('.generic_popup').find('.gp_ui').animate({
            opacity: 0
        }, 800, 'easeInOutQuint', () => {});
    }
}
export default GenericPopup;