class Checkbox {
    _onChnage;
    _selected;
    _parentUI;
    _label;
    _ui;

    constructor(parentUI, label, onChnage, selected = false) {
        this._parentUI = parentUI;
        this._label = label;
        this._onChnage = onChnage;
        this._selected = selected;
    }

    render() {
        const template = `
<div class="product_widget apt_no_padding no_background pt_10 pb_10">
    <div class="widget_radio_entry ${ this._selected ? 'selected' : '' }" data-id="72">
        <div class="square_symbol primary_color_border">
            <div class="square_fill primary_color show"><span class="icon-check"></span></div>
        </div>
        <div class="variant_info">${ this._label }</div>
    </div>
</div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._parentUI);
        const _this = this;
        this._ui.click(function(event) {
            event.preventDefault();
            _this._switch();
        })
    }

    _switch() {
        this._selected = this._selected ? false : true;
        this._updateOnChange();
    }

    setSelected(val) {
        this._selected = val;
        this._updateOnChange();
    }

    _updateOnChange() {
        if (this._selected) {
            if (!this._ui.find('.widget_radio_entry').hasClass('selected')) {
                this._ui.find('.widget_radio_entry').addClass('selected')
            }
        } else {
            if (this._ui.find('.widget_radio_entry').hasClass('selected')) {
                this._ui.find('.widget_radio_entry').removeClass('selected')
            }
        }
        this._onChnage(this._selected);
    }
}
export default Checkbox;