"use strict";

function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
function _get() { return _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (e, t, r) { var p = _superPropBase(e, t); if (p) { var n = Object.getOwnPropertyDescriptor(p, t); return n.get ? n.get.call(arguments.length < 3 ? e : r) : n.value; } }, _get.apply(null, arguments); }
function _superPropBase(t, o) { for (; !{}.hasOwnProperty.call(t, o) && null !== (t = _getPrototypeOf(t));); return t; }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
!function () {
  "use strict";

  var registered = false;
  var REPEATER_ROW_SELECTORS = ['.elementor-repeater-row-item-title', '.e-repeater-row-item-title', '.elementor-repeater-row-tools', '.elementor-repeater-row-handle', '.e-repeater-row-title'];
  function getRepeaterControlView(controlName) {
    try {
      var page = elementor.getPanelView && elementor.getPanelView().getCurrentPageView && elementor.getPanelView().getCurrentPageView();
      if (!page) {
        return null;
      }
      if (typeof page.getControlViewByName === 'function') {
        var direct = page.getControlViewByName(controlName);
        if (direct) {
          return direct;
        }
      }
      var views = page.children && page.children._views;
      if (views) {
        for (var key in views) {
          if (!Object.prototype.hasOwnProperty.call(views, key)) {
            continue;
          }
          var view = views[key];
          if (view && view.model && view.model.get('name') === controlName) {
            return view;
          }
        }
      }
    } catch (e) {}
    return null;
  }
  function findRepeaterRows($scope) {
    for (var i = 0; i < REPEATER_ROW_SELECTORS.length; i++) {
      var $rows = $scope.find(REPEATER_ROW_SELECTORS[i]);
      if ($rows.length) {
        return $rows;
      }
    }
    return jQuery();
  }
  function expandRepeaterRow($rows, memberId) {
    $rows.filter('.elementor-active').trigger('click');
    setTimeout(function () {
      var $target = $rows.eq(Number(memberId));
      if (!$target.length) {
        return;
      }
      $target.trigger('click');
      setTimeout(function () {
        var $scrollParent = $target.parents().filter(function () {
          var oy = jQuery(this).css('overflow-y');
          return oy === 'auto' || oy === 'scroll';
        }).first();
        if (!$scrollParent.length) {
          $scrollParent = $target.parents().filter(function () {
            return this.scrollHeight > this.clientHeight;
          }).first();
        }
        if ($scrollParent.length) {
          var headerHeight = jQuery('#elementor-panel-header').outerHeight() || 60;
          var containerTop = $scrollParent[0].getBoundingClientRect().top;
          var targetTop = $target[0].getBoundingClientRect().top;
          var currentScroll = $scrollParent.scrollTop();
          $scrollParent.scrollTop(currentScroll + (targetTop - containerTop) - headerHeight + 55);
        }
      }, 400);
    }, 300);
  }
  function activateRepeaterItem(memberId, controlName, sectionName, attempt, sectionOpened) {
    attempt = attempt || 0;
    var controlView = getRepeaterControlView(controlName);
    var $scope = controlView ? controlView.$el : jQuery('#elementor-panel-content-wrapper');
    var $rows = findRepeaterRows($scope);
    if ($rows.length) {
      expandRepeaterRow($rows, memberId);
      return;
    }
    if (!sectionOpened && sectionName) {
      var sectionView = getRepeaterControlView(sectionName);
      if (sectionView && !sectionView.$el.hasClass('elementor-open')) {
        var $heading = sectionView.$el.find('.elementor-panel-heading');
        ($heading.length ? $heading : sectionView.$el).trigger('click');
      }
      sectionOpened = true;
    }
    if (attempt < 12) {
      setTimeout(function () {
        activateRepeaterItem(memberId, controlName, sectionName, attempt + 1, sectionOpened);
      }, 150);
    } else if (window.console) {
      window.console.warn('Happy Nested Hover List: repeater rows not found for "' + controlName + '".');
    }
  }
  function register() {
    if (registered) {
      return true;
    }
    if (typeof elementor === "undefined" || typeof $e === "undefined") {
      return false;
    }
    var component = $e.components && ($e.components.get("nested-elements/nested-repeater") || $e.components.get("nested-elements"));
    var nestedModule = component && component.exports ? component.exports : null;
    if (!nestedModule || !nestedModule.NestedViewBase || !nestedModule.NestedModelBase) {
      return false;
    }
    var NestedElementBase = elementor.modules && elementor.modules.elements && elementor.modules.elements.types && elementor.modules.elements.types.NestedElementBase;
    if (typeof NestedElementBase !== "function") {
      return false;
    }
    var NestedViewBase = nestedModule.NestedViewBase;
    var HappyNestedHoverListView = /*#__PURE__*/function (_NestedViewBase) {
      function HappyNestedHoverListView() {
        _classCallCheck(this, HappyNestedHoverListView);
        return _callSuper(this, HappyNestedHoverListView, arguments);
      }
      _inherits(HappyNestedHoverListView, _NestedViewBase);
      return _createClass(HappyNestedHoverListView, [{
        key: "events",
        value: function events() {
          var parentEvents = typeof NestedViewBase.prototype.events === "function" ? NestedViewBase.prototype.events.call(this) : {};
          return Object.assign({}, parentEvents, {
            "click .ha-n-hover-list-title": "onTitleClick",
            "keydown .ha-n-hover-list-title": "onTitleKeydown"
          });
        }
      }, {
        key: "onTitleClick",
        value: function onTitleClick(event) {
          var $title = jQuery(event.currentTarget);
          var $clickedItem = $title.closest(".ha-n-hover-list-item");
          var $list = $title.closest(".ha-n-hover-list");
          var wasActive = $clickedItem.hasClass('e-active');
          $list.children(".ha-n-hover-list-item").each(function () {
            var $item = jQuery(this);
            if ($item.hasClass('e-active')) {
              $item.removeClass('e-active');
              $item.children('.ha-n-hover-list-title').removeClass('e-active').attr('aria-expanded', 'false');
            }
          });
          if (!wasActive) {
            $clickedItem.addClass('e-active');
            $title.addClass('e-active').attr('aria-expanded', 'true');
          }
          this.openItemSettings($clickedItem);
        }
      }, {
        key: "openItemSettings",
        value: function openItemSettings($clickedItem) {
          try {
            if (typeof $e === 'undefined') {
              return;
            }
            var widgetContainer = this.container;
            if (!widgetContainer) {
              return;
            }
            var itemIndex = $clickedItem.index();
            $e.run('document/elements/select', {
              container: widgetContainer
            });
            if (itemIndex >= 0) {
              activateRepeaterItem(itemIndex, 'items', 'section_items');
            }
          } catch (e) {}
        }
      }, {
        key: "onTitleKeydown",
        value: function onTitleKeydown(event) {
          if ("Enter" !== event.key && " " !== event.key) {
            return;
          }
          event.preventDefault();
          jQuery(event.currentTarget).trigger("click");
        }
      }]);
    }(NestedViewBase);
    var ZOOM_VAR_CONTROLS = {
      'title_zoom_scale': '--ha-n-hover-list-title-zoom-scale',
      'title_zoom_duration': '--ha-n-hover-list-title-zoom-duration',
      'title_zoom_easing': '--ha-n-hover-list-title-zoom-easing'
    };
    var ZOOM_CLASS_CONTROLS = {
      'title_zoom': 'ha-n-hover-list-title-zoom',
      'icon_zoom': 'ha-n-hover-list-icon-zoom'
    };
    function findNestedHoverListRoot(view) {
      var $root = view && view.$el && view.$el.length ? view.$el.closest('.elementor-widget-ha-n-hover-list') : jQuery();
      if (!$root.length && view && view.$el) {
        $root = view.$el.find('.elementor-widget-ha-n-hover-list').first();
      }
      if (!$root.length && view && view.$el && view.$el.hasClass('elementor-widget-ha-n-hover-list')) {
        $root = view.$el;
      }
      return $root.length ? $root : null;
    }
    function patchZoomControl(view, controlName, value) {
      var zoomClass = ZOOM_CLASS_CONTROLS[controlName];
      if (zoomClass) {
        var $root = findNestedHoverListRoot(view);
        if ($root) {
          var $list = $root.find('.ha-n-hover-list').first();
          if (!$list.length && $root.hasClass('ha-n-hover-list')) {
            $list = $root;
          }
          if ($list.length) {
            $list.toggleClass(zoomClass, 'yes' === value);
          }
        }
        return;
      }
      var prop = ZOOM_VAR_CONTROLS[controlName];
      if (!prop) {
        return;
      }
      var cssValue = value && 'object' === _typeof(value) ? value.size : value;
      if ('title_zoom_duration' === controlName && cssValue) {
        cssValue += 'ms';
      }
      if (cssValue) {
        cssValue = String(cssValue);
      }
      var $root2 = findNestedHoverListRoot(view);
      if (!$root2) {
        return;
      }
      if (cssValue) {
        $root2[0].style.setProperty(prop, cssValue);
      } else {
        $root2[0].style.removeProperty(prop);
      }
    }
    var originalRenderChanges = HappyNestedHoverListView.prototype.renderChanges;
    HappyNestedHoverListView.prototype.renderChanges = function (settings) {
      try {
        if (settings && typeof settings.changedAttributes === 'function') {
          var changed = settings.changedAttributes();
          var changedKeys = Object.keys(changed);
          var zoomKeys = changedKeys.filter(function (key) {
            return ZOOM_CLASS_CONTROLS[key] || ZOOM_VAR_CONTROLS[key];
          });
          if (zoomKeys.length && zoomKeys.length === changedKeys.length) {
            var self = this;
            zoomKeys.forEach(function (key) {
              patchZoomControl(self, key, changed[key]);
            });
            originalRenderChanges.apply(this, arguments);
            return;
          }
        }
      } catch (e) {}
      return originalRenderChanges.apply(this, arguments);
    };
    var HappyNestedHoverListElement = /*#__PURE__*/function (_NestedElementBase) {
      function HappyNestedHoverListElement() {
        _classCallCheck(this, HappyNestedHoverListElement);
        return _callSuper(this, HappyNestedHoverListElement, arguments);
      }
      _inherits(HappyNestedHoverListElement, _NestedElementBase);
      return _createClass(HappyNestedHoverListElement, [{
        key: "getType",
        value: function getType() {
          return "ha-happy-nested-hover-list";
        }
      }, {
        key: "getView",
        value: function getView() {
          return HappyNestedHoverListView;
        }
      }, {
        key: "getModel",
        value: function getModel() {
          return nestedModule.NestedModelBase;
        }
      }, {
        key: "getInitialConfig",
        value: function getInitialConfig() {
          return Object.assign({}, _superPropGet(HappyNestedHoverListElement, "getInitialConfig", this, 3)([]), {
            defaults: {
              repeater_title_setting: "item_title"
            }
          });
        }
      }]);
    }(NestedElementBase);
    elementor.elementsManager.registerElementType(new HappyNestedHoverListElement());
    registered = true;
    return true;
  }
  if (window.elementorCommon && elementorCommon.elements && elementorCommon.elements.$window) {
    elementorCommon.elements.$window.on("elementor/nested-element-type-loaded", register);
  }
  jQuery(function () {
    if (registered) {
      return;
    }
    var attempts = 0;
    var interval = setInterval(function () {
      if (register() || ++attempts > 60) {
        clearInterval(interval);
      }
    }, 150);
  });
}();