<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Singular extends Base_Condition {

	public function get_key() {
		return 'is_singular';
	}

	public function check( $rule, $context ) {
		return is_singular();
	}
}
