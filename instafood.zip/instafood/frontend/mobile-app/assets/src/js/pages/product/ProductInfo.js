import ProductUtils from '../../utils/ProductUtils';
import LanguageUtils from '../../utils/LanguageUtils';

class ProductInfo {

    _ui;
    _product;

    constructor(ui) {
        this._ui = ui;
    }

    renderProduct(product) {
        this._product = product;
        this._ui.html('');
        this._render();
    }

    _render() {
        const product_variations = _.get(this._product, 'meta.product_variations', []);
        const price_display = _.get(this._product, 'meta.variation_min_price.price_display', '');
        const price_display_decoded = LanguageUtils.getInstance().decodeHtml(price_display);

        let priceInfo = '';
        if (product_variations.length > 1) {
            let priceInfoFrom =  LanguageUtils.getInstance().decodeHtml(LanguageUtils.getInstance().getLabel('product_variants_price_info'));
            priceInfoFrom = _.template(priceInfoFrom);
            const compiledPriceTemplate = priceInfoFrom({ 'productPrice' : price_display });
            priceInfo = LanguageUtils.getInstance().decodeHtml(compiledPriceTemplate);
        } else {
            priceInfo = `${price_display_decoded}`;
        }

        const template = `
        <div class="content">
            <div class="product_name">
                ${ProductUtils.getProductName(this._product)}
            </div>
            <div class="product_price_info">${priceInfo}</div>
        </div>
        <div class="product_description">${ProductUtils.getProductDescription(this._product)}</div>
        `;
        const contentUI = jQuery(template);
        contentUI.appendTo(this._ui);
    }
}
export default ProductInfo;