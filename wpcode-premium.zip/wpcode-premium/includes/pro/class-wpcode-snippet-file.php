<?php
/**
 * The on-disk format for file-managed snippets.
 *
 * A snippet file is a comment header of "Key: value" lines followed by the code. PHP, HTML and Universal
 * snippets use a docblock in a .php file with an ABSPATH guard; CSS, JS and SCSS use a slash-star block in a
 * file with their own extension. SCSS keeps its compiled CSS in a committed "<slug>.compiled.css" companion
 * because the plugin only compiles SCSS in the browser.
 *
 * build() renders a snippet to its file(s); parse() turns a file into the sanitized data array that
 * wpcode_get_snippet() accepts, or a WP_Error naming the problem. Neither writes to the database. parse()
 * needs wpcode()->auto_insert for the location registry and honours the wpcode_strip_script_tags_for_js
 * filter through WPCode_Snippet_Execute::normalize_code().
 *
 * @package WPCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WPCode_Snippet_File.
 */
class WPCode_Snippet_File {

	/**
	 * Code types executed as PHP; stored in .php files.
	 *
	 * @var string[]
	 */
	const PHP_TYPES = array( 'php', 'html', 'universal' );

	/**
	 * Code types served as assets; stored in files with their own extension.
	 *
	 * @var string[]
	 */
	const ASSET_TYPES = array( 'css', 'js', 'scss' );

	/**
	 * Suffix of the compiled CSS companion of an SCSS file.
	 *
	 * @var string
	 */
	const COMPANION_SUFFIX = '.compiled.css';

	/**
	 * The guard line every generated PHP file starts its code with.
	 *
	 * @var string
	 */
	const GUARD = "defined( 'ABSPATH' ) || exit;";

	/**
	 * How a "<?" inside HTML markup is written to a .php file so it prints instead of running.
	 *
	 * @var string
	 */
	const HTML_PHP_MARKER = "<?php echo '<?'; ?>";

	/**
	 * Longest slug written from a title; the rest of the file name is the extension or a suffix.
	 *
	 * @var int
	 */
	const MAX_SLUG_LENGTH = 100;

	/**
	 * Header labels mapped to internal keys.
	 *
	 * @var array
	 */
	const HEADERS = array(
		'Snippet Name'         => 'title',
		'Key'                  => 'key',
		'Type'                 => 'code_type',
		'Status'               => 'status',
		'Auto Insert'          => 'auto_insert',
		'Location'             => 'location',
		'Location Extra'       => 'location_extra',
		'Insert Number'        => 'insert_number',
		'Priority'             => 'priority',
		'Device'               => 'device_type',
		'Shortcode'            => 'custom_shortcode',
		'Shortcode Attributes' => 'shortcode_attributes',
		'Schedule Start'       => 'schedule_start',
		'Schedule End'         => 'schedule_end',
		'Tags'                 => 'tags',
		'Note'                 => 'note',
		'Conditional Logic'    => 'rules',
		'Load As File'         => 'load_as_file',
		'Compress'             => 'compress_output',
	);

	/**
	 * Registered auto-insert location slugs per code type, memoized per request.
	 *
	 * @var array
	 */
	protected static $locations = array();

	/**
	 * Whether a code type is stored as a file in the mode.
	 *
	 * @param string $code_type The code type.
	 *
	 * @return bool
	 */
	public static function is_file_type( $code_type ) {
		return in_array( $code_type, self::PHP_TYPES, true ) || in_array( $code_type, self::ASSET_TYPES, true );
	}

	/**
	 * The file extension for a code type.
	 *
	 * @param string $code_type The code type.
	 *
	 * @return string
	 */
	public static function extension_for( $code_type ) {
		return in_array( $code_type, self::PHP_TYPES, true ) ? 'php' : $code_type;
	}

	/**
	 * The compiled CSS companion file name for an SCSS file name.
	 *
	 * @param string $file The SCSS file name, for example theme.scss.
	 *
	 * @return string
	 */
	public static function companion_for( $file ) {
		return preg_replace( '/\.scss$/i', '', $file ) . self::COMPANION_SUFFIX;
	}

	/**
	 * Whether a file name in the snippets directory is a snippet source file.
	 * Excludes the index, dotfiles, unknown extensions and SCSS companions; case-insensitive because the
	 * directory may live on a case-insensitive file system.
	 *
	 * @param string $basename The file name without a directory.
	 *
	 * @return bool
	 */
	public static function is_snippet_file( $basename ) {
		$lower = strtolower( (string) $basename );
		if ( '' === $lower || '.' === $lower[0] || 'index.php' === $lower ) {
			return false;
		}
		if ( substr( $lower, - strlen( self::COMPANION_SUFFIX ) ) === self::COMPANION_SUFFIX ) {
			return false;
		}
		$extension = pathinfo( $lower, PATHINFO_EXTENSION );

		return in_array( $extension, array( 'php', 'css', 'js', 'scss' ), true );
	}

	/**
	 * Pick a file slug for a snippet that is unique among the given file names.
	 *
	 * @param WPCode_Snippet $snippet The snippet.
	 * @param string[]       $taken   File names already present in the directory.
	 *
	 * @return string The slug without extension.
	 */
	public static function slug_for( $snippet, $taken ) {
		$extension = self::extension_for( $snippet->get_code_type() );
		// ASCII only: sanitize_title() would percent-encode non-Latin titles into unreadable file names.
		$base = trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( remove_accents( (string) $snippet->get_title() ) ) ), '-' );
		$base = rtrim( substr( $base, 0, self::MAX_SLUG_LENGTH ), '-' );
		if ( '' === $base ) {
			$base = 'snippet-' . absint( $snippet->get_id() );
		}
		// "index" is the loader index; treat it as taken for every extension.
		$taken   = array_map( 'strtolower', (array) $taken );
		$taken[] = 'index.' . $extension;
		$slug    = $base;
		$next    = 2;
		while ( in_array( strtolower( $slug . '.' . $extension ), $taken, true ) ) {
			$slug = $base . '-' . $next;
			$next ++;
		}

		return $slug;
	}

	/**
	 * Make HTML markup safe to write after "?>" in a .php file: every "<?" is printed by PHP instead of
	 * opening a PHP block, so an HTML snippet can never run PHP from its file, as it never does from the editor.
	 *
	 * @param string $code The HTML.
	 *
	 * @return string
	 */
	public static function neutralize_php_in_html( $code ) {
		return str_replace( '<?', self::HTML_PHP_MARKER, (string) $code );
	}

	/**
	 * Render a snippet to its file contents.
	 *
	 * @param WPCode_Snippet $snippet The snippet.
	 * @param string         $file    The relative file name, for example disable-comments.php.
	 * @param string         $key     The snippet's file key, written as the Key header; empty to omit it.
	 *
	 * @return array|WP_Error Relative file name to contents (two entries for SCSS), or an error when a header cannot be written.
	 */
	public static function build( $snippet, $file, $key = '' ) {
		$code_type = $snippet->get_code_type();
		$headers   = self::headers_for( $snippet, $key );
		if ( is_wp_error( $headers ) ) {
			return $headers;
		}
		$lines = '';
		foreach ( $headers as $key => $value ) {
			$lines .= ' * ' . $key . ': ' . $value . "\n";
		}
		$code = rtrim( (string) $snippet->get_code(), "\r\n" );

		if ( in_array( $code_type, self::PHP_TYPES, true ) ) {
			$contents  = "<?php\n/**\n" . $lines . " */\n" . self::GUARD . "\n";
			$contents .= 'php' === $code_type ? "\n" : "?>\n";
			if ( 'html' === $code_type ) {
				$code = self::neutralize_php_in_html( $code );
			}
		} else {
			$contents = "/*\n" . $lines . " */\n\n";
		}
		$contents .= $code . "\n";

		$files = array( $file => $contents );
		if ( 'scss' === $code_type ) {
			$files[ self::companion_for( $file ) ] = rtrim( (string) $snippet->get_compiled_code(), "\r\n" ) . "\n";
		}

		return $files;
	}

	/**
	 * Parse a snippet file into sanitized snippet data.
	 *
	 * @param string $path Absolute path of the file.
	 *
	 * @return array|WP_Error Keys: file, key, code_type, active, data, compiled_code, warnings.
	 */
	public static function parse( $path ) {
		$file = basename( $path );
		if ( ! self::is_snippet_file( $file ) ) {
			return new WP_Error( 'invalid_file', __( 'Not a snippet file.', 'wpcode-premium' ) );
		}
		$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $raw ) {
			return new WP_Error( 'unreadable', __( 'The file could not be read.', 'wpcode-premium' ) );
		}
		$raw       = self::normalize( $raw );
		$extension = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		$is_php    = 'php' === $extension;
		$pattern   = $is_php ? '#\A<\?php\s*/\*\*?[ \t]*\n(.*?)\n[ \t]*\*/[ \t]*\n#s' : '#\A\s*/\*\*?[ \t]*\n(.*?)\n[ \t]*\*/[ \t]*\n#s';

		if ( ! preg_match( $pattern, $raw, $match ) ) {
			return new WP_Error( 'no_header', __( 'The file has no WPCode header comment.', 'wpcode-premium' ) );
		}

		$warnings = array();
		$headers  = self::parse_header_lines( $match[1], $warnings );
		$rest     = substr( $raw, strlen( $match[0] ) );

		// Type: from the header for .php files, from the extension otherwise.
		if ( $is_php ) {
			$type = isset( $headers['code_type'] ) ? sanitize_key( $headers['code_type'] ) : 'php';
			if ( ! in_array( $type, self::PHP_TYPES, true ) ) {
				/* translators: %s: the Type header value. */
				return new WP_Error( 'invalid_type', sprintf( __( 'Unknown type "%s" for a .php file. Use php, html or universal.', 'wpcode-premium' ), $type ) );
			}
		} else {
			$type = $extension;
		}

		$code = self::strip_prologue( $rest, $type, $is_php, $warnings );
		if ( is_wp_error( $code ) ) {
			return $code;
		}

		// The Key header keeps a renamed file the same snippet; lowercase letters, digits, dashes and underscores.
		$key = isset( $headers['key'] ) ? trim( $headers['key'] ) : '';
		if ( '' !== $key && ( sanitize_key( $key ) !== $key || strlen( $key ) > 64 ) ) {
			/* translators: %s: the Key header value. */
			return new WP_Error( 'invalid_key', sprintf( __( 'Invalid Key "%s". Use up to 64 lowercase letters, digits, dashes and underscores.', 'wpcode-premium' ), $key ) );
		}

		$slug      = preg_replace( '/\.[a-z]+$/i', '', $file );
		$validated = self::validate_headers( $headers, $type, $slug, $warnings );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$code = WPCode_Snippet_Execute::normalize_code( $code, $type );

		if ( 'html' === $type ) {
			$code = self::restore_php_in_html( $code );
			if ( is_wp_error( $code ) ) {
				return $code;
			}
		}

		if ( WPCode_Snippet_Execute::is_code_not_allowed( $code ) ) {
			return new WP_Error( 'restricted_code', __( 'The file contains code WPCode does not allow.', 'wpcode-premium' ) );
		}

		$compiled_code = null;
		if ( 'scss' === $type ) {
			$companion = dirname( $path ) . '/' . self::companion_for( $file );
			if ( ! file_exists( $companion ) ) {
				/* translators: %s: the companion file name. */
				return new WP_Error( 'missing_companion', sprintf( __( 'SCSS needs its compiled CSS next to it as %s.', 'wpcode-premium' ), self::companion_for( $file ) ) );
			}
			$compiled_code = self::normalize( (string) file_get_contents( $companion ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( "\n" === substr( $compiled_code, - 1 ) ) {
				$compiled_code = substr( $compiled_code, 0, - 1 );
			}
		}

		$data         = $validated['data'];
		$data['code'] = $code;

		return array(
			'file'          => $file,
			'key'           => $key,
			'code_type'     => $type,
			'active'        => $validated['active'],
			'data'          => $data,
			'compiled_code' => $compiled_code,
			'warnings'      => $warnings,
		);
	}

	/**
	 * Registered auto-insert location slugs a code type may use, as the editor offers them.
	 *
	 * @param string $code_type The code type.
	 *
	 * @return string[]
	 */
	public static function registered_locations( $code_type ) {
		if ( ! isset( self::$locations[ $code_type ] ) ) {
			$locations = array();
			foreach ( wpcode()->auto_insert->get_types() as $type ) {
				if ( 'all' !== $type->code_type && $type->code_type !== $code_type ) {
					continue;
				}
				$locations = array_merge( $locations, array_keys( (array) $type->get_locations() ) );
			}
			self::$locations[ $code_type ] = array_values( array_unique( $locations ) );
		}

		return self::$locations[ $code_type ];
	}

	/**
	 * Collect the header values for a snippet, omitting defaults and empty values.
	 *
	 * @param WPCode_Snippet $snippet The snippet.
	 * @param string         $key     The snippet's file key; empty to omit it.
	 *
	 * @return array|WP_Error Header label to value.
	 */
	protected static function headers_for( $snippet, $key = '' ) {
		$code_type = $snippet->get_code_type();
		$headers   = array(
			'Snippet Name' => self::one_line( $snippet->get_title() ),
		);
		if ( '' !== $key ) {
			$headers['Key'] = $key;
		}
		if ( in_array( $code_type, self::PHP_TYPES, true ) ) {
			$headers['Type'] = $code_type;
		}
		if ( ! $snippet->is_active() ) {
			$headers['Status'] = 'inactive';
		}
		if ( 1 !== (int) $snippet->get_auto_insert() ) {
			$headers['Auto Insert'] = 'no';
		}
		$location = (string) $snippet->get_location();
		if ( '' !== $location ) {
			$headers['Location'] = $location;
		}
		$location_extra = $snippet->get_location_extra();
		if ( is_string( $location_extra ) && '' !== $location_extra ) {
			$headers['Location Extra'] = self::one_line( $location_extra );
		}
		if ( (int) $snippet->get_auto_insert_number() > 1 ) {
			$headers['Insert Number'] = (int) $snippet->get_auto_insert_number();
		}
		if ( 10 !== (int) $snippet->get_priority() ) {
			$headers['Priority'] = (int) $snippet->get_priority();
		}
		$device = (string) $snippet->get_device_type();
		if ( '' !== $device && 'any' !== $device ) {
			$headers['Device'] = $device;
		}
		$shortcode = $snippet->get_custom_shortcode();
		if ( ! empty( $shortcode ) ) {
			$headers['Shortcode'] = $shortcode;
		}
		$attributes = $snippet->get_shortcode_attributes();
		if ( ! empty( $attributes ) ) {
			$headers['Shortcode Attributes'] = implode( ', ', $attributes );
		}
		$schedule = $snippet->get_schedule();
		if ( ! empty( $schedule['start'] ) ) {
			$headers['Schedule Start'] = self::one_line( $schedule['start'] );
		}
		if ( ! empty( $schedule['end'] ) ) {
			$headers['Schedule End'] = self::one_line( $schedule['end'] );
		}
		$tags = $snippet->get_tags();
		if ( ! empty( $tags ) ) {
			$headers['Tags'] = implode( ', ', $tags );
		}
		$note = (string) $snippet->get_note();
		if ( '' !== trim( $note ) ) {
			$headers['Note'] = self::one_line( $note );
		}
		if ( $snippet->conditional_rules_enabled() ) {
			$rules = $snippet->get_conditional_rules();
			if ( ! empty( $rules ) ) {
				$encoded = wp_json_encode( $rules );
				if ( false === $encoded ) {
					return new WP_Error( 'rules_not_encodable', __( 'The conditional logic rules cannot be written as JSON.', 'wpcode-premium' ) );
				}
				$headers['Conditional Logic'] = $encoded;
			}
		}
		if ( in_array( $code_type, self::ASSET_TYPES, true ) ) {
			if ( ! $snippet->get_load_as_file() ) {
				$headers['Load As File'] = 'no';
			}
			if ( $snippet->maybe_compress_output() ) {
				$headers['Compress'] = 'yes';
			}
		}

		return $headers;
	}

	/**
	 * Make a value safe for a single header line: backslashes doubled, newlines as "\n", no comment terminator.
	 *
	 * @param string $value The value.
	 *
	 * @return string
	 */
	protected static function one_line( $value ) {
		$value = str_replace( '\\', '\\\\', (string) $value );
		$value = str_replace( array( "\r\n", "\r", "\n" ), '\n', $value );

		return str_replace( '*/', '* /', $value );
	}

	/**
	 * Reverse one_line(): "\n" becomes a newline and "\\" a backslash; any other sequence is left alone.
	 *
	 * @param string $value The header value.
	 *
	 * @return string
	 */
	protected static function decode_line( $value ) {
		return preg_replace_callback(
			'/\\\\(\\\\|n)/',
			function ( $match ) {
				return 'n' === $match[1] ? "\n" : '\\';
			},
			(string) $value
		);
	}

	/**
	 * Strip a UTF-8 BOM and normalize line endings.
	 *
	 * @param string $raw The file contents.
	 *
	 * @return string
	 */
	protected static function normalize( $raw ) {
		if ( "\xEF\xBB\xBF" === substr( $raw, 0, 3 ) ) {
			$raw = substr( $raw, 3 );
		}

		return str_replace( array( "\r\n", "\r" ), "\n", $raw );
	}

	/**
	 * Split the header block into internal keys. Keys are matched without regard to case.
	 *
	 * @param string $block    The text between the comment delimiters.
	 * @param array  $warnings Collected warnings, by reference.
	 *
	 * @return array
	 */
	protected static function parse_header_lines( $block, &$warnings ) {
		$lookup = array_change_key_case( self::HEADERS, CASE_LOWER );
		$headers = array();
		foreach ( explode( "\n", $block ) as $line ) {
			$line = preg_replace( '/^\s*\*?\s*/', '', $line );
			if ( '' === trim( $line ) ) {
				continue;
			}
			if ( ! preg_match( '/^([A-Za-z][A-Za-z ]*?)\s*:\s?(.*)$/', $line, $match ) ) {
				/* translators: %s: the header line. */
				$warnings[] = sprintf( __( 'Ignored header line "%s".', 'wpcode-premium' ), trim( $line ) );
				continue;
			}
			$key = strtolower( trim( $match[1] ) );
			if ( ! isset( $lookup[ $key ] ) ) {
				/* translators: %s: the header name. */
				$warnings[] = sprintf( __( 'Unknown header "%s".', 'wpcode-premium' ), trim( $match[1] ) );
				continue;
			}
			$headers[ $lookup[ $key ] ] = rtrim( $match[2] );
		}

		return $headers;
	}

	/**
	 * Remove the prologue after the header (guard line, PHP closing tag, one blank line) and the final newline.
	 *
	 * @param string $rest     Everything after the header comment.
	 * @param string $type     The code type.
	 * @param bool   $is_php   Whether the file is a .php file.
	 * @param array  $warnings Collected warnings, by reference.
	 *
	 * @return string|WP_Error
	 */
	protected static function strip_prologue( $rest, $type, $is_php, &$warnings ) {
		$code = $rest;
		if ( $is_php ) {
			// The canonical guard or a common equivalent: "|| exit;", "or die();" or an if block, after optional blank lines.
			$defined       = 'defined\s*\(\s*([\'"])ABSPATH\1\s*\)';
			$stop          = '(?:exit|die)\s*(?:\(\s*\))?\s*;';
			$guard_pattern = '#\A\s*(?:' . $defined . '\s*(?:\|\||or)\s*' . $stop . '|if\s*\(\s*!\s*' . str_replace( '\\1', '\\2', $defined ) . '\s*\)\s*(?:\{\s*' . $stop . '\s*\}|' . $stop . '))[ \t]*\n#i';
			if ( preg_match( $guard_pattern, $code ) ) {
				$code = preg_replace( $guard_pattern, '', $code, 1 );
			} else {
				// The directory sits under wp-content, so a file without the guard would run on a direct request.
				return new WP_Error(
					'missing_guard',
					/* translators: %s: the required guard line. */
					sprintf( __( 'A .php snippet file must start its code with an ABSPATH guard such as "%s", so a direct request to the file does not run it.', 'wpcode-premium' ), self::GUARD )
				);
			}
			if ( 'php' === $type ) {
				if ( preg_match( '#\A\s*\?>#', $code ) ) {
					return new WP_Error( 'invalid_prologue', __( 'A PHP snippet file must not close PHP with ?> after the header. If this is an HTML snippet, add a "Type: html" header.', 'wpcode-premium' ) );
				}
				$code = preg_replace( "#\A\n#", '', $code, 1 );
			} else {
				if ( ! preg_match( '#\A[ \t]*\?>\n?#', $code ) ) {
					return new WP_Error( 'invalid_prologue', __( 'An HTML or Universal snippet file must close PHP with ?> on the line after the header.', 'wpcode-premium' ) );
				}
				$code = preg_replace( '#\A[ \t]*\?>\n?#', '', $code, 1 );
			}
		} else {
			$code = preg_replace( "#\A\n#", '', $code, 1 );
		}
		if ( "\n" === substr( $code, - 1 ) ) {
			$code = substr( $code, 0, - 1 );
		}

		return $code;
	}

	/**
	 * Undo neutralize_php_in_html() and refuse any other "<?" in HTML markup.
	 *
	 * @param string $code The HTML read from the file.
	 *
	 * @return string|WP_Error
	 */
	protected static function restore_php_in_html( $code ) {
		$placeholder = "\0wpcode-lt-q\0";
		$code        = str_replace( self::HTML_PHP_MARKER, $placeholder, $code );
		if ( false !== strpos( $code, '<?' ) ) {
			return new WP_Error( 'php_in_html', __( 'An HTML snippet cannot contain PHP. Use a Universal snippet to mix HTML and PHP.', 'wpcode-premium' ) );
		}

		return str_replace( $placeholder, '<?', $code );
	}

	/**
	 * Read a yes/no header.
	 *
	 * @param string $value The raw value.
	 *
	 * @return bool|null True, false, or null when the value is not recognized.
	 */
	protected static function parse_bool( $value ) {
		$value = strtolower( trim( (string) $value ) );
		if ( in_array( $value, array( 'yes', 'true', 'on', '1' ), true ) ) {
			return true;
		}
		if ( in_array( $value, array( 'no', 'false', 'off', '0' ), true ) ) {
			return false;
		}

		return null;
	}

	/**
	 * Validate and sanitize the header values into snippet data.
	 *
	 * @param array  $headers  Internal key to raw value.
	 * @param string $type     The code type.
	 * @param string $slug     The file slug, used for a fallback title.
	 * @param array  $warnings Collected warnings, by reference.
	 *
	 * @return array|WP_Error array( 'active' => bool, 'data' => array ).
	 */
	protected static function validate_headers( $headers, $type, $slug, &$warnings ) {
		$title = isset( $headers['title'] ) ? sanitize_text_field( self::decode_line( $headers['title'] ) ) : '';
		if ( '' === $title ) {
			$title      = ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );
			$warnings[] = __( 'No Snippet Name header; the file name is used as the title.', 'wpcode-premium' );
		}

		$active = true;
		if ( isset( $headers['status'] ) ) {
			$status = strtolower( trim( $headers['status'] ) );
			if ( in_array( $status, array( 'active', 'enabled', 'on', 'published', 'publish' ), true ) ) {
				$active = true;
			} elseif ( in_array( $status, array( 'inactive', 'disabled', 'off', 'draft' ), true ) ) {
				$active = false;
			} else {
				/* translators: %s: the Status header value. */
				return new WP_Error( 'invalid_status', sprintf( __( 'Unknown status "%s". Use active or inactive.', 'wpcode-premium' ), $status ) );
			}
		}

		$auto_insert = 1;
		if ( isset( $headers['auto_insert'] ) ) {
			$parsed = self::parse_bool( $headers['auto_insert'] );
			if ( null === $parsed ) {
				/* translators: %s: the Auto Insert header value. */
				return new WP_Error( 'invalid_auto_insert', sprintf( __( 'Unknown Auto Insert value "%s". Use yes or no.', 'wpcode-premium' ), trim( $headers['auto_insert'] ) ) );
			}
			$auto_insert = $parsed ? 1 : 0;
		}

		$location = isset( $headers['location'] ) ? sanitize_key( $headers['location'] ) : '';
		if ( 1 === $auto_insert && '' === $location ) {
			$location = 'php' === $type ? 'everywhere' : 'site_wide_header';
		}
		if ( 1 === $auto_insert && ! in_array( $location, self::registered_locations( $type ), true ) ) {
			/* translators: 1: the Location header value, 2: the code type. */
			return new WP_Error( 'invalid_location', sprintf( __( 'Unknown location "%1$s" for a %2$s snippet.', 'wpcode-premium' ), $location, $type ) );
		}
		if ( 0 === $auto_insert ) {
			$location = '';
		}

		$device = isset( $headers['device_type'] ) ? sanitize_key( $headers['device_type'] ) : 'any';
		if ( ! in_array( $device, array( 'any', 'desktop', 'mobile' ), true ) ) {
			/* translators: %s: the Device header value. */
			return new WP_Error( 'invalid_device', sprintf( __( 'Unknown device "%s". Use any, desktop or mobile.', 'wpcode-premium' ), $device ) );
		}

		$rules     = array();
		$use_rules = false;
		if ( isset( $headers['rules'] ) && '' !== trim( $headers['rules'] ) ) {
			$rules = json_decode( $headers['rules'], true );
			if ( ! is_array( $rules ) || ! isset( $rules['show'], $rules['groups'] ) || ! in_array( $rules['show'], array( 'show', 'hide' ), true ) || ! is_array( $rules['groups'] ) ) {
				return new WP_Error( 'invalid_rules', __( 'Conditional Logic must be a JSON object with "show" and "groups".', 'wpcode-premium' ) );
			}
			$use_rules = true;
		}

		$tags = array();
		if ( isset( $headers['tags'] ) ) {
			foreach ( explode( ',', $headers['tags'] ) as $tag ) {
				$tag = sanitize_text_field( trim( $tag ) );
				if ( '' !== $tag ) {
					$tags[] = $tag;
				}
			}
		}

		$attributes = array();
		if ( isset( $headers['shortcode_attributes'] ) ) {
			foreach ( explode( ',', $headers['shortcode_attributes'] ) as $attribute ) {
				$attribute = sanitize_key( trim( $attribute ) );
				if ( '' !== $attribute ) {
					$attributes[] = $attribute;
				}
			}
		}

		$data = array(
			'title'                => $title,
			'code_type'            => $type,
			'location'             => $location,
			'auto_insert'          => $auto_insert,
			'insert_number'        => isset( $headers['insert_number'] ) ? max( 1, absint( $headers['insert_number'] ) ) : 1,
			'priority'             => isset( $headers['priority'] ) ? intval( $headers['priority'] ) : 10,
			'use_rules'            => $use_rules,
			'rules'                => $rules,
			'tags'                 => $tags,
			'note'                 => isset( $headers['note'] ) ? wp_kses_post( self::decode_line( $headers['note'] ) ) : '',
			'location_extra'       => isset( $headers['location_extra'] ) ? sanitize_text_field( self::decode_line( $headers['location_extra'] ) ) : '',
			'device_type'          => $device,
			'custom_shortcode'     => isset( $headers['custom_shortcode'] ) ? sanitize_key( $headers['custom_shortcode'] ) : '',
			'shortcode_attributes' => $attributes,
			'schedule'             => array(
				'start' => isset( $headers['schedule_start'] ) ? sanitize_text_field( self::decode_line( $headers['schedule_start'] ) ) : '',
				'end'   => isset( $headers['schedule_end'] ) ? sanitize_text_field( self::decode_line( $headers['schedule_end'] ) ) : '',
			),
		);

		if ( in_array( $type, self::ASSET_TYPES, true ) ) {
			$data['load_as_file'] = true;
			if ( isset( $headers['load_as_file'] ) ) {
				$parsed = self::parse_bool( $headers['load_as_file'] );
				if ( null === $parsed ) {
					/* translators: %s: the Load As File header value. */
					return new WP_Error( 'invalid_load_as_file', sprintf( __( 'Unknown Load As File value "%s". Use yes or no.', 'wpcode-premium' ), trim( $headers['load_as_file'] ) ) );
				}
				$data['load_as_file'] = $parsed;
			}
			if ( isset( $headers['compress_output'] ) ) {
				$parsed = self::parse_bool( $headers['compress_output'] );
				if ( null === $parsed ) {
					/* translators: %s: the Compress header value. */
					return new WP_Error( 'invalid_compress', sprintf( __( 'Unknown Compress value "%s". Use yes or no.', 'wpcode-premium' ), trim( $headers['compress_output'] ) ) );
				}
				if ( $parsed ) {
					$data['compress_output'] = true;
				}
			}
		}

		return array(
			'active' => $active,
			'data'   => $data,
		);
	}
}
