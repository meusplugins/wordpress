# Wow Herd Effects Pro

[Plugin page](https://wow-estore.com/item/wow-herd-effects-pro/)


### Changelog

#### = Version 5.0 =
* **Added:** **Icon Types:** Support for emoji, custom icon classes, and the option to disable icons.
* **Added:** **Title Variable Support:** Titles now support dynamic variables.
* **Added:** **Content Padding:** Option to set padding for the notification content.
* **Added:** **Close Button:** Added offset location option and hover color.
* **Added:** **Multi Display Rules:** Enhanced display control with shortcodes, page types, post categories/tags, author pages, and date archives.
* **Added:** **Hide Based on Browser:** Option to hide notifications on selected browsers.
* **Added:** **Multi Scheduling:** Schedule notifications for specific days, times, and dates to support temporary events or campaigns.
* **Added:** **Resource Optimization:** Option to hide notifications on mobile or desktop devices to optimize for different screen sizes.
* **Added:** **Language Attribute:** Custom language attribute support for multilingual sites.
* **Added:** **Geotargeting:** Display notifications based on the country location of website visitors.
* **Added:** **Referrer URL Targeting:** Target notifications to users arriving from specific referring domains, useful for partner campaigns.
* **Added:** **URL Parameter Targeting:** Show notifications only if the URL contains a designated parameter.
* **Added:** **HTML Editor:** Open notification content in the HTML editor.
* **Added:** **Tag and Link Options:** New options for adding tags and links.
* **Improvement:** **Refreshed Interface:** Revamped dashboard page style for a more intuitive and user-friendly experience.
* **Improvement:** **Code Optimization:** Rewritten jQuery code in vanilla JavaScript for improved performance.
* **Updated:** **Font Awesome:** Updated to version 6.5 for access to the latest icons.
* **Fixed:** **Notification Counters:** Issues with notification counters have been resolved.

#### = Version 4.2.2 =
* Fixed: creating the databased
* Fixed: dynamic property for PHP 8.2 


#### = Version 4.2.1 =
* Fixed: When a user closes any of the notifications, all notifications will cease.
* Fixed: When choose to display a close button and include a URL to direct it to a specific location, clicking the close button will consistently navigate to the provided URL.
* Fixed: Leaving the option "stop the notification after this number of times on the same page" empty will result in the notification continuously displaying.

#### = Version 4.2 =

* Added: Export/Import function
* Changed: support page
* Fixed: minor bugs

#### = Version 4.1.2 =

* Fixed: show in taxonomies

#### = Version 4.1.1 =

* FIXED bug with color-picker-alpha
* UPDATED Font Awesome Icons to version 5.14

#### = Version 4.1 =

* CHANGED optimized scripts
* FIXED Link on notification

#### = Version 4.0.1 =

* FIXED Custom icon option

#### = Version 4.0 =

* Added: Live preview
* Added: notification schedule options
* Added: test mode option
* Added: Unit for location
* Updated: Admin style
* Update: Font Awesome Icon to v. 5.12

#### = Version 3.2 =

* Fixed: display notifications

#### = Version 3.1.1 =

* Added: support old shortcode

#### = Version 3.1 =

* Fixed: Saving parameters

#### = Version 3.0 =

* Added: option 'Don't show on screens more'
* Added: option for disabling FontAwesome 5 from front-end
* Added: Border style options: border style
* Added: Shadow style options
* Added: Content style options
* Added: Title style options
* Added: Icon style options
* Added: Close button size option
* Changed: Admin Style
* Optimized: Styles and Scripts (minification and response time reduction)
* Fixed: Control on the devices

#### = Version 2.3.2 =

* Fixed: deleted tag 'p' from notice

#### = Version 2.3 =

* Updated: Font Awesome to version 5
* Added: 2 variables
* Added: Close Button
* Added: Title color
* Added: function 'Don't show after click' on link
* Added: Editor for notification content
* Fixed: position 'Bottom'

#### = Version 2.2.4 =

* Added: file pot for translation
* Fixed: class conflict with animated

#### = Version 2.2.3 =

* Fixed: insert more then 1 notification

#### = Version 2.2.2 =

* Fixed: color picker alpha for Wordpress 4.9
* Version 2.2.1
* Fixed: main class.

#### = Version 2.2 =

* Added: Support for display on taxonomy pages.
* Added: Show menu depending on user's role.
* Added: Support page.

#### = Version 2.1 =

* Added: the Third variable

#### = Version 2.0 =

* Changed: structure
* Changed: admin style

#### = Version 1.4.1 =

* Fixed: Location
* Fixed: Show for users

#### = Version 1.4 =

* Added: The time interval in which the notification will be displayed;
* Added: Display notification in posts of category with certain IDs;
* Added: Number of notifications per page for one visitor;

#### = Version 1.3 =

* Add: Notification link;
* Updated: Icon (FontAwesome 4.7);
* Optimized: database;

#### = Version 1.2 =

* Add: Display for different types of users
* Add: Depending on the site language
* Add: Different animation effects
* Change: Admin panel style

#### = Version 1.1 =

* Fix: Script of show the notification.
* Fix: Replaced deprecated php functions 'split'.
* Fix: Can enter 'Name' and 'City' in new line.
* Fix: Verifying access to the folder 'asset'.
* Fix: Support and Facebook link.
* Fix: Optimized code.

## License

Distributed under the MIT License. See `LICENSE` for more information.

## Contact

Dmytro Lobov - givememoney1982@gmail.com

Plugin URL: [https://wow-estore.com/item/wow-herd-effects-pro/](https://wow-estore.com/item/wow-herd-effects-pro/)