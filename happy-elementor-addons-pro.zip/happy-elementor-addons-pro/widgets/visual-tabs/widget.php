<?php

/**
 * Visual Tabs widget class
 *
 * Scroll-driven two-column service list implemented with native browser APIs
 * only (requestAnimationFrame, CSS transitions, CSS custom properties, the
 * Web Animations API and IntersectionObserver) — GSAP is never required.
 *
 * Scroll-driven two-column service list.
 * Left titles fade to full opacity as they hit mid-viewport,
 * right media/content columns fade in on the same trigger.
 *
 * @package Happy_Addons_Pro
 */

namespace Happy_Addons_Pro\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Modules\NestedElements\Base\Widget_Nested_Base;
use Elementor\Modules\NestedElements\Controls\Control_Nested_Repeater;
use Elementor\Repeater;
use Elementor\Utils;


if (! defined('ABSPATH')) {
	exit;
}

if (! class_exists('Elementor\Modules\NestedElements\Base\Widget_Nested_Base')) {
	return;
}

class Visual_Tabs extends Widget_Nested_Base {

	private $service_item_settings = [];

	public static function register_editor_styles() {
		$handle = 'ha-v-tabs-editor-panel-styles';
		wp_register_style($handle, false);
		wp_enqueue_style($handle);
		wp_add_inline_style($handle, '
			.elementor-control-prefix_align_items_before .elementor-choices label i,
			.elementor-control-prefix_align_items_after .elementor-choices label i {
				transform: rotate(calc(var(--rotation-direction, 1) * 90deg));
			}
		');
	}

	public function get_name(): string {
		return 'ha-visual-tabs';
	}

	public function get_title(): string {
		return esc_html__('Visual Tabs', 'happy-addons-pro');
	}

	public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/visual-tabs/';
    }

	public function get_icon(): string {
		return 'hm hm-cta';
	}

	public function get_keywords(): array {
		return ['nested', 'service', 'list', 'scroll', 'creative', 'vtabs'];
	}

	public function get_categories(): array {
		return ['happy_addons_pro_category'];
	}

	public function get_style_depends(): array {
		return ['happy-visual-tabs'];
	}

	public function get_script_depends(): array {
		return ['happy-elementor-addons-visual-tabs'];
	}

	protected function get_default_children_title() {
		return esc_html__('Service #%d', 'happy-addons-pro');
	}

	protected function get_default_repeater_title_setting_key(): string {
		return 'service_title';
	}

	protected function get_default_children_elements(): array {
		return [
			$this->item_content_container(1),
			$this->item_content_container(2),
			$this->item_content_container(3),
			$this->item_content_container(4),
			$this->item_content_container(5),
		];
	}

	protected function item_content_container(int $index) {
		return [
			'elType'   => 'container',
			'settings' => [
				'_title'        => sprintf(
					/* translators: %d: Service index. */
					esc_html__('Service #%d', 'happy-addons-pro'),
					$index
				),
				'content_width' => 'full',
			],
		];
	}

	protected function get_default_children_placeholder_selector(): string {
		return '.ha-v-tabs-list';
	}

	protected function get_default_children_container_placeholder_selector(): string {
		return '.ha-v-tabs-item';
	}

	protected function get_html_wrapper_class(): string {
		return 'elementor-widget-ha-visual-tabs';
	}

	protected function get_initial_config(): array {
		return array_merge(parent::get_initial_config(), [
			'support_improved_repeaters' => true,
			'target_container'           => ['.ha-v-tabs-list'],
			'node'                       => 'div',
			'is_interlaced'              => true,
		]);
	}

	protected function register_controls(): void {
		$this->register_items_controls();
		$this->register_layout_controls();
		$this->register_content_animation_controls();
		$this->register_scroll_controls();
		$this->register_list_title_style_controls();
		$this->register_prefix_style_controls();
	}

	protected function register_items_controls(): void {

		$this->start_controls_section(
			'section_items',
			[
				'label' => esc_html__('Items', 'happy-addons-pro'),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'service_title',
			[
				'label'       => esc_html__('Title', 'happy-addons-pro'),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__('Service Title', 'happy-addons-pro'),
				'placeholder' => esc_html__('Service Title', 'happy-addons-pro'),
				'label_block' => true,
				'dynamic'     => ['active' => true],
			]
		);

		$repeater->add_control(
			'prefix_type',
			[
				'label'   => esc_html__('Prefix / Suffix Type', 'happy-addons-pro'),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'text',
				'options' => [
					'text' => [
						'title' => esc_html__('Text', 'happy-addons-pro'),
						'icon'  => 'eicon-text',
					],
					'icon' => [
						'title' => esc_html__('Icon', 'happy-addons-pro'),
						'icon'  => 'eicon-star',
					],
				],
				'toggle'  => false,
				'frontend_available' => true,
			]
		);

		$repeater->add_control(
			'prefix_text',
			[
				'label'       => esc_html__('Prefix / Suffix Text', 'happy-addons-pro'),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => esc_html__('e.g. 001', 'happy-addons-pro'),
				'label_block' => true,
				'dynamic'     => ['active' => true],
				'condition'   => [
					'prefix_type' => 'text',
				],
				'render_type' => 'ui',
			]
		);

		$repeater->add_control(
			'prefix_icon',
			[
				'label'       => esc_html__('Prefix / Suffix Icon', 'happy-addons-pro'),
				'type'        => Controls_Manager::ICONS,
				'skin'        => 'inline',
				'label_block' => false,
				'default'     => [
					'value'   => '',
					'library' => 'fa-solid',
				],
				'condition'   => [
					'prefix_type' => 'icon',
				],
			]
		);

		$repeater->add_control(
			'element_css_id',
			[
				'label'          => esc_html__('CSS ID', 'happy-addons-pro'),
				'type'           => Controls_Manager::TEXT,
				'default'        => '',
				'dynamic'        => ['active' => true],
				'title'          => esc_html__('Add your custom id WITHOUT the Pound key. e.g: my-id', 'happy-addons-pro'),
				'style_transfer' => false,
				'classes'        => 'elementor-control-direction-ltr',
			]
		);

		$this->add_control(
			'items',
			[
				'type'               => Control_Nested_Repeater::CONTROL_TYPE,
				'fields'             => $repeater->get_controls(),
				'default'            => [
					['service_title' => esc_html__('Service #1', 'happy-addons-pro')],
					['service_title' => esc_html__('Service #2', 'happy-addons-pro')],
					['service_title' => esc_html__('Service #3', 'happy-addons-pro')],
					['service_title' => esc_html__('Service #4', 'happy-addons-pro')],
					['service_title' => esc_html__('Service #5', 'happy-addons-pro')],
				],
				'frontend_available' => true,
				'title_field'        => '{{{ service_title }}}',
				'button_text'        => esc_html__('Add Service', 'happy-addons-pro'),
			]
		);



		$this->add_control(
			'show_number',
			[
				'label'        => esc_html__('Show Prefix / Suffix', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'    => esc_html__('No', 'happy-addons-pro'),
				'default'      => 'yes',
				'separator'    => 'before',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'prefix_position',
			[
				'label'   => esc_html__('Prefix / Suffix Position', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'above'  => esc_html__('Above Title', 'happy-addons-pro'),
					'below'  => esc_html__('Below Title', 'happy-addons-pro'),
					'before' => esc_html__('Before Title', 'happy-addons-pro'),
					'after'  => esc_html__('After Title', 'happy-addons-pro'),
				],
				'default' => 'before',
				'description' => esc_html__('Above/Below = stacked on separate lines. Before/After = inline on the same line.', 'happy-addons-pro'),
				'condition' => [
					'show_number' => 'yes',
				],
				'frontend_available' => true,
				'render_type' => 'ui',
			]
		);

		$this->add_control(
			'prefix_align_items_before',
			[
				'label'   => esc_html__('Prefix / Suffix Alignment', 'happy-addons-pro'),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__('Start', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__('End', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-end-h',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ha-v-tabs-title-wrap[data-prefix-position="before"]' => 'align-items: {{VALUE}};',
				],
				'condition' => [
					'prefix_position' => 'before',
					'show_number'     => 'yes',
				],
				'render_type' => 'ui',

			]
		);

		$this->add_control(
			'prefix_align_items_after',
			[
				'label'   => esc_html__('Prefix / Suffix Alignment', 'happy-addons-pro'),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__('Start', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__('End', 'happy-addons-pro'),
						'icon'  => 'eicon-flex eicon-justify-end-h',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ha-v-tabs-title-wrap[data-prefix-position="after"]' => 'align-items: {{VALUE}};',
				],
				'condition' => [
					'prefix_position' => 'after',
					'show_number'     => 'yes',
				],
				'render_type' => 'ui',
			]
		);

		$this->add_control(
			'service_title_tag',
			[
				'label'   => esc_html__('Title HTML Tag', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
					'p'    => 'p',
				],
				'default' => 'h2',
			]
		);

		$this->end_controls_section();
	}

	protected function register_layout_controls(): void {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__('Layout', 'happy-addons-pro'),
			]
		);

		$this->add_control(
			'title_position',
			[
				'label'        => esc_html__('Items Position', 'happy-addons-pro'),
				'type'         => Controls_Manager::CHOOSE,
				'default'      => 'left',
				'options'      => [
					'left' => [
						'title' => esc_html__('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'frontend_available' => true,
			]
		);

	$this->add_control(
		'vertical_item_position',
		[
			'label'   => esc_html__('Vertical Items Position', 'happy-addons-pro'),
			'type'    => Controls_Manager::CHOOSE,
			'default' => 'start',
			'toggle'  => false,
			'options' => [
				'start' => [
					'title' => esc_html__('Top', 'happy-addons-pro'),
					'icon'  => 'eicon-v-align-top',
				],
				'center' => [
					'title' => esc_html__('Center', 'happy-addons-pro'),
					'icon'  => 'eicon-v-align-middle',
				],
				'end' => [
					'title' => esc_html__('Bottom', 'happy-addons-pro'),
					'icon'  => 'eicon-v-align-bottom',
				],
			],
			'selectors' => [
				'{{WRAPPER}}' => '--ha-v-tabs-items-v-align: {{VALUE}};',
			],
			'render_type' => 'ui',
		]
	);

	

		$this->add_responsive_control(
			'title_col_width',
			[
				'label'      => esc_html__('Items Column Width (%)', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['%'],
				'range'      => [
					'%' => ['min' => 10, 'max' => 90],
				],
				'default'    => [
					'unit' => '%',
					'size' => 40,
				],
				'tablet_default' => [
					'unit' => '%',
					'size' => 40,
				],
				'mobile_default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-v-tabs-title-col-width: {{SIZE}}{{UNIT}};',
				],
				
			]
		);

		$this->add_responsive_control(
			'column_gap',
			[
				'label'       => esc_html__('Column Gap', 'happy-addons-pro'),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => ['px', '%', 'vw'],
				'range'       => [
					'px' => ['max' => 200],
					'%'  => ['max' => 30],
				],
				'default'     => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors'   => [
					'{{WRAPPER}}' => '--ha-v-tabs-column-gap: {{SIZE}}{{UNIT}};',
				],
				
			]
		);

	$this->add_responsive_control(
		'sticky_top',
		[
			'label'      => esc_html__('Sticky Top Offset', 'happy-addons-pro'),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => ['px', '%', 'vh'],
			'range'      => [
				'px' => ['max' => 300],
			],
			'default'    => [
				'unit' => 'px',
				'size' => 40,
			],
			'condition'  => [
				'select_type' => 'scroll',
			],
			'selectors'  => [
				'{{WRAPPER}}' => '--ha-v-tabs-sticky-top: {{SIZE}}{{UNIT}};',
			],
		]
	);

	$this->end_controls_section();
	}

	protected function register_content_animation_controls(): void {

		$this->start_controls_section(
			'section_content_animation',
			[
				'label' => esc_html__('Content Animation', 'happy-addons-pro'),
			]
		);
		$this->add_control(
			'select_type',
			[
				'label'   => esc_html__('Select Type', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'scroll' => esc_html__('Scroll', 'happy-addons-pro'),
					'hover'  => esc_html__('Hover', 'happy-addons-pro'),
					'click'  => esc_html__('Click', 'happy-addons-pro'),
				],
				'default' => 'scroll',
				'separator' => 'before',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'content_animation',
			[
				'label'   => esc_html__('Animation Style', 'happy-addons-pro'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'fade',
				'options' => [
					'none'        => esc_html__('None', 'happy-addons-pro'),
					'fade'        => esc_html__('Smooth Fade Swap', 'happy-addons-pro'),
					'vertical-reveal'  => esc_html__('Vertical Reveal', 'happy-addons-pro'),
					'reveal-bottom'  => esc_html__('Reveal Bottom', 'happy-addons-pro'),
					'reveal-top'  => esc_html__('Reveal Top', 'happy-addons-pro'),
					'square-reveal' => esc_html__('Square Reveal', 'happy-addons-pro'),
					'mask-reveal' => esc_html__('Mask Reveal', 'happy-addons-pro'),
					'zoom'        => esc_html__('Zoom Transition', 'happy-addons-pro'),
					'blur'        => esc_html__('Blur Swap', 'happy-addons-pro'),
					'flip-3d'     => esc_html__('3D Flip Swap', 'happy-addons-pro'),
					'zoom-blur'   => esc_html__('Zoom Blur', 'happy-addons-pro'),
					'slide-down-reveal' => esc_html__('Slide Down Reveal', 'happy-addons-pro'),
					'slide-up-reveal'   => esc_html__('Slide Up Reveal', 'happy-addons-pro'),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'content_animation_duration',
			[
				'label'      => esc_html__('Animation Duration (ms)', 'happy-addons-pro'),
				'type'       => Controls_Manager::NUMBER,
				'default'    => 400,
				'min'        => 100,
				'max'        => 8000,
				'step'       => 50,
				'frontend_available' => true,
			]
		);

	$this->add_control(
		'content_animation_easing',
		[
			'label'   => esc_html__('Animation Easing', 'happy-addons-pro'),
			'type'    => Controls_Manager::SELECT,
			'default' => 'ease',
			'options' => [
				'ease'        => esc_html__('Ease', 'happy-addons-pro'),
				'ease-in'     => esc_html__('Ease In', 'happy-addons-pro'),
				'ease-out'    => esc_html__('Ease Out', 'happy-addons-pro'),
				'ease-in-out' => esc_html__('Ease In Out', 'happy-addons-pro'),
				'bounce'      => esc_html__('Bounce', 'happy-addons-pro'),
				'elastic'     => esc_html__('Elastic', 'happy-addons-pro'),
			],
			'frontend_available' => true,
		]
	);

	$this->add_control(
		'title_zoom_heading',
		[
			'label'     => esc_html__('Active Item Title', 'happy-addons-pro'),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
		]
	);

		$this->add_control(
			'title_zoom',
			[
				'label'        => esc_html__('Zoom', 'happy-addons-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'    => esc_html__('No', 'happy-addons-pro'),
				'default'      => '',
			]
		);

	$this->add_control(
		'title_zoom_scale',
		[
			'label'      => esc_html__('Zoom Scale', 'happy-addons-pro'),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => ['x'],
			'range'      => [
				'x' => ['min' => 1, 'max' => 2, 'step' => 0.05],
			],
			'default'    => [
				'unit' => 'x',
				'size' => 1.2,
			],
			'selectors'  => [
				'{{WRAPPER}}' => '--ha-v-tabs-title-zoom-scale: {{SIZE}};',
			],
			'condition'  => [
				'title_zoom' => 'yes',
			],
			'render_type' => 'ui',
		]
	);

	$this->add_control(
		'title_zoom_duration',
		[
			'label'      => esc_html__('Zoom Duration (ms)', 'happy-addons-pro'),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => ['ms'],
			'range'      => [
				'ms' => ['min' => 100, 'max' => 3000, 'step' => 50],
			],
			'default'    => [
				'unit' => 'ms',
				'size' => 300,
			],
			'selectors'  => [
				'{{WRAPPER}}' => '--ha-v-tabs-title-zoom-duration: {{SIZE}}ms;',
			],
			'condition'  => [
				'title_zoom' => 'yes',
			],
			'render_type' => 'ui',
		]
	);

	$this->add_control(
		'title_zoom_easing',
		[
			'label'   => esc_html__('Zoom Easing', 'happy-addons-pro'),
			'type'    => Controls_Manager::SELECT,
			'default' => 'ease',
			'options' => [
				'ease'                                  => esc_html__('Ease', 'happy-addons-pro'),
				'ease-in'                               => esc_html__('Ease In', 'happy-addons-pro'),
				'ease-out'                              => esc_html__('Ease Out', 'happy-addons-pro'),
				'ease-in-out'                           => esc_html__('Ease In Out', 'happy-addons-pro'),
				'linear'                                => esc_html__('Linear', 'happy-addons-pro'),
				'cubic-bezier(0.68, -0.55, 0.265, 1.55)' => esc_html__('Bounce', 'happy-addons-pro'),
				'cubic-bezier(0.5, 1.75, 0.4, 0.75)'    => esc_html__('Elastic', 'happy-addons-pro'),
			],
			'selectors' => [
				'{{WRAPPER}}' => '--ha-v-tabs-title-zoom-easing: {{VALUE}};',
			],
			'condition' => [
				'title_zoom' => 'yes',
			],
			'render_type' => 'ui',
		]
	);

	$this->end_controls_section();
	}

	protected function register_scroll_controls(): void {

		$this->start_controls_section(
			'section_scroll',
			[
				'label'     => esc_html__('Scroll', 'happy-addons-pro'),
				'condition' => [
					'select_type' => 'scroll',
				],
			]
		);

		$this->add_control(
			'scroll_speed',
			[
				'label'       => esc_html__('Scroll Speed', 'happy-addons-pro'),
				'description' => esc_html__('Controls how fast the content changes while the section stays pinned. Higher value = less scrolling needed to advance through items. 1 = default.', 'happy-addons-pro'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0.5,
				'max'         => 5,
				'step'        => 0.1,
				'default'     => 3,
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'enable_parallax',
			[
				'label'        => esc_html__('Image Parallax', 'happy-addons-pro'),
				'type'         => Controls_Manager::HIDDEN,
				'label_on'     => esc_html__('Yes', 'happy-addons-pro'),
				'label_off'    => esc_html__('No', 'happy-addons-pro'),
				'default'      => '',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();
	}

	protected function register_list_title_style_controls(): void {

		$this->start_controls_section(
			'section_service_list_style',
			[
				'label' => esc_html__('List Title', 'happy-addons-pro'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .ha-v-tabs-service-title',
			]
		);
		$this->add_control(
			'title_text_align',
			[
				'label'     => esc_html__('Text Align', 'happy-addons-pro'),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => 'left',
				
				'options'   => [
					'left'    => [
						'title' => esc_html__('Left', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-left',
					],
					'center'  => [
						'title' => esc_html__('Center', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-center',
					],
					'right'   => [
						'title' => esc_html__('Right', 'happy-addons-pro'),
						'icon'  => 'eicon-text-align-right',
					],
				],
			'selectors' => [
				'{{WRAPPER}} .ha-v-tabs-title-wrap' => 'text-align: {{VALUE}};',
				'{{WRAPPER}} .ha-v-tabs-title-wrap[data-prefix-position="before"]' => 'justify-content: {{VALUE}};',
				'{{WRAPPER}} .ha-v-tabs-title-wrap[data-prefix-position="after"]' => 'justify-content: {{VALUE}};',
			],
			'frontend_available' => true,

		]
		);

		$this->add_responsive_control(
			'row_gap',
			[
				'label'      => esc_html__('Space Between', 'happy-addons-pro'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'vw'],
				'range'      => [
					'px' => ['max' => 200],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 0,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--ha-v-tabs-row-gap: {{SIZE}}{{UNIT}};',
				],
				
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => esc_html__('Padding', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'selectors'  => [
					'{{WRAPPER}} .ha-v-tabs-title-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],

			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .ha-v-tabs-title-wrap',
			]
		);

		$this->add_responsive_control(
			'item_border_radius',
			[
				'label'      => esc_html__('Border Radius', 'happy-addons-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em', 'rem', 'custom'],
				'selectors'  => [
					'{{WRAPPER}} .ha-v-tabs-title-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],

			]
		);

	$this->add_control(
		'hr_list_title_tabs',
		[
			'type' => Controls_Manager::DIVIDER,
		]
	);

		$this->start_controls_tabs('list_title_style_tabs');

		$this->start_controls_tab('list_title_normal', [
			'label' => esc_html__('Normal', 'happy-addons-pro'),
		]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'title_background_normal',
				'types'    => ['classic', 'gradient'],
				'exclude'  => ['image'],
				'selector' => '{{WRAPPER}} .ha-v-tabs-title-wrap',
			]
		);

		$this->add_control(
			'title_text_color',
			[
				'label'     => esc_html__('Text Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00000047',
				'selectors' => [
					'{{WRAPPER}}' => '--ha-v-tabs-title-normal-color: {{VALUE}};',
				],

			]
		);

	$this->end_controls_tab();

	$this->start_controls_tab('list_title_active', [
			'label' => esc_html__('Active', 'happy-addons-pro'),
		]);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'title_background_active',
				'types'    => ['classic', 'gradient'],
				'exclude'  => ['image'],
				'selector' => '{{WRAPPER}} .ha-v-tabs-item.e-active .ha-v-tabs-title-wrap',
			]
		);

		$this->add_control(
			'title_text_color_active',
			[
				'label'     => esc_html__('Text Color', 'happy-addons-pro'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}}' => '--ha-v-tabs-title-active-color: {{VALUE}};',
				],

			]
		);

	$this->add_control(
		'item_border_color_active',
		[
			'label'     => esc_html__('Border Color', 'happy-addons-pro'),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .ha-v-tabs-item.e-active .ha-v-tabs-title-wrap' => 'border-color: {{VALUE}};',
			],

		]
	);

	$this->end_controls_tab();

	$this->end_controls_tabs();

	$this->end_controls_section();
	}

	protected function register_prefix_style_controls(): void {

	$this->start_controls_section(
		'section_prefix_style',
		[
			'label'     => esc_html__('Prefix / Suffix', 'happy-addons-pro'),
			'tab'       => Controls_Manager::TAB_STYLE,
			'condition' => [
				'show_number' => 'yes',
			],
		]
	);

	$this->add_group_control(
		Group_Control_Typography::get_type(),
		[
			'name'     => 'number_typography',
			'selector' => '{{WRAPPER}} .ha-v-tabs-service-number',
		]
	);

	$this->add_responsive_control(
		'number_spacing',
		[
			'label'      => esc_html__('Spacing', 'happy-addons-pro'),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => ['px', 'em'],
			'range'      => [
				'px' => ['max' => 100],
			],
			'default'    => [
				'unit' => 'px',
				'size' => 8,
			],
			'selectors'  => [
				'{{WRAPPER}}' => '--ha-v-tabs-number-spacing: {{SIZE}}{{UNIT}};',
			],
		]
	);

	$this->add_responsive_control(
		'number_padding',
		[
			'label'      => esc_html__('Padding', 'happy-addons-pro'),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%', 'em', 'rem', 'custom'],
			'selectors'  => [
				'{{WRAPPER}} .ha-v-tabs-service-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
	);

	$this->add_group_control(
		Group_Control_Border::get_type(),
		[
			'name'     => 'number_border',
			'selector' => '{{WRAPPER}} .ha-v-tabs-service-number',
		]
	);

	$this->add_responsive_control(
		'number_border_radius',
		[
			'label'      => esc_html__('Border Radius', 'happy-addons-pro'),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => ['px', '%', 'em', 'rem', 'custom'],
			'selectors'  => [
				'{{WRAPPER}} .ha-v-tabs-service-number' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			],
		]
	);

	$this->add_control(
		'hr_prefix_tabs',
		[
			'type' => Controls_Manager::DIVIDER,
		]
	);

	$this->start_controls_tabs('prefix_style_tabs');

	$this->start_controls_tab('prefix_style_normal', [
		'label' => esc_html__('Normal', 'happy-addons-pro'),
	]);

	$this->add_group_control(
		Group_Control_Background::get_type(),
		[
			'name'     => 'number_background_normal',
			'types'    => ['classic', 'gradient'],
			'exclude'  => ['image'],
			'selector' => '{{WRAPPER}} .ha-v-tabs-service-number',
		]
	);

	$this->add_control(
		'number_color',
		[
			'label'     => esc_html__('Prefix / Suffix Color', 'happy-addons-pro'),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}' => '--ha-v-tabs-number-normal-color: {{VALUE}};',
			],
		]
	);

	$this->end_controls_tab();

	$this->start_controls_tab('prefix_style_active', [
		'label' => esc_html__('Active', 'happy-addons-pro'),
	]);

	$this->add_group_control(
		Group_Control_Background::get_type(),
		[
			'name'     => 'number_background_active',
			'types'    => ['classic', 'gradient'],
			'exclude'  => ['image'],
			'selector' => '{{WRAPPER}} .ha-v-tabs-item.e-active .ha-v-tabs-service-number',
		]
	);

	$this->add_control(
		'number_color_active',
		[
			'label'     => esc_html__('Prefix / Suffix Color', 'happy-addons-pro'),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}}' => '--ha-v-tabs-number-active-color: {{VALUE}};',
			],
		]
	);

	$this->add_control(
		'number_border_color_active',
		[
			'label'     => esc_html__('Border Color', 'happy-addons-pro'),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .ha-v-tabs-item.e-active .ha-v-tabs-service-number' => 'border-color: {{VALUE}};',
			],
		]
	);

	$this->end_controls_tab();

	$this->end_controls_tabs();

	$this->end_controls_section();
}

	protected function render(): void {
		$settings      = $this->get_settings_for_display();
		$items         = $settings['items'] ?? [];
		$widget_number = $this->get_id_int();

		$show_number    = 'yes' === ($settings['show_number'] ?? 'no');
		$prefix_position = $settings['prefix_position'] ?? 'above';
		$select_type    = $settings['select_type'] ?? 'scroll';
		$title_html_tag = Utils::validate_html_tag($settings['service_title_tag'] ?? 'h2');
		$title_position = $settings['title_position'] ?? 'left';
		$inactive_opacity_setting = $settings['title_inactive_opacity'] ?? null;
		if (is_array($inactive_opacity_setting) && array_key_exists('size', $inactive_opacity_setting)) {
			$inactive_opacity = (float) $inactive_opacity_setting['size'];
		} elseif (is_numeric($inactive_opacity_setting)) {
			$inactive_opacity = (float) $inactive_opacity_setting;
		} else {
			$inactive_opacity = 1;
		}

		$enable_parallax = 'yes' === ($settings['enable_parallax'] ?? '');
		$content_animation = $settings['content_animation'] ?? 'fade';
		$content_animation_duration = $settings['content_animation_duration'] ?? 400;
		$content_animation_easing = $settings['content_animation_easing'] ?? 'ease';
		$scroll_speed = isset($settings['scroll_speed']) ? max(0.1, (float) $settings['scroll_speed']) : 3;
		$title_text_align = $settings['title_text_align'] ?? 'right';
		$title_zoom = 'yes' === ($settings['title_zoom'] ?? '');

		$this->add_render_attribute('service-list-wrapper', [
			'class'                => ['ha-v-tabs-list', 'right' === $title_position ? 'ha-v-tabs-title-right' : '', $title_zoom ? 'ha-v-tabs-zoom' : ''],
			'data-widget-number'   => $widget_number,
			'data-select-type'     => $select_type,
			'data-inactive-opacity'   => $inactive_opacity,
			'data-parallax'        => $enable_parallax ? '1' : '0',
			'data-content-animation' => $content_animation,
			'data-content-animation-duration' => $content_animation_duration,
			'data-content-animation-easing' => $content_animation_easing,
			'data-scroll-speed'    => $scroll_speed,
			'data-title-text-align' => $title_text_align,
		]);

		$items_html = '';

		foreach ($items as $index => $item) {
			$service_count    = $index + 1;
			$item_setting_key = $this->get_repeater_setting_key('service_title', 'items', $index);
			$raw_css_id       = $item['element_css_id'] ?? '';
			$sanitized_css_id = preg_replace('/[^a-zA-Z0-9_-]/', '', sanitize_title($raw_css_id));
			$item_id          = empty($sanitized_css_id) ? 'ha-v-tabs-item-' . $widget_number . $service_count : $sanitized_css_id;
		$item_title       = sanitize_text_field($item['service_title'] ?? '');
		$prefix_type      = $item['prefix_type'] ?? 'text';
			$prefix_text      = sanitize_text_field($item['prefix_text'] ?? '');
			$prefix_icon      = $item['prefix_icon'] ?? [];
			$is_active        = (0 === $index);

			if ('icon' === $prefix_type) {
				$show_prefix = $show_number && ! empty($prefix_icon['value']);
			} else {
				$show_prefix = $show_number && ! empty($prefix_text);
			}

			$item_settings = [
				'index'         => $index,
				'service_count' => $service_count,
				'item_id'       => $item_id,
				'widget_number' => $widget_number,
				'item'          => $item,
				'settings'      => $settings,
			];

			$this->service_item_settings[] = $item_settings;

			$this->add_render_attribute($item_setting_key, [
				'id'                => $item_id,
				'class'             => ['ha-v-tabs-item', $is_active ? 'e-active' : ''],
				'data-service-index' => $service_count,
			]);

			ob_start();
?>
			<div <?php $this->print_render_attribute_string($item_setting_key); ?>>
				<div id="<?php echo esc_attr($item_id); ?>-title" class="ha-v-tabs-title-wrap" data-prefix-position="<?php echo esc_attr($prefix_position); ?>">
					<?php if ($show_prefix) : ?>
						<span class="ha-v-tabs-service-number">
							<?php if ('icon' === $prefix_type) : ?>
								<?php Icons_Manager::render_icon($prefix_icon, ['aria-hidden' => 'true']); ?>
							<?php else : ?>
								<?php echo esc_html($prefix_text); ?>
							<?php endif; ?>
						</span>
					<?php endif; ?>
					<<?php echo esc_attr($title_html_tag); ?> class="ha-v-tabs-service-title">
						<?php echo esc_html($item_title); ?>
					</<?php echo esc_attr($title_html_tag); ?>>
				</div>
				<div class="ha-v-tabs-gap" aria-hidden="true"></div>
				<?php
				$item_settings_data = $this->service_item_settings[$index];
				$this->print_child($item_settings_data['index'], $item_settings_data);
				?>
			</div>
		<?php
			$items_html .= ob_get_clean();
		}
		?>
		<div <?php $this->print_render_attribute_string('service-list-wrapper'); ?>>
			<?php echo $items_html; ?>
		</div>
	<?php
	}

	public function print_child($index, $item_settings = []) {

		$children = $this->get_children();

		if (! isset($children[$index])) {
			return;
		}

		$child = $children[$index];
		$child_id = $child->get_id();

		$add_attribute_to_container = function ($should_render, $container) use ($child_id, $item_settings) {
			if ($container->get_id() === $child_id) {
				$this->add_attributes_to_container($container, $item_settings);
			}

			return $should_render;
		};

		add_filter('elementor/frontend/container/should_render', $add_attribute_to_container, 10, 3);

		$child->print_element();

		remove_filter('elementor/frontend/container/should_render', $add_attribute_to_container);
	}

	protected function add_attributes_to_container($container, $item_settings) {
		$container->add_render_attribute('_wrapper', [
			'role'               => 'region',
			'aria-labelledby'    => $item_settings['item_id'] . '-title',
			'data-service-index' => $item_settings['service_count'] ?? 1,
		]);
	}

	protected function content_template(): void {
	?>
		<#
			const elementUid=view.getIDInt().toString();
			const titleHTMLTag=elementor.helpers.validateHTMLTag(settings.service_title_tag || 'h2' );
			const showPrefix=settings.show_number==='yes' ;
			const prefixPosition=settings.prefix_position || 'above' ;
			const selectType=settings.select_type || 'scroll' ;

			const enableParallax=settings.enable_parallax==='yes' ;
			const contentAnimation=settings.content_animation || 'fade' ;
			const contentAnimationDuration=settings.content_animation_duration || 400;
			const contentAnimationEasing=settings.content_animation_easing || 'ease' ;
			const scrollSpeed=parseFloat(settings.scroll_speed) || 3;
			const titlePosition=settings.title_position || 'left' ;
			const titleTextAlign=settings.title_text_align || 'right' ;
			const titleZoom=settings.title_zoom==='yes' ;

			view.addRenderAttribute('service-list-wrapper', { 'class' : ['ha-v-tabs-list', titlePosition === 'right' ? 'ha-v-tabs-title-right' : '', titleZoom ? 'ha-v-tabs-zoom' : ''] , 'data-widget-number' : elementUid, 'data-select-type' : selectType, 'data-parallax' : enableParallax ? '1' : '0' , 'data-content-animation' : contentAnimation, 'data-content-animation-duration' : contentAnimationDuration, 'data-content-animation-easing' : contentAnimationEasing, 'data-scroll-speed' : scrollSpeed, 'data-title-text-align' : titleTextAlign
			});
			#>
			<div {{{ view.getRenderAttributeString('service-list-wrapper') }}}>
				<# if (settings['items']) { #>
					<# _.each(settings['items'], function(item, index) { #>
						<#
							const serviceCount=index + 1;
							const itemUid=elementUid + serviceCount;
							const itemId=item.element_css_id || 'ha-v-tabs-item-' + itemUid;
							const isActive=(0===index);
							const prefixType=item.prefix_type || 'text' ;
							const prefixText=item.prefix_text || '' ;
							const renderPrefixIcon=(icon)=> {
							if (!icon || !icon.value) return '';
							const rendered = elementor.helpers.renderIcon(view, icon, { 'aria-hidden': true }, 'i', 'object');
							return typeof rendered === 'string' ? rendered : (rendered && rendered.value || '');
							};
						const prefixIconHtml = renderPrefixIcon(item.prefix_icon);
						const showItemPrefix = showPrefix && (prefixType === 'icon' ? !!prefixIconHtml : !!prefixText);
						const itemTitle = String(item.service_title || '').trim();

							view.addRenderAttribute('item-' + itemUid, {
							'id': itemId,
							'class': ['ha-v-tabs-item', isActive ? 'e-active' : ''],
							'data-service-index': serviceCount
							});
							#>
							<div {{{ view.getRenderAttributeString('item-' + itemUid) }}}>
								<div id="{{{ itemId }}}-title" class="ha-v-tabs-title-wrap" data-prefix-position="{{{ prefixPosition }}}">
									<# if (showItemPrefix) { #>
										<span class="ha-v-tabs-service-number">
											<# if (prefixType==='icon' ) { #>
												{{{ prefixIconHtml }}}
												<# } else { #>
													{{{ prefixText }}}
													<# } #>
										</span>
										<# } #>
											<{{{ titleHTMLTag }}} class="ha-v-tabs-service-title">{{{ itemTitle }}}</{{{ titleHTMLTag }}}>
								</div>
								<div class="ha-v-tabs-gap" aria-hidden="true"></div>
							</div>
							<# }); #>
								<# } #>
			</div>
		<?php
	}

	protected function content_template_single_repeater_item(): void {
		?>
			<#
				const tabIndex=view.collection.length;
				const elementUid=view.getIDInt().toString();
				const serviceCount=tabIndex + 1;
				const itemUid=elementUid + serviceCount;
				const itemId=data.element_css_id || 'ha-v-tabs-item-' + itemUid;
				const prefixType=data.prefix_type || 'text' ;
				const prefixText=data.prefix_text || '' ;
				const prefixPosition=data.prefix_position || 'before' ;
				const renderPrefixIcon=(icon)=> {
				if (!icon || !icon.value) return '';
				const rendered = elementor.helpers.renderIcon(view, icon, { 'aria-hidden': true }, 'i', 'object');
				return typeof rendered === 'string' ? rendered : (rendered && rendered.value || '');
				};
			const prefixIconHtml = renderPrefixIcon(data.prefix_icon);
			const showItemPrefix = prefixType === 'icon' ? !!prefixIconHtml : !!prefixText;
			const itemTitle = String(data.service_title || '').trim();

				view.addRenderAttribute('item-wrapper-' + serviceCount, {
				'id': itemId,
				'class': 'ha-v-tabs-item',
				'data-service-index': serviceCount
				});
				#>
				<div {{{ view.getRenderAttributeString('item-wrapper-' + serviceCount) }}}>
					<div id="{{{ itemId }}}-title" class="ha-v-tabs-title-wrap" data-prefix-position="{{{ prefixPosition }}}">
						<# if (showItemPrefix) { #>
							<span class="ha-v-tabs-service-number">
								<# if (prefixType==='icon' ) { #>
									{{{ prefixIconHtml }}}
									<# } else { #>
										{{{ prefixText }}}
										<# } #>
							</span>
							<# } #>
								<div class="ha-v-tabs-service-title">{{{ itemTitle }}}</div>
					</div>
				</div>
		<?php
	}
}

add_action('elementor/editor/after_enqueue_styles', [Visual_Tabs::class, 'register_editor_styles']);
