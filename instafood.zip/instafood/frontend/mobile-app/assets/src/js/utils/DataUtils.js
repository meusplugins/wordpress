import Cart from '../cart/Cart';

let instance;
const instanceKey = '_*&*(239';

class DataUtils {

    static _instance;
    static PRODUCTS = 'products';
    static CHOICE_GROUPS = 'choiceGroups';
    static CHOICES = 'choices';
    static PRODUCT_CATEGORIES = 'product_categories';
    static OPTIONS = 'options';
    static LOCALES = 'locales';

    _data;
    _products = [];
    _choiceGroups = [];
    _choices = [];
    _product_categories = [];
    _aggregatedGroups = [];

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._data = {};
    }

    setupData(jsonData) {
        if (!_.isNil(jsonData)) {
            try {
                this._data = JSON.parse(jsonData);
                this._products = _.get(this._data, 'products', []);
                this._handleHiddenProducts();
                this._choiceGroups = _.get(this._data, 'choiceGroups', []);
                this._choices = _.get(this._data, 'choices', []);
                this._product_categories = _.get(this._data, 'product_categories', []);

                this._formatProducts();
                this._formatChoices();
                this._formatGroups();

            } catch (error) {
                console.log(error);
            }
        }
    }

    _handleHiddenProducts() {
        if (!Array.isArray(this._products)) {
            return;
        }
        const validProducts = this._products.filter(product => {
            if (this.hasCurrentTable() && this.canDineIn()) {
                // is dine in
                return product?.meta?.item_dinein_disabled !== 'ON';
            } else if (!this.hasCurrentTable()) {
                // is delivery or pickup
                return product?.meta?.item_pickup_delivery_disabled !== 'ON';
            }
        })
        this._products = [...validProducts];
    }

    _formatProducts(product) {
        this._products = this._products.map(product => {
            const product_variations = _.get(product, 'meta.product_variations', []);
            const product_variations_float_prices = [];
            product_variations.forEach(variation => {
                product_variations_float_prices.push({
                    ...variation, price_float_val: parseFloat(_.get(variation, 'price'))
                })
            });
            const variation_min_price = _.minBy(product_variations_float_prices, 'price_float_val');
            return {
                ...product,
                meta: {..._.get(product, 'meta', {}), variation_min_price, product_variations: product_variations_float_prices}
            };
        })
    }

    _formatChoices() {
        const formatedChoices = this._choices.map(choice => {
            return {...choice, price_float_val: parseFloat(_.get(choice, 'choice_price'))}
        });
        this._choices = [...formatedChoices];
    }

    _formatGroups() {
        for (let i = 0; i < this._choiceGroups.length; i++) {
            let group = this._choiceGroups[i];
            const groupChoices = _.get(group, 'post_meta.choices_ids', []);
            const groupChoicesWithData = [];

            this._choices.forEach(choice => {
                for (let k = 0; k < groupChoices.length; k++) {
                    const groupChoice = groupChoices[k];
                    if (parseInt(groupChoice, 10) === parseInt(choice.term_id, 10)) {
                        groupChoicesWithData.push({...choice});
                        break;
                    } 
                }
            });
            group = { ...group, group_choices: groupChoicesWithData }
            this._aggregatedGroups.push(group);
        }
    }

    getFromData(dataFieldKey) {
        return _.get(this._data, `${dataFieldKey}`, {});
    }

    getProducts() {
        return this._products;
    }

    getProduct(productId) {
        let product = {};
        for (let i = 0; i < this._products.length; i++) {
            if (parseInt(productId, 10) === _.get(this._products[i], 'ID', '')) {
                product = this._products[i];
                break;
            }
        }
        return product;
    }

    getChoices() {
        return this._choices;
    }

    getChoicesFromData(existingChoicesIds) {
        const filtered = this._choices.filter(choice => {
            const found = existingChoicesIds.find(choiceId => choiceId === _.get(choice, 'term_id'));
            if (found !== undefined) {
                return choice;
            }
            return false;
        });
        return filtered;
    }

    getOption(optionKey) {
        return _.get(this.getFromData(DataUtils.OPTIONS), optionKey, '');
    }

    getAggregatedGroups() {
        return this._aggregatedGroups;
    }

    meetsMinOrderValue() {
        let out = true;
        let min_order_value = parseFloat(this.getOption('restaurant_delivery_min_order_value'));
        if (min_order_value === '') {
            return true;
        }
        if (isNaN(min_order_value)) {
            return true;
        }
        if (min_order_value === 0 || min_order_value < 0) {
            return false;
        }
        if (min_order_value > Cart.getInstance().getCartTotal()) {
            return false;
        }
        return out;
    }

    getDifMinOrder() {
        let min_order_value = parseFloat(this.getOption('restaurant_delivery_min_order_value'));
        return min_order_value - Cart.getInstance().getCartTotal();
    }

    hasCurrentTable() {
        let out = false;
        const params = new URLSearchParams(window.location.search);
        for (const param of params) {
            if (params.has('ift')) {
                out = true;
                break;
            }
        }
        return out;
    }

    getCurrentTable() {
        let out = false;
        const params = new URLSearchParams(window.location.search);
        for (const param of params) {
            if (params.has('ift')) {
                out = params.get('ift');
                break;
            }
        }
        return out;
    }

    canDineIn() {
        const local_order_enabled = DataUtils.getInstance().getOption('local_order_enabled') === 'ON';
        return this.hasCurrentTable() && local_order_enabled;
    }

    canDeliver() {
        const delivery_enabled = this.getOption('delivery_enabled') === 'ON';
        return !this.hasCurrentTable() && delivery_enabled;
    }

    canPickUp() {
        const pickup_order_enabled = this.getOption('pickup_order_enabled') === 'ON';
        return !this.hasCurrentTable() && pickup_order_enabled;
    }

    getFormmatedPriceDisplay(price) {
        
        const isPriceDot = this.getOption('frontend_enabled_decimal_dot') === 'ON';

        // override from the child plugin
        if (window.instafoodCustomJSHooks) {
            price = Number(price);
            const newFormattedPrice = instafoodCustomJSHooks.onPriceFormat(price, isPriceDot);
            if (newFormattedPrice) {
                return newFormattedPrice;
            }
        }

        if (isPriceDot) {
            return Number.parseFloat(price).toFixed(2);
        } else {
            return Number.parseFloat(price).toFixed(2).replace('.', ',');
        }
    }

    hasLanguagePreset() {
        let out = false;
        const params = new URLSearchParams(window.location.search);
        for (const param of params) {
            if (params.has('lng')) {
                out = true;
                break;
            }
        }
        return out;
    }

    getLanguagePreset() {
        let out = false;
        const params = new URLSearchParams(window.location.search);
        for (const param of params) {
            if (params.has('lng')) {
                out = params.get('lng');
                break;
            }
        }
        return out;
    }

    static getInstance() {
        if (!instance) {
            instance = new DataUtils(instanceKey);
        }
        return instance;
    }
}
export default DataUtils;