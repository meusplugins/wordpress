import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Events } from '../../events/EventBus';

class ExistingProductInCartInfo {
    _ui;
    _parentUi;
    _existingCartProductData;

    constructor(parentUi, existingCartProductData) {
        this._parentUi = parentUi;
        this._existingCartProductData = existingCartProductData;
    }

    render() {
        if (!Array.isArray(this._existingCartProductData)) {
            return;
        }
        let output = '';
        this._existingCartProductData.forEach(entry => {
            const { quantity, productName } = entry;
            output += `
            <div class="already_in_cart_content">
                <div class="p_info"><span>${ quantity }x</span> ${ productName }</div>
                <div class="edit_in_cart">${ LanguageUtils.getInstance().getLabel('edit_in_cart_label') }</div>
            </div>
            `;
        })
        const { quantity, productName } = this._existingCartProductData;
        const template = `
        <div class="already_in_cart_widget">
            <div class="already_in_cart_title">${ LanguageUtils.getInstance().getLabel('already_in_cart_label') }</div>
            ${ output }
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._parentUi);
        this._ui.find('.edit_in_cart').click(function(event) {
            event.preventDefault();
            EventBus.getInstance().triggerEvent(Events.PRODUCT_SCREEN_CLOSE, {});
        })
    }
}
export default ExistingProductInCartInfo;