(() => {
	'use strict';

	const config = window.JetEngineBricksListingItemSettings || {};

	if (!config.postId || !config.ajaxUrl || !config.actions) {
		return;
	}

	const namespace = 'jet-engine-bricks-listing-settings';
	const entrySelector = '[data-jet-engine-bricks-listing-settings-entry="1"]';
	const panelSelector = '[data-jet-engine-bricks-listing-settings-panel="1"]';
	const supportedTypes = ['checkbox', 'number', 'select', 'text', 'textarea'];
	const successStatusDelay = 3000;
	const openGroups = new Set();
	const labels = () => config.labels || {};

	let observer = null;
	let scheduled = false;
	let originalSettingsNodes = null;
	let startupTries = 0;
	let loaded = false;
	let loading = false;
	let saving = false;
	let dirty = false;
	let successStatusTimer = null;
	let statusMode = '';
	let localSettings = { ...(config.settings || {}) };

	const scheduleInject = () => {
		if (scheduled) {
			return;
		}

		scheduled = true;

		window.requestAnimationFrame(() => {
			scheduled = false;
			injectEntry();
			ensureObserverRoot();
		});
	};

	const getSettingsPanel = () => document.querySelector(config.selectors?.settingsPanel || '#bricks-panel-settings');

	const getControlsContainer = (settingsPanel) => settingsPanel?.querySelector(config.selectors?.controls || '.bricks-panel-controls');

	const getInsertionList = (settingsPanel) => {
		const controls = getControlsContainer(settingsPanel);

		if (!controls) {
			return null;
		}

		const lists = [...controls.children].filter((child) => child.matches?.(config.selectors?.controlGroups || 'ul.control-groups'));
		let list = lists.length ? lists[0] : null;

		if (!list) {
			list = document.createElement('ul');
			list.className = 'control-groups';
			list.setAttribute(`data-${namespace}-owned`, '1');
			controls.appendChild(list);
		}

		return list;
	};

	const injectEntry = () => {
		const settingsPanel = getSettingsPanel();

		if (!settingsPanel || settingsPanel.querySelector(panelSelector) || settingsPanel.querySelector(entrySelector)) {
			return;
		}

		const list = getInsertionList(settingsPanel);

		if (!list) {
			return;
		}

		const item = document.createElement('li');
		item.className = 'control-group';
		item.dataset.jetEngineBricksListingSettingsEntry = '1';

		const title = document.createElement('div');
		title.className = 'control-group-title';
		title.setAttribute('role', 'button');
		title.setAttribute('tabindex', '0');

		const titleText = document.createElement('span');
		titleText.textContent = labels().entryTitle || 'Listing Item Settings';

		title.append(createSvgIcon('settings', 'icon'), titleText);
		title.addEventListener('click', openPanel);
		title.addEventListener('keydown', (event) => {
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				openPanel();
			}
		});

		item.appendChild(title);
		list.appendChild(item);
	};

	const openPanel = () => {
		const settingsPanel = getSettingsPanel();

		if (!settingsPanel) {
			return;
		}

		originalSettingsNodes = [];

		while (settingsPanel.firstChild) {
			originalSettingsNodes.push(settingsPanel.removeChild(settingsPanel.firstChild));
		}

		settingsPanel.appendChild(renderPanel());

		if (!loaded && !loading) {
			loadSettings();
		}
	};

	const renderPanel = () => {
		const panel = document.createElement('div');
		panel.className = 'jet-engine-bricks-listing-settings-panel';
		panel.dataset.jetEngineBricksListingSettingsPanel = '1';

		const header = document.createElement('div');
		header.id = 'bricks-panel-header';
		header.className = 'jet-engine-bricks-listing-settings-panel__header';

		const back = document.createElement('button');
		back.type = 'button';
		back.className = 'jet-engine-bricks-listing-settings-panel__back';
		back.textContent = labels().back || 'Back';
		back.addEventListener('click', restoreSettingsList);

		const title = document.createElement('div');
		title.className = 'title';
		title.textContent = labels().panelTitle || 'Listing Settings';

		header.append(title, back);

		const body = document.createElement('div');
		body.className = 'bricks-panel-controls jet-engine-bricks-listing-settings-panel__body';
		renderPanelBody(body);

		panel.append(header, body);
		updateBusyState(panel);

		return panel;
	};

	const renderPanelBody = (body) => {
		body.textContent = '';

		const wrapper = document.createElement('div');
		wrapper.className = 'regular-controls-wrapper';

		const list = document.createElement('ul');
		list.className = 'control-groups';

		Object.entries(getControlGroups()).forEach(([groupKey, group]) => {
			if (isRequiredMet(group.required)) {
				list.appendChild(renderControlGroup(groupKey, group));
			}
		});

		wrapper.appendChild(list);
		body.append(wrapper, renderActions());
		updateRequiredControls(body);
	};

	const renderControlGroup = (groupKey, group) => {
		const item = document.createElement('li');
		item.className = 'control-group';
		item.dataset.controlGroup = groupKey;

		if (openGroups.has(groupKey)) {
			item.classList.add('open');
		}

		const title = document.createElement('div');
		title.className = 'control-group-title';
		title.setAttribute('role', 'button');
		title.setAttribute('tabindex', '0');
		title.setAttribute('aria-expanded', item.classList.contains('open') ? 'true' : 'false');

		const titleText = document.createElement('span');
		titleText.textContent = group.title || group.label || groupKey;

		const actions = document.createElement('div');
		actions.className = 'control-group-actions';

		actions.appendChild(createSvgIcon('arrow-right', 'arrow'));
		title.append(titleText, actions);

		const toggle = () => toggleGroup(item, groupKey, title);
		title.addEventListener('click', toggle);
		title.addEventListener('keydown', (event) => {
			if (event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				toggle();
			}
		});

		item.appendChild(title);

		getControlsForGroup(groupKey).forEach(([controlKey, control]) => {
			item.appendChild(renderControl(controlKey, control));
		});

		return item;
	};

	const createSvgIcon = (name, className) => {
		const icon = document.createElement('span');
		icon.className = `bricks-svg-wrapper ${className}`;
		icon.dataset.name = name;
		icon.innerHTML = getSvgIconMarkup(name);

		return icon;
	};

	const getSvgIconMarkup = (name) => {
		const icons = {
			'arrow-right': '<svg class="bricks-svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="M6.6395 0.975L17.1451 11.4806C17.4323 11.7673 17.4323 12.2327 17.1451 12.5194L6.6395 23.025" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg>',
			'settings': '<svg class="bricks-svg" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="M12 15.5A3.5 3.5 0 1 0 12 8a3.5 3.5 0 0 0 0 7.5Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"></path><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2.06 2.06 0 0 1-2.91 2.91l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.05V21a2.06 2.06 0 0 1-4.12 0v-.09A1.7 1.7 0 0 0 8.5 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2.06 2.06 0 0 1-2.91-2.91l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.05-.4H3a2.06 2.06 0 0 1 0-4.12h.09A1.7 1.7 0 0 0 4.6 8.5a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2.06 2.06 0 0 1 2.91-2.91l.06.06A1.7 1.7 0 0 0 9 4.6c.38-.16.72-.37 1-.6a1.7 1.7 0 0 0 .4-1.05V3a2.06 2.06 0 0 1 4.12 0v.09A1.7 1.7 0 0 0 15.5 4.6a1.7 1.7 0 0 0 1.87-.34l.06-.06a2.06 2.06 0 0 1 2.91 2.91l-.06.06A1.7 1.7 0 0 0 19.4 9c.16.38.37.72.6 1 .3.25.67.39 1.05.4H21a2.06 2.06 0 0 1 0 4.12h-.09A1.7 1.7 0 0 0 19.4 15Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"></path></svg>',
		};

		return icons[name] || '';
	};

	const toggleGroup = (item, groupKey, title) => {
		const isOpen = !item.classList.contains('open');
		item.classList.toggle('open', isOpen);
		title.setAttribute('aria-expanded', isOpen ? 'true' : 'false');

		if (isOpen) {
			openGroups.add(groupKey);
		} else {
			openGroups.delete(groupKey);
		}
	};

	const renderActions = () => {
		const wrap = document.createElement('div');
		wrap.className = 'jet-engine-bricks-listing-settings-actions';

		const save = document.createElement('button');
		save.type = 'button';
		save.className = 'button button-primary jet-engine-bricks-listing-settings-save';
		save.dataset.jetEngineBricksListingSettingsSave = '1';
		save.textContent = labels().save || 'Save';
		save.addEventListener('click', saveSettings);

		const status = document.createElement('p');
		status.className = 'jet-engine-bricks-listing-settings-status';
		status.dataset.jetEngineBricksListingSettingsStatus = '1';
		status.setAttribute('role', 'status');
		status.setAttribute('aria-live', 'polite');

		wrap.append(save, status);

		return wrap;
	};

	const renderControl = (controlKey, control) => {
		const type = supportedTypes.includes(control.type) ? control.type : 'text';
		const field = document.createElement('div');
		field.dataset.controlkey = controlKey;
		field.dataset.jetEngineBricksListingSettingsControl = controlKey;

		const controlWrap = document.createElement('div');
		controlWrap.className = `control control-${type}`;

		const inner = document.createElement('div');
		inner.className = 'control-inner has-label control-inline';

		const label = document.createElement('label');
		label.setAttribute('for', controlKey);
		label.setAttribute('title', control.label || controlKey);

		const text = document.createElement('span');
		text.className = 'text';
		text.textContent = control.label || controlKey;
		label.appendChild(text);

		inner.append(label, renderInput(controlKey, control, type));
		controlWrap.appendChild(inner);

		const description = control.description || control.desc;

		if (description) {
			const desc = document.createElement('div');
			desc.className = 'description';
			desc.textContent = description;
			controlWrap.appendChild(desc);
		}

		field.appendChild(controlWrap);

		return field;
	};

	const renderInput = (controlKey, control, type) => {
		const wrapper = document.createElement('div');
		wrapper.dataset.control = type;

		if (type === 'select') {
			const select = document.createElement('select');
			select.id = controlKey;
			select.name = controlKey;
			appendOptions(select, control.options || {});
			select.value = getValue(controlKey);
			bindInput(select, controlKey);
			wrapper.appendChild(select);
			return wrapper;
		}

		if (type === 'textarea') {
			const textarea = document.createElement('textarea');
			textarea.id = controlKey;
			textarea.name = controlKey;
			textarea.rows = Number(control.rows) || 5;
			textarea.placeholder = control.placeholder || '';
			textarea.value = getValue(controlKey);
			bindInput(textarea, controlKey);
			wrapper.appendChild(textarea);
			return wrapper;
		}

		const input = document.createElement('input');
		input.id = controlKey;
		input.name = controlKey;
		input.type = ['checkbox', 'number'].includes(type) ? type : 'text';
		input.placeholder = control.placeholder || '';

		if (type === 'checkbox') {
			input.checked = getValue(controlKey) === 'yes';
		} else {
			input.value = getValue(controlKey);
		}

		bindInput(input, controlKey);
		wrapper.appendChild(input);

		return wrapper;
	};

	const bindInput = (input, controlKey) => {
		input.dataset.jetEngineBricksListingSettingsField = controlKey;
		input.addEventListener('change', onControlChange);
		input.addEventListener('input', onControlInput);
	};

	const appendOptions = (select, options) => {
		if (Array.isArray(options)) {
			options.forEach((option) => {
				if (option?.options) {
					appendOptGroup(select, option.label || '', option.options);
					return;
				}

				if (option?.values) {
					appendOptGroup(select, option.label || '', option.values);
					return;
				}

				if (option && typeof option === 'object' && Object.hasOwn(option, 'value')) {
					appendOption(select, option.value, option.label || option.value);
					return;
				}

				appendOption(select, option, option);
			});

			return;
		}

		Object.entries(options || {}).forEach(([value, option]) => {
			if (option?.options) {
				appendOptGroup(select, option.label || value, option.options);
				return;
			}

			if (option?.values) {
				appendOptGroup(select, option.label || value, option.values);
				return;
			}

			appendOption(select, value, option?.label || option);
		});
	};

	const appendOptGroup = (select, label, options) => {
		const group = document.createElement('optgroup');
		group.label = label;
		appendOptions(group, options);
		select.appendChild(group);
	};

	const appendOption = (parent, value, label) => {
		const option = document.createElement('option');
		option.value = value === null || value === undefined ? '' : String(value);
		option.textContent = label === null || label === undefined ? option.value : String(label);
		parent.appendChild(option);
	};

	const onControlInput = (event) => {
		if (event.target?.type !== 'checkbox') {
			updateSettingFromInput(event.target);
			updateRequiredControls();
		}
	};

	const onControlChange = (event) => {
		updateSettingFromInput(event.target);
		updateRequiredControls();
	};

	const updateSettingFromInput = (input) => {
		const key = input?.dataset?.jetEngineBricksListingSettingsField;

		if (!key) {
			return;
		}

		localSettings[key] = input.type === 'checkbox' ? (input.checked ? 'yes' : '') : input.value;
		dirty = true;
		clearSuccessStatus();
	};

	const updateRequiredControls = (root = document) => {
		Object.entries(getControls()).forEach(([controlKey, control]) => {
			const wrap = root.querySelector(`[data-jet-engine-bricks-listing-settings-control="${controlKey}"]`);

			if (wrap) {
				setControlVisibility(wrap, isRequiredMet(control.required));
			}
		});
	};

	const setControlVisibility = (wrap, isVisible) => {
		wrap.hidden = !isVisible;
		wrap.style.display = isVisible ? '' : 'none';
		wrap.setAttribute('aria-hidden', isVisible ? 'false' : 'true');
	};

	const isRequiredMet = (required) => {
		const rules = normalizeRequired(required);

		if (!rules.length) {
			return true;
		}

		return rules.every((condition) => evaluateCondition(condition));
	};

	const normalizeRequired = (required) => {
		if (!required) {
			return [];
		}

		if (isConditionTuple(required)) {
			return [required];
		}

		if (Array.isArray(required)) {
			return required.filter(isConditionTuple);
		}

		return [];
	};

	const isConditionTuple = (required) => Array.isArray(required) && required.length >= 3 && typeof required[0] === 'string';

	const evaluateCondition = (condition) => {
		const [key, operator, expected] = condition;
		const actual = getValue(key);
		const expectedValues = castToArray(expected).map(normalizeComparableValue);
		const actualValues = castToArray(actual).map(normalizeComparableValue);
		const matches = actualValues.some((actualValue) => expectedValues.includes(actualValue));

		if (operator === '!=') {
			return !matches;
		}

		return matches;
	};

	const castToArray = (value) => (Array.isArray(value) ? value : [value]);

	const normalizeComparableValue = (value) => {
		if (value === null || value === undefined) {
			return '';
		}

		return String(value);
	};

	const getControlGroups = () => config.controlGroups || {};

	const getControls = () => config.controls || {};

	const getControlsForGroup = (groupKey) => Object.entries(getControls()).filter(([, control]) => control?.group === groupKey);

	const getValue = (key) => {
		if (Object.prototype.hasOwnProperty.call(localSettings, key)) {
			return localSettings[key] ?? '';
		}

		return '';
	};

	const restoreSettingsList = () => {
		const settingsPanel = getSettingsPanel();

		if (!settingsPanel || !originalSettingsNodes) {
			originalSettingsNodes = null;
			return;
		}

		settingsPanel.textContent = '';
		originalSettingsNodes.forEach((node) => settingsPanel.appendChild(node));
		originalSettingsNodes = null;
		injectEntry();
	};

	const loadSettings = () => {
		loading = true;
		setStatus(labels().loading || 'Loading...');
		updateBusyState();

		sendAjax(config.actions.load, {})
			.then((response) => {
				loading = false;
				loaded = true;

				if (!dirty && response.settings) {
					applyPayload(response);
				}

				setStatus('');
				updateBusyState();
			})
			.catch((error) => {
				loading = false;
				setStatus(error.message || labels().loadError || 'Unable to load listing settings.', true);
				updateBusyState();
			});
	};

	const saveSettings = () => {
		if (saving) {
			return;
		}

		saving = true;
		setStatus(labels().saving || 'Saving...');
		updateBusyState();

		sendAjax(config.actions.save, {
			settings: JSON.stringify(localSettings),
		})
			.then((response) => {
				saving = false;
				dirty = false;
				loaded = true;
				applyPayload(response);
				setSuccessStatus(response.message || labels().saved || 'Settings saved.');
				updateBusyState();
			})
			.catch((error) => {
				saving = false;
				setStatus(error.message || labels().saveError || 'Unable to save listing settings.', true);
				updateBusyState();
			});
	};

	const applyPayload = (response) => {
		if (response.settings) {
			localSettings = { ...response.settings };
		}

		if (response.controlGroups) {
			config.controlGroups = response.controlGroups;
		}

		if (response.controls) {
			config.controls = response.controls;
		}

		rerenderPanelBody();
	};

	const rerenderPanelBody = () => {
		const body = document.querySelector(`${panelSelector} .jet-engine-bricks-listing-settings-panel__body`);

		if (!body) {
			return;
		}

		renderPanelBody(body);
		updateBusyState(body);
	};

	const sendAjax = (action, extraData) => {
		const data = new window.FormData();

		data.append('action', action);
		data.append('post_id', config.postId);
		data.append('_nonce', config.nonce || '');

		Object.entries(extraData || {}).forEach(([key, value]) => {
			data.append(key, value);
		});

		return window.fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data,
		})
			.then((response) => response.json())
			.then((payload) => {
				if (payload?.success) {
					return payload.data || {};
				}

				const message = payload?.data?.message || '';
				throw new Error(message);
			});
	};

	const clearSuccessStatusTimer = () => {
		if (successStatusTimer) {
			window.clearTimeout(successStatusTimer);
			successStatusTimer = null;
		}
	};

	const clearSuccessStatus = () => {
		if (statusMode !== 'success') {
			return;
		}

		clearSuccessStatusTimer();
		setStatus('');
	};

	const setSuccessStatus = (message) => {
		setStatus(message, false, 'success');
		clearSuccessStatusTimer();

		successStatusTimer = window.setTimeout(() => {
			if (statusMode === 'success') {
				setStatus('');
			}
		}, successStatusDelay);
	};

	const setStatus = (message, isError = false, mode = '') => {
		const status = document.querySelector(`${panelSelector} [data-jet-engine-bricks-listing-settings-status="1"]`);

		if (mode !== 'success') {
			clearSuccessStatusTimer();
		}

		if (!status) {
			statusMode = '';
			return;
		}

		status.textContent = message || '';
		status.classList.toggle('is-error', Boolean(isError));
		status.setAttribute('role', isError ? 'alert' : 'status');
		statusMode = message ? (mode || (isError ? 'error' : 'info')) : '';
	};

	const updateBusyState = (root = document) => {
		const save = root.querySelector('[data-jet-engine-bricks-listing-settings-save="1"]');

		if (save) {
			save.disabled = loading || saving;
			save.textContent = saving ? (labels().saving || 'Saving...') : (labels().save || 'Save');
		}
	};

	const ensureObserverRoot = () => {
		const root = document.querySelector(config.selectors?.panel || '#bricks-panel') || document.querySelector('#bricks-panel-inner') || document.body;

		if (!root || (observer && observer.__root === root)) {
			return;
		}

		if (observer) {
			observer.disconnect();
		}

		observer = new window.MutationObserver(scheduleInject);
		observer.__root = root;
		observer.observe(root, { childList: true, subtree: true });
	};

	const startupRetry = () => {
		scheduleInject();
		startupTries += 1;

		if (startupTries < 50 && !document.querySelector(config.selectors?.panel || '#bricks-panel')) {
			window.setTimeout(startupRetry, 150);
		}
	};

	document.addEventListener('DOMContentLoaded', scheduleInject);
	ensureObserverRoot();
	startupRetry();
})();
