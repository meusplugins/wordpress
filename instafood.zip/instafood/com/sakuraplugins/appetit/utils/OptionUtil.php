<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;
require_once(plugin_dir_path(__FILE__) . '../config.php');

use com\sakuraplugins\appetit\Config as Config;

class OptionUtil {
    
    private static $instance = null;
    private $options;

    private function __construct() {
        $this->options = get_option(Config::getOptionsGroupSlug(), []);
    }

    public function getOption(string $optsKey, $default = null) {
        return (isset($this->options[$optsKey])) ? $this->options[$optsKey] : $default;
    }

    public function getAllOptions($default = []) {
        return (isset($this->options)) ? $this->options : $default;
    }

    public function hasReCaptcha() {
        $recaptcha_site_key = $this->getOption('recaptcha_site_key', '');
        $recaptcha_secret_key = $this->getOption('recaptcha_secret_key', '');
        return $recaptcha_site_key !== '' && $recaptcha_secret_key !== '';
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new OptionUtil();
        }
        return self::$instance;
    }
}
?>