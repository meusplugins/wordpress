<?php
/**
 * Pagination filter class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Smart_Filters_Pagination_Filter' ) ) {
	/**
	 * Define Jet_Smart_Filters_Pagination_Filter class
	 */
	class Jet_Smart_Filters_Pagination_Filter {

		/**
		 * Get provider ID
		 */
		public function get_id() {

			return 'pagination';
		}

		/**
		 * Render initial frontend pagination.
		 *
		 * @param array  $controls Pagination controls.
		 * @param string $provider Provider ID.
		 * @param string $query_id Provider query ID.
		 */
		public function render_pagination( $controls, $provider, $query_id = 'default' ) {

			$query_id   = $query_id ? $query_id : 'default';
			$query_props = jet_smart_filters()->query->get_query_props( $provider, $query_id );
			$pages       = ! empty( $query_props['max_num_pages'] ) ? absint( $query_props['max_num_pages'] ) : 0;
			$page        = ! empty( $query_props['page'] ) ? absint( $query_props['page'] ) : 1;

			if ( $pages < 2 ) {
				return;
			}

			$page = min( max( 1, $page ), $pages );

			$this->render_pagination_items( $controls, $pages, $page, $provider, $query_id );
		}

		/**
		 * Render pagination sample.
		 *
		 * @param array $controls Pagination controls.
		 */
		public function render_pagination_sample( $controls ) {

			$this->render_pagination_items( $controls, 10, 4 );
		}

		/**
		 * Render pagination items.
		 *
		 * @param array  $controls Pagination controls.
		 * @param int    $pages    Total pages count.
		 * @param int    $page     Current page.
		 * @param string $provider Provider ID. Empty for editor samples.
		 * @param string $query_id Provider query ID.
		 */
		private function render_pagination_items( $controls, $pages, $page, $provider = '', $query_id = 'default' ) {

			$items_enabled     = ! empty( $controls['items_enabled'] ) && filter_var( $controls['items_enabled'], FILTER_VALIDATE_BOOLEAN );
			$pages_mid_size    = ! empty( $controls['pages_mid_size'] ) ? absint( $controls['pages_mid_size'] ) : 0;
			$pages_end_size    = ! empty( $controls['pages_end_size'] ) ? absint( $controls['pages_end_size'] ) : 0;
			$nav_enabled       = ! empty( $controls['nav_enabled'] ) && filter_var( $controls['nav_enabled'], FILTER_VALIDATE_BOOLEAN );
			$hide_inactive_nav = ! empty( $controls['hide_inactive_nav'] ) && filter_var( $controls['hide_inactive_nav'], FILTER_VALIDATE_BOOLEAN );
			$load_more_enabled = ! empty( $controls['load_more_enabled'] ) && filter_var( $controls['load_more_enabled'], FILTER_VALIDATE_BOOLEAN );
			$pages_show_all    = 0 === $pages_mid_size;
			$dots              = true;
			$is_frontend       = ! empty( $provider );

			echo '<nav class="jet-filters-pagination" aria-label="Pagination">';
				if ( $nav_enabled && ( ! $hide_inactive_nav || 1 !== $page ) ) {
					if ( $is_frontend ) {
						$prev_page = max( 1, $page - 1 );
						$disabled  = 1 === $page ? ' disabled aria-disabled="true"' : '';

						printf(
							'<a class="jet-filters-pagination__item prev-next prev" data-value="prev" rel="prev" href="%1$s"%2$s>',
							esc_url( $this->get_page_url( $prev_page, $provider, $query_id ) ),
							$disabled // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static attributes only.
						);
					} else {
						echo '<a class="jet-filters-pagination__item prev-next prev">';
					}

						echo wp_kses_post(
							jet_smart_filters()->utils->template_replace_with_value(
								'for-js/pagination/item.php',
								isset( $controls['prev'] ) ? $controls['prev'] : ''
							)
						);
					echo '</a>';
				}
				if ( $items_enabled ) {
					for ( $i = 1; $i <= $pages ; $i++ ) {
						$show_dots = ( $pages_end_size < $i && $i < $page - $pages_mid_size ) || ( $pages_end_size <= ( $pages - $i ) && $i > $page + $pages_mid_size );

						if ( ! $show_dots || $pages_show_all ) {
							$dots = true;
							if ( $page === $i ) {
								printf(
									'<div class="jet-filters-pagination__item jet-filters-pagination__current" data-value="%1$s" aria-current="page">',
									esc_attr( $i )
								);
									echo wp_kses_post(
										jet_smart_filters()->utils->template_replace_with_value(
											'for-js/pagination/item.php',
											$i
										)
									);
								echo '</div>';
							} else {
								if ( $is_frontend ) {
									printf(
										'<a class="jet-filters-pagination__item" data-value="%1$s" href="%2$s">',
										esc_attr( $i ),
										esc_url( $this->get_page_url( $i, $provider, $query_id ) )
									);
								} else {
									echo '<a class="jet-filters-pagination__item">';
								}

									echo wp_kses_post(
										jet_smart_filters()->utils->template_replace_with_value(
											'for-js/pagination/item.php',
											$i
										)
									);
								echo '</a>';
							}
						} elseif ( $dots ) {
							$dots = false;
							echo $is_frontend
								? '<div class="jet-filters-pagination__item">'
								: '<a class="jet-filters-pagination__item">';
								echo wp_kses_post(
									jet_smart_filters()->utils->get_template_html(
										'for-js/pagination/dots.php'
									)
								);
							echo $is_frontend ? '</div>' : '</a>';
						}
					}
				}
				if ( $nav_enabled && ( ! $hide_inactive_nav || $page !== $pages ) ) {
					if ( $is_frontend ) {
						$next_page = min( $pages, $page + 1 );
						$disabled  = $page === $pages ? ' disabled aria-disabled="true"' : '';

						printf(
							'<a class="jet-filters-pagination__item prev-next next" data-value="next" rel="next" href="%1$s"%2$s>',
							esc_url( $this->get_page_url( $next_page, $provider, $query_id ) ),
							$disabled // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static attributes only.
						);
					} else {
						echo '<a class="jet-filters-pagination__item prev-next next">';
					}

						echo wp_kses_post(
							jet_smart_filters()->utils->template_replace_with_value(
								'for-js/pagination/item.php',
								isset( $controls['next'] ) ? $controls['next'] : ''
							)
						);
					echo '</a>';
				}
				if ( $load_more_enabled && ( ! $is_frontend || $page < $pages ) ) {
					echo $is_frontend
						? '<div class="jet-filters-pagination__load-more" role="button">'
						: '<div class="jet-filters-pagination__load-more">';
						echo wp_kses_post(
							jet_smart_filters()->utils->template_replace_with_value(
								'for-js/pagination/load-more.php',
								isset( $controls['load_more_text'] ) ? $controls['load_more_text'] : ''
							)
						);
					echo '</div>';
				}
			echo '</nav>';
		}

		/**
		 * Build a pagination page URL.
		 *
		 * @param int    $page     Page number.
		 * @param string $provider Provider ID.
		 * @param string $query_id Provider query ID.
		 *
		 * @return string
		 */
		private function get_page_url( $page, $provider, $query_id ) {

			$args     = jet_smart_filters()->utils->get_current_filter_url_args( $provider, $query_id );
			$base_url = untrailingslashit( get_site_url() ) . '/' . ltrim( jet_smart_filters()->data->get_pagination_baseurl(), '/' );

			foreach ( $args as $key => $arg ) {
				if ( 'pagenum' === $arg['query_type'] ) {
					unset( $args[ $key ] );
				}
			}

			$args[] = array(
				'value'       => absint( $page ),
				'query_var'   => false,
				'query_type'  => 'pagination',
				'filter_type' => 'pagination',
			);

			$url = jet_smart_filters()->utils->get_filtered_url(
				$base_url,
				'default' === $query_id ? null : $query_id,
				$provider,
				$args,
				false
			);

			$third_party_args = jet_smart_filters()->utils->get_third_party_query_args();

			return $third_party_args ? add_query_arg( $third_party_args, $url ) : $url;
		}
	}
}
