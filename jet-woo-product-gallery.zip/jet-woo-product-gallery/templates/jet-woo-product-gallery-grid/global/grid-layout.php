<?php
/**
 * JetGallery Grid layout content.
 */

if ( ! isset( $video_state ) ) {
	$video_state = $this->get_video_position_state( $settings, $with_featured_image );
}

if ( ! isset( $video_display_in ) ) {
	$video_display_in = $video_state['video_display_type'];
}

if ( ! isset( $show_video_before_featured ) ) {
	$show_video_before_featured = $video_state['show_video_before_featured'];
}

if ( ! isset( $show_video_after_featured ) ) {
	$show_video_after_featured = $video_state['show_video_after_featured'];
}

if ( ! isset( $show_video_last ) ) {
	$show_video_last = $video_state['show_video_last'];
}

if ( ! isset( $video_in_primary ) ) {
	$video_in_primary = $is_primary_image && $with_featured_image && $show_video_before_featured;
}

if ( ! isset( $move_featured_to_grid ) ) {
	$move_featured_to_grid = $video_in_primary;
}

if ( ! $video_in_primary && $show_video_before_featured ) {
	include $this->get_global_template( 'video' );
}

if ( $move_featured_to_grid || ( ! $is_primary_image && $with_featured_image ) ) {
	if ( has_post_thumbnail( $post_id ) ) {
		include $this->get_global_template( 'image' );
	} else {
		$this->render_placeholder_image();
	}
}

if ( $show_video_after_featured ) {
	include $this->get_global_template( 'video' );
}

if ( ! empty( $attachment_ids ) ) {
	$visibility    = $this->get_grid_visibility( $attachment_ids, $grid_items_count );
	$visible_count = $visibility['visible_count'];
	$hidden_count  = $visibility['hidden_count'];

	$index_offset = 0;

	if ( ! $video_in_primary && $show_video_before_featured ) {
		$index_offset++;
	}

	if ( $move_featured_to_grid || ( ! $is_primary_image && $with_featured_image ) ) {
		$index_offset++;
	}

	if ( $show_video_after_featured ) {
		$index_offset++;
	}

	$index = 0;
	foreach ( $attachment_ids as $attachment_id ) {
		$index++;

		$vars = $this->prepare_thumbnail_data( $attachment_id, $index + $index_offset, $visible_count, $hidden_count );
		extract( $vars );

		include $this->get_global_template( 'thumbnails' );
	}
}

if ( $show_video_last ) {
	include $this->get_global_template( 'video' );
}

if ( 'popup' === $video_display_in ) {
	include $this->get_global_template( 'popup-video' );
}
