<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;


require_once(plugin_dir_path(__FILE__) . '../utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . 'TablesService.php');


use com\sakuraplugins\appetit\utils\TimeUtils;

class WaiterService {
    
    private $waiter_calls = [];
    const WAITER_CALLS_HISTORY_META_KEY = 'WAITER_CALLS_HISTORY_META_KEY';

    function __construct() {
        $this->waiter_calls = get_option(self::WAITER_CALLS_HISTORY_META_KEY, []);
    }

    public function addCall($tableNo) {
        if (sizeof($this->waiter_calls) > 100) {
            array_shift($this->waiter_calls);
        }

        $tableData = TablesService::getInstance()->getTable($tableNo);
        $tableDesc = $tableData['tableDesc'] ?? '';
        $table = $tableData['tableNo'] ?? '';

        if ($tableData) {
            array_push($this->waiter_calls, [
                'id' => uniqid(),
                'table' => $table,
                'tableDesc' => $tableDesc,
                'date' => TimeUtils::getInstance()->getDateNow()->format('Y-m-d h:i a'),
            ]);
            update_option(self::WAITER_CALLS_HISTORY_META_KEY, $this->waiter_calls, false);
        }
    }

    public function removeCall($id) {
        for ($i = 0; $i < sizeof($this->waiter_calls); $i++) { 
            if ($this->waiter_calls[$i]['id'] === $id) {
                array_splice($this->waiter_calls, $i, 1);
                break;
            }
        }
        update_option(self::WAITER_CALLS_HISTORY_META_KEY, $this->waiter_calls, false);
    }

    public function getAll() {
        $allCalls = array_reverse($this->waiter_calls);
        if (is_array($allCalls)) {
            foreach ($allCalls as $key => $value) {
                $tData = $value;
                $tData['table'] = isset($tData['table']) ? esc_html($tData['table']) : '';
                $tData['tableDesc'] = isset($tData['tableDesc']) ? esc_html($tData['tableDesc']) : '';
                $allCalls[$key] = $tData;
            }
        }
        return array_reverse($this->waiter_calls);
    }
}
?>