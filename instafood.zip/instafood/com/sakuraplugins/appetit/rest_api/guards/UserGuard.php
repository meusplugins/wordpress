<?php
namespace com\sakuraplugins\appetit\rest_api\guards;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'IGuard.php');
require_once(plugin_dir_path(__FILE__) . 'BaseGuard.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/UserManagement.php');

use com\sakuraplugins\appetit\utils\UserManagement;

class UserGuard extends BaseGuard implements IGuard {

    public static function validateRequest(\WP_REST_Request $request) {
        if (current_user_can(UserManagement::ORDERS_PAGE_CAP)) {
            return true;
        }
        
        return new \WP_REST_Response([
            'status' => 'FAIL',
            'data' => [],
            'errors' => [esc_html__('You can not access this endpoint', 'instafood')],
        ], 200);
    }
}
?>