<?php
namespace com\sakuraplugins\appetit\rest_api\guards;
if (!defined('ABSPATH')) exit;

interface IGuard {
    public static function validateRequest(\WP_REST_Request $request);
}
?>