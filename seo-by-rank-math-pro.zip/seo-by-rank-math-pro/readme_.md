S H A R E D       O N        W P L O C K E R .C O M 
