import LanguageUtils from '../../utils/LanguageUtils';
import Order from '../../order/Order';
import EventBus, { Event, Events } from '../../events/EventBus';

class ChoosePaymentWidget {

    _parrentUI;
    _ui;
    _staticHolderUI;
    _availablePaymentMethods = [];

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.render(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    render() {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        this._availablePaymentMethods = Order.getInstance().getAvailablePaymentMethods();
        const paymentMethodsNo = this._availablePaymentMethods.length;
        if (paymentMethodsNo === 0) {
            return;
        }

        let paymentMethodsHtml = '';
        for (let i = 0; i < this._availablePaymentMethods.length; i++) {
            
                let isSelected = paymentMethodsNo === 1 || Order.getInstance().getPaymentType() === this._availablePaymentMethods[i];

                let label = '';
                if (this._availablePaymentMethods[i] === 'cash_on_delivery') {
                    label = LanguageUtils.getInstance().getLabel('payment_method_cash');
                }
                if (this._availablePaymentMethods[i] === 'stripe') {
                    label = LanguageUtils.getInstance().getLabel('payment_method_stripe');
                }

                const payment_method_template = `
                <div class="product_widget delivery_widget local_delivery payment_type" data-payment-type="${ this._availablePaymentMethods[i] }">
                    <div class="widget_radio_entry ${ isSelected ? 'selected' : '' }">
                        <div class="radio_symbol primary_color_border"><div class="radio_fill primary_color_background show"></div></div>
                        <div class="variant_info">${ label }</div>
                    </div>
                </div>
                `;
                paymentMethodsHtml += payment_method_template;
        }

        const template = `
        <div class="apt_content_widget mt_20 bm_20 payment_method_widget">
            <div class="in_content">
                <div class="wgt_header space_btw">
                    <div class="wgt_title_ui">
                        <span class="icon-wallet wgt_icon"></span>
                        <div class="wgt_title">${ LanguageUtils.getInstance().getLabel('payment_method_wgt_title') }</div>
                    </div>
                </div>
                <div class="wgt_content mt_10">
                    <div class="wgt_mayment_methods">${ paymentMethodsHtml }</div>
                </div>
            </div>
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo(this._staticHolderUI);
        const _this = this;

        if (paymentMethodsNo === 1) {
            Order.getInstance().setPaymentType(this._availablePaymentMethods[0]);
            EventBus.getInstance().triggerEvent(Events.ORDER_PAYMENT_METHOD_CHANGED);
            return;
        }
        this._ui.find('.payment_type').each(function(index) {
            jQuery(this).click(function(event) {
                event.preventDefault();
                const pType = jQuery(this).attr('data-payment-type');
                Order.getInstance().setPaymentType(pType, true);
                _this._selectPaymentType(pType);
            })
        })
    }

    _selectPaymentType(pType) {
        this._ui.find('.payment_type').each(function(index) {
            if (jQuery(this).find('.widget_radio_entry').hasClass('selected')) {
                jQuery(this).find('.widget_radio_entry').removeClass('selected')
            }
            if (pType === jQuery(this).attr('data-payment-type')) {
                if (!jQuery(this).find('.widget_radio_entry').hasClass('selected')) {
                    jQuery(this).find('.widget_radio_entry').addClass('selected')
                }   
            }
        })
    }
}
export default ChoosePaymentWidget;