"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/**
 * Happy Addons Pro — Elementor V4 (Atomic) common runtime.
 *
 * Source modules concatenated by gulp (see gulpfile.mjs) into
 * happy-addons-atomic-pro.js: this file opens the closure, boot.js closes it,
 * and each feature file in between adds itself with addFeature().
 *
 * The Happy Addons Atomic runtime (window.HappyAtomic) finds the configured
 * elements on the frontend and in the editor preview and creates/destroys one
 * runtime object per element; Pro only registers its feature runtimes there.
 */
(function (w, d) {
  'use strict';

  var atomic = w.HappyAtomic;
  if (!atomic || !atomic.api || typeof atomic.registerFeature !== 'function') {
    return;
  }
  var reducedMotion = atomic.api.reducedMotion;
  var isEditor = atomic.api.isEditor;
  var isMobile = atomic.api.isMobile;
  var num = atomic.api.num;
  var features = [];
  function addFeature(feature) {
    features.push(feature);
  }

  /* ------------------------------------------------------------------ *
   * Infinite Marquee (e-flexbox, e-div-block, e-grid)
   *
   * Frontend: the container's children move into a track and are cloned
   * until the loop is seamless. Editor: the originals stay (hidden) so the
   * editor keeps working with them; only clones run in the track.
   * ------------------------------------------------------------------ */
  var AMQ_MAX_SETS = 20;
  var AMQ_SKIP_TAGS = /^(SCRIPT|STYLE|TEMPLATE|LINK)$/;
  function InfiniteMarquee(el, config) {
    this.el = el;
    this.config = config;
    this.editMode = isEditor();
    this.track = null;
    this.originals = [];
    this.anim = null;
    this.rafId = null;
    this.observer = null;
    this.debounce = null;
    this.listeners = [];
    this.saved = null;
    this.built = false;
    this.lastWidth = el.clientWidth;
    var self = this;
    this.onResize = function () {
      clearTimeout(self.resizeTimer);
      self.resizeTimer = setTimeout(function () {
        if (self.el.clientWidth !== self.lastWidth) {
          self.rebuild();
        }
      }, 250);
    };
    w.addEventListener('resize', this.onResize);
    if ('complete' !== d.readyState) {
      this.onLoad = function () {
        self.rebuild();
      };
      w.addEventListener('load', this.onLoad);
    }
    this.build();
  }
  InfiniteMarquee.prototype.items = function () {
    var editMode = this.editMode;
    return Array.prototype.filter.call(this.el.children, function (node) {
      if (node.classList.contains('ha-amq-content') || AMQ_SKIP_TAGS.test(node.tagName)) {
        return false;
      }

      // The editor adds its own helpers next to the elements; only elements have a data-id.
      return !editMode || node.hasAttribute('data-id');
    });
  };
  InfiniteMarquee.prototype.reveal = function () {
    this.el.style.visibility = 'visible';
  };
  InfiniteMarquee.prototype.build = function () {
    var el = this.el;
    var config = this.config;
    var editMode = this.editMode;
    if (reducedMotion() || isMobile() && !config.enable_on_mobile || editMode && config.disable_in_editor) {
      this.reveal();
      return;
    }
    var originals = this.items();
    if (!originals.length) {
      this.reveal();
      if (editMode) {
        this.observe();
      }
      return;
    }
    var vertical = 'vertical' === config.mode;
    var sizes = [];
    if (editMode) {
      var rendered = false;
      originals.forEach(function (node) {
        var rect = node.getBoundingClientRect();
        if (rect.width > 1 || rect.height > 1) {
          rendered = true;
        }
      });

      // The editor has not laid the elements out yet; retry when it does.
      if (!rendered) {
        this.observe();
        return;
      }
    }
    originals.forEach(function (node) {
      var rect = node.getBoundingClientRect();
      sizes.push(vertical ? rect.height : rect.width);
    });
    var containerSize = vertical ? el.clientHeight : el.clientWidth;
    this.originals = originals;
    this.saved = {
      elStyle: el.getAttribute('style'),
      itemStyles: originals.map(function (node) {
        return node.getAttribute('style');
      })
    };
    this.lastWidth = el.clientWidth;
    el.classList.add('ha-amq-container');
    el.classList.toggle('is-vertical', vertical);
    el.classList.toggle('ha-amq-pause', !!config.pause_hover);
    var isArc = !!config.elips && !vertical;
    el.classList.toggle('ha-amq-arc', isArc);
    var track = d.createElement('div');
    track.className = 'ha-amq-content';
    track.style.gap = Math.max(0, num(config.gap_between_iem, 5)) + 'px';
    this.track = track;
    var makeClone = function makeClone(node, size) {
      var clone = node.cloneNode(true);
      clone.removeAttribute('data-id');
      clone.removeAttribute('id');
      clone.setAttribute('aria-hidden', 'true');
      clone.querySelectorAll('[data-id]').forEach(function (child) {
        child.removeAttribute('data-id');
      });
      clone.querySelectorAll('[id]').forEach(function (child) {
        child.removeAttribute('id');
      });
      clone.classList.add('ha-amq-item');
      if (size > 0) {
        clone.style.flex = '0 0 ' + size + 'px';
      }
      return clone;
    };

    // The first set: the real elements (frontend) or their clones (editor).
    originals.forEach(function (node, i) {
      var item = editMode ? makeClone(node, sizes[i]) : node;
      if (!editMode) {
        node.classList.add('ha-amq-item');
        if (sizes[i] > 0) {
          node.style.flex = '0 0 ' + sizes[i] + 'px';
        }
      }
      track.appendChild(item);
    });
    if (vertical && containerSize > 0 && !editMode) {
      el.style.height = containerSize + 'px';
    }
    el.appendChild(track);

    // Distance between a set and the next one, measured with a probe copy.
    var first = track.children[0];
    var probe = first.cloneNode(true);
    track.appendChild(probe);
    var firstRect = first.getBoundingClientRect();
    var probeRect = probe.getBoundingClientRect();
    var setSize = Math.round(Math.abs(vertical ? probeRect.top - firstRect.top : probeRect.left - firstRect.left));
    track.removeChild(probe);
    if (setSize < 1) {
      setSize = 1;
    }
    var sets = Math.min(AMQ_MAX_SETS, Math.max(1, Math.ceil(containerSize / setSize)));
    var copies = sets * 2 + (vertical ? 1 : 0);
    for (var s = 1; s < copies; s++) {
      originals.forEach(function (node, i) {
        track.appendChild(makeClone(node, sizes[i]));
      });
    }
    if (editMode) {
      el.style.position = 'relative';
      if (vertical && containerSize > 0) {
        el.style.height = containerSize + 'px';
      }
      originals.forEach(function (node) {
        node.style.position = 'absolute';
        node.style.visibility = 'hidden';
        node.style.pointerEvents = 'none';
      });
    }
    var loopSize = setSize * sets;
    var speed = Math.max(1, num(config.speed, 120));
    var direction = vertical ? config.vertical_direction || 'top' : config.horizontal_direction || 'left';
    var backwards = 'left' === direction || 'top' === direction;
    this.built = true;
    if (isArc) {
      this.startArc(setSize, speed, 'left' === direction);
    } else {
      this.startLoop(vertical, backwards ? 0 : -loopSize, backwards ? -loopSize : 0, loopSize / speed);
    }
    this.reveal();
    if (editMode) {
      this.observe();
    }
  };
  InfiniteMarquee.prototype.listen = function (target, type, handler) {
    target.addEventListener(type, handler);
    this.listeners.push([target, type, handler]);
  };

  /**
   * Straight marquee: one endless linear animation of the track.
   */
  InfiniteMarquee.prototype.startLoop = function (vertical, from, to, seconds) {
    var track = this.track;
    var frame = function frame(value) {
      return {
        transform: vertical ? 'translate3d(0,' + value + 'px,0)' : 'translate3d(' + value + 'px,0,0)'
      };
    };
    this.anim = track.animate([frame(from), frame(to)], {
      duration: seconds * 1000,
      iterations: Infinity,
      easing: 'linear'
    });
    if (this.config.pause_hover) {
      var anim = this.anim;
      this.listen(this.el, 'mouseenter', function () {
        anim.pause();
      });
      this.listen(this.el, 'mouseleave', function () {
        anim.play();
      });
    }
  };

  /**
   * Arc marquee: a per-frame loop that also curves, scales, rotates, fades
   * and blurs each item by its distance from the container center.
   */
  InfiniteMarquee.prototype.startArc = function (setSize, speed, toLeft) {
    var self = this;
    var config = this.config;
    var el = this.el;
    var track = this.track;
    var items = Array.prototype.slice.call(track.children);
    var curve = num(config.elips_curve, 130);
    var zoom = !!config.elips_zoom;
    var rotate = !!config.elips_rotate;
    var fade = !!config.elips_fade;
    var blur = !!config.elips_blur;
    var scrollEffect = !!config.scroll_effect;
    var minScale = 0.5;
    var maxScale = 1;

    // Items often carry their own transitions, which would fight the per-frame transforms.
    items.forEach(function (item) {
      item.style.setProperty('transition', 'none', 'important');
    });

    // Item centers relative to the track, measured before any transform.
    var trackLeft = track.getBoundingClientRect().left;
    var centers = items.map(function (item) {
      var rect = item.getBoundingClientRect();
      return rect.left + rect.width / 2 - trackLeft;
    });
    var scrollX = toLeft ? 0 : -setSize;
    var paused = false;
    var last = performance.now();
    var mult = 1;
    var targetMult = 1;
    var lastScrollY = w.scrollY || 0;
    var _render = function render(now) {
      if (!track.isConnected) {
        return;
      }
      var dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (scrollEffect) {
        var scrollY = w.scrollY || 0;
        var delta = scrollY - lastScrollY;
        lastScrollY = scrollY;
        if (Math.abs(delta) > 0.5 && dt > 0) {
          targetMult = 1 + Math.max(-8, Math.min(8, delta / (dt * 1000))) * 12;
        } else {
          targetMult += (1 - targetMult) * 0.02;
        }
        mult += (targetMult - mult) * 0.04;
      }
      if (!paused) {
        scrollX += (toLeft ? -1 : 1) * speed * dt * mult;
        while (scrollX <= -setSize) {
          scrollX += setSize;
        }
        while (scrollX > 0) {
          scrollX -= setSize;
        }
      }
      track.style.transform = 'translate3d(' + scrollX + 'px,0,0)';
      var box = el.getBoundingClientRect();
      var half = box.width / 2;
      var centerX = box.left + half;
      var left = track.getBoundingClientRect().left;
      for (var i = 0; i < items.length; i++) {
        var norm = half > 0 ? (left + centers[i] - centerX) / half : 0;
        var dist = Math.abs(Math.max(-1, Math.min(1, norm)));
        var style = items[i].style;
        var angle = rotate && half > 0 ? Math.atan(2 * curve * norm / half) * 180 / Math.PI : 0;
        var scale = zoom ? maxScale - dist * (maxScale - minScale) : 1;
        style.transform = 'translate3d(0,' + norm * norm * curve + 'px,0) scale(' + scale + ') rotate(' + angle + 'deg)';
        if (fade) {
          style.opacity = 1 - dist * 0.35;
        }
        if (blur) {
          style.filter = dist > 0.7 ? 'blur(' + (dist - 0.7) * 4 + 'px)' : '';
        }
        style.zIndex = String(Math.round((1 - dist) * 100));
      }
      self.rafId = requestAnimationFrame(_render);
    };
    this.arcItems = items;
    _render(performance.now());
    if (config.pause_hover) {
      this.listen(el, 'mouseenter', function () {
        paused = true;
      });
      this.listen(el, 'mouseleave', function () {
        paused = false;
        last = performance.now();
      });
    }
  };

  // Editor only: rebuild when the editor re-renders the container's elements.
  InfiniteMarquee.prototype.observe = function () {
    if (this.observer || 'undefined' === typeof MutationObserver) {
      return;
    }
    var self = this;
    this.observer = new MutationObserver(function (mutations) {
      var relevant = mutations.some(function (mutation) {
        return mutation.addedNodes.length || mutation.removedNodes.length;
      });
      if (!relevant) {
        return;
      }
      clearTimeout(self.debounce);
      self.debounce = setTimeout(function () {
        self.rebuild();
      }, 400);
    });
    this.observer.observe(this.el, {
      childList: true,
      subtree: true
    });
  };
  InfiniteMarquee.prototype.isStale = function () {
    return this.built && !!this.track && !this.track.isConnected;
  };
  InfiniteMarquee.prototype.rebuild = function () {
    if (!this.el.isConnected) {
      return;
    }
    this.teardown(true);
    this.build();
  };

  // Stops everything running, without touching the DOM.
  InfiniteMarquee.prototype.halt = function () {
    clearTimeout(this.debounce);
    clearTimeout(this.resizeTimer);
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    if (this.anim) {
      this.anim.cancel();
      this.anim = null;
    }
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    this.listeners.forEach(function (item) {
      item[0].removeEventListener(item[1], item[2]);
    });
    this.listeners = [];
  };

  // The editor replaced the markup: stop without restoring the old one over it.
  InfiniteMarquee.prototype.abandon = function () {
    this.halt();
    w.removeEventListener('resize', this.onResize);
    if (this.onLoad) {
      w.removeEventListener('load', this.onLoad);
    }
    this.built = false;
    this.track = null;
    this.reveal();
  };
  InfiniteMarquee.prototype.teardown = function (keepWindowListeners) {
    var el = this.el;
    var saved = this.saved;
    this.halt();
    if (this.arcItems) {
      this.arcItems.forEach(function (item) {
        ['transform', 'opacity', 'filter', 'zIndex'].forEach(function (prop) {
          item.style[prop] = '';
        });
        item.style.removeProperty('transition');
      });
      this.arcItems = null;
    }
    if (this.track && saved) {
      var track = this.track;
      var restore = function restore(node, style) {
        if (null === style) {
          node.removeAttribute('style');
        } else {
          node.setAttribute('style', style);
        }
      };
      this.originals.forEach(function (node, i) {
        node.classList.remove('ha-amq-item');
        restore(node, saved.itemStyles[i]);

        // Frontend: the originals live in the track; put them back.
        if (node.parentNode === track) {
          el.insertBefore(node, track);
        }
      });
      if (track.parentNode) {
        track.parentNode.removeChild(track);
      }
      restore(el, saved.elStyle);
    }
    el.classList.remove('ha-amq-container', 'is-vertical', 'ha-amq-pause', 'ha-amq-arc');
    this.track = null;
    this.originals = [];
    this.saved = null;
    this.built = false;
    if (!keepWindowListeners) {
      w.removeEventListener('resize', this.onResize);
      if (this.onLoad) {
        w.removeEventListener('load', this.onLoad);
      }
    }
  };
  InfiniteMarquee.prototype.destroy = function () {
    this.teardown(false);
    this.reveal();
  };
  addFeature({
    key: 'infinite-marquee',
    type: ['e-flexbox', 'e-div-block', 'e-grid'],
    prefix: 'ha_im_',
    Runtime: InfiniteMarquee,
    target: function target(node) {
      return node;
    }
  });

  /* ------------------------------------------------------------------ *
   * Horizontal Scroll (e-flexbox, e-div-block, e-grid)
   *
   * Frontend only (a pinned ScrollTrigger cannot run inside the editor
   * preview, same as Classic). The container's children move into a track
   * that slides sideways while the container is pinned. Desktop only.
   * ------------------------------------------------------------------ */
  var AHS_SETTLE_DELAY = 300;
  var AHS_SKIP_TAGS = /^(SCRIPT|STYLE|TEMPLATE|LINK)$/;
  var AHS_DESKTOP = '(min-width: 1025px)';
  function HorizontalScroll(el, config) {
    this.el = el;
    this.config = config;
    this.track = null;
    this.items = [];
    this.tween = null;
    this.geom = null;
    this.saved = null;
    this.refreshTimer = null;
    this.observer = null;
    this.lastWidth = 0;
    this.media = w.matchMedia ? w.matchMedia(AHS_DESKTOP) : null;
    var self = this;
    this.onRefresh = function () {
      self.scheduleRefresh();
    };
    this.onViewport = function () {
      clearTimeout(self.viewportTimer);
      self.viewportTimer = setTimeout(function () {
        self.reconcile();
      }, 120);
    };
    w.addEventListener('resize', this.onViewport);
    w.addEventListener('orientationchange', this.onViewport);
    if (this.media && this.media.addEventListener) {
      this.media.addEventListener('change', this.onViewport);
    }
    if ('complete' !== d.readyState) {
      w.addEventListener('load', this.onRefresh);
    }
    this.build();
  }
  HorizontalScroll.prototype.reveal = function () {
    this.el.style.visibility = 'visible';
  };
  HorizontalScroll.prototype.isDesktop = function () {
    return this.media ? this.media.matches : w.innerWidth >= 1025;
  };
  HorizontalScroll.prototype.panels = function () {
    return Array.prototype.filter.call(this.el.children, function (node) {
      return !node.classList.contains('ha-ahs-inner') && !AHS_SKIP_TAGS.test(node.tagName);
    });
  };
  HorizontalScroll.prototype.measure = function () {
    var track = this.track;
    var width = this.el.offsetWidth;
    if (!track || width < 1 || !this.items.length) {
      return null;
    }
    var auto = this.el.classList.contains('ha-ahs-auto-width');
    var total = auto ? track.scrollWidth : width * this.items.length;
    return {
      width: width,
      total: total,
      max: Math.max(0, total - width),
      auto: auto
    };
  };
  HorizontalScroll.prototype.applyGeometry = function () {
    var geom = this.measure();
    if (!geom) {
      return null;
    }
    this.geom = geom;
    if (!geom.auto) {
      this.track.style.width = geom.total + 'px';
    }
    return geom;
  };
  HorizontalScroll.prototype.getGeometry = function () {
    return this.geom || this.applyGeometry() || {
      width: 0,
      total: 0,
      max: 0,
      auto: false
    };
  };
  HorizontalScroll.prototype.fromX = function () {
    return 'right' === this.config.direction ? -this.getGeometry().max : 0;
  };
  HorizontalScroll.prototype.toX = function () {
    return 'right' === this.config.direction ? 0 : -this.getGeometry().max;
  };

  // No horizontal overflow means no pin distance, so no phantom whitespace.
  HorizontalScroll.prototype.distance = function () {
    var geom = this.getGeometry();
    return geom.max > 0 ? geom.total : 0;
  };
  HorizontalScroll.prototype.build = function () {
    var el = this.el;
    if (reducedMotion() || isEditor() || !this.isDesktop() || typeof ScrollTrigger === 'undefined') {
      this.reveal();
      return;
    }
    var items = this.panels();

    // A single panel has nothing to slide.
    if (items.length < 2) {
      this.reveal();
      return;
    }
    this.items = items;
    this.saved = {
      elClass: el.classList.contains('ha-ahs-wrapper'),
      itemStyles: items.map(function (node) {
        return node.getAttribute('style');
      })
    };
    var track = d.createElement('div');
    track.className = 'ha-ahs-inner';
    this.track = track;
    el.classList.add('ha-ahs-wrapper');
    el.classList.toggle('ha-ahs-auto-width', !!this.config.enable_auto_width);
    items.forEach(function (node) {
      node.classList.add('ha-ahs-item');
      track.appendChild(node);
    });
    el.appendChild(track);
    this.lastWidth = el.offsetWidth;
    var geom = this.applyGeometry();
    if (!geom) {
      this.teardown(true);
      this.reveal();
      return;
    }
    var self = this;
    var snap = !!this.config.snap_scroll && items.length > 1 ? 1 / (items.length - 1) : 0;
    var offset = Math.max(0, num(this.config.start_offset, 0));
    gsap.set(track, {
      x: this.fromX()
    });
    this.tween = gsap.fromTo(track, {
      x: function x() {
        return self.fromX();
      }
    }, {
      x: function x() {
        return self.toX();
      },
      ease: 'none',
      scrollTrigger: {
        trigger: el,
        start: 'top top+=' + offset,
        end: function end() {
          return '+=' + self.distance();
        },
        pin: true,
        scrub: 1,
        snap: snap,
        anticipatePin: 1,
        invalidateOnRefresh: true,
        // Re-measure before ScrollTrigger reads start/end, so stale values are never reused.
        onRefreshInit: function onRefreshInit() {
          self.geom = null;
          self.applyGeometry();
        }
      }
    });
    this.observe();
    this.reveal();
    this.scheduleRefresh();
  };

  // Width-only observer: height changes while pinned must not trigger refreshes.
  HorizontalScroll.prototype.observe = function () {
    if ('undefined' === typeof ResizeObserver || this.observer) {
      return;
    }
    var self = this;
    this.observer = new ResizeObserver(function () {
      var width = Math.round(self.el.offsetWidth);
      if (width !== self.lastWidth) {
        self.lastWidth = width;
        self.scheduleRefresh();
      }
    });
    this.observer.observe(this.el);
  };
  HorizontalScroll.prototype.scheduleRefresh = function () {
    var self = this;
    clearTimeout(this.refreshTimer);
    this.refreshTimer = setTimeout(function () {
      self.refreshTimer = null;
      if (!self.tween || !self.el.isConnected) {
        return;
      }
      self.geom = null;
      self.applyGeometry();
      ScrollTrigger.refresh();
    }, AHS_SETTLE_DELAY);
  };

  // Enter/leave the desktop layout without a page reload.
  HorizontalScroll.prototype.reconcile = function () {
    if (!this.el.isConnected) {
      return;
    }
    if (!this.isDesktop()) {
      if (this.track) {
        this.teardown(true);
      }
      this.reveal();
      return;
    }
    if (!this.track) {
      this.build();
      return;
    }
    this.scheduleRefresh();
  };

  // Stops the animation and puts the children back, without touching listeners.
  HorizontalScroll.prototype.teardown = function (keepListeners) {
    var el = this.el;
    var track = this.track;
    var saved = this.saved;
    clearTimeout(this.refreshTimer);
    this.refreshTimer = null;
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    if (this.tween) {
      if (this.tween.scrollTrigger) {
        this.tween.scrollTrigger.kill(true);
      }
      this.tween.kill();
      this.tween = null;
    }
    if (track) {
      gsap.set(track, {
        clearProps: 'transform,width'
      });
      this.items.forEach(function (node, i) {
        node.classList.remove('ha-ahs-item');
        if (saved) {
          if (null === saved.itemStyles[i]) {
            node.removeAttribute('style');
          } else {
            node.setAttribute('style', saved.itemStyles[i]);
          }
        }
        if (node.parentNode === track) {
          el.insertBefore(node, track);
        }
      });
      if (track.parentNode) {
        track.parentNode.removeChild(track);
      }
    }
    el.classList.remove('ha-ahs-wrapper', 'ha-ahs-auto-width');
    this.track = null;
    this.items = [];
    this.geom = null;
    this.saved = null;
    if (!keepListeners) {
      clearTimeout(this.viewportTimer);
      w.removeEventListener('resize', this.onViewport);
      w.removeEventListener('orientationchange', this.onViewport);
      w.removeEventListener('load', this.onRefresh);
      if (this.media && this.media.removeEventListener) {
        this.media.removeEventListener('change', this.onViewport);
      }
    }
  };
  HorizontalScroll.prototype.destroy = function () {
    this.teardown(false);
    this.reveal();
  };
  addFeature({
    key: 'horizontal-scroll',
    prefix: 'ha_hs_',
    Runtime: HorizontalScroll
  });

  /* ------------------------------------------------------------------ *
   * Image Trails (e-flexbox, e-div-block, e-grid)
   *
   * Port of happy-image-trails.js: the container follows the pointer and
   * flies the trail images out behind it (Normal) or drops them (Falling),
   * with an optional magic cursor. The sizes and colors reach the CSS as
   * custom properties on the overlay, because the GSAP tweens clear the
   * inline styles of the images.
   * ------------------------------------------------------------------ */
  var IT_UA_MOBILE = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
  function itUnwrap(value) {
    while (value && 'object' === _typeof(value) && '$$type' in value) {
      value = value.value;
    }
    return value;
  }

  // Frontend: URLs from PHP. Editor: the "ha-image-item" props of the settings,
  // whose library images carry only the attachment id (a number here).
  function itImageUrls(list) {
    return (Array.isArray(list) ? list : []).map(function (item) {
      if ('string' === typeof item) {
        return item;
      }
      var value = itUnwrap(item);
      var image = value && itUnwrap(value.image);
      var src = image && itUnwrap(image.src);
      var url = src && 'object' === _typeof(src) ? itUnwrap(src.url) : src;
      if ('string' === typeof url && url) {
        return url;
      }
      var id = src && 'object' === _typeof(src) ? itUnwrap(src.id) : null;
      return id ? Number(id) : '';
    }).filter(Boolean);
  }

  // Turns the attachment ids into URLs through the editor's media library.
  function itResolveUrls(items, done) {
    var media = w.parent && w.parent.wp && w.parent.wp.media || w.wp && w.wp.media;
    var urls = new Array(items.length);
    var pending = 0;
    items.forEach(function (item, index) {
      if ('string' === typeof item) {
        urls[index] = item;
        return;
      }
      var attachment = media && media.attachment ? media.attachment(item) : null;
      if (!attachment) {
        return;
      }
      if (attachment.get('url')) {
        urls[index] = attachment.get('url');
        return;
      }
      pending++;
      attachment.fetch().always(function () {
        urls[index] = attachment.get('url') || '';
        if (! --pending) {
          done(urls.filter(Boolean));
        }
      });
    });
    if (!pending) {
      done(urls.filter(Boolean));
    }
  }
  function itLerp(a, b, n) {
    return (1 - n) * a + n * b;
  }

  // Resolved URLs per element: an editor rebuild (every setting change or
  // re-render drops the overlay) reuses them and remounts synchronously,
  // without another media fetch or imagesLoaded wait.
  var itUrlCache = new WeakMap();

  // Relative to the overlay the images are positioned in, read fresh on every
  // move: the editor preview scrolls and re-lays out under a still pointer.
  function itPointerPos(ev, container) {
    var rect = container.getBoundingClientRect();
    return {
      x: ev.clientX - rect.left,
      y: ev.clientY - rect.top
    };
  }
  function itFall(img, containerHeight, rotationDuration) {
    gsap.timeline().from(img, {
      opacity: 0,
      scale: 0,
      ease: 'elastic.out(1,0.3)'
    }).to(img, {
      rotation: 'random([-360, 360])',
      duration: rotationDuration,
      ease: 'power1'
    }, '<').to(img, {
      y: '+=' + (containerHeight + 200),
      ease: 'back.in(.4)',
      duration: 1
    }, 0);
  }
  function ImageTrails(el, config) {
    this.el = el;
    this.config = config;
    this.editMode = isEditor();
    this.content = null;
    this.cursor = null;
    this.images = [];
    this.listeners = [];
    this.rafId = null;
    this.cursorRafId = null;
    this.destroyed = false;
    this.started = false;
    this.inside = false;
    this.imageIndex = 0;
    this.mouse = {
      x: 0,
      y: 0
    };
    this.lastMouse = {
      x: 0,
      y: 0
    };
    this.cacheMouse = {
      x: 0,
      y: 0
    };
    this.zIndex = 1;
    this.editorObserver = null;
    this.remountTimer = null;
    this.inlinePosition = false;
    this.build();
  }
  ImageTrails.prototype.listen = function (target, type, handler, options) {
    target.addEventListener(type, handler, options);
    this.listeners.push([target, type, handler]);
  };

  // The editor re-renders the element and drops the overlay.
  ImageTrails.prototype.isStale = function () {
    if (!this.content) {
      return false;
    }
    if (!this.el.contains(this.content)) {
      return true;
    }

    // A re-render of the class attribute only drops the class: put it back.
    this.el.classList.add('ha-it-yes');
    return false;
  };
  ImageTrails.prototype.abandon = function () {
    this.teardown();
  };

  // Editor only: the editor re-renders the element on every edit. The class
  // attribute comes back without the runtime's class, and sometimes the whole
  // markup (and the overlay with it) is replaced. Recover at once instead of
  // waiting for the shared lifecycle poll (up to half a second away).
  ImageTrails.prototype.watchEditorRender = function () {
    if (this.editorObserver || 'undefined' === typeof MutationObserver) {
      return;
    }
    var self = this;
    this.editorObserver = new MutationObserver(function () {
      if (self.destroyed || !self.content) {
        return;
      }

      // Only the class was rewritten: put the runtime class back.
      if (self.el.contains(self.content)) {
        if (!self.el.classList.contains('ha-it-yes')) {
          self.el.classList.add('ha-it-yes');
        }
        return;
      }

      // The markup was replaced and the overlay dropped: rebuild.
      clearTimeout(self.remountTimer);
      self.remountTimer = setTimeout(function () {
        self.remount();
      }, 100);
    });
    this.editorObserver.observe(this.el, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
  };

  // Editor only: rebuild from the cached URLs, so the overlay returns in the
  // same frame the editor dropped it.
  ImageTrails.prototype.remount = function () {
    var cache = itUrlCache.get(this.el);
    if (this.destroyed || !this.editMode || !cache || !cache.urls.length) {
      return;
    }
    this.teardown();
    this.destroyed = false;
    this.build();
  };
  ImageTrails.prototype.build = function () {
    var c = this.config;
    var items = itImageUrls(c.images);
    var self = this;
    var cache = itUrlCache.get(this.el);
    var key = JSON.stringify(items);
    if (!items.length || reducedMotion() || IT_UA_MOBILE.test(w.navigator.userAgent) || this.editMode && !c.show_in_editor) {
      return;
    }

    // The same images as before (an editor rebuild): mount at once.
    if (cache && cache.key === key && cache.urls.length) {
      this.mount(cache.urls, true);
      return;
    }
    itResolveUrls(items, function (urls) {
      if (urls.length && !self.destroyed && !self.content) {
        itUrlCache.set(self.el, {
          key: key,
          urls: urls
        });
        self.mount(urls, false);
      }
    });
  };
  ImageTrails.prototype.mount = function (urls, ready) {
    var el = this.el;
    var c = this.config;
    var self = this;
    var content = d.createElement('div');
    content.className = 'ha-it-content';
    content.style.setProperty('--ha-it-width', num(c.image_width, 250) + 'px');
    content.style.setProperty('--ha-it-height', num(c.image_height, 0) > 0 ? num(c.image_height, 0) + 'px' : 'auto');
    content.style.setProperty('--ha-it-ratio', num(c.image_height, 0) > 0 ? 'auto' : '1');
    content.style.setProperty('--ha-it-radius', num(c.image_radius, 10) + 'px');
    content.style.setProperty('--ha-it-z-index', String(Math.round(num(c.image_z_index, 1))));
    urls.forEach(function (url) {
      var img = d.createElement('div');
      var inner = d.createElement('div');
      img.className = 'ha-it-content__img';
      inner.className = 'ha-it-content__img-inner';
      inner.style.backgroundImage = 'url("' + url.replace(/[\"\\]/g, encodeURIComponent) + '")';
      img.appendChild(inner);
      content.appendChild(img);
    });
    el.classList.add('ha-it-yes');
    content.classList.toggle('is-falling', 'falling' === c.trail_style);
    el.insertBefore(content, el.firstChild);
    this.content = content;
    this.zIndex = Math.round(num(c.image_z_index, 1));
    Array.prototype.forEach.call(content.children, function (node) {
      self.images.push({
        el: node,
        rect: node.getBoundingClientRect()
      });
    });
    this.onMove = function (ev) {
      self.mouse = itPointerPos(ev.touches ? ev.touches[0] : ev, self.content || el);
      if (self.content) {
        el.classList.add('ha-it-yes');
        self.content.classList.add('is-active');
        self.startLoop();
      }
    };
    this.onFirstMove = function () {
      self.startLoop();
    };
    var inners = Array.prototype.slice.call(content.querySelectorAll('.ha-it-content__img-inner'));
    if ('function' === typeof w.imagesLoaded && !ready) {
      w.imagesLoaded(inners, {
        background: true
      }, function () {
        self.start();
      });
    } else {
      this.start();
    }
    if (c.cursor) {
      this.buildCursor();
    }

    // The editor re-renders the element on every edit: keep the overlay
    // anchored and bring it back at once when the markup is replaced.
    if (this.editMode) {
      if ('static' === w.getComputedStyle(el).position) {
        el.style.position = 'relative';
        this.inlinePosition = true;
      }
      this.watchEditorRender();

      // A remount while the pointer already hovers: the trail stays live
      // without waiting for the next mousemove.
      if (el.matches(':hover')) {
        content.classList.add('is-active');
        if (this.rafId) {
          cancelAnimationFrame(this.rafId);
          this.rafId = null;
        }
        this.startLoop();
      }
    }
  };
  ImageTrails.prototype.start = function () {
    var el = this.el;
    var self = this;
    if (this.destroyed || this.started) {
      return;
    }
    this.started = true;
    this.listen(el, 'mousemove', this.onMove);
    this.listen(el, 'touchmove', this.onMove, {
      passive: true
    });
    this.listen(el, 'mousemove', this.onFirstMove);
    this.listen(el, 'mouseenter', function () {
      if (self.content) {
        self.content.classList.add('is-active');
      }
    });
    this.listen(el, 'mouseleave', function () {
      if (self.content) {
        self.content.classList.remove('is-active');
      }
      self.hovering = false;
    });
  };

  // The loop runs only while the pointer is over the container.
  ImageTrails.prototype.startLoop = function () {
    var self = this;
    if (this.rafId || this.destroyed) {
      return;
    }
    this.cacheMouse = {
      x: this.mouse.x,
      y: this.mouse.y
    };
    this.hovering = true;
    this.rafId = requestAnimationFrame(function () {
      self.render();
    });
  };
  ImageTrails.prototype.render = function () {
    if (this.destroyed) {
      return;
    }
    if (!this.hovering) {
      this.rafId = null;
      return;
    }
    var threshold = num(this.config.threshold, 80);
    this.cacheMouse.x = itLerp(this.cacheMouse.x, this.mouse.x, 0.1);
    this.cacheMouse.y = itLerp(this.cacheMouse.y, this.mouse.y, 0.1);
    if (Math.hypot(this.mouse.x - this.lastMouse.x, this.mouse.y - this.lastMouse.y) > threshold) {
      this.showNext();
      this.lastMouse = {
        x: this.mouse.x,
        y: this.mouse.y
      };
    }
    var self = this;
    this.rafId = requestAnimationFrame(function () {
      self.render();
    });
  };
  ImageTrails.prototype.showNext = function () {
    var c = this.config;
    var img = this.images[this.imageIndex % this.images.length];
    var duration = num(c.animation_duration, 0.4);
    this.imageIndex++;
    gsap.killTweensOf(img.el);
    gsap.set(img.el, {
      clearProps: 'all'
    });
    if ('falling' === c.trail_style) {
      gsap.set(img.el, {
        opacity: 1,
        left: this.cacheMouse.x,
        top: this.cacheMouse.y,
        xPercent: -50,
        yPercent: -50,
        position: 'absolute'
      });
      itFall(img.el, this.el.offsetHeight, num(c.rotation_duration, 0.5));
      return;
    }
    gsap.set(img.el, {
      opacity: num(c.image_opacity, 1),
      scale: 1,
      zIndex: ++this.zIndex,
      x: this.cacheMouse.x - img.rect.width / 2,
      y: this.cacheMouse.y - img.rect.height / 2
    });
    gsap.timeline().to(img.el, {
      duration: duration,
      ease: 'power1',
      x: this.mouse.x - img.rect.width / 2,
      y: this.mouse.y - img.rect.height / 2
    }, 0).to(img.el, {
      duration: duration,
      ease: 'power3',
      opacity: 0,
      scale: 0.2
    }, duration);
  };
  ImageTrails.prototype.buildCursor = function () {
    var el = this.el;
    var c = this.config;
    var self = this;
    var cursor = d.createElement('div');
    var ball = d.createElement('div');
    var delayed = {
      x: 0,
      y: 0
    };
    var mouse = {
      x: 0,
      y: 0
    };
    cursor.className = 'ha-it-cursor';
    ball.className = 'ha-it-cursor__ball';
    ball.style.opacity = '0';
    ball.style.width = num(c.cursor_width, 14) + 'px';
    ball.style.height = num(c.cursor_height, 14) + 'px';
    ball.style.backgroundColor = c.cursor_color || '#FF535B';
    ball.style.borderRadius = num(c.cursor_radius, 50) + '%';
    ball.style.transition = 'width ' + num(c.cursor_transition, 0.3) + 's ease, height ' + num(c.cursor_transition, 0.3) + 's ease, background-color ' + num(c.cursor_transition, 0.3) + 's ease';
    cursor.appendChild(ball);
    el.appendChild(cursor);
    this.cursor = cursor;

    // A remount while the pointer already hovers keeps the ball visible.
    if (this.editMode && el.matches(':hover')) {
      ball.style.opacity = '';
    }
    this.listen(d, 'mousemove', function (ev) {
      var rect = el.getBoundingClientRect();
      mouse.x = ev.clientX - rect.left;
      mouse.y = ev.clientY - rect.top;
    });
    this.listen(el, 'mouseenter', function () {
      self.inside = true;
      ball.style.opacity = '';
    });
    this.listen(el, 'mouseleave', function () {
      self.inside = false;
      ball.style.opacity = '0';
    });
    var _tick = function tick() {
      if (self.destroyed) {
        return;
      }
      if (self.inside) {
        delayed.x += (mouse.x - delayed.x) * 0.15;
        delayed.y += (mouse.y - delayed.y) * 0.15;
        ball.style.transform = 'translate(-50%, -50%) translate(' + delayed.x + 'px, ' + delayed.y + 'px)';
      }
      self.cursorRafId = requestAnimationFrame(_tick);
    };
    this.cursorRafId = requestAnimationFrame(_tick);
  };
  ImageTrails.prototype.teardown = function () {
    this.destroyed = true;
    clearTimeout(this.remountTimer);
    this.remountTimer = null;
    if (this.editorObserver) {
      this.editorObserver.disconnect();
      this.editorObserver = null;
    }
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    if (this.cursorRafId) {
      cancelAnimationFrame(this.cursorRafId);
      this.cursorRafId = null;
    }
    this.listeners.forEach(function (item) {
      item[0].removeEventListener(item[1], item[2]);
    });
    this.listeners = [];
    if (this.onFirstMove) {
      this.el.removeEventListener('mousemove', this.onFirstMove);
    }
    this.images.forEach(function (img) {
      gsap.killTweensOf(img.el);
    });
    this.images = [];
    [this.content, this.cursor].forEach(function (node) {
      if (node && node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    this.content = null;
    this.cursor = null;
    this.el.classList.remove('ha-it-yes');
    if (this.inlinePosition) {
      this.el.style.position = '';
      this.inlinePosition = false;
    }

    // The same instance mounts again after an editor remount.
    this.started = false;
  };
  ImageTrails.prototype.destroy = function () {
    this.teardown();
  };
  addFeature({
    key: 'image-trails',
    type: ['e-flexbox', 'e-div-block', 'e-grid'],
    prefix: 'ha_it_',
    Runtime: ImageTrails,
    target: function target(node) {
      return node;
    }
  });

  /* ------------------------------------------------------------------ *
   * Sticky Pin Element (containers, heading, paragraph, image, button, SVG)
   *
   * Frontend only (a pinned ScrollTrigger cannot run inside the editor
   * preview, same as Classic). Pins the element while its parent container
   * is scrolled through and toggles the active classes/colors.
   * ------------------------------------------------------------------ */
  var ASP_LAYOUT = {
    started: false,
    lastHeight: 0,
    timer: null,
    busy: false
  };
  function aspPageHeight() {
    return Math.max(d.documentElement.scrollHeight, d.body ? d.body.scrollHeight : 0);
  }

  // One shared watcher: refresh the triggers when the page height changes (late images, accordions...).
  function aspStartLayoutSync() {
    if (ASP_LAYOUT.started) {
      return;
    }
    ASP_LAYOUT.started = true;
    ASP_LAYOUT.lastHeight = aspPageHeight();
    if (typeof ScrollTrigger.config === 'function') {
      ScrollTrigger.config({
        ignoreMobileResize: true
      });
    }
    var schedule = function schedule() {
      clearTimeout(ASP_LAYOUT.timer);
      ASP_LAYOUT.timer = setTimeout(function () {
        if (ASP_LAYOUT.busy || ScrollTrigger.isRefreshing) {
          return;
        }
        var height = aspPageHeight();
        if (height === ASP_LAYOUT.lastHeight) {
          return;
        }
        ASP_LAYOUT.busy = true;
        ScrollTrigger.refresh();
        ASP_LAYOUT.lastHeight = aspPageHeight();
        ASP_LAYOUT.busy = false;
      }, 200);
    };
    if ('undefined' !== typeof MutationObserver && d.body) {
      new MutationObserver(schedule).observe(d.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['style', 'class', 'hidden']
      });
    }
    d.addEventListener('transitionend', schedule, true);
    d.addEventListener('animationend', schedule, true);
    d.addEventListener('load', schedule, true);

    // Late fonts, images and lazy content move the start/end areas without any DOM change.
    if ('undefined' !== typeof ResizeObserver && d.body) {
      new ResizeObserver(schedule).observe(d.body);
    }
    if (d.fonts && d.fonts.ready) {
      d.fonts.ready.then(schedule);
    }
  }
  function aspPosition(point, offset) {
    var position = String(point).replace(/-/g, ' ');
    var raw = String(offset === undefined || offset === null ? '' : offset).trim();
    var value = parseFloat(raw);
    if (raw !== '' && !isNaN(value) && value !== 0) {
      position += (value > 0 ? '+=' : '-=') + Math.abs(value);
      if (raw.indexOf('%') !== -1) {
        position += '%';
      }
    }
    return position;
  }
  function aspFind(selector) {
    try {
      return d.querySelector(selector);
    } catch (e) {
      return null;
    }
  }

  /**
   * The element a custom start/end area points to. Like Classic it takes a CSS
   * selector; a bare name without "." or "#" (the class or ID typed in the
   * Attributes/CSS ID field) is looked up as a class, then as an ID.
   */
  function aspQuery(selector) {
    selector = String(selector || '').trim();
    if (!selector) {
      return null;
    }
    var found = aspFind(selector);
    if (!found && /^[A-Za-z_][\w-]*$/.test(selector)) {
      found = aspFind('.' + selector) || aspFind('#' + selector);
    }
    return found;
  }

  // The outermost container around the element (or the element's own container).
  function aspParentEnd(el) {
    var con = el.closest('.e-con');
    if (con) {
      while (con.parentElement && con.parentElement.closest('.e-con')) {
        con = con.parentElement.closest('.e-con');
      }
      return con;
    }
    return el.parentElement;
  }
  function StickyPin(el, config) {
    this.el = el;
    this.config = config;
    this.trigger = null;
    this.toggleClass = '';
    this.refreshTimer = null;
    this.build();
  }
  StickyPin.prototype.reveal = function () {
    this.el.style.visibility = 'visible';
  };
  StickyPin.prototype.build = function () {
    var el = this.el;
    var config = this.config;
    if (isEditor() || reducedMotion() || typeof ScrollTrigger === 'undefined' || isMobile() && !config.enable_on_device) {
      this.reveal();
      return;
    }
    var self = this;
    var toggleClass = String(config.active_class || '').trim();
    var pinTarget = 'false' !== config.pin_type;
    var triggerEl = el;
    this.toggleClass = toggleClass;
    if ('custom' === config.start_trigger) {
      var startEl = aspQuery(config.custom_start_area);
      if (startEl) {
        triggerEl = startEl;
        pinTarget = pinTarget ? el : false;
      }
    }
    var vars = {
      trigger: triggerEl,
      pin: pinTarget,
      start: aspPosition(config.pin_start, config.pin_start_offset),
      end: aspPosition(config.pin_end, config.pin_end_offset),
      markers: !!config.pin_markers,
      pinSpacing: false,
      anticipatePin: 1,
      scrub: false,
      onEnter: function onEnter() {
        self.setActive(true);
      },
      onLeave: function onLeave() {
        self.setActive(false);
      },
      onEnterBack: function onEnterBack() {
        self.setActive(true);
      },
      onLeaveBack: function onLeaveBack() {
        self.setActive(false);
      }
    };
    var endEl = 'custom' === config.end_trigger ? aspQuery(config.custom_end_area) : aspParentEnd(el);
    if (endEl) {
      vars.endTrigger = endEl;
    }
    el.classList.add('ha-asp-element');
    // Same as Classic: no transform transition, or the pin release would animate.
    el.style.setProperty('--e-transform-transition-duration', '0s', 'important');
    el.style.setProperty('--e-con-transform-transition-duration', '0s', 'important');
    el.style.setProperty('--ha-asp-transition-duration', Math.max(0, num(config.transition_duration, 0.3)) + 's');
    if (config.active_color) {
      el.style.setProperty('--ha-asp-color', config.active_color);
      el.classList.add('ha-asp-has-color');
    }
    if (config.active_background) {
      el.style.setProperty('--ha-asp-bg', config.active_background);
      el.classList.add('ha-asp-has-bg');
    }
    this.trigger = ScrollTrigger.create(vars);
    aspStartLayoutSync();
    this.refreshTimer = setTimeout(function () {
      ScrollTrigger.refresh();
    }, 100);

    // Like Classic: measure again once the page has fully loaded.
    if ('complete' !== d.readyState) {
      this.onLoad = function () {
        ASP_LAYOUT.lastHeight = aspPageHeight();
        ScrollTrigger.refresh();
      };
      w.addEventListener('load', this.onLoad);
    }
    this.reveal();
  };
  StickyPin.prototype.setActive = function (on) {
    this.el.classList.toggle('ha-asp-active', on);
    if (this.toggleClass) {
      this.el.classList.toggle(this.toggleClass, on);
    }
  };
  StickyPin.prototype.destroy = function () {
    var el = this.el;
    clearTimeout(this.refreshTimer);
    if (this.onLoad) {
      w.removeEventListener('load', this.onLoad);
      this.onLoad = null;
    }
    if (this.trigger) {
      this.trigger.revert();
      this.trigger.kill();
      this.trigger = null;
    }
    el.classList.remove('ha-asp-element', 'ha-asp-active', 'ha-asp-has-color', 'ha-asp-has-bg');
    if (this.toggleClass) {
      el.classList.remove(this.toggleClass);
    }
    el.style.removeProperty('--e-transform-transition-duration');
    el.style.removeProperty('--e-con-transform-transition-duration');
    el.style.removeProperty('--ha-asp-transition-duration');
    el.style.removeProperty('--ha-asp-color');
    el.style.removeProperty('--ha-asp-bg');
    this.reveal();
  };
  addFeature({
    key: 'sticky-pin-element',
    prefix: 'ha_spl_',
    Runtime: StickyPin
  });

  /* ------------------------------------------------------------------ *
   * Global Animation (containers, heading, paragraph, image, button, SVG)
   *
   * Frontend only, like Classic. Tweens the element with GSAP, either when
   * it appears, scrubbed to the scroll position, or on page load.
   * ------------------------------------------------------------------ */
  var GA_COLOR_TARGETS = 'h1, h2, h3, h4, h5, h6, p, a, button';
  var GA_TWEEN_KEYS = ['ease', 'delay', 'duration', 'repeat', 'repeatDelay', 'yoyo', 'force3D', 'onStart', 'onComplete', 'onUpdate', 'scrollTrigger', 'immediateRender', 'toggleActions', 'paused'];
  var GA_CLEAR_MAP = {
    x: 'transform',
    y: 'transform',
    scale: 'transform',
    scaleX: 'transform',
    scaleY: 'transform',
    rotation: 'transform',
    rotate: 'transform',
    rotateX: 'transform',
    rotateY: 'transform',
    rotationX: 'transform',
    rotationY: 'transform',
    skewX: 'transform',
    skewY: 'transform',
    opacity: 'opacity',
    autoAlpha: 'opacity,visibility',
    color: 'color',
    backgroundColor: 'background-color',
    background: 'background-color',
    width: 'width',
    height: 'height',
    maxWidth: 'max-width',
    maxHeight: 'max-height',
    minWidth: 'min-width',
    minHeight: 'min-height',
    padding: 'padding',
    borderRadius: 'border-radius',
    border: 'border',
    borderWidth: 'border-width',
    borderColor: 'border-color',
    borderStyle: 'border-style',
    boxShadow: 'box-shadow',
    transformOrigin: 'transform-origin',
    filter: 'filter',
    transformPerspective: 'transform'
  };
  function gaFloat(value) {
    if (value === undefined || value === null || value === '') {
      return null;
    }
    var parsed = parseFloat(value);
    return isNaN(parsed) ? null : parsed;
  }
  function gaInt(value) {
    if (value === undefined || value === null || value === '') {
      return null;
    }
    var parsed = parseInt(value, 10);
    return isNaN(parsed) ? null : parsed;
  }

  // A CSS value typed in the panel: numbers stay numbers (GSAP reads them as px), the rest is kept.
  function gaScalar(value) {
    if (value === undefined || value === null) {
      return null;
    }
    value = String(value).trim();
    if (value === '') {
      return null;
    }
    if (/^-?\d+(\.\d+)?$/.test(value)) {
      return parseFloat(value);
    }
    return value;
  }

  // A length for a CSS shorthand part: a bare number is px.
  function gaLength(value) {
    var scalar = gaScalar(value);
    return typeof scalar === 'number' ? scalar + 'px' : scalar;
  }
  function gaEase(ease) {
    if (!ease || ease === 'none') {
      return null;
    }
    if (ease === 'slowmo') {
      return 'slowMo';
    }
    if (ease === 'stepped') {
      return 'steps(12)';
    }
    return ease;
  }
  function gaPosition(point) {
    return !point || point === 'custom' ? null : String(point).replace(/-/g, ' ');
  }
  function gaBorder(item) {
    var width = gaLength(item.value);
    var style = item.choice;
    var color = item.color;
    if (!width && !color && !style) {
      return null;
    }
    return {
      border: (width || '0px') + ' ' + (style || 'solid') + ' ' + (color || 'currentColor')
    };
  }
  function gaBoxShadow(item) {
    var part = function part(value) {
      var parsed = gaFloat(value);
      return (parsed === null ? 0 : parsed) + 'px';
    };
    return {
      boxShadow: (item.choice === 'inset' ? 'inset ' : '') + part(item.value) + ' ' + part(item.value2) + ' ' + part(item.value3) + ' ' + part(item.value4) + ' ' + (item.color || 'rgba(0,0,0,0.5)')
    };
  }
  function gaFlip(item) {
    var type = item.choice || 'mirror';
    var horizontal = item.choice2 !== 'vertical';
    if (type === '3d') {
      var deg = gaFloat(item.value);
      deg = deg === null ? 180 : deg;

      // transformPerspective gives the 3D turn real depth without parent CSS changes.
      return horizontal ? {
        rotateY: deg,
        transformPerspective: 800
      } : {
        rotateX: deg,
        transformPerspective: 800
      };
    }
    return horizontal ? {
      scaleX: -1
    } : {
      scaleY: -1
    };
  }

  // The value of one Custom Properties item: a number, a string, or an object of GSAP vars.
  function gaResolve(item) {
    switch (item.property) {
      case 'opacity':
      case 'scale':
      case 'scaleX':
      case 'scaleY':
      case 'rotate':
      case 'rotateX':
      case 'rotateY':
      case 'transformPerspective':
      case 'delay':
      case 'duration':
      case 'repeatDelay':
        return gaFloat(item.value);
      case 'repeat':
        return gaInt(item.value);
      case 'transformOrigin':
        return (item.choice === 'custom' ? item.value : item.choice) || '100% 100%';
      case 'color':
        return item.color || null;
      case 'background':
        return item.color ? {
          backgroundColor: item.color
        } : null;
      case 'force3D':
      case 'yoyo':
        return item["switch"] ? true : null;
      case 'border':
        return gaBorder(item);
      case 'boxShadow':
        return gaBoxShadow(item);
      case 'skew':
        var skew = {};
        var skewX = gaFloat(item.value);
        var skewY = gaFloat(item.value2);
        if (skewX !== null) {
          skew.skewX = skewX;
        }
        if (skewY !== null) {
          skew.skewY = skewY;
        }
        return Object.keys(skew).length ? skew : null;
      case 'blur':
        var blur = gaLength(item.value);
        return blur ? {
          filter: 'blur(' + blur + ')'
        } : null;
      case 'flip':
        return gaFlip(item);
      default:
        // x, y, width, height, min/max sizes, padding, borderRadius
        return gaScalar(item.value);
    }
  }

  // The GSAP vars of the Custom Properties, in list order (a later item wins).
  function gaBuildConfig(config) {
    var vars = {};
    var ease = gaEase(config.easing);
    if (ease) {
      vars.ease = ease;
    }
    (config.props || []).forEach(function (item) {
      var resolved = item && item.property ? gaResolve(item) : null;
      if (resolved === null || resolved === undefined) {
        return;
      }
      if (_typeof(resolved) === 'object') {
        Object.keys(resolved).forEach(function (name) {
          vars[name] = resolved[name];
        });
      } else {
        vars[item.property] = resolved;
      }
    });
    return vars;
  }

  // The inline styles a finished "from" tween leaves behind, so the element returns to its own CSS.
  function gaClearProps(vars) {
    var set = {};
    Object.keys(vars).forEach(function (key) {
      if (GA_TWEEN_KEYS.indexOf(key) !== -1) {
        return;
      }
      (GA_CLEAR_MAP[key] || key).split(',').forEach(function (css) {
        set[css] = true;
      });
    });
    return Object.keys(set).join(',');
  }
  function GlobalAnimation(el, config) {
    this.el = el;
    this.config = config;
    this.target = null;
    this.tween = null;
    this.colorTween = null;
    this.colorTargets = null;
    this.build();
  }

  // An image animates its <img>, so sizing properties and transforms reach the picture itself.
  GlobalAnimation.prototype.getTarget = function () {
    var el = this.el;
    if (el.tagName === 'IMG') {
      return el;
    }
    if (el.getAttribute('data-e-type') === 'e-image') {
      return el.querySelector('img') || el;
    }
    return el;
  };
  GlobalAnimation.prototype.build = function () {
    var config = this.config;
    if (isEditor() || typeof gsap === 'undefined' || isMobile() && !config.enable_mobile) {
      return;
    }
    var vars = gaBuildConfig(config);

    // Ease alone is not enough to animate.
    var hasProps = Object.keys(vars).some(function (key) {
      return key !== 'ease';
    });
    if (!hasProps) {
      return;
    }
    var el = this.el;
    var target = this.getTarget();
    var method = typeof gsap[config.animation] === 'function' ? config.animation : 'from';
    var mode = config.trigger_mode;
    var scrollBased = typeof ScrollTrigger !== 'undefined' && (mode === 'scroll' || mode === 'playwithscroll');
    var scrub = scrollBased && mode === 'playwithscroll';
    var tweenVars = Object.assign({}, vars);
    this.target = target;
    el.classList.add('ha-ga-animation');
    if (scrollBased) {
      var st = {
        trigger: target,
        start: 'top 85%'
      };
      if (scrub) {
        st.scrub = true;
      } else {
        st.toggleActions = 'play none none none';
      }
      if (config.wrapper === 'custom') {
        if (config.anim_start === 'custom') {
          if (config.anim_start_custom) {
            st.start = config.anim_start_custom;
          }
        } else if (config.anim_start) {
          st.start = gaPosition(config.anim_start);
        }
        if (config.anim_end === 'custom') {
          if (config.anim_end_custom) {
            st.end = config.anim_end_custom;
          }
        } else if (config.anim_end) {
          st.end = gaPosition(config.anim_end);
        }
        if (config.markers) {
          st.markers = true;
        }
      }
      tweenVars.scrollTrigger = st;
    }

    // A scrubbed tween must follow the scroll 1:1, not GSAP's default ease.
    if (scrub && !tweenVars.ease) {
      tweenVars.ease = 'none';
    }

    // For a scrubbed "from" tween the perspective and origin are setup values, not targets.
    if (scrub && method === 'from') {
      var baseline = {};
      if (vars.transformPerspective !== undefined) {
        baseline.transformPerspective = vars.transformPerspective;
      }
      if (vars.transformOrigin !== undefined) {
        baseline.transformOrigin = vars.transformOrigin;
      }
      if (Object.keys(baseline).length) {
        gsap.set(target, baseline);
      }
    }
    gsap.killTweensOf(target);
    target.style.willChange = 'transform';
    target.style.transition = 'none';
    el.style.transition = 'none';

    // 3D flips must render their back face.
    if (vars.transformPerspective !== undefined) {
      target.style.WebkitBackfaceVisibility = 'visible';
      target.style.backfaceVisibility = 'visible';
    }
    var clearOnComplete = method === 'from' && mode !== 'playwithscroll';
    var clearProps = clearOnComplete ? gaClearProps(vars) : '';
    this.tween = gsap[method](target, Object.assign({}, tweenVars, {
      onStart: function onStart() {
        target.style.willChange = 'transform';
        target.style.transition = 'none';
        el.style.transition = 'none';
        el.classList.add('ha-ga-animating');
      },
      onComplete: function onComplete() {
        el.classList.remove('ha-ga-animating');
        if (clearOnComplete && clearProps) {
          gsap.set(target, {
            clearProps: clearProps
          });
        }

        // At rest (no transform delta), so restoring the transition is instant.
        target.style.transition = '';
        el.style.transition = '';
      }
    }));
    if (vars.color !== undefined) {
      this.animateColor(target, method, tweenVars, clearOnComplete);
    }
    if (scrollBased) {
      this.refreshTimer = setTimeout(function () {
        ScrollTrigger.refresh();
      }, 120);
    }
  };

  // Text colours are also set on the text inside the element, so animate those too.
  GlobalAnimation.prototype.animateColor = function (target, method, tweenVars, clearOnComplete) {
    // The element's own color is part of the main tween; only the text inside needs its own.
    var targets = [].slice.call(target.querySelectorAll(GA_COLOR_TARGETS));
    if (!targets.length) {
      return;
    }
    this.colorTargets = targets;
    gsap.killTweensOf(targets);

    // Colour and timing only: everything else stays on the main target.
    var colorVars = {
      color: tweenVars.color
    };
    ['ease', 'duration', 'delay', 'repeat', 'repeatDelay', 'yoyo', 'force3D'].forEach(function (key) {
      if (tweenVars[key] !== undefined) {
        colorVars[key] = tweenVars[key];
      }
    });
    if (tweenVars.scrollTrigger) {
      colorVars.scrollTrigger = Object.assign({}, tweenVars.scrollTrigger);
    }
    this.colorTween = gsap[method](targets, Object.assign({}, colorVars, {
      onComplete: function onComplete() {
        if (clearOnComplete) {
          gsap.set(targets, {
            clearProps: 'color'
          });
        }
      }
    }));
  };
  GlobalAnimation.prototype.destroy = function () {
    var el = this.el;
    var target = this.target;
    clearTimeout(this.refreshTimer);
    [this.tween, this.colorTween].forEach(function (tween) {
      if (!tween) {
        return;
      }
      if (tween.scrollTrigger) {
        tween.scrollTrigger.kill();
      }
      tween.kill();
    });
    if (this.colorTargets) {
      gsap.killTweensOf(this.colorTargets);
      gsap.set(this.colorTargets, {
        clearProps: 'color'
      });
    }
    if (target) {
      gsap.killTweensOf(target);
      target.style.willChange = '';
      target.style.transition = '';
    }
    el.classList.remove('ha-ga-animation', 'ha-ga-animating');
    el.style.transition = '';
    this.tween = null;
    this.colorTween = null;
    this.colorTargets = null;
    this.target = null;
  };
  addFeature({
    key: 'global-animation',
    prefix: 'ha_ga_',
    Runtime: GlobalAnimation
  });

  /* ------------------------------------------------------------------ *
   * Global Badge (containers, heading, paragraph, button)
   *
   * Builds the badge (text and icon / image / Lottie) as the first child of
   * the element, the way the Classic extension does, and runs the floating
   * effects. Frontend and editor preview. The Classic selectors become
   * inline styles / custom properties of the badge.
   * ------------------------------------------------------------------ */
  function gbUnwrap(value) {
    while (value && 'object' === _typeof(value) && '$$type' in value) {
      value = value.value;
    }
    return value;
  }
  function gbIsSafari() {
    var ua = navigator.userAgent;
    if (/iP(hone|ad|od)/i.test(ua) && !w.MSStream) {
      return /WebKit/i.test(ua) && !/(Chrome|CriOS|OPiOS|FxiOS)/.test(ua);
    }
    return /^((?!chrome|android).)*safari/i.test(ua);
  }

  // Frontend: the URL from PHP. Editor: the image prop of the settings, whose
  // library images carry only the attachment id (a number here).
  function gbImageSource(raw) {
    if ('string' === typeof raw) {
      return raw;
    }
    var image = gbUnwrap(raw);
    var src = image && gbUnwrap(image.src);
    var url = src && 'object' === _typeof(src) ? gbUnwrap(src.url) : src;
    if ('string' === typeof url && url) {
      return url;
    }
    var id = src && 'object' === _typeof(src) ? gbUnwrap(src.id) : null;
    return id ? Number(id) : '';
  }
  function gbResolveImage(source, done) {
    if ('string' === typeof source || !source) {
      done(source || '');
      return;
    }
    var media = w.parent && w.parent.wp && w.parent.wp.media || w.wp && w.wp.media;
    var attachment = media && media.attachment ? media.attachment(source) : null;
    if (!attachment) {
      done('');
      return;
    }
    if (attachment.get('url')) {
      done(attachment.get('url'));
      return;
    }
    attachment.fetch().always(function () {
      done(attachment.get('url') || '');
    });
  }
  function gbHas(value) {
    return null !== value && undefined !== value && '' !== value && !isNaN(parseFloat(value));
  }

  // A From/To range: two numbers from PHP, or the "from,to" text in the editor.
  function gbRange(c, key, fallback) {
    if (gbHas(c[key + '_from'])) {
      return [parseFloat(c[key + '_from']), parseFloat(c[key + '_to'])];
    }
    var parts = String(c[key] || '').split(',');
    return [num(parts[0], fallback[0]), num(parts[1], fallback[1])];
  }
  function gbSizeCss(size) {
    size = gbUnwrap(size);
    if (!size || undefined === size.size || null === size.size || '' === size.size) {
      return '';
    }
    var unit = size.unit || 'px';
    return 'auto' === unit ? 'auto' : parseFloat(size.size) + unit;
  }

  // Margin / Padding: the four sides from PHP, or the stored size(s) in the editor.
  function gbSides(value) {
    value = gbUnwrap(value);
    if (!value || 'object' !== _typeof(value)) {
      return null;
    }
    if (undefined !== value.top) {
      return value;
    }
    if (undefined !== value.size) {
      var one = gbSizeCss(value);
      return {
        top: one,
        right: one,
        bottom: one,
        left: one
      };
    }
    return {
      top: gbSizeCss(value['block-start']),
      right: gbSizeCss(value['inline-end']),
      bottom: gbSizeCss(value['block-end']),
      left: gbSizeCss(value['inline-start'])
    };
  }
  function gbPx(value) {
    return parseFloat(value) + 'px';
  }
  function GlobalBadge(el, config) {
    this.el = el;
    this.c = config;
    this.wrap = null;
    this.tweens = [];
    this.lottie = null;
    this.destroyed = false;
    this.restorePosition = false;
    this.build();
  }

  // The element's children were replaced (the editor re-rendered it).
  GlobalBadge.prototype.isStale = function () {
    return !this.wrap || !this.el.contains(this.wrap) || !this.el.classList.contains('ha-agb-yes');
  };
  GlobalBadge.prototype.abandon = function () {
    this.destroyed = true;
    this.stopEffects();
  };
  GlobalBadge.prototype.build = function () {
    var self = this;
    var c = this.c;
    var el = this.el;
    var type = c.type || 'stripe';
    var hor = c.hor || 'right';
    var ver = c.ver || 'top';
    var display = c.display || 'row';
    var hasIcon = 'none' !== c.icon_type;
    var clip = 'custom' === type && c.clip_enabled && c.path;
    el.classList.add('ha-agb-yes', 'ha-agb-' + type, 'ha-agb-' + hor, 'ha-agb-' + display);
    if ('static' === getComputedStyle(el).position) {
      el.style.position = 'relative';
      this.restorePosition = true;
    }
    var wrap = d.createElement('span');
    var inner = d.createElement('span');
    var text = null;
    var icon = null;
    wrap.className = 'ha-agb-wrap';
    inner.className = 'ha-agb-inner';
    wrap.appendChild(inner);
    if (c.text) {
      text = d.createElement('span');
      text.className = 'ha-agb-text';
      text.textContent = c.text;
      inner.appendChild(text);
    }
    var sets = {
      wrap: {},
      inner: {},
      text: {},
      icon: {}
    };
    var style = function style(node, props) {
      Object.keys(props).forEach(function (name) {
        var value = props[name];
        if (null === value || undefined === value || '' === value) {
          return;
        }
        if (0 === name.indexOf('--')) {
          node.style.setProperty(name, value);
        } else {
          node.style[name] = value;
        }
      });
    };

    /* Layout */
    var w1 = sets.wrap;
    var i1 = sets.inner;
    if (hasIcon) {
      i1.flexDirection = display;
    }
    if (gbHas(c.zindex)) {
      w1.zIndex = c.zindex;
    }
    if ('custom' === type && c.rotate && !c.efct_translate_toggle && !c.efct_rotate_toggle && !c.efct_scale_toggle) {
      w1.transform = 'rotate(' + c.rotate + 'deg)';
    }
    var hOffset = gbHas(c.hor_offset) ? gbPx(c.hor_offset) : '';
    var vOffset = gbHas(c.ver_offset) ? gbPx(c.ver_offset) : '';
    if ('stripe' === type || 'tri' === type) {
      w1[hor] = '0';
    } else if ('circle' === type || 'custom' === type) {
      w1[hor] = hOffset || '8px';
      w1[ver] = vOffset || '8px';
    } else if ('bookmark' === type) {
      w1[hor] = hOffset || '20px';
    } else if ('flag' === type) {
      w1.top = vOffset;
    }
    if ('tri' === type) {
      i1.left = hOffset;
      i1['left' === hor ? 'bottom' : 'top'] = vOffset;
    }
    if ('stripe' === type) {
      i1['--ha-agb-strip-x'] = hOffset;
      i1['--ha-agb-strip-y'] = vOffset;
    }

    /* Style */
    if (gbHas(c.size)) {
      if ('tri' === type) {
        w1.borderBottomWidth = gbPx(c.size);
        w1['left' === hor ? 'borderTopWidth' : 'borderLeftWidth'] = gbPx(c.size);
        w1.borderRightWidth = gbPx(c.size);
      } else if ('custom' === type) {
        i1.width = gbPx(c.size);
        i1.height = gbPx(c.size);
      }
    }
    sets.text.color = c.color;
    if (['stripe', 'circle', 'custom'].indexOf(type) !== -1) {
      if ('gradient' === c.bg_type) {
        if (c.bg_color && c.bg_color_b) {
          i1.background = 'linear-gradient(' + (parseFloat(c.bg_angle) || 0) + 'deg, ' + c.bg_color + ', ' + c.bg_color_b + ')';
        }
      } else {
        i1.backgroundColor = c.bg_color;
      }
    }
    if (['bookmark', 'tri', 'flag'].indexOf(type) !== -1) {
      w1['--ha-agb-bgc'] = c.bgcolor;
    }
    if (c.ts_color) {
      w1.textShadow = gbPx(c.ts_x || 0) + ' ' + gbPx(c.ts_y || 0) + ' ' + gbPx(c.ts_blur || 0) + ' ' + c.ts_color;
    }
    if (c.bs_color && 'tri' !== type) {
      var shadow = ('inset' === c.bs_position ? 'inset ' : '') + gbPx(c.bs_x || 0) + ' ' + gbPx(c.bs_y || 0) + ' ' + gbPx(c.bs_blur || 0) + ' ' + gbPx(c.bs_spread || 0) + ' ' + c.bs_color;
      ('bookmark' === type ? w1 : i1).boxShadow = shadow;
    }
    var typo = {
      fontFamily: c.typo_font_family,
      fontSize: gbHas(c.typo_font_size) ? gbPx(c.typo_font_size) : '',
      fontWeight: c.typo_font_weight,
      textTransform: c.typo_text_transform,
      fontStyle: c.typo_font_style,
      textDecoration: c.typo_text_decoration,
      lineHeight: gbHas(c.typo_line_height) ? String(c.typo_line_height) + 'em' : '',
      letterSpacing: gbHas(c.typo_letter_spacing) ? gbPx(c.typo_letter_spacing) : ''
    };
    if (c.typo_font_family && w.elementorFrontend && w.elementorFrontend.helpers && w.elementorFrontend.helpers.enqueueFont) {
      w.elementorFrontend.helpers.enqueueFont(String(c.typo_font_family).replace(/^["']|["']$/g, ''));
    }
    if ('stripe' !== type) {
      Object.assign(w1, typo);
    }
    if ('stripe' === type || 'custom' === type) {
      Object.assign(i1, typo);
    }
    if (!clip && ('circle' === type || 'custom' === type) && c.border_style) {
      i1.borderStyle = c.border_style;
      i1.borderWidth = gbHas(c.border_width) ? gbPx(c.border_width) : '';
      i1.borderColor = c.border_color;
    }
    if (!clip && gbHas(c.border_rad) && ['flag', 'circle', 'custom'].indexOf(type) !== -1) {
      var r = gbPx(c.border_rad);
      if ('flag' === type) {
        i1.borderRadius = 'left' === hor ? r + ' ' + r + ' ' + r + ' 0' : r + ' ' + r + ' 0 ' + r;
      } else {
        i1.borderRadius = r;
      }
    }
    if (!clip && 'custom' === type) {
      [['top', 'borderTopLeftRadius'], ['right', 'borderTopRightRadius'], ['bottom', 'borderBottomRightRadius'], ['left', 'borderBottomLeftRadius']].forEach(function (side) {
        var value = c['border_rad2_' + side[0]];
        if (gbHas(value)) {
          i1[side[1]] = gbPx(value);
        }
      });
    }
    var padding = gbSides(c.padding);
    if (padding && ['stripe', 'flag', 'circle', 'custom'].indexOf(type) !== -1) {
      i1.paddingTop = padding.top;
      i1.paddingRight = padding.right;
      i1.paddingBottom = padding.bottom;
      i1.paddingLeft = padding.left;
    }
    var margin = gbSides(c.margin);
    if (margin) {
      w1.marginTop = margin.top;
      w1.marginRight = margin.right;
      w1.marginBottom = margin.bottom;
      w1.marginLeft = margin.left;
    }
    if ('bookmark' === type) {
      if (gbHas(c.padding_bookmark_top)) {
        w1.paddingTop = gbPx(c.padding_bookmark_top);
      }
      if (gbHas(c.padding_bookmark_bottom)) {
        w1.paddingBottom = gbPx(c.padding_bookmark_bottom);
      }
    }
    if (clip) {
      w1.filter = 'blur(.25px)';
      w1.clipPath = c.path;
      w1.webkitClipPath = c.path;
    }

    /* Icon, image or Lottie */
    var iconNode = null;
    var lottieNode = null;
    var imgNode = null;
    if (hasIcon) {
      icon = d.createElement('span');
      icon.className = 'ha-agb-icon';
      if ('icon' === c.icon_type && c.icon) {
        iconNode = d.createElement('i');
        iconNode.className = 'ha-agb-icon-fa ' + c.icon;
        icon.appendChild(iconNode);
      } else if ('image' === c.icon_type) {
        imgNode = d.createElement('img');
        imgNode.className = 'ha-agb-img';
        imgNode.alt = c.img_alt || '';
        icon.appendChild(imgNode);
      } else if ('lottie' === c.icon_type && c.lottie_url) {
        lottieNode = d.createElement('div');
        lottieNode.className = 'ha-agb-lottie-animation ha-agb-lottie-icon';
        icon.appendChild(lottieNode);
      } else {
        icon = null;
      }
    }
    if (icon) {
      inner.appendChild(icon);
      if (gbHas(c.spacing)) {
        if ('row' === display) {
          (c.rtl ? sets.text : sets.icon).textIndent = gbPx(c.spacing);
        } else {
          sets.icon.marginBottom = gbPx(c.spacing);
        }
      }
      if (c.icon_color && 'icon' === c.icon_type) {
        sets.icon.color = c.icon_color;
        sets.icon.fill = c.icon_color;
      }
      if (gbHas(c.icon_size)) {
        var size = gbPx(c.icon_size);
        sets.icon.fontSize = size;
        if ('bookmark' !== type) {
          sets.icon.lineHeight = size;
        }
        sets.icon.width = size;
        sets.icon.height = size;
        if (lottieNode) {
          style(lottieNode, {
            width: size,
            height: size
          });
        }
        if (imgNode && 'bookmark' !== type) {
          style(imgNode, {
            width: size,
            height: size
          });
        }
      }
      if (gbHas(c.icon_rad) && 'image' === c.icon_type) {
        style(imgNode, {
          borderRadius: gbPx(c.icon_rad)
        });
      }
    }
    style(wrap, sets.wrap);
    style(inner, sets.inner);
    if (text) {
      style(text, sets.text);
    }
    if (icon) {
      style(icon, sets.icon);
    }
    el.insertBefore(wrap, el.firstChild);
    this.wrap = wrap;
    if (imgNode) {
      gbResolveImage(gbImageSource(c.img), function (url) {
        if (!self.destroyed && url) {
          imgNode.src = url;
        }
      });
    }
    if (lottieNode && 'undefined' !== typeof lottie) {
      this.lottie = lottie.loadAnimation({
        container: lottieNode,
        loop: !!c.loop,
        path: c.lottie_url,
        autoplay: true
      });
    }
    this.startEffects();
  };
  GlobalBadge.prototype.startEffects = function () {
    var c = this.c;
    if (!c.effects || c.disable_on_safari && gbIsSafari() || 'undefined' === typeof gsap) {
      return;
    }
    var target = this.wrap;
    var add = function add(from, to, speed) {
      to.duration = Math.max(0.01, parseFloat(speed) || 1);
      to.repeat = -1;
      to.yoyo = true;
      to.ease = 'sine.inOut';
      return gsap.fromTo(target, from, to);
    };
    var movable = 'stripe' !== c.type;
    var tweens = this.tweens;
    var tx = gbRange(c, 'efct_translatex', [-5, 5]);
    var ty = gbRange(c, 'efct_translatey', [-5, 5]);
    var rx = gbRange(c, 'efct_rotatex', [0, 45]);
    var ry = gbRange(c, 'efct_rotatey', [0, 45]);
    var rz = gbRange(c, 'efct_rotatez', [0, 45]);
    var sx = gbRange(c, 'efct_scalex', [1, 1.2]);
    var sy = gbRange(c, 'efct_scaley', [1, 1.2]);
    var op = gbRange(c, 'efct_opacity', [0, 50]);
    var bl = gbRange(c, 'efct_blur', [0, 1]);
    var gs = gbRange(c, 'efct_gscale', [0, 50]);
    if (movable && c.efct_translate_toggle) {
      tweens.push(add({
        x: tx[0],
        y: ty[0]
      }, {
        x: tx[1],
        y: ty[1]
      }, c.efct_translate_speed));
    }
    if (movable && c.efct_rotate_toggle) {
      tweens.push(add({
        rotationX: rx[0],
        rotationY: ry[0],
        rotation: rz[0]
      }, {
        rotationX: rx[1],
        rotationY: ry[1],
        rotation: rz[1]
      }, c.efct_rotate_speed));
    }
    if (movable && c.efct_scale_toggle) {
      tweens.push(add({
        scaleX: sx[0],
        scaleY: sy[0]
      }, {
        scaleX: sx[1],
        scaleY: sy[1]
      }, c.efct_scale_speed));
    }
    if (c.efct_opacity_toggle) {
      tweens.push(add({
        opacity: op[0] / 100
      }, {
        opacity: op[1] / 100
      }, c.efct_opacity_speed));
    }
    if (c.efct_blur_toggle) {
      tweens.push(add({
        filter: 'blur(' + bl[0] + 'px)'
      }, {
        filter: 'blur(' + bl[1] + 'px)'
      }, c.efct_blur_speed));
    }
    if (c.efct_grayscale_toggle) {
      tweens.push(add({
        filter: 'grayscale(' + gs[0] + '%)'
      }, {
        filter: 'grayscale(' + gs[1] + '%)'
      }, c.efct_gscale_speed));
    }
  };
  GlobalBadge.prototype.stopEffects = function () {
    this.tweens.forEach(function (tween) {
      tween.kill();
    });
    this.tweens = [];
    if (this.wrap && 'undefined' !== typeof gsap) {
      gsap.set(this.wrap, {
        clearProps: 'x,y,rotation,rotationX,rotationY,scaleX,scaleY,opacity,filter'
      });
    }
  };
  GlobalBadge.prototype.destroy = function () {
    this.destroyed = true;
    this.stopEffects();
    if (this.lottie) {
      this.lottie.destroy();
      this.lottie = null;
    }
    if (this.wrap && this.wrap.parentNode) {
      this.wrap.parentNode.removeChild(this.wrap);
    }
    this.el.classList.remove('ha-agb-yes');
    this.el.className = this.el.className.replace(/(^|\s)ha-agb-(stripe|flag|tri|circle|bookmark|custom|left|right|row|column)(?=\s|$)/g, '');
    if (this.restorePosition) {
      this.el.style.removeProperty('position');
    }
    this.wrap = null;
  };
  addFeature({
    key: 'global-badge',
    type: ['e-flexbox', 'e-div-block', 'e-grid', 'e-heading', 'e-paragraph', 'e-button'],
    prefix: 'ha_agb_',
    Runtime: GlobalBadge,
    target: function target(node) {
      return node;
    }
  });

  /* ------------------------------------------------------------------ *
   * Happy Particle Effects (e-flexbox, e-div-block, e-grid)
   *
   * Port of happy-particles-init.js: a wrapper is added as the first child of
   * the container and particles.js draws the selected style (or the custom
   * JSON) on it. Frontend and editor preview; the hover effect is frontend only.
   * ------------------------------------------------------------------ */
  function hpeEmpty(value) {
    return null === value || undefined === value || '' === value;
  }
  function hpeJSON(raw) {
    if (raw && 'object' === _typeof(raw)) {
      return raw;
    }
    if ('string' !== typeof raw || !raw.trim()) {
      return null;
    }
    try {
      var parsed = JSON.parse(raw);
      return parsed && 'object' === _typeof(parsed) ? parsed : null;
    } catch (e) {
      return null;
    }
  }
  function ParticleEffects(el, config) {
    this.el = el;
    this.config = config;
    this.wrapper = null;
    this.hosted = false;
    this.build();
  }
  ParticleEffects.prototype.build = function () {
    var el = this.el;
    var config = this.config;
    if ('function' !== typeof w.particlesJS) {
      return;
    }
    var id = 'ha-particle-' + String(el.getAttribute('data-id') || '').replace(/[^a-zA-Z0-9_-]/g, '');
    var style = config.style || 'nasa';
    var particles;
    if ('custom' === style) {
      particles = hpeJSON(config.json);
      if (!particles) {
        return;
      }
    } else {
      particles = this.settings(style);
    }
    var wrapper = d.createElement('div');
    wrapper.id = id;
    wrapper.className = 'ha-particle-wrapper';

    // Behind the content, above the container's own background (see the stylesheet).
    el.classList.add('ha-pe-host');
    el.insertBefore(wrapper, el.firstChild);
    this.wrapper = wrapper;
    try {
      w.particlesJS(id, particles);
    } catch (e) {
      this.destroy();
    }
  };
  ParticleEffects.prototype.settings = function (style) {
    var config = this.config;
    var color = config.color || '#bdbdbd';
    var number = 150;
    var shape = 'circle';
    var sides = 5;
    var opacity = 0.6;
    var opacityRandom = true;
    var opacityAnim = false;
    var lineLinked = false;
    var speed = 4;
    var moveRandom = true;
    var size = 2;
    var sizeRandom = true;
    var sizeAnim = false;
    var onhover = 'repulse';
    var direction = 'none';
    var interactive = false;
    if ('default' === style) {
      lineLinked = true;
      opacityRandom = false;
      moveRandom = false;
      speed = 6;
    } else if ('nasa' === style) {
      number = 160;
      opacity = 1;
      opacityAnim = true;
      speed = 1;
      size = 3;
      onhover = 'bubble';
    } else if ('snow' === style) {
      opacity = 0.5;
      size = 4;
      speed = 3;
      direction = config.direction || 'bottom';
      number = 200;
      opacityRandom = false;
    }
    if (!hpeEmpty(config.opacity)) {
      opacity = num(config.opacity, opacity);
    }
    if (config.advanced) {
      if (!hpeEmpty(config.number)) {
        number = num(config.number, number);
      }
      if (!hpeEmpty(config.size)) {
        size = num(config.size, size);
      }
      if (!hpeEmpty(config.speed)) {
        speed = num(config.speed, speed);
      }

      // The hover effect does not work inside the editor (as in Classic).
      interactive = !!config.interactive && !isEditor();
    }
    return {
      particles: {
        number: {
          value: number,
          density: {
            enable: true,
            value_area: 800
          }
        },
        color: {
          value: color
        },
        shape: {
          type: shape,
          stroke: {
            width: 0,
            color: '#ffffff'
          },
          polygon: {
            nb_sides: sides
          }
        },
        opacity: {
          value: opacity,
          random: opacityRandom,
          anim: {
            enable: opacityAnim,
            speed: 1,
            opacity_min: 0.1,
            sync: false
          }
        },
        size: {
          value: size,
          random: sizeRandom,
          anim: {
            enable: sizeAnim,
            speed: 5,
            size_min: 35,
            sync: false
          }
        },
        line_linked: {
          enable: lineLinked,
          distance: 150,
          color: color,
          opacity: 0.4,
          width: 1
        },
        move: {
          enable: true,
          speed: speed,
          direction: direction,
          random: moveRandom,
          straight: false,
          out_mode: 'out',
          attract: {
            enable: false,
            rotateX: 600,
            rotateY: 1200
          }
        }
      },
      interactivity: {
        detect_on: 'canvas',
        events: {
          onhover: {
            enable: interactive,
            mode: onhover
          },
          onclick: {
            enable: false,
            mode: 'push'
          },
          resize: true
        },
        modes: {
          grab: {
            distance: 400,
            line_linked: {
              opacity: 1
            }
          },
          bubble: {
            distance: 200,
            size: 0,
            duration: 2,
            opacity: 0,
            speed: 2
          },
          repulse: {
            distance: 150
          },
          push: {
            particles_nb: 4
          },
          remove: {
            particles_nb: 2
          }
        }
      },
      retina_detect: true
    };
  };

  // The editor re-renders the container and drops the wrapper with it.
  ParticleEffects.prototype.isStale = function () {
    return !!this.wrapper && !this.wrapper.isConnected;
  };
  ParticleEffects.prototype.abandon = function () {
    this.stop();
    this.wrapper = null;
  };

  // particles.js' own destroy resets its global list, so only this instance is stopped.
  ParticleEffects.prototype.stop = function () {
    var wrapper = this.wrapper;
    if (!wrapper || !Array.isArray(w.pJSDom)) {
      return;
    }
    w.pJSDom = w.pJSDom.filter(function (item) {
      var canvas = item && item.pJS && item.pJS.canvas && item.pJS.canvas.el;
      if (canvas && wrapper.contains(canvas)) {
        try {
          cancelAnimationFrame(item.pJS.fn.drawAnimFrame);
          cancelAnimationFrame(item.pJS.fn.checkAnimFrame);
        } catch (e) {}
        return false;
      }
      return true;
    });
  };
  ParticleEffects.prototype.destroy = function () {
    this.stop();
    if (this.wrapper && this.wrapper.parentNode) {
      this.wrapper.parentNode.removeChild(this.wrapper);
    }
    this.wrapper = null;
    this.el.classList.remove('ha-pe-host');
  };
  addFeature({
    key: 'happy-particle-effects',
    type: ['e-flexbox', 'e-div-block', 'e-grid'],
    prefix: 'ha_pe_',
    Runtime: ParticleEffects,
    target: function target(node) {
      return node;
    }
  });

  /* ------------------------------------------------------------------ *
   * Multi Layer Parallax (e-flexbox, e-div-block, e-grid)
   *
   * Port of multi-layer-parallax.js: the layers (images) are added as the
   * first children of the container and move with the scroll (translateY /
   * translateX, smoothParallaxMotion) or follow the mouse (Mouse Track).
   * Frontend: layers come from PHP (image_url, plain values). Editor preview:
   * the "ha-mlp-layer" props of the settings (images carry only the
   * attachment id), so both shapes are normalised first.
   * ------------------------------------------------------------------ */
  var MLP_CLASS = 'ha-multi-layer-parallax';
  var MLP_HOST = 'ha-multi-layer-parallax--yes';
  function mlpDeep(value) {
    while (value && 'object' === _typeof(value) && !Array.isArray(value) && '$$type' in value) {
      value = value.value;
    }
    if (Array.isArray(value)) {
      return value.map(mlpDeep);
    }
    if (value && 'object' === _typeof(value)) {
      var out = {};
      Object.keys(value).forEach(function (key) {
        out[key] = mlpDeep(value[key]);
      });
      return out;
    }
    return value;
  }
  function mlpBool(value, fallback) {
    return null === value || undefined === value || '' === value ? fallback : !!value && 'false' !== value;
  }

  // "start,end" text (editor) or {start, end} (frontend), 0 - 100.
  function mlpView(value) {
    var start = 0;
    var end = 100;
    if (value && 'object' === _typeof(value)) {
      start = num(value.start, 0);
      end = num(value.end, 100);
    } else if ('string' === typeof value && value) {
      var parts = value.split(',');
      start = num(parts[0], 0);
      end = num(parts[1], 100);
    }
    return {
      start: start,
      end: end
    };
  }
  function mlpDevices(value) {
    if (Array.isArray(value)) {
      return value;
    }
    return 'string' === typeof value && value ? value.split(',').map(function (item) {
      return item.trim();
    }) : [];
  }
  function mlpMode() {
    return w.elementorFrontend && 'function' === typeof w.elementorFrontend.getCurrentDeviceMode ? w.elementorFrontend.getCurrentDeviceMode() : 'desktop';
  }

  // One layer of the settings, with plain values and defaults (the Classic ones).
  function mlpLayer(raw) {
    var layer = mlpDeep(raw) || {};
    var image = layer.image && 'object' === _typeof(layer.image) ? layer.image : {};
    var src = image.src && 'object' === _typeof(image.src) ? image.src : {};
    var url = layer.image_url || ('string' === typeof image.src ? image.src : src.url) || '';
    return {
      hide: mlpBool(layer.hide, false),
      url: 'string' === typeof url ? url : '',
      id: !url && src.id ? Number(src.id) : 0,
      alt: layer.alt || '',
      width: num(layer.width, 100),
      z_index: num(layer.z_index, 1),
      hor: layer.hor || 'custom',
      hor_pos: num(layer.hor_pos, 0),
      ver: layer.ver || 'custom',
      ver_pos: num(layer.ver_pos, 0),
      effect: layer.effect || 'scroll_parallax',
      rate: num(layer.rate, -10),
      scroll_ver: mlpBool(layer.scroll_ver, true),
      direction: layer.direction || 'down',
      speed: num(layer.speed, 4),
      view: mlpView(layer.view),
      scroll_hor: mlpBool(layer.scroll_hor, false),
      direction_hor: layer.direction_hor || 'down',
      speed_hor: num(layer.speed_hor, 4),
      view_hor: mlpView(layer.view_hor),
      show_on: mlpDevices(layer.show_on)
    };
  }

  // Editor images carry the attachment id only: the media library gives the URL.
  function mlpResolve(layers, done) {
    var media = w.parent && w.parent.wp && w.parent.wp.media || w.wp && w.wp.media;
    var pending = 0;
    layers.forEach(function (layer) {
      if (layer.url || !layer.id || !media || !media.attachment) {
        return;
      }
      var attachment = media.attachment(layer.id);
      if (attachment.get('url')) {
        layer.url = attachment.get('url');
        layer.alt = layer.alt || attachment.get('alt') || '';
        return;
      }
      pending++;
      attachment.fetch().always(function () {
        layer.url = attachment.get('url') || '';
        layer.alt = layer.alt || attachment.get('alt') || '';
        if (! --pending) {
          done();
        }
      });
    });
    if (!pending) {
      done();
    }
  }

  // Scroll motion of one layer: the Classic smoothParallaxMotion.
  function MlpScroll(node, vertical, horizontal) {
    this.node = node;
    this.vertical = vertical;
    this.horizontal = horizontal;
    this.busy = false;
    this.frame = 0;
    this.onScroll = this.onScroll.bind(this);
    var order = [];
    if (vertical) {
      order.push('translateY(var(--translateY))');
    }
    if (horizontal) {
      order.push('translateX(var(--translateX))');
    }
    node.style.transform = order.join(' ');
    w.addEventListener('scroll', this.onScroll, {
      passive: true
    });
    w.addEventListener('load', this.onScroll);
  }
  MlpScroll.prototype.onScroll = function () {
    if (this.busy) {
      return;
    }
    var self = this;
    this.busy = true;
    this.frame = requestAnimationFrame(function () {
      self.process();
      self.busy = false;
    });
  };
  MlpScroll.prototype.progress = function () {
    var rect = this.node.getBoundingClientRect();
    var range = (this.node.offsetHeight || 0) + w.innerHeight;
    var entry = rect.top - w.innerHeight;
    var percent = 100 / range * (entry * -1);
    return Math.max(0, Math.min(100, percent));
  };
  MlpScroll.prototype.apply = function (name, percent, data) {
    if ('down' === data.direction) {
      percent = 100 - percent;
    }
    percent = Math.max(data.range.start || 0, Math.min(data.range.end || 100, percent));
    var value = -(percent - 50) * (data.speed || 1);
    this.node.style.setProperty('--' + name, value + 'px');
  };
  MlpScroll.prototype.process = function () {
    var percent = this.progress();
    if (this.vertical) {
      this.apply('translateY', percent, this.vertical);
    }
    if (this.horizontal) {
      this.apply('translateX', percent, this.horizontal);
    }
  };
  MlpScroll.prototype.destroy = function () {
    cancelAnimationFrame(this.frame);
    w.removeEventListener('scroll', this.onScroll);
    w.removeEventListener('load', this.onScroll);
    this.node.style.transform = '';
  };
  function MultiLayerParallax(el, config) {
    this.el = el;
    this.config = config;
    this.nodes = [];
    this.scrolls = [];
    this.mode = mlpMode();
    this.destroyed = false;
    this.onMove = null;
    this.onResize = null;
    this.timer = null;
    var self = this;
    var layers = (Array.isArray(mlpDeep(config.layers)) ? mlpDeep(config.layers) : []).map(mlpLayer).filter(function (layer) {
      return !layer.hide;
    });
    this.devices = mlpDevices(mlpDeep(config.devices));
    this.layers = layers;
    mlpResolve(layers, function () {
      if (!self.destroyed) {
        self.build();
      }
    });
    this.onResize = function () {
      clearTimeout(self.timer);
      self.timer = setTimeout(function () {
        if (!self.destroyed && mlpMode() !== self.mode) {
          self.build();
        }
      }, 150);
    };
    w.addEventListener('resize', this.onResize);
  }
  MultiLayerParallax.prototype.clear = function () {
    this.scrolls.forEach(function (scroll) {
      scroll.destroy();
    });
    if (this.onMove) {
      this.el.removeEventListener('mousemove', this.onMove);
    }
    this.nodes.forEach(function (node) {
      if ('undefined' !== typeof gsap) {
        gsap.killTweensOf(node);
      }
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    this.scrolls = [];
    this.nodes = [];
    this.onMove = null;
  };
  MultiLayerParallax.prototype.build = function () {
    var self = this;
    var el = this.el;
    var mode = mlpMode();
    var scrollOn = this.devices.indexOf(mode) !== -1;
    var mouse = false;
    this.mode = mode;
    this.clear();
    el.classList.add(MLP_HOST);
    this.layers.forEach(function (layer, index) {
      if (!layer.url || layer.show_on.indexOf(mode) === -1) {
        return;
      }
      var node = d.createElement('div');
      var img = d.createElement('img');
      var track = 'mouse_track' === layer.effect && 0 !== layer.rate;
      img.className = 'ha-multi-layer-parallax-img';
      img.src = layer.url;
      img.alt = layer.alt;
      node.id = 'ha-multi-layer-parallax-' + String(el.getAttribute('data-id') || '').replace(/[^a-zA-Z0-9_-]/g, '') + '-' + index;
      node.className = MLP_CLASS + ' ha-multi-layer-parallax-' + layer.hor + ' ha-multi-layer-parallax-' + layer.ver + ' ha-multi-layer-parallax-img';
      node.setAttribute('data-parallax', track ? 'true' : 'false');
      node.style.zIndex = layer.z_index;
      node.style.width = layer.width + '%';
      if (track) {
        node.setAttribute('data-rate', layer.rate);
        mouse = true;
      }
      if ('custom' === layer.hor) {
        node.style.left = layer.hor_pos + '%';
      }
      if ('custom' === layer.ver) {
        node.style.top = layer.ver_pos + '%';
      }
      node.appendChild(img);
      el.insertBefore(node, el.firstChild);
      self.nodes.push(node);
      if (!scrollOn || 'scroll_parallax' !== layer.effect || !(layer.scroll_ver || layer.scroll_hor)) {
        return;
      }
      self.scrolls.push(new MlpScroll(node, layer.scroll_ver ? {
        speed: layer.speed,
        direction: layer.direction,
        range: layer.view
      } : null, layer.scroll_hor ? {
        speed: layer.speed_hor,
        direction: layer.direction_hor,
        range: layer.view_hor
      } : null));
    });
    if (mouse && 'undefined' !== typeof gsap) {
      this.onMove = function (event) {
        self.nodes.forEach(function (node) {
          if ('true' !== node.getAttribute('data-parallax')) {
            return;
          }
          var rate = parseFloat(node.getAttribute('data-rate'));
          gsap.to(node, {
            duration: 0.2,
            x: -((event.clientX - w.innerWidth / 2) / rate),
            y: -((event.clientY - w.innerHeight / 2) / rate)
          });
        });
      };
      el.addEventListener('mousemove', this.onMove);
    }
  };

  // The editor re-renders the container and drops the layers with it.
  MultiLayerParallax.prototype.isStale = function () {
    return this.nodes.length > 0 && (!this.nodes[0].isConnected || !this.el.classList.contains(MLP_HOST));
  };
  MultiLayerParallax.prototype.abandon = function () {
    this.destroyed = true;
    this.scrolls.forEach(function (scroll) {
      scroll.destroy();
    });
    if (this.onMove) {
      this.el.removeEventListener('mousemove', this.onMove);
    }
    w.removeEventListener('resize', this.onResize);
    clearTimeout(this.timer);
    this.scrolls = [];
    this.nodes = [];
  };
  MultiLayerParallax.prototype.destroy = function () {
    this.destroyed = true;
    this.clear();
    w.removeEventListener('resize', this.onResize);
    clearTimeout(this.timer);
    this.el.classList.remove(MLP_HOST);
  };
  addFeature({
    key: 'multi-layer-parallax',
    type: ['e-flexbox', 'e-div-block', 'e-grid'],
    prefix: 'ha_mlp_',
    Runtime: MultiLayerParallax,
    target: function target(node) {
      return node;
    }
  });

  /* ------------------------------------------------------------------ *
   * Boot
   * ------------------------------------------------------------------ */
  features.forEach(function (feature) {
    atomic.registerFeature(feature);
  });
})(window, document);