<?php
/**
 * Admin ajax handlers for the Pro version of the plugin.
 *
 * @package WPCode
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_ajax_wpcode_load_snippets', 'wpcode_ajax_snippets_list' );
add_action( 'wp_ajax_wpcode_load_selected_snippet', 'wpcode_ajax_selected_snippet' );
add_action( 'wp_ajax_wpcode_load_revision_detail', 'wpcode_load_revision_detail' );
add_action( 'wp_ajax_wpcode_verify_license', 'wpcode_verify_license' );
add_action( 'wp_ajax_wpcode_deactivate_license', 'wpcode_deactivate_license' );

add_action( 'wp_ajax_wpcode_install_addon', 'wpcode_install_addon' );

add_action( 'wp_ajax_wpcode_search_snippets', 'wpcode_ajax_search_snippets' );
add_action( 'wp_ajax_wpcode_search_posts', 'wpcode_ajax_search_posts' );
add_action( 'wp_ajax_wpcode_search_users', 'wpcode_ajax_search_users' );

add_action( 'wp_ajax_wpcode_refresh_library_cache', 'wpcode_refresh_library_cache' );
add_action( 'wp_ajax_wpcode_revisions_cleanup_step', 'wpcode_revisions_cleanup_step' );

// Override the sync snippet function to handle cloud snippets with higher priority.
add_action( 'wp_ajax_wpcode_sync_snippet', 'wpcode_sync_snippet_pro', 5 );
add_action( 'wp_ajax_wpcode_refresh_license', 'wpcode_refresh_license' );


/**
 * AJAX handler for syncing a snippet from the cloud library - Pro version.
 * This function overrides the one in the main plugin to handle cloud snippets.
 * If the snippet is not a cloud snippet, it returns early to let the lite version handle it.
 *
 * @return void
 */
function wpcode_sync_snippet_pro() {

	// Check nonce.
	if ( ! check_ajax_referer( 'wpcode_admin', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed.', 'insert-headers-and-footers' ) ) );
	}

	// Check permissions.
	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error( array( 'message' => __( 'You do not have permission to edit snippets.', 'insert-headers-and-footers' ) ) );
	}

	$snippet_id = isset( $_POST['snippet_id'] ) ? absint( $_POST['snippet_id'] ) : 0;
	$cloud_id   = isset( $_POST['cloud_id'] ) ? sanitize_text_field( wp_unslash( $_POST['cloud_id'] ) ) : false;

	// If this is not a cloud snippet, return early to let the lite version handle it.
	if ( empty( $cloud_id ) ) {
		return;
	}

	if ( ! $snippet_id ) {
		wp_send_json_error( array( 'message' => __( 'Invalid snippet ID.', 'insert-headers-and-footers' ) ) );
	}

	// Check if library is connected.
	if ( ! wpcode()->library_auth->has_auth() ) {
		wp_send_json_error( array( 'message' => __( 'You need to connect to the WPCode Library to sync cloud snippets.', 'insert-headers-and-footers' ) ) );
	}

	// Update snippet from cloud library.
	$result = wpcode()->my_library->update_snippet_from_library( $snippet_id, $cloud_id );

	if ( ! $result ) {
		wp_send_json_error( array( 'message' => __( 'Failed to update snippet from cloud library.', 'insert-headers-and-footers' ) ) );
	}

	wp_send_json_success(
		array(
			'message' => __( 'Snippet successfully updated from cloud library.', 'insert-headers-and-footers' ),
			'version' => ! empty( $result['version'] ) ? $result['version'] : '',
		)
	);
}

/**
 * Ajax handler to load a list of snippets.
 *
 * @return void
 */
function wpcode_ajax_snippets_list() {

	check_ajax_referer( 'wpcode_admin_global' );

	if ( ! current_user_can( 'wpcode_activate_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	$page     = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
	$post_id  = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	$search   = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
	$selected = isset( $_POST['selected'] ) ? array_map( 'absint', $_POST['selected'] ) : array();

	if ( 0 !== $post_id && empty( $selected ) ) {
		$selected_snippets = get_post_meta( $post_id, '_wpcode_page_snippets', true );
		if ( empty( $selected_snippet ) ) {
			$selected_snippets = array();
		}
		foreach ( $selected_snippets as $selected_snippet ) {
			if ( isset( $selected_snippet['snippet_id'] ) ) {
				$selected[] = absint( $selected_snippet['snippet_id'] );
			}
		}
	}

	$query_args = array(
		'post_type'      => 'wpcode',
		'posts_per_page' => 10,
		'paged'          => $page,
		'post_status'    => 'any',
	);

	if ( ! empty( $search ) ) {
		$query_args['s'] = trim( $search );
	}

	$snippets = get_posts( $query_args );

	$response = array(
		'snippets' => array(),
	);
	foreach ( $snippets as $snippet ) {
		$snippet_obj            = new WPCode_Snippet( $snippet );
		$response['snippets'][] = wpcode_get_snippet_item_picker( $snippet_obj, in_array( $snippet_obj->get_id(), $selected, true ) );
	}

	wp_send_json_success( $response );
}

/**
 * Ajax handler for loading the markup of a selected snippet in the Metabox.
 *
 * @return void
 */
function wpcode_ajax_selected_snippet() {
	check_ajax_referer( 'wpcode_admin_global' );

	if ( ! current_user_can( 'wpcode_activate_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	$snippet_id = isset( $_POST['snippet_id'] ) ? absint( $_POST['snippet_id'] ) : 0;
	$snippet    = new WPCode_Snippet( $snippet_id );

	if ( 0 === $snippet->get_id() ) {
		wp_send_json_error();
	}

	wp_send_json_success(
		array(
			'snippet' => wpcode_get_snippet_item_selected( $snippet, $snippet->get_location(), $snippet->get_auto_insert_number() ),
		)
	);
}

/**
 * Get the HTML markup for a snippet.
 *
 * @param int|WPCode_Snippet $snippet The snippet to get the markup for.
 * @param bool               $checked Is the checkbox checked (snippet selected).
 *
 * @return string
 */
function wpcode_get_snippet_item_picker( $snippet, $checked = false ) {
	if ( ! $snippet instanceof WPCode_Snippet ) {
		$snippet = new WPCode_Snippet( $snippet );
	}

	$markup = '<div class="wpcode-snippet-picker-item">';

	$markup .= sprintf(
		'<label for="wpcode-snippet-checkbox-%2$s">%1$s</label>',
		esc_html( $snippet->get_title() ),
		absint( $snippet->get_id() )
	);
	$markup .= wpcode_get_checkbox_toggle( $checked, 'wpcode-snippet-checkbox-' . $snippet->get_id(), '', absint( $snippet->get_id() ) );
	$markup .= '</div>';

	return $markup;
}

/**
 * Get the markup for a selected snippet with option to override the location.
 *
 * @param int|WPCode_Snippet $snippet The snippet id or snippet object.
 * @param string             $location The location to override the global une.
 * @param int                $insert_number The insert number for locations that need one.
 *
 * @return string
 */
function wpcode_get_snippet_item_selected( $snippet, $location, $insert_number ) {
	if ( ! $snippet instanceof WPCode_Snippet ) {
		$snippet = new WPCode_Snippet( $snippet );
	}

	$name        = "wpcode_auto_insert_override[{$snippet->get_id()}]";
	$name_number = "wpcode_auto_insert_number_override[{$snippet->get_id()}]";

	$markup = sprintf(
		'<div class="wpcode-list-item wpcode-selected-snippet-item wpcode-list-item-has-pill" id="%1$s" data-id="%2$s">',
		'wpcode-selected-snippet-' . $snippet->get_id(),
		$snippet->get_id()
	);
	if ( ! $snippet->is_active() ) {
		$markup .= sprintf(
			'<span class="wpcode-list-item-pill wpcode-list-item-pill-gray">%s</span>',
			__( 'Inactive', 'wpcode-premium' )
		);
	}
	$markup .= sprintf(
		'<div class="wpcode-list-item-top-actions"><button type="button" class="wpcode-button-just-icon wpcode-remove-snippet-item">%s</button></div>',
		get_wpcode_icon( 'trash' )
	);
	$markup .= sprintf(
		'<h3 title="%1$s">%2$s</h3>',
		esc_attr( $snippet->get_title() ),
		esc_html( $snippet->get_title() )
	);
	if ( '' !== $snippet->get_location() ) {
		$markup .= '<h4>';
		// Translators: The name of the global auto-insert location for a snippet loaded in the edit-post metabox.
		$markup .= sprintf( esc_html__( 'Global location: %s', 'wpcode-premium' ), wpcode()->auto_insert->get_location_label( $snippet->get_location() ) );
		if ( in_array( $snippet->get_location(), wpcode_get_auto_insert_locations_with_number(), true ) && $snippet->get_auto_insert_number() ) {
			$markup .= ' #' . $snippet->get_auto_insert_number();
		}
		$markup .= '</h4>';
	} else {
		$markup .= '<h4>' . __( 'Auto-insert disabled', 'wpcode-premium' ) . '</h4>';
	}
	$markup .= '<div class="wpcode-list-item-location-details">';
	$markup .= '<div class="wpcode-auto-insert-location-wrap">';
	$markup .= sprintf(
		'<label for="%1$s">%2$s</label>',
		$name,
		__( 'Page location:', 'wpcode-premium' )
	);
	$markup .= wpcode_get_auto_insert_location_picker( $location, $snippet->get_code_type(), $name );

	$markup .= '</div>';// End .wpcode-auto-insert-location-wrap.

	$insert_number_wrap_hidden = ! in_array( $location, wpcode_get_auto_insert_locations_with_number(), true ) ? ' wpcode-hidden' : '';

	$markup .= sprintf(
		'<div class="wpcode-auto-insert-number-wrap%1$s">',
		$insert_number_wrap_hidden
	);
	$markup .= sprintf(
		'<label for="%1$s">%2$s</label>',
		$name_number,
		__( 'Insert number:', 'wpcode-premium' )
	);
	$markup .= '<input type="number" name="' . esc_attr( $name_number ) . '" value="' . absint( $insert_number ) . '" />';
	$markup .= '</div>'; // .wpcode-auto-insert-number-wrap
	$markup .= '</div>'; // .wpcode-list-item-location-details

	$markup .= '</div>';

	return $markup;
}

/**
 * Load the detail panel for one revision compared with the live item.
 *
 * @return void
 */
function wpcode_load_revision_detail() {
	check_ajax_referer( 'wpcode_admin' );

	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) {
		wp_send_json_error();
	}

	$revision_id = isset( $_POST['revision'] ) ? absint( $_POST['revision'] ) : 0;
	$view        = $revision_id ? WPCode_Revisions_View::for_revision( $revision_id ) : null;

	if ( ! $view ) {
		wp_send_json_error();
	}

	// Same rules as viewing the page: Header & Footer needs a site-level capability, the rest edit_post.
	if ( WPCode_Revisions_View::TYPE_HEADER_FOOTER === $view->get_type() ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'unfiltered_html' ) ) {
			wp_send_json_error();
		}
	} elseif ( ! current_user_can( 'edit_post', $view->get_parent_id() ) ) {
		wp_send_json_error();
	}

	$revision = $view->get_revision( $revision_id );

	if ( ! $revision ) {
		wp_send_json_error();
	}

	// Not checked against the item's rows: the revision limit can remove the restored revision.
	$restored = isset( $_POST['restored'] ) ? absint( $_POST['restored'] ) : 0;

	wp_send_json_success(
		array(
			'markup' => $view->render_detail( $revision, $restored ),
		)
	);
}


/**
 * Verify license via Ajax.
 *
 * @since 2.1.0
 */
function wpcode_verify_license() {

	// Run a security check.
	check_ajax_referer( 'wpcode_admin' );

	// Check for permissions. The flag comes from the request as is_network_admin() is always false in admin-ajax.php.
	$multisite = is_multisite() && isset( $_POST['multisite'] ) && boolval( $_POST['multisite'] );
	if ( ! current_user_can( $multisite ? 'manage_network_options' : 'manage_options' ) ) {
		wp_send_json_error( null, 403 );
	}

	// Check for license key.
	if ( empty( $_POST['license'] ) ) {
		wp_send_json_error( esc_html__( 'Please enter a license key.', 'wpcode-premium' ) );
	}

	wpcode()->license->verify_key( sanitize_text_field( wp_unslash( $_POST['license'] ) ), true, $multisite );
}

/**
 * Deactivate license via Ajax.
 *
 * @since 2.1.0
 */
function wpcode_deactivate_license() {

	$true = true;

	// Run a security check.
	check_ajax_referer( 'wpcode_admin' );

	// Check for permissions. The flag comes from the request as is_network_admin() is always false in admin-ajax.php.
	$multisite = is_multisite() && isset( $_POST['multisite'] ) && boolval( $_POST['multisite'] );
	if ( ! current_user_can( $multisite ? 'manage_network_options' : 'manage_options' ) ) {
		wp_send_json_error( null, 403 );
	}

	$force = isset( $_POST['force'] ) && 'true' === $_POST['force'];

	wpcode()->license->deactivate_key( true, $force, $multisite );
}

/**
 * Ajax endpoint for installing an addon.
 *
 * @return void
 */
function wpcode_install_addon() {
	check_ajax_referer( 'wpcode_admin' );

	if ( ! wpcode()->addons->can_install() ) {
		wp_send_json_error(
			array(
				'message' => __( 'You do not have permission to install addons.', 'wpcode-premium' ),
			)
		);
	}

	$slug = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';

	if ( empty( $slug ) ) {
		wp_send_json_error(
			array(
				'message' => __( 'No addon slug provided.', 'wpcode-premium' ),
			)
		);
	}

	$multisite = isset( $_POST['multisite'] ) && boolval( $_POST['multisite'] );

	$addon = wpcode()->addons->install_addon( $slug, $multisite );

	if ( false === $addon ) {
		wp_send_json_error(
			array(
				'message' => __( 'Could not install addon.', 'wpcode-premium' ),
			)
		);
	}

	wp_send_json_success(
		array(
			'message' => __( 'Addon installed successfully.', 'wpcode-premium' ),
			'slug'    => $slug,
		)
	);
}

/**
 * Ajax endpoint for searching through snippets.
 *
 * @return void
 */
function wpcode_ajax_search_snippets() {
	check_ajax_referer( 'wpcode_admin' );

	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

	$snippets = get_posts(
		array(
			's'              => $term,
			'post_type'      => 'wpcode',
			'posts_per_page' => 10,
			'post_status'    => 'any',
		)
	);

	$results = array();

	foreach ( $snippets as $snippet ) {
		$results[] = array(
			'id'   => $snippet->ID,
			'text' => $snippet->post_title,
		);
	}

	wp_send_json(
		array(
			'results' => $results,
		)
	);
}

/**
 * Ajax endpoint for searching through posts.
 *
 * @return void
 */
function wpcode_ajax_search_posts() {
	check_ajax_referer( 'wpcode_admin' );

	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

	$public_post_types = get_post_types(
		array(
			'public' => true,
		)
	);

	$posts = get_posts(
		array(
			's'              => $term,
			'post_type'      => $public_post_types,
			'posts_per_page' => 10,
			'post_status'    => 'any',
			'orderby'        => 'relevance',
		)
	);

	$results = array();

	foreach ( $posts as $post ) {
		$results[] = array(
			'id'   => $post->ID,
			'text' => $post->post_title,
		);
	}

	wp_send_json(
		array(
			'results' => $results,
		)
	);
}

/**
 * Ajax callback for searching through users.
 *
 * @return void
 */
function wpcode_ajax_search_users() {
	check_ajax_referer( 'wpcode_admin' );

	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	$term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

	$users = get_users(
		array(
			'search'         => '*' . $term . '*',
			'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
			'number'         => 10,
		)
	);

	$results = array();

	foreach ( $users as $user ) {
		$results[] = array(
			'id'   => $user->ID,
			'text' => $user->display_name,
		);
	}

	wp_send_json(
		array(
			'results' => $results,
		)
	);
}

/**
 * AJAX handler for refreshing the library cache.
 * This is a global version of the maybe_refresh_library_cache method in class-wpcode-admin-page-code-snippets-pro.php.
 *
 * @return void
 */
function wpcode_refresh_library_cache() {
	// Check nonce.
	if ( ! check_ajax_referer( 'wpcode_admin', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed.', 'insert-headers-and-footers' ) ) );
	}

	// Check permissions.
	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error( array( 'message' => __( 'You do not have permission to check for updates.', 'insert-headers-and-footers' ) ) );
	}

	// Check if the library is connected.
	if ( ! wpcode()->library_auth->has_auth() ) {
		wp_send_json_error( array( 'message' => __( 'You need to connect to the WPCode Library to check for updates to your private library.', 'insert-headers-and-footers' ) ) );
	}

	// Attempt to refresh the library cache.
	$result = wpcode()->my_library->refresh_library_cache();

	// If the cache was not refreshed due to rate limiting.
	if ( ! $result ) {
		wp_send_json_error(
			array(
				'message'          => __( 'Please wait before checking again. You can check for private library updates once per minute.', 'insert-headers-and-footers' ),
				'recently_updated' => true,
			)
		);
	}

	wp_send_json_success( array( 'message' => __( 'Library cache refreshed successfully.', 'insert-headers-and-footers' ) ) );
}
/**
 * AJAX handler for refreshing the license status.
 *
 * @return void
 */
function wpcode_refresh_license() {

	// Run a security check.
	check_ajax_referer( 'wpcode_admin' );

	// Check for permissions.
	if ( ! current_user_can( 'wpcode_edit_snippets' ) ) { //phpcs:ignore
		wp_send_json_error();
	}

	// Get the multisite flag.
	$multisite = isset( $_POST['multisite'] ) && boolval( $_POST['multisite'] );

	// Get the license object.
	$license = wpcode()->license;

	// Get the license key.
	$license_key = $license->get( $multisite );

	// Check for license key.
	if ( empty( $license_key ) ) {
		wp_send_json_error( esc_html__( 'Please enter a license key.', 'wpcode-premium' ) );
	}

	// Validate the license key with force = true to refresh from server.
	$result = $license->validate_key( $license_key, true, false, false, $multisite );

	if ( $result ) {
		// Get the updated license type.
		$license_type = $license->type( $multisite );

		wp_send_json_success(
			array(
				'msg'  => esc_html__( 'License key refreshed successfully!', 'wpcode-premium' ),
				'type' => $license_type,
			)
		);
	} elseif ( $license->is_expired() ) {
		wp_send_json_error( esc_html__( 'Your license key has expired. Please renew your license.', 'wpcode-premium' ) );
	} elseif ( $license->is_disabled() ) {
		wp_send_json_error( esc_html__( 'Your license key has been disabled.', 'wpcode-premium' ) );
	} elseif ( $license->is_invalid() ) {
		wp_send_json_error( esc_html__( 'Your license key is invalid.', 'wpcode-premium' ) );
	} else {
		wp_send_json_error( esc_html__( 'There was an error refreshing your license. Please try again later.', 'wpcode-premium' ) );
	}
}

/**
 * Advance the user-triggered revision cleanup by one batch.
 *
 * Takes nothing from the request but the nonce. The limit, the items and the row count are all
 * re-derived server side from the saved settings, so a crafted request cannot widen what gets
 * deleted, and the run is bounded per call by the retention class.
 *
 * @return void
 */
function wpcode_revisions_cleanup_step() {
	// Its own nonce, not the shared wpcode_admin one. That action is minted on every WPCode admin
	// screen and shared with a dozen harmless endpoints; this one destroys history irreversibly, so
	// it should not be unlocked by a leak anywhere else in the plugin.
	// Keyed to the saved limit: a nonce minted while a different limit was in force no longer
	// verifies, so a stale tab cannot run a cleanup the dialog it is showing never described.
	if ( ! check_ajax_referer( 'wpcode_revisions_cleanup_' . wpcode()->revisions_retention->get_keep_count(), 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Security check failed.', 'wpcode-premium' ) ) );
	}

	// The same capability as the Settings page, so anyone shown the cleanup button can run it.
	if ( ! current_user_can( 'wpcode_manage_settings' ) ) {
		wp_send_json_error( array( 'message' => __( 'You do not have permission to remove revisions.', 'wpcode-premium' ) ) );
	}

	if ( ! isset( wpcode()->revisions_retention ) ) {
		wp_send_json_error( array( 'message' => __( 'Revision removal is not available.', 'wpcode-premium' ) ) );
	}

	$state = wpcode()->revisions_retention->cleanup_step();

	wp_send_json_success(
		array(
			'status'  => isset( $state['status'] ) ? $state['status'] : 'done',
			'removed' => isset( $state['removed'] ) ? absint( $state['removed'] ) : 0,
			'total'   => isset( $state['total'] ) ? absint( $state['total'] ) : 0,
		)
	);
}
