<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');


use com\sakuraplugins\appetit\utils\OptionUtil;

class TablesService {
    private static $instance = null;
    
    private $qr_tables_no = [];
    private $qr_tables_desc = [];

    function __construct() {
        $this->qr_tables_no = OptionUtil::getInstance()->getOption('qr_tables_no', []);
        $this->qr_tables_desc = OptionUtil::getInstance()->getOption('qr_tables_desc', []);
    }
    public function getTable($tableNo) {
        if (sizeof($this->qr_tables_no) === 0) {
            return null;
        }
        $out = null;
        for ($i = 0; $i < sizeof($this->qr_tables_no); $i++) { 
            if (intval($this->qr_tables_no[$i]) === intval($tableNo)) {
                $out = [
                    'tableNo' => $this->qr_tables_no[$i] ?? '',
                    'tableDesc' => $this->qr_tables_desc[$i] ?? '',
                ];
                break;
            }
        }
        return $out;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new TablesService();
        }
        return self::$instance;
    }
}
?>