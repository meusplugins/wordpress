import { Languages } from './LanguageUtils';
const STORAGE_KEY = 'appetit_329';

class StorageUtil {

	static isStorageSupported() {
		return typeof(Storage) !== 'undefined';
	}

	static setStorageData(dataObj) {
		if (!StorageUtil.isStorageSupported()) {
			return null;
		}		

		if (_.isString(dataObj)) {
			localStorage.setItem(STORAGE_KEY, dataObj);
			return true;
		} else if (_.isObject(dataObj)) {
			let serializiedData;
			try {
				serializiedData = JSON.stringify(dataObj);
				localStorage.setItem(STORAGE_KEY, serializiedData);
			} catch (err) { 
				console.log(err);
				return null;
			};
			return true;			
		}		
	}

	static getStorageData() {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}
		let data = null;
		try {
			let serializiedData = localStorage.getItem(STORAGE_KEY);
			data = JSON.parse(serializiedData);
		} catch (err) { data = null; console.log(err); };
		return data;
	}

	static setLanguage(language) {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}
		let allData = StorageUtil.getStorageData();
		if (_.isNil(allData)) {
			allData = {};
		}
		allData.language = language;
		StorageUtil.setStorageData(allData);
	}

	static getLanguage() {
		if (!StorageUtil.isStorageSupported()) {
			return null;
		}
		const allData = StorageUtil.getStorageData();
        return _.get(allData, 'language', Languages.PRIMARY);
	}

	static removeLanguage() {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}		
		StorageUtil.setLanguage(null);
	}

	static setData(key, value) {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}
		let allData = StorageUtil.getStorageData();
		if (_.isNil(allData)) {
			allData = {};
		}
		allData[key] = value;
		StorageUtil.setStorageData(allData);
	}

	static getData(key, defaultVal = null) {
		if (!StorageUtil.isStorageSupported()) {
			return null;
		}
		const allData = StorageUtil.getStorageData();
        return _.get(allData, key, defaultVal);
	}

	static removeData(key) {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}
		let allData = StorageUtil.getStorageData();
		if (_.isNil(allData)) {
			allData = {};
		}
		allData[key] = null;
		StorageUtil.setStorageData(allData);
	}

	static removeStorageData() {
		if (!StorageUtil.isStorageSupported()) {
			return;
		}
		try {
			localStorage.removeItem(STORAGE_KEY);
		} catch (err) { console.log(err) };		
	}	
}

export default StorageUtil;