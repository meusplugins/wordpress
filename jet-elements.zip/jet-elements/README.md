# JetElements For Elementor

Brand new addon for Elementor Page builder. It provides the set of modules to create different kinds of content, adds custom modules to your website and applies attractive styles in the matter of several clicks!

# ChangeLog

## [2.9.2.4](https://github.com/ZemezLab/jet-elements/archive/2.9.2.4.zip) - 09.10.2026
* Fixed: prevent stored XSS and validate dataset colors in Line Сhart widget

## [2.9.2.3](https://github.com/ZemezLab/jet-elements/archive/2.9.2.3.zip) - 05.10.2026
* Fixed: prevent stored XSS in pin popup links in Advanced Map

## [2.9.2.2](https://github.com/ZemezLab/jet-elements/archive/2.9.2.2.zip) - 14.09.2026
* Fixed: prevent stored XSS in Testimonials, Posts and Price List title tags

## [2.9.2.1](https://github.com/ZemezLab/jet-elements/archive/2.9.2.1.zip)
* Fixed: prevent untrusted file inclusion as custom map style;
* Fixed: restrict inline SVG file reads to the uploads directory.

## [2.9.2](https://github.com/ZemezLab/jet-elements/archive/2.9.2.zip) - 20.08.2026
* Added: [Crocoblock/suggestions#778](https://github.com/Crocoblock/suggestions/issues/778)
* Added: [Crocoblock/suggestions#1120](https://github.com/Crocoblock/suggestions/issues/1120)
* Added: [Crocoblock/suggestions#4442](https://github.com/Crocoblock/suggestions/issues/4442)
* Fixed: ampersand escaping in Animated Text widget
* Fixed: delay scratch canvas init in the Animated Box widget after popup open

## [2.9.1.2](https://github.com/ZemezLab/jet-elements/archive/2.9.1.2.zip) - 09.07.2026
* Fixed: attribute-context XSS in JetElements render paths

## [2.9.1.1](https://github.com/ZemezLab/jet-elements/archive/2.9.1.1.zip) - 07.07.2026
* Fixed: stored XSS in JetElements render helpers

## [2.9.1](https://github.com/ZemezLab/jet-elements/archive/2.9.1.zip) - 03.07.2026
* Fixed: slider background control visibility
* Fixed: portfolio dynamic images
* Fixed: animated box flip in Elementor Loop Carousel on mobile
* Fixed: mobile column width for scrollable Table widget
* Update: bump dashboard module 2.2.3

## [2.9.0.1](https://github.com/ZemezLab/jet-elements/archive/2.9.0.1.zip) - 22.05.2026
* Fixed: JetEngine query slider rendering with empty mapped fields

## [2.9.0](https://github.com/ZemezLab/jet-elements/archive/2.9.0.zip) - 19.05.2026
* Added: [Crocoblock/suggestions#2190](https://github.com/Crocoblock/suggestions/issues/2190)
* Added: [Crocoblock/suggestions#441](https://github.com/Crocoblock/suggestions/issues/441)
* Added: [Crocoblock/suggestions#1974](https://github.com/Crocoblock/suggestions/issues/1974)
* Added: [Crocoblock/suggestions#3569](https://github.com/Crocoblock/suggestions/issues/3569)
* Added: [Crocoblock/suggestions#1216](https://github.com/Crocoblock/suggestions/issues/1216)
* Added: [Crocoblock/suggestions#7565](https://github.com/Crocoblock/suggestions/issues/7565)

## [2.8.2](https://github.com/ZemezLab/jet-elements/archive/2.8.2.zip) - 17.04.2026
* Fixed: restore YouTube audio rendering via MediaElement in Audio Player
* Fixed: prevent fatal error when dynamic image tag returns string in Advanced Carousel
* Fixed: duplicated Lottie in Elementor editor listing items
* Fixed: slider init when used inside JetMenu mega menu content
* Fixed: prevent mobile swipe from skipping sections in Scroll Navigation widget
* Fixed: reset sticky hover state on mobile dots in Scroll Navigation widget

## [2.8.1.1](https://github.com/ZemezLab/jet-elements/archive/2.8.1.1.zip) - 02.03.2026
* Added: filter for template content

## [2.8.1](https://github.com/ZemezLab/jet-elements/archive/2.8.1.zip) - 25.02.2026
* Fixed: Elementor nested tabs compatibility - reinit only own widgets
* Fixed: Jet Video - hide background and add transition
* Fixed: Handle slider initialization inside nested accordion
* Update: Remove legacy Jet Templates feature
* Update: bump dashboard module to 2.1.8

## [2.8.0.2](https://github.com/ZemezLab/jet-elements/archive/2.8.0.2.zip) - 02.02.2026
* Fixed: restore Masonry layout for Instagram widget after 2.8.0 regression

## [2.8.0.1](https://github.com/ZemezLab/jet-elements/archive/2.8.0.1.zip) - 26.01.2026
* Fixed: enqueue jet-elements script for section parallax on frontend
* Fixed: improve section switch scrolling alignment

## [2.8.0](https://github.com/ZemezLab/jet-elements/archive/2.8.0.zip) - 15.01.2026
* Added: [Crocoblock/suggestions#221](https://github.com/Crocoblock/suggestions/issues/221)
* Added: [Crocoblock/suggestions#7824](https://github.com/Crocoblock/suggestions/issues/7824)
* Added: [Crocoblock/suggestions#5679](https://github.com/Crocoblock/suggestions/issues/5679)
* Added: [Crocoblock/suggestions#6987](https://github.com/Crocoblock/suggestions/issues/6987)
* Added: [Crocoblock/suggestions#6301](https://github.com/Crocoblock/suggestions/issues/6301)
* Added: [Crocoblock/suggestions#961](https://github.com/Crocoblock/suggestions/issues/961)
* Added: [Crocoblock/suggestions#8289](https://github.com/Crocoblock/suggestions/issues/8289)
* Fixed: removed extra escaping for variable

## [2.7.12.3](https://github.com/ZemezLab/jet-elements/archive/2.7.12.3.zip) - 23.12.2025
* Fixed: sanitize and escape JSON data-settings attributes in multiple widgets to prevent XSS

## [2.7.12.2](https://github.com/ZemezLab/jet-elements/archive/2.7.12.2.zip) - 15.12.2025
* Fixed: escape classes in Headline widget to prevent XSS
* Fixed: minor issue

## [2.7.12.1](https://github.com/ZemezLab/jet-elements/archive/2.7.12.1.zip) - 27.10.2025
* Fixed: Ensure image URL is properly escaped in Heading widget before print.

## [2.7.12](https://github.com/ZemezLab/jet-elements/archive/2.7.12.zip) - 20.10.2025
* Added: coordinates (lat/lon) support for Weather widget
* Fixed: prevent bullet flickering when jumping through multiple sections in Jet Scroll Navigation
* Fixed: detect dynamic tag values in tooltip check for pricing features
* Fixed: proper tooltip escaping in pricing features
* Fixed: improve smooth scroll navigation behavior on mobile devices
* Update: Changed description field type from TEXTAREA to WYSIWYG in Timeline widgets

## [2.7.11](https://github.com/ZemezLab/jet-elements/archive/2.7.11.zip) - 22.09.2025
* Added: "Scroll Threshold" setting to jet-scroll-navigation widget
* Fixed: [Crocoblock/suggestions#7129](https://github.com/Crocoblock/suggestions/issues/7129)
* Fixed: mobile layout detection in Elementor editor for Horizontal Timeline widget
* Fixed: pixel transparency detection in Animated Box widget
* Fixed: Progress bar overflow handling when current value exceeds maximum
* Fixed: add smooth scroll animation with configurable speed on desktop navigation

## [2.7.10.1](https://github.com/ZemezLab/jet-elements/archive/2.7.10.1.zip) - 09.09.2025
* Fixed: Countdown Timer widget broken on initial page load

## [2.7.10](https://github.com/ZemezLab/jet-elements/archive/2.7.10.zip) - 21.08.2025
* Fixed: WP Security Standard warnings

## [2.7.9.1](https://github.com/ZemezLab/jet-elements/archive/2.7.9.1.zip) - 04.08.2025
* Fixed: XSS vulnerability
* Fixed: move output buffer cleanup after validation checks
* Fixed: minor issue

## [2.7.9](https://github.com/ZemezLab/jet-elements/archive/2.7.9.zip) - 28.07.2025
* Added: [Crocoblock/suggestions#7600](https://github.com/Crocoblock/suggestions/issues/7600)
* Added: [Crocoblock/suggestions#8176](https://github.com/Crocoblock/suggestions/issues/8176)
* Update: restrict media control to SVG files
* Fixed: ignore swipe under 5px to avoid accidental switching in the scroll navigation widgets
* Fixed: minor issue

## [2.7.8.1](https://github.com/ZemezLab/jet-elements/archive/2.7.8.1.zip) - 10.07.2025
* Fixed: XSS vulnerability

## [2.7.8](https://github.com/ZemezLab/jet-elements/archive/2.7.8.zip) - 23.06.2025
* Added: [Crocoblock/suggestions#8144](https://github.com/Crocoblock/suggestions/issues/8144)
* Added: [Crocoblock/suggestions#2257](https://github.com/Crocoblock/suggestions/issues/2257)
* Added: [Crocoblock/suggestions#6835](https://github.com/Crocoblock/suggestions/issues/6835)
* Added: [Crocoblock/suggestions#3992](https://github.com/Crocoblock/suggestions/issues/3992)
* Added: completed class and styles for full progress bar
* Fixed: XSS vulnerability in Button and Download Button widgets
* Fixed: security vulnerability in AJAX `get_query_control_options` endpoint
* Fixed: minor issue

## [2.7.7](https://github.com/ZemezLab/jet-elements/archive/2.7.7.zip) - 23.05.2025
* Added: [Crocoblock/suggestions#1970](https://github.com/Crocoblock/suggestions/issues/1970)
* Added: [Crocoblock/suggestions#6180](https://github.com/Crocoblock/suggestions/issues/6180)
* Added: [Crocoblock/suggestions#7239](https://github.com/Crocoblock/suggestions/issues/7239)
* Added: WPML Media Translation support for image ID replacement
* Fixed: improve responsive behavior of `Fluid Columns Width` on mobile in the Advanced Carousel widget
* Fixed: anchor link in the Animated Box widget
* Fixed: prevent clicks on shuffled slides in the Slider widget
* Fixed: minor issue

## [2.7.6](https://github.com/ZemezLab/jet-elements/archive/2.7.6.zip) - 02.05.2025
* Added: [Crocoblock/suggestions#7977](https://github.com/Crocoblock/suggestions/issues/7977)
* Added: [Crocoblock/suggestions#7456](https://github.com/Crocoblock/suggestions/issues/7456)
* Added: [Crocoblock/suggestions#4977](https://github.com/Crocoblock/suggestions/issues/4977)
* Fixed: improve IntersectionObserver handling for scroll navigation widget
* Fixed: WPML compatibility
* Fixed: minor issue

## [2.7.5.1](https://github.com/ZemezLab/jet-elements/archive/2.7.5.1.zip) - 08.04.2025
* Fixed: background setting in the Audio Player widget

## [2.7.5](https://github.com/ZemezLab/jet-elements/archive/2.7.5.zip) - 31.04.2025
* Update: compatibility with Elementor 3.26
* Added: optimized Google Maps loading with defer
* Fixed: compatibility Elementor Loop Carousel with Audio Player widget
* Fixed: switch scratch type in the Animated Box widget for Jet Popup
* Fixed: minor issue

## [2.7.4.2](https://github.com/ZemezLab/jet-elements/archive/2.7.4.2.zip) - 14.03.2025
* Added: validation for widget_id: ensuring it's a string with a valid format
* Fixed: prevent unauthorized access to templates in REST API.

## [2.7.4.1](https://github.com/ZemezLab/jet-elements/archive/2.7.4.1.zip) - 27.02.2025
* Fixed: apply correct styles in the Advanced Map widget
* Fixed: prevents duplicate content rendering in the Dropbar widget

## [2.7.4](https://github.com/ZemezLab/jet-elements/archive/2.7.4.zip) - 21.02.2025
* Added: [Crocoblock/suggestions#7958](https://github.com/Crocoblock/suggestions/issues/7958)
* Added: option `Use Ajax Loading for Template` in the Dropbar widget
* Added: SVG icons for control buttons in the Video Player widget
* Update: Google Maps AdvancedMarkerElement implementation
* Update: Instagram Gallery widget
* Fixed: centered line in the Vertical Timeline widget
* Fixed: animate cards for mobile device in the Vertical Timeline widget
* Fixed: parallax section with Elements caching active
* Fixed: minor issue

## [2.7.3](https://github.com/ZemezLab/jet-elements/archive/2.7.3.zip) - 17.01.2025
* Added: [Crocoblock/suggestions#7931](https://github.com/Crocoblock/suggestions/issues/7931)
* Added: [Crocoblock/suggestions#7936](https://github.com/Crocoblock/suggestions/issues/7936)
* Fixed:  Audio Player widget formatting in Elementor tabs
* Fixed:  Instagram post link
* Fixed:  escaping attribute values
* Fixed:  compatibility Audio Player widget with Map Listing
* Fixed:  minor issue


## [2.7.2.1](https://github.com/ZemezLab/jet-elements/archive/2.7.2.1.zip) - 18.12.2024
* Fixed: [compatibility with JetEngine Query Gateway](https://github.com/Crocoblock/issues-tracker/issues/13589)

## [2.7.2](https://github.com/ZemezLab/jet-elements/archive/2.7.2.zip) - 09.12.2024
* Added: enqueue parallax stylesheets
* Fixed: Advanced Carousel navigation
* Fixed: Video Player with fullwidth container
* Update: migration from deprecated schemes to the new globals & compatibility with Elementor 3.26
* Update: Instagram API
* Delete: Waypoints JS


## [2.7.1.1](https://github.com/ZemezLab/jet-elements/archive/2.7.1.1.zip) - 01.11.2024
* Added: [Crocoblock/suggestions#7831](https://github.com/Crocoblock/suggestions/issues/7831)
* Added: [Crocoblock/suggestions#7836](https://github.com/Crocoblock/suggestions/issues/7836)
* Fixed: minor issue.

## [2.7.1](https://github.com/ZemezLab/jet-elements/archive/2.7.1.zip) - 28.10.2024
* Update: styles enqueue & compatibility with Elementor 3.24
* Added: widget output caching

## [2.7.0](https://github.com/ZemezLab/jet-elements/archive/2.7.0.zip) - 25.09.2024
* Added: [Crocoblock/suggestions#7547](https://github.com/Crocoblock/suggestions/issues/7547)
* Added: [Crocoblock/suggestions#6391](https://github.com/Crocoblock/suggestions/issues/6391)
* Added: сompatibility with Elementor 3.24
* Added: SVG icons for control buttons in the Audio widget
* Added: option `YouTube Shorts` in the Video Player widget
* Added: option `GDPR` for vimeo in the Video Player widget
* Fixed: escaping attribute values in the Slider widget
* Fixed: compatibility with deprecated methods
* Fixed: minor issues
* Update: Chart js

## [2.6.20.1](https://github.com/ZemezLab/jet-elements/archive/2.6.20.1.zip) - 09.08.2024
* Fixed: security issues

## [2.6.20](https://github.com/ZemezLab/jet-elements/archive/2.6.20.zip) - 06.08.2024
* Added: `Lazy Load Images` option in the Testimonials widget
* Added: compatibility slick carousel with Listing Grid widget
* Added: сompatibility with Elementor 3.24
* Fixed: navigation icon in the Slider widget
* Fixed: minor issues
* Update: JetDashboard Module to v2.2.0

## [2.6.19](https://github.com/ZemezLab/jet-elements/archive/2.6.19.zip) - 27.06.2024
* Fixed: fade animation effect for mobile Safari in the Animated Box widget
* Fixed: active dots during scroll up in the Scroll Navigation widget
* Fixed: arrow icon on Safari in the Slider widget
* Fixed: WPML compatibility for repeater widgets
* Fixed: minor issues

## [2.6.18](https://github.com/ZemezLab/jet-elements/archive/2.6.18.zip) - 14.05.2024
* Added: `jet-elements/advanced-map/query-arg` filter hook
* Added: new icons of widgets
* Fixed: incorrent numbers in the Progress Bar widget
* Fixed: triggers page transition in the Download Button
* Fixed: error and does not allow the Elementor ready templates to load
* Fixed: minor issues

## [2.6.17.1](https://github.com/ZemezLab/jet-elements/archive/2.6.17.1.zip) - 04.04.2024
* Fixed: minor bugs

## [2.6.17](https://github.com/ZemezLab/jet-elements/archive/2.6.17.zip) - 03.04.2024
* Fixed: slider item flashing in safari
* Fixed: overlay style with scratch switch type in the Animated Box widget
* Fixed: hover effects in the Button widget
* Fixed: compatibility with deprecated methods
* Fixed: correctly escape URL for all widgets where user can manually set a link
* Fixed: security issues
* Fixed: minor issues

## [2.6.16](https://github.com/ZemezLab/jet-elements/archive/2.6.16.zip) - 21.02.2024
* Added: [Crocoblock/suggestions#7318](https://github.com/Crocoblock/suggestions/issues/7318)
* Added: `Labels length` option in the Bar Chart Widget
* Fixed: styles in the widget Table for Safari browser
* Fixed: attached template's display in edit mode in the Dropbar widget
* Fixed: blur animation on mobile in the Animated Box widget
* Fixed: zoom for map listing in the Scroll Navigation widget
* Fixed: cache option in the Instagram widget
* Fixed: hover effects in the Button widget
* Fixed: minor issues
* Updated: JetDashboard Module

## [2.6.15](https://github.com/ZemezLab/jet-elements/archive/2.6.15.zip) - 16.01.2024
* Added: [Crocoblock/suggestions#7238](https://github.com/Crocoblock/suggestions/issues/7238)
* Added: `Lazy Load Images` option in the Advanced Carousel widget
* Fixed: `Slides to Scroll` option with widescreen breakpoints in the Image Comparison widget
* Fixed: float value in the Circle  Progress widget
* Fixed: plane shadow in the Button widget
* Fixed: minor issues

## [2.6.14](https://github.com/ZemezLab/jet-elements/archive/2.6.14.zip) - 06.11.2023
* Fixed: [Crocoblock/suggestions#6842](https://github.com/Crocoblock/suggestions/issues/6842)
* Fixed: Contact Form 7 styles
* Fixed: Second item stretch to full width in the Slider widget
* Fixed: Column Vertical Scrollbar with Sticky Column script conflict
* Fixed: nofollow attribute with image in the Portfolio widget
* Fixed: minor issues
* Added: Parallax Section compatibility with Elementor Dropdown Menu
* Added: `Slider CSS ID` option in the Slider widget
* Added: `Show current weather details in your timezone` option in the Weather widget
* Added: `Button Download Name` option in the Download Button widget
* Added: `jet-elements/download-button/label` filter hook
* Updated: Vue js module

## [2.6.13.2](https://github.com/ZemezLab/jet-elements/archive/2.6.13.2.zip) - 03.10.2023
* Fixed: elementor-template Rest API endpoint

## [2.6.13.1](https://github.com/ZemezLab/jet-elements/archive/2.6.13.1.zip) - 02.10.2023
* Fixed: minor issue.

## [2.6.13](https://github.com/ZemezLab/jet-elements/archive/2.6.13.zip) - 28.09.2023
* Updated: better encrypring logic for the download button
* Updated: security issue

## [2.6.12.2](https://github.com/ZemezLab/jet-elements/archive/2.6.12.2.zip) - 14.09.2023
* Updated: JetDashboard Module

## [2.6.12.1](https://github.com/ZemezLab/jet-elements/archive/2.6.12.1.zip) - 10.08.2023
* Fixed: Change template render method for Elementor to avoid errors in the editor

## [2.6.12](https://github.com/ZemezLab/jet-elements/archive/2.6.12.zip) - 03.08.2023
* Fixed: Сompatibility global styles for Elementor 3.15.0

## [2.6.11](https://github.com/ZemezLab/jet-elements/archive/2.6.11.zip) - 05.07.2023
* Fixed: Better sanitize custom callbacks before execute
* Fixed: minor issues

## [2.6.10](https://github.com/ZemezLab/jet-elements/archive/2.6.10.zip) - 29.05.2023
* Fixed: [Crocoblock/suggestions#6325](https://github.com/Crocoblock/suggestions/issues/6325)
* Fixed: [Crocoblock/suggestions#6326](https://github.com/Crocoblock/suggestions/issues/6326)
* Fixed: [Crocoblock/suggestions#6516](https://github.com/Crocoblock/suggestions/issues/6516)
* Fixed: [Crocoblock/suggestions#6578](https://github.com/Crocoblock/suggestions/issues/6578)
* Added: Advanced Carousel, Posts, Testimonials, Slider, Portfolio, Horizontal Timeline, Image Comparison compatibility with Elementor Dropdown Menu
* Fixed: Insert url for external thumbnail for Team Member, Slider widgets
* Fixed: Blocking scroll on mobile in Image Comparison widget
* Fixed: minor issues

## [2.6.9](https://github.com/ZemezLab/jet-elements/archive/2.6.9.zip) - 14.02.2023
* Added: [Crocoblock/suggestions#6345](https://github.com/Crocoblock/suggestions/issues/6345)
* Fixed: Widgets Accessibility
* Added: `Random Slides Order` option in the Advanced Carousel widget
* Added: `jet-elements/slider/slider-options` filter hook
* Added: `jet-elements/jet-testimonials/carousel-options` filter hook
* Added: `jet-elements/jet-image-comparison/carousel-options` filter hook
* Added: `jet-elements/jet-posts/carousel-options` filter hook
* Added: `jet-elements/jet-carousel/carousel-options` filter hook
* Added: `Show Title in a Lightbox Popup`, `Show Description in a Lightbox Popup` options for Instagram, Images Layout, Advanced Carousel, Portfolio widgets
* Fixed: minor issues

## [2.6.8](https://github.com/ZemezLab/jet-elements/archive/2.6.8.zip) - 21.11.2022
* Added: [Crocoblock/suggestions#5895](https://github.com/Crocoblock/suggestions/issues/5895)
* Added: [Crocoblock/suggestions#5938](https://github.com/Crocoblock/suggestions/issues/5938)
* Fixed: Horizontal Timeline widget compatibility with Elementor Additional Custom Breakpoints
* Added: Table widget compatibility with Elementor Additional Custom Breakpoints
* Added: `Lazy Load Images` option in the Slider widget for enable/disable lazy load Slider images
* Added: `Center Mode` option in Advanced Carousel and Testimonials widgets
* Added: Section Parallax compatibility with Elementor Flexbox Container
* Added: `Auto Close` option for Pins in the Advanced Map widget
* Added: `Use Custom Alignments` option for slides in the Slider widget
* Fixed: minor issues

## [2.6.7](https://github.com/ZemezLab/jet-elements/archive/2.6.7.zip) - 08.08.2022
* Added: [Crocoblock/suggestions#5447](https://github.com/Crocoblock/suggestions/issues/5447)
* Added: [Crocoblock/suggestions#5450](https://github.com/Crocoblock/suggestions/issues/5450)
* Added: [Crocoblock/suggestions#5536](https://github.com/Crocoblock/suggestions/issues/5536)
* Added: [Crocoblock/suggestions#2108](https://github.com/Crocoblock/suggestions/issues/2108)
* Fixed: [Crocoblock/suggestions#5532](https://github.com/Crocoblock/suggestions/issues/5532)
* Added: [Crocoblock/suggestions#5580](https://github.com/Crocoblock/suggestions/issues/5580)
* Added: [Crocoblock/suggestions#5596](https://github.com/Crocoblock/suggestions/issues/5596)
* Added: [Crocoblock/suggestions#5623](https://github.com/Crocoblock/suggestions/issues/5623)
* Added: `Add Encryption for Download ID` option in the Download Button widget
* Added: short youtube url support in the Video Player widget
* Fixed: Scroll Navigation widget compatibility with Elementor Flexbox Container
* Fixed: compatibility with Elementor 3.7
* Fixed: minor issues

## [2.6.6](https://github.com/ZemezLab/jet-elements/archive/2.6.6.zip) - 30.05.2022
* Fixed: [Crocoblock/suggestions#4587](https://github.com/Crocoblock/suggestions/issues/4587)
* Fixed: [Crocoblock/suggestions#3181](https://github.com/Crocoblock/suggestions/issues/3181)
* Fixed: [Crocoblock/suggestions#5411](https://github.com/Crocoblock/suggestions/issues/5411)
* Fixed: minor issues

## [2.6.5](https://github.com/ZemezLab/jet-elements/archive/2.6.5.zip) - 02.05.2022
* Fixed: [Crocoblock/issues-tracker#366](https://github.com/Crocoblock/issues-tracker/issues/366)

## [2.6.4](https://github.com/ZemezLab/jet-elements/archive/2.6.4.zip) - 14.04.2022
* Added: [Crocoblock/suggestions#4959](https://github.com/Crocoblock/suggestions/issues/4959)
* Added: [Crocoblock/suggestions#4921](https://github.com/Crocoblock/suggestions/issues/4921)
* Added: [Crocoblock/suggestions#4296](https://github.com/Crocoblock/suggestions/issues/4296)
* Added: [Crocoblock/suggestions#2009](https://github.com/Crocoblock/suggestions/issues/2009)
* Added: [Crocoblock/suggestions#5154](https://github.com/Crocoblock/suggestions/issues/5154)
* Fixed: animated box issues
* Fixed: widgets compatibility with new breakpoints

## [2.6.3](https://github.com/ZemezLab/jet-elements/archive/2.6.3.zip) - 23.03.2022
* Fixed: elementor 3.6 compatibility

## [2.6.2](https://github.com/ZemezLab/jet-elements/archive/2.6.2.zip) - 27.01.2022
* Added: [Crocoblock/suggestions#3657](https://github.com/Crocoblock/suggestions/issues/3657)
* Added: [Crocoblock/suggestions#3760](https://github.com/Crocoblock/suggestions/issues/3760)
* Added: [Crocoblock/suggestions#4465](https://github.com/Crocoblock/suggestions/issues/4465)
* Added: [Crocoblock/suggestions#3646](https://github.com/Crocoblock/suggestions/issues/3646)
* Added: [Crocoblock/suggestions#1754](https://github.com/Crocoblock/suggestions/issues/1754)
* Fixed: WPML compatibility
* Fixed: compatibility template library with Elementor 3.5
* Fixed: minor issues

## [2.6.1](https://github.com/ZemezLab/jet-elements/archive/2.6.1.zip) - 19.11.2021
* Fixed: js error in the Slider widget

## [2.6.0](https://github.com/ZemezLab/jet-elements/archive/2.6.0.zip) - 09.11.2021
* Added: [Crocoblock/suggestions#3227](https://github.com/Crocoblock/suggestions/issues/3227)
* Fixed: widgets compatibility with new breakpoints
* Fixed: PHP 8 compatibility
* Fixed: scratch type in the Animated Box widget
* Fixed: minor issues

## [2.5.9](https://github.com/ZemezLab/jet-elements/archive/2.5.9.zip) - 23.08.2021
* Added: [Crocoblock/suggestions#3624](https://github.com/Crocoblock/suggestions/issues/3624)
* Added: [Crocoblock/suggestions#3639](https://github.com/Crocoblock/suggestions/issues/3639)
* Fixed: RTL issues
* Fixed: WPML issues
* Fixed: PHP 8 compatibility
* Fixed: scratch type in the Animated Box widget
* Fixed: typing effect in the Animated Text widget
* Fixed: lightbox in the Portfolio widget
* Fixed: default slider height in the Slider widget

## [2.5.8](https://github.com/ZemezLab/jet-elements/archive/2.5.8.zip) - 23.06.2021
* Added: [Crocoblock/suggestions#1748](https://github.com/Crocoblock/suggestions/issues/1748)
* Added: [Crocoblock/suggestions#2518](https://github.com/Crocoblock/suggestions/issues/2518)
* Added: [Crocoblock/suggestions#2523](https://github.com/Crocoblock/suggestions/issues/2523)
* Added: [Crocoblock/suggestions#2520](https://github.com/Crocoblock/suggestions/issues/2520)
* Added: [Crocoblock/suggestions#2672](https://github.com/Crocoblock/suggestions/issues/2672)
* Added: [Crocoblock/suggestions#2532](https://github.com/Crocoblock/suggestions/issues/2532)
* Added: [Crocoblock/suggestions#3076](https://github.com/Crocoblock/suggestions/issues/3076)
* Added: [Crocoblock/suggestions#3133](https://github.com/Crocoblock/suggestions/issues/3133)
* Fixed: use global colors in the Circle Progress widget
* Fixed: tooltips in the Pricing Table widget
* Fixed: actions after expire in the Countdown widget
* Fixed: image border in the Team Member widget

## [2.5.7](https://github.com/ZemezLab/jet-elements/archive/2.5.7.zip) - 28.04.2021
* Updated: JetDashboard Module to v2.0.8
* Fixed: compatibility with Elementor 3.2

## [2.5.6](https://github.com/ZemezLab/jet-elements/archive/2.5.6.zip) - 08.04.2021
* Added: [Crocoblock/suggestions#2519](https://github.com/Crocoblock/suggestions/issues/2519)
* Added: [Crocoblock/suggestions#2562](https://github.com/Crocoblock/suggestions/issues/2562)
* Added: [Crocoblock/suggestions#2433](https://github.com/Crocoblock/suggestions/issues/2433)
* Added: [Crocoblock/suggestions#2910](https://github.com/Crocoblock/suggestions/issues/2910)
* Added: Elementor compatibility tag
* Added: validation the html tags settings
* Fixed: minor issues

## [2.5.5](https://github.com/ZemezLab/jet-elements/archive/2.5.5.zip) - 03.03.2021
* Added: [Crocoblock/suggestions#2504](https://github.com/Crocoblock/suggestions/issues/2504)
* Added: [Crocoblock/suggestions#2521](https://github.com/Crocoblock/suggestions/issues/2521)
* Fixed: [Crocoblock/suggestions#2723](https://github.com/Crocoblock/suggestions/issues/2723)
* Fixed: [Crocoblock/suggestions#2079](https://github.com/Crocoblock/suggestions/issues/2079)
* Fixed: Elementor 3.1.2 compatibility issue

## [2.5.4](https://github.com/ZemezLab/jet-elements/archive/2.5.4.zip) - 05.02.2021
* Added: [Crocoblock/suggestions#2025](https://github.com/Crocoblock/suggestions/issues/2025)
* Added: [Crocoblock/suggestions#2267](https://github.com/Crocoblock/suggestions/issues/2267)
* Added: [Crocoblock/suggestions#2378](https://github.com/Crocoblock/suggestions/issues/2378)
* Added: [Crocoblock/suggestions#2486](https://github.com/Crocoblock/suggestions/issues/2486)
* Added: [Crocoblock/suggestions#2082](https://github.com/Crocoblock/suggestions/issues/2082)
* Added: [Crocoblock/suggestions#2104](https://github.com/Crocoblock/suggestions/issues/2104)
* Fixed: text spacing in the Animated Text widget
* Fixed: image margin in the Testimonials widget

## [2.5.3](https://github.com/ZemezLab/jet-elements/archive/2.5.3.zip) - 17.12.2020
* Updated: JetDashboard Module to v2.0.6
* Added: better compatibility with WPML
* Added: better compatibility the Audio widget with Dynamic Tags
* Added: `Link Hover Color` control in the Advanced Carousel widget
* Added: `Content Alignment` control in the Button widget
* Added: DMS format for coordinates in the Advanced Map widget
* Added: [Crocoblock/suggestions#1925](https://github.com/Crocoblock/suggestions/issues/1925)
* Fixed: minor bugs

## [2.5.2](https://github.com/ZemezLab/jet-elements/archive/2.5.2.zip) - 12.11.2020
* Updated: JetDashboard Module to v2.0.4

## [2.5.1](https://github.com/ZemezLab/jet-elements/archive/2.5.1.zip) - 11.11.2020
* Updated: JetDashboard Module to v2.0.3

## [2.5.0](https://github.com/ZemezLab/jet-elements/archive/2.5.0.zip) - 10.11.2020
* Added: new Line Chart widget
* Added: [Crocoblock/suggestions#1321](https://github.com/Crocoblock/suggestions/issues/1321)
* Added: [Crocoblock/suggestions#1371](https://github.com/Crocoblock/suggestions/issues/1371)
* Updated: JetDashboard Module to v2.0.2

## [2.4.1](https://github.com/ZemezLab/jet-elements/archive/2.4.1.zip) - 19.10.2020
* Added: native lazy loading for images
* Added: an ability to use the official Instagram Graph API for getting tagged photos in the Instagram widget

## [2.4.0](https://github.com/ZemezLab/jet-elements/archive/2.4.0.zip) - 06.10.2020
* Updated: JetDashboard Module to v2.0.0

## [2.3.3](https://github.com/ZemezLab/jet-elements/archive/2.3.3.zip) - 28.08.2020
* Fixed: compatibility with Elementor 3.0 ( Repeater issue )
* Fixed: a fold init in the Pricing table widget

## [2.3.2](https://github.com/ZemezLab/jet-elements/archive/2.3.2.zip) - 17.08.2020
* Added: compatibility the Vertical Timeline widget with popups
* Added: getting a list of templates in controls through ajax
* Fixed: compatibility with Elementor Pro

## [2.3.1](https://github.com/ZemezLab/jet-elements/archive/2.3.1.zip) - 28.07.2020
* Added: [Crocoblock/suggestions#788](https://github.com/Crocoblock/suggestions/issues/788)
* Added: [Crocoblock/suggestions#885](https://github.com/Crocoblock/suggestions/issues/885)
* Added: [Crocoblock/suggestions#1212](https://github.com/Crocoblock/suggestions/issues/1212)
* Added: [Crocoblock/suggestions#1240](https://github.com/Crocoblock/suggestions/issues/1240)
* Added: [Crocoblock/suggestions#1241](https://github.com/Crocoblock/suggestions/issues/1241)
* Added: [Crocoblock/suggestions#1258](https://github.com/Crocoblock/suggestions/issues/1258)
* Added: tooltips in the featured list in the Pricing List widget
* Added: an ability fold the featured list in the Pricing List widget

## [2.3.0](https://github.com/ZemezLab/jet-elements/archive/2.3.0.zip) - 16.07.2020
* Added: new Lottie widget
* Added: elements order controls in the Pricing Table widget
* Added: an ability to use dynamic tags in the Custom Access Token control of Instagram widget
* Added: multiple performance improvements and bug fixes
* Update: JetDashboard Module to v1.0.16

## [2.2.17](https://github.com/ZemezLab/jet-elements/archive/2.2.17.zip) - 10.05.2020
* Fixed: backward compatibility with deprecated methods

## [2.2.16](https://github.com/ZemezLab/jet-elements/archive/2.2.16.zip) - 09.05.2020
* Added: compatibility with deprecated methods

## [2.2.15](https://github.com/ZemezLab/jet-elements/archive/2.2.15.zip) - 09.05.2020
* Added: `Column Vertical Scrollbar` option to the Jet Advanced settings
* Added: better compatibility with Multi-language plugins
* Added: compatibility waypoint callbacks inside popups
* Update: Countdown Timer js
* Fixed: PHP 7+ compatibility
* Fixed: Slider widget with Elementor entrance animation in template

## [2.2.14](https://github.com/ZemezLab/jet-elements/archive/2.2.14.zip) - 21.04.2020
* Added: `Open link in new window` and `Add nofollow` controls for the social link in the Team Member widget
* Fixed: [#1116](https://github.com/Crocoblock/suggestions/issues/1116)
* Fixed: prevent error in svg-manager

## [2.2.13](https://github.com/ZemezLab/jet-elements/archive/2.2.13.zip) - 31.03.2020
* Added: `Alignment` control for items in the Countdown Timer widget
* Added: `Alignment` control for the form in the Subscribe widget
* Added: Possibility to display float numbers in Bar Chart widget
* Added: better compatibility the Image Comparison widget with Dynamic Tags

## [2.2.12](https://github.com/ZemezLab/jet-elements/archive/2.2.12.zip) - 16.03.2020
* Added: `alt` attribute for images in the Instagram Gallery widget
* Update: JetDashboard Module to v1.0.11
* Fixed: minor issue in the Animated Box widget

## [2.2.11](https://github.com/ZemezLab/jet-elements/archive/2.2.11.zip) - 10.03.2020
* Fixed: Animated Box widget on mobile devices

## [2.2.10](https://github.com/ZemezLab/jet-elements/archive/2.2.10.zip) - 26.02.2020
* Update: Instagram widget for new API
* Update: a link on how to get Instagram Access Token

## [2.2.9](https://github.com/ZemezLab/jet-elements/archive/2.2.9.zip) - 21.02.2020
* Added: compatibility with Custom Link Attributes in Elementor 2.9
* Added: `alt` attribute for images in the Image Comparison widget
* Fixed: compatibility with Elementor 2.9


## [2.2.8](https://github.com/ZemezLab/jet-elements/archive/2.2.8.zip) - 13.02.2020
* Added: an ability URL instead of Lightbox on Images in the Portfolio widget ([#695](https://github.com/CrocoBlock/suggestions/issues/695))
* Added: ability to disable on mobile the Scroll Navigation ([#170](https://github.com/CrocoBlock/suggestions/issues/170))
* Added: `Slides to Scroll` control in the Horizontal Timeline widget ([#808](https://github.com/CrocoBlock/suggestions/issues/808))
* Added: better compatibility with WPML and Elementor Popup Actions
* Update: JetDashboard Module to v1.0.10
* Fixed: style conflict in the Audio widget ([#738](https://github.com/CrocoBlock/suggestions/issues/738))
* Fixed: display `excerpt` in the Posts widget on Archives Pages


## [2.2.7](https://github.com/ZemezLab/jet-elements/archive/2.2.7.zip) - 30.01.2020
* Added: an ability to use dynamic tags in the Thumbnail control of Video widget
* Added: an ability to use dynamic tags in the Text image controls of Headline widget
* Added: `Max Terms to Show` control in the Posts widget
* Added: `Shuffle Image List` control in the Images Layout widget
* Added: `rel` attributes for Download Button Widget
* Added: `jquery` dependency for the SliderPro js script
* Update: Jet-Dashboard Module to v1.0.9

## [2.2.6](https://github.com/ZemezLab/jet-elements/archive/2.2.6.zip) - 20.12.2019
* Added: RTL support in the Horizontal Timeline widget
* Added: `Image Size` control in the Timeline widget

## [2.2.5](https://github.com/ZemezLab/jet-elements/archive/2.2.5.zip) - 19.12.2019
* Update: Jet-Dashboard Module to v1.0.8

## [2.2.4](https://github.com/ZemezLab/jet-elements/archive/2.2.4.zip) - 13.12.2019
* Update: Jet-Dashboard Module to v1.0.7

## [2.2.3](https://github.com/ZemezLab/jet-elements/archive/2.2.3.zip) - 11.12.2019
* Update: Jet-Dashboard Module

## [2.2.2](https://github.com/ZemezLab/jet-elements/archive/2.2.2.zip) - 05.12.2019
* Fixed: minor bugs

## [2.2.1](https://github.com/ZemezLab/jet-elements/archive/2.2.1.zip) - 03.12.2019
* Update: Jet-Dashboard Module Initialization

## [2.2.0](https://github.com/ZemezLab/jet-elements/archive/2.2.0.zip) - 29.11.2019
* Added: Jet-Dashboard Module

## [2.1.6](https://github.com/ZemezLab/jet-elements/archive/2.1.6.zip) - 29.11.2019
* Added: compatibility the Image Comparison Widget with a3 lazy load plugin
* Added: better compatibility the Download Button widget with WPML plugin
* Fixed: issues in the Animation Box widget
* Fixed: prevent php error on update DB

## [2.1.5](https://github.com/ZemezLab/jet-elements/archive/2.1.5.zip) - 19.11.2019
* Fixed: js issue in the Animation Box widget

## [2.1.4](https://github.com/ZemezLab/jet-elements/archive/2.1.4.zip) - 05.11.2019
* Added: new the Parallax Types: `Scrolling Blur` and `Scrolling Transparency`
* Added: date callbacks for prepare meta values in the Posts widget
* Added: better compatibility the Horizontal Timeline widget with OceanWP theme
* Fixed: prevent js errors in IE

## [2.1.3](https://github.com/ZemezLab/jet-elements/archive/2.1.3.zip) - 24.10.2019
* Added: new the Parallax Types: `Horizontal Scroll` and `Scrolling Rotate`
* Update: a link on how to get Instagram Access Token
* Fixed: `Pull Up` animation effect in the Animation Box widget
* Fixed: prevent php error on update DB
* Fixed: prevent PHP error on PHP 5.4 server

## [2.1.2](https://github.com/ZemezLab/jet-elements/archive/2.1.2.zip) - 11.10.2019
* Added: filter hook 'jet-elements/posts/meta_callbacks' for the Custom Fields meta value callback in the Posts Widget
* Update: Weather widget for New weather API
* Fixed: grid layout in the Portfolio widget

## [2.1.1](https://github.com/ZemezLab/jet-elements/archive/2.1.1.zip) - 08.10.2019
* Fixed: js issue in the Animation Box widget

## [2.1.0](https://github.com/ZemezLab/jet-elements/archive/2.1.0.zip)
* Added: Bar Chart widget
* Added: New Animation Effects in the Animated Box widget
* Added: an ability to use dynamic tags in the Countdown Timer widget
* Added: an ability to use lightbox in the Video Player Widget
* Added: an ability to use dynamic tags for numeric controls
* Added: responsive control to the Map Height control in the Advanced Map widget
* Added: `Hide items with a missing price` control in the Price List widget
* Added: compatibility with JetStylesManager plugin
* Added: `HTML tag` control in the Animated Text widget
* Added: better compatibility with dynamic data in the Audio and Video widgets
* Fixed: prevent PHP error in the Testimonial widget
* Fixed: ajax error in the Subscribe widget
* Fixed: Street View Controls in the Advanced Map widget
* Fixed: Slider widget compatibility with third-party lazy loading plugins
* Fixed: lightbox by categories in the Portfolio widget
* Fixed: responsive mode in the Table widget

## [2.0.1](https://github.com/ZemezLab/jet-elements/archive/2.0.1.zip) - 19.08.2019
* Added: link control in the Testimonials widget
* Fixed: js issue in the Animation Box widget

## [2.0.0](https://github.com/ZemezLab/jet-elements/archive/2.0.0.zip) - 14.08.2019
* Added: Editor Load Level Option
* Added: compatibility with new Icons control
* Added: toggle event in the Animated Box widget
* Added: template content in the Animated Box widget
* Added: better RTL compatibility in the Advanced Carousel widget
* Added: multiple performance improvements and bug fixes
* Update: settings page

## [1.15.16](https://github.com/ZemezLab/jet-elements/archive/1.15.16.zip) - 24.07.2019
* Added: `vh` size unit to the Item Height control in the Images Layout widget
* Added: FA5 compatibility for styles
* Fixed: prevent PHP errors on some sites in the editor

## [1.15.15](https://github.com/ZemezLab/jet-elements/archive/1.15.15.zip) - 11.07.2019
* Added: actions after expire timer in the Countdown Timer widget
* Added: evergreen timer type in the Countdown Timer widget
* Added: Endless timer type in the Countdown Timer widget
* Added: `Content Motion Effect` control in the Slider Widget
* Added: Ability to use Elementor templates in the Advanced Carousel Widget
* Added: responsive controls to the `Border Radius` and to the `Item Margin` in the Testimonials Widget
* Added: need helps links to widgets
* Fixed: enqueue `jquery tablesorter` script when not used ([#344](https://github.com/CrocoBlock/suggestions/issues/344))
* Fixed: style conflict in the Download button widget with BeTheme theme

## [1.15.14](https://github.com/ZemezLab/jet-elements/archive/1.15.14.zip) - 12.06.2019
* Added: `Terms Links` in the Posts Widget
* Added: an ability to use Elementor templates in the Slider Widget
* Added: an ability to use dynamic tags in the Table widget
* Added: `Alignment` responsive control for custom fields in the Posts widget
* Fixed: displaying a button in the Advanced Carousel widget

## [1.15.13](https://github.com/ZemezLab/jet-elements/archive/1.15.13.zip) - 30.05.2019
* Added: option to open images in lightbox slider in the Instagram Gallery Widget
* Added: responsive control to the `Fixed position` in the Dropbar Widget
* Added: responsive control to the `Column Padding` in the Posts widget
* Added: `Vertical Alignment` control for buttons (if enabled the Equal Columns Height option) in the Posts Widget
* Added: additional size units to the `Point Size` control in Vertical Timeline and Horizontal Timeline Widgets
* Added: `Action Button` in Vertical Timeline and Horizontal Timeline Widgets
* Added: additional size units to `Height` control in the Animated Box Widget
* Added: responsive controls to `Thumbnail width` and `Thumbnail height` in the Slider Widget
* Added: `Text Direction` control in the Animated Text Widget
* Added: several improvements in the Advanced Carousel Widget ([#218](https://github.com/CrocoBlock/suggestions/issues/218))
* Added: `Center Mode` control in the Advanced Carousel Widget
* Update: max value the option `Number of instagram posts` now is 50 in the Instagram Gallery Widget
* Fixed: translate week day in the Weather Widget
* Fixed: not correct displaying excerpt in the editor in the Posts Widget
* Fixed: `Contain` Image Scale Mode in the Slider Widget

## [1.15.12](https://github.com/ZemezLab/jet-elements/archive/1.15.12.zip) - 15.05.2019
* Added: rating for items in the Testimonials Widget
* Added: `Title HTML Tag` control in the Vertical Timeline Widget
* Fixed: display svg in the Inline SVG Widget

## [1.15.11](https://github.com/ZemezLab/jet-elements/archive/1.15.11.zip) - 09.05.2019
* Added: display the SVG thumbnails in media library and featured image
* Added: `Featured Image Size` control for `Box Background` layout in the Posts Widget
* Update: minify assets
* Update: Scroll navigation js script
* Fixed: Posts Carousel behavior when found posts less than number slides to show

## [1.15.10](https://github.com/ZemezLab/jet-elements/archive/1.15.10.zip) - 24.04.2019
* Added: the ability to use dynamic tags for decorative images in the Headline Widget
* Update: replace Home URL with site URL in framework loader

## [1.15.9](https://github.com/ZemezLab/jet-elements/archive/1.15.9.zip) - 22.04.2019
* Added: `alt` attribute for images in widgets
* Added: `rel` and `target` attributes for buttons in widgets
* Update: disabled lazy load images by WP Rocket in the Images Comparison Widget

## [1.15.8](https://github.com/ZemezLab/jet-elements/archive/1.15.8.zip) - 08.04.2019
* Hot Fix: scroll navi widget

## [1.15.7](https://github.com/ZemezLab/jet-elements/archive/1.15.7.zip) - 04.04.2019
* Fixed: scroll navi widget / section switching function
* Fixed: subscribe widget / ajax url
* Fixed: compatibility with the wpml old versions
* Fixed: dynamic alt in the Portfolio Widget

## [1.15.5](https://github.com/ZemezLab/jet-elements/archive/1.15.5.zip) - 18.03.2019
* Added: allow to use dynamic tags in the Inline Svg Widget
* Added: link attributes for action button in the Pricing Table widget
* Update: CX Framework
* Update: max value the option `Number of forecast days` now is 7 in the Weather Widget
* Fixed: console error in the Circle Progress Widget
* Fixed: the height of the slider does not work for the tablet in the editor mode
* Fixed: alt attribute of image in the Banner Widget
* Fixed: alt attribute of image in the Team Member Widget

## [1.15.4](https://github.com/ZemezLab/jet-elements/archive/1.15.4.zip)
* Added: `Scheme_Typography`in the Dropbar Widget
* Fixed: compatibility with Elementor 2.5.0
* Fixed: Jetpack compatibility
* Fixed: displaying `0` string in the Table Widget

## [1.15.3](https://github.com/ZemezLab/jet-elements/archive/1.15.3.zip)
* Added: compatibility with Elementor 2.5.0
* Fixed: minor bugs

## [1.15.2](https://github.com/ZemezLab/jet-elements/archive/1.15.2.zip)
* Added: Jetpack compatibility in the Instagram Gallery Widget
* Added: New options for content wrapper in the Slider Widget
* Added: better wpml compatibility in the Table Widget
* Update: max value for `Item Per Page` option in the Portfolio Widget is 50
* Fixed: enqueue preview styles
* Fixed: 6 column layout in the Portfolio Widget

## [1.15.1](https://github.com/ZemezLab/jet-elements/archive/1.15.1.zip)
* Added: the ability to set custom style json in the Advanced Map Widget
* Added: several performance improvements
* Fixed: thumbnail size on mobile in the Posts Widget

## [1.15.0](https://github.com/ZemezLab/jet-elements/archive/1.15.0.zip)
* Added: Pie Charts widget
* Added: Column flex orientation
* Added: better compatibility with dynamic tags in the Video and Audio widgets
* Fixed: Scheme_Typography in the Services Widget
* Fixed: minor css bugs

## [1.14.10](https://github.com/ZemezLab/jet-elements/archive/1.14.10.zip)
* Added: compatibility with Elementor 2.4.0
* Added: `Show/Hide title` option in the Weather Widget
* Update: cherry-framework to 1.5.11
* Fixed: prevent js error in the IE browser
* Fixed: prevent error in the Instagram Gallery Widget
* Fixed: minor css bugs

## [1.14.9](https://github.com/ZemezLab/jet-elements/archive/1.14.9.zip)
* Added: responsive control to the `Alignment` in the Headline widget
* Fixed: Weather Widget

## [1.14.8](https://github.com/ZemezLab/jet-elements/archive/1.14.8.zip)
* Fixed: displaying filters if using Dynamic Data Addon in the Portfolio Widget
* Added: multiple performance improvements and bug fixes

## [1.14.7](https://github.com/ZemezLab/jet-elements/archive/1.14.7.zip)
* Added: Allow to use dynamic tags in the Jet Parallax Sections
* Added: compatibility a URL controls in widgets with WPML plugin
* Added: gradient options for text elements in the Headline Widget
* Fixed: displaying filtered items in the Portfolio Widget

## [1.14.6](https://github.com/ZemezLab/jet-elements/archive/1.14.6.zip)
* Added: `Button Alignment` option in the Download Button Widget
* Added: `Image Size` option in the Images Layout Widget
* Added: `Image Size` option in the Portfolio Widget
* Fixed: compatibility with Elementor 2.3.3
* Fixed: html validation errors in the Table Widgets

## [1.14.5](https://github.com/ZemezLab/jet-elements/archive/1.14.5.zip)
* Added: RU localization

## [1.14.4](https://github.com/ZemezLab/jet-elements/archive/1.14.4.zip)
* Fixed: carousel mode in the Posts Widget

## [1.14.3](https://github.com/ZemezLab/jet-elements/archive/1.14.3.zip)
* Added: Changelog link
* Fixed: prevent php error on multisite
* Fixed: minor css bugs

## [1.14.2](https://github.com/ZemezLab/jet-elements/archive/1.14.2.zip)
* Fixed: Elementor 2.3.0 compatibility
* Fixed: typing effect in the Animated Text Widget
* Fixed: Subscribe Widget

## [1.14.1](https://github.com/ZemezLab/jet-elements/archive/1.14.1.zip)
* Added: multiple performance improvements and bug fixes

## [1.14.0](https://github.com/ZemezLab/jet-elements/archive/1.14.0.zip)
* Added: new Horizontal Timeline Widget
* Added: ability using dynamic tags in widgets
* Added: multiple performance improvements and bug fixes

## [1.13.3](https://github.com/ZemezLab/jet-elements/archive/1.13.3.zip)
* Added: responsive controls for `Circle Size`, `Value Stoke Width`, `Background Stoke Width` in the Circle Progress Widget
* Added: better RTL compatibility in the widgets Advanced Carousel, Image-Comparison, Testimonials, Posts, Slider
* Added: better compatibility the Video Player Widget with Astra theme
* Update: anime.js to 2.2.0
* Fixed: Instagram Widget
* Fixed: `Show Thousand Separator` option in the Circle Progress Widget

## [1.13.2](https://github.com/ZemezLab/jet-elements/archive/1.13.2.zip)
* Added: allow to set dynamic location in the Weather widget
* Added: allow to use dynamic tags in the Download button widget
* Fixed: encoding bug `&` in the Advanced Map Widget

## [1.13.1](https://github.com/ZemezLab/jet-elements/archive/1.13.1.zip)
* Added: compatibility with `WPML String Translation` plugin for new widgets
* Update: keywords list in the language file
* Fixed: js conflict with `Ultimate Addons` plugin
* Added: multiple performance improvements and bug fixes

## [1.13.0](https://github.com/ZemezLab/jet-elements/archive/1.13.0.zip)
* Added: new Audio Player Widget
* Added: new Video Player Widget
* Added: new Dropbar Widget
* Added: additional fields in the Subscribe Widget
* Added: multiple performance improvements and bug fixes

## [1.12.3](https://github.com/ZemezLab/jet-elements/archive/1.12.3.zip)
* ADD: Allow to filter repeater items before processing.

## [1.12.2](https://github.com/ZemezLab/jet-elements/archive/1.12.2.zip)
* Added: Related posts option for 'Query by' control in Posts widget
* Added: 'Use as archive template' control in Posts widget
* Added: layout generator notice in CF7 widget
* Fixed: week day localization in the Weather Widget

## [1.12.1](https://github.com/ZemezLab/jet-elements/archive/1.12.1.zip)
* Fixed: stretching of images in the Internet Explorer browser in the Advanced Carousel Widget

## [1.12.0](https://github.com/ZemezLab/jet-elements/archive/1.12.0.zip)
* Added: new Weather Widget
* Added: new Table Widget
* Added: All Filter Label option in the Portfolio Widget
* Added: Scrolling Zoom Parallax Type in the Parallax extension
* Added: Transform 3D Animation Property in the Parallax extension
* Fixed: not working `Back to default` button in the Box-Style Group Control
* Added: multiple performance improvements and bug fixes

## [1.11.2](https://github.com/ZemezLab/jet-elements/archive/1.11.2.zip)
* ADD: Custom Query controls for Posts widget

## [1.11.1](https://github.com/ZemezLab/jet-elements/archive/1.11.1.zip)
* FIX: prevent error in PHP 5.4

## [1.11.0](https://github.com/ZemezLab/jet-elements/archive/1.11.0.zip)
* Added: Timeline Widget
* Added: Inline SVG Widget
* Added: Price List Widget
* Added: multiple performance improvements and bug fixes

## [1.10.4](https://github.com/ZemezLab/jet-elements/archive/1.10.4.zip)
* Fixed: Elementor 2.1 compatibility

## [1.10.3](https://github.com/ZemezLab/jet-elements/archive/1.10.3.zip)
* Added: Scroll Navi / scroll offset option
* Added: Slider Widget / slider height vh(viewport height) unit
* Fixed: Slider Widget / image tag sizes attr(w3c validation)

## [1.10.2](https://github.com/ZemezLab/jet-elements/archive/1.10.2.zip)
* Added: 'HTML Tag' control for title and subtitle to the Animated Box, Services, Team Member, Animation Box, Banner, Portfolio, Image Layouts
* Added: Divider deco element to Heading Widget
* Added: enable/disable on device option to parallax extension
* Added: default form check to contact form 7
* Added: empty api key message to advanced map
* Added: 'Open external link in new window' control for item external link to the 'Images Layout' widget
* Added: Slider widget / autoplay stop on hover option
* Added: Portfolio Widget / link button / text aligment style
* Updated: insta widget / remote request timeout value(from 5 to 20)
* Fixed: centering the map when there are many markers in the Advanced Map
* Fixed: parallax extension / none type check
* Fixed: Portfolio Widget / more button visible check
* Fixed: Portfolio Widget / justify layout / empty image size value check

## [1.10.1](https://github.com/ZemezLab/jet-elements/archive/1.10.1.zip)
* Added: multiple performance improvements and bug fixes

## [1.10.0](https://github.com/ZemezLab/jet-elements/archive/1.10.0.zip)
* Added: new Portfolio widget
* Added: multiple performance improvements and bug fixes
* Added: Equal Items Height control in the Testimonials Widget
* Added: border-radius control for Post Thumbnail in the Posts Widget
* Updated: 'Textarea Minimal Height' control in the Contact Form 7 Widget
* Updated: Corner Color control condition in the Team Member Widget
* Updated: Circle Progress Widget - outside content is not limited to width
* Updated: testimonials icon-inner selector for icon style controls in the Testimonials widget
* Fixed: applying css style for Action Box in the Pricing Table Widget

## [1.9.3](https://github.com/ZemezLab/jet-elements/archive/1.9.3.zip)
* Added: multiple performance improvements and bug fixes

## [1.9.2](https://github.com/ZemezLab/jet-elements/archive/1.9.2.zip)
* Fixed: Subscribe Widget(Enter key button event)

## [1.9.1](https://github.com/ZemezLab/jet-elements/archive/1.9.1.zip)
* Fixed: Image Layout widget

## [1.9.0](https://github.com/ZemezLab/jet-elements/archive/1.9.0.zip)
* Add: New categories and blocks into Elementor templates library
* Fixed: Better Ocean WP compatibility

## [1.8.2](https://github.com/ZemezLab/jet-elements/archive/1.8.2.zip)
* Add: Elementor 2.0 compatibility
* Fixed: Instagram widget

## [1.8.1](https://github.com/ZemezLab/jet-elements/archive/1.8.1.zip)
* Add: Elementor 2.0 compatibility
* Fixed: Instagram widget

## [1.8.0.3](https://github.com/ZemezLab/jet-elements/archive/1.8.0.3.zip)
* Add: js triggers

## [1.8.0.2](https://github.com/ZemezLab/jet-elements/archive/1.8.0.2.zip)
* Fixed: Instagram widget

## [1.8.0.1](https://github.com/ZemezLab/jet-elements/archive/1.8.0.1.zip)
* Fixed: Elementor 2.0.0 compatibility

## [1.8.0](https://github.com/ZemezLab/jet-elements/releases/tag/1.8.0)
* Added: Progress Bar widget
* Added: multiple performance improvements and bug fixes

## [1.7.1.2](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.1.2)
* Updated: change control type from text to url for links controls
* Fixed: prevent problems with icon control

## [1.7.1.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.1.1)
* Added: animation Prop type option for parallax items
* Fixed: cherry js core browser avaliable check

## [1.7.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.1)
* Added: possibility to disable widgets that can be used
* Added: adaptive height option to Testimonials widget
* Fixed: block section scroling bug(OceanWp theme compatibility bug)

## [1.7.0.2](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0.2)
* Fixed: instagram request bug
* Fixed: scroll Navi waypoint once trigger bug

## [1.7.0.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0.1)
* Updated .pot file

## [1.7.0](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0)
* Added consulting page template
* Added beauty salon page template
* Car repair page template
