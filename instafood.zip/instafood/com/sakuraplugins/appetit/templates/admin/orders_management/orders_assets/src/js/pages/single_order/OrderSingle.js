import RestManager from '../../services/RestManager';
import EventBus, { Events, Event } from '../../events/EventBus';
import DataUtils from '../../utils/DataUtils';

let instance;
const instanceKey = '23__ad809ad7238_KSJK';

class OrderSingle {

    _ui;
    _order;
    _ID;
    _mode;

    _onOrdersRequestEdit;

    _containers = ['items_ui', 'details_ui', 'actions_ui'];
    _orderData = {};

    _isLoading = false;
    _initialTab = 'items_ui';

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._onOrdersRequestEdit = new Event(Events.REQUEST_OPEN_SINGLE_ORDER, ({ ID, _mode }) => {
            this._ID = ID;
            this._mode = _mode;
            this.init_win();
        });
        EventBus.getInstance().registerEvent(this._onOrdersRequestEdit);
    }

    init_win() {
        this._initialTab = 'items_ui';
        const _this = this;
        this._buildBase();
        this._ui.find('.close_btn').click(function(event) {
            event.preventDefault();
            _this._closeWindow();
        })
        this._retrieveOrder();
        this._handleRemotePrintOrder();
    }

    _buildBase() {
        const order_single_items = DataUtils.getInstance().getLabel('order_single_items');
        const order_single_details = DataUtils.getInstance().getLabel('order_single_details');
        const order_single_actions = DataUtils.getInstance().getLabel('order_single_actions');

        const printnode_api_key = DataUtils.getInstance().getOption('printnode_api_key', '');
        const hasPrintAPIKey = printnode_api_key !== '';
        const printers = DataUtils.getInstance().getOption('available_printers', []);
        const hasPrinters = Array.isArray(printers) && printers.length > 0;

        let printersHtml = ``;
        if (hasPrintAPIKey && hasPrinters) {
            let printersListHtml = ``;

            for (let i = 0; i < printers.length; i++) {
                const printer = printers[i];
                printersListHtml += `<option value="${printer?.id}">${ printer?.name } (${ printer?.description })</option>`;
            }

            printersHtml = `
            <div style="margin-left: 3rem;">
                <span style="margin-right: 15px;">${DataUtils.getInstance().getLabel('remote_printers_label')}:</span>
                <select class="remote_printer_select" style="min-width: 6rem; max-width: 10rem; margin-right: 15px;">
                    <option value="">${DataUtils.getInstance().getLabel('select_remote_printer')}</option>
                    ${ printersListHtml }
                </select>
                <button disabled type="button" class="btn btn-secondary remote_print_btn">${DataUtils.getInstance().getLabel('print_remote')}</button>
            </div>
            `;
        }

        const template = `
        <div class="appetit_lightbox">
            <div class="lightbox_win">
                <div class="header_ui">
                    <div class="header_title_ui">
                        <div class="title">${ DataUtils.getInstance().getLabel('order_single_title') }: #${ this._ID }<span style="margin-left: 1em" class="title_order_status"></span></div>
                        <div class="close_btn"><span class="icon-clear"></span></div>
                    </div>
                    <div class="nav_ui">
                        <div class="nav_item selected" data-link="items_ui">${ order_single_items }</div>
                        <div class="nav_item" data-link="details_ui">${ order_single_details }</div>
                        <div class="nav_item" data-link="actions_ui">${ order_single_actions }</div>
                    </div>
                </div>
                <div class="content_ui">
                <div class="loading d_none"><div class="lds-ripple"><div></div><div></div></div></div>
                <div class="content_main_ui"></div>
                </div>
                <div class="footer_ui">
                    <div style="display: flex; align-items: center;">
                        <button type="button" class="btn btn-secondary download_order_items_btn">
                        ${ DataUtils.getInstance().getLabel('print_bill_btn') }
                        </button>
                        ${ printersHtml }
                    </div>
                    <button type="button" class="btn btn-light close_order_single_btn">
                    ${ DataUtils.getInstance().getLabel('close_order_single') }
                    </button>
                </div>
            </div>
        </div>
        `;
        this._ui = jQuery(template);
        this._ui.appendTo('body');
    }

    _render() {
        const _this = this;
        this._setTitleOrderType();
        this._handlePrintOrder();
        this._renderContent();
        this._ui.find('.nav_item').each(function(index) {
            jQuery(this).click(function(event) {
                event.preventDefault();
                _this._selectTab(jQuery(this).attr('data-link'));
            })
        })
        const { _payment_status } = this._orderData?._orderAll;
        if (_payment_status === 'PAYMENT_CANCELED') {
            _this._selectTab('actions_ui');
        } else {
            _this._selectTab(this._initialTab);
        }
    }

    _handleRemotePrintOrder() {
        const _this = this;
        let isPriniting = false;
        if (!this._ui.find('.remote_print_btn')[0]) {
            return;
        }

        let printerID = '';

        const selectPrinterOnChange = function(printerId) {
            printerID = printerId;
            const hasPrinterId = printerId !== '';
            if (hasPrinterId) {
                _this._ui.find('.remote_print_btn').removeAttr('disabled');
            } else {
                _this._ui.find('.remote_print_btn').attr('disabled', 'disabled');
            }
        }

        jQuery('.remote_printer_select').on('change', function(event) {
            selectPrinterOnChange(this.value);
        })

        this._ui.find('.remote_print_btn').click(function(event) {
            event.preventDefault();
            if (isPriniting) {
                return;
            }

            isPriniting = true;
            RestManager.getInstance()
            .postAjax('remote_print_order_single', {
                ID: _this._ID, printerId: printerID
            })
            .then(result => {
                isPriniting = false;
                const { status } = result;
                if (status !== 'OK') {
                    const { errors } = result;
                    console.log(errors);
                    return alert(errors[0]);
                }
                toastr.success(`${DataUtils.getInstance().getLabel('remote_printer_success')}`, '', {
                    iconClass: "appetit-toast-custom",
                });
            })
            .catch(err => {
                console.log('Print err', err);
                isPriniting = false;
            }) 
        })
    }

    _handlePrintOrder() {
        const _this = this;
        this._ui.find('.download_order_items_btn').click(function(event) {
            event.preventDefault();
            let invoicePageUrl = DataUtils.getInstance().getOption('invoicePageUrl');
            if (invoicePageUrl === undefined || invoicePageUrl === 'undefined' || invoicePageUrl === '') {
                return;
            }
            const { _public_id } = _this._orderData?._orderAll;
            const url = new URL(invoicePageUrl);
            const search_params = url.searchParams;
            search_params.set('opid', _public_id);
            url.search = search_params.toString();
            var new_url = url.toString();
            window.open(new_url, '_blank');
        })
        this._ui.find('.close_order_single_btn').click(function(event) {
            event.preventDefault();
            _this._closeWindow();
        });
    }

    _setTitleOrderType() {
        const order_statuses_mapped = DataUtils.getInstance().getOption('order_statuses_mapped', {});
        const { _orderType } = this._orderData?._orderAll;
        const orderTypeLabel = DataUtils.getInstance().getOrderTypeLabel(_orderType);
        const orderInfo = jQuery(`<div class="status_info ${ DataUtils.getInstance().getOrderTypeClass(_orderType) }">${ orderTypeLabel }</div>`)
        this._ui.find('.title_order_status').empty();
        orderInfo.appendTo(this._ui.find('.title_order_status'));
    }

    _renderContent() {
        this._renderItems();
        this._renderDetails();
        this._renderActions();
    }

    _renderItems() {
        const { line_items, total } = this._orderData?._lineItemsData;
        if (!Array.isArray(line_items)) {
            return;
        }
        const order_single_choices = DataUtils.getInstance().getLabel('order_single_choices');
        const order_single_total = DataUtils.getInstance().getLabel('order_single_total');

        let c = 0;
        let itemsHtml = '';
        line_items.map(lineItem => {
            let lineItemHtml = ``;
            
            switch (lineItem?.type) {
                case 'prduct':
                    const { hasVariants } = lineItem;
                    const variantName = lineItem?.variant?.name;
                    const productName = `${ lineItem?.quantity } x ${ lineItem?.name } ${ hasVariants ? `<span>(${variantName})</span>` : '' }`;
                    lineItemHtml = `
                    <div class="line_item_ui">
                        <div class="line_item_entry">
                            <div class="name_ui">
                                <div class="name_entry bold">${ productName }</div>
                                <div class="name_info">(${ lineItem?.description })</div>
                            </div>
                            <div class="price">${ this._priceDisplay(lineItem?.price) }</div>
                        </div>
                    </div>
                    `;
                    const { choices } = lineItem;
                    if (Array.isArray(choices) && choices.length > 0) {
                        lineItemHtml += `<div style="padding-left: 1em; font-weight: 500;">${ order_single_choices }:</div>`;
                        for (let i = 0; i < choices.length; i++) {
                            const choice = choices[i];
                            lineItemHtml += `
                            <div class="line_item_ui">
                                <div class="line_item_entry">
                                    <div class="name_ui">
                                        <div class="name_entry space">${ choice?.name }</div>
                                    </div>
                                    <div class="price">${ this._priceDisplay(choice?.price) }</div>
                                </div>
                            </div>
                            `;
                        }
                    }
                    const additional_notes = lineItem?.additional_notes;
                    if (additional_notes && additional_notes !== '') {
                        lineItemHtml += `<div style="padding-left: 1em; font-weight: 500;">${ DataUtils.getInstance().getLabel('order_single_customer_notes') }:</div>`;
                        lineItemHtml += `<div style="padding-left: 2em;">${ additional_notes }</div>`;
                    }
                break;
                case 'tipping':
                    lineItemHtml = `
                    <div class="line_item_ui">
                        <div class="line_item_entry">
                            <div class="name_ui">
                                <div class="name_entry bold">${ lineItem?.name }</div>
                            </div>
                            <div class="price">${ this._priceDisplay(lineItem?.price) }</div>
                        </div>
                    </div>
                    `;
                break;
                case 'delivery_cost':
                    lineItemHtml = `
                    <div class="line_item_ui">
                        <div class="line_item_entry">
                            <div class="name_ui">
                                <div class="name_entry bold">${ lineItem?.name }</div>
                            </div>
                            <div class="price">${ this._priceDisplay(lineItem?.price) }</div>
                        </div>
                    </div>
                    `;
                break;
            }
            
            c++;
            const back = c % 2 === 1 ? 'background: #f4f5fc' : '';

            let lineItemHolder = `<div class="line_item_ui_holder" style="${back}">${lineItemHtml}</div>`;

            itemsHtml += lineItemHolder;
        })

        let totalUI = `
        <div class="line_item_ui_holder no_border">
            <div class="line_item_ui">
                <div class="line_item_entry">
                    <div class="name_ui">
                        <div class="name_entry bold-strong">${ order_single_total }</div>
                    </div>
                    <div class="price">${ this._priceDisplay(total) }</div>
                </div>
            </div>
        </div>
        `;

        const t = `
        <div id="items_ui" class="content_section items_ui">
            ${ itemsHtml }${ totalUI }
            <div style="height: 20px;"></div>
        </div>
        `;
        if (this._ui.find('.items_ui')[0]) {
            this._ui.find('.items_ui').remove();
        }
        const items_ui = jQuery(t);
        items_ui.hide();
        items_ui.appendTo(this._ui.find('.content_main_ui'))
    }

    _renderDetails() {
        const { _orderType, _orderStatus, _payment_method, 
        _payment_status, _orderDate, _delivery_info, stripe_receipt_url } = this._orderData?._orderAll;

        const order_statuses_mapped = DataUtils.getInstance().getOption('order_statuses_mapped', {});
        const order_payment_methods_mapped = DataUtils.getInstance().getOption('order_payment_methods_mapped', {});
        const payment_statuses_mapped = DataUtils.getInstance().getOption('payment_statuses_mapped', {});

        let pickupSafeMatch = '';
        if (_orderType === 'PICKUP') {
            const { _safe_match_bkg, _safe_match_code } = this._orderData?._orderAll;
            pickupSafeMatch = `
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_safe_match_label'), '') }
            <div class="safe_match_wgt" style="background: ${_safe_match_bkg}; margin-top: 10px;"><span>${_safe_match_code}</span></div>
            `
        }

        let stripeReceiptHtml = ``;
        if (_payment_method === 'stripe' && stripe_receipt_url && stripe_receipt_url !== '') {
            stripeReceiptHtml = `<a href="${ stripe_receipt_url }" target="_blank">${ DataUtils.getInstance().getLabel('stripe_receipt') }</a>`;
        }

        let detailsHtml = `
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_type_single'), DataUtils.getInstance().getOrderTypeLabel(_orderType)) }
            ${ pickupSafeMatch }
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_status_single'), order_statuses_mapped[_orderStatus]) }
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_payment_method_single'), order_payment_methods_mapped[_payment_method]) }
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_payment_status_single'), payment_statuses_mapped[_payment_status]) }
            ${ stripeReceiptHtml }
            ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_date_single'), _orderDate) }
        `;
        switch (_orderType) {
            case 'DELIVERY':
                let { _delivery_info } = this._orderData?._orderAll;
                let { _customerAddress, _customerCity, _customerPhone, _customer_notes } = _delivery_info;

                detailsHtml += `
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_customerAddress_single'), `${_customerAddress}, ${_customerCity}`) }
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_customerPhone_single'), _customerPhone, true) }
                `
                if (_customer_notes && _customer_notes !== '') {
                    detailsHtml += `${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_customer_notes_single'), _customer_notes) }`;
                }
            break;
            case 'PICKUP':
                let deliveryInfo = this._orderData?._orderAll?._delivery_info;
                let { _customerFirstName, _pickupCustomerPhone, _pickup_day, _pickup_time } = deliveryInfo;
                
                detailsHtml += `
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_customer_first_name'), _customerFirstName) }
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_customerPhone_single'), _pickupCustomerPhone, true) }
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_pickup_day'), _pickup_day) }
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_pickup_time'), _pickup_time) }
                `
            break;
            case 'DINEIN':
                let deliveryInfoDineIn = this._orderData?._orderAll?._delivery_info;
                const { _table } = deliveryInfoDineIn;
                const tableDescription = lodash.get(deliveryInfoDineIn, '_table_details._tableDesc', '');
                const descriptionHtml = tableDescription !== '' ? ` <span>(${ tableDescription })</span>` : '';
                detailsHtml += `
                ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_table_label'), _table + descriptionHtml) }
                `
                const _validTable = lodash.get(deliveryInfoDineIn, '_table_details._validTable', false);
                if (!_validTable) {                    
                    detailsHtml += `
                    <div class="alert alert-danger" role="alert">
                        ${ DataUtils.getInstance().getLabel('order_cpayment_cancelled_by_user') }
                    </div>
                    `
                }
            break;
        }

        if (this._ui.find('.details_ui')[0]) {
            this._ui.find('.details_ui').remove();
        }

        const t = `
        <div class="content_section details_ui">
            ${ detailsHtml }
            <div style="height: 20px;"></div>
        </div>
        `;
        const details_ui = jQuery(t);
        details_ui.hide();
        details_ui.appendTo(this._ui.find('.content_main_ui'))
    }

    _orderDetailHelper(label, value, isPhone = false) {
        return `
            <div class="order_detail_entry">
                <div class="label">${ label }:</div>
                <div class="value">${ !isPhone ? value : `<a href="tel:${value}">${value}</a>` }</div>
            </div>
        `
    }

    _renderActions() {
        if (this._ui.find('.actions_ui')[0]) {
            this._ui.find('.actions_ui').remove();
        }

        
        const order_statuses = DataUtils.getInstance().getOption('order_statuses', {});
        const order_statuses_mapped = DataUtils.getInstance().getOption('order_statuses_mapped', {});
        
        
        const { _orderStatus, _payment_status } = this._orderData?._orderAll;
        // 'PAYMENT_CANCELED'

        let options = '';

        order_statuses.forEach(status => {
            options += `
            <option value="${status}" ${ _orderStatus === status ? 'selected' : ''}>${ order_statuses_mapped[status] }</option>
            `;
        });

        let statusActionsHtml = `
        ${ this._orderDetailHelper(DataUtils.getInstance().getLabel('order_change_status_label'), '') }
        <select class="select_change_status" style="min-width: 250px;">${ options }</select>
        `;

        const current_user_role = DataUtils.getInstance().getOption('current_user_role', '');
        
        let canceled_warning = '';
        const isPaymentCanceled = _payment_status === 'PAYMENT_CANCELED';
        if (isPaymentCanceled) {
            canceled_warning = `
            <div class="alert alert-danger" role="alert">
                ${ DataUtils.getInstance().getLabel('order_cpayment_cancelled_by_user') }
            </div>
            `;
        }

        if (isPaymentCanceled || current_user_role === 'administrator' || current_user_role === 'IF_RESTAURANT_ADMIN') {
            statusActionsHtml = `
            ${ canceled_warning }
            <button type="button" class="btn btn-danger btn_delete_order" style="margin-bottom: 20px;">${ DataUtils.getInstance().getLabel('order_delete_order') }</button>
            ${ statusActionsHtml }
            `;
        }

        const t = `
        <div class="content_section actions_ui">
            ${ statusActionsHtml }
            <div style="height: 20px;"></div>
        </div>
        `;
        const actions_ui = jQuery(t);
        actions_ui.hide();
        
        const _this = this;
        actions_ui.find('.select_change_status').on('change', function() {
            _this._changeStatus(this.value);
        })

        actions_ui.find('.btn_delete_order').click(function(event) {
            event.preventDefault();
            _this._changeStatus('DELETE', true);
        })

        actions_ui.appendTo(this._ui.find('.content_main_ui'))
    }

    _selectTab(tab) {
        this._initialTab = tab;
        this._ui.find('.nav_item').each(function(index) {
            jQuery(this).removeClass('selected');
            const tab_link = jQuery(this).attr('data-link');
            if (tab_link === tab) {
                jQuery(this).addClass('selected');
            }
        })
        this._ui.find('.content_section').hide();
        this._ui.find(`.${tab}`).show();
    }

    _priceDisplay(price) {
        const { currencySymbol, currencyPosition } = this._orderData?._lineItemsData;
        if (currencyPosition === 'BEFORE') {
            return `<span>${ currencySymbol }</span><span>${ price }</span>`;
        }
        return `<span>${ price }</span><span>${ currencySymbol }</span>`;
    }

    _retrieveOrder() {
        this._handlePreloader();
        RestManager.getInstance()
        .postAjax('fetch_order_single', {
            ID: this._ID
        })
        .then(result => {
            this._handlePreloader(false);
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            this._orderData = result?.data;
            this._render();
        });
    }

    _changeStatus(order_action, closeAfter = false) {
        if (this._isLoading) {
            return;
        }

        RestManager.getInstance().changeOrderStatus(this._ID, order_action, this._mode)
        .then(result => {
            if (closeAfter) {
                this._closeWindow();
                return;
            }
            this._retrieveOrder();
        });
    }

    _handlePreloader(show = true) {
        this._isLoading = show;
        if (show) {
            return this._ui.find('.loading').removeClass('d_none');
        }
        this._ui.find('.loading').addClass('d_none');
    }

    _closeWindow() {
        this._ui.remove();
    }
    
    static getInstance() {
        if (!instance) {
            instance = new OrderSingle(instanceKey);
        }
        return instance;
    }
}
export default OrderSingle;