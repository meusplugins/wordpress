import DataUtils from './DataUtils';
import StorageUtil from './StorageUtil';
let instance;
const instanceKey = 'eent_bus9KS9';

export class Languages {
    static PRIMARY = 'primary_lang_';
    static SECONDARY = 'secondary_lang_';
}

class LanguageUtils {

    getLang() {
        const options = DataUtils.getInstance().getFromData(DataUtils.OPTIONS);
        if (_.get(options, 'secondary_lang_enabled', '') !== 'ON') {
            return Languages.PRIMARY;
        }
        return StorageUtil.getLanguage();
    }

    getLabel(key) {
        const locales = DataUtils.getInstance().getFromData(DataUtils.LOCALES);
        return _.get(locales, `${key}.${this.getLang()}`, '');
    }

    decodeHtml(val) {
        return jQuery("<div />").html(val).text();
    }
    
    static getInstance() {
        if (!instance) {
            instance = new LanguageUtils(instanceKey);
        }
        return instance;
    }
}
export default LanguageUtils;