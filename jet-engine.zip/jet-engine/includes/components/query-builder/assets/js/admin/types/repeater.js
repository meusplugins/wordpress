(function( $ ) {

	'use strict';

	Vue.component( 'jet-repeater-query', {
		template: '#jet-repeater-query',
		mixins: [
			window.JetQueryWatcherMixin,
			window.JetQueryRepeaterMixin,
			window.JetQueryMetaParamsMixin,
		],
		props: [ 'value', 'dynamic-value' ],
		data: function() {
			return {
				sourcesList: window.jet_query_component_repeater.sources,
				metaFields: window.jet_query_component_repeater.meta_fields,
				metaFieldsTree: window.jet_query_component_repeater.meta_fields_tree || {},
				optionsFields: window.jet_query_component_repeater.options_fields,
				optionsFieldsTree: window.jet_query_component_repeater.options_fields_tree || {},
				customContentTypeFieldsTree: window.jet_query_component_repeater.custom_content_type_fields_tree || {},
				taxonomies: window.JetEngineQueryConfig.taxonomies,
				operators: window.JetEngineQueryConfig.operators_list,
				dataTypes: window.JetEngineQueryConfig.data_types,
				query: {},
				dynamicQuery: {},
			};
		},
		computed: {
			metaClauses: function() {

				let result = [];

				for ( var i = 0; i < this.query.meta_query.length; i++ ) {
					if ( this.query.meta_query[ i ].clause_name ) {
						result.push( {
							value: this.query.meta_query[ i ].clause_name,
							label: this.query.meta_query[ i ].clause_name,
						} )
					}
				}

				return result;
			},
			selectedFieldKey: function() {

				switch ( this.query.source ) {
					case 'jet_engine':
						return this.query.jet_engine_field || '';

					case 'jet_engine_option':
						return this.query.jet_engine_option_field || '';

					case 'custom_content_type_field':
						return this.query.custom_content_type_field || '';

					default:
						return '';
				}
			},
			selectedFieldTree: function() {

				if ( ! this.selectedFieldKey ) {
					return null;
				}

				if ( 'jet_engine' === this.query.source ) {
					return this.metaFieldsTree[ this.selectedFieldKey ] || null;
				}

				if ( 'jet_engine_option' === this.query.source ) {
					return this.optionsFieldsTree[ this.selectedFieldKey ] || null;
				}

				if ( 'custom_content_type_field' === this.query.source ) {
					return this.customContentTypeFieldsTree[ this.selectedFieldKey ] || null;
				}

				return null;
			},
			nestedPathOptions: function() {

				let options = [
					{
						value: '',
						label: 'Top level rows',
					}
				];

				if ( this.selectedFieldTree && Array.isArray( this.selectedFieldTree.paths ) ) {
					options = options.concat( this.selectedFieldTree.paths );
				}

				return options;
			},
			resolvedFieldOptions: function() {

				if ( ! this.selectedFieldTree || ! this.selectedFieldTree.fields ) {
					return [];
				}

				return this.selectedFieldTree.fields[ this.query.nested_path || '' ] || [];
			},
			hasGeneratedNestedPaths: function() {
				return 1 < this.nestedPathOptions.length;
			},
			hasResolvedFieldOptions: function() {
				return 0 < this.resolvedFieldOptions.length;
			},
			resolvedLevelLabel: function() {
				return this.query.nested_path ? 'selected nested repeater level' : 'selected repeater level';
			},
		},
		watch: {
			selectedFieldKey: function() {
				this.ensureNestedPathState();
			},
			'query.source': function() {
				this.ensureNestedPathState();
			},
		},
		created: function() {

			this.query = { ...this.value };
			this.dynamicQuery = { ...this.dynamicValue };

			if ( ! this.query.orderby ) {
				this.$set( this.query, 'orderby', [] );
			}

			if ( undefined === this.query.nested_path ) {
				this.$set( this.query, 'nested_path', '' );
			}

			this.presetMeta();

			let allFields = [];
			
			allFields = window.jet_query_component_repeater.meta_fields
				.reduce( ( acc, cur ) => acc.concat( cur.options.map( op => op.value ) ), allFields );

			let currentEngineField = this?.query?.jet_engine_field;

			if ( currentEngineField?.length && ! allFields.includes( currentEngineField ) ) {
				let userFields = [];
			
				userFields = window.jet_query_component_repeater.meta_fields
					.filter( o => o?.for === 'user' )
					.reduce( ( acc, cur ) => acc.concat( cur.options.map( op => op.value ) ), userFields );

				for ( const name of userFields ) {
					if ( name.includes( currentEngineField ) ) {
						this.$set( this.query, 'jet_engine_field', name );
						break;
					}
				}
			}

			// if ( undefined === this.query.hide_empty ) {
			// 	this.$set( this.query, 'hide_empty', true );
			// }

			this.ensureNestedPathState();

		},
		methods: {
			ensureNestedPathState: function() {

				if ( 'custom' === this.query.source ) {
					return;
				}

				if ( ! this.hasGeneratedNestedPaths ) {
					this.$set( this.query, 'nested_path', '' );
					return;
				}

				let allowedPaths = this.nestedPathOptions.map( ( option ) => option.value );

				if ( ! allowedPaths.includes( this.query.nested_path || '' ) ) {
					this.$set( this.query, 'nested_path', '' );
				}
			},
		},
	} );

})( jQuery );
