<?php
namespace com\sakuraplugins\appetit\mainmobile;
if ( ! defined('ABSPATH' ) ) exit;

use com\sakuraplugins\appetit\utils\OptionUtil;

require_once(plugin_dir_path(__FILE__) . '../IAppetitPage.php');

class Homepage implements IAppetitPage {

    public function render(): void {
        ?>
        <section id="apt_home_screen" class="apt-page apt-page-full">
            <?php $this->renderHeader(); ?>
            <?php $this->renderMainNav(); ?>
            <?php $this->renderMenuItems(); ?>
        </section>
        <?php
    }

    private function renderHeader(): void {
        $restaurant_cover_image_id = OptionUtil::getInstance()->getOption('restaurant_cover_image_id');
        $restaurant_cover_image_url = '';
        if ($restaurant_cover_image_id) {
            $restaurant_cover_image_data = wp_get_attachment_image_src($restaurant_cover_image_id, 'appetit-cover-medium');
            if (is_array($restaurant_cover_image_data) && isset($restaurant_cover_image_data[0])) {
                $restaurant_cover_image_url = $restaurant_cover_image_data[0];
            }
        }
        ?>
        <div class="apt-cover-header" style="background: url('<?= $restaurant_cover_image_url; ?>'); background-size: cover; background-position: center;">
            <div class="apt-cover-header-overlay">

                <div class="apt-header-info">
                    <div class="apt-header-title mb_10"></div>
                </div>
            </div>
        </div>
        <?php
    }

    private function renderMainNav(): void {
        ?>
        <div class="apt-categories-nav-holder"></div>
        <?php
    }

    private function renderMenuItems(): void {
        ?>
        <div class="apt_screen_content_ui"></div>
        <?php
    }
}

?>