import LanguageUtils, { Languages } from './LanguageUtils';
import DataUtils from './DataUtils';

class ProductUtils {
    static getProductName(product) {
        const currentLanguage  = LanguageUtils.getInstance().getLang();
        if (currentLanguage === Languages.PRIMARY) {
            return _.get(product, 'meta.item_name_1', '');
        } else {
            return _.get(product, 'meta.item_name_2', '');
        }
    }

    static getProductDescription(product) {
        const currentLanguage  = LanguageUtils.getInstance().getLang();
        if (currentLanguage === Languages.PRIMARY) {
            return _.get(product, 'meta.item_description_1', '');
        } else {
            return _.get(product, 'meta.item_description_2', '');
        }
    }

    static getVariationName(variation) {
        const currentLanguage  = LanguageUtils.getInstance().getLang();
        if (currentLanguage === Languages.PRIMARY) {
            return _.get(variation, 'variation_name_1', '');
        } else {
            return _.get(variation, 'variation_name_2', '');
        }
    }

    static getChoiceName(choice) {
        const currentLanguage  = LanguageUtils.getInstance().getLang();
        return _.get(choice, `${currentLanguage}choice_name`, '');
    }

    static getGroupName(group) {
        const currentLanguage  = LanguageUtils.getInstance().getLang();
        return _.get(group, `post_meta.${currentLanguage}group_name`, '');
    }

    static productHasVariants(product) {
        const product_variants = _.get(product, 'meta.product_variations', []);
        return product_variants.length > 1 ? true : false;
    }

    static getProductSingleVariant(product) {
        const product_variants = _.get(product, 'meta.product_variations', []);
        return _.get(product_variants, '[0]', false);
    }

    static productHasChoiceGroups(product) {
        const choice_groups = _.get(product, 'meta.choice_groups', []);
        return choice_groups.length > 0 ? true : false;
    }

    static getProductGroups(product) {
        const choice_groups = _.get(product, 'meta.choice_groups', []);
        const allAggregatedGroups = DataUtils.getInstance().getAggregatedGroups();
        const product_groups = [];

        for (let k = 0; k < choice_groups.length; k++) {
            const group_id = choice_groups[k];
            for (let i = 0; i < allAggregatedGroups.length; i++) {
                if (parseInt(allAggregatedGroups[i].ID, 10) === parseInt(group_id, 10)) {
                    product_groups.push(allAggregatedGroups[i]);
                }
            }
        }
        return product_groups;
    }
}
export default ProductUtils;