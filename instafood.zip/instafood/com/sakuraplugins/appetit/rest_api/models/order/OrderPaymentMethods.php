<?php
namespace com\sakuraplugins\appetit\rest_api\models;
if (!defined('ABSPATH')) exit;

abstract class OrderPaymentMethods {
    const STRIPE = 'stripe';
    const CASH_ON_DELIVERY = 'cash_on_delivery';

    static function getAll() {
        return [self::STRIPE, self::CASH_ON_DELIVERY];
    }

    static function getMappedToLabels() {
        return [
            self::STRIPE => esc_html__('Stripe', 'instafood'),
            self::CASH_ON_DELIVERY => esc_html__('Cash on delivery', 'instafood'),
        ];
    }
}
?>