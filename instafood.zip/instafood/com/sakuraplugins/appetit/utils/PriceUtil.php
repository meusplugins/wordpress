<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . 'OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . 'Currency.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\utils\Currency;

class PriceUtil {

    private static $instance = null;
    
    private $restaurant_currency_code;
    private $currency_position;
    private $allCurrencies;
    private $currentCurrency = [];
    
    private function __construct() {
        $this->restaurant_currency_code = OptionUtil::getInstance()->getOption('restaurant_currency_code', '');
        $this->currency_position = OptionUtil::getInstance()->getOption('currency_position', 'BEFORE');
        $this->allCurrencies = Currency::getCurrencies();
        foreach ($this->allCurrencies as $currency) {
            if ($this->restaurant_currency_code === $currency['code']) {
                $this->currentCurrency = $currency;
                break;
            }
        }
    }

    public function getPriceDisplay($price): string {
        $price_display = '';
        if (isset($price) && is_numeric($price)) {
            $price_display = $this->getDisplayWithCurrency($this->numberTwoDecimals($price));
        } else {
            $price_display = $this->getDisplayWithCurrency($this->numberTwoDecimals(0));
        }
        return $price_display;
    }

    public function numberTwoDecimals($no) {
        $formattedPrice = apply_filters('instafood_price_format_filter', $no);
        if ($formattedPrice && $formattedPrice !== $no) {
            return $formattedPrice;
        }

        $frontend_enabled_decimal_dot = OptionUtil::getInstance()->getOption("frontend_enabled_decimal_dot", '');
        $separator = $frontend_enabled_decimal_dot === 'ON' ? '.' : ',';
        if (isset($no) && is_numeric($no)) {
            return number_format($no, 2, $separator , ".");
        }
        return number_format(0, 2, $separator , ".");
    }

    public function getDisplayWithCurrency($formattedNo): string {
        $currencySymbol = isset($this->currentCurrency['symbol']) ? $this->currentCurrency['symbol'] : '$';
        if ($this->currency_position === 'BEFORE') {
            return "<span class='currency_symbol'>$currencySymbol</span><span class='currency_val'>$formattedNo</span>";
        } else {
            return "<span class='currency_val'>$formattedNo</span><span class='currency_symbol'>$currencySymbol</span>";
        }
    }

    function getCurrencySymbol() {
        return isset($this->currentCurrency['symbol']) ? $this->currentCurrency['symbol'] : '$';
    }

    function getCurrencyPosition() {
        return $this->currency_position;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new PriceUtil();
        }
        return self::$instance;
    }
}
?>