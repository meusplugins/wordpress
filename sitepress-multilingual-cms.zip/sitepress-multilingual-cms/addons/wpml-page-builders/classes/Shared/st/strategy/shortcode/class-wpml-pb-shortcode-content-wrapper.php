<?php

use WPML\FP\Logic;
use WPML\FP\Maybe;
use WPML\FP\Str;
use WPML\LIB\WP\Gutenberg;
use function WPML\FP\pipe;


class WPML_PB_Shortcode_Content_Wrapper {

	const WRAPPER_SHORTCODE_NAME = 'wpml_string_wrapper';

	private $content;

	private $valid_shortcodes;

	private $shortcodes = array();

	private $content_array;

	private $insert_wrapper = array();

	public function __construct( $content, array $valid_shortcodes ) {
		$this->content          = $content;
		$this->valid_shortcodes = $valid_shortcodes;
	}

	public function get_wrapped_content() {
		$this->split_content();
		$this->parse_shortcodes();
		$this->drop_in_tag_shortcodes();
		$this->analyze_unwrapped_text();
		$this->insert_wrappers();
		return $this->content;
	}

	private function split_content() {
		$length = mb_strlen( $this->content );

		for ( $i = 0; $i < $length; $i++ ) {
			$this->content_array[] = mb_substr( $this->content, $i, 1 );
		}
	}

	private function parse_shortcodes() {
		$close_bracket_position = false;
		$content_length         = count( $this->content_array );

		for ( $i = 0; $i < $content_length; $i++ ) {
			if ( false !== $close_bracket_position && $close_bracket_position >= $i ) {
				continue;
			}

			if ( '[' === $this->content_array[ $i ] ) {
				$close_bracket_position = $this->parse_shortcode( $i );
			}
		}
	}

	private function parse_shortcode( $open_bracket_position ) {
		$shortcode_name         = $this->get_shortcode_name( $open_bracket_position );
		$close_bracket_position = $this->get_shortcode_end( $open_bracket_position, $shortcode_name );
		$is_closing             = isset( $this->content_array[ $open_bracket_position + 1 ] )
			&& '/' === $this->content_array[ $open_bracket_position + 1 ];

		if ( ! in_array( $shortcode_name, $this->valid_shortcodes, true ) ) {
			return $close_bracket_position;
		}

		if ( $is_closing ) {
			$shortcode_index = $this->find_last_opened_shortcode( $shortcode_name );

			if ( null !== $shortcode_index ) {
				$this->shortcodes[ $shortcode_index ]['end'] = $close_bracket_position;
				$this->remove_nested_shortcodes_between(
					$this->shortcodes[ $shortcode_index ]['start'],
					$close_bracket_position
				);
			}
		} else {
			$this->shortcodes[] = array(
				'name'  => $shortcode_name,
				'start' => $open_bracket_position,
				'end'   => $close_bracket_position,
			);
		}

		return $close_bracket_position;
	}

	private function remove_nested_shortcodes_between( $start, $end ) {
		foreach ( $this->shortcodes as $key => $shortcode ) {

			if ( $start < $shortcode['start'] && $end > $shortcode['end'] ) {
				unset( $this->shortcodes[ $key ] );
			}
		}
	}

	private function drop_in_tag_shortcodes() {
		$in_tag_starts = $this->get_in_tag_shortcode_starts();

		$this->shortcodes = array_values(
			array_filter(
				$this->shortcodes,
				function ( $shortcode ) use ( $in_tag_starts ) {
					return ! isset( $in_tag_starts[ $shortcode['start'] ] );
				}
			)
		);
	}

	private function get_in_tag_shortcode_starts() {
		$shortcodes     = array_values( $this->shortcodes );
		$shortcodes_cnt = count( $shortcodes );
		$content_length = count( (array) $this->content_array );
		$in_tag_starts  = array();
		$is_in_tag      = false;
		$index          = 0;

		for ( $i = 0; $i < $content_length; $i++ ) {
			while ( $index < $shortcodes_cnt && $shortcodes[ $index ]['start'] < $i ) {
				$index++;
			}

			if ( $index < $shortcodes_cnt && $shortcodes[ $index ]['start'] === $i ) {
				if ( $is_in_tag ) {
					$in_tag_starts[ $i ] = true;
				}
				$i = $shortcodes[ $index ]['end'];
				continue;
			}

			$char = $this->content_array[ $i ];

			if ( ! $is_in_tag && '<' === $char && isset( $this->content_array[ $i + 1 ] ) && preg_match( '/^[A-Za-z\/]$/', $this->content_array[ $i + 1 ] ) ) {
				$is_in_tag = true;
			} elseif ( $is_in_tag && '>' === $char ) {
				$is_in_tag = false;
			}
		}

		return $in_tag_starts;
	}

	private function analyze_unwrapped_text() {
		$next_unwrapped_text_start = 0;

		foreach ( $this->shortcodes as $shortcode ) {
			$unwrapped_text_start      = $next_unwrapped_text_start;
			$unwrapped_text_end        = $shortcode['start'] - 1;
			$next_unwrapped_text_start = $shortcode['end'] + 1;

			if ( $unwrapped_text_start < $unwrapped_text_end ) {
				$this->set_wrapper_positions( $unwrapped_text_start, $unwrapped_text_end );
			}
		}

		$max_content_char_position = mb_strlen( $this->content ) - 1;

		if ( $next_unwrapped_text_start < $max_content_char_position ) {
			$this->set_wrapper_positions( $next_unwrapped_text_start, $max_content_char_position );
		}
	}

	private function set_wrapper_positions( $start, $end ) {
		$raw_chunk = mb_substr( $this->content, $start, $end - $start );

		if ( '' === trim( $raw_chunk ) ) {
			return;
		}

		$chunk_start        = $this->get_wrapper_insert_position( $start, 'open' );
		$unwrapped_text_end = $this->get_wrapper_insert_position( $end, 'close' );

		$this->insert_wrapper[ $chunk_start ]        = '[' . self::WRAPPER_SHORTCODE_NAME . ']';
		$this->insert_wrapper[ $unwrapped_text_end ] = '[/' . self::WRAPPER_SHORTCODE_NAME . ']';
	}

	private function get_wrapper_insert_position( $position, $type ) {
		if ( 'close' === $type ) {
			$increment = - 1;
		} else {
			$increment = 1;
		}

		while ( isset( $this->content_array[ $position ] )
				&& in_array( $this->content_array[ $position ], array( "\n", "\r" ), true )
		) {
			$position = $position + $increment;
		}

		if ( 'close' === $type ) {
			$position++;
		}

		return $position;
	}

	private function get_shortcode_name( $open_bracket_position ) {
		$char_position = $open_bracket_position + 1;
		$name          = '';

		while ( isset( $this->content_array[ $char_position ] )
				&& ( '' === $name || ! in_array( $this->content_array[ $char_position ], array( ' ', ']' ), true ) )
		) {
			if ( '/' !== $this->content_array[ $char_position ] ) {
				$name .= $this->content_array[ $char_position ];
			}

			$char_position++;
		}

		return $name;
	}

	private function get_shortcode_end( $open_bracket_position, $shortcode_name ) {
		$char_position = $open_bracket_position + mb_strlen( $shortcode_name );

		$is_in_single_quotes = false;
		$is_in_double_quotes = false;

		while ( isset( $this->content_array[ $char_position ] )
				&& ( ']' !== $this->content_array[ $char_position ] || $is_in_single_quotes || $is_in_double_quotes )
		) {
			if ( ! $is_in_single_quotes && '"' === $this->content_array[ $char_position ] ) {
				$is_in_double_quotes = ! $is_in_double_quotes;
			} elseif ( ! $is_in_double_quotes && "'" === $this->content_array[ $char_position ] ) {
				$is_in_single_quotes = ! $is_in_single_quotes;
			}

			$char_position ++;
		}

		return $char_position;
	}

	private function find_last_opened_shortcode( $shortcode_name ) {
		$last_matching_index = null;

		foreach ( $this->shortcodes as $shortcode_index => $shortcode ) {
			if ( $shortcode['name'] === $shortcode_name ) {
				$last_matching_index = (int) $shortcode_index;
			}
		}

		return $last_matching_index;
	}

	private function insert_wrappers() {
		$offset = 0;

		foreach ( $this->insert_wrapper as $wrapper_position => $wrapper ) {
			$insert_position = $wrapper_position + $offset;
			$before          = mb_substr( $this->content, 0, $insert_position );
			$after           = mb_substr( $this->content, $insert_position );
			$this->content   = $before . $wrapper . $after;
			$offset          = $offset + mb_strlen( $wrapper );
		}
	}

	public static function maybeWrap( $content, array $shortcodes ) {
		$containsOneShortcode = pipe( Str::match( '/' . get_shortcode_regex( $shortcodes ) . '/s' ), Logic::isEmpty(), Logic::not() );

		return Maybe::of( $content )
			->filter( Gutenberg::doesNotHaveBlock() )
			->filter( $containsOneShortcode )
			->filter( [ self::class, 'isStrippedContentDifferent' ] )
			->map( [ self::class, 'wrap' ] )
			->getOrElse( $content );
	}

	public static function hasOnlyInTagShortcodes( $content, array $shortcodes ) {
		if ( '' === (string) $content ) {
			return false;
		}

		$wrapper = new self( $content, $shortcodes );
		$wrapper->split_content();
		$wrapper->parse_shortcodes();

		return $wrapper->shortcodes
			&& count( $wrapper->shortcodes ) === count( $wrapper->get_in_tag_shortcode_starts() );
	}

	public static function isStrippedContentDifferent( $content ) {
		$content_with_stripped_shortcode = preg_replace( '/\[([\S]*)[^\]]*\][\s\S]*?\[\/(\1)\]|\[[^\]]*\]/', '', $content );
		$content_with_stripped_shortcode = trim( $content_with_stripped_shortcode );
		return ! empty( $content_with_stripped_shortcode ) && trim( $content ) !== $content_with_stripped_shortcode;
	}

	public static function wrap( $content ) {
		return '[' . self::WRAPPER_SHORTCODE_NAME . ']' . $content . '[/' . self::WRAPPER_SHORTCODE_NAME . ']';
	}

	public static function unwrap( $content ) {
		return str_replace(
			[
				'[' . self::WRAPPER_SHORTCODE_NAME . ']',
				'[/' . self::WRAPPER_SHORTCODE_NAME . ']',
			],
			'',
			$content
		);
	}
}
