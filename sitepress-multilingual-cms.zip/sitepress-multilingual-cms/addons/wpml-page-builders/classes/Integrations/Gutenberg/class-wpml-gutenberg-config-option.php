<?php

use WPML\FP\Obj;
use WPML\PB\ConvertIds\Helper as ConvertIdsHelper;
use WPML\PB\Gutenberg\XPath;

class WPML_Gutenberg_Config_Option {

	const OPTION                 = 'wpml-gutenberg-config';
	const OPTION_IDS_IN_BLOCKS   = 'wpml-gutenberg-config-ids-in-blocks';
	const OPTION_MEDIA_IN_BLOCKS = 'wpml-gutenberg-config-media-in-blocks';

	const SEARCH_METHOD_WILDCARD = 'wildcards';
	const SEARCH_METHOD_REGEX    = 'regex';

	private $logger;

	private $loggedRefusals = [];

	public function __construct( ?callable $logger = null ) {
		$this->logger = $logger ?: [ $this, 'writeErrorLog' ];
	}

	public function update_from_config( $config_data ) {
		$blocks          = [];
		$ids_in_blocks   = [];
		$media_in_blocks = [];

		if ( isset( $config_data['wpml-config']['gutenberg-blocks']['gutenberg-block'] ) ) {
			foreach ( $config_data['wpml-config']['gutenberg-blocks']['gutenberg-block'] as $block_config ) {
				if ( '1' === $block_config['attr']['translate'] ) {
					$blocks = $this->add_block_xpaths( $blocks, $block_config );
					$blocks = $this->add_block_attribute_keys( $blocks, $block_config );
					$blocks = $this->add_block_label( $blocks, $block_config );
				} else {
					$blocks[ self::get_block_name( $block_config ) ] = [];
				}

				$ids_in_blocks   = $this->add_ids_in_block_xpath( $ids_in_blocks, $block_config );
				$ids_in_blocks   = $this->add_ids_in_block_keys( $ids_in_blocks, $block_config );
				$media_in_blocks = $this->add_media_in_block_keys( $media_in_blocks, $block_config );
			}
		}

		update_option( self::OPTION, $blocks, 'no' );
		update_option( self::OPTION_IDS_IN_BLOCKS, $ids_in_blocks, 'yes' );
		update_option( self::OPTION_MEDIA_IN_BLOCKS, $media_in_blocks, 'yes' );
	}

	public static function get_block_name( array $block_config ) {
		return Obj::path( [ 'attr', 'type' ], $block_config );
	}

	private function add_block_xpaths( array $blocks, array $block_config ) {
		if ( isset( $block_config['xpath'] ) ) {
			$block_name    = self::get_block_name( $block_config );
			$xpaths_config = [];

			foreach ( $this->normalize_key_data( $block_config['xpath'] ) as $xpaths ) {
				if ( self::is_string_type( Obj::path( [ 'attr', 'type' ], $xpaths ) ) ) {
					$xpaths        = XPath::normalize( $xpaths );
					$xpaths_config = array_merge( $xpaths_config, array_values( $xpaths ) );
				}
			}

			if ( $xpaths_config ) {
				$earlier                        = isset( $blocks[ $block_name ]['xpath'] ) ? $blocks[ $block_name ]['xpath'] : [];
				$blocks[ $block_name ]['xpath'] = array_values( array_unique( array_merge( $earlier, $xpaths_config ), SORT_REGULAR ) );
			}
		}

		return $blocks;
	}

	private function add_ids_in_block_xpath( array $ids_in_blocks, array $block_config ) {
		$xpaths = $this->normalize_key_data( (array) Obj::prop( 'xpath', $block_config ) );

		foreach ( $xpaths as $xpath ) {
			$type = Obj::path( [ 'attr', 'type' ], $xpath );

			if ( ConvertIdsHelper::isValidType( $type ) ) {
				$block_name = self::get_block_name( $block_config );

				$value         = Obj::path( [ 'value' ], $xpath );
				$selected_type = ConvertIdsHelper::selectElementType( Obj::path( [ 'attr', 'sub-type' ], $xpath ), $type );

				$ids_in_blocks[ $block_name ]          = isset( $ids_in_blocks[ $block_name ] ) ? $ids_in_blocks[ $block_name ] : [];
				$ids_in_blocks[ $block_name ]['xpath'] = isset( $ids_in_blocks[ $block_name ]['xpath'] ) ? $ids_in_blocks[ $block_name ]['xpath'] : [];
				$ids_in_blocks[ $block_name ]['xpath'] = array_merge( $ids_in_blocks[ $block_name ]['xpath'], [ $value => $selected_type ] );
			}
		}

		return $ids_in_blocks;
	}

	private function add_block_attribute_keys( array $blocks, array $block_config ) {
		if ( isset( $block_config['key'] ) ) {
			$keys = $this->get_keys_recursively( $block_config['key'], (string) self::get_block_name( $block_config ) );
			$keys = $this->cleanup_to_include_key( $keys );

			if ( $keys ) {
				$block_name                   = self::get_block_name( $block_config );
				$earlier                      = isset( $blocks[ $block_name ]['key'] ) ? $blocks[ $block_name ]['key'] : [];
				$blocks[ $block_name ]['key'] = array_replace_recursive( $earlier, $keys );
			}
		}

		return $blocks;
	}

	private function add_ids_in_block_keys( array $ids_in_blocks, array $block_config ) {
		$keys_config = $this->find_convert_ids_key_recursively( $block_config );

		if ( $keys_config ) {
			$block_name = self::get_block_name( $block_config );

			$ids_in_blocks[ $block_name ]        = isset( $ids_in_blocks[ $block_name ] ) ? $ids_in_blocks[ $block_name ] : [];
			$ids_in_blocks[ $block_name ]['key'] = isset( $ids_in_blocks[ $block_name ]['key'] ) ? $ids_in_blocks[ $block_name ]['key'] : [];
			$ids_in_blocks[ $block_name ]['key'] = array_merge( $ids_in_blocks[ $block_name ]['key'], $keys_config );
		}

		return $ids_in_blocks;
	}

	private function find_convert_ids_key_recursively( array $config, array $path = [] ) {
		$current_keys = $this->normalize_key_data( (array) Obj::prop( 'key', $config ) );
		$keys_config  = [];

		if ( $current_keys ) {
			foreach ( $current_keys as $current_key ) {
				$current_name = Obj::path( [ 'attr', 'name' ], $current_key );
				$current_path = array_merge( $path, [ $current_name ] );
				$keys_config  = array_merge( $keys_config, $this->find_convert_ids_key_recursively( $current_key, $current_path ) );
			}
		} else {
			$type = Obj::path( [ 'attr', 'type' ], $config );

			if ( ConvertIdsHelper::isValidType( $type ) ) {
				$path_to_key   = implode( '>', $path );
				$selected_type = ConvertIdsHelper::selectElementType( Obj::path( [ 'attr', 'sub-type' ], $config ), $type );

				$keys_config[ $path_to_key ] = $selected_type;
			}
		}

		return $keys_config;
	}

	private function add_media_in_block_keys( array $media_in_blocks, array $block_config ) {
		$keys_config = $this->find_media_url_key_recursively( $block_config );

		if ( $keys_config ) {
			$block_name = self::get_block_name( $block_config );

			$media_in_blocks[ $block_name ]        = isset( $media_in_blocks[ $block_name ] ) ? $media_in_blocks[ $block_name ] : [];
			$media_in_blocks[ $block_name ]['key'] = isset( $media_in_blocks[ $block_name ]['key'] ) ? $media_in_blocks[ $block_name ]['key'] : [];
			$media_in_blocks[ $block_name ]['key'] = array_merge( $media_in_blocks[ $block_name ]['key'], $keys_config );
		}

		return $media_in_blocks;
	}

	private function find_media_url_key_recursively( array $config, array $path = [] ) {
		$current_keys = $this->normalize_key_data( (array) Obj::prop( 'key', $config ) );
		$keys_config  = [];

		if ( $current_keys ) {
			foreach ( $current_keys as $current_key ) {
				$current_name = Obj::path( [ 'attr', 'name' ], $current_key );
				$current_path = array_merge( $path, [ $current_name ] );
				$keys_config  = array_merge( $keys_config, $this->find_media_url_key_recursively( $current_key, $current_path ) );
			}
		} else {
			$type = Obj::path( [ 'attr', 'type' ], $config );

			if ( WPML_Page_Builders_Media_Gutenberg::TYPE_URL === $type || WPML_Page_Builders_Media_Gutenberg::TYPE_IDS === $type ) {
				$path_to_key                 = implode( '>', $path );
				$keys_config[ $path_to_key ] = $type;
			}
		}

		return $keys_config;
	}

	private function add_block_label( array $blocks, array $block_config ) {
		if ( isset( $block_config['attr']['label'] ) ) {
			$blocks[ self::get_block_name( $block_config ) ]['label'] = $block_config['attr']['label'];
		}

		return $blocks;
	}

	private function get_keys_recursively( array $keys_config, $block_name = '', array $path = [] ) {
		$final_config = array();
		$keys_config  = $this->normalize_key_data( $keys_config );

		foreach ( $keys_config as $key_config ) {

			if ( $this->is_refused_text_key( $key_config ) ) {
				$this->log_refused_text_key( $block_name, array_merge( $path, [ (string) $key_config['attr']['name'] ] ) );
				continue;
			}

			$partial_config = [];
			$type           = Obj::pathOr( '', [ 'attr', 'type' ], $key_config );

			if ( self::is_string_type( $type ) ) {
				$partial_config['to_include'] = true;

				if ( $type ) {
					$partial_config['type'] = $type;
				}
			}

			if ( isset( $key_config['attr']['search-method'] ) ) {
				$partial_config['search-method'] = $key_config['attr']['search-method'];
			}

			if ( isset( $key_config['attr']['label'] ) ) {
				$partial_config['label'] = $key_config['attr']['label'];
			}

			if ( isset( $key_config['attr']['encoding'] ) ) {
				$partial_config['encoding'] = $key_config['attr']['encoding'];
			}

			if ( isset( $key_config['key'] ) ) {
				$children       = $this->get_keys_recursively( $key_config['key'], $block_name, array_merge( $path, [ (string) Obj::path( [ 'attr', 'name' ], $key_config ) ] ) );
				$valid_children = $this->filter_string_keys( $children );

				if ( $valid_children ) {
					$partial_config['children'] = $valid_children;
				} else {
					unset( $partial_config['to_include'] );
				}
			}

			if ( $partial_config ) {
				$final_config = array_merge( $final_config, [ $key_config['attr']['name'] => $partial_config ] );
			}
		}

		return $final_config;
	}

	private function is_refused_text_key( array $key_config ) {
		$name = Obj::path( [ 'attr', 'name' ], $key_config );
		$type = Obj::pathOr( '', [ 'attr', 'type' ], $key_config );

		return is_string( $name )
			&& ! isset( $key_config['key'] )
			&& false === strpos( $name, '*' )
			&& self::SEARCH_METHOD_REGEX !== Obj::path( [ 'attr', 'search-method' ], $key_config )
			&& self::is_string_type( $type )
			&& ! in_array( $type, [ WPML_Page_Builders_Media_Gutenberg::TYPE_URL, WPML_Page_Builders_Media_Gutenberg::TYPE_IDS ], true )
			&& \WPML\PB\Gutenberg\NeverTextKeys::matches( $name );
	}

	private function log_refused_text_key( $block_name, array $key_path ) {
		$path = implode( '>', $key_path );
		$id   = $block_name . '/' . $path;

		if ( isset( $this->loggedRefusals[ $id ] ) ) {
			return;
		}
		$this->loggedRefusals[ $id ] = true;

		call_user_func(
			$this->logger,
			sprintf(
				'WPML: the configuration of the block "%s" names the attribute "%s" as text. It holds an id, a class name or an anchor, which is never translated, so the key is ignored.',
				$block_name,
				$path
			)
		);
	}

	public function writeErrorLog( $message ) {
		error_log( $message );
	}

	private function filter_string_keys( $keys ) {
		return wpml_collect( $keys )
			->filter( Obj::prop( 'to_include' ) )
			->toArray();
	}

	private function cleanup_to_include_key( $data ) {
		foreach ( $data as &$item ) {
			unset( $item['to_include'] );

			if ( isset( $item['children'] ) ) {
				$item['children'] = $this->cleanup_to_include_key( $item['children'] );
			}
		}

		return $data;
	}

	private function normalize_key_data( array $data ) {
		return isset( $data['value'] ) ? array( $data ) : $data;
	}

	private static function is_string_type( $type ) {
		return ! ConvertIdsHelper::isValidType( $type );
	}

	public function get() {
		return get_option( self::OPTION, array() );
	}

	public function get_ids_in_blocks() {
		return get_option( self::OPTION_IDS_IN_BLOCKS, [] );
	}

	public function get_media_in_blocks() {
		return get_option( self::OPTION_MEDIA_IN_BLOCKS, [] );
	}
}
