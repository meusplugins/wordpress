<?php return array('dependencies' => array(), 'version' => 'a2c9cdc9234946bde305');
