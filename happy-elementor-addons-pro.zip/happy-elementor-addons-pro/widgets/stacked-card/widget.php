<?php
    /**
 * Cards Stacked
 * @package Happy_Addons_Pro
 */
    namespace Happy_Addons_Pro\Widget;

    use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;

    defined( 'ABSPATH' ) || die();

    class Stacked_Card extends Base {

    /**
     * Get widget title.
     *
     * @access public
     * @since 1.0.0
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Stacked Card', 'happy-addons-pro' );
    }

    /**
     * Get widget user document.
     *
     * @access public
     * @since 1.0.0
     *
     * @return string Widget document.
     */
    public function get_custom_help_url() {
        return 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/happy-effects-pro/stacked-card/';
    }

    /**
     * Get widget icon.
     *
     * @access public
     * @since 1.0.0
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'hm hm-photo-stack';
    }

    public function get_keywords() {
        return ['cards', 'Card', 'Cards', 'stack', 'stacked', 'Cards Stacked', 'Stacked Card', 'CardStacked', 'Cards-Stacked'];
    }

    /**
     * Register widget content controls
     */
    protected function register_content_controls() {
        $this->__cards_content_controls();
        $this->__settings_content_controls();
    }

    protected function __cards_content_controls() {

        $isContainerActive    = ha_elementor()->experiments->is_feature_active( 'container' );
        $elementorLibraryType = $isContainerActive ? 'container' : 'section';

        $this->start_controls_section(
            '_section_cst_contents',
            [
                'label' => __( 'Cards Content', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_CONTENT
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'content_source',
            [
                'type'      => Controls_Manager::SELECT,
                'label'     => __( 'Content Source', 'happy-addons-pro' ),
                'default'   => 'editor',
                'separator' => 'before',
                'options'   => [
                    'editor'   => __( 'Editor', 'happy-addons-pro' ),
                    'template' => __( 'Template', 'happy-addons-pro' )
                ]
            ]
        );

        $repeater->add_control(
            'template',
            [
                'label'       => __( 'Template', 'happy-addons-pro' ),
                'placeholder' => __( 'Select a template to use as tab content', 'happy-addons-pro' ),
                'description' => sprintf( __( 'Wondering what is template or need to create one? Please click %1$shere%2$s ', 'happy-addons-pro' ),
                    '<a target="_blank" href="' . esc_url( admin_url( '/edit.php?post_type=elementor_library&tabs_group=library&elementor_library_type=' . $elementorLibraryType ) ) . '">',
                    '</a>'
                ),
                'type'        => Controls_Manager::SELECT2,
                'label_block' => true,
                'options'     => hapro_get_section_templates(),
                'condition'   => [
                    'content_source' => 'template'
                ]
            ]
        );

        $repeater->add_control(
            'icon',
            [
                'label'       => __( 'Icon', 'happy-addons-pro' ),
                'type'        => Controls_Manager::ICONS,
                'skin'        => 'inline',
                'label_block' => false,
                'default'     => [
                    'value'   => 'fas fa-gem',
                    'library' => 'fa-solid'
                ],
                'condition'   => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'title',
            [
                'type'        => Controls_Manager::TEXTAREA,
                'label'       => __( 'Title', 'happy-addons-pro' ),
                'default'     => __( 'Smooth & Seamless Scrolling Animation', 'happy-addons-pro' ),
                'placeholder' => __( 'Type Your Title', 'happy-addons-pro' ),
                'dynamic'     => [
                    'active' => true
                ],
                'condition'   => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'editor',
            [
                'label'      => __( 'Content Editor', 'happy-addons-pro' ),
                'show_label' => false,
                'type'       => Controls_Manager::WYSIWYG,
                'condition'  => [
                    'content_source' => 'editor'
                ],
                'dynamic'    => [
                    'active' => true
                ]
            ]
        );

        $repeater->add_control(
            'btn_text',
            [
                'label'       => __( 'Button Text', 'happy-addons-pro' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Explore', 'happy-addons-pro' ),
                'placeholder' => __( 'Type your text', 'happy-addons-pro' ),
                'condition'   => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'happy-addons-pro' ),
                'type'        => Controls_Manager::ICONS,
                'skin'        => 'inline',
                'label_block' => false,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'fa-solid'
                ],
                'condition'   => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'btn_link',
            [
                'label'       => __( 'Link', 'happy-addons-pro' ),
                'type'        => Controls_Manager::URL,
                'options'     => ['url', 'is_external', 'nofollow'],
                'default'     => [
                    'url'         => '',
                    'is_external' => true,
                    'nofollow'    => true
                ],
                'label_block' => true,
                'condition'   => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'     => __( 'Image', 'happy-addons-pro' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src()
                ],
                'condition' => [
                    'content_source' => 'editor'
                ]
            ]
        );

        $repeater->add_control(
            'ha_cst_card_style_heading',
            [
                'label'     => __( 'Style', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            ]
        );

        $repeater->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'ha_cst_card_bg',
                'types'    => ['classic', 'gradient'],
                'exclude'  => ['image'],
                'selector' => '{{WRAPPER}}.ha-cards-stacked .ha-cst-wrapper {{CURRENT_ITEM}}.ha-cst-card'
            ]
        );

        $this->add_control(
            'card_items',
            [
                'show_label' => false,
                'type'       => Controls_Manager::REPEATER,
                'fields'     => $repeater->get_controls(),
                // 'title_field' => '{{ title }}',
                'default'    => [
                    [
                        // 'content_source' => 'editor',
                        'title'    => 'Show Your Product Step by Step',
                        'editor'   => __('Guide your visitors through your product features as each card smoothly appears while scrolling.', 'happy-addons-pro'),
                        'btn_text' => 'See Demo',
                        'card_background_background' => 'classic',
                        'card_background_color' => '',
                    ],
                    [
                        // 'content_source' => 'editor',
                        'title'    => 'Tell a Visual Story with Stacked Cards',
                        'editor'   => __('Present your content in a storytelling format where each card reveals the next part of your message.', 'happy-addons-pro' ),
                        'btn_text' => 'Learn More',
                        'card_background_background' => 'classic',
                        'card_background_color' => '',
                    ],
                    [
                        // 'content_source' => 'editor',
                        'title'    => 'Make Your Website Feel Modern and Dynamic',
                        'editor'   => __('Use stacked cards to showcase services, product features, case studies, or portfolio items.', 'happy-addons-pro'),
                        'btn_text' => 'Explore More',
                        'card_background_background' => 'classic',
                        'card_background_color' => '',
                    ]
                ]
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title Tag', 'happy-addons-pro' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h1'   => 'H1',
                    'h2'   => 'H2',
                    'h3'   => 'H3',
                    'h4'   => 'H4',
                    'h5'   => 'H5',
                    'h6'   => 'H6',
                    'div'  => 'div',
                    'span' => 'span',
                    'p'    => 'p'
                ],
                'default' => 'h3'
            ]
        );

        $this->add_control(
            'rpt_magic',
            [
                'label'        => __( 'none', 'happy-addons-pro' ),
                'type'         => Controls_Manager::HIDDEN,
                'default'      => 'retaeper',
                'prefix_class' => 'cigam-'
            ]
        );

        $this->end_controls_section();
    }

    protected function __settings_content_controls() {

        $this->start_controls_section(
            '_section_cst_settings',
            [
                'label' => __( 'Settings', 'happy-addons-pro' )
            ]
        );

        $this->add_control(
            'ha_cst_layout',
            [
                'type'           => Controls_Manager::CHOOSE,
                'label'          => __( 'Layout', 'happy-addons-pro' ),
                'default'        => 'row',
                'toggle'         => false,
                'options'        => [
                    'row-reverse'    => [
                        'title' => __( 'Left (Image Left, Content Right)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-left'
                    ],
                    'column-reverse' => [
                        'title' => __( 'Top (Image Top, Content Bottom)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-v-align-top'
                    ],
                    'row'            => [
                        'title' => __( 'Right (Content Left, Image Right)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-right'
                    ],
                    'column'         => [
                        'title' => __( 'Bottom (Content Top, Image Bottom)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-v-align-bottom'
                    ]
                ],
                'style_transfer' => true,
                'selectors'      => [
                    '{{WRAPPER}} .ha-cst-card' => 'flex-direction: {{VALUE}};'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_direction',
            [
                'label'              => __( 'Stack Direction', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'vertical',
                'options'            => [
                    'horizontal' => __( 'Horizontal', 'happy-addons-pro' ),
                    'vertical'   => __( 'Vertical', 'happy-addons-pro' )
                ],
                'render_type'        => 'template',
                'toggle'             => false,
                'frontend_available' => true
            ]
        );

        $this->add_control(
            'ha_cst_hs_mode',
            [
                'type'           => Controls_Manager::CHOOSE,
                'label'          => __( 'Mode', 'happy-addons-pro' ),
                'default'        => 'right-to-left',
                'toggle'         => false,
                'options'        => [
                    'right-to-left'    => [
                        'title' => __( 'Left (Right to Left)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-left'
                    ],
                    'left-to-right'            => [
                        'title' => __( 'Right (Left to Right)', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-right'
                    ],
                ],
                'condition' => [
                    'ha_cst_direction' => 'horizontal'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->add_control(
            'ha_cst_trigger_point',
            [
                'label'              => __( 'Trigger Point', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'center-top',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' ),
                    'custom'        => __( 'Custom', 'happy-addons-pro' )
                ],
                'description'        => __( 'First value = element position, second = viewport position.',
                    'happy-addons-pro' ),
                'render_type'        => 'template',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $this->add_control(
            'ha_cst_custom_trigger_point',
            [
                'label'              => __( 'Custom Trigger(Start)', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'default'            => 'top top+=100',
                'placeholder'        => __( 'e.g., top top+=100', 'happy-addons-pro' ),
                'render_type'        => 'template',
                'frontend_available' => true,
                'condition'          => [
                    'ha_cst_trigger_point' => 'custom'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_delay',
            [
                'label'              => __( 'Delay(s)', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => 0.1,
                'max'                => 10,
                'step'               => 0.1,
                'default'            => 1.5,
                'render_type'        => 'template',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $this->add_control(
            'ha_cst_offset',
            [
                'label'              => __( 'Stack Offset', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => 0,
                'max'                => 150,
                'step'               => 1,
                'default'            => 10,
                'render_type'        => 'template',
                'frontend_available' => true,
                'style_transfer'     => true
            ]
        );

        $this->add_control(
            'ha_cst_rotation',
            [
                'label'              => __( 'Rotation Value (DEG)', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => 0,
                'max'                => 360,
                'step'               => 1,
                'default'            => 60,
                'render_type'        => 'template',
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'ha_cst_direction!' => 'horizontal'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function register_style_controls() {
        $this->__card_stacked_layout_style_controls();
        $this->__card_stacked_content_style_controls();
        $this->__card_stacked_button_style_controls();
        $this->__card_stacked_image_style_controls();
    }

    protected function __card_stacked_layout_style_controls() {
        $this->start_controls_section(
            '__ha_cst_layout_style',
            [
                'label' => __( 'Layout', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'ha_cst_layout_bg',
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .ha-cst-card'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_layout_padding',
            [
                'label'      => __( 'Padding', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'ha_cst_layout_border',
                'selector' => '{{WRAPPER}} .ha-cst-card'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_layout_radius',
            [
                'label'      => __( 'Border Radius', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_layout_height',
            [
                'label'      => __( 'Height', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'vh'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 2000
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-cards' => 'height: {{SIZE}}{{UNIT}} !important; max-height: {{SIZE}}{{UNIT}} !important;'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function __card_stacked_content_style_controls() {
        $this->start_controls_section(
            '__ha_cst_content_style',
            [
                'label' => __( 'Content', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_responsive_control(
            'ha_cst_content_padding',
            [
                'label'      => __( 'Padding', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_card_icon_heading',
            [
                'label'     => __( 'Icon', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'ha_cst_card_icon_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-cst-icon' => 'fill: {{VALUE}}; color: {{VALUE}}'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_card_icon_size',
            [
                'label'      => __( 'Icon Size', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-icon' => 'font-size: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_card_icon_margin',
            [
                'label'      => __( 'Margin', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_title_heading',
            [
                'label'     => __( 'Title', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'ha_cst_title_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}}'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'ha_cst_title_typo',
                'selector' => '{{WRAPPER}} .title'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_title_margin',
            [
                'label'      => __( 'Margin', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_desc_heading',
            [
                'label'     => __( 'Description', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            ]
        );

        $this->add_control(
            'ha_cst_desc_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-cst-card .ha-cst-content-text' => 'color: {{VALUE}}'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'ha_cst_desc_typo',
                'selector' => '{{WRAPPER}} .ha-cst-card .ha-cst-content-text'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_desc_margin',
            [
                'label'      => __( 'Margin', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-card .ha-cst-content-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function __card_stacked_button_style_controls() {
        $this->start_controls_section(
            '__ha_cst_btn_style',
            [
                'label' => __( 'Button', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'ha_cst_btn_typo',
                'selector' => '{{WRAPPER}} .ha-cst-btn'
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'ha_cst_btn_border',
                'selector' => '{{WRAPPER}} .ha-cst-btn'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_btn_radius',
            [
                'label'      => __( 'Border Radius', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_btn_padding',
            [
                'label'      => __( 'Padding', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_btn_align_x',
            [
                'label'       => __( 'Alignment', 'happy-addons-pro' ),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'left'   => [
                        'title' => __( 'Left', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => __( 'Center', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-center'
                    ],
                    'right'  => [
                        'title' => __( 'Right', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-right'
                    ]
                ],
                'toggle'      => true,
                'selectors'   => [
                    '{{WRAPPER}} .ha-cst-btn-wrapper' => 'text-align: {{VALUE}};'
                ]
            ]
        );

        // Tabs for Normal and Hover states
        $this->start_controls_tabs(
            'ha_cst_btn_style_tabs'
        );

        //Normal
        $this->start_controls_tab(
            'ha_cst_btn_normal_tab',
            [
                'label' => __( 'Normal', 'happy-addons-pro' )
            ]
        );

        $this->add_control(
            'ha_cst_btn_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-cst-btn' => 'fill: {{VALUE}}; color: {{VALUE}}'
                ]
            ]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ha_cst_btn_bg',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .ha-cst-btn',
			]
		);

        $this->end_controls_tab();

        // Hover
        $this->start_controls_tab(
            'ha_cst_btn_hover_tab',
            [
                'label' => __( 'Hover', 'happy-addons-pro' )
            ]
        );

        $this->add_control(
            'ha_cst_btn_h_color',
            [
                'label'     => __( 'Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-cst-btn:hover' => 'fill: {{VALUE}}; color: {{VALUE}}'
                ]
            ]
        );

        $this->add_control(
            'ha_cst_btn_border_hover_color',
            [
                'label'     => __( 'Border Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ha-cst-btn:hover' => 'border-color: {{VALUE}};'
                ]
            ]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'ha_cst_btn_hover_bg',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .ha-cst-btn:hover',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'ha_cst_btn_icon_heading',
            [
                'label'     => __( 'Icon', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'after'
            ]
        );

        $this->add_responsive_control(
            'ha_cst_btn_icon_size',
            [
                'label'      => __( 'Icon Size', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .btn-icon' => 'font-size: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_btn_icon_gap',
            [
                'label'      => __( 'Icon Gap', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 250
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-btn' => 'gap: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function __card_stacked_image_style_controls() {
        $this->start_controls_section(
            '__ha_cst_image_style',
            [
                'label' => __( 'Image', 'happy-addons-pro' ),
                'tab'   => Controls_Manager::TAB_STYLE
            ]
        );

        $this->add_responsive_control(
            'ha_cst_img_width',
            [
                'label'      => __( 'Width', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 2100
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-image img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ha-cst-image'     => 'flex: 0 0 {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_img_height',
            [
                'label'      => __( 'Height', 'happy-addons-pro' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 2100
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-image img' => 'height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_img_radius',
            [
                'label'      => __( 'Border Radius', 'happy-addons-pro' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem'],
                'selectors'  => [
                    '{{WRAPPER}} .ha-cst-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ]
            ]
        );

        $this->add_responsive_control(
            'ha_cst_img_align_x',
            [
                'label'       => __( 'Alignment', 'happy-addons-pro' ),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'left'   => [
                        'title' => __( 'Left', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-left'
                    ],
                    'center' => [
                        'title' => __( 'Center', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-center'
                    ],
                    'right'  => [
                        'title' => __( 'Right', 'happy-addons-pro' ),
                        'icon'  => 'eicon-h-align-right'
                    ]
                ],
                'toggle'      => true,
                'selectors'   => [
                    '{{WRAPPER}} .ha-cst-image' => 'text-align: {{VALUE}};'
                ],
                'condition'   => [
                    'ha_cst_layout' => ['column', 'column-reverse']
                ]
            ]
        );

        $this->add_control(
            'ha_cst_image_fit',
            [
                'label'              => __( 'Object Fit', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'contain' => __( 'Contain', 'happy-addons-pro' ),
                    'cover'   => __( 'Cover', 'happy-addons-pro' ),
                    'fill'    => __( 'Fill', 'happy-addons-pro' )
                ],
                // 'default'            => 'cover',
                'selectors'          => [
                    '{{WRAPPER}} .ha-cst-image img' => 'object-fit: {{VALUE}};'
                ],
                'style_transfer'     => true,
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
            $settings  = $this->get_settings_for_display();
            $cardItems = (array) $settings['card_items'];
            $title_tag = $settings['title_tag'];

            $is_horizontal = $settings['ha_cst_direction'] === 'horizontal';
            $hs_mode       = ! empty( $settings['ha_cst_hs_mode'] ) ? $settings['ha_cst_hs_mode'] : 'right-to-left';

            $this->add_render_attribute( 'ha_cards_stacked', [
                'class' => 'ha-cst-wrapper',
                'data-direction' => $settings['ha_cst_direction'],
                'data-mode' => $is_horizontal ? $hs_mode : '',
            ] );

            // OPEN wrapper only if horizontal
            if ( $is_horizontal ) {
                echo '<div class="ha-cst-clip-container">';
            }
        ?>
            
            <div <?php $this->print_render_attribute_string( 'ha_cards_stacked' ); ?>>
                <div class="ha-cst-cards">
                    <?php
                        if ( $cardItems ) {
                            foreach ( $cardItems as $index => $card ) {
                                $btn_link = 'btn_id_' . $index;
                                if ( !empty( $card['btn_link']['url'] ) ) {
                                    $this->add_link_attributes( $btn_link, $card['btn_link'] );
                                }

                                if ( 'editor' === $card['content_source'] ) {
                        ?>
                    <div class="ha-cst-card elementor-repeater-item-<?php echo $card['_id']; ?>">
                        <div class="ha-cst-content">
                            <div class="ha-cst-icon">
                                <?php Icons_Manager::render_icon( $card['icon'], ['aria-hidden' => 'true'] ); ?>
                            </div>
                            <<?php Utils::print_validated_html_tag( $title_tag ); ?> class="title">
                            <?php echo esc_html( $card['title'] ); ?>
                        </<?php Utils::print_validated_html_tag( $title_tag ); ?>>
                        <div class="ha-cst-content-text">
                            <?php echo $this->parse_text_editor( $card['editor'] ); ?>
                        </div>
                        <a <?php $this->print_render_attribute_string( $btn_link ); ?> class="ha-cst-btn">
                            <?php echo esc_html( $card['btn_text'] ); ?>
                            <span class="btn-icon">
                                <?php Icons_Manager::render_icon( $card['btn_icon'], ['aria-hidden' => 'true'] ); ?>
                            </span>
                        </a>
                    </div>
                    <div class="ha-cst-image">
                        <img src="<?php echo esc_url( $card['image']['url'] ); ?>" alt="<?php echo esc_attr( $card['title'] ); ?>">
                    </div>
                </div>
                    <?php
                        } else {
                            if ( 'template' === $card['content_source'] && $card['template'] ) {?>
                                <div class="ha-cst-card ha-card-el">
                                    <?php
                                        $item_template = apply_filters( 'wpml_object_id', $card['template'], 'elementor_library' );
                                        echo ha_elementor()->frontend->get_builder_content_for_display( $item_template );
                                    ?>
                                </div>
                                <?php
                                    }
                                }
                            }
                        }
                    ?>
                </div>
            </div>

    <?php
            // CLOSE wrapper only if horizontal
            if ( $is_horizontal ) {
                echo '</div>';
            }
            
    }

}
