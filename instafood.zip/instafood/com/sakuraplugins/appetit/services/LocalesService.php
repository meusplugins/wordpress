<?php
namespace com\sakuraplugins\appetit\services;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . '../config.php');
require_once(plugin_dir_path(__FILE__) . '../templates/admin/settings/SettingsConfig.php');

use com\sakuraplugins\appetit\utils\OptionUtil;
use com\sakuraplugins\appetit\templates\admin\settings\SettingsConfig;

class LocalesService {
    private static $instance = null;
    private $locales = [];

    public function getLocales() {
        if (isset($this->locales) && is_array($this->locales) && sizeof($this->locales) > 0) {
            return $this->locales;
        }
        $apt_locales = OptionUtil::getInstance()->getOption("apt_locales", []);
        $locales_config = SettingsConfig::getLocales();
        for ($i=0; $i < sizeof($locales_config); $i++) {
            $defaultLocaleEntry = $locales_config[$i];
            $localeEntry = isset($apt_locales[$i]) ? $apt_locales[$i] : $defaultLocaleEntry;
            $localeEntryVal = isset($apt_locales[$defaultLocaleEntry['db_key']]) ? $apt_locales[$defaultLocaleEntry['db_key']] : [];
            
            $this->locales[$defaultLocaleEntry['db_key']] = [
                'primary_lang_' => isset($localeEntryVal['primary_lang_']) ? esc_html($localeEntryVal['primary_lang_']) : $localeEntry['primary_lang_'],
                'secondary_lang_' => isset($localeEntryVal['secondary_lang_']) ? esc_html($localeEntryVal['secondary_lang_']) : $localeEntry['secondary_lang_'],
            ];
        }
        $this->locales['restaurant_name'] = [
            'primary_lang_' => OptionUtil::getInstance()->getOption("restaurant_name", ''),
            'secondary_lang_' => OptionUtil::getInstance()->getOption("restaurant_name", ''),
        ];

        $this->locales['restaurant_about'] = [
            'primary_lang_' => OptionUtil::getInstance()->getOption("restaurant_about", ''),
            'secondary_lang_' => OptionUtil::getInstance()->getOption("restaurant_about", ''),
        ];

        $this->locales['primary_lang_ccode'] = [
            'primary_lang_' => OptionUtil::getInstance()->getOption("primary_lang_ccode", ''),
            'secondary_lang_' => OptionUtil::getInstance()->getOption("primary_lang_ccode", ''),
        ];
        $this->locales['secondary_lang_ccode'] = [
            'primary_lang_' => OptionUtil::getInstance()->getOption("secondary_lang_ccode", ''),
            'secondary_lang_' => OptionUtil::getInstance()->getOption("secondary_lang_ccode", ''),
        ];
        return $this->locales;
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new LocalesService();
        }
        return self::$instance;
    }
}
?>