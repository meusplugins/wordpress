<?php

namespace WPML\PB\BeaverBuilder;

class LayoutUpdate extends \WPML_Page_Builders_Update {

	use KeepsUnpublishedDraft;
}
