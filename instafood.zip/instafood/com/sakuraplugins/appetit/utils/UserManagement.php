<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;

require_once(plugin_dir_path(__FILE__) . '../cpt/MenuItemCpt.php');
require_once(plugin_dir_path(__FILE__) . '../cpt/OrderCpt.php');
require_once(plugin_dir_path(__FILE__) . '../cpt/ChoiceGroupsCpt.php');

use com\sakuraplugins\appetit\cpt\MenuItemCpt;
use com\sakuraplugins\appetit\cpt\OrderCpt;
use com\sakuraplugins\appetit\cpt\ChoiceGroupsCpt;

class UserManagement {
    
    const IF_RESTAURANT_ADMIN = 'IF_RESTAURANT_ADMIN';
    const IF_RESTAURANT_STAFF = 'IF_RESTAURANT_STAFF';

    const IF_SETTINGS_CAP = 'IF_SETTINGS_CAP';
    const ORDERS_PAGE_CAP = 'ORDERS_PAGE_CAP';

    static function addRoles() {

        add_role(self::IF_RESTAURANT_ADMIN,
            esc_html__('Restaurant administrator', 'instafood'),
            [
                'read' => true,
                'edit_posts' => false,
                'delete_posts' => false,
                'publish_posts' => false,
                'upload_files' => true,
            ]
        );
        add_role(self::IF_RESTAURANT_STAFF,
            esc_html__('Restaurant staff', 'instafood'),
            [
                'read' => true,
                'edit_posts' => false,
                'delete_posts' => false,
                'publish_posts' => false,
                'upload_files' => false,
            ]
        );
    }

    static function removeRoles() {
        $roles = [self::IF_RESTAURANT_ADMIN, self::IF_RESTAURANT_STAFF];
        foreach($roles as $the_role) {
            $role = get_role($the_role);
            if (!$role) {
                continue;
            }
            remove_role($the_role);
        }
    }

    static function mapCapabilitiesToRoles() {
        $roles = ['administrator', self::IF_RESTAURANT_ADMIN, self::IF_RESTAURANT_STAFF];
        foreach($roles as $the_role) {
            $role = get_role($the_role);
            if (!$role) {
                continue;
            }
            
            $role->add_cap(self::ORDERS_PAGE_CAP);

            if ($the_role === self::IF_RESTAURANT_ADMIN) {
                $role->add_cap(self::IF_SETTINGS_CAP);
                $role->add_cap('create_users');
                $role->add_cap('edit_users');
                $role->add_cap('delete_users');
                $role->add_cap('list_users');
                $role->add_cap('remove_users');
                $role->add_cap('promote_users');
            }
            
            if ($the_role === self::IF_RESTAURANT_ADMIN || $the_role === 'administrator') {
                $role->add_cap(self::IF_SETTINGS_CAP);

                $menu_item_capabilities = self::compile_post_type_capabilities(MenuItemCpt::getPostType(), MenuItemCpt::getPostTypePlural());
                $menuCatCaps = MenuItemCpt::getCategoryCaps();

                foreach (array_merge($menu_item_capabilities, $menuCatCaps) as $menuCap) {
                    $role->add_cap( $menuCap );
                }

                $order_capabilities = self::compile_post_type_capabilities(OrderCpt::getPostType(), OrderCpt::getPostTypePlural());
                foreach ($order_capabilities as $oCap) {
                    $role->add_cap( $oCap );
                }

                $cg_capabilities = self::compile_post_type_capabilities(ChoiceGroupsCpt::getPostType(), ChoiceGroupsCpt::getPostTypePlural());
                $cgCatCaps = ChoiceGroupsCpt::getCategoryCaps();

                foreach (array_merge($cg_capabilities, $cgCatCaps) as $cgCap) {
                    $role->add_cap( $cgCap );
                }
            }
        }
    }

    static function compile_post_type_capabilities($singular = 'post', $plural = 'posts') {
        return [
            'edit_post'      => "edit_$singular",
            'read_post'      => "read_$singular",
            'delete_post'        => "delete_$singular",
            'edit_posts'         => "edit_$plural",
            'edit_others_posts'  => "edit_others_$plural",
            'publish_posts'      => "publish_$plural",
            'read_private_posts'     => "read_private_$plural",
            'read'                   => "read",
            'delete_posts'           => "delete_$plural",
            'delete_private_posts'   => "delete_private_$plural",
            'delete_published_posts' => "delete_published_$plural",
            'delete_others_posts'    => "delete_others_$plural",
            'edit_private_posts'     => "edit_private_$plural",
            'edit_published_posts'   => "edit_published_$plural",
            'create_posts'           => "edit_$plural",
        ];
    }

    static function getCurrentUserRole() {
        if( is_user_logged_in() ) {
                $user = wp_get_current_user();
                $roles = ( array ) $user->roles;
                $role = $roles[0] ?? '';
                return $role;
            } else {
            return '';
        }
    }
}
?>