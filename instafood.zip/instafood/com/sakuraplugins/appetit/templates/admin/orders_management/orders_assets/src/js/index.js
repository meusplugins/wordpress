import DataUtils from './utils/DataUtils';
import LiveOrders from './pages/live_orders/LiveOrders';
import RegularOrders from './pages/regular_orders/RegularOrders';
import LiveOrdersTopNav from './components/LiveOrdersTopNav';
import CallWaiterTopNav from './components/CallWaiterTopNav';
import OrderSingle from './pages/single_order/OrderSingle';
import WaiterCalls from './pages/waiter_calls/WaiterCalls';


DataUtils.getInstance().setupData(jQuery('#appetit_data').val());

LiveOrdersTopNav.getInstance();
CallWaiterTopNav.getInstance();
LiveOrders.getInstance().init();
RegularOrders.getInstance().init();
OrderSingle.getInstance();
WaiterCalls.getInstance().init();

toastr.options = {
    "debug": false,
    "positionClass": "toast-bottom-full-width",
    "onclick": null,
    "fadeIn": 300,
    "fadeOut": 800,
    "timeOut": 2000,
    "extendedTimeOut": 800
}
