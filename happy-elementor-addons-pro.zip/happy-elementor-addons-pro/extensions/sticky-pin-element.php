<?php

namespace Happy_Addons_Pro\Extensions;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;

defined( 'ABSPATH' ) || die();

class Sticky_Pin_Element {

    private static $instance = null;

    private $load_script = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function init() {

        add_action( 'wp_enqueue_scripts', [$this, 'register_scripts'] );
        add_action( 'wp_enqueue_scripts', [$this, 'register_styles'] );

        add_action( 'elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts'] );

        add_action( 'elementor/element/common/_section_style/after_section_end', [$this, 'register_controls'], 1 );
        add_action( 'elementor/frontend/widget/before_render', [$this, 'before_render'] );

        if ( defined( 'ELEMENTOR_VERSION' ) && ha_elementor()->experiments->is_feature_active( 'container' ) ) {
            add_action( 'elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 1 );
            add_action( 'elementor/frontend/container/before_render', [$this, 'before_render'] );
        }
    }

    public function register_scripts() {

        $suffix = ha_is_script_debug_enabled() ? '.' : '.min.';

        wp_register_script(
            'sticky-pin-element',
            HAPPY_ADDONS_PRO_ASSETS . 'js/sticky-pin-element' . $suffix . 'js',
            ['jquery', 'happy-elementor-addons', 'gsap', 'scroll-trigger'],
            HAPPY_ADDONS_PRO_VERSION,
            true
        );
    }

    public function register_styles() {

        wp_register_style(
            'sticky-pin-element',
            HAPPY_ADDONS_PRO_ASSETS . 'css/widgets/sticky-pin-element.min.css',
            [],
            HAPPY_ADDONS_PRO_VERSION
        );
    }

    public function enqueue_preview_scripts() {

        wp_enqueue_script( 'gsap' );
        wp_enqueue_script( 'scroll-trigger' );

        wp_enqueue_script( 'sticky-pin-element' );

        wp_enqueue_style( 'sticky-pin-element' );
    }

    public function register_controls( $element ) {

        $element->start_controls_section(
            '_ha_spl_section',
            [
                'label' => esc_html__( 'Sticky Pin Element', 'happy-addons-pro' ) . ha_get_section_icon(),
                'tab'   => Controls_Manager::TAB_ADVANCED
            ]
        );

        $this->add_content_controls( $element );

        $element->end_controls_section();
    }

    public function add_content_controls( $element ) {

        $element->add_control(
            'ha_spl_init_notice',
            [
                'type'       => Controls_Manager::ALERT,
                'alert_type' => 'info',
                'heading'    => __( 'Note:', 'happy-addons-pro' ),
                'content'    => sprintf(
                    __( 'Avoid using Happy Animations and Sticky Pin on the same element. Need help? <a href="%s" target="_blank" rel="noopener noreferrer">Read Documentation</a>', 'happy-addons-pro' ),
                    esc_url( 'https://happyaddons.com/docs/happy-addons-for-elementor-pro/features/sticky-pin-elements/' )
                ),
            ]
        );

        $element->add_control(
            'ha_spl_switcher',
            [
                'label'              => __( 'Enable', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'prefix_class'       => 'ha-spl-',
                'render_type'        => 'template',
                'return_value'       => 'yes',
                'frontend_available' => true,
                'assets'             => [
                    'scripts' => [
                        [
                            'name'       => 'elementor-frontend',
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name'     => 'ha_spl_switcher',
                                        'operator' => '===',
                                        'value'    => 'yes'
                                    ]
                                ]
                            ]
                        ],
                        [
                            'name'       => 'gsap',
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name'     => 'ha_spl_switcher',
                                        'operator' => '===',
                                        'value'    => 'yes'
                                    ]
                                ]
                            ]
                        ],
                        [
                            'name'       => 'scroll-trigger',
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name'     => 'ha_spl_switcher',
                                        'operator' => '===',
                                        'value'    => 'yes'
                                    ]
                                ]
                            ]
                        ],
                        [
                            'name'       => 'sticky-pin-element',
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name'     => 'ha_spl_switcher',
                                        'operator' => '===',
                                        'value'    => 'yes'
                                    ]
                                ]
                            ]
                        ]
                    ],
                    'styles'  => [
                        [
                            'name'       => 'sticky-pin-element',
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name'     => 'ha_spl_switcher',
                                        'operator' => '===',
                                        'value'    => 'yes'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        );

        $element->add_responsive_control(
            'ha_spl_pin_start',
            [
                'label'              => __( 'Pin Start Position', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'top-top',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'description'        => __(
                    'First value is the element position, second is the viewport position.',
                    'happy-addons-pro'
                )
            ]
        );

        $element->add_responsive_control(
            'ha_spl_start_trigger',
            [
                'label'              => __( 'Start Trigger', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'default',
                'options'            => [
                    'default' => __( 'Default', 'happy-addons-pro' ),
                    'custom'  => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'description'        => __( 'Choose "Custom" to specify a CSS selector for the element that triggers the pin.', 'happy-addons-pro' )

            ]
        );

        $element->add_responsive_control(
            'ha_spl_pin_start_offset',
            [
                'label'              => __( 'Start Offset', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'default'            => 0,
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'frontend_available' => true,
                'render_type'        => 'template',
                'placeholder'        => __( '100', 'happy-addons-pro' ),
                'description'        => __( 'Offset applied to the Pin Start position (e.g., 100, -100, 50%, -50%).', 'happy-addons-pro' )
            ]
        );

        $element->add_responsive_control(
            'ha_spl_custom_start_area',
            [
                'label'              => __( 'Custom Start Area', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'placeholder'        => __( '.your-selector', 'happy-addons-pro' ),
                'description'        => __( 'Enter a CSS selector for the Column, Section, Container, or Widget element that triggers the pin.', 'happy-addons-pro' ),
                'condition'          => [
                    'ha_spl_switcher'      => 'yes',
                    'ha_spl_start_trigger' => 'custom'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $element->add_responsive_control(
            'ha_spl_pin_end',
            [
                'label'              => __( 'Pin End Position', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'bottom-bottom',
                'options'            => [
                    'top-top'       => __( 'Top - Top', 'happy-addons-pro' ),
                    'top-center'    => __( 'Top - Center', 'happy-addons-pro' ),
                    'top-bottom'    => __( 'Top - Bottom', 'happy-addons-pro' ),
                    'center-top'    => __( 'Center - Top', 'happy-addons-pro' ),
                    'center-center' => __( 'Center - Center', 'happy-addons-pro' ),
                    'center-bottom' => __( 'Center - Bottom', 'happy-addons-pro' ),
                    'bottom-top'    => __( 'Bottom - Top', 'happy-addons-pro' ),
                    'bottom-center' => __( 'Bottom - Center', 'happy-addons-pro' ),
                    'bottom-bottom' => __( 'Bottom - Bottom', 'happy-addons-pro' )
                ],
                'description'        => __(
                    'First value is the element position, second is the viewport position.',
                    'happy-addons-pro'
                ),
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'separator'          => 'before'
            ]
        );

        $element->add_responsive_control(
            'ha_spl_end_trigger',
            [
                'label'              => __( 'End Trigger', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'default',
                'options'            => [
                    'default' => __( 'Default', 'happy-addons-pro' ),
                    'custom'  => __( 'Custom', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'description'        => __( 'Choose "Custom" to specify a CSS selector for the element that triggers the end of pinning.', 'happy-addons-pro' )
            ]
        );

        $element->add_responsive_control(
            'ha_spl_pin_end_offset',
            [
                'label'              => __( 'End Offset', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'default'            => 0,
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'frontend_available' => true,
                'render_type'        => 'template',
                'placeholder'        => __( '50', 'happy-addons-pro' ),
                'description'        => __( 'Offset applied to the Pin End position (e.g., 100, -100, 50%, -50%).', 'happy-addons-pro' )
            ]
        );

        $element->add_control(
            'ha_spl_custom_end_area',
            [
                'label'              => __( 'Custom End Area', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'placeholder'        => __( '.your-selector', 'happy-addons-pro' ),
                'description'        => __( 'Enter a CSS selector for the Column, Section, Container, or Widget element where pinning should end.', 'happy-addons-pro' ),
                'condition'          => [
                    'ha_spl_switcher'    => 'yes',
                    'ha_spl_end_trigger' => 'custom'
                ],
                'render_type'        => 'template',
                'frontend_available' => true
            ]
        );

        $element->add_responsive_control(
            'ha_spl_pin_type',
            [
                'label'              => __( 'Pin', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SELECT,
                'default'            => 'true',
                'options'            => [
                    'true'  => __( 'True', 'happy-addons-pro' ),
                    'false' => __( 'False', 'happy-addons-pro' )
                ],
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template',
                'frontend_available' => true,
                'description'        => __(
                    'Enable or disable element pinning during scroll.',
                    'happy-addons-pro'
                )
            ]
        );

        $element->add_control(
            'ha_spl_pin_markers',
            [
                'label'              => __( 'Pin Markers', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'return_value'       => 'yes',
                'frontend_available' => true,
                'render_type'        => 'template',
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ]
            ]
        );

        $element->add_control(
            'ha_spl_enable_on_device',
            [
                'label'              => __( 'Enable On Mobile', 'happy-addons-pro' ),
                'type'               => Controls_Manager::SWITCHER,
                'default'            => 'no',
                'frontend_available' => true,
                'render_type'        => 'template',
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'description'        => __( 'When disabled, the animation will not run on mobile devices.', 'happy-addons-pro' )
            ]
        );

        $element->add_control(
            'ha_spl_active_heading',
            [
                'label'     => __( 'Active Pin Style', 'happy-addons-pro' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'ha_spl_switcher' => 'yes'
                ]
            ]
        );

        $element->add_responsive_control(
            'ha_spl_active_class',
            [
                'label'              => __( 'Toggle Class', 'happy-addons-pro' ),
                'type'               => Controls_Manager::TEXT,
                'placeholder'        => __( 'sticky-active', 'happy-addons-pro' ),
                'frontend_available' => true,
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'render_type'        => 'template'
            ]
        );

        $element->add_responsive_control(
            'ha_spl_active_color',
            [
                'label'     => __( 'Text Color', 'happy-addons-pro' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}.ha-spl-sticky-active'   => 'color: {{VALUE}};',
                    '{{WRAPPER}}.ha-spl-sticky-active *' => 'color: {{VALUE}};'
                ],
                'condition' => [
                    'ha_spl_switcher' => 'yes'
                ]
            ]
        );

        $element->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'      => 'ha_spl_active_background',
                'types'     => ['classic', 'gradient', 'video'],
                'selector'  => '{{WRAPPER}}.ha-spl-sticky-active, {{WRAPPER}}.ha-spl-sticky-active .elementor-widget-container',
                'condition' => [
                    'ha_spl_switcher' => 'yes'
                ]
            ]
        );

        $element->add_responsive_control(
            'ha_spl_transition_duration',
            [
                'label'              => __( 'Transition Duration(s)', 'happy-addons-pro' ),
                'type'               => Controls_Manager::NUMBER,
                'min'                => 0,
                'max'                => 10,
                'step'               => 0.1,
                'default'            => 0.3,
                'condition'          => [
                    'ha_spl_switcher' => 'yes'
                ],
                'frontend_available' => true,
                'render_type'        => 'template',
                'description'        => __( 'Set the duration of the transition effect when the element becomes sticky or returns to its normal position.', 'happy-addons-pro' )
            ]
        );
    }

    public function before_render( $element ) {
        $settings = $element->get_settings_for_display();

        if ( empty( $settings['ha_spl_switcher'] ) || 'yes' !== $settings['ha_spl_switcher'] ) {
            return;
        }

        $element->add_render_attribute( '_wrapper', 'class', 'ha-spl-element' );
    }

}
