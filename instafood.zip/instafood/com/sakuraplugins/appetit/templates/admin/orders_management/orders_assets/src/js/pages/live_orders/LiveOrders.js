import RestManager from '../../services/RestManager';
import DataUtils from '../../utils/DataUtils';
import OrderItem, { OrderMode } from '../../components/OrderItem';
import EventBus, { Events, Event } from '../../events/EventBus';

let instance;
const instanceKey = '23__ad847238_KSJK';

class LiveOrders {

    _ui;
    _intervalId;
    _intervalSeconds = 12;

    _ordersInstances = [];
    _onOrdersStatusChange;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._ui = jQuery('#live_orders');
        this._onOrdersStatusChange = new Event(Events.ORDER_CHANGED_STATUS, (data) => {
            this._handleOrderStatusChange(data);
        });
        EventBus.getInstance().registerEvent(this._onOrdersStatusChange);

        this._intervalId = setInterval(() => {
            this._retriveIncommingOrders();
        }, this._intervalSeconds * 1000);
    }

    init() {
        this._retrieveNewOrders()
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            const orders = lodash.get(result, 'data.data.orders', []);
            DataUtils.getInstance().setInitialLiveOrders(orders);
            this._render();
            this._handleNotfound();
        })
    }

    _render() {
        const orders = DataUtils.getInstance().getInitialLiveOrders();
        
        let c = 0;
        orders.forEach(order => {
            const showBackground = c % 2 === 1;
            const orderItem = new OrderItem(order, OrderMode.LIVE_ORDER);
            this._ordersInstances.push(orderItem);
            const orderTemplateUI = orderItem.getTemplate(showBackground)
            orderTemplateUI.appendTo(this._ui.find('.appetit_table_body'));
            c++;
        });
    }

    _retriveIncommingOrders() {
        this._retrieveNewOrders(DataUtils.getInstance().getExistingOrdersIds())
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
            }
            const orders = lodash.get(result, 'data.data.orders', []);
            DataUtils.getInstance().setNewLiveOrders(orders);
            let c = 0;
            orders.reverse().forEach(order => {
                const showBackground = c % 2 === 1;
                const orderItem = new OrderItem(order, OrderMode.LIVE_ORDER);
                this._ordersInstances.push(orderItem);
                const orderTemplateUI = orderItem.getTemplate(showBackground)
                orderTemplateUI.prependTo(this._ui.find('.appetit_table_body'));
                c++;
            });
        })
    }

    _retrieveNewOrders(exclude_ids = []) {
        this._ui.find('.orders_loading').css('opacity', 1);
        return new Promise((resolve, reject) => {
            const query = {
                order_status: 'NEW_ORDER',
                orderby: 'date_desc',
            }
            if (exclude_ids.length > 0) {
                query.exclude_posts = exclude_ids;
            }

            RestManager.getInstance()
            .postAjax('fetch_orders', {
                query
            })
            .then(result => {
                this._ui.find('.orders_loading').css('opacity', 0);
                resolve(result);
            });
        })
    }

    _handleNotfound() {
        const count = DataUtils.getInstance().getLiveOrdersCount();
        this._ui.find('.not_found').hide();
        if (count !== 0) {
            this._ui.find('.not_found').hide();
        } else {
            this._ui.find('.not_found').show();
        }
    }

    _handleOrderStatusChange({ ID, order_action, _mode, _from_lightbox }) {
        const instanceData = this._findOrderInstance(ID);
        if (!instanceData) {
            return;
        }
        
        const { index, instance } = instanceData;

        if (instance.getMode() !== _mode) {
            return;
        }

        instance.removeUI();
        this._ordersInstances.splice(index, 1);
        DataUtils.getInstance().removeLiveOrder(ID);

        EventBus.getInstance().triggerEvent(Events.RELOAD_REGULAR_ORDERS, {});
        instance.updateStatusSoft(order_action);
        this._handleNotfound();
    }

    _findOrderInstance(orderId) {
        let instanceData = false;
        for (let i = 0; i < this._ordersInstances.length; i++) {
            const orderItem = this._ordersInstances[i];
            if (parseInt(orderId) === parseInt(orderItem.getOrder().ID)) {
                instanceData = { index: i, instance: orderItem }
                break;
            }
        }
        return instanceData;
    }
    
    static getInstance() {
        if (!instance) {
            instance = new LiveOrders(instanceKey);
        }
        return instance;
    }
}
export default LiveOrders;