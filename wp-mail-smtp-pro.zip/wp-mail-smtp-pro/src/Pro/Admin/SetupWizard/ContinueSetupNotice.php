<?php

namespace WPMailSMTP\Pro\Admin\SetupWizard;

use WPMailSMTP\Admin\SetupWizard\UpgradeReturn;
use WPMailSMTP\WP;

/**
 * Offers a way back to the wizard step a Lite to Pro upgrade started from.
 *
 * @since 4.10.4
 */
class ContinueSetupNotice {

	/**
	 * Notice key, also the one its dismissal sends over AJAX.
	 *
	 * @since 4.10.4
	 *
	 * @var string
	 */
	private const KEY = 'setup_wizard_continue';

	/**
	 * Register hooks.
	 *
	 * @since 4.10.4
	 *
	 * @return void
	 */
	public function hooks() {

		add_action( 'admin_init', [ $this, 'maybe_add_notice' ] );
		add_filter( 'wp_mail_smtp_admin_process_ajax_data', [ $this, 'maybe_forget_on_dismiss' ], 10, 2 );
	}

	/**
	 * Queue the notice while a step is stored.
	 *
	 * @since 4.10.4
	 *
	 * @return void
	 */
	public function maybe_add_notice() {

		if ( ! current_user_can( wp_mail_smtp()->get_capability_manage_global_options() ) ) {
			return;
		}

		$upgrade_return = new UpgradeReturn();
		$step           = $upgrade_return->get_step();

		if ( empty( $step ) ) {
			return;
		}

		WP::add_admin_notice(
			sprintf(
				'%1$s</p><p><a href="%2$s" class="button button-primary">%3$s</a>',
				esc_html__( 'WP Mail SMTP Pro is active. Continue your setup where you left off.', 'wp-mail-smtp-pro' ),
				esc_url( $upgrade_return->get_url( $upgrade_return->get_valid_step( $step ), $upgrade_return->get_variant() ) ),
				esc_html__( 'Continue Setup', 'wp-mail-smtp-pro' )
			),
			WP::ADMIN_NOTICE_INFO,
			true,
			self::KEY
		);
	}

	/**
	 * Forget the step when the notice is dismissed.
	 *
	 * @since 4.10.4
	 *
	 * @param array  $data AJAX response data.
	 * @param string $task AJAX task.
	 *
	 * @return array
	 */
	public function maybe_forget_on_dismiss( $data, $task ) {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified in Area::process_ajax().
		if ( $task !== 'notice_dismiss' || empty( $_POST['notice'] ) || sanitize_key( $_POST['notice'] ) !== self::KEY ) {
			return $data;
		}

		if ( ! current_user_can( wp_mail_smtp()->get_capability_manage_global_options() ) ) {
			return $data;
		}

		( new UpgradeReturn() )->forget();

		// The shared dismissal hides this notice for good; a later upgrade must show it again.
		delete_user_meta( get_current_user_id(), 'wp_mail_smtp_notice_' . self::KEY . '_dismissed' );

		return $data;
	}
}
