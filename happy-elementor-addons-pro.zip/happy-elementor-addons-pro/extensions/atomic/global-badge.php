<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Base\Atomic_Control_Base;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Image_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Toggle_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Dimensions_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Font_Family_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * Dual From/To slider (the Classic range slider) bound to a "from,to" text.
 * Rendered by the "ha-range" control of the Pro editor script.
 */
class Badge_Range_Control extends Atomic_Control_Base {

	private $range = [ 'min' => 0, 'max' => 100, 'step' => 1 ];

	public function get_type(): string {
		return 'ha-range';
	}

	public function set_range( $min, $max, $step ) {
		$this->range = [ 'min' => $min, 'max' => $max, 'step' => $step ];

		return $this;
	}

	public function get_props(): array {
		return $this->range;
	}
}

/**
 * The Elementor font family list (system and Google fonts), the same control
 * as the native Typography section. Rendered by "ha-font-family".
 */
class Badge_Font_Family_Control extends Atomic_Control_Base {

	public function get_type(): string {
		return 'ha-font-family';
	}

	public function get_props(): array {
		return [];
	}
}

/**
 * The native Atomic Margin / Padding control: four linked sizes with units.
 * Rendered by "ha-dimensions".
 */
class Badge_Dimensions_Control extends Atomic_Control_Base {

	public function get_type(): string {
		return 'ha-dimensions';
	}

	public function get_props(): array {
		return [];
	}
}

/**
 * Searchable Font Awesome icon picker, like the Classic icon control.
 * Rendered by the "ha-icon-picker" control of the Pro editor script.
 */
class Badge_Icon_Picker_Control extends Atomic_Control_Base {

	public function get_type(): string {
		return 'ha-icon-picker';
	}

	public function get_props(): array {
		return [ 'icons' => Global_Badge::icon_list() ];
	}
}

/**
 * Global Badge for the Atomic containers (e-flexbox, e-div-block, e-grid) and
 * the Atomic elements that can hold the badge (heading, paragraph, button).
 *
 * Same settings and behaviour as the Classic Global Badge extension: a badge
 * (Stripe, Flag, Triangle, Circle, Bookmark or a Custom Layout) with a text and
 * an icon, image or Lottie animation, its layout and style, and the floating
 * effects. Atomic settings are single valued (not per-breakpoint), so the
 * Classic responsive variants collapse into one value each, and the Classic
 * selectors become inline styles / custom properties set by the runtime.
 */
class Global_Badge extends Atomic_Feature_Base {

	/** Fields that stay empty (not 0) until a value is typed. */
	private $optional = [];

	protected function prefix() {
		return 'ha_agb_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid', 'e-heading', 'e-paragraph', 'e-button' ];
	}

	protected function feature_key() {
		return 'global-badge';
	}

	protected function section_label() {
		return __( 'Global Badge', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		if ( ! isset( $schema['classes'], $schema['link'] ) ) {
			return false;
		}

		// A container, or one of the elements listed in target_types().
		return isset( $schema['tag'] ) && ! isset( $schema['image'] ) && ! isset( $schema['svg'] );
	}

	public function init() {
		parent::init();

		add_action( 'elementor/preview/enqueue_styles', [ $this, 'enqueue_icon_fonts' ] );
		add_action( 'elementor/preview/enqueue_scripts', [ $this, 'enqueue_lottie' ] );
	}

	/**
	 * Font Awesome of the "Icon" type (Elementor registers them).
	 */
	public function enqueue_icon_fonts() {
		foreach ( [ 'elementor-icons-fa-solid', 'elementor-icons-fa-regular', 'elementor-icons-fa-brands' ] as $handle ) {
			if ( wp_style_is( $handle, 'registered' ) ) {
				wp_enqueue_style( $handle );
			}
		}
	}

	public function enqueue_lottie() {
		$this->register_lottie();
		wp_enqueue_script( 'lottie-js' );
	}

	private function register_lottie() {
		if ( ! wp_script_is( 'lottie-js', 'registered' ) ) {
			wp_register_script( 'lottie-js', HAPPY_ADDONS_PRO_ASSETS . 'vendor/lottie/lottie.min.js', null, HAPPY_ADDONS_PRO_VERSION, true );
		}
	}

	public function before_render( $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) ) {
			return;
		}

		if ( ! in_array( $element::get_element_type(), $this->target_types(), true ) ) {
			return;
		}

		$settings = $element->get_atomic_settings();

		if ( empty( $settings[ $this->prefix() . 'switcher' ] ) ) {
			return;
		}

		if ( 'icon' === ( $settings[ $this->prefix() . 'icon_type' ] ?? '' ) ) {
			$this->enqueue_icon_fonts();
		}

		if ( 'lottie' === ( $settings[ $this->prefix() . 'icon_type' ] ?? '' ) ) {
			$this->enqueue_lottie();
		}

		$family = trim( (string) ( $settings[ $this->prefix() . 'typo_font_family' ] ?? '' ), " \t\n\r\0\x0B\"'" );

		if ( '' !== $family && class_exists( '\Elementor\Plugin' ) ) {
			\Elementor\Plugin::$instance->frontend->enqueue_font( $family );
		}

		// The sizes are read as stored: Elementor's renderer would flatten them.
		$this->raw_sizes = [
			'padding' => $element->get_settings( $this->prefix() . 'padding' ),
			'margin'  => $element->get_settings( $this->prefix() . 'margin' ),
		];

		parent::before_render( $element );

		$this->raw_sizes = [];
	}

	/** Raw Margin / Padding of the element being rendered. */
	private $raw_sizes = [];

	private static function unwrap( $value ) {
		while ( is_array( $value ) && array_key_exists( '$$type', $value ) ) {
			$value = $value['value'] ?? null;
		}

		return $value;
	}

	/**
	 * A stored size ({ size, unit }) as CSS, or ''.
	 */
	private static function size_css( $size ) {
		$size = self::unwrap( $size );

		if ( ! is_array( $size ) || ! isset( $size['size'] ) || '' === $size['size'] ) {
			return '';
		}

		$unit = (string) ( $size['unit'] ?? 'px' );

		if ( 'auto' === $unit ) {
			return 'auto';
		}

		if ( ! in_array( $unit, [ 'px', '%', 'em', 'rem', 'vw', 'vh' ], true ) || ! is_numeric( $size['size'] ) ) {
			return '';
		}

		return (float) $size['size'] . $unit;
	}

	/**
	 * The four sides of a stored Margin / Padding (one size, or a size per side) as CSS.
	 */
	private static function sides( $raw ) {
		$value = self::unwrap( $raw );

		if ( ! is_array( $value ) ) {
			return null;
		}

		if ( isset( $value['size'] ) ) {
			$one = self::size_css( $value );

			return [ 'top' => $one, 'right' => $one, 'bottom' => $one, 'left' => $one ];
		}

		return [
			'top'    => self::size_css( $value['block-start'] ?? null ),
			'right'  => self::size_css( $value['inline-end'] ?? null ),
			'bottom' => self::size_css( $value['block-end'] ?? null ),
			'left'   => self::size_css( $value['inline-start'] ?? null ),
		];
	}

	/**
	 * Font Awesome icons of Elementor ("fas fa-ribbon"...), as picker options.
	 *
	 * @return array[]
	 */
	public static function icon_list() {
		static $list = null;

		if ( null !== $list ) {
			return $list;
		}

		$list = [];

		foreach ( [ 'solid' => 'fas', 'regular' => 'far', 'brands' => 'fab' ] as $file => $prefix ) {
			$path = ELEMENTOR_ASSETS_PATH . 'lib/font-awesome/json/' . $file . '.json';
			$data = is_readable( $path ) ? json_decode( (string) file_get_contents( $path ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

			foreach ( array_keys( $data['icons'] ?? [] ) as $name ) {
				$list[] = [
					'value' => $prefix . ' fa-' . $name,
					'label' => $name . ' (' . ucfirst( $file ) . ')',
				];
			}
		}

		return $list;
	}

	private static function types() {
		return [
			'stripe'   => __( 'Stripe', 'happy-addons-pro' ),
			'flag'     => __( 'Flag', 'happy-addons-pro' ),
			'tri'      => __( 'Triangle', 'happy-addons-pro' ),
			'circle'   => __( 'Circle', 'happy-addons-pro' ),
			'bookmark' => __( 'Bookmark', 'happy-addons-pro' ),
			'custom'   => __( 'Custom Layout', 'happy-addons-pro' ),
		];
	}

	protected function fields() {
		$on      = [ 'switcher' => true ];
		$icon    = $on + [ 'icon_type' => [ 'icon', 'image', 'lottie' ] ];
		$effects = $on + [ 'effects' => true ];
		$moving  = [ 'flag', 'tri', 'circle', 'bookmark', 'custom' ];
		$fields  = [];

		// A number that stays empty until a value is typed.
		$opt = function ( $label, array $show = [], array $extra = [] ) {
			return [
				'type'     => 'number',
				'default'  => null,
				'optional' => true,
				'label'    => $label,
				'show'     => $show,
			] + $extra;
		};

		$fields['switcher'] = [
			'type'    => 'bool',
			'default' => false,
			'label'   => __( 'Enable Global Badge', 'happy-addons-pro' ),
		];
		$fields['text']     = [
			'type'    => 'string',
			'default' => 'New',
			'label'   => __( 'Text', 'happy-addons-pro' ),
			'show'    => $on,
		];
		$fields['type']      = [
			'type'    => 'enum',
			'default' => 'stripe',
			'label'   => __( 'Style', 'happy-addons-pro' ),
			'options' => self::types(),
			'show'    => $on,
		];
		$fields['icon_type'] = [
			'type'    => 'enum',
			'default' => 'none',
			'label'   => __( 'Icon Type', 'happy-addons-pro' ),
			'options' => [
				'none'   => __( 'None', 'happy-addons-pro' ),
				'icon'   => __( 'Icon', 'happy-addons-pro' ),
				'image'  => __( 'Image', 'happy-addons-pro' ),
				'lottie' => __( 'Lottie', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];
		$fields['icon']      = [
			'type'        => 'string',
			'default'     => 'fas fa-ribbon',
			'label'       => __( 'Choose Icon', 'happy-addons-pro' ),
			'description' => __( 'A Font Awesome class, e.g. fas fa-ribbon, far fa-star or fab fa-wordpress.', 'happy-addons-pro' ),
			'show'        => $on + [ 'icon_type' => 'icon' ],
		];
		// "img" (Choose Image) is an extra prop, see extra_props().
		$fields['lottie_url'] = [
			'type'        => 'string',
			'default'     => 'https://assets4.lottiefiles.com/private_files/lf30_ujs3c7ok.json',
			'label'       => __( 'Animation JSON URL', 'happy-addons-pro' ),
			'description' => __( 'Get the JSON code URL from lottiefiles.com.', 'happy-addons-pro' ),
			'show'        => $on + [ 'icon_type' => 'lottie' ],
		];
		$fields['loop']       = [
			'type'    => 'bool',
			'default' => true,
			'label'   => __( 'Loop', 'happy-addons-pro' ),
			'show'    => $on + [ 'icon_type' => 'lottie' ],
		];
		$fields['clip_enabled'] = [
			'type'    => 'bool',
			'default' => false,
			'label'   => __( 'Enable Clip Path', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => 'custom' ],
		];
		$fields['path']         = [
			'type'        => 'string',
			'default'     => '',
			'label'       => __( 'Path Value', 'happy-addons-pro' ),
			'description' => __( 'Paste your Path code here. EX: polygon(50% 0%, 0% 10%, 100% 100%). Get it from bennettfeely.com/clippy.', 'happy-addons-pro' ),
			'show'        => $on + [ 'type' => 'custom', 'clip_enabled' => true ],
		];

		/* Effects */
		$fields['effects'] = [
			'type'    => 'bool',
			'default' => false,
			'label'   => __( 'Effects', 'happy-addons-pro' ),
			'show'    => $on,
		];

		// One From/To range, like the Classic dual slider: kept as "from,to".
		$range = function ( $key, $label, $from, $to, $min, $max, $step, array $toggle_show ) use ( &$fields ) {
			$fields[ $key ] = [
				'type'    => 'range',
				'default' => $from . ',' . $to,
				'min'     => $min,
				'max'     => $max,
				'step'    => $step,
				'label'   => $label,
				'show'    => $toggle_show,
			];
		};

		$effect = function ( $name, $label, array $type_show, array $values, $speed_key ) use ( &$fields, $effects, $range ) {
			$toggle_key = 'efct_' . $name . '_toggle';
			$fields[ $toggle_key ] = [
				'type'    => 'bool',
				'default' => false,
				'label'   => $label,
				'show'    => $effects + $type_show,
			];

			$show = [ $toggle_key => true ] + $effects + $type_show;

			foreach ( $values as $value ) {
				$range( $value[0], $value[1], $value[2], $value[3], $value[4], $value[5], $value[6], $show );
			}

			$fields[ $speed_key ] = [
				'type'    => 'slider',
				'default' => 1,
				'min'     => 0,
				'max'     => 10,
				'step'    => 0.1,
				'label'   => __( 'Speed', 'happy-addons-pro' ),
				'show'    => $show,
			];
		};

		$not_stripe = [ 'type' => $moving ];

		$effect( 'translate', __( 'Translate', 'happy-addons-pro' ), $not_stripe, [
			[ 'efct_translatex', __( 'Translate X', 'happy-addons-pro' ), -5, 5, -100, 100, 1 ],
			[ 'efct_translatey', __( 'Translate Y', 'happy-addons-pro' ), -5, 5, -100, 100, 1 ],
		], 'efct_translate_speed' );

		$effect( 'rotate', __( 'Rotate', 'happy-addons-pro' ), $not_stripe, [
			[ 'efct_rotatex', __( 'Rotate X', 'happy-addons-pro' ), 0, 45, -180, 180, 1 ],
			[ 'efct_rotatey', __( 'Rotate Y', 'happy-addons-pro' ), 0, 45, -180, 180, 1 ],
			[ 'efct_rotatez', __( 'Rotate Z', 'happy-addons-pro' ), 0, 45, -180, 180, 1 ],
		], 'efct_rotate_speed' );

		$effect( 'scale', __( 'Scale', 'happy-addons-pro' ), $not_stripe, [
			[ 'efct_scalex', __( 'Scale X', 'happy-addons-pro' ), 1, 1.2, 0, 5, 0.1 ],
			[ 'efct_scaley', __( 'Scale Y', 'happy-addons-pro' ), 1, 1.2, 0, 5, 0.1 ],
		], 'efct_scale_speed' );

		$effect( 'opacity', __( 'Opacity', 'happy-addons-pro' ), [], [
			[ 'efct_opacity', __( 'Opacity', 'happy-addons-pro' ), 0, 50, 0, 100, 1 ],
		], 'efct_opacity_speed' );

		$effect( 'blur', __( 'Blur', 'happy-addons-pro' ), [], [
			[ 'efct_blur', __( 'Blur', 'happy-addons-pro' ), 0, 1, 0, 3, 0.1 ],
		], 'efct_blur_speed' );

		$effect( 'grayscale', __( 'Grayscale', 'happy-addons-pro' ), [], [
			[ 'efct_gscale', __( 'Grayscale', 'happy-addons-pro' ), 0, 50, 0, 100, 1 ],
		], 'efct_gscale_speed' );

		$fields['disable_on_safari'] = [
			'type'    => 'bool',
			'default' => false,
			'label'   => __( 'Disable Effects On Safari', 'happy-addons-pro' ),
			'show'    => $effects,
		];

		/* Style & Layout tabs */
		$fields['tab'] = [
			'type'    => 'enum',
			'default' => 'layout',
			'label'   => __( 'Style & Layout', 'happy-addons-pro' ),
			'options' => [
				'layout' => __( 'Layout', 'happy-addons-pro' ),
				'style'  => __( 'Style', 'happy-addons-pro' ),
				'icon'   => __( 'Icon', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];

		/* Layout */
		$fields['display'] = [
			'type'    => 'enum',
			'default' => 'row',
			'label'   => __( 'Display', 'happy-addons-pro' ),
			'options' => [
				'row'    => __( 'Inline', 'happy-addons-pro' ),
				'column' => __( 'Block', 'happy-addons-pro' ),
			],
			'icons'   => [
				'row'    => 'DotsHorizontalIcon',
				'column' => 'DotsVerticalIcon',
			],
			'show'    => $icon,
		];
		$fields['hor']     = [
			'type'    => 'enum',
			'default' => 'right',
			'label'   => __( 'Horizontal Position', 'happy-addons-pro' ),
			'options' => [
				'left'  => __( 'Left', 'happy-addons-pro' ),
				'right' => __( 'Right', 'happy-addons-pro' ),
			],
			'icons'   => [
				'left'  => 'LayoutAlignLeftIcon',
				'right' => 'LayoutAlignRightIcon',
			],
			'show'    => $on,
		];
		$fields['ver']     = [
			'type'    => 'enum',
			'default' => 'top',
			'label'   => __( 'Vertical Position', 'happy-addons-pro' ),
			'options' => [
				'top'    => __( 'Top', 'happy-addons-pro' ),
				'bottom' => __( 'Bottom', 'happy-addons-pro' ),
			],
			'icons'   => [
				'top'    => 'LayoutNavbarIcon',
				'bottom' => 'LayoutBottombarIcon',
			],
			'show'    => $on + [ 'type' => [ 'custom', 'circle' ] ],
		];
		$fields['rotate']  = [
			'type'    => 'number',
			'default' => 0,
			'min'     => -180,
			'max'     => 180,
			'step'    => 1,
			'label'   => __( 'Rotate (deg)', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => 'custom' ],
			'hide_when' => [ 'efct_translate_toggle' => true, 'efct_rotate_toggle' => true, 'efct_scale_toggle' => true ],
		];
		$fields['zindex'] = $opt( __( 'Z-Index', 'happy-addons-pro' ), $on, [
			'step'        => 1,
			'description' => __( 'Default is 5', 'happy-addons-pro' ),
		] );

		/* Style */
		$fields['hor_offset'] = $opt( __( 'Horizontal Offset (px)', 'happy-addons-pro' ), $on + [ 'type' => [ 'stripe', 'tri', 'circle', 'bookmark', 'custom' ] ], [ 'min' => 0, 'max' => 200 ] );
		$fields['ver_offset'] = $opt( __( 'Vertical Offset (px)', 'happy-addons-pro' ), $on + [ 'type' => [ 'stripe', 'flag', 'tri', 'circle', 'custom' ] ], [ 'min' => 0, 'max' => 200 ] );
		$fields['spacing']    = $opt( __( 'Spacing (px)', 'happy-addons-pro' ), $icon, [ 'min' => 0, 'max' => 100 ] );
		$fields['size']       = $opt( __( 'Box Size (px)', 'happy-addons-pro' ), $on + [ 'type' => [ 'tri', 'custom' ] ], [ 'min' => 0, 'max' => 200 ] );
		$fields['color']      = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Text Color', 'happy-addons-pro' ),
			'show'    => $on,
		];

		$bg_types = [ 'stripe', 'circle', 'custom' ];

		$fields['bg_type']   = [
			'type'    => 'enum',
			'default' => 'classic',
			'label'   => __( 'Background Type', 'happy-addons-pro' ),
			'options' => [
				'classic'  => __( 'Classic', 'happy-addons-pro' ),
				'gradient' => __( 'Gradient', 'happy-addons-pro' ),
			],
			'show'    => $on + [ 'type' => $bg_types ],
		];
		$fields['bg_color']  = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Color', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => $bg_types ],
		];
		$fields['bg_color_b'] = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Second Color', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => $bg_types, 'bg_type' => 'gradient' ],
		];
		$fields['bg_angle']   = [
			'type'    => 'number',
			'default' => 180,
			'min'     => 0,
			'max'     => 360,
			'step'    => 1,
			'label'   => __( 'Angle (deg)', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => $bg_types, 'bg_type' => 'gradient' ],
		];
		$fields['bgcolor']    = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Background Color', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => [ 'bookmark', 'tri', 'flag' ] ],
		];

		$fields['ts_color'] = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Text Shadow Color', 'happy-addons-pro' ),
			'show'    => $on,
		];
		foreach ( [ 'ts_x' => __( 'Text Shadow Horizontal (px)', 'happy-addons-pro' ), 'ts_y' => __( 'Text Shadow Vertical (px)', 'happy-addons-pro' ), 'ts_blur' => __( 'Text Shadow Blur (px)', 'happy-addons-pro' ) ] as $key => $label ) {
			$fields[ $key ] = [
				'type'    => 'number',
				'default' => 0,
				'min'     => -100,
				'max'     => 100,
				'step'    => 1,
				'label'   => $label,
				'show'    => $on,
			];
		}

		$shadow = $on + [ 'type' => [ 'stripe', 'flag', 'circle', 'bookmark', 'custom' ] ];

		$fields['bs_color'] = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Box Shadow Color', 'happy-addons-pro' ),
			'show'    => $shadow,
		];
		foreach ( [ 'bs_x' => __( 'Box Shadow Horizontal (px)', 'happy-addons-pro' ), 'bs_y' => __( 'Box Shadow Vertical (px)', 'happy-addons-pro' ), 'bs_blur' => __( 'Box Shadow Blur (px)', 'happy-addons-pro' ), 'bs_spread' => __( 'Box Shadow Spread (px)', 'happy-addons-pro' ) ] as $key => $label ) {
			$fields[ $key ] = [
				'type'    => 'number',
				'default' => 0,
				'min'     => -100,
				'max'     => 100,
				'step'    => 1,
				'label'   => $label,
				'show'    => $shadow,
			];
		}
		$fields['bs_position'] = [
			'type'    => 'enum',
			'default' => 'outline',
			'label'   => __( 'Box Shadow Position', 'happy-addons-pro' ),
			'options' => [
				'outline' => __( 'Outline', 'happy-addons-pro' ),
				'inset'   => __( 'Inset', 'happy-addons-pro' ),
			],
			'show'    => $shadow,
		];

		/* Typography */
		$fields['typo_font_family'] = [
			'type'    => 'string',
			'default' => '',
			'label'   => __( 'Font Family', 'happy-addons-pro' ),
			'show'    => $on,
		];
		$fields['typo_font_size']   = $opt( __( 'Font Size (px)', 'happy-addons-pro' ), $on, [ 'min' => 0, 'max' => 200 ] );
		$fields['typo_font_weight'] = [
			'type'    => 'enum',
			'default' => '',
			'label'   => __( 'Font Weight', 'happy-addons-pro' ),
			'options' => [
				''       => __( 'Default', 'happy-addons-pro' ),
				'100'    => '100',
				'200'    => '200',
				'300'    => '300',
				'400'    => '400',
				'500'    => '500',
				'600'    => '600',
				'700'    => '700',
				'800'    => '800',
				'900'    => '900',
				'normal' => __( 'Normal', 'happy-addons-pro' ),
				'bold'   => __( 'Bold', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];
		$fields['typo_text_transform'] = [
			'type'    => 'enum',
			'default' => '',
			'label'   => __( 'Transform', 'happy-addons-pro' ),
			'options' => [
				''           => __( 'Default', 'happy-addons-pro' ),
				'uppercase'  => __( 'Uppercase', 'happy-addons-pro' ),
				'lowercase'  => __( 'Lowercase', 'happy-addons-pro' ),
				'capitalize' => __( 'Capitalize', 'happy-addons-pro' ),
				'none'       => __( 'Normal', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];
		$fields['typo_font_style'] = [
			'type'    => 'enum',
			'default' => '',
			'label'   => __( 'Style', 'happy-addons-pro' ),
			'options' => [
				''       => __( 'Default', 'happy-addons-pro' ),
				'normal' => __( 'Normal', 'happy-addons-pro' ),
				'italic' => __( 'Italic', 'happy-addons-pro' ),
				'oblique' => __( 'Oblique', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];
		$fields['typo_text_decoration'] = [
			'type'    => 'enum',
			'default' => '',
			'label'   => __( 'Decoration', 'happy-addons-pro' ),
			'options' => [
				''             => __( 'Default', 'happy-addons-pro' ),
				'underline'    => __( 'Underline', 'happy-addons-pro' ),
				'overline'     => __( 'Overline', 'happy-addons-pro' ),
				'line-through' => __( 'Line Through', 'happy-addons-pro' ),
				'none'         => __( 'None', 'happy-addons-pro' ),
			],
			'show'    => $on,
		];
		$fields['typo_line_height']    = $opt( __( 'Line Height (em)', 'happy-addons-pro' ), $on, [
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.1,
			'description' => __( 'Use Line Height to control the height of the Bookmark.', 'happy-addons-pro' ),
		] );
		$fields['typo_letter_spacing'] = $opt( __( 'Letter Spacing (px)', 'happy-addons-pro' ), $on, [ 'min' => -10, 'max' => 50, 'step' => 0.1 ] );

		/* Border */
		$bordered = $on + [ 'type' => [ 'circle', 'custom' ], 'clip_enabled' => false ];

		$fields['border_style'] = [
			'type'    => 'enum',
			'default' => '',
			'label'   => __( 'Border Type', 'happy-addons-pro' ),
			'options' => [
				''       => __( 'None', 'happy-addons-pro' ),
				'solid'  => __( 'Solid', 'happy-addons-pro' ),
				'double' => __( 'Double', 'happy-addons-pro' ),
				'dotted' => __( 'Dotted', 'happy-addons-pro' ),
				'dashed' => __( 'Dashed', 'happy-addons-pro' ),
				'groove' => __( 'Groove', 'happy-addons-pro' ),
			],
			'show'    => $bordered,
		];
		$fields['border_width'] = $opt( __( 'Border Width (px)', 'happy-addons-pro' ), $bordered, [ 'min' => 0, 'max' => 50 ] );
		$fields['border_color'] = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Border Color', 'happy-addons-pro' ),
			'show'    => $bordered,
		];
		$fields['border_rad']   = $opt( __( 'Border Radius (px)', 'happy-addons-pro' ), $on + [ 'type' => [ 'flag', 'circle', 'custom' ], 'clip_enabled' => false ], [ 'min' => 0, 'max' => 500 ] );

		foreach ( [ 'top' => __( 'Top', 'happy-addons-pro' ), 'right' => __( 'Right', 'happy-addons-pro' ), 'bottom' => __( 'Bottom', 'happy-addons-pro' ), 'left' => __( 'Left', 'happy-addons-pro' ) ] as $side => $label ) {
			/* translators: %s: side, e.g. Top */
			$fields[ 'border_rad2_' . $side ] = $opt( sprintf( __( 'Border Radius %s (px)', 'happy-addons-pro' ), $label ), $on + [ 'type' => 'custom', 'clip_enabled' => false ], [ 'min' => 0, 'max' => 500 ] );
		}

		$fields['padding'] = [
			'type'    => 'dimensions',
			'default' => null,
			'label'   => __( 'Padding', 'happy-addons-pro' ),
			'show'    => $on + [ 'type' => [ 'stripe', 'flag', 'circle', 'custom' ] ],
		];
		$fields['margin']  = [
			'type'    => 'dimensions',
			'default' => null,
			'label'   => __( 'Margin', 'happy-addons-pro' ),
			'show'    => $on,
		];

		foreach ( [ 'top' => __( 'Top', 'happy-addons-pro' ), 'bottom' => __( 'Bottom', 'happy-addons-pro' ) ] as $side => $label ) {
			/* translators: %s: side, e.g. Top */
			$fields[ 'padding_bookmark_' . $side ] = $opt( sprintf( __( 'Padding %s (px)', 'happy-addons-pro' ), $label ), $on + [ 'type' => 'bookmark' ], [ 'min' => 0, 'max' => 200 ] );
		}

		/* Icon style */
		$fields['icon_color'] = [
			'type'    => 'color',
			'default' => '',
			'label'   => __( 'Icon Color', 'happy-addons-pro' ),
			'show'    => $on + [ 'icon_type' => 'icon' ],
		];
		$fields['icon_size']  = $opt( __( 'Icon Size (px)', 'happy-addons-pro' ), $icon, [ 'min' => 0, 'max' => 500 ] );
		$fields['icon_rad']   = $opt( __( 'Icon Border Radius (px)', 'happy-addons-pro' ), $on + [ 'icon_type' => 'image' ], [ 'min' => 0, 'max' => 500 ] );

		// The Layout / Style / Icon tabs: from "display" on, each field shows on its own tab.
		$tab = '';

		foreach ( array_keys( $fields ) as $key ) {
			$tab = [ 'display' => 'layout', 'hor_offset' => 'style', 'icon_color' => 'icon' ][ $key ] ?? $tab;

			if ( '' !== $tab ) {
				$fields[ $key ]['show']['tab'] = $tab;
			}
		}

		// Remember which numbers stay empty (see add_props()).
		$this->optional = array_keys( array_filter( $fields, function ( $field ) {
			return ! empty( $field['optional'] );
		} ) );

		return $fields;
	}

	/**
	 * The Choose Image prop, shown for the Image icon type.
	 */
	protected function extra_props() {
		$image = Image_Prop_Type::make();

		$image->set_dependencies(
			Dependency_Manager::make( Dependency_Manager::RELATION_AND )
				->where( [
					'operator' => 'eq',
					'path'     => [ $this->prefix() . 'switcher' ],
					'value'    => true,
					'effect'   => 'hide',
				] )
				->where( [
					'operator' => 'eq',
					'path'     => [ $this->prefix() . 'icon_type' ],
					'value'    => 'image',
					'effect'   => 'hide',
				] )
				->get()
		);

		return [ $this->prefix() . 'img' => $image ];
	}

	protected function extra_controls() {
		return [
			'icon' => Image_Control::bind_to( $this->prefix() . 'img' )->set_label( __( 'Choose Image', 'happy-addons-pro' ) ),
		];
	}

	/**
	 * Numbers that stay empty until a value is typed carry no default.
	 */
	public function add_props( $schema ) {
		$schema = parent::add_props( $schema );

		if ( ! is_array( $schema ) || ! isset( $schema[ $this->prefix() . 'switcher' ] ) ) {
			return $schema;
		}

		$fields = $this->fields();

		foreach ( $this->optional as $key ) {
			$prop = $this->prefix() . $key;

			if ( ! isset( $schema[ $prop ] ) ) {
				continue;
			}

			$schema[ $prop ] = Number_Prop_Type::make()->float();
		}

		// The native Margin / Padding prop: one size, or four.
		foreach ( [ 'padding', 'margin' ] as $key ) {
			if ( isset( $schema[ $this->prefix() . $key ] ) ) {
				$schema[ $this->prefix() . $key ] = Union_Prop_Type::create_from( Size_Prop_Type::make() )->add_prop_type( Dimensions_Prop_Type::make() );
			}
		}

		// The native Typography font family prop (it loads Google fonts).
		if ( isset( $schema[ $this->prefix() . 'typo_font_family' ] ) ) {
			// A plain text value (saved before the native prop was used) stays valid.
			$schema[ $this->prefix() . 'typo_font_family' ] = Union_Prop_Type::create_from( Font_Family_Prop_Type::make() )
				->add_prop_type( String_Prop_Type::make() )
				->default( [ '$$type' => 'font-family', 'value' => '' ] );
		}

		// Every dependency is rebuilt: a setting that was never touched is not
		// stored, so a test on its default value must not need it stored.
		foreach ( $fields as $key => $field ) {
			$prop = $this->prefix() . $key;

			if ( empty( $field['show'] ) || ! isset( $schema[ $prop ] ) ) {
				continue;
			}

			$schema[ $prop ]->set_dependencies( $this->show_dependencies( $field['show'], $field['hide_when'] ?? [], $fields ) );
		}

		return $schema;
	}

	/**
	 * The tabs, the From/To ranges and the icon picker replace the plain
	 * controls of their fields.
	 */
	public function add_controls( $controls, $element ) {
		$controls = parent::add_controls( $controls, $element );

		if ( ! is_array( $controls ) ) {
			return $controls;
		}

		$fields = $this->fields();

		foreach ( $controls as $section ) {
			if ( ! $section instanceof Section || $this->prefix() . 'section' !== $section->get_id() ) {
				continue;
			}

			$items = $section->get_items();

			foreach ( $items as $index => $item ) {
				if ( ! is_object( $item ) || ! method_exists( $item, 'get_bind' ) ) {
					continue;
				}

				$key = substr( (string) $item->get_bind(), strlen( $this->prefix() ) );

				if ( ! isset( $fields[ $key ] ) ) {
					continue;
				}

				$field = $fields[ $key ];

				if ( 'tab' === $key ) {
					$options = [];

					foreach ( $field['options'] as $value => $label ) {
						$options[ $value ] = [ 'title' => $label ];
					}

					$items[ $index ] = Toggle_Control::bind_to( $this->prefix() . $key )
						->set_label( $field['label'] )
						->add_options( $options )
						->set_exclusive( true )
						->set_convert_options( true )
						->set_full_width( true )
						->set_size( 'tiny' );
				} elseif ( 'range' === $field['type'] ) {
					$items[ $index ] = Badge_Range_Control::bind_to( $this->prefix() . $key )
						->set_label( $field['label'] )
						->set_range( $field['min'], $field['max'], $field['step'] );
				} elseif ( 'dimensions' === $field['type'] ) {
					$items[ $index ] = Badge_Dimensions_Control::bind_to( $this->prefix() . $key )
						->set_label( $field['label'] );
				} elseif ( 'typo_font_family' === $key ) {
					$items[ $index ] = Badge_Font_Family_Control::bind_to( $this->prefix() . $key )
						->set_label( $field['label'] );
				} elseif ( 'icon' === $key ) {
					$items[ $index ] = Badge_Icon_Picker_Control::bind_to( $this->prefix() . $key )
						->set_label( $field['label'] );
				}
			}

			$section->set_items( $items );
		}

		return $controls;
	}

	/**
	 * Dependencies of a field: it shows while every "show" test holds and no
	 * "hide_when" switch is on. A test on a value that is the setting's default
	 * is written as "none of the other values" and "off" as "not on", because an
	 * untouched setting is not stored (it reads as empty, not as its default).
	 */
	private function show_dependencies( array $show, array $hide_when, array $fields ) {
		$manager = Dependency_Manager::make( Dependency_Manager::RELATION_AND );
		$add     = function ( $operator, $key, $value ) use ( $manager ) {
			$manager->where( [
				'operator' => $operator,
				'path'     => [ $this->prefix() . $key ],
				'value'    => $value,
				'effect'   => 'hide',
			] );
		};

		foreach ( $show as $key => $value ) {
			$default = $fields[ $key ]['default'] ?? null;
			$options = array_map( 'strval', array_keys( $fields[ $key ]['options'] ?? [] ) );

			if ( false === $value ) {
				$add( 'ne', $key, true );
			} elseif ( $options && in_array( (string) $default, array_map( 'strval', (array) $value ), true ) ) {
				$add( 'nin', $key, array_values( array_diff( $options, array_map( 'strval', (array) $value ) ) ) );
			} else {
				$add( is_array( $value ) ? 'in' : 'eq', $key, $value );
			}
		}

		foreach ( $hide_when as $key => $value ) {
			$add( 'ne', $key, $value );
		}

		return $manager->get();
	}

	/**
	 * The editor preview reads the settings from the editor; it needs the
	 * image key to carry them over.
	 */
	public function defaults() {
		return parent::defaults() + [ 'img' => null ];
	}

	/**
	 * Settings plus the image URL (the runtime gets a URL, not image props).
	 */
	protected function sanitize_config( array $settings ) {
		$config = parent::sanitize_config( $settings );

		// Empty numbers stay empty.
		foreach ( $this->optional as $key ) {
			$value = $settings[ $this->prefix() . $key ] ?? null;

			if ( null === $value || '' === $value ) {
				$config[ $key ] = null;
			}
		}

		// The "from,to" ranges become two numbers each.
		foreach ( $this->fields() as $key => $field ) {
			if ( 'range' !== $field['type'] ) {
				continue;
			}

			$parts = array_map( 'floatval', explode( ',', (string) ( $config[ $key ] ?? $field['default'] ) ) + [ 0, 0 ] );

			$config[ $key . '_from' ] = max( $field['min'], min( $field['max'], $parts[0] ) );
			$config[ $key . '_to' ]   = max( $field['min'], min( $field['max'], $parts[1] ) );
			unset( $config[ $key ] );
		}

		$config['padding'] = self::sides( $this->raw_sizes['padding'] ?? null );
		$config['margin']  = self::sides( $this->raw_sizes['margin'] ?? null );
		$config['text']    = sanitize_text_field( (string) ( $settings[ $this->prefix() . 'text' ] ?? '' ) );
		$config['path'] = preg_replace( '/[^a-z0-9%.,\s()\-+]/i', '', (string) ( $settings[ $this->prefix() . 'path' ] ?? '' ) );
		$config['rtl']  = is_rtl();

		$lottie = esc_url_raw( (string) ( $settings[ $this->prefix() . 'lottie_url' ] ?? '' ) );

		$config['lottie_url'] = $lottie;
		$config['icon']       = preg_replace( '/[^a-z0-9\s_-]/i', '', (string) ( $settings[ $this->prefix() . 'icon' ] ?? '' ) );
		$config['img']        = '';
		$config['img_alt']    = '';

		$image = $settings[ $this->prefix() . 'img' ] ?? null;
		$src   = is_array( $image ) ? ( $image['src'] ?? '' ) : '';
		$id    = 0;

		if ( is_array( $src ) ) {
			$id  = (int) ( $src['id'] ?? 0 );
			$src = $src['url'] ?? '';
		}

		if ( '' === (string) $src && $id ) {
			$src = wp_get_attachment_url( $id );
		}

		$config['img'] = esc_url_raw( (string) $src );

		if ( $id ) {
			$config['img_alt'] = sanitize_text_field( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
		} elseif ( is_array( $image ) && ! empty( $image['alt'] ) ) {
			$config['img_alt'] = sanitize_text_field( (string) $image['alt'] );
		}

		return $config;
	}
}
