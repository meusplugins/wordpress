<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Types\Repeatable_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Array_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Base\Object_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Contracts\Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Url_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;
use Elementor\Modules\AtomicWidgets\Utils\Image\Placeholder_Image;
use Happy_Addons\Elementor\Classes\Atomic_Field_Control;
use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * One layer of Multi Layer Parallax. Same settings as a Classic repeater item;
 * the "ha-mlp-layer" editor control shows the ones that apply to the chosen
 * effect. "view" / "view_hor" are "start,end" texts (the Classic range slider)
 * and "show_on" is the comma separated list of devices the layer shows on.
 */
class Mlp_Layer_Prop_Type extends Object_Prop_Type {

	public static function get_key(): string {
		return 'ha-mlp-layer';
	}

	protected function define_shape(): array {
		return [
			'label'         => String_Prop_Type::make(),
			'hide'          => Boolean_Prop_Type::make(),
			'image'         => Image_Prop_Type::make(),
			'width'         => Number_Prop_Type::make()->float(),
			'z_index'       => Number_Prop_Type::make()->float(),
			'hor'           => String_Prop_Type::make()->enum( [ 'left', 'center', 'right', 'custom' ] ),
			'hor_pos'       => Number_Prop_Type::make()->float(),
			'ver'           => String_Prop_Type::make()->enum( [ 'top', 'vcenter', 'bottom', 'custom' ] ),
			'ver_pos'       => Number_Prop_Type::make()->float(),
			'effect'        => String_Prop_Type::make()->enum( [ 'mouse_track', 'scroll_parallax' ] ),
			'rate'          => Number_Prop_Type::make()->float(),
			'scroll_ver'    => Boolean_Prop_Type::make(),
			'direction'     => String_Prop_Type::make()->enum( [ 'up', 'down' ] ),
			'speed'         => Number_Prop_Type::make()->float(),
			'view'          => String_Prop_Type::make(),
			'scroll_hor'    => Boolean_Prop_Type::make(),
			'direction_hor' => String_Prop_Type::make()->enum( [ 'up', 'down' ] ),
			'speed_hor'     => Number_Prop_Type::make()->float(),
			'view_hor'      => String_Prop_Type::make(),
			'show_on'       => String_Prop_Type::make(),
		];
	}
}

/**
 * The layers list. The key is what the editor builds for a repeatable control
 * whose items are "ha-mlp-layer" (<item key>-array).
 */
class Mlp_Layers_Prop_Type extends Array_Prop_Type {

	public static function get_key(): string {
		return 'ha-mlp-layer-array';
	}

	protected function define_item_type(): Prop_Type {
		return Mlp_Layer_Prop_Type::make();
	}
}

/**
 * Multi Layer Parallax for the Atomic containers (e-flexbox, e-div-block, e-grid).
 * The V4 counterpart of extensions/multi-layer-parallax.php.
 *
 * Same settings as Classic: Enable, the Layers repeater (image, size, z-index,
 * horizontal / vertical alignment and position, Mouse Track or Scroll Parallax
 * with vertical / horizontal direction, speed and viewport, Show Layer On) and
 * Apply Scroll Parallax On. The layers are built and moved by the Atomic Pro
 * runtime (multi-layer-parallax.js), which gets the sanitized config (frontend)
 * or reads the editor settings (editor preview), so the Classic "Apply" button
 * is not needed. Atomic settings are single valued (not per-breakpoint), so the
 * responsive Size / Position settings collapse into one value each.
 */
class Multi_Layer_Parallax extends Atomic_Feature_Base {

	/** Raw layers of the element being rendered. */
	private $raw_layers = [];

	protected function prefix() {
		return 'ha_mlp_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	}

	protected function feature_key() {
		return 'multi-layer-parallax';
	}

	protected function section_label() {
		return __( 'Multi Layer Parallax', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		return isset( $schema['classes'], $schema['tag'], $schema['link'] )
			&& ! isset( $schema['title'], $schema['image'], $schema['text'], $schema['paragraph'] );
	}

	/**
	 * Devices as the Classic feature lists them (custom breakpoints included).
	 *
	 * @return array<string,string> device => label
	 */
	public static function devices() {
		try {
			return \Happy_Addons_Pro\Extensions\Multi_Layer_Parallax::get_all_breakpoints();
		} catch ( \Throwable $e ) {
			return [
				'desktop' => __( 'Desktop', 'happy-addons-pro' ),
				'tablet'  => __( 'Tablet', 'happy-addons-pro' ),
				'mobile'  => __( 'Mobile', 'happy-addons-pro' ),
			];
		}
	}

	/**
	 * @return array[] [ [ 'value' => device, 'label' => label ], ... ]
	 */
	public static function device_options() {
		$list = [];

		foreach ( self::devices() as $value => $label ) {
			$list[] = [ 'value' => (string) $value, 'label' => $label ];
		}

		return $list;
	}

	private static function all_devices_csv() {
		return implode( ',', array_keys( self::devices() ) );
	}

	protected function fields() {
		return [
			'switcher' => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Enable?', 'happy-addons-pro' ),
			],
		];
	}

	protected function extra_props() {
		$show = Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where( [
				'operator' => 'eq',
				'path'     => [ $this->prefix() . 'switcher' ],
				'value'    => true,
				'effect'   => 'hide',
			] )
			->get();

		$layers = Mlp_Layers_Prop_Type::make()->default( [] );
		$layers->set_dependencies( $show );

		$devices = String_Prop_Type::make()->default( self::all_devices_csv() );
		$devices->set_dependencies( $show );

		return [
			$this->prefix() . 'layers'  => $layers,
			$this->prefix() . 'devices' => $devices,
		];
	}

	protected function extra_controls() {
		$number = function ( $value ) {
			return [ '$$type' => 'number', 'value' => $value ];
		};
		$string = function ( $value ) {
			return [ '$$type' => 'string', 'value' => $value ];
		};
		$bool = function ( $value ) {
			return [ '$$type' => 'boolean', 'value' => $value ];
		};

		$layers = Repeatable_Control::bind_to( $this->prefix() . 'layers' )
			->set_repeaterLabel( __( 'Layers', 'happy-addons-pro' ) )
			->set_child_control_type( 'ha-mlp-layer' )
			->set_child_control_props( [
				'sizes'   => Image_Sizes::get_all(),
				'devices' => self::device_options(),
				'labels'  => [
					'hide'          => __( 'Hide This Layer', 'happy-addons-pro' ),
					'image'         => __( 'Choose Image', 'happy-addons-pro' ),
					'width'         => __( 'Size (%)', 'happy-addons-pro' ),
					'z_index'       => __( 'Z-index', 'happy-addons-pro' ),
					'hor'           => __( 'Horizontal Alignment', 'happy-addons-pro' ),
					'hor_pos'       => __( 'Horizontal Position (%)', 'happy-addons-pro' ),
					'ver'           => __( 'Vertical Alignment', 'happy-addons-pro' ),
					'ver_pos'       => __( 'Vertical Position (%)', 'happy-addons-pro' ),
					'effect'        => __( 'Effect Type', 'happy-addons-pro' ),
					'rate'          => __( 'Rate', 'happy-addons-pro' ),
					'scroll_ver'    => __( 'Vertical Parallax', 'happy-addons-pro' ),
					'direction'     => __( 'Direction', 'happy-addons-pro' ),
					'speed'         => __( 'Speed', 'happy-addons-pro' ),
					'view'          => __( 'Viewport', 'happy-addons-pro' ),
					'scroll_hor'    => __( 'Horizontal Parallax', 'happy-addons-pro' ),
					'show_on'       => __( 'Show Layer On', 'happy-addons-pro' ),
					'bottom'        => __( 'Bottom', 'happy-addons-pro' ),
					'top'           => __( 'Top', 'happy-addons-pro' ),
				],
				'descriptions' => [
					'z_index' => __( 'Set z-index for the current layer', 'happy-addons-pro' ),
					'hor_pos' => __( 'Set the horizontal position for the layer background, default: 50%', 'happy-addons-pro' ),
					'ver_pos' => __( 'Set the vertical position for the layer background, default: 50%', 'happy-addons-pro' ),
					'rate'    => __( 'Choose the movement rate for the layer background, default: -10', 'happy-addons-pro' ),
				],
				'options' => [
					'hor'       => $this->options( [
						'left'   => __( 'Left', 'happy-addons-pro' ),
						'center' => __( 'Center', 'happy-addons-pro' ),
						'right'  => __( 'Right', 'happy-addons-pro' ),
						'custom' => __( 'Custom', 'happy-addons-pro' ),
					] ),
					'ver'       => $this->options( [
						'top'     => __( 'Top', 'happy-addons-pro' ),
						'vcenter' => __( 'Center', 'happy-addons-pro' ),
						'bottom'  => __( 'Bottom', 'happy-addons-pro' ),
						'custom'  => __( 'Custom', 'happy-addons-pro' ),
					] ),
					'effect'    => $this->options( [
						'mouse_track'     => __( 'Mouse Track', 'happy-addons-pro' ),
						'scroll_parallax' => __( 'Scroll Parallax', 'happy-addons-pro' ),
					] ),
					'direction' => $this->options( [
						'up'   => __( 'Up', 'happy-addons-pro' ),
						'down' => __( 'Down', 'happy-addons-pro' ),
					] ),
					'direction_hor' => $this->options( [
						'up'   => __( 'Left', 'happy-addons-pro' ),
						'down' => __( 'Right', 'happy-addons-pro' ),
					] ),
				],
			] )
			->set_initialValues( (object) [
				'hide'          => $bool( false ),
				'image'         => Image_Prop_Type::generate( [
					'src'  => Image_Src_Prop_Type::generate( [
						'id'  => null,
						'url' => Url_Prop_Type::generate( Placeholder_Image::get_placeholder_image() ),
					] ),
					'size' => $string( 'large' ),
				] ),
				'width'         => $number( 100 ),
				'z_index'       => $number( 1 ),
				'hor'           => $string( 'custom' ),
				'hor_pos'       => $number( 0 ),
				'ver'           => $string( 'custom' ),
				'ver_pos'       => $number( 0 ),
				'effect'        => $string( 'scroll_parallax' ),
				'rate'          => $number( -10 ),
				'scroll_ver'    => $bool( true ),
				'direction'     => $string( 'down' ),
				'speed'         => $number( 4 ),
				'view'          => $string( '0,100' ),
				'scroll_hor'    => $bool( false ),
				'direction_hor' => $string( 'down' ),
				'speed_hor'     => $number( 4 ),
				'view_hor'      => $string( '0,100' ),
				'show_on'       => $string( self::all_devices_csv() ),
			] )
			->set_patternLabel( '${value.label.value}' )
			->set_placeholder( __( 'Layer', 'happy-addons-pro' ) )
			->set_prop_key( 'ha-mlp-layer-array' )
			->set_is_sortable( true )
			->hide_toggle();

		// Device checkboxes (the Classic multiple select), rendered by "ha-mlp-devices".
		$devices = Atomic_Field_Control::custom(
			$this->prefix() . 'devices',
			'ha-mlp-devices',
			[ 'devices' => self::device_options() ],
			__( 'Apply Scroll Parallax On', 'happy-addons-pro' )
		);

		return [ 'switcher' => [ $layers, $devices ] ];
	}

	private function options( array $list ) {
		$out = [];

		foreach ( $list as $value => $label ) {
			$out[] = [ 'value' => (string) $value, 'label' => $label ];
		}

		return $out;
	}

	public function before_render( $element ) {
		if ( ! is_object( $element ) || ! method_exists( $element, 'get_atomic_settings' ) || ! method_exists( $element, 'get_element_type' ) ) {
			return;
		}

		if ( ! in_array( $element::get_element_type(), $this->target_types(), true ) ) {
			return;
		}

		// The layers are read as stored: they are not resolved by Elementor's renderer.
		$this->raw_layers = $element->get_settings( $this->prefix() . 'layers' );

		parent::before_render( $element );

		$this->raw_layers = [];
	}

	/**
	 * The editor preview reads the settings from the editor; it needs the
	 * layers and devices keys to carry them over.
	 */
	public function defaults() {
		return parent::defaults() + [
			'layers'  => [],
			'devices' => self::all_devices_csv(),
		];
	}

	/**
	 * Settings plus the layers, with plain values and the image URL / alt text
	 * (the runtime gets URLs, not image props).
	 */
	protected function sanitize_config( array $settings ) {
		$config = parent::sanitize_config( $settings );

		$devices = $settings[ $this->prefix() . 'devices' ] ?? '';
		$devices = is_string( $devices ) && '' !== $devices ? $devices : self::all_devices_csv();

		$config['devices'] = self::sanitize_devices( $devices );
		$config['layers']  = $this->sanitize_layers( $this->raw_layers );

		return $config;
	}

	private static function unwrap( $value ) {
		while ( is_array( $value ) && isset( $value['$$type'] ) && array_key_exists( 'value', $value ) ) {
			$value = $value['value'];
		}

		return $value;
	}

	private static function sanitize_devices( $csv ) {
		$known = array_keys( self::devices() );
		$list  = is_array( $csv ) ? $csv : explode( ',', (string) $csv );

		return array_values( array_intersect( $known, array_map( 'trim', $list ) ) );
	}

	private static function pick( $value, array $allowed, $default ) {
		$value = is_scalar( $value ) ? (string) $value : '';

		return in_array( $value, $allowed, true ) ? $value : $default;
	}

	private static function number( $value, $default, $min = null, $max = null ) {
		if ( ! is_numeric( $value ) ) {
			return $default;
		}

		$value = (float) $value;

		if ( null !== $min ) {
			$value = max( $min, $value );
		}

		if ( null !== $max ) {
			$value = min( $max, $value );
		}

		return $value;
	}

	/**
	 * "start,end" (0 - 100), as the Classic viewport range.
	 */
	private static function view( $value ) {
		$parts = explode( ',', is_scalar( $value ) ? (string) $value : '' );
		$start = self::number( $parts[0] ?? '', 0, 0, 100 );
		$end   = self::number( $parts[1] ?? '', 100, 0, 100 );

		return [ 'start' => $start, 'end' => $end ];
	}

	private function sanitize_layers( $raw ) {
		$items = self::unwrap( $raw );

		if ( ! is_array( $items ) ) {
			return [];
		}

		$list = [];

		foreach ( array_slice( $items, 0, 100 ) as $item ) {
			$item = self::unwrap( $item );

			if ( ! is_array( $item ) ) {
				continue;
			}

			$get = function ( $key ) use ( $item ) {
				return self::unwrap( $item[ $key ] ?? null );
			};

			if ( $get( 'hide' ) ) {
				continue;
			}

			$image = $this->image( $item['image'] ?? null );

			// The Classic layer is the image: without one there is nothing to draw.
			if ( '' === $image['url'] ) {
				continue;
			}

			$show_on = $get( 'show_on' );

			$list[] = [
				'image_url'     => $image['url'],
				'alt'           => $image['alt'],
				'width'         => self::number( $get( 'width' ), 100, 0, 1000 ),
				'z_index'       => (int) self::number( $get( 'z_index' ), 1, -9999, 9999 ),
				'hor'           => self::pick( $get( 'hor' ), [ 'left', 'center', 'right', 'custom' ], 'custom' ),
				'hor_pos'       => self::number( $get( 'hor_pos' ), 0, -1000, 1000 ),
				'ver'           => self::pick( $get( 'ver' ), [ 'top', 'vcenter', 'bottom', 'custom' ], 'custom' ),
				'ver_pos'       => self::number( $get( 'ver_pos' ), 0, -1000, 1000 ),
				'effect'        => self::pick( $get( 'effect' ), [ 'mouse_track', 'scroll_parallax' ], 'scroll_parallax' ),
				'rate'          => self::number( $get( 'rate' ), -10, -20, 20 ),
				'scroll_ver'    => null === $get( 'scroll_ver' ) ? true : (bool) $get( 'scroll_ver' ),
				'direction'     => self::pick( $get( 'direction' ), [ 'up', 'down' ], 'down' ),
				'speed'         => self::number( $get( 'speed' ), 4, 0, 10 ),
				'view'          => self::view( $get( 'view' ) ?? '0,100' ),
				'scroll_hor'    => (bool) $get( 'scroll_hor' ),
				'direction_hor' => self::pick( $get( 'direction_hor' ), [ 'up', 'down' ], 'down' ),
				'speed_hor'     => self::number( $get( 'speed_hor' ), 4, 0, 10 ),
				'view_hor'      => self::view( $get( 'view_hor' ) ?? '0,100' ),
				'show_on'       => self::sanitize_devices( is_string( $show_on ) && '' !== $show_on ? $show_on : self::all_devices_csv() ),
			];
		}

		return $list;
	}

	/**
	 * URL and alt text of a layer image (attachment, or a plain URL).
	 *
	 * @return array{url:string,alt:string}
	 */
	private function image( $raw ) {
		$image = self::unwrap( $raw );
		$src   = is_array( $image ) ? self::unwrap( $image['src'] ?? null ) : null;
		$size  = is_array( $image ) ? (string) self::unwrap( $image['size'] ?? '' ) : '';
		$id    = is_array( $src ) ? (int) self::unwrap( $src['id'] ?? 0 ) : 0;
		$url   = is_array( $src ) ? self::unwrap( $src['url'] ?? '' ) : '';
		$alt   = '';

		if ( $id ) {
			$resolved = wp_get_attachment_image_url( $id, '' !== $size ? $size : 'full' );

			if ( $resolved ) {
				$url = $resolved;
			}

			$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
		}

		return [
			'url' => esc_url_raw( is_string( $url ) ? $url : '' ),
			'alt' => sanitize_text_field( $alt ),
		];
	}
}
