"use strict";

(function ($, w) {
  'use strict';

  $(w).on('elementor/frontend/init', function () {
    var DESKTOP_QUERY = '(min-width: 1025px)';
    function itemHasCustomWidth(el) {
      var inlineStyle = el.getAttribute('style') || '';
      if (/(^|;)\s*width\s*:/i.test(inlineStyle)) {
        return true;
      }
      var width = w.getComputedStyle(el).getPropertyValue('--width').trim();
      return !!width && '100%' !== width;
    }
    var HappyHorizontalScroll2 = elementorModules.frontend.handlers.Base.extend({
      onInit: function onInit() {
        elementorModules.frontend.handlers.Base.prototype.onInit.apply(this, arguments);
        this._isBuilt = false;
        this._layoutBound = false;
        this._bindLayoutChangeListeners();
        this.run();
      },
      onElementChange: function onElementChange(changedKey) {
        if (typeof changedKey === 'string' && (changedKey === 'ha_hs2_switcher' || changedKey === 'ha_hs2_direction' || changedKey === 'ha_hs2_snap_scroll_switcher' || changedKey === 'ha_hs2_enable_auto_width')) {
          this._teardown();
          this.run();
        }
      },
      onDestroy: function onDestroy() {
        this._unbindLayoutChangeListeners();
        this._teardown();
        elementorModules.frontend.handlers.Base.prototype.onDestroy.apply(this, arguments);
      },
      /**
       * Bind scroll + layout change listeners once.
       * Scroll drives the horizontal translate; layout events re-measure
       * the track (Elementor Tabs / Accordion / image + font loads, etc.).
       */
      _bindLayoutChangeListeners: function _bindLayoutChangeListeners() {
        if (this._layoutBound) {
          return;
        }
        var self = this;
        var reconcile = this._reconcileResponsiveState.bind(this);
        var refresh = this._refreshLayout.bind(this);
        this._onScrollHandler = function () {
          self._onScroll();
        };
        this._snapToNearest = this._snapToNearest.bind(this);
        this._debouncedReconcile = this._debounce(reconcile, 120);
        this._debouncedRefresh = this._debounce(refresh, 120);
        this._desktopMediaQuery = w.matchMedia(DESKTOP_QUERY);
        $(w).on('scroll', this._onScrollHandler);
        $(w).on('resize', this._debouncedReconcile);
        $(w).on('orientationchange', this._debouncedReconcile);
        if (this._desktopMediaQuery.addEventListener) {
          this._desktopMediaQuery.addEventListener('change', this._debouncedReconcile);
        } else if (this._desktopMediaQuery.addListener) {
          // Safari < 14
          this._desktopMediaQuery.addListener(this._debouncedReconcile);
        }
        $(w).on('elementor-pro/motion-fx/recalc', this._debouncedRefresh);
        $(w).on('ha:nested:change', this._debouncedRefresh);
        $(document).on('ha_TabHandlerBase_changed', this._debouncedRefresh);

        // Late resources (images / fonts) change track measurements.
        $(w).on('load', this._debouncedRefresh);
        if (w.document.fonts && w.document.fonts.ready) {
          w.document.fonts.ready.then(this._debouncedRefresh);
        }

        // Elementor Accordion / Toggle widgets above this section shift
        // the page layout without firing any event — watch for size changes.
        if (typeof w.ResizeObserver !== 'undefined') {
          this._resizeObserver = new w.ResizeObserver(this._debouncedRefresh);
          this._resizeObserver.observe(w.document.body);
          this._resizeObserver.observe(this.$element[0]);
        }
        this._layoutBound = true;
      },
      _unbindLayoutChangeListeners: function _unbindLayoutChangeListeners() {
        if (!this._layoutBound) {
          return;
        }
        clearTimeout(this._snapTimer);
        $(w).off('scroll', this._onScrollHandler);
        $(w).off('resize', this._debouncedReconcile);
        $(w).off('orientationchange', this._debouncedReconcile);
        if (this._desktopMediaQuery) {
          if (this._desktopMediaQuery.removeEventListener) {
            this._desktopMediaQuery.removeEventListener('change', this._debouncedReconcile);
          } else if (this._desktopMediaQuery.removeListener) {
            this._desktopMediaQuery.removeListener(this._debouncedReconcile);
          }
          this._desktopMediaQuery = null;
        }
        $(w).off('elementor-pro/motion-fx/recalc', this._debouncedRefresh);
        $(w).off('ha:nested:change', this._debouncedRefresh);
        $(document).off('ha_TabHandlerBase_changed', this._debouncedRefresh);
        $(w).off('load', this._debouncedRefresh);
        if (this._resizeObserver) {
          this._resizeObserver.disconnect();
          this._resizeObserver = null;
        }
        this._layoutBound = false;
      },
      /**
       * Desktop-only feature. Below the breakpoint the original
       * vertical / list layout is restored.
       */
      _reconcileResponsiveState: function _reconcileResponsiveState() {
        if (!this._desktopMediaQuery || !this._desktopMediaQuery.matches) {
          this._teardown();
          return;
        }
        if (!this._isBuilt) {
          this.run();
          return;
        }
        this._refreshLayout();
      },
      _refreshLayout: function _refreshLayout() {
        if (!this._isBuilt) {
          return;
        }

        // Only re-measure when this section is actually visible.
        if (!this.$element.is(':visible')) {
          return;
        }
        this._measure();
        this._updateScroll();
      },
      _debounce: function _debounce(fn, wait) {
        var timer;
        return function () {
          var ctx = this;
          var args = arguments;
          clearTimeout(timer);
          timer = setTimeout(function () {
            fn.apply(ctx, args);
          }, wait);
        };
      },
      run: function run() {
        if (!this._desktopMediaQuery || !this._desktopMediaQuery.matches) {
          return;
        }
        var settings = this.getElementSettings();
        if (settings.ha_hs2_switcher !== 'yes') return;
        if (this.isEdit) {
          return;
        }
        if (this._isBuilt) {
          return;
        }
        var $wrapper = this.$element;
        var $children = $wrapper.children().not('.ha-hs2-inner');
        if ($children.length < 2) return;

        // Build track: wrapper > inner (sticky) > track (translated) > items
        var $inner = $('<div class="ha-hs2-inner"></div>');
        var $track = $('<div class="ha-hs2-track"></div>');
        $children.each(function () {
          var $child = $(this);
          $child.addClass('ha-hs2-item');
          if (itemHasCustomWidth(this)) {
            $child.addClass('ha-hs2-item-custom-width');
          }
          $child.appendTo($track);
        });
        $track.appendTo($inner);
        $inner.appendTo($wrapper);
        this._$inner = $inner;
        this._track = $track[0];
        this._totalPanels = $children.length;
        this._isBuilt = true;
        this._measure();
        this._updateScroll();
      },
      _measure: function _measure() {
        if (!this._isBuilt) {
          return;
        }
        var $wrapper = this.$element;
        var track = this._track;
        var containerWidth = $wrapper.outerWidth();
        if (!containerWidth || containerWidth < 1) return;
        var isAutoWidth = $wrapper.hasClass('ha-hs2-auto-width-enabled');
        var hasCustomWidth = !isAutoWidth && $(track).children('.ha-hs2-item-custom-width').length > 0;
        var totalWidth;
        if (isAutoWidth || hasCustomWidth) {
          totalWidth = track.scrollWidth;
          track.style.width = '';
        } else {
          totalWidth = containerWidth * this._totalPanels;
          track.style.width = totalWidth + 'px';
        }
        this._containerWidth = containerWidth;
        this._totalWidth = totalWidth;
        this._maxTranslate = Math.max(0, totalWidth - containerWidth);

        // Same scroll distance as the GSAP version (end: "+=" totalWidth).
        // The sticky inner stays pinned for viewport height + scroll distance.
        if (this._maxTranslate > 0) {
          this._scrollDistance = totalWidth;
          $wrapper.height(w.innerHeight + this._scrollDistance);
        } else {
          this._scrollDistance = 1;
          $wrapper.height('');
        }
      },
      _onScroll: function _onScroll() {
        var _this = this;
        if (!this._isBuilt) {
          return;
        }
        if (!this._ticking) {
          this._ticking = true;
          w.requestAnimationFrame(function () {
            _this._updateScroll();
            _this._ticking = false;
          });
        }
        this._scheduleSnap();
      },
      _updateScroll: function _updateScroll() {
        if (!this._isBuilt || this._maxTranslate <= 0) {
          return;
        }

        // Live viewport position instead of a cached document offset —
        // immune to layout shifts above this section (accordion, toggle...).
        var progress = -this.$element[0].getBoundingClientRect().top / this._scrollDistance;
        progress = Math.max(0, Math.min(1, progress));
        var direction = this.getElementSettings().ha_hs2_direction || 'left';
        var x;
        if (direction === 'right') {
          // Starts fully translated (last panel) and settles to 0.
          x = -this._maxTranslate * (1 - progress);
        } else {
          x = -this._maxTranslate * progress;
        }
        this._track.style.transform = 'translate3d(' + x + 'px,0,0)';
      },
      _scheduleSnap: function _scheduleSnap() {
        clearTimeout(this._snapTimer);
        if (!this._isBuilt || this._maxTranslate <= 0) {
          return;
        }
        var settings = this.getElementSettings();
        if (settings.ha_hs2_snap_scroll_switcher !== 'yes') {
          return;
        }

        // Snap once scrolling has been idle for a moment.
        this._snapTimer = setTimeout(this._snapToNearest, 160);
      },
      _snapToNearest: function _snapToNearest() {
        if (!this._isBuilt || this._maxTranslate <= 0 || this._totalPanels < 2) {
          return;
        }
        var settings = this.getElementSettings();
        if (settings.ha_hs2_snap_scroll_switcher !== 'yes') {
          return;
        }
        var scrollY = w.pageYOffset || w.document.documentElement.scrollTop;
        var rectTop = this.$element[0].getBoundingClientRect().top;
        var progress = -rectTop / this._scrollDistance;
        var index = Math.round(progress * (this._totalPanels - 1));
        index = Math.max(0, Math.min(this._totalPanels - 1, index));
        var target = scrollY + rectTop + index / (this._totalPanels - 1) * this._scrollDistance;
        if (Math.abs(target - scrollY) < 2) {
          return;
        }
        w.scrollTo({
          top: target,
          behavior: 'smooth'
        });
      },
      _teardown: function _teardown() {
        if (!this._isBuilt) {
          return;
        }
        clearTimeout(this._snapTimer);
        var $inner = this.$element.children('.ha-hs2-inner');
        if ($inner.length) {
          var $track = $inner.children('.ha-hs2-track');
          var $items = $track.length ? $track.children() : $inner.children();
          $items.each(function () {
            $(this).removeClass('ha-hs2-item ha-hs2-item-custom-width');
          }).appendTo(this.$element);
          $inner.remove();
        }
        this.$element.height('');
        this._$inner = null;
        this._track = null;
        this._totalPanels = 0;
        this._containerWidth = 0;
        this._totalWidth = 0;
        this._maxTranslate = 0;
        this._scrollDistance = 1;
        this._isBuilt = false;
      }
    });
    elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
      elementorFrontend.elementsHandler.addHandler(HappyHorizontalScroll2, {
        $element: $scope
      });
    });
  });
})(jQuery, window);