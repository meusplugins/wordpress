<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class Is_Front_Page extends Base_Condition {

	public function get_key() {
		return 'is_front_page';
	}

	public function check( $rule, $context ) {
		return is_front_page();
	}
}
