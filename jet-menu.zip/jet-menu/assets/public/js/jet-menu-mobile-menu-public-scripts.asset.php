<?php return array('dependencies' => array(), 'version' => 'e29c36d511324d6d56d2');
