<?php
namespace Jet_Engine\Query_Builder\File_Query;

use WP_Error;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * JSON-specific file query parser.
 */
class JSON_Parser extends Base_Parser {

	/**
	 * Parse JSON content into normalized rows and properties.
	 *
	 * @param array $source Resolved source payload.
	 * @param array $query  Normalized file query arguments.
	 * @param array $limits Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	public static function parse( $source, $query, $limits ) {
		$data = json_decode( $source['content'], true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error( 'file_query_invalid_json', sprintf( __( 'JSON parse error: %s', 'jet-engine' ), json_last_error_msg() ) );
		}

		$records = array();

		if ( is_array( $data ) && self::is_sequential_array( $data ) ) {
			$records = $data;
		} elseif ( is_array( $data ) && ! empty( $query['json']['records_path'] ) ) {
			$records = self::resolve_records_path( $data, $query['json']['records_path'] );

			if ( ! is_array( $records ) || ! self::is_sequential_array( $records ) ) {
				return new WP_Error( 'file_query_invalid_records_path', __( 'JSON records path must resolve to an array of objects.', 'jet-engine' ) );
			}
		} else {
			return new WP_Error( 'file_query_invalid_json_shape', __( 'JSON source must be an array of objects or provide a records path that resolves to one.', 'jet-engine' ) );
		}

		$rows = array();

		foreach ( $records as $index => $record ) {
			if ( ! is_array( $record ) || self::is_sequential_array( $record ) ) {
				return new WP_Error( 'file_query_invalid_json_record', __( 'JSON records must be objects with named properties.', 'jet-engine' ) );
			}

			$normalized = self::normalize_json_record( $record, $index + 1, $limits );

			if ( is_wp_error( $normalized ) ) {
				return $normalized;
			}

			$rows[] = $normalized;
		}

		return self::finalize_rows( $rows, $limits );
	}

	/**
	 * Normalize a decoded JSON object into a flat row.
	 *
	 * @param array $record    JSON object record.
	 * @param int   $row_index One-based row index.
	 * @param array $limits    Parsing limits.
	 *
	 * @return array|WP_Error
	 */
	protected static function normalize_json_record( $record, $row_index, $limits ) {
		$normalized     = array();
		$fallback_index = 1;

		foreach ( $record as $key => $value ) {
			$fallback = 'col_' . $fallback_index;
			$fallback_index++;

			$error = self::flatten_json_value( $normalized, $value, $key, $fallback, $limits );

			if ( is_wp_error( $error ) ) {
				return $error;
			}
		}

		$normalized[ self::reserved_index_key() ] = $row_index;

		if ( count( $normalized ) - 1 > $limits['max_columns'] ) {
			return new WP_Error( 'file_query_columns_limit', __( 'The selected source exceeds the allowed column limit.', 'jet-engine' ) );
		}

		return $normalized;
	}

	/**
	 * Flatten a nested JSON value into one or more normalized row fields.
	 *
	 * @param array  $row      Row being built.
	 * @param mixed  $value    Current value.
	 * @param string $path     Current property path.
	 * @param string $fallback Fallback key name.
	 * @param array  $limits   Parsing limits.
	 *
	 * @return bool|WP_Error
	 */
	protected static function flatten_json_value( &$row, $value, $path, $fallback, $limits ) {
		if ( is_array( $value ) && ! self::is_sequential_array( $value ) ) {
			foreach ( $value as $child_key => $child_value ) {
				$next_path = $path ? $path . '.' . $child_key : $child_key;
				$error     = self::flatten_json_value( $row, $child_value, $next_path, $fallback, $limits );

				if ( is_wp_error( $error ) ) {
					return $error;
				}
			}

			return true;
		}

		$normalized = self::prepare_normalized_value( $value, $limits );

		if ( is_wp_error( $normalized ) ) {
			return $normalized;
		}

		$key      = self::generate_unique_key( array_keys( $row ), $path, $fallback );
		$row[ $key ] = $normalized;

		if ( count( $row ) > $limits['max_columns'] ) {
			return new WP_Error( 'file_query_columns_limit', __( 'The selected source exceeds the allowed column limit.', 'jet-engine' ) );
		}

		return true;
	}
}