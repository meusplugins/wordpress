<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . '../../utils/Geo.php');
require_once(plugin_dir_path(__FILE__) . '../../services/OptionsService.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/OptionUtil.php');
require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');
require_once(plugin_dir_path(__FILE__) . '../../services/GeocodeService.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/Sanitizer.php');

use \com\sakuraplugins\appetit\utils\Geo;
use \com\sakuraplugins\appetit\utils\OptionUtil;
use \com\sakuraplugins\appetit\services\GeocodeService;
use \com\sakuraplugins\appetit\utils\Sanitizer;

class VerifyDeliveryAddressController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/verify-delivery-distance', array(
            array(
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'verifyDistance'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * verify distance
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function verifyDistance(\WP_REST_Request $request) {
        if (INSTAFOOD_PREVIEW_MODE === true) {
            return ResponseHelper::respond(['canOrder' => true]);
        }
        $restaurant_max_delivery_radius = OptionUtil::getInstance()->getOption("restaurant_max_delivery_radius", '');
        if ($restaurant_max_delivery_radius === '') {
            return ResponseHelper::respond(['canOrder' => true]);
        }

        $gmap_api_key = OptionUtil::getInstance()->getOption("gmap_api_key", '');
        $restaurant_lat = OptionUtil::getInstance()->getOption("restaurant_lat", '');
        $restaurant_lng = OptionUtil::getInstance()->getOption("restaurant_lng", '');


        if ($gmap_api_key === '' || $restaurant_lat === '' || $restaurant_lng === '') {
            return ResponseHelper::respond(['canOrder' => true]);
        }

        $displayAddress = Sanitizer::sanitizeInput($request->get_param('displayAddress'));
        $city = Sanitizer::sanitizeInput($request->get_param('city'));

        $gs = new GeocodeService(trim($gmap_api_key));
        $mapResult = $gs->geocode("$displayAddress, $city");
        if (!$mapResult) {
            return ResponseHelper::respond(['canOrder' => false]);
        }

        $restaurant_lat = OptionUtil::getInstance()->getOption('restaurant_lat', '51.5073509');
        $restaurant_lng = OptionUtil::getInstance()->getOption('restaurant_lng', '-0.1277583');

        $distance = Geo::getDistance($restaurant_lat, $restaurant_lng, $mapResult[0], $mapResult[1], 'M');

        if (intval($restaurant_max_delivery_radius, 10) < floatval($distance)) {
            return ResponseHelper::respond(['canOrder' => false]);
        }

        return ResponseHelper::respond(['canOrder' => true]);
    }
    
}
?>