import Cart from '../../cart/Cart';
import LanguageUtils from '../../utils/LanguageUtils';
import EventBus, { Event, Events } from '../../events/EventBus';
import Order from '../../order/Order';
import RestManager from '../../services/RestManager';

class RestaurantClosedWgt {

    _parrentUI;
    _ui;
    _onOrderConfigChanged;
    _staticHolderUI;

    constructor(parrentUI) {
        this._parrentUI = parrentUI;
        this._staticHolderUI = jQuery(`<div></div>`);
        this._staticHolderUI.appendTo(this._parrentUI);
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderConfigChanged = new Event(Events.ORDER_CONFIG_CHANGED, data => this.update(data));
        EventBus.getInstance().registerEvent(this._onOrderConfigChanged);
    }

    _checkIsRestaurantOpen() {
        RestManager.getInstance().get('/shop-open')
        .then(result => {
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            const {
                data: {
                    isOpen
                }
            } = result;
            Order.getInstance().setIsShopOpen(isOpen);
            this._handleShopOpenInfo(isOpen);
        });
    }

    _handleShopOpenInfo(isOpen) {
        if (_.get(this, '_staticHolderUI[0]')) {
            this._staticHolderUI.empty();
        }
        const { isDineIn, isDelivery } = Order.getInstance().getShippingOptions();
        if (!isOpen && (isDineIn || isDelivery)) {
            const template = `
                <div class="appetit-alert yellow" style="padding-bottom: 0;">
                    <div class="alert-content">
                        ${ LanguageUtils.getInstance().getLabel('shop_closed_message') }
                    </div>
                </div>
            `;
            this._ui = jQuery(template);
            this._ui.appendTo(this._staticHolderUI)
        }
    }

    render() {
        this._checkIsRestaurantOpen();
    }

    update() {
        this._checkIsRestaurantOpen();
    }
}
export default RestaurantClosedWgt;