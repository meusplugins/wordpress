=== Elementor Pro ===
Contributors: elemntor
Tags: page builder, editor, landing page, drag-and-drop, elementor, visual editor, wysiwyg, design, maintenance mode, coming soon, under construction, website builder, landing page builder, front-end builder
Requires at least: 6.6
Tested up to: 6.8
Requires PHP: 7.4
Requires Elementor: 3.29
