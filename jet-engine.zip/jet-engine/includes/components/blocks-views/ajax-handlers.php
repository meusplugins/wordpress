<?php
/**
 * Elementor views manager
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Blocks_Views_Ajax_Handlers' ) ) {

	/**
	 * Resolve saved block attributes for trusted listing AJAX requests.
	 */
	class Jet_Engine_Blocks_Views_Ajax_Handlers {

		/** Register the saved-block lookup used by listing AJAX. */
		public function __construct() {
			add_filter( 'jet-engine/listings/ajax/settings-by-id/blocks', array( $this, 'find_block_by_id' ), 10, 4 );
		}

		/**
		 * Resolve saved attributes, optionally requiring an actual Listing Grid.
		 *
		 * @param array       $result Initial filter result.
		 * @param string|null $element_id Canonical block ID, not its CSS ID.
		 * @param int|null    $post_id Owning document ID.
		 * @param bool        $grid_only Whether asserted owner access requires a grid.
		 * @return array
		 */
		public function find_block_by_id( $result = array(), $element_id = null, $post_id = null, $grid_only = false ) {

			$post = get_post( $post_id );

			if ( ! $post ) {
				return $result;
			}

			$blocks = parse_blocks( $post->post_content );
			$attrs  = $this->recursive_find_block( $blocks, $element_id, $grid_only );

			if ( ! empty( $attrs ) ) {
				$attrs['inline_columns_css'] = true;
				return $attrs;
			} else {
				return $result;
			}

		}

		/**
		 * Find a canonical block ID through nested saved blocks.
		 *
		 * @param array       $blocks Parsed block tree.
		 * @param string|null $element_id Canonical block ID.
		 * @param bool        $grid_only Whether to reject other block types.
		 * @return array|false
		 */
		public function recursive_find_block( $blocks = array(), $element_id = null, $grid_only = false ) {

			if ( empty( $blocks ) ) {
				return false;
			}

			foreach ( $blocks as $block ) {
				if ( ! empty( $block['attrs']['_block_id'] ) && $element_id === $block['attrs']['_block_id'] ) {
					if ( $grid_only && 'jet-engine/listing-grid' !== ( $block['blockName'] ?? '' ) ) {
						return false;
					}
					return $block['attrs'];
				} elseif ( ! empty( $block['innerBlocks'] ) ) {
					$attrs = $this->recursive_find_block( $block['innerBlocks'], $element_id, $grid_only );

					if ( $attrs ) {
						return $attrs;
					}

				}
			}

			return false;

		}

	}

}
