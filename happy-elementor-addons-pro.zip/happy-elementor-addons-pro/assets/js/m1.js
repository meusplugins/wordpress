"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function ($, w) {
  "use strict";

  // Track live instances by element id so stale instances
  // (e.g. after an editor re-render) can be destroyed.
  var marqueeInstances = {};

  // Editor-injected UI that must never become a marquee item
  // (element handles/overlays, empty-view placeholders).
  var EDITOR_UI_SELECTOR = ".elementor-element-overlay, .elementor-empty-view, .elementor-add-section";
  $(w).on("elementor/frontend/init", function () {
    if (typeof gsap === "undefined") return;
    var HappyInfiniteMarquee = elementorModules.frontend.handlers.Base.extend({
      onInit: function onInit() {
        elementorModules.frontend.handlers.Base.prototype.onInit.apply(this, arguments);
        this.build();
      },
      onElementChange: function onElementChange(prop) {
        // Prefix match also covers responsive variants
        // (e.g. ha_im_speed_tablet) in the editor.
        if (prop && prop.indexOf("ha_im_") === 0) {
          this._rebuild();
        }
      },
      destroyMarquee: function destroyMarquee() {
        if (this._renderObserver) {
          try {
            this._renderObserver.disconnect();
          } catch (e) {}
          this._renderObserver = null;
        }
        clearTimeout(this._renderDebounce);
        this._renderDebounce = null;
        if (this._rafId) {
          cancelAnimationFrame(this._rafId);
          this._rafId = null;
        }
        if (this.tween) {
          this.tween.kill();
          this.tween = null;
        }
        if (this._styleSheet && this._styleSheet.parentNode) {
          this._styleSheet.parentNode.removeChild(this._styleSheet);
          this._styleSheet = null;
        }
        if (this._elipsItems) {
          this._elipsItems.forEach(function (el) {
            el.style.transform = "";
            el.style.opacity = "";
            el.style.filter = "";
            el.style.zIndex = "";
            el.style.removeProperty("transition");
          });
          this._elipsItems = null;
        }
        if (this._track) {
          if (this._originals && this._originals.length) {
            if (this._isEditMode) {
              // Edit mode: originals never moved —
              // restore their saved inline styles and
              // the inner wrapper's style.
              this._originals.forEach(function (el, i) {
                var s = this._savedItemStyles ? this._savedItemStyles[i] : null;
                if (s) {
                  el.setAttribute("style", s);
                } else {
                  el.removeAttribute("style");
                }
              }.bind(this));
              if (this._inner && this._inner.length) {
                if (this._savedInnerStyle) {
                  this._inner[0].setAttribute("style", this._savedInnerStyle);
                } else {
                  this._inner[0].removeAttribute("style");
                }
              }
              this.$element.removeClass("ha-marquee-container");
            } else if (this._inner && this._inner.length) {
              // Frontend: move the original items back
              // into the inner wrapper (before the track
              // is removed) so rebuilds work on clean
              // markup.
              var $inner = this._inner;
              this._originals.forEach(function (el) {
                $(el).removeClass("ha-marquee-item").css("flex", "");
                $inner.append(el);
              });
            }
          }
          if (this._track.parentNode) {
            this._track.parentNode.removeChild(this._track);
          }
          this._originals = null;
          this._savedItemStyles = null;
          this._savedInnerStyle = null;
          this._inner = null;
          this._track = null;
        }
        this.$element.removeClass("is-vertical");
        this.$element.off(".haMarquee");
        this.$element.removeData("ha-init");
      },
      getResponsiveSetting: function getResponsiveSetting(settings, key, respectEmpty) {
        var deviceMode = elementorFrontend.getCurrentDeviceMode();
        if (deviceMode !== 'desktop') {
          var deviceKey = key + '_' + deviceMode;
          if (settings[deviceKey] !== undefined && (respectEmpty || settings[deviceKey] !== '')) {
            return settings[deviceKey];
          }
        }
        return settings[key];
      },
      /**
       * Edit mode only: watch for the editor (re)rendering child
       * widgets inside this element and rebuild the marquee from the
       * fresh markup. childList-only so per-frame style writes from
       * the animation engines never trigger it.
       */
      _observeEditorRenders: function _observeEditorRenders() {
        if (this._renderObserver) return;
        var self = this;
        this._renderObserver = new MutationObserver(function (mutations) {
          if (self._mutating) return;
          var relevant = mutations.some(function (m) {
            return m.addedNodes.length > 0 || m.removedNodes.length > 0;
          });
          if (!relevant) return;
          clearTimeout(self._renderDebounce);
          self._renderDebounce = setTimeout(function () {
            if (!self.$element || !self.$element[0].isConnected) {
              self.destroyMarquee();
              return;
            }
            self._rebuild();
          }, 400);
        });
        this._renderObserver.observe(this.$element[0], {
          childList: true,
          subtree: true
        });
      },
      _rebuild: function _rebuild() {
        if (this._mutating) return;
        this._mutating = true;
        try {
          this.destroyMarquee();
          this.build();
        } finally {
          this._mutating = false;
        }
      },
      build: function build() {
        var settings = this.getElementSettings();
        if (settings.ha_im_switcher !== "yes") return;
        if ('mobile' === elementorFrontend.getCurrentDeviceMode() && settings.ha_im_enable_on_mobile !== 'yes') {
          return;
        }
        var pauseOnHover = settings.ha_im_pause_hover === "yes";
        var isEditMode = typeof elementorFrontend !== "undefined" && elementorFrontend.isEditMode && elementorFrontend.isEditMode();

        // Editor-only on/off switch: when "Disable in Editor" is
        // active, skip the marquee so the items stay in their
        // normal (editable) layout. The frontend is unaffected.
        if (isEditMode && settings.ha_im_disable_in_editor === "yes") {
          return;
        }
        var $wrapper = this.$element;
        if ($wrapper.data("ha-init")) return;

        // Destroy a stale instance for this element (e.g. left
        // behind by an editor re-render) before taking over.
        var elementId = $wrapper.attr("data-id");
        if (elementId) {
          var prev = marqueeInstances[elementId];
          if (prev && prev !== this) {
            prev.destroyMarquee();
          }
          marqueeInstances[elementId] = this;
        }
        $wrapper.data("ha-init", true);

        // Detect inner wrapper (container or section)
        var $inner = $wrapper.children(".e-con-inner");
        if (!$inner.length) {
          $inner = $wrapper.children(".elementor-container");
        }
        var $source;
        if ($inner.length) {
          $source = $inner.children();
        } else {
          $inner = $wrapper;
          $source = $wrapper.children().not(".ha-marquee-content");
        }

        // Keep only actual Elementor elements as marquee items.
        // This excludes section shape dividers (.elementor-shape),
        // background overlays, editor resize handles and element
        // overlays — all of which live inside the same wrapper.
        $source = $source.filter(".elementor-element").not(EDITOR_UI_SELECTOR);

        // Keep references so destroyMarquee() can restore the DOM.
        this._inner = $inner;
        this._isEditMode = isEditMode;
        if (isEditMode) {
          // The editor renders widgets progressively: when this
          // container's element_ready fires, its children may not
          // be rendered yet (zero size). Building from unrendered
          // children produces empty clones, so wait for their
          // arrival via the render observer instead.
          var hasRenderedChild = false;
          $source.each(function () {
            var r = this.getBoundingClientRect();
            if (r.width > 1 || r.height > 1) {
              hasRenderedChild = true;
              return false;
            }
          });
          if (!$source.length || !hasRenderedChild) {
            $wrapper.removeData("ha-init");
            this._observeEditorRenders();
            return;
          }
        } else if (!$source.length) {
          return;
        }

        // Get mode and direction settings
        var mode = this.getResponsiveSetting(settings, "ha_im_mode") || "horizontal";
        var isVertical = mode === "vertical";

        // Toggle class. In edit mode the PHP render hook does not
        // run, so add the container class here for the CSS.
        $wrapper.toggleClass("is-vertical", isVertical);
        if (isEditMode) {
          $wrapper.addClass("ha-marquee-container");
        }

        // Capture the original rendered size of every item BEFORE
        // any DOM mutation.
        var originals = [];
        var fixedSizes = [];
        $source.each(function () {
          var rect = this.getBoundingClientRect();
          fixedSizes.push(isVertical ? rect.height : rect.width);
          originals.push(this);
        });
        this._originals = originals;

        // Container (viewport) size, captured before the track
        // replaces the content.
        var containerSize = isVertical ? $inner[0].clientHeight : $inner[0].clientWidth;

        // Create track
        var $track = $('<div class="ha-marquee-content"></div>');
        if (isEditMode) {
          // EDIT MODE — never restructure editor-owned DOM
          // (moving/emptying the container children makes the
          // editor re-render endlessly and freezes the page).
          // Instead: keep the originals in place (hidden AFTER all
          // cloning is done, so clones never inherit the hiding
          // inline styles) and animate a track built from
          // anonymous clones. The originals stay fully editable
          // in the panel/navigator.
          var gap = parseInt(this.getResponsiveSetting(settings, "ha_im_gap_between_iem"), 10);
          if (!isNaN(gap)) {
            $track.css("gap", gap + "px");
          }
          originals.forEach(function (el, i) {
            var clone = el.cloneNode(true);
            // Duplicate data-id attributes and editor
            // handles confuse the Elementor editor, so
            // clones stay anonymous.
            clone.removeAttribute("data-id");
            $(clone).find(".elementor-element-overlay").remove();
            $(clone).addClass("ha-marquee-item");
            if (fixedSizes[i] > 0) {
              $(clone).css("flex", "0 0 " + fixedSizes[i] + "px");
            }
            $track.append(clone);
          }.bind(this));

          // Appending (not emptying) is additive and safe.
          $inner.append($track);
        } else {
          // FRONTEND — move items into track and lock their size.
          originals.forEach(function (el, i) {
            var $el = $(el).addClass("ha-marquee-item");
            if (fixedSizes[i] > 0) {
              $el.css("flex", "0 0 " + fixedSizes[i] + "px");
            }
            $track.append(el);
          });
          $inner.empty().append($track);
        }

        // Force reflow to ensure layout is complete
        $track[0].offsetHeight;

        // Measure one repeating set (first item + trailing gap)
        // against a probe clone of it.
        var firstChild = $track[0].children[0];
        var probe = firstChild.cloneNode(true);
        $track[0].appendChild(probe);
        var firstRect = firstChild.getBoundingClientRect();
        var probeRect = probe.getBoundingClientRect();
        var setSize;
        if (isVertical) {
          setSize = Math.abs(probeRect.top - firstRect.top);
        } else {
          setSize = Math.abs(probeRect.left - firstRect.left);
        }
        $track[0].removeChild(probe);
        setSize = Math.round(setSize);
        if (!setSize || setSize < 1) setSize = 1;

        // Determine how many sets are needed for a seamless loop
        var setsNeeded = Math.max(1, Math.ceil(containerSize / setSize));

        // Safety cap: in pathological layouts (zero-sized items)
        // avoid stamping thousands of clones.
        var MAX_SETS = 20;
        var cappedSets = Math.min(setsNeeded, MAX_SETS);

        // Clone enough full sets so the track holds
        // (cappedSets * 2) copies. To makes the loop visually seamless.
        var totalCopies = cappedSets * 2;
        for (var s = 1; s < totalCopies; s++) {
          originals.forEach(function (el, i) {
            var clone = el.cloneNode(true);
            if (isEditMode) {
              // Anonymous clones in edit mode.
              clone.removeAttribute("data-id");
              $(clone).find(".elementor-element-overlay").remove();
              $(clone).addClass("ha-marquee-item");
              if (fixedSizes[i] > 0) {
                $(clone).css("flex", "0 0 " + fixedSizes[i] + "px");
              }
            }
            $track.append(clone);
          }.bind(this));
        }
        if (isEditMode) {
          // Hide the originals ONLY after every clone has been
          // stamped (cloneNode copies inline styles, so clones
          // made from hidden elements would be invisible).
          this._savedInnerStyle = $inner.attr("style") || "";
          $inner.css("position", "relative");
          this._savedItemStyles = originals.map(function (el) {
            return el.getAttribute("style") || "";
          });
          originals.forEach(function (el) {
            el.style.position = "absolute";
            el.style.visibility = "hidden";
            el.style.pointerEvents = "none";
          });
        }

        // Distance the track travels during one full loop
        var loopSize = setSize * cappedSets;
        var speed = this.getResponsiveSetting(settings, "ha_im_speed") || 120;

        // Determine animation direction
        var from = 0;
        var to = 0;
        var direction;
        if (isVertical) {
          direction = this.getResponsiveSetting(settings, "ha_im_vertical_direction") || "top";
          if (direction === "top") {
            from = 0;
            to = -loopSize;
          } else {
            from = -loopSize;
            to = 0;
          }
        } else {
          direction = this.getResponsiveSetting(settings, "ha_im_horizontal_direction") || "left";
          if (direction === "left") {
            from = 0;
            to = -loopSize;
          } else {
            from = -loopSize;
            to = 0;
          }
        }

        // Handle Hover functionality
        $wrapper.off(".haMarquee");

        // Store track reference for cleanup (shared by both engines)
        this._track = $track[0];

        // Elips (arc) effect — replaces the CSS keyframe animation with a per-frame JS loop
        // Only available in horizontal mode (matches the demo spec).
        var elipsEnabled = settings.ha_im_elips === "yes" && !isVertical;
        if (elipsEnabled) {
          this._startElips({
            $track: $track,
            $inner: $inner,
            direction: direction,
            loopSize: loopSize,
            setSize: setSize,
            speed: speed,
            pauseOnHover: pauseOnHover,
            settings: settings
          });
        } else {
          this._startCssAnimation({
            isVertical: isVertical,
            from: from,
            to: to,
            loopSize: loopSize,
            speed: speed,
            pauseOnHover: pauseOnHover,
            $track: $track
          });
        }

        // Keep the marquee in sync when the editor re-renders the
        // child widgets (e.g. editing a widget's settings).
        if (isEditMode) {
          this._observeEditorRenders();
        }
      },
      /**
       * Default engine: CSS @keyframes infinite loop.
       * Used whenever the Elips effect is disabled (and for vertical mode).
       */
      _startCssAnimation: function _startCssAnimation(opts) {
        var _this = this;
        var isVertical = opts.isVertical;
        var from = opts.from;
        var to = opts.to;
        var loopSize = opts.loopSize;
        var speed = opts.speed;
        var pauseOnHover = opts.pauseOnHover;
        var $track = opts.$track;
        var $wrapper = this.$element;

        // Use CSS animation for smoother infinite loop
        var animationName = "ha-marquee-".concat(Date.now());
        var transformFrom = isVertical ? "translate3d(0, ".concat(from, "px, 0)") : "translate3d(".concat(from, "px, 0, 0)");
        var transformTo = isVertical ? "translate3d(0, ".concat(to, "px, 0)") : "translate3d(".concat(to, "px, 0, 0)");
        var keyframes = "\n\t\t\t\t\t\t@keyframes ".concat(animationName, " {\n\t\t\t\t\t\t\tfrom {\n\t\t\t\t\t\t\t\ttransform: ").concat(transformFrom, ";\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t\tto {\n\t\t\t\t\t\t\t\ttransform: ").concat(transformTo, ";\n\t\t\t\t\t\t\t}\n\t\t\t\t\t\t}\n\t\t\t\t\t");

        // Inject keyframes
        var styleSheet = document.createElement("style");
        styleSheet.textContent = keyframes;
        document.head.appendChild(styleSheet);

        // Apply animation to track
        var duration = loopSize / speed;
        $track[0].style.animation = "".concat(animationName, " ").concat(duration, "s linear infinite");
        $track[0].style.willChange = "transform";

        // Store references for cleanup
        this._styleSheet = styleSheet;
        this._animationName = animationName;

        // Hover handlers
        if (pauseOnHover) {
          $wrapper.on("mouseenter.haMarquee", function () {
            $track[0].style.animationPlayState = "paused";
          });
          $wrapper.on("mouseleave.haMarquee", function () {
            $track[0].style.animationPlayState = "running";
          });
        }

        // Create dummy tween object for compatibility
        this.tween = {
          pause: function pause() {
            $track[0].style.animationPlayState = "paused";
          },
          resume: function resume() {
            $track[0].style.animationPlayState = "running";
          },
          kill: function kill() {
            $track[0].style.animation = "";
            if (_this._styleSheet && _this._styleSheet.parentNode) {
              _this._styleSheet.parentNode.removeChild(_this._styleSheet);
            }
          }
        };
      },
      /**
       * Elips (arc) engine: a requestAnimationFrame loop that drives
       * the horizontal scroll AND applies per-item transforms based on
       * each item's distance from the container center:
       */
      _startElips: function _startElips(opts) {
        var _this2 = this;
        var $track = opts.$track;
        var $inner = opts.$inner;
        var direction = opts.direction;
        var loopSize = opts.loopSize;
        var setSize = opts.setSize || loopSize;
        var speed = opts.speed;
        var pauseOnHover = opts.pauseOnHover;
        var settings = opts.settings;
        var $wrapper = this.$element;

        // Elips tunables (all user-controlled)
        var curveRaw = this.getResponsiveSetting(settings, "ha_im_elips_curve");
        var curveDepth = curveRaw ? _typeof(curveRaw) === "object" ? curveRaw.size != null ? curveRaw.size : 130 : curveRaw : 130;
        var zoomEnabled = this.getResponsiveSetting(settings, "ha_im_elips_zoom", true) === "yes";
        var rotateEnabled = this.getResponsiveSetting(settings, "ha_im_elips_rotate", true) === "yes";
        var fadeEnabled = this.getResponsiveSetting(settings, "ha_im_elips_fade", true) === "yes";
        var blurEnabled = this.getResponsiveSetting(settings, "ha_im_elips_blur", true) === "yes";
        var minScale = 0.5;
        var maxScale = 1.0;
        var maxRotate = 14;

        // All track children (originals + clones) get per-frame transforms.
        var trackEl = $track[0];
        var items = Array.prototype.slice.call(trackEl.children);
        this._elipsItems = items;

        // Force-disable CSS transitions on every item. The marquee
        // items are typically Elementor widgets that carry their
        // own transitions (hover/theme effects).
        items.forEach(function (el) {
          el.style.setProperty("transition", "none", "important");
        });

        // Precompute each item's horizontal center relative to the
        // track's left edge ONCE, before any per-frame transforms are applied.
        var initTrackRect = trackEl.getBoundingClientRect();
        var itemCenters = items.map(function (el) {
          var r = el.getBoundingClientRect();
          return r.left + r.width / 2 - initTrackRect.left;
        });

        // Wrap distance = setSize (one repeating set), NOT loopSize.
        var scrollX = direction === "left" ? 0 : -setSize;
        var paused = false;
        var lastTime = performance.now();
        var rafId = null;
        var containerEl = $inner[0];
        var _render = function render(now) {
          // Self-heal: stop orphan loops if the element was
          // removed from the DOM (e.g. deleted in the editor).
          if (!trackEl.isConnected) return;

          // Clamp dt so a backgrounded tab does not jump the track.
          var dt = Math.min(0.05, (now - lastTime) / 1000);
          lastTime = now;
          if (!paused) {
            var delta = speed * dt;
            if (direction === "left") {
              scrollX -= delta;
              if (scrollX <= -setSize) scrollX += setSize;
            } else {
              scrollX += delta;
              if (scrollX >= 0) scrollX -= setSize;
            }
          }
          trackEl.style.transform = "translate3d(".concat(scrollX, "px, 0, 0)");

          // Read container + track rects ONCE per frame for all items, so the per-item transforms are consistent.
          var cRect = containerEl.getBoundingClientRect();
          var tRect = trackEl.getBoundingClientRect();
          var centerX = cRect.left + cRect.width / 2;
          var halfRange = cRect.width / 2;
          var trackLeft = tRect.left;
          for (var i = 0; i < items.length; i++) {
            var el = items[i];
            var itemCenterX = trackLeft + itemCenters[i];

            // UNCLAMPED normalized distance from center
            var norm = halfRange > 0 ? (itemCenterX - centerX) / halfRange : 0;
            // CLAMPED version kept for scale/opacity/blur calculations, so items outside the viewport don't get crazy transforms.
            var clampDist = Math.max(-1, Math.min(1, norm));
            var absDist = Math.abs(clampDist);

            // Quadratic drop using UNCLAMPED norm — items farther from center are lower on the curve.
            var yOffset = norm * norm * curveDepth;
            var scale = 1;
            if (zoomEnabled) {
              scale = maxScale - absDist * (maxScale - minScale);
            }
            var rotate = 0;
            if (rotateEnabled) {
              // Rotation follows the TANGENT of the parabolic curve, so the slope is computed from the UNCLAMPED norm.
              var slope = halfRange > 0 ? 2 * curveDepth * norm / halfRange : 0;
              rotate = Math.atan(slope) * 180 / Math.PI;
            }
            var opacity = 1;
            if (fadeEnabled) {
              opacity = 1 - absDist * 0.35;
            }
            var filterStr = "";
            if (blurEnabled && absDist > 0.7) {
              filterStr = "blur(".concat((absDist - 0.7) * 4, "px)");
            }

            // translate3d (Z=0) keeps the item on its own GPU layer, which is important for smooth per-frame transforms.
            el.style.transform = "translate3d(0, ".concat(yOffset, "px, 0) scale(").concat(scale, ") rotate(").concat(rotate, "deg)");
            if (fadeEnabled) {
              el.style.opacity = opacity;
            }
            if (blurEnabled) {
              el.style.filter = filterStr;
            }
            el.style.zIndex = String(Math.round((1 - absDist) * 100));
          }
          rafId = requestAnimationFrame(_render);
          _this2._rafId = rafId;
        };

        // Render the first frame synchronously so items receive their initial transforms
        _render(performance.now());

        // Hover handlers
        if (pauseOnHover) {
          $wrapper.on("mouseenter.haMarquee", function () {
            paused = true;
          });
          $wrapper.on("mouseleave.haMarquee", function () {
            paused = false;
            lastTime = performance.now();
          });
        }

        // Dummy tween object for API compatibility with the CSS path
        this.tween = {
          pause: function pause() {
            paused = true;
          },
          resume: function resume() {
            paused = false;
            lastTime = performance.now();
          },
          kill: function kill() {
            if (rafId) {
              cancelAnimationFrame(rafId);
              rafId = null;
            }
            _this2._rafId = null;
            trackEl.style.transform = "";
            items.forEach(function (el) {
              el.style.transform = "";
              el.style.opacity = "";
              el.style.filter = "";
              el.style.zIndex = "";
              el.style.removeProperty("transition");
            });
          }
        };
      }
    });

    // HANDLER REGISTRATION
    elementorFrontend.hooks.addAction("frontend/element_ready/global", function ($scope) {
      elementorFrontend.elementsHandler.addHandler(HappyInfiniteMarquee, {
        $element: $scope
      });
    });
  });
})(jQuery, window);