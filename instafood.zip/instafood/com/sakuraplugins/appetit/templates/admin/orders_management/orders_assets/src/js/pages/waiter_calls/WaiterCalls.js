import RestManager from '../../services/RestManager';
import DataUtils from '../../utils/DataUtils';
import EventBus, { Events, Event } from '../../events/EventBus';

let instance;
const instanceKey = '23__ad847_238_KSJK';

class WaiterCalls {

    _ui;
    _intervalId;
    _intervalCallsSeconds = 5;
    _c = 0;
    
    _calls = [];
    _newResults = [];
    _isFirstLoad = false;

    constructor(key) {
        if (key !== instanceKey) {
            throw new Error('Cannot instantiate like this')
        }
        this._ui = jQuery('#waiter_calls');

        this._intervalId = setInterval(() => {
            this._retrieveNewCalls();
        }, this._intervalCallsSeconds * 1000);
    }

    init() {
        this._retrieveNewCalls();
    }

    _retrieveNewCalls() {
        RestManager.getInstance()
        .postAjax('fetch_waiter_calls', {
        })
        .then(result => {
            this._ui.find('.orders_loading').css('opacity', 0);
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            this._newResults = lodash.get(result, 'data.waiter_calls', []);
            this._populate();
        });
    }

    _populate() {
        if (!Array.isArray(this._newResults)) {
            return;
        }
        if (this._newResults.length === 0) {
            this._handleNotfound();
            return;
        }

        const new_to_add = this._newResults.filter(entry => {
            const intersects = lodash.intersectionWith(this._calls, [entry], lodash.isEqual);
            if (intersects.length === 0) {
                return entry;
            }
        });


        if (new_to_add.length > 0 && this._isFirstLoad) {
            try {
                document.getElementById('alert2').play();
            } catch (err) {
                console.log(err);
            }
        }

        new_to_add.forEach(wCall => {
            this._calls.unshift(wCall);
            const showBackground = this._c % 2 === 1;

            const { id, table, date, tableDesc } = wCall;
            const close_waiter_call = DataUtils.getInstance().getLabel('close_waiter_call');

            const template = `
                <tr id="_${id}" class="waiter_call_entry${ showBackground ? ' fill' : '' }" data-id="${id}">
                    <th class="o_table" style="font-weight: 400;">
                    ${ table } ${ tableDesc ? `<span style="color: #7e7e7e; margin-left: 5px;">(${ tableDesc })</span>` : '' }
                    </th>
                    <th class="o_date" style="font-weight: 400;">${ date }</th>
                    <th class="o_actions">
                        <button type="button" class="btn btn-light close_waiter_call_btn">${ close_waiter_call }</button>
                    </th>
                </tr>
            `;
            const _this = this;
            this._c++;
            const call_ui = jQuery(template);
            call_ui.prependTo(this._ui.find('.appetit_table_body'));
            call_ui.find('.close_waiter_call_btn').click(function(event) {
                event.preventDefault();
                jQuery(this).attr('disabled', true);
                _this._deleteWaiterCall(id);
            })
        });
        this._isFirstLoad = true;
        this._handleNotfound();
        if (new_to_add.length > 0) {
            EventBus.getInstance().triggerEvent(Events.LIVE_WAITER_CALLS_COUNT, { count: this._calls.length });
        }
    }

    _deleteWaiterCall(id) {
        // delete_waiter_call
        RestManager.getInstance()
        .postAjax('delete_waiter_call', {
            id
        })
        .then(result => {
            this._ui.find('.orders_loading').css('opacity', 0);
            const { status } = result;
            if (status !== 'OK') {
                const { errors } = result;
                console.log(errors);
                return alert(errors[0]);
            }
            this._ui.find(`#_${id}`).remove();
            for (let i = 0; i < this._calls.length; i++) {
                if (this._calls[i]?.id === id) {
                    this._calls.splice(i, 1);
                    break;
                }
            }
            this._handleNotfound();
        });
    }

    _handleNotfound() {
        const count = this._calls.length;
        this._ui.find('.not_found').hide();
        if (count !== 0) {
            this._ui.find('.not_found').hide();
        } else {
            this._ui.find('.not_found').show();
        }
    }
    
    static getInstance() {
        if (!instance) {
            instance = new WaiterCalls(instanceKey);
        }
        return instance;
    }
}
export default WaiterCalls;