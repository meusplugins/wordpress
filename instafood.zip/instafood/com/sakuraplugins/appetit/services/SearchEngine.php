<?php
namespace com\sakuraplugins\appetit\services;

require_once(plugin_dir_path(__FILE__) . '../cpt/OrderCpt.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . '../rest_api/models/order/OrderStatus.php');


use com\sakuraplugins\appetit\cpt\OrderCpt;
use \com\sakuraplugins\appetit\rest_api\models\Order;
use \com\sakuraplugins\appetit\rest_api\models\OrderStatus;

class SearchEngine {
    
    private $query;
    private $order_status;
    private $result_per_page = -1;
    private $paged = 1;
    private $exclude_posts = [];
    private $filter_order_status;
    private $filter_order_type;
    private $filter_order_id;
    private $filter_order_safe_match;

    private $orders = [];
    private $max_num_pages = 1;
    private $found_posts = 0;
    public $orderby;

    private $errors = [];

    function __construct($query) {
        $this->query = $query;
        $this->order_status = $this->query['order_status'] ?? false;
        $this->result_per_page = $this->query['result_per_page'] ?? -1;
        $this->paged = $this->query['paged'] ?? 1;
        $this->orderby = $this->query['orderby'] ?? false;
        $this->exclude_posts = $this->query['exclude_posts'] ?? [];
        $this->filter_order_status = $this->query['filter_order_status'] ?? false;
        $this->filter_order_type = $this->query['filter_order_type'] ?? false;
        $this->filter_order_id = $this->query['filter_order_id'] ?? false;
        $this->filter_order_safe_match = $this->query['filter_order_safe_match'] ?? false;
    }

    function search() {
        $args = $this->getOrderArgsArgs();

        $this->orders = [];
        $this->max_num_pages = 1;
        $this->found_posts = 0;

        $the_query = new \WP_Query($args);

        if ($the_query->have_posts()) {
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                $post_id = get_the_ID();
                $order = new Order();
                $order->setId($post_id);
                $order->populate();
                $data = $order->getAllProperties();
                $post_date = get_the_date('Y-m-d h:ia');
                array_push($this->orders, array_merge($data, [
                    '_post_date' => $post_date
                ]));
            }
        } else {
            // no posts found
        }
        $this->max_num_pages = $the_query->max_num_pages;
        $this->found_posts = $the_query->found_posts;
        wp_reset_postdata();
        wp_reset_query();

        $result = new \stdClass();
        $result->data = [
            'orders' => $this->orders,
            'currentPage' => $this->paged,
            'max_num_pages' => $this->max_num_pages,
            'total_posts' => $this->found_posts
        ];
        $result->errors = $this->getErrors();
        return $result;
    }


    private function getOrderArgsArgs() {

        $args = [
            'post_type' => OrderCpt::getPostType(),
            'post_status' => 'private',
            'posts_per_page' => $this->result_per_page,
            'paged' => $this->paged,
            'meta_query' => [
                'relation' => 'AND'
            ]
        ];

        if ($this->filter_order_id) {
            $args['p'] = $this->filter_order_id;
        }

        if ($this->order_status) {
            array_push($args['meta_query'], [
                'key' => '_orderStatus',
                'value' => $this->order_status,
                'compare' => '='
            ]);
        } else {
            array_push($args['meta_query'], [
                'key' => '_orderStatus',
                'value' => OrderStatus::NEW_ORDER,
                'compare' => '!='
            ]);
        }

        if ($this->filter_order_status) {
            array_push($args['meta_query'], [
                'key' => '_orderStatus',
                'value' => $this->filter_order_status,
                'compare' => '='
            ]);
        }

        if ($this->filter_order_type) {
            array_push($args['meta_query'], [
                'key' => '_orderType',
                'value' => $this->filter_order_type,
                'compare' => '='
            ]);
        }

        if ($this->filter_order_safe_match) {
            array_push($args['meta_query'], [
                'key' => '_safe_match_code_lowercase',
                'value' => strtolower($this->filter_order_safe_match),
                'compare' => '='
            ]);
        }

        $isOrderByDate = $this->orderby === 'date_desc' || $this->orderby === 'date_asc';
        if ($isOrderByDate) {
            $args['orderby'] = 'date';
            if ($this->orderby === 'date_desc') {
                $args['order'] = 'DESC';
            }
            if ($this->orderby === 'date_asc') {
                $args['order'] = 'ASC';
            }
        }

        if (sizeof($this->exclude_posts) > 0) {
            $args['post__not_in'] = $this->exclude_posts;
        }

        return $args;
    }

    function hasErrors(): bool {
        return sizeof($this->errors) > 0;
    }

    function getErrors(): array {
        return $this->errors;
    }
}
?>