import EventBus, { Event, Events } from '../../events/EventBus';
import TopNav from './TopNav';
// import BottomNav from './BottomNav';
import { ORDER_TYPES } from '../../order/Order';
import LanguageUtils from '../../utils/LanguageUtils';
import DataUtils from '../../utils/DataUtils';

let instance;
const instanceKey = '_order_complete_screen';

class OrderCompletePage {

    _isOpen = false;
    _ui;
    _onOrderCompleteOpenEvent;
    _onOrderCompleteCloseEvent;
    _topNav;

    _orderSummaryData;
    _isPickup;
    _isDinein;
    _isDelivery;

    init() {
        this._ui = jQuery('#apt_order_complete_screen');
        this._topNav = new TopNav(this._ui);
        this._topNav.render();
        this._content_ui = this._ui.find('.both_nav_apt_content_ui');
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderCompleteOpenEvent = new Event(Events.OPEN_ORDER_COMPLETE_SCREEN_REQUEST, data => this._pageOpen(data));
        EventBus.getInstance().registerEvent(this._onOrderCompleteOpenEvent);
        this._onOrderCompleteCloseEvent = new Event(Events.CLOSE_ORDER_COMPLETE_SCREEN_REQUEST, data => this._pageClose(data));
        EventBus.getInstance().registerEvent(this._onOrderCompleteCloseEvent);
    }

    _renderFailMessage() {
        this._topNav.setPageTitle(LanguageUtils.getInstance().getLabel('order_complete_fail_title'));
        const template = `
        <div class="order_complete_content pt_50">
            <div class="test_center order_message">${ LanguageUtils.getInstance().getLabel('order_fail_message') }</div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderDineInMessage() {
        const template = `
        <div class="order_complete_content">
            <div class="success_content">
                <div class="checked_success">
                    <div class="checked_ui primary_color_border primary_color">
                        <span class="icon-check"></span>
                    </div>
                </div>
            </div>
            <div class="test_center order_message">${ LanguageUtils.getInstance().getLabel('order_success_dinein_msg') }</div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderDeliveryMessage() {
        const template = `
        <div class="order_complete_content">
            <div class="success_content">
                <div class="checked_success">
                    <div class="checked_ui primary_color_border primary_color">
                        <span class="icon-check"></span>
                    </div>
                </div>
            </div>
            <div class="test_center order_message">${ LanguageUtils.getInstance().getLabel('order_success_delivery_msg') }</div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderPickupMessage() {
        let order_success_pickup_msg = LanguageUtils.getInstance().getLabel('order_success_pickup_msg');
        order_success_pickup_msg = LanguageUtils.getInstance().decodeHtml(order_success_pickup_msg);
        const compiled = _.template(order_success_pickup_msg);

        const t = DataUtils.getInstance().getOption('order_success_pickup_msg');
        const order_success_pickup_msg_template = _.template(LanguageUtils.getInstance().decodeHtml(t));

        const timeInfo = `${ this._orderSummaryData?._pickup_date?.day } ${ this._orderSummaryData?._pickup_date?.time }`;
        const template = `
        <div class="order_complete_content">
            <div class="success_content">
                <div class="checked_success">
                    <div class="checked_ui primary_color_border primary_color">
                        <span class="icon-check"></span>
                    </div>
                </div>
            </div>
            <div class="test_center order_message">${ compiled({ orderPickupDate: `${ timeInfo }` }) }</div>
            <div class="test_center order_message mt_30 mb_30">${ LanguageUtils.getInstance().getLabel('order_success_pickup_safe_match_msg') }</div>
            <div class="safe_match_ui" style="background: ${ this._orderSummaryData?._safe_match_bkg };">
                <div class="safe_code">${ this._orderSummaryData?._safe_match_code }</div>
            </div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _renderPreviewMode() {
        const template = `
        <div class="appetit-alert red">
            <div class="alert-content">
                Order complete when using the card as the payment method is not available in the demo/preview mode. In order to test the flow please choose cash on delivery as the payment method on checkout.
            </div>
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _populateContent() {
        if (this._orderSummaryData === false) {
            if (DataUtils.getInstance().getOption('INSTAFOOD_PREVIEW_MODE')) {
                return this._renderPreviewMode();
            }
            this._renderFailMessage();
            return;
        }
        this._topNav.setPageTitle(LanguageUtils.getInstance().getLabel('order_complete_title'));
        
        if (this._isDinein) {
            this._renderDineInMessage();
            return;
        }

        if (this._isDelivery) {
            this._renderDeliveryMessage();
            return;
        }

        if (this._isPickup) {
            this._renderPickupMessage();
            return;
        }
    }

    _pageOpen(data) {
        this._orderSummaryData = data;
        this._isPickup = this._orderSummaryData?._orderType === ORDER_TYPES.PICKUP;
        this._isDinein = this._orderSummaryData?._orderType === ORDER_TYPES.DINEIN;
        this._isDelivery = this._orderSummaryData?._orderType === ORDER_TYPES.DELIVERY;

        this._onBeforePageOpen();
        this._ui.animate({
            top: 0
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageOpen();
        });
    }

    _onBeforePageOpen() {
        this._populateContent();
        this._ui.css('opacity', 1);
        this._ui.css('top', this._ui.height());
        if (this._ui.hasClass('hide')) {
            this._ui.removeClass('hide');
        }
    }

    _onAfterPageOpen() {
        this._isOpen = true;
    }

    _pageClose() {
        this._onBeforePageClose();
        this._ui.animate({
            top: this._ui.height()
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageClose();
        });
    }

    _onBeforePageClose() {}

    _onAfterPageClose() {
        this._isOpen = false;
        this._content_ui.empty();
        this._ui.css('opacity', 0);
    }

    static getInstance() {
        if (!instance) {
            instance = new OrderCompletePage(instanceKey);
        }
        return instance;
    }
}
export default OrderCompletePage;