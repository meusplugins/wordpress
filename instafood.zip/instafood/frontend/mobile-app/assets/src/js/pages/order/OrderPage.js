import EventBus, { Event, Events } from '../../events/EventBus';
import Cart from '../../cart/Cart';
import OrderTopNav from './OrderTopNav';
import OrderBottomNav from './OrderBottomNav';
import OrderSummary from './OrderSummary';
import ShippingMethodChoose from './ShippingMethodChoose';
import DeliveryAddressWgt from './DeliveryAddressWgt';
import PickUpWidget from './PickUpWidget';
import ChoosePaymentWidget from './ChoosePaymentWidget';
import PickupInfoWgt from './PickupInfoWgt';
import RestaurantClosedWgt from './RestaurantClosedWgt';
import Order from '../../order/Order';
import DataUtils from '../../utils/DataUtils';
import TermsAgreement from '../../components/checkbox/TermsAgreement';
import LanguageUtils from '../../utils/LanguageUtils';

let instance;
const instanceKey = '_order_screen';

class OrderPage {

    _isOpen = false;
    _ui;
    _onOrderOpenEvent;
    _onOrderCloseEvent;
    _orderTopNav;
    _orderBottomNav;
    _orderSummary;
    _restaurantClosedWgt;
    _shippingMethodChoose;

    init() {
        const hasOrderTypes = Order.getInstance().hasOrderTypes();

        this._ui = jQuery('#apt_order_screen');
        this._orderTopNav = new OrderTopNav(this._ui);
        this._orderTopNav.render();

        if (hasOrderTypes) {
            this._orderBottomNav = new OrderBottomNav(this._ui);
            this._orderBottomNav.render();
        } else {
            this._ui.find('.both_nav_apt_nav_bottom').css('display', 'none');
            this._ui.find('.both_nav_apt_content_ui').css('height', '100%');
        }
        this._content_ui = this._ui.find('.both_nav_apt_content_ui');
        this._addEventListeners();
    }

    _addEventListeners() {
        this._onOrderOpenEvent = new Event(Events.OPEN_ORDER_SCREEN_REQUEST, data => this._pageOpen(data));
        EventBus.getInstance().registerEvent(this._onOrderOpenEvent);
        this._onOrderCloseEvent = new Event(Events.CLOSE_ORDER_SCREEN_REQUEST, data => this._pageClose(data));
        EventBus.getInstance().registerEvent(this._onOrderCloseEvent);
    }

    _populateContent() {
        
        this._shippingMethodChoose = new ShippingMethodChoose(this._content_ui);
        this._shippingMethodChoose.render();

        this._restaurantClosedWgt = new RestaurantClosedWgt(this._content_ui);
        this._restaurantClosedWgt.render();

        this._orderSummary = new OrderSummary(this._content_ui);
        this._orderSummary.render();
        const daw = new DeliveryAddressWgt(this._content_ui);
        daw.render();
        const pw = new PickUpWidget(this._content_ui);
        pw.render();
        const piw = new PickupInfoWgt(this._content_ui);
        piw.render();

        const paymentOptionsW = new ChoosePaymentWidget(this._content_ui);
        paymentOptionsW.render();

        this._renderCanNotOrderInfo();

        this._renderTerms();
        this._renderReCaptcha();
    }

    _renderCanNotOrderInfo() {
        const hasOrderTypes = Order.getInstance().hasOrderTypes();
        const order_types_not_available = LanguageUtils.getInstance().getLabel('order_types_not_available');
        if (!hasOrderTypes) {
            const t = `
            <div class="apt_content_widget mt_20 bm_20 order_summary_widget">
                <div class="in_content">
                    <div class="isf_warn_alert">
                    ${order_types_not_available}
                    </div>
                    <div class="order_summary_call_btn mt_20">
                        <a href="tel:${ DataUtils.getInstance().getOption('restaurant_phone') }" class="apt_button primary bottom_close_btn">
                        <span class="icon-phone" style="margin-right: .7em;"></span>
                        ${ LanguageUtils.getInstance().getLabel('phone_call_label') }
                        </a>
                    </div>
                </div>
            </div>
            `;
            jQuery(t).appendTo(this._content_ui);
        }
    }

    _renderTerms() {
        const hasOrderTypes = Order.getInstance().hasOrderTypes();
        if (!hasOrderTypes) {
            return;
        }
        const ta = new TermsAgreement(this._content_ui, (val) => {}, false);
        ta.render();
    }

    _renderReCaptcha() {
        if (!DataUtils.getInstance().getOption('hasReCaptcha')) {
            return;
        }
        const template = `
        <div class="recaptcha-privacy">This site is protected by reCAPTCHA and the Google
        <a href="https://policies.google.com/privacy">Privacy Policy</a> and
        <a href="https://policies.google.com/terms">Terms of Service</a> apply.
        </div>
        `;
        jQuery(template).appendTo(this._content_ui);
    }

    _pageOpen(data) {
        this._onBeforePageOpen();
        this._ui.animate({
            top: 0
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageOpen();
        });
    }

    _onBeforePageOpen() {
        Order.getInstance().reset();
        this._populateContent();
        this._ui.css('opacity', 1);
        this._ui.css('top', this._ui.height());
        if (this._ui.hasClass('hide')) {
            this._ui.removeClass('hide');
        }
    }

    _onAfterPageOpen() {
        this._isOpen = true;
    }

    _pageClose() {
        this._onBeforePageClose();
        this._ui.animate({
            top: this._ui.height()
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageClose();
        });
    }

    _onBeforePageClose() {}

    _onAfterPageClose() {
        this._isOpen = false;
        this._content_ui.empty();
        this._ui.css('opacity', 0);
    }

    static getInstance() {
        if (!instance) {
            instance = new OrderPage(instanceKey);
        }
        return instance;
    }
}
export default OrderPage;