<?php
namespace com\sakuraplugins\appetit\utils;
if ( ! defined( 'ABSPATH' ) ) exit;

class Sanitizer {

    const TXT_TYPE = 'txt_type';
    const EM_TYPE = 'email';

    static function sanitizeDataArrayInput($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_string($value)) {
                    $data[$key] = sanitize_text_field(wp_unslash($value));
                }
            }
        }
        return $data;
    }

    static function sanitizeInput($val) {
        if (is_string($val)) {
            return sanitize_text_field(wp_unslash($val));
        }
        return $val;
    }

    static function sanitizeVal($val, $type = self::TXT_TYPE) {
        if ($type === self::TXT_TYPE) {
            return sanitize_text_field($val);
        }
        if ($type === self::EM_TYPE) {
            return sanitize_email($val);
        }
        return $val;
    }

    static function escapeHtmlFromArray($data) {
        if (!is_array($data)) {
            return $data;
        }
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $data[$key] = esc_html($value);
            }
        }
        return $data;
    }
}
?>