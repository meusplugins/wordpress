<?php
namespace com\sakuraplugins\appetit\rest_api\guards;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . '../controllers/ResponseHelper.php');
use \com\sakuraplugins\appetit\rest_api\controllers\ResponseHelper;

class BaseGuard {
    protected static function respondError(array $errors = []) {
        return ResponseHelper::respond([], 'FAIL', $errors);
    }
}
?>