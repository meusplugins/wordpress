import CartTopNav from './CartTopNav';
import CartBottomNav from './CartBottomNav';
import EventBus, { Event, Events } from '../../events/EventBus';
import Cart from '../../cart/Cart';
import CartItemDisplay from './CartItemDisplay';

let instance;
const instanceKey = '_cart_screen';

class CartPage {

    _isOpen = false;
    _onCartOpenEvent;
    _onCartCloseEvent;
    _ui;
    _cartTopNav;
    _cartBottomNav;
    _content_ui;
    _cartProducts = [];
    _onCartChangeEvent;

    init() {
        this._addEventListeners();
        this._ui = jQuery('#apt_cart_screen');
        this._cartTopNav = new CartTopNav(this._ui);
        this._cartTopNav.render();
        this._cartBottomNav = new CartBottomNav(this._ui);
        this._cartBottomNav.render();
        this._content_ui = this._ui.find('.both_nav_apt_content_ui');
    }

    _addEventListeners() {
        this._onCartOpenEvent = new Event(Events.OPEN_CART_SCREEN_REQUEST, data => this._pageOpen(data));
        EventBus.getInstance().registerEvent(this._onCartOpenEvent);
        this._onCartCloseEvent = new Event(Events.CLOSE_CART_SCREEN_REQUEST, data => this._pageClose(data));
        EventBus.getInstance().registerEvent(this._onCartCloseEvent);
        this._onCartChangeEvent = new Event(Events.CART_CHANGED, ({ cartProduct }) => {
            this._handleCartChange(cartProduct);
        });
        EventBus.getInstance().registerEvent(this._onCartChangeEvent);
    }

    _populateContent() {
        jQuery('<div class="cart_items_ui"></div>').appendTo(this._content_ui);
        this._cartProducts = [];
        const cartProductsData = Cart.getInstance().getCartItemsWithInfo();
        if (!Array.isArray(cartProductsData)) {
            return;
        }
        const cart_items_ui = this._content_ui.find('.cart_items_ui');
        for (let i = 0; i < cartProductsData.length; i++) {
            const cartItemData = cartProductsData[i];
            const cartItemDisplay = new CartItemDisplay(cartItemData, cart_items_ui);
            cartItemDisplay.render();
        }
    }

    _handleCartChange(cartProduct) {
        const cartTotal = Cart.getInstance().getCartTotal();
        this._cartBottomNav.update();
        if (cartTotal === 0) {
            EventBus.getInstance().triggerEvent(Events.CLOSE_CART_SCREEN_REQUEST, false);
            return;
        }
    }

    _pageOpen(data) {
        this._onBeforePageOpen();
        this._ui.animate({
            top: 0
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageOpen();
        });
    }

    _onBeforePageOpen() {
        this._cartBottomNav.update();
        this._populateContent();
        this._ui.css('opacity', 1);
        this._ui.css('top', this._ui.height());
        if (this._ui.hasClass('hide')) {
            this._ui.removeClass('hide');
        }
        this._ui.find('.cart_content_ui').scrollTop(0);
    }

    _onAfterPageOpen() {
        this._isOpen = true;
    }

    _pageClose() {
        this._onBeforePageClose();
        this._ui.animate({
            top: this._ui.height()
        }, 700, 'easeInOutQuint', () => { 
            this._onAfterPageClose();
        });
    }

    _onBeforePageClose() {}

    _onAfterPageClose() {
        this._isOpen = false;
        this._content_ui.empty();
        this._ui.css('opacity', 0);
    }

    static getInstance() {
        if (!instance) {
            instance = new CartPage(instanceKey);
        }
        return instance;
    }
}
export default CartPage;