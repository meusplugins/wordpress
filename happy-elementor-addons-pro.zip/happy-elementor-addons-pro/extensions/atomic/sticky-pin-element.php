<?php
namespace Happy_Addons_Pro\Extensions\Atomic;

use Happy_Addons\Elementor\Extensions\Atomic\Atomic_Feature_Base;

defined( 'ABSPATH' ) || die();

require_once HAPPY_ADDONS_DIR_PATH . 'extensions/atomic/atomic-feature-base.php';

/**
 * Sticky Pin Element for the Atomic containers (e-flexbox, e-div-block, e-grid)
 * and the Atomic elements that render a single root (heading, paragraph,
 * image, button, SVG).
 *
 * Same settings as the Classic Sticky Pin Element extension. Atomic settings
 * are single valued (not per-breakpoint), so the Classic responsive variants
 * collapse into one value each.
 */
class Sticky_Pin_Element extends Atomic_Feature_Base {

	protected function prefix() {
		return 'ha_spl_';
	}

	protected function target_type() {
		return 'e-flexbox';
	}

	protected function target_types() {
		return [ 'e-flexbox', 'e-div-block', 'e-grid', 'e-heading', 'e-paragraph', 'e-image', 'e-button', 'e-svg' ];
	}

	protected function feature_key() {
		return 'sticky-pin-element';
	}

	protected function section_label() {
		return __( 'Sticky Pin Element', 'happy-addons-pro' );
	}

	protected function matches_schema( array $schema ) {
		if ( ! isset( $schema['classes'], $schema['link'] ) ) {
			return false;
		}

		// A container, or one of the single root elements listed in target_types().
		return isset( $schema['tag'] ) || isset( $schema['image'] ) || isset( $schema['svg'] );
	}

	public function init() {
		parent::init();

		add_filter( 'elementor/frontend/the_content', [ $this, 'merge_duplicate_class_attributes' ], 20 );
	}

	/**
	 * Atomic elements print a "class" attribute added through the Attributes
	 * control next to their own class attribute. Browsers keep only the first
	 * duplicate, so a selector such as ".sp-end" for a custom start/end area
	 * never matches. Merge the duplicates into one class attribute.
	 */
	public function merge_duplicate_class_attributes( $content ) {
		if ( ! is_string( $content ) || false === strpos( $content, 'data-e-type' ) ) {
			return $content;
		}

		$merged = preg_replace_callback(
			'/<[a-z][a-z0-9-]*\s[^>]*\sdata-e-type=[^>]*>/i',
			function ( $match ) {
				$tag = $match[0];

				if ( preg_match_all( '/\sclass=(["\'])(.*?)\1/s', $tag, $found ) < 2 ) {
					return $tag;
				}

				$classes = trim( implode( ' ', $found[2] ) );
				$done    = false;

				return preg_replace_callback(
					'/\sclass=(["\'])(.*?)\1/s',
					function ( $class ) use ( &$done, $classes ) {
						if ( $done ) {
							return '';
						}

						$done = true;

						return ' class="' . $classes . '"';
					},
					$tag
				);
			},
			$content
		);

		return null === $merged ? $content : $merged;
	}

	private function positions() {
		return array_diff_key( self::trigger_points(), [ 'custom' => true ] );
	}

	protected function fields() {
		$on     = [ 'switcher' => true ];
		$start  = $on + [ 'start_trigger' => 'custom' ];
		$end    = $on + [ 'end_trigger' => 'custom' ];
		$custom = [
			'default' => __( 'Default', 'happy-addons-pro' ),
			'custom'  => __( 'Custom', 'happy-addons-pro' ),
		];

		return [
			'switcher'            => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable', 'happy-addons-pro' ),
				'description' => __( 'Avoid using Happy Animations and Sticky Pin on the same element.', 'happy-addons-pro' ),
			],
			'pin_start'           => [
				'type'        => 'enum',
				'default'     => 'top-top',
				'label'       => __( 'Pin Start Position', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position.', 'happy-addons-pro' ),
				'options'     => $this->positions(),
				'show'        => $on,
			],
			'start_trigger'       => [
				'type'        => 'enum',
				'default'     => 'default',
				'label'       => __( 'Start Trigger', 'happy-addons-pro' ),
				'description' => __( 'Choose "Custom" to specify a CSS selector for the element that triggers the pin.', 'happy-addons-pro' ),
				'options'     => $custom,
				'show'        => $on,
			],
			'pin_start_offset'    => [
				'type'        => 'string',
				'default'     => '0',
				'label'       => __( 'Start Offset', 'happy-addons-pro' ),
				'description' => __( 'Offset applied to the Pin Start position (e.g., 100, -100, 50%, -50%).', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'custom_start_area'   => [
				'type'        => 'string',
				'default'     => '',
				'label'       => __( 'Custom Start Area', 'happy-addons-pro' ),
				'description' => __( 'Enter a CSS selector, class or ID of the element that triggers the pin (e.g. .your-selector, #your-id or your-class).', 'happy-addons-pro' ),
				'show'        => $start,
			],
			'pin_end'             => [
				'type'        => 'enum',
				'default'     => 'bottom-bottom',
				'label'       => __( 'Pin End Position', 'happy-addons-pro' ),
				'description' => __( 'First value is the element position, second is the viewport position.', 'happy-addons-pro' ),
				'options'     => $this->positions(),
				'show'        => $on,
			],
			'end_trigger'         => [
				'type'        => 'enum',
				'default'     => 'default',
				'label'       => __( 'End Trigger', 'happy-addons-pro' ),
				'description' => __( 'Choose "Custom" to specify a CSS selector for the element that triggers the end of pinning.', 'happy-addons-pro' ),
				'options'     => $custom,
				'show'        => $on,
			],
			'pin_end_offset'      => [
				'type'        => 'string',
				'default'     => '0',
				'label'       => __( 'End Offset', 'happy-addons-pro' ),
				'description' => __( 'Offset applied to the Pin End position (e.g., 100, -100, 50%, -50%).', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'custom_end_area'     => [
				'type'        => 'string',
				'default'     => '',
				'label'       => __( 'Custom End Area', 'happy-addons-pro' ),
				'description' => __( 'Enter a CSS selector, class or ID of the element where pinning should end (e.g. .your-selector, #your-id or your-class).', 'happy-addons-pro' ),
				'show'        => $end,
			],
			'pin_type'            => [
				'type'        => 'enum',
				'default'     => 'true',
				'label'       => __( 'Pin', 'happy-addons-pro' ),
				'description' => __( 'Enable or disable element pinning during scroll.', 'happy-addons-pro' ),
				'options'     => [
					'true'  => __( 'True', 'happy-addons-pro' ),
					'false' => __( 'False', 'happy-addons-pro' ),
				],
				'show'        => $on,
			],
			'pin_markers'         => [
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Pin Markers', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'enable_on_device'    => [
				'type'        => 'bool',
				'default'     => false,
				'label'       => __( 'Enable On Mobile', 'happy-addons-pro' ),
				'description' => __( 'When disabled, the animation will not run on mobile devices.', 'happy-addons-pro' ),
				'show'        => $on,
			],
			'active_class'        => [
				'type'    => 'string',
				'default' => '',
				'label'   => __( 'Toggle Class', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'active_color'        => [
				'type'    => 'color',
				'default' => '',
				'label'   => __( 'Active Text Color', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'active_background'   => [
				'type'    => 'color',
				'default' => '',
				'label'   => __( 'Active Background Color', 'happy-addons-pro' ),
				'show'    => $on,
			],
			'transition_duration' => [
				'type'        => 'number',
				'default'     => 0.3,
				'min'         => 0,
				'max'         => 10,
				'step'        => 0.1,
				'label'       => __( 'Transition Duration(s)', 'happy-addons-pro' ),
				'description' => __( 'Set the duration of the transition effect when the element becomes sticky or returns to its normal position.', 'happy-addons-pro' ),
				'show'        => $on,
			],
		];
	}
}
