<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

namespace ThemePunch\SR\Ports;

if(!defined('ABSPATH')) exit();

/**
 * Outgoing email (WordPress: wp_mail). A host that cannot send leaves Submit Form's Email out of its editor (SR7.E.host.off formmail).
 * @since 7.2.12
 */
interface Mailer {

	/**
	 * one plain text mail
	 * @param string[] $to       validated addresses, empty = the site's own (WordPress: the admin email)
	 * @param string   $subject  one line
	 * @param string   $text     the body, plain text
	 * @param string   $reply_to a validated address or ''
	 * @return bool the host accepted the mail
	 */
	public function send($to, $subject, $text, $reply_to = '');
}
