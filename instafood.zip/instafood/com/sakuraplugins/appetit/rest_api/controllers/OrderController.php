<?php
namespace com\sakuraplugins\appetit\rest_api\controllers;
if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__) . 'ResponseHelper.php');
require_once(plugin_dir_path(__FILE__) . '../guards/Guards.php');
require_once(plugin_dir_path(__FILE__) . '../models/order/Order.php');
require_once(plugin_dir_path(__FILE__) . '../models/order/OrderTypes.php');
require_once(plugin_dir_path(__FILE__) . '../../services/StripeService.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/TimeUtils.php');
require_once(plugin_dir_path(__FILE__) . '../../utils/Sanitizer.php');

use \com\sakuraplugins\appetit\rest_api\guards\Guards;
use \com\sakuraplugins\appetit\rest_api\models\Order;
use \com\sakuraplugins\appetit\rest_api\models\OrderTypes;
use \com\sakuraplugins\appetit\utils\TimeUtils;
use com\sakuraplugins\appetit\services\LocalesService;
use \com\sakuraplugins\appetit\utils\Sanitizer;

class OrderController extends \WP_REST_Controller {

    public function register_routes() {

        register_rest_route('instafood', '/order', array(
            array(
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'createOrder'],
                'args'                => array(),
                'permission_callback' => '__return_true',
            ),
        ));
    }

    /**
     * create order
     *
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function createOrder(\WP_REST_Request $request) {

        $guardResult = Guards::use([Guards::RecaptchaGuard], $request);
        if($guardResult instanceof \WP_REST_Response) {
            return $guardResult;
        }

        $orderRaw = $request->get_param('order');
        
        $_order_type = Sanitizer::sanitizeInput($orderRaw['_order_type'] ?? '');
        $isOpen = TimeUtils::getInstance()->isOpenNow();
        if (!$isOpen && ($_order_type === OrderTypes::DELIVERY || $_order_type === OrderTypes::DINEIN)) {
            $locales = LocalesService::getInstance()->getLocales();
            $shop_closed_message = $locales['shop_closed_message']['primary_lang_'] ?? 'Tip';
            return ResponseHelper::respond([], ResponseHelper::STATUS_FAIL, [$shop_closed_message]);
        }


        $order = Order::createFromRawData($orderRaw);
        if ($order->hasErrors()) {
            return ResponseHelper::respond([], ResponseHelper::STATUS_FAIL, $order->getErrors());
        }
        $order->insertOrderToDb();
        
        return ResponseHelper::respond($order->getOrderSummary());
    }
}
?>