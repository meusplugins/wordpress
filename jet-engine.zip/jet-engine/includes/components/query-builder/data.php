<?php
namespace Jet_Engine\Query_Builder;

use Jet_Engine\Query_Builder\File_Query\Parser;
/**
 * Glossaries data controller class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once jet_engine()->plugin_path( 'includes/components/query-builder/file-query/parser.php' );

/**
 * Define Jet_Engine_Options_Data class
 */
class Data extends \Jet_Engine_Base_Data {

	/**
	 * Table name
	 *
	 * @var string
	 */
	public $table = 'post_types';

	/**
	 * Query arguments
	 *
	 * @var array
	 */
	public $query_args = array(
		'status' => 'query',
	);

	/**
	 * Table format
	 *
	 * @var string
	 */
	public $table_format = array( '%s', '%s', '%s', '%s', '%s' );

	/**
	 * Returns blacklisted post types slugs
	 *
	 * @return array
	 */
	public function items_blacklist() {
		return array();
	}

	/**
	 * Returns blacklisted post types slugs
	 *
	 * @return array
	 */
	public function meta_blacklist() {
		return array();
	}

	/**
	 * Sanitizr post type request
	 *
	 * @return void
	 */
	public function sanitize_item_request() {
		$request_args = ! empty( $this->request['args'] ) ? $this->request['args'] : array();
		$q_type       = ! empty( $request_args['query_type'] ) ? $request_args['query_type'] : false;

		if ( 'file-query' !== $q_type ) {
			return true;
		}

		$query         = ! empty( $request_args[ $q_type ] ) ? $request_args[ $q_type ] : array();
		$dynamic_query = ! empty( $request_args[ '__dynamic_' . $q_type ] ) && is_array( $request_args[ '__dynamic_' . $q_type ] )
			? $request_args[ '__dynamic_' . $q_type ]
			: array();
		$validation    = Parser::validate_query( $query, array(
			'validate_source'  => ! $this->has_dynamic_file_query_source( $dynamic_query ),
			'validate_orderby' => ! $this->has_dynamic_file_query_source( $dynamic_query ) && ! $this->has_dynamic_file_query_orderby( $dynamic_query ),
			'validate_id_column' => ! $this->has_dynamic_file_query_source( $dynamic_query ) && ! $this->has_dynamic_file_query_id_column( $dynamic_query ),
		) );

		if ( empty( $validation['errors'] ) ) {
			return true;
		}

		foreach ( $validation['errors'] as $message ) {
			$this->parent->add_notice( 'error', $message );
		}

		return false;
	}

	protected function has_dynamic_file_query_source( $dynamic_query ) {
		foreach ( array( 'data_type', 'source_type', 'source_text', 'source_file', 'json', 'csv', 'xlsx' ) as $key ) {
			if ( isset( $dynamic_query[ $key ] ) && $this->has_dynamic_file_query_value( $dynamic_query[ $key ] ) ) {
				return true;
			}
		}

		return false;
	}

	protected function has_dynamic_file_query_orderby( $dynamic_query ) {
		foreach ( array( 'orderby', 'meta_key' ) as $key ) {
			if ( isset( $dynamic_query[ $key ] ) && $this->has_dynamic_file_query_value( $dynamic_query[ $key ] ) ) {
				return true;
			}
		}

		return false;
	}

	protected function has_dynamic_file_query_id_column( $dynamic_query ) {
		return isset( $dynamic_query['id_column'] ) && $this->has_dynamic_file_query_value( $dynamic_query['id_column'] );
	}

	protected function has_dynamic_file_query_value( $value ) {
		if ( is_array( $value ) ) {
			foreach ( $value as $item ) {
				if ( $this->has_dynamic_file_query_value( $item ) ) {
					return true;
				}
			}

			return false;
		}

		return is_scalar( $value ) && '' !== trim( (string) $value );
	}

	/**
	 * Prepare post data from request to write into database
	 *
	 * @return array
	 */
	public function sanitize_item_from_request() {

		$request = $this->request;

		$result = array(
			'slug'        => '',
			'status'      => 'query',
			'labels'      => array(),
			'args'        => array(),
			'meta_fields' => array(),
		);

		$name = ! empty( $request['name'] ) ? sanitize_text_field( $request['name'] ) : 'Untitled query';

		$labels = array(
			'name' => $name,
		);

		// Sanitize arguments
		$args          = array();
		$request_args  = ! empty( $request['args'] ) ? $request['args'] : array();
		$q_type        = ! empty( $request_args['query_type'] ) ? $request_args['query_type'] : false;
		$allowed_types = apply_filters(
			'jet-engine/query-builder/data/allowed-query-types',
			array_keys( Manager::instance()->editor->get_types() ),
			$request
		);

		if ( in_array( $q_type, $allowed_types ) ) {
			$dynamic = '__dynamic_';
			$args['query_type'] = $q_type;
			$args[ $q_type ] = isset( $request_args[ $q_type ] ) ? $request_args[ $q_type ] : array();
			$args[ $dynamic . $q_type ] = isset( $request_args[ $dynamic . $q_type ] ) ? $request_args[ $dynamic . $q_type ] : array();

			if ( 'file-query' === $q_type ) {
				$args[ $q_type ] = Parser::normalize_query( $args[ $q_type ] );
			}
		}

		$bool_args = array(
			'show_preview',
			'cache_query',
			'api_endpoint',
			'avoid_duplicates',
		);

		foreach ( $bool_args as $key ) {
			$value = isset( $request_args[ $key ] ) ? $request_args[ $key ] : false;
			$args[ $key ] = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
		}

		$regular_args = array(
			'preview_page',
			'preview_page_title',
			'preview_query_string',
			'query_id',
			'description',
			'api_namespace',
			'api_path',
			'api_access',
			'api_access_cap',
			'api_access_role',
			'api_schema',
			'cache_expires',
		);

		foreach ( $regular_args as $key ) {
			$args[ $key ] = isset( $request_args[ $key ] ) ? $request_args[ $key ] : null;
		}

		if ( ! empty( $args['api_endpoint'] ) && empty( $args['api_access'] ) ) {
			$args['api_access'] = 'role';
		}

		$result['slug']   = null;
		$result['labels'] = $labels;
		$result['args']   = $args;

		return $result;

	}

	/**
	 * Sanitize meta fields
	 *
	 * @param  [type] $meta_fields [description]
	 * @return [type]              [description]
	 */
	public function sanitize_meta_fields( $meta_fields ) {
		return $meta_fields;
	}

	/**
	 * Filter post type for register
	 *
	 * @return array
	 */
	public function filter_item_for_register( $item ) {

		$result       = array();
		$args         = jet_engine_safe_unserialize_array( $item['args'], 'query_builder_register_args' );
		$labels       = jet_engine_safe_unserialize_array( $item['labels'], 'query_builder_register_labels' );
		$args['name'] = isset( $labels['name'] ) ? $labels['name'] : '';
		$result       = array_merge( $item, $args );

		// Set default value for `cache_query` & `cache_expires` settings.
		if ( ! isset( $result['cache_query'] ) ) {
			$result['cache_query'] = true;
		}

		if ( ! isset( $result['cache_expires'] ) ) {
			$result['cache_expires'] = 0;
		}

		unset( $result['args'] );
		unset( $result['labels'] );
		unset( $result['status'] );
		unset( $result['slug'] );
		unset( $result['meta_fields'] );

		return $result;

	}

	/**
	 * Filter post type for edit
	 *
	 * @return array
	 */
	public function filter_item_for_edit( $item ) {
		return $this->filter_item_for_register( $item );
	}

}
