<?php

namespace Jet_Menu\Modules\Dynamic_Visibility\Conditions;

if ( ! defined( 'WPINC' ) ) {
	die;
}

class WC_Is_Product_Category extends Base_Condition {

	public function get_key() {
		return 'wc_is_product_category';
	}

	public function check( $rule, $context ) {
		return function_exists( 'is_product_category' ) ? is_product_category() : false;
	}
}